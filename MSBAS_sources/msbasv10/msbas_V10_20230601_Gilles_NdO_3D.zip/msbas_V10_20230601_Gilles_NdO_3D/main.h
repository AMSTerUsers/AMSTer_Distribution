#ifndef MAIN_H
#define MAIN_H


#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <sstream> 
#include <cstdlib>
#include <cmath>
#include <cstdio>
#include <vector>
#include <stdexcept>
#include <algorithm> 
#include <chrono>
#include <ctime>
#include <gdal_priv.h>
#include <gdal_alg.h>

#include <omp.h>
#include <mpi.h>

using namespace std;

#define ERROR(msg) ErrorMessage(__FILE__,__LINE__,__func__, msg)
#define LOG_FILE "MSBAS_LOG.txt"
#define PI 3.1415926

string ErrorMessage(const char *fname, int lineno, const char *fxname, string msg);
void WriteLog(string message);
string i2s(long num);
string i2sf(long num); //formatted
string f2s(double num);
bool fexists(const char *filename);

extern "C" {
    
    void sgelss_(int *m, int *n, int *nrhs, float *a, int *lda,
            float *b, int *ldb, float *s, float *RCOND, int *RANK, float *work,
            int *lwork, int *info);

    void dgelss_(int *m, int *n, int *nrhs, double *a, int *lda,
            double *b, int *ldb, double *s, double *RCOND, int *RANK, double *work,
            int *lwork, int *info);

    void sgelsd_(int *m, int *n, int *nrhs, float *a, int *lda,
            float *b, int *ldb, float *s, float *RCOND, int *RANK, float *work,
            int *lwork, int *iwork, int *info);

    void dgelsd_(int *m, int *n, int *nrhs, double *a, int *lda,
            double *b, int *ldb, double *s, double *RCOND, int *RANK, double *work,
            int *lwork, int *iwork, int *info);
}

#endif /* MAIN_H */

