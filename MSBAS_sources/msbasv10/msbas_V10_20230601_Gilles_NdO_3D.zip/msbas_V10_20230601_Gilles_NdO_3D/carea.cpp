#include "carea.h"

carea::carea(string name, int world_size, int world_rank)
{
    PAR = new Param(name);
    WORLD_SIZE = world_size;
    WORLD_RANK = world_rank;

    DIM = 0;
    ROWS = 0;
    COLUMNS = 0;

    int nlines_per_block = ceil(PAR->LENGTH / WORLD_SIZE);
    LINE_START = nlines_per_block*WORLD_RANK;
    LINE_STOP = (WORLD_RANK != (WORLD_SIZE - 1) ? nlines_per_block * (WORLD_RANK + 1) - 1 : PAR->LENGTH - 1);
    WriteLog("process " + i2s(WORLD_RANK) + " of " + i2s(WORLD_SIZE) + " will process lines in range " + i2s(LINE_START) + " - " + i2s(LINE_STOP));
    BLOCK_SIZE = PAR->WIDTH * (LINE_STOP - LINE_START);

    ZSCORE_MASK.assign(PAR->WIDTH * PAR->LENGTH, 0);
    for (int i = 0; i < PAR->SET.size(); i++) SET.push_back(Set(PAR, i));

    // interpolate data
    if (PAR->FORMAT_INT_RADIUS > 0)
    {
        // count interferograms
        vector <Interferogram *> pInSAR;
        for (int l = 0; l < SET.size(); l++) for (int k = 0; k < SET[l].InSAR.size(); k++) pInSAR.push_back(&SET[l].InSAR[k]);
        int ints_per_node = ceil(pInSAR.size()/WORLD_SIZE);
        int int_start = ints_per_node*WORLD_RANK;
        int int_stop  = (WORLD_RANK != (WORLD_SIZE - 1) ? ints_per_node * (WORLD_RANK + 1) - 1 : pInSAR.size() - 1);
        WriteLog("process " + i2s(WORLD_RANK) + " of " + i2s(WORLD_SIZE) + " will interpolate interferograms in range " + i2s(int_start) + " - " + i2s(int_stop));

        for (int i = int_start; i <= int_stop; i++)
        {
            WriteLog("process " + i2s(WORLD_RANK) + " of " + i2s(WORLD_SIZE) + " started interpolating interferogram " + pInSAR[i]->NAME);
            PAR->Interpolate(pInSAR[i]->NAME);
            WriteLog("process " + i2s(WORLD_RANK) + " of " + i2s(WORLD_SIZE) + " finished interpolating interferogram " + pInSAR[i]->NAME);
        }
    }

    if (PAR->DDNS_FILE.size() > 0 && PAR->DDEW_FILE.size() > 0)
    {
        DD[0].assign(PAR->WIDTH * PAR->LENGTH, PAR->NAN_VAL);
        DD[1].assign(PAR->WIDTH * PAR->LENGTH, PAR->NAN_VAL);
        PAR->ReadAll(PAR->DDNS_FILE, &DD[0][0]);
        PAR->ReadAll(PAR->DDEW_FILE, &DD[1][0]);
    }
}

carea::~carea()
{
    // delete *.temp files
    if (WORLD_RANK == 0 && PAR->FORMAT_INT_RADIUS > 0)
    {
        WriteLog("\ncleaning up...");
        for (int l = 0; l < SET.size(); l++)
            for (int k = 0; k < SET[l].InSAR.size(); k++)
                remove((SET[l].InSAR[k].NAME + ".temp").c_str());
    }
}

void carea::preprocess()
{
    // compute statistics
    if (WORLD_RANK == 0) WriteLog("\nanalysing spatial coverage...");
    for (int l = 0; l < SET.size(); l++)
    {
        // mask out based on data
        #pragma omp parallel for
        for (int k = 0; k < SET[l].InSAR.size(); k++)
        {
            float *data = (float*) calloc(PAR->WIDTH * PAR->LENGTH, sizeof (float));
            if (!data) throw std::invalid_argument(ERROR("can not allocate memory"));

            // read data
            if (PAR->FORMAT_INT_RADIUS > 0)
                PAR->ReadAll(SET[l].InSAR[k].NAME + ".temp", data);
            else
                PAR->ReadAll(SET[l].InSAR[k].NAME, data);

            SET[l].InSAR[k].Statistics(data);

            if (SET[l].InSAR[k].COV < PAR->MC_FLAG) SET[l].InSAR[k].DEL = true;

            SET[l].InSAR[k].Calibrate(data);

            if (SET[l].InSAR[k].DEL == false)
            {
                #pragma omp critical            
                {
                    for (int i = 0; i < PAR->WIDTH; i++)
                        for (int j = 0; j < PAR->LENGTH; j++)
                        {
                            if (ZSCORE_MASK[i + PAR->WIDTH * j] >= 0 && data[i + PAR->WIDTH * j] != PAR->NAN_VAL)
                                ZSCORE_MASK[i + PAR->WIDTH * j] += abs(data[i + PAR->WIDTH * j] - SET[l].InSAR[k].MEAN) / SET[l].InSAR[k].STD;
                            else if (ZSCORE_MASK[i + PAR->WIDTH * j] > 0 && data[i + PAR->WIDTH * j] == PAR->NAN_VAL)
                                ZSCORE_MASK[i + PAR->WIDTH * j] = -1;
                            else if (ZSCORE_MASK[i + PAR->WIDTH * j] != -1)
                                ZSCORE_MASK[i + PAR->WIDTH * j] = -2;

                            if (ZSCORE_MASK[i + PAR->WIDTH * j] == -2 && data[i + PAR->WIDTH * j] != PAR->NAN_VAL)
                                ZSCORE_MASK[i + PAR->WIDTH * j] = -1;
                        }
                }
            }
            if (data) free(data);
        }

        // mask out based on look up tables
        #pragma omp parallel for
        for (int i = 0; i < PAR->WIDTH; i++)
            for (int j = 0; j < PAR->LENGTH; j++)
                if (SET[l].S[0][i + j * PAR->WIDTH] == PAR->NAN_VAL) ZSCORE_MASK[i + PAR->WIDTH * j] = -2;
    }
    // mask out based on dem
    if (PAR->DDNS_FILE.size() > 0 && PAR->DDEW_FILE.size() > 0)
    {
        for (int i = 0; i < PAR->WIDTH; i++)
            for (int j = 0; j < PAR->LENGTH; j++)
                if (DD[0][i + j * PAR->WIDTH] == PAR->NAN_VAL || DD[1][i + j * PAR->WIDTH] == PAR->NAN_VAL) ZSCORE_MASK[i + PAR->WIDTH * j] = -2;
    }

    double fcov = 0, pcov = 0;
    for (int i = 0; i < PAR->WIDTH; i++)
        for (int j = 0; j < PAR->LENGTH; j++)
        {
            if (ZSCORE_MASK[i + PAR->WIDTH * j] >= 0)
                fcov += 1.0;
            if (ZSCORE_MASK[i + PAR->WIDTH * j] >= -1)
                pcov += 1.0;
            if (ZSCORE_MASK[i + PAR->WIDTH * j] == -2)
                ZSCORE_MASK[i + PAR->WIDTH * j] = 0;
        }
    if (WORLD_RANK == 0) WriteLog("partial coverage = " + f2s(pcov / (PAR->WIDTH * PAR->LENGTH)) + " full coverage = " + f2s(fcov / (PAR->WIDTH * PAR->LENGTH)));

    // remove interferograms set for deletion
    for (int l = 0; l < SET.size(); l++)
        for (int k = 0; k < SET[l].InSAR.size();)
            if (SET[l].InSAR[k].DEL == true)
            {
                if (WORLD_RANK == 0) WriteLog("removing due to low spatial coverage " + SET[l].InSAR[k].FNAME + " COV = " + f2s(SET[l].InSAR[k].COV));
                SET[l].InSAR.erase(SET[l].InSAR.begin() + k);
                SET[l].rInSARs++;
            } else
                k++;

    if (PAR->C_FLAG == 100)
    {
        if (WORLD_RANK == 0) WriteLog("\ncomputing location of minimal z-score...");

        double zscore_min_init = 1e9;
        double zscore_min = zscore_min_init, coverage_min = 0;
        while (zscore_min == zscore_min_init && PAR->CSIZE > 0 && PAR->LSIZE > 0)
        {
            if (WORLD_RANK == 0) WriteLog("trying region CSIZE = " + i2s(PAR->CSIZE) + " LSIZE = " + i2s(PAR->LSIZE));

            for (int ii = 0; ii < PAR->WIDTH; ii++)
                for (int jj = 0; jj < PAR->LENGTH; jj++)
                    if (ZSCORE_MASK[ii + PAR->WIDTH * jj] > 0)
                    {
                        double zscore = 0, coverage = 0;
                        double count = 0, count_all = 0;

                        for (int i = (ii - PAR->CSIZE); i <= (ii + PAR->CSIZE); i++)
                            for (int j = (jj - PAR->LSIZE); j <= (jj + PAR->LSIZE); j++)
                            {
                                if ((i >= 0)&&(j >= 0)&&(i < PAR->WIDTH)&&(j < PAR->LENGTH) && ZSCORE_MASK[i + PAR->WIDTH * j] > 0)
                                {
                                    zscore += ZSCORE_MASK[i + PAR->WIDTH * j];
                                    count += 1.0;
                                }
                                count_all += 1.0;
                            }
                        if (count > 0.68 * count_all && zscore / count < zscore_min)
                        {
                            zscore_min = zscore / count;
                            coverage_min = count / count_all;
                            PAR->C_FLAG = 1;
                            PAR->CPOS[0] = ii;
                            PAR->LPOS[0] = jj;
                        }
                    }
            PAR->CSIZE--;
            PAR->LSIZE--;
        }

        if (zscore_min != zscore_min_init)
        {
            // print absolute coordinates even if WINDOW_SIZE is specified, but in processing use relative coordinates
            if (WORLD_RANK == 0) WriteLog("minimal z-score is found at column = " + i2s(PAR->CPOS[0] + PAR->CSTART) + " and row = " + i2s(PAR->LPOS[0] + PAR->LSTART));
            PAR->C_FLAG = 1;

            for (int l = 0; l < SET.size(); l++)
                #pragma omp parallel for
                for (int k = 0; k < SET[l].InSAR.size(); k++)
                {
                    float *data = (float*) calloc(PAR->WIDTH * PAR->LENGTH, sizeof (float));
                    if (!data) throw std::invalid_argument(ERROR("can not allocate memory"));

                    // read data and compute statistics
                    if (PAR->FORMAT_INT_RADIUS > 0)
                        PAR->ReadAll(SET[l].InSAR[k].NAME + ".temp", data);
                    else
                        PAR->ReadAll(SET[l].InSAR[k].NAME, data);

                    // compute calibration offset
                    SET[l].InSAR[k].Calibrate(data);
                    if (data) free(data);
                }
            // remove interferograms set for deletion
            for (int l = 0; l < SET.size(); l++)
                for (int k = 0; k < SET[l].InSAR.size();)
                    if (SET[l].InSAR[k].DEL == true)
                    {
                        if (WORLD_RANK == 0) WriteLog("removing due to low spatial coverage " + SET[l].InSAR[k].FNAME + " COV = " + f2s(SET[l].InSAR[k].COV));
                        SET[l].InSAR.erase(SET[l].InSAR.begin() + k);
                        SET[l].rInSARs++;
                    } else
                        k++;
        } else
        {
            WriteLog("cannot compute minimal z-score, assuming C_FLAG=10");
            PAR->C_FLAG = 10;
        }
    }

    double count = 0;
    for (int l = 0; l < SET.size(); l++) count += SET[l].InSAR.size();
    if (count == 0) throw std::invalid_argument(ERROR("no interferograms left for processing, try filling gaps by interpolation"));

    if (WORLD_RANK == 0) WriteLog("\ncomputing problem dimension...");
    float lfn = 10e9;
    if (SET.size() <= 0)
        throw std::invalid_argument(ERROR("incorrect number of sets"));
    else
    {
        int ra = 0, aa = 0, rd = 0, ad = 0, dem = 0; // range ascending, azimuth ascending, range descending, azimuth descending, DEM
        for (int i = 0; i < SET.size(); i++)
        {
            if (SET[i].PASS == 'A' && SET[i].TYPE == 'R')
                ra++;
            else if (SET[i].PASS == 'A' && SET[i].TYPE == 'A')
                aa++;
            else if (SET[i].PASS == 'D' && SET[i].TYPE == 'R')
                rd++;
            else if (SET[i].PASS == 'D' && SET[i].TYPE == 'A')
                ad++;
            else
                throw std::invalid_argument(ERROR("incorrect set type and/or azimuth"));
        }

        // DEM
        if (PAR->DDNS_FILE.size() != 0 && PAR->DDEW_FILE.size() != 0) dem = 1;

        // This is not an exhaustive list!

        // just one kind of a set
        if (((aa > 0) && (ad + ra + rd) == 0) || ((ad > 0) && (aa + ra + rd) == 0) || ((ra > 0) && (aa + ad + rd) == 0) || ((rd > 0) && (aa + ad + ra) == 0))
        {
            DIM = 1;

            for (int l = 0; l < SET.size(); l++)
                for (int k = 0; k < SET[l].InSAR.size(); k++)
                {
                    SLC.push_back(Image(SET[l].InSAR[k].IMAGE[0]));
                    SLC.push_back(Image(SET[l].InSAR[k].IMAGE[1]));
                }

        }// no azimuth offsets, no DEM
        else if ((aa + ad) == 0 && dem == 0 && ra > 0 && rd > 0)
        {
            //DIM = 2;
            DIM = 3;
            double start_asc = lfn;
            double start_dsc = lfn;
            double stop_asc = 0;
            double stop_dsc = 0;
            for (int l = 0; l < SET.size(); l++)
                for (int k = 0; k < SET[l].InSAR.size(); k++)
                    if (SET[l].InSAR[k].PASS == 'A')
                    {
                        if (SET[l].InSAR[k].IMAGE[0].DATE < start_asc) start_asc = SET[l].InSAR[k].IMAGE[0].DATE;
                        if (SET[l].InSAR[k].IMAGE[1].DATE > stop_asc) stop_asc = SET[l].InSAR[k].IMAGE[1].DATE;
                    } else if (SET[l].InSAR[k].PASS == 'D')
                    {
                        if (SET[l].InSAR[k].IMAGE[0].DATE < start_dsc) start_dsc = SET[l].InSAR[k].IMAGE[0].DATE;
                        if (SET[l].InSAR[k].IMAGE[1].DATE > stop_dsc) stop_dsc = SET[l].InSAR[k].IMAGE[1].DATE;
                    }
            double datestart = max(start_asc, start_dsc);
            double datestop = min(stop_asc, stop_dsc);
            for (int l = 0; l < SET.size(); l++)
                for (int k = 0; k < SET[l].InSAR.size(); k++)
                {
                    if (SET[l].InSAR[k].IMAGE[0].DATE >= datestart && SET[l].InSAR[k].IMAGE[0].DATE <= datestop)
                        SLC.push_back(Image(SET[l].InSAR[k].IMAGE[0]));
                    if (SET[l].InSAR[k].IMAGE[1].DATE >= datestart && SET[l].InSAR[k].IMAGE[1].DATE <= datestop)
                        SLC.push_back(Image(SET[l].InSAR[k].IMAGE[1]));
                }
        }// (DEM (SPF) or azimuth offsets) and range offsets
        else if ((dem > 0 || (aa + ad) > 0) && ra > 0 && rd > 0)
        {
            if (dem > 0 && (aa + ad) > 0 && PAR->D_FLAG == 1)
                DIM = 4;
            else
                DIM = 3;
            double start_asc = lfn;
            double start_dsc = lfn;
            double stop_asc = 0;
            double stop_dsc = 0;
            for (int l = 0; l < SET.size(); l++)
                for (int k = 0; k < SET[l].InSAR.size(); k++)
                    if (SET[l].InSAR[k].PASS == 'A')
                    {
                        if (SET[l].InSAR[k].IMAGE[0].DATE < start_asc) start_asc = SET[l].InSAR[k].IMAGE[0].DATE;
                        if (SET[l].InSAR[k].IMAGE[1].DATE > stop_asc) stop_asc = SET[l].InSAR[k].IMAGE[1].DATE;
                    } else if (SET[l].InSAR[k].PASS == 'D')
                    {
                        if (SET[l].InSAR[k].IMAGE[0].DATE < start_dsc) start_dsc = SET[l].InSAR[k].IMAGE[0].DATE;
                        if (SET[l].InSAR[k].IMAGE[1].DATE > stop_dsc) stop_dsc = SET[l].InSAR[k].IMAGE[1].DATE;
                    }
            double datestart = max(start_asc, start_dsc);
            double datestop = min(stop_asc, stop_dsc);
            for (int l = 0; l < SET.size(); l++)
                for (int k = 0; k < SET[l].InSAR.size(); k++)
                {
                    if (SET[l].InSAR[k].IMAGE[0].DATE >= datestart && SET[l].InSAR[k].IMAGE[0].DATE <= datestop)
                        SLC.push_back(Image(SET[l].InSAR[k].IMAGE[0]));
                    if (SET[l].InSAR[k].IMAGE[1].DATE >= datestart && SET[l].InSAR[k].IMAGE[1].DATE <= datestop)
                        SLC.push_back(Image(SET[l].InSAR[k].IMAGE[1]));
                }
        }// either ascending or descending azimuth and range and DEM (SPF)
        else if (((aa > 0 && ra > 0 && ad == 0 && rd == 0) || (ad > 0 && rd > 0 && aa == 0 && ra == 0)) && dem > 0)
        {
            DIM = 3;
            for (int l = 0; l < SET.size(); l++)
                for (int k = 0; k < SET[l].InSAR.size(); k++)
                {
                    SLC.push_back(Image(SET[l].InSAR[k].IMAGE[0]));
                    SLC.push_back(Image(SET[l].InSAR[k].IMAGE[1]));
                }
        } else
            throw std::invalid_argument(ERROR("cannot determine problem dimension, detected unsupported combination of input data"));
    }

    WriteLog("MSBAS-" + i2s(DIM) + "D");
    sort(SLC.begin(), SLC.end());
    SLC.erase(unique(SLC.begin(), SLC.end()), SLC.end());
    if (SLC.empty()) throw std::invalid_argument(ERROR("no valid SLCs are available"));

    // applying boundary correction

    for (int l = 0; l < SET.size(); l++)
        for (int k = 0; k < SET[l].InSAR.size();)
            if (SET[l].InSAR[k].IMAGE[1].DATE > SLC[0].DATE && SET[l].InSAR[k].IMAGE[0].DATE < SLC[SLC.size() - 1].DATE)
            {
                SET[l].InSAR[k].Boundary(SLC[0].DATE, SLC[SLC.size() - 1].DATE);
                k++;
            } else
            {
                if (WORLD_RANK == 0) WriteLog("removing due to temporal coverage " + SET[l].InSAR[k].FNAME + " COV = " + f2s(SET[l].InSAR[k].COV));
                SET[l].InSAR.erase(SET[l].InSAR.begin() + k);
                SET[l].rInSARt++;
            }

    // compute time matrix
    // estimate matrix size

    for (int l = 0; l < SET.size(); l++) ROWS += SET[l].InSAR.size();
    COLUMNS = DIM * (SLC.size() - 1);

    // constraint for motion along slope
    if (PAR->DDNS_FILE.size() > 0 && PAR->DDEW_FILE.size() > 0) ROWS = ROWS + (SLC.size() - 1);

    // regularization
    if (PAR->R_FLAG == 1)
        ROWS = ROWS + COLUMNS;
    else if (PAR->R_FLAG == 2 && (COLUMNS - 1 * DIM) > 0)
        ROWS = ROWS + COLUMNS - 1 * DIM;
    else if (PAR->R_FLAG == 3 && (COLUMNS - 2 * DIM) > 0)
        ROWS = ROWS + COLUMNS - 2 * DIM;

    // allocate memory for TIME_MATRIX
    TIME_MATRIX.assign(COLUMNS * ROWS, 0);

    // populate matrix
    int rows = 0;

    for (int l = 0; l < SET.size(); l++)
        for (int k = 0; k < SET[l].InSAR.size(); k++)
        {
            for (int m = 0; m < (SLC.size() - 1); m++)
                for (int n = 0; n < DIM; n++)
                {
                    if (SLC[m].DATE >= SET[l].InSAR[k].IMAGE[0].DATE && SLC[m].DATE < SET[l].InSAR[k].IMAGE[1].DATE)
                        TIME_MATRIX[n + m * DIM + rows * COLUMNS] = (SLC[m + 1].DATE - SLC[m].DATE);
                }
            rows++;
        }

    // constraint for motion along slope
    if (PAR->DDNS_FILE.size() > 0 && PAR->DDEW_FILE.size() > 0)
        rows = rows + (SLC.size() - 1);

    // regularization
    if (PAR->R_FLAG == 1)
        for (int i = 0; i < COLUMNS; i++)
        {
            TIME_MATRIX[(rows + i) * COLUMNS + i] = PAR->R_LAMBDA;
        } else if (PAR->R_FLAG == 2)
        for (int i = 0; i < (COLUMNS - 1 * DIM); i++)
        {
            TIME_MATRIX[(rows + i) * COLUMNS + i] = -PAR->R_LAMBDA;
            TIME_MATRIX[(rows + i) * COLUMNS + i + 1 * DIM] = PAR->R_LAMBDA;
        } else if (PAR->R_FLAG == 3)
        for (int i = 0; i < (COLUMNS - 2 * DIM); i++)
        {
            TIME_MATRIX[(rows + i) * COLUMNS + i] = PAR->R_LAMBDA;
            TIME_MATRIX[(rows + i) * COLUMNS + i + 1 * DIM] = -2 * PAR->R_LAMBDA;
            TIME_MATRIX[(rows + i) * COLUMNS + i + 2 * DIM] = PAR->R_LAMBDA;
        }

    // compute and write summary
    if (WORLD_RANK == 0)
    {
        // compute distributions
        for (int l = 0; l < SET.size(); l++)
            for (int k = 0; k < SET[l].InSAR.size(); k++)
                for (int j = 0; j < SLC.size(); j++)
                {
                    if (SET[l].InSAR[k].IMAGE[0].DATE == SLC[j].DATE) SLC[j].COUNT[0] += 1.0;
                    if (SET[l].InSAR[k].IMAGE[1].DATE == SLC[j].DATE) SLC[j].COUNT[1] += 1.0;
                }

        for (int l = 0; l < SET.size(); l++)
        {
            for (int k = 0; k < SET[l].InSAR.size(); k++)
                for (int j = 0; j < SLC.size(); j++)
                {
                    if (SET[l].InSAR[k].IMAGE[0].DATE == SLC[j].DATE)
                    {
                        SET[l].InSAR[k].IMAGE[0].COUNT[0] = SLC[j].COUNT[0];
                        SET[l].InSAR[k].IMAGE[0].COUNT[1] = SLC[j].COUNT[1];
                        SET[l].SLC.push_back(SLC[j]);
                    }
                    if (SET[l].InSAR[k].IMAGE[1].DATE == SLC[j].DATE)
                    {
                        SET[l].InSAR[k].IMAGE[1].COUNT[0] = SLC[j].COUNT[0];
                        SET[l].InSAR[k].IMAGE[1].COUNT[1] = SLC[j].COUNT[1];
                        SET[l].SLC.push_back(SLC[j]);
                    }
                }
            sort(SET[l].SLC.begin(), SET[l].SLC.end());
            SET[l].SLC.erase(unique(SET[l].SLC.begin(), SET[l].SLC.end()), SET[l].SLC.end());
        }

        WriteLog("\nsummary...");

        int nInSAR = 0;
        for (int l = 0; l < SET.size(); l++)
        {
            WriteLog("SET " + i2s(l) + ": NAME = " + SET[l].NAME + " PASS = " + SET[l].PASS + " TYPE = " + SET[l].TYPE);
            WriteLog("       nInSAR provided = " + i2s(PAR->SET[l].InSAR.size()) + " removed low.s.cov = " + i2s(SET[l].rInSARs) + " removed low.t.cov = " + i2s(SET[l].rInSARt) + " left = " + i2s(SET[l].InSAR.size()));
            WriteLog("       nSLC = " + i2s(SET[l].SLC.size()) + " first = " + SET[l].SLC[0].NAME + " last = " + SET[l].SLC[SET[l].SLC.size() - 1].NAME);
            nInSAR += SET[l].InSAR.size();
        }
        WriteLog("nInSAR = " + i2s(nInSAR));
        WriteLog("nSLC = " + i2s(SLC.size()) + " first = " + SLC[0].NAME + " last = " + SLC[SLC.size() - 1].NAME + " or first = " + f2s(SLC[0].DATE) + " last = " + f2s(SLC[SLC.size() - 1].DATE));

        WriteLog("inversion parameters for problem Ax=Y: unknowns (columns in A, (nSLC-1)*DIM) = " + i2s(COLUMNS) + " equations (rows in A, nInSAR +(nSLC-0/1/2*DIM)*DIM +(nSLC-1)*DD)) = " + i2s(ROWS));
        WriteLog("A: " + i2s(COLUMNS) + " x " + i2s(ROWS));
        WriteLog("x: " + i2s(PAR->WIDTH) + " x " + i2s(COLUMNS));
        WriteLog("Y: " + i2s(PAR->WIDTH) + " x " + i2s(ROWS));

        WriteLog("SLC distribution");
        for (int i = 0; i < SLC.size(); i++) WriteLog(SLC[i].NAME + " slave = " + i2s(SLC[i].COUNT[1]) + " master = " + i2s(SLC[i].COUNT[0]));

        WriteLog("InSAR distribution (MasS, MasM, SasS, SasM)");
        for (int l = 0; l < SET.size(); l++)
            for (int k = 0; k < SET[l].InSAR.size(); k++)
            {
                string str = "";
                if (SET[l].InSAR[k].IMAGE[0].COUNT[1] == 0 && SET[l].InSAR[k].IMAGE[1].COUNT[0] == 0) str = " - disconnected and can be deleted";
                WriteLog(SET[l].InSAR[k].FNAME + " " + i2s(SET[l].InSAR[k].IMAGE[0].COUNT[1]) + " " + i2s(SET[l].InSAR[k].IMAGE[0].COUNT[0]) + " " + i2s(SET[l].InSAR[k].IMAGE[1].COUNT[1]) + " " + i2s(SET[l].InSAR[k].IMAGE[1].COUNT[0]) + str);
            }
    }
}

void carea::read()
{
    for (int l = 0; l < SET.size(); l++)
        #pragma omp parallel for
        for (int k = 0; k < SET[l].InSAR.size(); k++)
        {
            SET[l].InSAR[k].LOS.push_back(Buffer(PAR, SET[l].InSAR[k].NAME, LINE_START, LINE_STOP));
            SET[l].InSAR[k].LOS[0].ReadLines();
        }

    RANK.push_back(Buffer(PAR, "MSBAS_RANK", LINE_START, LINE_STOP));
    COND_NUM.push_back(Buffer(PAR, "MSBAS_COND_NUM", LINE_START, LINE_STOP));
    NORM_X.push_back(Buffer(PAR, "MSBAS_NORM_X", LINE_START, LINE_STOP));
    NORM_AXY.push_back(Buffer(PAR, "MSBAS_NORM_AXY", LINE_START, LINE_STOP));
    STACK.push_back(Buffer(PAR, "MSBAS_STACK", LINE_START, LINE_STOP));
    STACK.push_back(Buffer(PAR, "MSBAS_STACK_STD", LINE_START, LINE_STOP));

    LINEAR_RATE.push_back(Image(PAR, "MSBAS_LINEAR_RATE"));
    LINEAR_RATE.push_back(Image(PAR, "MSBAS_LINEAR_RATE_STD"));
    LINEAR_RATE.push_back(Image(PAR, "MSBAS_LINEAR_RATE_R2"));

    if (DIM == 1)
    {
        LINEAR_RATE[0].LOS.push_back(Buffer(PAR, LINEAR_RATE[0].NAME + "_LOS", LINE_START, LINE_STOP));
        LINEAR_RATE[1].LOS.push_back(Buffer(PAR, LINEAR_RATE[1].NAME + "_LOS", LINE_START, LINE_STOP));
        LINEAR_RATE[2].LOS.push_back(Buffer(PAR, LINEAR_RATE[2].NAME + "_LOS", LINE_START, LINE_STOP));

        for (int l = 0; l < SLC.size(); l++)
        {
            SLC[l].LOS.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_LOS", LINE_START, LINE_STOP));
            SLC[l].LOS.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_vLOS", LINE_START, LINE_STOP));
        }
    } else if (DIM == 2)
    {
        LINEAR_RATE[0].EW.push_back(Buffer(PAR, LINEAR_RATE[0].NAME + "_EW", LINE_START, LINE_STOP));
        LINEAR_RATE[1].EW.push_back(Buffer(PAR, LINEAR_RATE[1].NAME + "_EW", LINE_START, LINE_STOP));
        LINEAR_RATE[2].EW.push_back(Buffer(PAR, LINEAR_RATE[2].NAME + "_EW", LINE_START, LINE_STOP));

        LINEAR_RATE[0].UD.push_back(Buffer(PAR, LINEAR_RATE[0].NAME + "_UD", LINE_START, LINE_STOP));
        LINEAR_RATE[1].UD.push_back(Buffer(PAR, LINEAR_RATE[1].NAME + "_UD", LINE_START, LINE_STOP));
        LINEAR_RATE[2].UD.push_back(Buffer(PAR, LINEAR_RATE[2].NAME + "_UD", LINE_START, LINE_STOP));

        for (int l = 0; l < SLC.size(); l++)
        {
            SLC[l].EW.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_EW", LINE_START, LINE_STOP));
            SLC[l].EW.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_vEW", LINE_START, LINE_STOP));
            SLC[l].UD.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_UD", LINE_START, LINE_STOP));
            SLC[l].UD.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_vUD", LINE_START, LINE_STOP));
        }

    } else if (DIM == 3)
    {
        LINEAR_RATE[0].NS.push_back(Buffer(PAR, LINEAR_RATE[0].NAME + "_NS", LINE_START, LINE_STOP));
        LINEAR_RATE[1].NS.push_back(Buffer(PAR, LINEAR_RATE[1].NAME + "_NS", LINE_START, LINE_STOP));
        LINEAR_RATE[2].NS.push_back(Buffer(PAR, LINEAR_RATE[2].NAME + "_NS", LINE_START, LINE_STOP));

        LINEAR_RATE[0].EW.push_back(Buffer(PAR, LINEAR_RATE[0].NAME + "_EW", LINE_START, LINE_STOP));
        LINEAR_RATE[1].EW.push_back(Buffer(PAR, LINEAR_RATE[1].NAME + "_EW", LINE_START, LINE_STOP));
        LINEAR_RATE[2].EW.push_back(Buffer(PAR, LINEAR_RATE[2].NAME + "_EW", LINE_START, LINE_STOP));

        LINEAR_RATE[0].UD.push_back(Buffer(PAR, LINEAR_RATE[0].NAME + "_UD", LINE_START, LINE_STOP));
        LINEAR_RATE[1].UD.push_back(Buffer(PAR, LINEAR_RATE[1].NAME + "_UD", LINE_START, LINE_STOP));
        LINEAR_RATE[2].UD.push_back(Buffer(PAR, LINEAR_RATE[2].NAME + "_UD", LINE_START, LINE_STOP));

        for (int l = 0; l < SLC.size(); l++)
        {
            SLC[l].NS.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_NS", LINE_START, LINE_STOP));
            SLC[l].NS.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_vNS", LINE_START, LINE_STOP));
            SLC[l].EW.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_EW", LINE_START, LINE_STOP));
            SLC[l].EW.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_vEW", LINE_START, LINE_STOP));
            SLC[l].UD.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_UD", LINE_START, LINE_STOP));
            SLC[l].UD.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_vUD", LINE_START, LINE_STOP));
        }
    } else if (DIM == 4)
    {
        LINEAR_RATE[0].NS.push_back(Buffer(PAR, LINEAR_RATE[0].NAME + "_NS", LINE_START, LINE_STOP));
        LINEAR_RATE[1].NS.push_back(Buffer(PAR, LINEAR_RATE[1].NAME + "_NS", LINE_START, LINE_STOP));
        LINEAR_RATE[2].NS.push_back(Buffer(PAR, LINEAR_RATE[2].NAME + "_NS", LINE_START, LINE_STOP));

        LINEAR_RATE[0].EW.push_back(Buffer(PAR, LINEAR_RATE[0].NAME + "_EW", LINE_START, LINE_STOP));
        LINEAR_RATE[1].EW.push_back(Buffer(PAR, LINEAR_RATE[1].NAME + "_EW", LINE_START, LINE_STOP));
        LINEAR_RATE[2].EW.push_back(Buffer(PAR, LINEAR_RATE[2].NAME + "_EW", LINE_START, LINE_STOP));

        LINEAR_RATE[0].UD.push_back(Buffer(PAR, LINEAR_RATE[0].NAME + "_UD", LINE_START, LINE_STOP));
        LINEAR_RATE[1].UD.push_back(Buffer(PAR, LINEAR_RATE[1].NAME + "_UD", LINE_START, LINE_STOP));
        LINEAR_RATE[2].UD.push_back(Buffer(PAR, LINEAR_RATE[2].NAME + "_UD", LINE_START, LINE_STOP));

        LINEAR_RATE[0].U1.push_back(Buffer(PAR, LINEAR_RATE[0].NAME + "_U1", LINE_START, LINE_STOP));
        LINEAR_RATE[1].U1.push_back(Buffer(PAR, LINEAR_RATE[1].NAME + "_U1", LINE_START, LINE_STOP));
        LINEAR_RATE[2].U1.push_back(Buffer(PAR, LINEAR_RATE[2].NAME + "_U1", LINE_START, LINE_STOP));

        for (int l = 0; l < SLC.size(); l++)
        {
            SLC[l].NS.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_NS", LINE_START, LINE_STOP));
            SLC[l].NS.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_vNS", LINE_START, LINE_STOP));
            SLC[l].EW.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_EW", LINE_START, LINE_STOP));
            SLC[l].EW.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_vEW", LINE_START, LINE_STOP));
            SLC[l].UD.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_UD", LINE_START, LINE_STOP));
            SLC[l].UD.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_vUD", LINE_START, LINE_STOP));
            SLC[l].U1.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_U1", LINE_START, LINE_STOP));
            SLC[l].U1.push_back(Buffer(PAR, "MSBAS_" + SLC[l].NAME + "_vU1", LINE_START, LINE_STOP));
        }
    }
    if (WORLD_RANK == 0)
    {
        PAR->WriteAll("MSBAS_ZSCORE_MASK", &ZSCORE_MASK[0]);

        // write time matrix
        FILE * pFile;
        pFile = fopen("MSBAS_TIME_MATRIX.txt", "w");
        if (pFile == 0) throw std::invalid_argument("cannot create MSBAS_TIME_MATRIX.txt");
        for (int j = 0; j < ROWS; j++)
        {
            for (int i = 0; i < COLUMNS; i++)
            {
                fprintf(pFile, "%11.6f ", TIME_MATRIX[i + COLUMNS * j]);
            }
            fprintf(pFile, "\n");
        }
        fclose(pFile);

        // write TSOUT
        pFile = fopen("MSBAS_TSOUT.txt", "w");
        if (!pFile) throw std::invalid_argument(ERROR("can not write to file MSBAS_TSOUT.txt"));
        if (PAR->FORMAT == 2)
            fprintf(pFile, "%s=%i,%i\n", "FORMAT", PAR->FORMAT, PAR->FORMAT_INT_RADIUS);
        else
            fprintf(pFile, "%s=%i\n", "FORMAT", PAR->FORMAT);

        fprintf(pFile, "%s=%i,%i\n", "FILE_SIZE", PAR->FWIDTH, PAR->FLENGTH);
        fprintf(pFile, "%s=%i", "C_FLAG", PAR->C_FLAG);
        if ((PAR->C_FLAG > 0)&&(PAR->C_FLAG < 10))
        {
            for (int i = 0; i < PAR->C_FLAG; i++)
                fprintf(pFile, ", %i, %i", PAR->CPOS[i] + PAR->CSTART, PAR->LPOS[i] + PAR->LSTART);
            fprintf(pFile, ", %i, %i\n", PAR->CSIZE, PAR->LSIZE);
        } else
            fprintf(pFile, "\n");

        for (int k = 0; k < SLC.size(); k++)
        {
            if (DIM == 1)
            {
                string f1 = SLC[k].LOS[0].NAME;
                if (PAR->FORMAT == 0 || PAR->FORMAT == 1)
                {
                    f1 += ".bin";
                } else if (PAR->FORMAT == 2)
                {
                    f1 += ".tif";
                }
                fprintf(pFile, "%s %f %s\n", SLC[k].NAME.c_str(), SLC[k].DATE, f1.c_str());
            } else if (DIM == 2)
            {
                string f1 = SLC[k].EW[0].NAME;
                string f2 = SLC[k].UD[0].NAME;

                if (PAR->FORMAT == 0 || PAR->FORMAT == 1)
                {
                    f1 += ".bin";
                    f2 += ".bin";
                } else if (PAR->FORMAT == 2)
                {
                    f1 += ".tif";
                    f2 += ".tif";
                }
                fprintf(pFile, "%s %f %s %s\n", SLC[k].NAME.c_str(), SLC[k].DATE, f1.c_str(), f2.c_str());
            } else if (DIM == 3)
            {
                string f1 = SLC[k].NS[0].NAME;
                string f2 = SLC[k].EW[0].NAME;
                string f3 = SLC[k].UD[0].NAME;

                if (PAR->FORMAT == 0 || PAR->FORMAT == 1)
                {
                    f1 += ".bin";
                    f2 += ".bin";
                    f3 += ".bin";
                } else if (PAR->FORMAT == 2)
                {
                    f1 += ".tif";
                    f2 += ".tif";
                    f3 += ".tif";
                }
                fprintf(pFile, "%s %f %s %s %s\n", SLC[k].NAME.c_str(), SLC[k].DATE, f1.c_str(), f2.c_str(), f3.c_str());
            } else if (DIM == 4)
            {
                string f1 = SLC[k].NS[0].NAME;
                string f2 = SLC[k].EW[0].NAME;
                string f3 = SLC[k].UD[0].NAME;
                string f4 = SLC[k].U1[0].NAME;

                if (PAR->FORMAT == 0 || PAR->FORMAT == 1)
                {
                    f1 += ".bin";
                    f2 += ".bin";
                    f3 += ".bin";
                    f4 += ".bin";
                } else if (PAR->FORMAT == 2)
                {
                    f1 += ".tif";
                    f2 += ".tif";
                    f3 += ".tif";
                    f4 += ".tif";
                }
                fprintf(pFile, "%s %f %s %s %s %s\n", SLC[k].NAME.c_str(), SLC[k].DATE, f1.c_str(), f2.c_str(), f3.c_str(), f4.c_str());
            }
        }
        fclose(pFile);
        
        // write TSOUT
        pFile = fopen("MSBAS_vTSOUT.txt", "w");
        if (!pFile) throw std::invalid_argument(ERROR("can not write to file MSBAS_vTSOUT.txt"));
        if (PAR->FORMAT == 2)
            fprintf(pFile, "%s=%i,%i\n", "FORMAT", PAR->FORMAT, PAR->FORMAT_INT_RADIUS);
        else
            fprintf(pFile, "%s=%i\n", "FORMAT", PAR->FORMAT);

        fprintf(pFile, "%s=%i,%i\n", "FILE_SIZE", PAR->FWIDTH, PAR->FLENGTH);
        fprintf(pFile, "%s=%i", "C_FLAG", PAR->C_FLAG);
        if ((PAR->C_FLAG > 0)&&(PAR->C_FLAG < 10))
        {
            for (int i = 0; i < PAR->C_FLAG; i++)
                fprintf(pFile, ", %i, %i", PAR->CPOS[i] + PAR->CSTART, PAR->LPOS[i] + PAR->LSTART);
            fprintf(pFile, ", %i, %i\n", PAR->CSIZE, PAR->LSIZE);
        } else
            fprintf(pFile, "\n");

        for (int k = 0; k < SLC.size(); k++)
        {
            if (DIM == 1)
            {
                string f1 = SLC[k].LOS[1].NAME;
                if (PAR->FORMAT == 0 || PAR->FORMAT == 1)
                {
                    f1 += ".bin";
                } else if (PAR->FORMAT == 2)
                {
                    f1 += ".tif";
                }
                fprintf(pFile, "%s %f %s\n", SLC[k].NAME.c_str(), SLC[k].DATE, f1.c_str());
            } else if (DIM == 2)
            {
                string f1 = SLC[k].EW[1].NAME;
                string f2 = SLC[k].UD[1].NAME;

                if (PAR->FORMAT == 0 || PAR->FORMAT == 1)
                {
                    f1 += ".bin";
                    f2 += ".bin";
                } else if (PAR->FORMAT == 2)
                {
                    f1 += ".tif";
                    f2 += ".tif";
                }
                fprintf(pFile, "%s %f %s %s\n", SLC[k].NAME.c_str(), SLC[k].DATE, f1.c_str(), f2.c_str());
            } else if (DIM == 3)
            {
                string f1 = SLC[k].NS[1].NAME;
                string f2 = SLC[k].EW[1].NAME;
                string f3 = SLC[k].UD[1].NAME;

                if (PAR->FORMAT == 0 || PAR->FORMAT == 1)
                {
                    f1 += ".bin";
                    f2 += ".bin";
                    f3 += ".bin";
                } else if (PAR->FORMAT == 2)
                {
                    f1 += ".tif";
                    f2 += ".tif";
                    f3 += ".tif";
                }
                fprintf(pFile, "%s %f %s %s %s\n", SLC[k].NAME.c_str(), SLC[k].DATE, f1.c_str(), f2.c_str(), f3.c_str());
            } else if (DIM == 4)
            {
                string f1 = SLC[k].NS[1].NAME;
                string f2 = SLC[k].EW[1].NAME;
                string f3 = SLC[k].UD[1].NAME;
                string f4 = SLC[k].U1[1].NAME;

                if (PAR->FORMAT == 0 || PAR->FORMAT == 1)
                {
                    f1 += ".bin";
                    f2 += ".bin";
                    f3 += ".bin";
                    f4 += ".bin";
                } else if (PAR->FORMAT == 2)
                {
                    f1 += ".tif";
                    f2 += ".tif";
                    f3 += ".tif";
                    f4 += ".tif";
                }
                fprintf(pFile, "%s %f %s %s %s %s\n", SLC[k].NAME.c_str(), SLC[k].DATE, f1.c_str(), f2.c_str(), f3.c_str(), f4.c_str());
            }
        }
        fclose(pFile);
    }
}

void carea::stacking()
{
    WriteLog("\ncomputing stack...");
    #pragma omp parallel for collapse(2)
    for (int j0 = LINE_START; j0 <= LINE_STOP; j0++)
        for (int i = 0; i < PAR->WIDTH; i++)
        {
            int j = j0 - LINE_START;
            double phi_sum = 0, dt_sum = 0, var_sum = 0, n = 0;

            if (ZSCORE_MASK[i + j0 * PAR->WIDTH] != PAR->NAN_VAL)
            {
                // computing stack
                for (int l = 0; l < SET.size(); l++)
                    for (int k = 0; k < SET[l].InSAR.size(); k++)
                    {
                        double dt = SET[l].InSAR[k].IMAGE[1].DATE - SET[l].InSAR[k].IMAGE[0].DATE;
                        double phi = (SET[l].InSAR[k].LOS[0].DATA[i + j * PAR->WIDTH] - SET[l].InSAR[k].OFFSET) * SET[l].InSAR[k].BNDCOR;
                        phi_sum += phi;
                        dt_sum += dt;
                    }
                STACK[0].DATA[i + j * PAR->WIDTH] = phi_sum / dt_sum;

                // computing variance
                for (int l = 0; l < SET.size(); l++)
                    for (int k = 0; k < SET[l].InSAR.size(); k++)
                    {
                        double dt = SET[l].InSAR[k].IMAGE[1].DATE - SET[l].InSAR[k].IMAGE[0].DATE;
                        double phi = (SET[l].InSAR[k].LOS[0].DATA[i + j * PAR->WIDTH] - SET[l].InSAR[k].OFFSET) * SET[l].InSAR[k].BNDCOR;
                        double phi_mean = STACK[0].DATA[i + j * PAR->WIDTH];

                        var_sum += pow(phi / dt - phi_mean, 2);
                        n += 1.0;
                    }
                if (n > 1) STACK[1].DATA[i + j * PAR->WIDTH] = sqrt(var_sum) / (n - 1);
            }
        }
}

void carea::process()
{
    //stacking();

    WriteLog("\ncomputing time series using SVD inversion...");

    int lwork, ilwork;
    dgelsd_query(ROWS, COLUMNS, 1, lwork, ilwork); // memory requirements for inversion
    if (lwork <= 0 || ilwork <= 0) throw std::invalid_argument(ERROR("LAPACK function returned error"));

    int np = omp_get_num_procs(); // number of processes
    long data_size_double = (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS) + (DIM + 1) * SLC.size()) * np;
    long data_size_int = ilwork * np;
    if (WORLD_RANK == 0) WriteLog("allocating memory for SVD inversion (by pixels) " + f2s((data_size_double * sizeof (float) +data_size_int * sizeof (int)) / pow(1024, 3)) + "GB, number of processes " + i2s(np) + "\n");

    double *data = new double [data_size_double];
    int *idata = new int [data_size_int];

    double steps_completed = 0;

    #pragma omp parallel for collapse(2)
    for (int j0 = LINE_START; j0 <= LINE_STOP; j0++)
        for (int i = 0; i < PAR->WIDTH; i++)
        {
            int j = j0 - LINE_START;
            if (ZSCORE_MASK[i + j0 * PAR->WIDTH] != PAR->NAN_VAL)
            {
                int pn = omp_get_thread_num();
                double *TM = data + pn * COLUMNS * ROWS;
                memset(TM, 0, sizeof (double)*COLUMNS * ROWS);
                double *TMt = data + np * 1 * COLUMNS * ROWS + pn * COLUMNS * ROWS;
                memset(TMt, 0, sizeof (double)*COLUMNS * ROWS);
                double *TMts = data + np * 2 * COLUMNS * ROWS + pn * COLUMNS * ROWS;
                memset(TMts, 0, sizeof (double)*COLUMNS * ROWS);

                double *V = data + np * (3 * COLUMNS * ROWS) + pn * max(ROWS, COLUMNS);
                memset(V, 0, sizeof (double)*max(ROWS, COLUMNS));
                double *V1d = data + np * (3 * COLUMNS * ROWS + max(ROWS, COLUMNS)) + pn * max(ROWS, COLUMNS);

                double *work = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS)) + pn * lwork;
                double *s = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork) + pn * min(ROWS, COLUMNS);
                int *iwork = idata + pn * ilwork;

                int rows = 0, rows_all = 0;

                for (int l = 0; l < SET.size(); l++)
                    for (int k = 0; k < SET[l].InSAR.size(); k++)
                    {
                        if (SET[l].InSAR[k].LOS[0].DATA[i + j * PAR->WIDTH] != PAR->NAN_VAL)
                        {
                            V[rows] = (SET[l].InSAR[k].LOS[0].DATA[i + j * PAR->WIDTH] - SET[l].InSAR[k].OFFSET) * SET[l].InSAR[k].BNDCOR;
                            for (int ii = 0; ii < DIM * (SLC.size() - 1); ii = ii + DIM)
                            {
                                if (DIM == 1)
                                {
                                    TM[ii + 0 + rows * COLUMNS] = TIME_MATRIX[ii + 0 + rows_all * COLUMNS];
                                } else if (DIM == 2)
                                {
                                    TM[ii + 0 + rows * COLUMNS] = TIME_MATRIX[ii + 0 + rows_all * COLUMNS] * SET[l].S[1][i + j0 * PAR->WIDTH];
                                    TM[ii + 1 + rows * COLUMNS] = TIME_MATRIX[ii + 1 + rows_all * COLUMNS] * SET[l].S[2][i + j0 * PAR->WIDTH];
                                } else if (DIM == 3)
                                {
                                    TM[ii + 0 + rows * COLUMNS] = TIME_MATRIX[ii + 0 + rows_all * COLUMNS] * SET[l].S[0][i + j0 * PAR->WIDTH];
                                    TM[ii + 1 + rows * COLUMNS] = TIME_MATRIX[ii + 1 + rows_all * COLUMNS] * SET[l].S[1][i + j0 * PAR->WIDTH];
                                    TM[ii + 2 + rows * COLUMNS] = TIME_MATRIX[ii + 2 + rows_all * COLUMNS] * SET[l].S[2][i + j0 * PAR->WIDTH];
                                } else if (DIM == 4)
                                {
                                    TM[ii + 0 + rows * COLUMNS] = TIME_MATRIX[ii + 0 + rows_all * COLUMNS] * SET[l].S[0][i + j0 * PAR->WIDTH];
                                    TM[ii + 1 + rows * COLUMNS] = TIME_MATRIX[ii + 1 + rows_all * COLUMNS] * SET[l].S[1][i + j0 * PAR->WIDTH];
                                    TM[ii + 2 + rows * COLUMNS] = TIME_MATRIX[ii + 2 + rows_all * COLUMNS] * SET[l].S[2][i + j0 * PAR->WIDTH];
                                    TM[ii + 3 + rows * COLUMNS] = TIME_MATRIX[ii + 3 + rows_all * COLUMNS] * SET[l].S[2][i + j0 * PAR->WIDTH];
                                }
                            }
                            rows++;
                        }
                        rows_all++;
                    }

                // col-major to row-major the 1d matrix before appending regularization rows
                for (int ii = 0; ii < COLUMNS; ii++) for (int jj = 0; jj < rows; jj++) TMts[jj + ii * rows] = TM[ii + jj * COLUMNS];

                int rank = 0;
                double cond_num = 0;

                // no interferograms
                if (rows == 0) continue;

                if (dgelsd(TMts, rows, COLUMNS, V1d, 1, rank, cond_num, lwork, ilwork, work, s, iwork) != 0) continue;
                RANK[0].DATA[i + j * PAR->WIDTH] = rank;

                if (PAR->DDNS_FILE.size() > 0 && PAR->DDEW_FILE.size() > 0) // watch for a case with DIM=3 and DD files provided (i.e. still 3D but with the constraint)
                {
                    for (int jj = rows; jj < (rows + SLC.size() - 1); jj++)
                    {
                        TM[jj * COLUMNS + DIM * (jj - rows) + 0] = DD[0][i + j0 * PAR->WIDTH];
                        TM[jj * COLUMNS + DIM * (jj - rows) + 1] = DD[1][i + j0 * PAR->WIDTH];
                        TM[jj * COLUMNS + DIM * (jj - rows) + 2] = -1;
                    }
                    rows = rows + SLC.size() - 1;
                }

                if (PAR->R_FLAG == 1)
                {
                    for (int i = 0; i < COLUMNS; i++)
                    {
                        TM[(rows + i) * COLUMNS + i] = PAR->R_LAMBDA;
                    }
                    rows = rows + COLUMNS;
                } else if (PAR->R_FLAG == 2)
                {
                    for (int i = 0; i < (COLUMNS - 1 * DIM); i++)
                    {
                        TM[(rows + i) * COLUMNS + i] = -PAR->R_LAMBDA;
                        TM[(rows + i) * COLUMNS + i + 1 * DIM] = PAR->R_LAMBDA;
                    }
                    rows = rows + COLUMNS - 1 * DIM;
                } else if (PAR->R_FLAG == 3)
                {
                    for (int i = 0; i < (COLUMNS - 2 * DIM); i++)
                    {
                        TM[(rows + i) * COLUMNS + i] = PAR->R_LAMBDA;
                        TM[(rows + i) * COLUMNS + i + 1 * DIM] = -2 * PAR->R_LAMBDA;
                        TM[(rows + i) * COLUMNS + i + 2 * DIM] = PAR->R_LAMBDA;
                    }
                    rows = rows + COLUMNS - 2 * DIM;
                }

                // col-major to row-major
                for (int ii = 0; ii < COLUMNS; ii++) for (int jj = 0; jj < rows; jj++) TMt[jj + ii * rows] = TM[ii + jj * COLUMNS];

                /*                if (i==0 && j==0)
                                {
                                    FILE * pFile;
                                    pFile = fopen(("A" + i2s(i) + ".txt").c_str(), "w");
                
                                    if (pFile == 0) throw std::invalid_argument("Error: CArea::MakeTimeMatrix2D, pFile == 0. Cannot open file MSBAS_TIME_MATRIX.txt.");
                                    for (int jj = 0; jj < rows; jj++)
                                    {
                                        for (int ii = 0; ii < COLUMNS; ii++)
                                        {
                                            fprintf(pFile, "%11.6f ", TM[ii + COLUMNS * jj]);
                                        }
                                        fprintf(pFile, "\n");
                                    }
                                    fclose(pFile);
                
                                    pFile = fopen(("Y" + i2s(i) + ".txt").c_str(), "w");
                                    if (pFile == 0) throw std::invalid_argument("Error: CArea::MakeTimeMatrix2D, pFile == 0. Cannot open file MSBAS_TIME_MATRIX.txt.");
                                    for (int kk = 0; kk < rows; kk++) fprintf(pFile, "%11.6f \n", V[kk]);
                                    fclose(pFile);
                                }
                 */

                // perform inversion
                if (dgelsd(TMt, rows, COLUMNS, V, 1, rank, cond_num, lwork, ilwork, work, s, iwork) != 0) continue;
                COND_NUM[0].DATA[i + j * PAR->WIDTH] = cond_num;


                // reconstruct time series and compute norm ||x||
                NORM_X[0].DATA[i + j * PAR->WIDTH] = 0;

                double *time = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS)) + pn * SLC.size();
                time[0] = SLC[0].DATE;

                double *los, *ns, *ew, *ud, *u1;
                if (DIM == 1)
                {
                    los = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS) + 1 * SLC.size()) + pn * SLC.size();
                    los[0] = 0;
                } else if (DIM == 2)
                {
                    ew = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS) + 1 * SLC.size()) + pn * SLC.size();
                    ud = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS) + 2 * SLC.size()) + pn * SLC.size();
                    ew[0] = 0;
                    ud[0] = 0;
                } else if (DIM == 3)
                {
                    ns = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS) + 1 * SLC.size()) + pn * SLC.size();
                    ew = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS) + 2 * SLC.size()) + pn * SLC.size();
                    ud = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS) + 3 * SLC.size()) + pn * SLC.size();
                    ns[0] = 0;
                    ew[0] = 0;
                    ud[0] = 0;
                } else if (DIM == 4)
                {
                    ns = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS) + 1 * SLC.size()) + pn * SLC.size();
                    ew = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS) + 2 * SLC.size()) + pn * SLC.size();
                    ud = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS) + 3 * SLC.size()) + pn * SLC.size();
                    u1 = data + np * (3 * COLUMNS * ROWS + 2 * max(ROWS, COLUMNS) + lwork + min(ROWS, COLUMNS) + 4 * SLC.size()) + pn * SLC.size();
                    ns[0] = 0;
                    ew[0] = 0;
                    ud[0] = 0;
                    u1[0] = 0;
                }

                for (int k = 0; k < (SLC.size() - 1); k++)
                {
                    time[k + 1] = SLC[k + 1].DATE;
                    double dt = (SLC[k + 1].DATE - SLC[k].DATE);
                    if (DIM == 1)
                    {
                        SLC[k + 1].LOS[0].DATA[i + j * PAR->WIDTH] = SLC[k].LOS[0].DATA[i + j * PAR->WIDTH] + V[DIM * k + 0] * dt;
                        SLC[k + 1].LOS[1].DATA[i + j * PAR->WIDTH] = V[DIM * k + 0];

                        los[k + 1] = SLC[k + 1].LOS[0].DATA[i + j * PAR->WIDTH];
                        NORM_X[0].DATA[i + j * PAR->WIDTH] += V[DIM * k + 0] * V[DIM * k + 0];
                    } else if (DIM == 2)
                    {

                        SLC[k + 1].EW[0].DATA[i + j * PAR->WIDTH] = SLC[k].EW[0].DATA[i + j * PAR->WIDTH] + V[DIM * k + 0] * dt;
                        SLC[k + 1].UD[0].DATA[i + j * PAR->WIDTH] = SLC[k].UD[0].DATA[i + j * PAR->WIDTH] + V[DIM * k + 1] * dt;
                        SLC[k + 1].EW[1].DATA[i + j * PAR->WIDTH] = V[DIM * k + 0];
                        SLC[k + 1].UD[1].DATA[i + j * PAR->WIDTH] = V[DIM * k + 1];

                        ew[k + 1] = SLC[k + 1].EW[0].DATA[i + j * PAR->WIDTH];
                        ud[k + 1] = SLC[k + 1].UD[0].DATA[i + j * PAR->WIDTH];
                        NORM_X[0].DATA[i + j * PAR->WIDTH] += V[DIM * k + 0] * V[DIM * k + 0] + V[DIM * k + 1] * V[DIM * k + 1];
                    } else if (DIM == 3)
                    {

                        SLC[k + 1].NS[0].DATA[i + j * PAR->WIDTH] = SLC[k].NS[0].DATA[i + j * PAR->WIDTH] + V[DIM * k + 0] * dt;
                        SLC[k + 1].EW[0].DATA[i + j * PAR->WIDTH] = SLC[k].EW[0].DATA[i + j * PAR->WIDTH] + V[DIM * k + 1] * dt;
                        SLC[k + 1].UD[0].DATA[i + j * PAR->WIDTH] = SLC[k].UD[0].DATA[i + j * PAR->WIDTH] + V[DIM * k + 2] * dt;
                        SLC[k + 1].NS[1].DATA[i + j * PAR->WIDTH] = V[DIM * k + 0];
                        SLC[k + 1].EW[1].DATA[i + j * PAR->WIDTH] = V[DIM * k + 1];
                        SLC[k + 1].UD[1].DATA[i + j * PAR->WIDTH] = V[DIM * k + 2];

                        ns[k + 1] = SLC[k + 1].NS[0].DATA[i + j * PAR->WIDTH];
                        ew[k + 1] = SLC[k + 1].EW[0].DATA[i + j * PAR->WIDTH];
                        ud[k + 1] = SLC[k + 1].UD[0].DATA[i + j * PAR->WIDTH];
                        NORM_X[0].DATA[i + j * PAR->WIDTH] += V[DIM * k + 0] * V[DIM * k + 0] + V[DIM * k + 1] * V[DIM * k + 1] + V[DIM * k + 2] * V[DIM * k + 2];
                    } else if (DIM == 4)
                    {
                        SLC[k + 1].NS[0].DATA[i + j * PAR->WIDTH] = SLC[k].NS[0].DATA[i + j * PAR->WIDTH] + V[DIM * k + 0] * dt;
                        SLC[k + 1].EW[0].DATA[i + j * PAR->WIDTH] = SLC[k].EW[0].DATA[i + j * PAR->WIDTH] + V[DIM * k + 1] * dt;
                        SLC[k + 1].UD[0].DATA[i + j * PAR->WIDTH] = SLC[k].UD[0].DATA[i + j * PAR->WIDTH] + V[DIM * k + 2] * dt;
                        SLC[k + 1].U1[0].DATA[i + j * PAR->WIDTH] = SLC[k].U1[0].DATA[i + j * PAR->WIDTH] + V[DIM * k + 3] * dt;
                        SLC[k + 1].NS[1].DATA[i + j * PAR->WIDTH] = V[DIM * k + 0];
                        SLC[k + 1].EW[1].DATA[i + j * PAR->WIDTH] = V[DIM * k + 1];
                        SLC[k + 1].UD[1].DATA[i + j * PAR->WIDTH] = V[DIM * k + 2];
                        SLC[k + 1].U1[1].DATA[i + j * PAR->WIDTH] = V[DIM * k + 3];

                        ns[k + 1] = SLC[k + 1].NS[0].DATA[i + j * PAR->WIDTH];
                        ew[k + 1] = SLC[k + 1].EW[0].DATA[i + j * PAR->WIDTH];
                        ud[k + 1] = SLC[k + 1].UD[0].DATA[i + j * PAR->WIDTH];
                        u1[k + 1] = SLC[k + 1].U1[0].DATA[i + j * PAR->WIDTH];
                        NORM_X[0].DATA[i + j * PAR->WIDTH] += V[DIM * k + 0] * V[DIM * k + 0] + V[DIM * k + 1] * V[DIM * k + 1] + V[DIM * k + 2] * V[DIM * k + 2] + V[DIM * k + 3] * V[DIM * k + 3];
                    }
                }
                if (DIM == 1)
                {
                    double aa, bb, sigmaa, sigmab, r2;
                    linreg(time, los, SLC.size(), aa, bb, sigmaa, sigmab, r2);
                    LINEAR_RATE[0].LOS[0].DATA[i + j * PAR->WIDTH] = (float) bb;
                    LINEAR_RATE[1].LOS[0].DATA[i + j * PAR->WIDTH] = (float) sigmab;
                    LINEAR_RATE[2].LOS[0].DATA[i + j * PAR->WIDTH] = (float) r2;
                } else if (DIM == 2)
                {
                    double aa, bb, sigmaa, sigmab, r2;
                    linreg(time, ew, SLC.size(), aa, bb, sigmaa, sigmab, r2);
                    LINEAR_RATE[0].EW[0].DATA[i + j * PAR->WIDTH] = (float) bb;
                    LINEAR_RATE[1].EW[0].DATA[i + j * PAR->WIDTH] = (float) sigmab;
                    LINEAR_RATE[2].EW[0].DATA[i + j * PAR->WIDTH] = (float) r2;

                    linreg(time, ud, SLC.size(), aa, bb, sigmaa, sigmab, r2);
                    LINEAR_RATE[0].UD[0].DATA[i + j * PAR->WIDTH] = (float) bb;
                    LINEAR_RATE[1].UD[0].DATA[i + j * PAR->WIDTH] = (float) sigmab;
                    LINEAR_RATE[2].UD[0].DATA[i + j * PAR->WIDTH] = (float) r2;
                } else if (DIM == 3)
                {
                    double aa, bb, sigmaa, sigmab, r2;
                    linreg(time, ns, SLC.size(), aa, bb, sigmaa, sigmab, r2);
                    LINEAR_RATE[0].NS[0].DATA[i + j * PAR->WIDTH] = (float) bb;
                    LINEAR_RATE[1].NS[0].DATA[i + j * PAR->WIDTH] = (float) sigmab;
                    LINEAR_RATE[2].NS[0].DATA[i + j * PAR->WIDTH] = (float) r2;

                    linreg(time, ew, SLC.size(), aa, bb, sigmaa, sigmab, r2);
                    LINEAR_RATE[0].EW[0].DATA[i + j * PAR->WIDTH] = (float) bb;
                    LINEAR_RATE[1].EW[0].DATA[i + j * PAR->WIDTH] = (float) sigmab;
                    LINEAR_RATE[2].EW[0].DATA[i + j * PAR->WIDTH] = (float) r2;

                    linreg(time, ud, SLC.size(), aa, bb, sigmaa, sigmab, r2);
                    LINEAR_RATE[0].UD[0].DATA[i + j * PAR->WIDTH] = (float) bb;
                    LINEAR_RATE[1].UD[0].DATA[i + j * PAR->WIDTH] = (float) sigmab;
                    LINEAR_RATE[2].UD[0].DATA[i + j * PAR->WIDTH] = (float) r2;
                } else if (DIM == 4)
                {
                    double aa, bb, sigmaa, sigmab, r2;
                    linreg(time, ns, SLC.size(), aa, bb, sigmaa, sigmab, r2);
                    LINEAR_RATE[0].NS[0].DATA[i + j * PAR->WIDTH] = (float) bb;
                    LINEAR_RATE[1].NS[0].DATA[i + j * PAR->WIDTH] = (float) sigmab;
                    LINEAR_RATE[2].NS[0].DATA[i + j * PAR->WIDTH] = (float) r2;

                    linreg(time, ew, SLC.size(), aa, bb, sigmaa, sigmab, r2);
                    LINEAR_RATE[0].EW[0].DATA[i + j * PAR->WIDTH] = (float) bb;
                    LINEAR_RATE[1].EW[0].DATA[i + j * PAR->WIDTH] = (float) sigmab;
                    LINEAR_RATE[2].EW[0].DATA[i + j * PAR->WIDTH] = (float) r2;

                    linreg(time, ud, SLC.size(), aa, bb, sigmaa, sigmab, r2);
                    LINEAR_RATE[0].UD[0].DATA[i + j * PAR->WIDTH] = (float) bb;
                    LINEAR_RATE[1].UD[0].DATA[i + j * PAR->WIDTH] = (float) sigmab;
                    LINEAR_RATE[2].UD[0].DATA[i + j * PAR->WIDTH] = (float) r2;

                    linreg(time, u1, SLC.size(), aa, bb, sigmaa, sigmab, r2);
                    LINEAR_RATE[0].U1[0].DATA[i + j * PAR->WIDTH] = (float) bb;
                    LINEAR_RATE[1].U1[0].DATA[i + j * PAR->WIDTH] = (float) sigmab;
                    LINEAR_RATE[2].U1[0].DATA[i + j * PAR->WIDTH] = (float) r2;
                }
                NORM_X[0].DATA[i + j * PAR->WIDTH] = sqrt(NORM_X[0].DATA[i + j * PAR->WIDTH]);

                // compute norm ||Ax-Y||
                NORM_AXY[0].DATA[i + j * PAR->WIDTH] = 0;
                float norm_axy = 0;

                int row = 0;
                for (int l = 0; l < SET.size(); l++)
                    for (int k = 0; k < SET[l].InSAR.size(); k++)
                        if (SET[l].InSAR[k].LOS[0].DATA[i + j * PAR->WIDTH] != PAR->NAN_VAL)
                        {
                            norm_axy = SET[l].InSAR[k].LOS[0].DATA[i + j * PAR->WIDTH];
                            for (int ii = 0; ii < (SLC.size() - 1); ii++)
                                if (DIM == 1)
                                    norm_axy -= (TM[DIM * ii + 0 + row * COLUMNS] * V[DIM * ii + 0]);
                                else if (DIM == 2)
                                    norm_axy -= (TM[DIM * ii + 0 + row * COLUMNS] * V[DIM * ii + 0] + TM[DIM * ii + 1 + row * COLUMNS] * V[DIM * ii + 1]);
                                else if (DIM == 3)
                                    norm_axy -= (TM[DIM * ii + 0 + row * COLUMNS] * V[DIM * ii + 0] + TM[DIM * ii + 1 + row * COLUMNS] * V[DIM * ii + 1] + TM[DIM * ii + 2 + row * COLUMNS] * V[DIM * ii + 2]);
                                else if (DIM == 4)
                                    norm_axy -= (TM[DIM * ii + 0 + row * COLUMNS] * V[DIM * ii + 0] + TM[DIM * ii + 1 + row * COLUMNS] * V[DIM * ii + 1] + TM[DIM * ii + 2 + row * COLUMNS] * V[DIM * ii + 2] + TM[DIM * ii + 3 + row * COLUMNS] * V[DIM * ii + 3]);

                            NORM_AXY[0].DATA[i + j * PAR->WIDTH] += norm_axy * norm_axy;
                            row++;
                        }
                NORM_AXY[0].DATA[i + j * PAR->WIDTH] = sqrt(NORM_AXY[0].DATA[i + j * PAR->WIDTH]);

            }

            #pragma omp atomic
            steps_completed += 1.0;

            double local_steps_completed = steps_completed;
            double float_completed0 = 0.0 + 100 * (double) (local_steps_completed - 1) / (double) (PAR->WIDTH * (LINE_STOP - LINE_START + 1));
            double float_completed = 0.0 + 100 * (double) (local_steps_completed) / (double) (PAR->WIDTH * (LINE_STOP - LINE_START + 1));

            if (floor(float_completed) > floor(float_completed0))
            {
                time_t now = time(0);
                tm* localtm = localtime(&now);
                WriteLog("completed by process " + i2s(WORLD_RANK) + " of " + i2s(WORLD_SIZE) + " " + i2s(int(floor(float_completed))) + "% on " + asctime(localtm));
            }
        }
    delete [] data, idata;
    if (WORLD_RANK == 0) WriteLog("SVD inversion completed successfully");
}

void carea::write()
{
    RANK[0].WriteLines();
    COND_NUM[0].WriteLines();
    NORM_X[0].WriteLines();
    NORM_AXY[0].WriteLines();
    STACK[0].WriteLines();
    STACK[1].WriteLines();

    for (int l = 0; l < LINEAR_RATE.size(); l++)
    {
        for (int k = 0; k < LINEAR_RATE[l].LOS.size(); k++) LINEAR_RATE[l].LOS[k].WriteLines();
        for (int k = 0; k < LINEAR_RATE[l].NS.size(); k++) LINEAR_RATE[l].NS[k].WriteLines();
        for (int k = 0; k < LINEAR_RATE[l].EW.size(); k++) LINEAR_RATE[l].EW[k].WriteLines();
        for (int k = 0; k < LINEAR_RATE[l].UD.size(); k++) LINEAR_RATE[l].UD[k].WriteLines();
        for (int k = 0; k < LINEAR_RATE[l].U1.size(); k++) LINEAR_RATE[l].U1[k].WriteLines();
    }

    for (int l = 0; l < SLC.size(); l++)
    {
        for (int k = 0; k < SLC[l].LOS.size(); k++) SLC[l].LOS[k].WriteLines();
        for (int k = 0; k < SLC[l].NS.size(); k++) SLC[l].NS[k].WriteLines();
        for (int k = 0; k < SLC[l].EW.size(); k++) SLC[l].EW[k].WriteLines();
        for (int k = 0; k < SLC[l].UD.size(); k++) SLC[l].UD[k].WriteLines();
        for (int k = 0; k < SLC[l].U1.size(); k++) SLC[l].U1[k].WriteLines();
    }
}

void carea::dgelsd_query(int m, int n, int nrhs, int &lwork, int &ilwork)

{
    lwork = ilwork = -1;
    int info = 0;
    double rcond = 0.00001; // condition number ... choose a small value
    int lda = m; // leading dimension of A
    int ldb = max(m, n); // leading dimension of B
    int rank_num = 0;

    double *work = new double [10];
    int *iwork = new int [10];

    double *s = NULL;
    double *a = NULL;
    double *b = NULL;

    dgelsd_(&m, &n, &nrhs, a, &lda, b, &ldb, s, &rcond, &rank_num, work, &lwork, iwork, &info);
    if (info < 0)
        WriteLog("LAPACK routine dgelsd returned error, invalid argument: " + f2s(info));
    else if (info > 0)
        WriteLog("SVD failed to converge and returned: " + f2s(info));
    else if (info == 0)
    {
        lwork = (int) work[0];
        ilwork = (int) iwork[0];
    }
    delete [] work;
    delete [] iwork;
}

inline int carea::dgelsd(double *a, int m, int n, double *b, int nrhs, int &rank_num, double &cond_num, int lwork, int ilwork, double *work, double *s, int *iwork)
{
    int info = 0;
    double rcond = 0.00001; // condition number ... choose a small value
    int lda = m; // leading dimension of A
    int ldb = max(m, n); // leading dimension of B

    dgelsd_(&m, &n, &nrhs, a, &lda, b, &ldb, s, &rcond, &rank_num, work, &lwork, iwork, &info);

    if (info < 0)
        WriteLog("LAPACK routine dgelsd returned error, invalid argument: " + f2s(info));
    else if (info > 0)
        WriteLog("SVD failed to converge and returned: " + f2s(info));
    else if (info == 0)
    {
        cond_num = s[0] / s[rank_num - 1];

        //        printf("Rank of matrix A: %d\n", rank_num);
        //        int sdim = min(m,n);
        //        printf("Singular values of A: ");
        //        for(int i = 0; i < sdim; i++) printf("%f\t", s[i]);
        //        printf("\n");
        //        printf("Conditioning number of A: %f\n ", s[0]/s[sdim-1]);
        //        printf("SVD solution is: ");
        //        for(int i = 0; i < sdim; i++) printf("%f\t", b[i]);
        //        printf("\n");
    }
    return info;
}

void carea::linreg(double *x, double *y, int length, double &aa, double &bb, double &sigmaa, double &sigmab, double &r2)
{
    if (length < 2) throw std::invalid_argument(ERROR("at least two points required for computing linear trend"));

    aa = bb = sigmaa = sigmab = r2 = 0;

    double sx = 0, sy = 0, mx = 0, my = 0, ssxx = 0, ssyy = 0, ssxy = 0, s = 0;

    for (int i = 0; i < length; i++)
    {
        sx += x[i];
        sy += y[i];
    }

    mx = sx / length;
    my = sy / length;

    for (int i = 0; i < length; i++)
    {
        ssxx += (x[i] - mx)*(x[i] - mx);
        ssyy += (y[i] - my)*(y[i] - my);
        ssxy += (x[i] - mx)*(y[i] - my);
    }

    bb = ssxy / ssxx;
    aa = my - bb * mx;

    s = sqrt((ssyy - ssxy * ssxy / ssxx) / (length - 2));
    sigmaa = s * sqrt(1 / length + mx * mx / ssxx);
    sigmab = s / sqrt(ssxx);

    r2 = ssxy * ssxy / ssxx / ssyy;
}
