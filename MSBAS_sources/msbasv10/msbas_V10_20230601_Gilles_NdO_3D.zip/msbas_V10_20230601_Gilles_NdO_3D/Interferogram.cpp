#include "Interferogram.h"

Interferogram::Interferogram(Param *par, int sn, int in, char pass)
{
    PAR = par;
    SN = sn;
    IN = in;

    NAME = PAR->SET[SN].InSAR[IN].NAME;
    FNAME = PAR->SET[SN].NAME + ":" + PAR->SET[SN].InSAR[IN].NAME;
    PASS = pass;
    SB = atof(PAR->SET[SN].InSAR[IN].SB.c_str());

    BNDCOR = 1;
    OFFSET = 0;
    MEAN = 0;
    STD = 0;
    COV = 0;
    DEL = false;
    
    LOS.clear();
    IMAGE.push_back(Image(PAR, PAR->SET[SN].InSAR[IN].MDATE, PAR->SET[SN].TIME));
    IMAGE.push_back(Image(PAR, PAR->SET[SN].InSAR[IN].SDATE, PAR->SET[SN].TIME));
    TB = IMAGE[1].DATE - IMAGE[0].DATE;
}

void Interferogram::Statistics(float *data)
{
    if (!data) throw std::invalid_argument(ERROR("trying to use an allocated buffer"));

    double sum = 0;
    double count = 0;

    for (int i = 0; i < PAR->WIDTH; i++)
        for (int j = 0; j < PAR->LENGTH; j++)
            if (data[i+PAR->WIDTH*j] != PAR->NAN_VAL)
            {
                sum += data[i+PAR->WIDTH*j];
                count +=1.0;
            }
    
    if (count > 0)
    {
        MEAN = sum / count;
        sum = 0;

        for (int i = 0; i < PAR->WIDTH; i++)
            for (int j = 0; j < PAR->LENGTH; j++)
                if (data[i+PAR->WIDTH*j] != PAR->NAN_VAL)
                    sum += (data[i+PAR->WIDTH*j]-MEAN)*(data[i+PAR->WIDTH*j]-MEAN);

        STD = sqrt(sum/count);
        COV = count / (PAR->WIDTH * PAR->LENGTH);
    }
    //WriteLog("statistics " + FNAME + " MEAN =" + f2s(MEAN) + " STD =" + f2s(STD) + " COV =" + f2s(COV));
}

void Interferogram::Calibrate(float *data)
{
    OFFSET = 0;
    if (!data) throw std::invalid_argument(ERROR("trying to use an allocated buffer"));

    int i = 0, j = 0, k = 0;
    double count = 0;

    // do nothing because calibrated data is provided
    if (PAR->C_FLAG == 0)
        OFFSET = 0;
    // set average of reference regions to zero, use up to 9 reference regions
    else if ((PAR->C_FLAG > 0)&&(PAR->C_FLAG < 10))
    {
        for (k = 0; k < PAR->C_FLAG; k++)
        {
            for (i = (PAR->CPOS[k] - PAR->CSIZE); i <= (PAR->CPOS[k] + PAR->CSIZE); i++)
                for (j = (PAR->LPOS[k] - PAR->LSIZE); j <= (PAR->LPOS[k] + PAR->LSIZE); j++)
                    if ((i >= 0)&&(j >= 0)&&(i < PAR->WIDTH)&&(j < PAR->LENGTH) && data[i+PAR->WIDTH*j] != 0)
                    {
                        OFFSET += data[i+PAR->WIDTH*j];
                        count += 1.0;
                    }
        }
        if (count > 0)
            OFFSET /= count;
        else
            DEL = true;
    }
    else if (PAR->C_FLAG == 10 || PAR->C_FLAG == 100) // set average of interferogram to zero, do it for PAR->C_FLAG=100 as well, in case z-score computation fails
        OFFSET = MEAN;

    //WriteLog("calibration offset " + FNAME + " OFFSET =" + f2s(OFFSET));
}

void Interferogram::Boundary(double start_time, double stop_time)
{
    BNDCOR = 1;

    if (IMAGE[0].DATE < start_time)
    {
        BNDCOR *= (IMAGE[1].DATE - start_time) / (IMAGE[1].DATE - IMAGE[0].DATE);
        IMAGE[0].DATE = start_time;
    }

    if (IMAGE[1].DATE > stop_time)
    {
        BNDCOR *= (stop_time - IMAGE[0].DATE) / (IMAGE[1].DATE - IMAGE[0].DATE);
        IMAGE[1].DATE = stop_time;
    }
    
    //WriteLog("boundary correction " + FNAME + " BNDCOR =" + f2s(BNDCOR));
}