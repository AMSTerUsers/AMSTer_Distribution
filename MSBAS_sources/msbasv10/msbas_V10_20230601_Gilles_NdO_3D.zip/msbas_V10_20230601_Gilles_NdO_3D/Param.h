#ifndef PARAM_H
#define PARAM_H

#include "main.h"

struct SInterferogram
{
    string NAME;
    string SB;
    string MDATE;
    string SDATE;

    SInterferogram(string name, string sb, string mdate, string sdate)
    {
        NAME = name;
        SB = sb;
        MDATE = mdate;
        SDATE = sdate;
    }
};

struct SSet
{
    string TYPE; //0-range offsets or InSAR, 1- azimuth offsets
    string TIME;
    string AZIMUTH;
    string INCIDENCE;
    string NAME;
    string LV_THETA_FILE;
    string LV_PHI_FILE;
    vector <SInterferogram> InSAR;

    SSet(string type, string time, string azimuth, string incidence, string name, string lv_theta_file, string lv_phi_file)
    {
        TYPE = type;
        TIME = time;
        AZIMUTH = azimuth;
        INCIDENCE = incidence;
        NAME = name;
        LV_THETA_FILE = lv_theta_file;
        LV_PHI_FILE = lv_phi_file;

        FILE * pFile;
        pFile = fopen(NAME.c_str(), "r");
        if (pFile == NULL) throw std::invalid_argument(ERROR("can not read file " + NAME));

        int i = 0;
        char v1[256], v2[256], v3[256], v4[256];
        while (fscanf(pFile, "%s %s %s %s", v1, v2, v3, v4) == 4)
        {
            string val1(v1), val2(v2), val3(v3), val4(v4);
            WriteLog(i2sf(i) + ": " + val1 + " " + val2 + " " + val3 + " " + val4);
            InSAR.push_back(SInterferogram(val1, val2, val3, val4));
            i++;
        }
        fclose(pFile);
    }
};

class Param
{
public:
    int FORMAT;
    int FORMAT_INT_RADIUS;
    int FWIDTH, FLENGTH;
    int CSTART, CSTOP, LSTART, LSTOP, WIDTH, LENGTH;
    int C_FLAG, CPOS[10], LPOS[10], CSIZE, LSIZE;
    int R_FLAG;
    float R_LAMBDA;
    int D_FLAG;
    float MC_FLAG;
    float NAN_VAL;

    string DEM_FILE, DDNS_FILE, DDEW_FILE;
    GDALDataset *poSrcDS;

    vector <SSet> SET;

    Param();
    Param(string name);
    ~Param();
    void ReadParFile();
    void ProcessPar(string parameter, string value);
    void ValidatePar();
    void Interpolate(string name);
    void ReadAll(string name, float *data);
    void WriteAll(string name, float *data);
    
private:
    string NAME;
};


#endif /* PARAM_H */

