#ifndef BUFFER_H
#define BUFFER_H

#include "main.h"
#include "Param.h"

class Buffer {
public:
    vector <float> DATA;
    string NAME;

    Buffer(Param *par, string name, int line_start, int line_stop);
    ~Buffer() {};

    void ReadLines();
    void WriteLines();

private:
    Param *PAR;
    int LINE_START;
    int LINE_STOP;
};

#endif /* BUFFER_H */

