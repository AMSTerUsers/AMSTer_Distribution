#include "Buffer.h"

Buffer::Buffer(Param *par, string name, int line_start, int line_stop)
{
    PAR = par;
    NAME = name;
    LINE_START=line_start;
    LINE_STOP=line_stop;
    if (LINE_START < 0 || LINE_STOP > PAR->LENGTH || LINE_START > LINE_STOP) throw std::invalid_argument(ERROR("cannot read these lines"));

    DATA.assign(PAR->WIDTH*(LINE_STOP-LINE_START+1), PAR->NAN_VAL);
    if (DATA.size() == 0) throw std::invalid_argument(ERROR("memory has not been allocated"));
}

void Buffer::ReadLines()
{
    GDALDataset *poDataset;
    GDALRasterBand *poBand;

    if (PAR->FORMAT == 0 || PAR->FORMAT == 1)
        throw std::invalid_argument(ERROR("binary format is no longer supported"));
    else if (PAR->FORMAT == 2)
    {
        // check if GTiff format is supported
        GDALDriver *poDriver = GetGDALDriverManager()->GetDriverByName("GTiff");
        if (poDriver == NULL) throw std::invalid_argument(ERROR("GTiff format is not supported"));

        // open data set
        if (PAR->FORMAT_INT_RADIUS > 0) // read interpolated data
            poDataset = (GDALDataset *) GDALOpen((NAME + ".temp").c_str(), GA_ReadOnly);
        else
            poDataset = (GDALDataset *) GDALOpen(NAME.c_str(), GA_ReadOnly);

        if (poDataset == NULL) throw std::invalid_argument(ERROR("can not open file " + NAME));
        poBand = poDataset->GetRasterBand(1);

        if (poBand->RasterIO(GF_Read, PAR->CSTART, PAR->LSTART + LINE_START, PAR->WIDTH, LINE_STOP - LINE_START + 1, &DATA[0], PAR->WIDTH, LINE_STOP-LINE_START + 1, GDT_Float32, 0, 0) != 0)
            throw std::invalid_argument(ERROR("failed reading file " + NAME + " or " + NAME + ".temp"));

        // process NaNs
        float gdal_nan = poBand->GetNoDataValue();
        if (gdal_nan != PAR->NAN_VAL) for (int i = 0; i < PAR->WIDTH; i++) if (DATA[i] == gdal_nan) DATA[i] = PAR->NAN_VAL;

        if (poDataset != NULL) GDALClose((GDALDatasetH) poDataset);
        poDataset = NULL;
        poBand = NULL;
    }
}

void Buffer::WriteLines()
{
    GDALDataset *poDataset = NULL;
    GDALRasterBand *poBand = NULL;

    if (PAR->FORMAT == 0 || PAR->FORMAT == 1)
        throw std::invalid_argument(ERROR("binary format is no longer supported"));
    else if (PAR->FORMAT == 2)
    {
        // check if GTiff format is supported
        GDALDriver *poDriver = GetGDALDriverManager()->GetDriverByName("GTiff");
        if (poDriver == NULL) throw std::invalid_argument(ERROR("GTiff format is not supported"));

        // re-use existing file if available
        if(fexists((NAME + ".tif").c_str()))
            poDataset = (GDALDataset *) GDALOpen((NAME + ".tif").c_str(), GA_Update);
        
        if (poDataset == NULL)
        {
            // if existing file is not available, create a new one using first input file as a template
            if (PAR->poSrcDS == NULL) throw std::invalid_argument(ERROR("GTiff file template is unavailable"));
            poDataset = poDriver->CreateCopy((NAME + ".tif").c_str(), PAR->poSrcDS, FALSE, NULL, NULL, NULL);
            poBand = poDataset->GetRasterBand(1);
            vector <float> d;
            d.assign(PAR->FWIDTH * PAR->FLENGTH,PAR->NAN_VAL);
            if (poBand->RasterIO(GF_Write, 0, 0, PAR->FWIDTH, PAR->FLENGTH, &d[0], PAR->FWIDTH, PAR->FLENGTH, GDT_Float32, 0, 0) != 0) throw std::invalid_argument(ERROR("cannot write to a GTiff file"));
        }
        else
            poBand = poDataset->GetRasterBand(1);

        // set NAN value to zero
        poBand->SetNoDataValue(PAR->NAN_VAL);

        if (poBand->RasterIO(GF_Write, PAR->CSTART, PAR->LSTART + LINE_START, PAR->WIDTH, LINE_STOP-LINE_START +1 , &DATA[0], PAR->WIDTH, LINE_STOP-LINE_START + 1, GDT_Float32, 0, 0) != 0)
            throw std::invalid_argument(ERROR("cannot write to a GTiff file"));

        //poBand->FlushCache(); //write from cash to a disk, this frees RAM, I hope 

        if (poDataset != NULL) GDALClose((GDALDatasetH) poDataset);
        poDataset = NULL;
        poBand = NULL;
    }
}
