#ifndef SET_H
#define SET_H

#include "Interferogram.h"
#include "main.h"
#include "Param.h"

class Set {
public:
    char TYPE; //R-range offsets or INTERFEROGRAM, A-azimuth offsets
    char PASS; //A-ascending or D-descending

    float AZIMUTH;
    float INCIDENCE;
    string TIME;
    string NAME;
    int rInSARs; // number of interferograms removed due to low spatial coverage
    int rInSARt; // number of interferograms removed due to temporal coverage

    vector <float> S [3]; // north, east, vertical
    vector <Interferogram> InSAR;
    vector <Image> SLC;

    Set(Param *par, const int sn);
    ~Set() {};

private:
    Param *PAR;
    int SN;
};

#endif /* SET_H */

