#include "Set.h"

Set::Set(Param *par, const int sn)
{
    PAR = par;
    SN = sn;
    rInSARs=rInSARt=0;

    TIME = PAR->SET[SN].TIME;

    if (atoi(PAR->SET[SN].TYPE.c_str()) == 0)
        TYPE = 'R';
    else if (atoi(PAR->SET[SN].TYPE.c_str()) == 1)
        TYPE = 'A';
    else
        throw std::invalid_argument(ERROR("unexpected set type"));

    AZIMUTH = atof(PAR->SET[SN].AZIMUTH.c_str());
    INCIDENCE = atof(PAR->SET[SN].INCIDENCE.c_str());
    NAME = PAR->SET[SN].NAME;

    S[0].assign(PAR->WIDTH * PAR->LENGTH, PAR->NAN_VAL);
    S[1].assign(PAR->WIDTH * PAR->LENGTH, PAR->NAN_VAL);
    S[2].assign(PAR->WIDTH * PAR->LENGTH, PAR->NAN_VAL);

    // variable geometry
    if (PAR->SET[SN].LV_THETA_FILE.size() != 0 && PAR->SET[SN].LV_PHI_FILE.size() != 0)
    {
        float *lv_theta = (float*) calloc(PAR->WIDTH * PAR->LENGTH, sizeof (float));
        if (!lv_theta) throw std::invalid_argument(ERROR("can not allocate memory"));
        PAR->ReadAll(PAR->SET[SN].LV_THETA_FILE, lv_theta);

        float *lv_phi = (float*) calloc(PAR->WIDTH * PAR->LENGTH, sizeof (float));
        if (!lv_phi) throw std::invalid_argument(ERROR("can not allocate memory"));
        PAR->ReadAll(PAR->SET[SN].LV_PHI_FILE, lv_phi);

        for (int i = 0; i < PAR->WIDTH; i++)
            for (int j = 0; j < PAR->LENGTH; j++)
                if (lv_theta[i + PAR->WIDTH * j] != PAR->NAN_VAL && lv_phi[i + PAR->WIDTH * j] != PAR->NAN_VAL)
                {
                    // range
                    if (TYPE == 'R')
                    {
                        S[0][i + PAR->WIDTH * j] = cos(lv_theta[i + PAR->WIDTH * j]) * sin(lv_phi[i + PAR->WIDTH * j]);
                        S[1][i + PAR->WIDTH * j] = cos(lv_theta[i + PAR->WIDTH * j]) * cos(lv_phi[i + PAR->WIDTH * j]);
                        S[2][i + PAR->WIDTH * j] = sin(lv_theta[i + PAR->WIDTH * j]);
                    }
                    // azimuth
                    else if (TYPE == 'A')
                    {
                        S[0][i + PAR->WIDTH * j] = -cos(lv_phi[i + PAR->WIDTH * j]);
                        S[1][i + PAR->WIDTH * j] = sin(lv_phi[i + PAR->WIDTH * j]);
                        S[2][i + PAR->WIDTH * j] = 0;
                    } else
                        throw std::invalid_argument(ERROR("detected incorrect set type"));
                }
        if (lv_theta) free(lv_theta);
        if (lv_phi) free(lv_phi);
    }
    // constant geometry
    else
        for (int i = 0; i < PAR->WIDTH; i++)
            for (int j = 0; j < PAR->LENGTH; j++)
                // range
                if (TYPE == 'R')
                {
                    S[0][i + PAR->WIDTH * j] = sin(AZIMUTH * PI / 180.) * sin(INCIDENCE * PI / 180.);
                    S[1][i + PAR->WIDTH * j] = -cos(AZIMUTH * PI / 180.) * sin(INCIDENCE * PI / 180.);
                    S[2][i + PAR->WIDTH * j] = cos(INCIDENCE * PI / 180.);
                }
                // azimuth
                else if (TYPE == 'A')
                {
                    S[0][i + PAR->WIDTH * j] = cos(AZIMUTH * PI / 180.);
                    S[1][i + PAR->WIDTH * j] = sin(AZIMUTH * PI / 180.);
                    S[2][i + PAR->WIDTH * j] = 0;
                } else
                    throw std::invalid_argument(ERROR("detected incorrect set type"));

    float se0 = 0, sn0 = 0;
    for (int i = 0; i < (PAR->WIDTH * PAR->LENGTH); i++)
        if (S[1][i] != PAR->NAN_VAL && S[0][i] != PAR->NAN_VAL)
        {
            se0 = S[1][i];
            sn0 = S[0][i];
            break;
        }

    if (se0 == 0 || sn0 == 0) throw std::invalid_argument(ERROR("cannot compute satellite orbit direction (ascending/descending)"));

    if (TYPE == 'R' && se0 < 0)
        PASS = 'A';
    else if (TYPE == 'R' && se0 > 0)
        PASS = 'D';
    else if (TYPE == 'A' && sn0 > 0)
        PASS = 'A';
    else if (TYPE == 'A' && sn0 < 0)
        PASS = 'D';
    else
        throw std::invalid_argument(ERROR("cannot compute satellite orbit direction (ascending/descending)"));

    WriteLog(NAME + " TYPE = " + TYPE + " PASS = " + PASS);

    for (int i = 0; i < PAR->SET[SN].InSAR.size(); i++) InSAR.push_back(Interferogram(PAR, SN, i, PASS));
    if (InSAR.empty()) throw std::invalid_argument(ERROR("set does not contain interferograms"));
    
    SLC.clear();
}