#include "main.h"
#include "carea.h"

int main(int argc, char** argv)
{
    try
    {
        // Initialize MPI.
        MPI_Init(NULL, NULL);

        // Get the number of processes
        int world_size;
        MPI_Comm_size(MPI_COMM_WORLD, &world_size);

        // Get the rank of the process
        int world_rank;
        MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

        // Get the name of the processor
        char processor_name[MPI_MAX_PROCESSOR_NAME];
        int name_len;
        MPI_Get_processor_name(processor_name, &name_len);

        for (int i = 0; i < world_size; ++i)
        {
            if (world_rank == i)
            {
                //  Process 0 
                if (world_rank == 0)
                {
                    remove(LOG_FILE);
                    WriteLog("Hello, welcome to msbas version 10 (20230413) developed by Sergey Samsonov, email: samsonov@insar.ca");
                    WriteLog("to run on workstation: msbas parameter_file [usually MSBAS_*_PAR.txt or header.txt]");
                    WriteLog("to run on HPC: allocate resources and then do something like this");
                    WriteLog("               mpirun --bind-to core --report-bindings --map-by ppr:1:node:pe=${SLURM_CPUS_ON_NODE} msbas parameter_file");
                    
                    if (argc < 2) throw std::invalid_argument(ERROR("missing parameter file [usually MSBAS_*_PAR.txt or header.txt]"));
                }
                WriteLog("MPI process " + i2s(world_rank) + " of " + i2s(world_size) + " with " + i2s(omp_get_num_procs()) + " OpenMP cores on host " + processor_name);
            }
            MPI_Barrier(MPI_COMM_WORLD);
        }

        carea* area;

        for (int i = 0; i < world_size; ++i)
        {
            if (world_rank == i)
            {
                WriteLog("executing init by process " + i2s(world_rank) + " of " + i2s(world_size));
                area = new carea(argv[1], world_size, world_rank);
            }
            MPI_Barrier(MPI_COMM_WORLD);
        }

        area->preprocess();

        for (int i = 0; i < world_size; ++i)
        {
            if (world_rank == i)
            {
                WriteLog("executing read by process " + i2s(world_rank) + " of " + i2s(world_size));
                area->read();
            }
            MPI_Barrier(MPI_COMM_WORLD);
        }

        area->process();

        for (int i = 0; i < world_size; ++i)
        {
            if (world_rank == i)
            {
                WriteLog("executing write by process " + i2s(world_rank) + " of " + i2s(world_size));
                area->write();
                area->~carea();
            }
            MPI_Barrier(MPI_COMM_WORLD);
        }

        if (world_rank == 0)
        {
            WriteLog("good bye");
        }

        // Finalize the MPI environment. No more MPI calls allowed.
        MPI_Finalize();
        return 0;
    }    catch (const std::invalid_argument& e)
    {
        WriteLog(e.what());
        return 1;
    }
}

string ErrorMessage(const char *fname, int lineno, const char *fxname, string msg)
{
    string fname1 = string(fname);
    string lineno1 = i2s(lineno);
    string fxname1 = string(fxname);
    return "error in [file " + fname1 + ", line " + lineno1 + ", function " + fxname1 + "]: " + msg + ", exiting now...";
}

void WriteLog(string message)
{
    FILE * pFile;
    pFile = fopen(LOG_FILE, "a");
    if (pFile != NULL)
    {
        fprintf(pFile, "%s\n", message.c_str());
        fclose(pFile);
    }

    printf("%s\n", message.c_str());
}

string i2s(long num)
{
    ostringstream ostr;
    ostr << num;
    return ostr.str();
}

string i2sf(long num)
{
    ostringstream ostr;
    ostr << setw(5) << num;
    return ostr.str();
}

string f2s(double num)
{
    ostringstream ostr;
    if (num > 0)
        ostr << showpoint << fixed << setprecision(8) << right << " " << num;
    else
        ostr << showpoint << fixed << setprecision(8) << right << num;
    return ostr.str();
}

bool fexists(const char *filename)
{
    ifstream ifile(filename);
    return (ifile ? true : false);
}
