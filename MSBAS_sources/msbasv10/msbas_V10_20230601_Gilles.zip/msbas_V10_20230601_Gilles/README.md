# Multidimensional Small Baseline Subset (MSBAS) version 10
is used for time series analysis of InSAR and speckle range/azimuth offset data. Depending on the input data, it can compute 1D, 2D, constrained 3D, unconstrained 3D, and 4D velocity and/or displacement time series. This version is designed to process large datasets (e.g., multi-frame Sentinel-1 InSAR) by intelligently managing processing resources. It utilizes MPI and OpenMP parallelization technologies and can be run on clusters. It also works on fully and partially coherent pixels.

The software manual has been submitted as a manuscript entitled "Parallelized Multidimensional Small Baseline Subset (MSBAS) software for computing deformation time series from partially-coherent DInSAR data" to the SoftwareX journal.

To download, run:
git clone https://github.com/insar-info/msbas

To compile, run:
cd msbas/src && make all

Supplementary files and test data for MSBAS-1D and 2D can be downloaded from https://insar.ca/pubs/msbas_V10_test_data.zip.

For instructions, consult readme.txt file provided with supplementary files.

For help, email to samsonov@insar.ca. 
