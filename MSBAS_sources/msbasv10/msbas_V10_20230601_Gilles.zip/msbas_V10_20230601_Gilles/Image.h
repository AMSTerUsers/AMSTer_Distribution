#ifndef IMAGE_H
#define IMAGE_H

#include "main.h"
#include "Param.h"
#include "Buffer.h"

class Image {
public:
    double DATE;
    string NAME;
    double COUNT[2];
    vector <Buffer> LOS;
    vector <Buffer> NS;
    vector <Buffer> EW;
    vector <Buffer> UD;
    vector <Buffer> U1;

    Image(Param *par, string name);
    Image(Param *par, string date, string time);
    ~Image() {};

    bool operator<(const Image &image) const {
        return (DATE < image.DATE);
    }

    bool operator==(const Image &image) const {
        return (DATE == image.DATE);
    }

private:
    Param *PAR;
};

#endif /* IMAGE_H */

