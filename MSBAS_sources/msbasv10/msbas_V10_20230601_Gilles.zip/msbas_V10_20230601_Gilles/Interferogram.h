#ifndef INTERFEROGRAM_H
#define INTERFEROGRAM_H

#include "main.h"
#include "Param.h"
#include "Buffer.h"
#include "Image.h"

class Interferogram {
public:
    string NAME;
    string FNAME;
    char PASS;
    float SB;
    float TB;
    float BNDCOR;
    float OFFSET;
    float MEAN;
    float STD;
    float COV;
    bool DEL;

    vector <Buffer> LOS;
    vector <Image> IMAGE;

    Interferogram(Param *par, int sn, int in, char pass);
    ~Interferogram() {};

    void Statistics(float *data);
    void Calibrate(float *data);
    void Boundary(double start_time, double stop_time);

private:
    Param *PAR;
    int SN;
    int IN;
};

#endif /* INTERFEROGRAM_H */

