#ifndef CAREA_H
#define CAREA_H

#include "main.h"
#include "Param.h"
#include "Set.h"
#include "Interferogram.h"

class carea {
public:
    carea (string name, int world_size, int world_rank);
    virtual ~carea();
    void preprocess();
    void read();
    void process();
    void write();

    void stacking();
    void linreg(double *x, double *y, int length, double &aa, double &bb, double &sigmaa, double &sigmab, double &r2);
    void dgelsd_query(int m, int n, int nrhs, int &lwork, int &ilwork);
    int dgelsd(double *a, int m, int n, double *b, int nrhs, int &rank_num, double &cond_num, int lwork, int ilwork, double *work, double *s, int *iwork);

   
private:
    
    Param *PAR;
    int WORLD_SIZE;
    int WORLD_RANK;
    vector <Set> SET;
    vector <Image> SLC;
    
    int DIM;
    int ROWS;
    int COLUMNS;
    int LINE_START;
    int LINE_STOP;
    long BLOCK_SIZE;
    vector <float> ZSCORE_MASK;
    vector <float> TIME_MATRIX;
    
    vector <Buffer> RANK;
    vector <Buffer> COND_NUM;
    vector <Buffer> NORM_X;
    vector <Buffer> NORM_AXY;
    vector <Buffer> STACK;
    vector <Image> LINEAR_RATE; //RATE, RATE_STD, RATE_R2
    vector <float> DD [2]; //DDNS,DDEW
};

#endif /* CAREA_H */

