Several versions exist of msbas. 

They are not numbered by the author but as the recent version requires additional parameters in the header 
(see header_v3.txt versus header_v4.txt), we decided arbitrary to name it v4 (version from 2019). 

The present version of the make file has been prepared on August 18 2022 by Gilles Celli in order to works both on Linux and Mac. However, it only operates on a limited version of cores. 

An optimized version has been prepared by Gilles Celli on Sept 19 2022 that makes use of all the cores. 

NdO Sept 2022. 
