#!/bin/bash
######################################################################################
# This script automatically install some dependencies of MasTer Engine that can be
# installed with apt.
#
# (Install dependencies for MasTer Engine core, MSBAS, MasTer scripts, DORIS)
#
# Parameters : - none
#
# Dependencies:	- none
#
# New in V1.2 (2020/10/01)
# - Added graphicsmagick-imagemagick-compat and libomp-dev
#
# New in V1.1 (2020/04/04):
# - Added tcsh installation for DORIS
# - added 7zip installation for Sentinel data download
#
# New in V1.0 (2020/04/01): 
# - Nothing, of course! This is the first version of the script...
#
# B. Smets   - v 1.2, 2020/10/01 -                         
######################################################################################
echo
PRG=`basename "$0"`
VER="v1.2 - Automatic APT installation of some dependencies for MasTer Engine"
AUT="Benoît Smets, (c)2020, Last modified on October 1, 2020"
echo " "
echo "${PRG} ${VER}, ${AUT}"
echo " "

# Simple apt install of dependencies
apt install -y sed
apt install -y grep
apt install -y gawk
apt install -y coreutils
apt install -y gmt
apt install -y snaphu
apt install -y gnuplot
apt install -y gnome-terminal
apt install -y liblapack-dev
apt install -y libxml2
apt install -y libxml2-dev
apt install -y libgeotiff-dev
apt install -y libhdf5-dev
apt install -y libfftw3-dev
apt install -y tcsh
apt install -y p7zip
apt install -y graphicsmagick-imagemagick-compat
apt install -y libomp-dev

# Symbolic links need to be created for sed and grep
ln -s /bin/sed /usr/bin/gsed
ln -s /bin/grep /usr/bin/ggrep

# Install gdal
add-apt-repository ppa:ubuntugis/ppa
apt-get update
apt-get install gdal-bin
apt-get install libgdal-dev

echo +++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo "THE DEPENDENCIES HAVE BEEN INSTALLED - HOPE IT WORKED"
echo +++++++++++++++++++++++++++++++++++++++++++++++++++++++
