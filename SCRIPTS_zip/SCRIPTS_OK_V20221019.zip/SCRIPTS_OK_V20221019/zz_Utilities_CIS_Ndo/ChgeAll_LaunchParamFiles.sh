#!/bin/bash
######################################################################################
# This script change all lines containing a given string with another one from all param files in sub dirs.
#
# Better be sure before launching - making backup of dir/subdirs is advised  
#
# I know, it is a bit messy and can be improved.. when time. But it works..
# N.d'Oreye, v 1.0 2016/04/07 -                         
######################################################################################

CRITERE=$1
NEWCRITERE=$2

#RUNDATE=`date "+ %m_%d_%Y_%Hh%Mm" | ${PATHGNU}/gsed "s/ //g"`

#echo "Change ${CRITERE} with ${NEWCRITERE} in following files: " > Modification_list_${RUNDATE}.txt  


# test first which files satisfies the criteria ? 
#
#for filename in `find /Users/doris/PROCESS/SCRIPTS_OK/Param_files -type f | ${PATHGNU}/grep LaunchCISparam`
# for filename in `find . -type f | ${PATHGNU}/grep LaunchCISparam`
#    do
#   	 echo "in ${filename} :" >> Modification_list_${RUNDATE}.txt 
#   	 ${PATHGNU}/grep "${CRITERE}" ${filename} >> Modification_list_${RUNDATE}.txt
#   	 echo " " >> Modification_list_${RUNDATE}.txt
# done

# echo "And in SuperMaster files: " >> Modification_list_${RUNDATE}.txt 
# echo "-------------------------- " >> Modification_list_${RUNDATE}.txt 
# for filename in `find /Users/doris/PROCESS/SCRIPTS_OK/Param_files_SuperMaster -type f | ${PATHGNU}/grep LaunchCISparam`
#    do
#   	 echo "in ${filename}: " >> Modification_list_${RUNDATE}.txt 
# 	 ${PATHGNU}/grep "${CRITERE}" ${filename} >> Modification_list_${RUNDATE}.txt
#   	 echo " " >> Modification_list_${RUNDATE}.txt
# done
# 

# TO REPLACE IN FILE 
# 
#for filename in `find /Users/doris/PROCESS/SCRIPTS_OK/Param_files -type f | ${PATHGNU}/grep LaunchCISparam`
for filename in `find . -type f -name "*.txt" | ${PATHGNU}/grep LaunchCISparam`
   do
 	 #echo "in ${filename} :" >> Modification_list_${RUNDATE}.txt 
	 #grep "${CRITERE}" ${filename} >> Modification_list_${RUNDATE}.txt
	 #echo " " >> Modification_list_${RUNDATE}.txt
	${PATHGNU}/gsed -i "s/${CRITERE}/${NEWCRITERE}/" ${filename}
done


#echo "And in SuperMaster files: " >> Modification_list_${RUNDATE}.txt 
#echo "-------------------------- " >> Modification_list_${RUNDATE}.txt 
# for filename in `find /Users/doris/PROCESS/SCRIPTS_OK/Param_files_SuperMaster -type f | ${PATHGNU}/grep LaunchCISparam`
#    do
#  	 echo "in ${filename}: " >> Modification_list_${RUNDATE}.txt 
#	 ${PATHGNU}/grep "${CRITERE}" ${filename} >> Modification_list_${RUNDATE}.txt
#  	 echo " " >> Modification_list_${RUNDATE}.txt
#   	gsed -i "s/${CRITERE}/${NEWCRITERE}/"  ${filename}
# done

echo +++++++++++++++++++++++
echo "ALL FILES MODIFIED For ${CRITERE}"
echo +++++++++++++++++++++++


