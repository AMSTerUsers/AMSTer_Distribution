#!/bin/bash
# 
# Compute geocoding from mod images computed during the ALL2GIF.sh process
#
# Requires: - computing one pair (preferably with higest coh possible) using the SM 
#			- pairs computed by ALL2GIFF?sh in VOL1/SAR_SM/AMPLITUDES/SAT/TRK/REGION/SM_SLVs
#
# hard coded:	- path to computing one pair (preferably with higest coh possible) using the SM 
#
# Param: 	- path to where processed images pairs are, ie VOL1/SAR_SM/AMPLITUDES/SAT/TRK/REGION/

#
# Dependencies:
#	 - 
#
# New in Distro V 1.1:	- 
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2015/08/24 - could make better with more functions... when time.
# -----------------------------------------------------------------------------------------
PRG=`basename "$0"`
VER="Distro V1.0 MasTer script utilities"
AUT="Nicolas d'Oreye, (c)2016-2019, Last modified on Apr 07, 2020"
echo " "
echo "${PRG} ${VER}, ${AUT}"
echo "Processing launched on $(date) " 
echo " " 

PATHTOAMPLGIFPAIRS=$1		# e.g. /Volumes/hp-1650-Data_Share1/SAR_SM/AMPLITUDES/S1/DRC_NyamCrater_A_174/Nyam_crater_originalForm

# First: get the master and the closest slave, then compute a full single pair (skipping the unwrapping) if does not exist yet. 
# Store results in PATHTOAMPLGIFPAIRS/_AMPLI


# update all path in PATHTOAMPLGIFPAIRS pair dirs

# in each pair dir: 


#


PATHTOGEOCODEDPAIR=/Volumes/hp-D3600-Data_Share1/PROCESS/CIS/RADARSAT/RS2_UF_Asc/20151201_20151225_NyigoCrater_Zoom1_ML1_ForGeocAmpli



for SLV
