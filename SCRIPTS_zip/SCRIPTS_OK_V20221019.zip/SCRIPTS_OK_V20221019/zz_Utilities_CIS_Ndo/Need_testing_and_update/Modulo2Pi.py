#!/opt/local/bin/python
######################################################################################
# This script displays a defo map (float32) as modulo 2Pi. 
#
# Parameters: -	FILETOANALYSE  
#
# Hardcoded:  - nlines and ncols
# 
# Dependencies:	- python3.10 and modules below (see import)
#
# New in Distro V 1.0:	- 
#
# launch command : python thisscript.py param1 param2
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# Nicolas d'Oreye, (c)2016-18
######################################################################################


import numpy as np
import sys
from numpy import *

filetoprocess = sys.argv[1]

A = np.fromfile("%s" % (filetoprocess),dtype='float32')

where_are_NaNs = isnan(A)
A[where_are_NaNs] = 0

#A.tofile("%s%s" % (filetoprocess,"zero"))

numberoflines = 1985
numberofcols = 2268

# Wavelength (in cm)
L = 5.5465765

print("")
print ("File to analyse: %s" % (filetoprocess))
#print ("Number of bins: %s" % (numberofbins))
print("")

B = np.array(A)

# set all values smaller than -10 Mo to 0 in arr
#arr[arr < -1000000] = 0

A = np.where(B < -1000000, 0, B)
#A =  np.place(B, B < -1000000, 0)


rewrap = lambda i: ((i * 100 * 2 * pi ) / (L /2)) % (2 * pi)

vectorized_rewrap = np.vectorize(rewrap)

C=(vectorized_rewrap(A))
print (A[1320000])
print (B[1320000])
print (C[1320000])

print ( np.max(A))
print ( np.max(B))
print ( np.max(C))


# Replace zeros with NaN
#A[A == 0] = np.nan

#D = np.reshape(C % (2 * pi), (int(numberoflines), int(numberofcols)))
D = np.reshape(C , (int(numberoflines), int(numberofcols)))

E = np.where(B == 2 * pi, 0, B)
print ( np.max(E))
E.tofile("%s%s" % (filetoprocess,"Wrapped"))

#plt.show()

#plt.savefig('Histo.pdf')

#C.tofile("%s"".CropLastCol" % (filetoprocess))
