#!/bin/bash
# -----------------------------------------------------------------------------------------
# This script is aiming at re-processing a fully terminated SuperMaster_MassProcess.sh 
#   from the Detrend (included) till the end of geocoding and renaming. 
#   
# All slave images must have been processed and stored in the usual MASSPROCESS/SAT/TRK directory.
#     e.g. /Volumes/hp-3600_RAID6/MASSPROCESS/SATDIR/TRKDIR
#
# Parameters : - file with the pairs to reprocess (e.g. from previous run of Verify_MassProcess_Results.sh)  
#              - file with the processing parameters (incl path) 
#
# Dependencies (this list is from the SuperMaster_MassProcess.sh) :
#    - Data coregistered on a super master 
#    - The FUNCTIONS_FOR_CIS.sh file with the function used by the script. Will be called automatically by the script
#    - gnu sed and awk for more compatibility. 
#    - cpxfiddle is usefull though not mandatory. This is part of Doris package (TU Delft) available here :
#            http://doris.tudelft.nl/Doris_download.html. 
#    - Fiji (from ImageJ) is usefull as well though not mandatory
#    - convert (to create jpg images from sun rasters)
#    - bc (for basic computations in scripts)
#    - functions "say" for Mac or "espeak" for Linux, but might not be mandatory
#    - gmt (for inverting deformation if MAS > SLV)
#    - snaphu
#
# New in V1.0.1 beta: espeak instead of say if Linux 
# New in V1.0.2 beta: - cleaning in variable declaration
#
# CSL InSAR Suite utilities. 
# NdO (c) 2015/08/24 - could make better with more functions... when time.
# -----------------------------------------------------------------------------------------
PRG=`basename "$0"`
VER="v1.0.2 Beta CIS script utilities"
AUT="Nicolas d'Oreye, (c)2015-2018, Last modified on June 22, 2020"
echo " "
echo "${PRG} ${VER}, ${AUT}"
echo " "

PAIRFILE=$1					# File with the compatible pairs; e.g. from Verify_MassProcess_Results.sh and Imgs_NotInDefoInterpolDetrend.txt
PARAMFILE=$2				# File with the parameters needed for the run

if [ $# -lt 2 ] ; then echo “Usage $0 PAIRS_FILE PARAMETER_FILE ”; exit; fi

# Function to extract parameters from config file: search for it and remove tab and white space
function GetParam()
	{
	unset PARAM 
	PARAM=$1
	PARAM=`grep -m 1 ${PARAM} ${PARAMFILE} | cut -f1 -d \# | ${PATHGNU}/gsed "s/	//g" | ${PATHGNU}/gsed "s/ //g"`
	eval PARAM=${PARAM}
	echo ${PARAM}
	}

# below if from SuperMaster_MassProcess.sh
SUPERMASTER=`GetParam SUPERMASTER`			# SUPERMASTER, date of the super master as selected by Prepa_MSBAS.sh in
											# e.g. /Volumes/hp-1650-Data_Share1/SAR_SUPER_MASTERS/MSBAS/VVP/seti/setParametersFile.txt

PROROOTPATH=`GetParam PROROOTPATH`			# PROROOTPATH, path to dir where data will be processed in sub dir named by the sat name. 
DATAPATH=`GetParam DATAPATH`				# DATAPATH, path to dir where data are stored 
FCTFILE=`GetParam FCTFILE`					# FCTFILE, path to file where all functions are stored

DEMDIR=`GetParam DEMDIR`					# DEMDIR, path to dir where DEM is stored
RECOMPDEM=`GetParam "RECOMPDEM,"`			# RECOMPDEM, recompute DEM even if already there (FORCE), or trust the one that would exist (KEEP)
SIMAMP=`GetParam "SIMAMP,"`					# SIMAMP, (SIMAMPno or SIMAMPyes). Option to compute simulated amplitude during Extenral DEM generation - usually not needed.

POP=`GetParam "POP,"`						# POP, option to pop up figs or not (POPno or POPyes)
FIG=`GetParam "FIG,"`						# FIG, option to compute or not the quick look using cpxfiddle (FIGno or FIGyes)

SATDIR=`GetParam "SATDIR,"`					# Satellite system. E.g. RADARSAT (must be the same as dirname structure)
TRKDIR=`GetParam "TRKDIR,"`					# Processing directory and dir where data are stored E.g. RS2_UF (must be the same as dirname structure)

CROP=`GetParam "CROP,"`						# CROP, CROPyes or CROPno 
FIRSTL=`GetParam "FIRSTL,"`					# Crop limits: first line to use
LASTL=`GetParam "LASTL,"`					# Crop limits: last line to use
FIRSTP=`GetParam "FIRSTP,"`					# Crop limits: first point (row) to use
LASTP=`GetParam "LASTP,"`					# Crop limits: last point (row) to use

MLAMPLI=`GetParam "MLAMPLI,"`				# MLAMPLI, Multilooking factor for amplitude images reduction (used for coregistration - 4-6 is appropriate). If rectangular pixel, it will be multiplied by corresponding ratio.
ZOOM=`GetParam "ZOOM,"`						# ZOOM, zoom factor used while cropping
PIXSHAPE=`GetParam "PIXSHAPE,"`				# PIXSHAPE, pix shape for products : SQUARE or ORIGINALFORM   
CALIBSIGMA, if SIGMAYES it will output sigma nought calibrated amplitude file (for S1 only)                    

COH=`GetParam "COH,"`						# Coarse coregistration correlation threshold  
CCOHWIN=`GetParam "CCOHWIN,"`     			# CCOHWIN, Coarse coreg window size (64 by default but may want less for very small crop)
CCDISTANCHOR=`GetParam "CCDISTANCHOR,"`		# CCDISTANCHOR, Coarse registration range & az distance between anchor points [pix]

FCOH=`GetParam "FCOH,"`						# Fine coregistration correlation threshold 
FCOHWIN=`GetParam "FCOHWIN,"`				# FCOHWIN, Fine coregistration window size (size in az or rg is computed based on Az/Rg ratio) 
FCDISTANCHOR=`GetParam "FCDISTANCHOR,"`		# FCDISTANCHOR, Fine registration range & az distance between anchor points [pix]

PROCESSMODE=`GetParam "PROCESSMODE,"`		# PROCESSMODE, DEFO to produce DInSAR or TOPO to produce DEM

INITPOL=`GetParam "INITPOL,"`		        # INITPOL, force polarisation at initInSAR for InSAR processing. If it does not exists it will find the first compatible MAS-SLV pol. 
LLRGCO=`GetParam "LLRGCO,"`					# LLRGCO, Lower Left Range coord offset for final interferometric products generation. Used mainly for Shadow measurements
LLAZCO=`GetParam "LLAZCO,"`					# LLAZCO, Lower Left Azimuth coord offset for final interferometric products generation. Used mainly for Shadow measurements
INTERFML=`GetParam "INTERFML,"`				#  multilook factor for final interferometric products
COHESTIMFACT=`GetParam "COHESTIMFACT,"`		# COHESTIMFACT, Coherence estimator window size
FILTFACTOR=`GetParam "FILTFACTOR,"`			# Range and Az filtering factor for interfero
POWSPECSMOOTFACT=`GetParam "POWSPECSMOOTFACT,"`	# POWSPECSMOOTFACT, Power spectrum filtering factor (for adaptative filtering)

APPLYMASK=`GetParam "APPLYMASK,"`			# APPLYMASK, Apply mask before unwrapping (APPLYMASKyes or APPLYMASKno)
if [ ${APPLYMASK} == "APPLYMASKyes" ] 
 then 
  PATHTOMASK=`GetParam "PATHTOMASK,"`			# PATHTOMASK, geocoded mask file name and path
 else 
  PATHTOMASK=`echo "NoMask"`
fi

SKIPUW=`GetParam "SKIPUW,"`					# SKIPUW, SKIPyes skips unwrapping and geocode all available products

CONNEXION_MODE=`GetParam "CONNEXION_MODE,"`	# CONNEXION_MODE, number of times that connexion search radius is augmented when stable connections are found ; 0 search along all coh zone  
BIASCOHESTIM=`GetParam "BIASCOHESTIM,"`		# BIASCOHESTIM, Biased coherence estimator range & Az window size (do not appli pix rratio) 
BIASCOHSPIR=`GetParam "BIASCOHSPIR,"`		# BIASCOHSPIR, Biased coherence square spiral size (if residual fringes are not unwrapped decrease it; must be odd)  
COHCLNTHRESH=`GetParam "COHCLNTHRESH,"`		# COHCLNTHRESH, Coherence cleaning threshold - used for mask
FALSERESCOHTHR=`GetParam "FALSERESCOHTHR,"`	# FALSERESCOHTHR, False Residue Coherence Threshold: higher is much slower. Use max 0.15 e.g. in crater 
UW_METHOD=`GetParam "UW_METHOD,"`			# UW_METHOD, Select phase unwrapping method (SNAPHU, CIS or DETPHUN)
DEFOTHRESHFACTOR=`GetParam "DEFOTHRESHFACTOR,"`	# DEFOTHRESHFACTOR, Snaphu : Factor applied to rho0 to get threshold for whether or not phase discontinuity is possible. rho0 is the expected, biased correlation measure if true correlation is 0. Increase if not good. 
DEFOCONST=`GetParam "DEFOCONST,"`				# DEFOCONST, Snaphu : Ratio of phase discontinuity probability density to peak probability density expected for discontinuity-possible pixel differences. Value of 1 means zero cost for discontinuity, 0 means infinite cost. Decrease if prblm. 
DEFOMAX_CYCLE=`GetParam "DEFOMAX_CYCLE,"`		# DEFOMAX_CYCLE, Snaphu : Max nr of expected phase cycle discontinuity. For topo where no phase jump is expected, it can be set to zero. 
SNAPHUMODE=`GetParam "SNAPHUMODE,"`				# SNAPHUMODE, Snaphu : TOPO, DEFO, SMOOTH, or NOSTATCOSTS. 
DETITERR=`GetParam "DETITERR,"`				# DETITERR, detPhUn : Number of iterration for detPhUn (Integer: 1, 2 or 3 is generaly OK)
DETCOHTHRESH=`GetParam "DETCOHTHRESH,"`		# DETCOHTHRESH, Coherence threshold

INTERPOL=`GetParam "INTERPOL,"`				# INTERPOL, interpolate the unwrapped interfero BEFORE or AFTER geocoding or BOTH. 	
REMOVEPLANE=`GetParam "REMOVEPLANE,"`		# REMOVEPLANE, if DETREND it will remove a best plane after unwrapping. Anything else will ignore the detrending. 	

PROJ=`GetParam "PROJ,"`						# PROJ, Chosen projection (UTM or GEOC)
GEOCMETHD=`GetParam "GEOCMETHD,"`			# GEOCMETHD, Resampling Size of Geocoded product: Forced (at FORCEGEOPIXSIZE - convenient for further MSBAS), Auto (closest multiple of 10), Closest (closest to ML az sampling)
RADIUSMETHD=`GetParam "RADIUSMETHD,"`		# LetCIS (CIS will copute best radius) or forced to a given radius 
RESAMPMETHD=`GetParam "RESAMPMETHD,"`		# TRI = Triangulation; AV = weighted average; NN = nearest neighbour 
WEIGHTMETHD=`GetParam "WEIGHTMETHD,"`		# Weighting method : ID = inverse distance; LORENTZ = lorentzian 
IDSMOOTH=`GetParam "IDSMOOTH,"`				# ID smoothing factor  
IDWEIGHT=`GetParam "IDWEIGHT,"`				# ID weighting exponent 
FWHM=`GetParam "FWHM,"`						# Lorentzian Full Width at Half Maximum
ZONEINDEX=`GetParam "ZONEINDEX,"`			# Zone index  
FORCEGEOPIXSIZE=`GetParam "FORCEGEOPIXSIZE,"` # Pixel size (in m) wanted for your final products. Required for MSBAS
XMIN=`GetParam "XMIN,"`						# XMIN, minimum X UTM coord of final Forced geocoded product
XMAX=`GetParam "XMAX,"`						# XMAX, maximum X UTM coord of final Forced geocoded product
YMIN=`GetParam "YMIN,"`						# YMIN, minimum Y UTM coord of final Forced geocoded product
YMAX=`GetParam "YMAX,"`						# YMAX, maximum Y UTM coord of final Forced geocoded product
GEOCKML=`GetParam "GEOCKML,"`				# GEOCKML, a kml file to define final geocoded product. If not found, it will use the coordinates above

REGION=`GetParam "REGION,"`					# REGION, Text description of area for dir naming
DEMNAME=`GetParam "DEMNAME,"`				# DEMNAME, name of DEM inverted by lines and columns

MASSPROCESSPATH=`GetParam MASSPROCESSPATH`	# MASSPROCESSPATH, path to dir where all processed pairs will be stored in sub dir named by the sat/trk name (SATDIR/TRKDIR)
RESAMPDATPATH=`GetParam RESAMPDATPATH`		# RESAMPDATPATH, path to dir where resampled data are stored 

mkdir -p ${PROROOTPATH}
eval PROPATH=${PROROOTPATH}/${SATDIR}/${TRKDIR}	# Path to dir where data will be processed.

source ${FCTFILE}

# Define Crop Dir
if [ ${CROP} == "CROPyes" ]
	then
		CROPDIR=/Crop_${REGION}_${FIRSTL}-${LASTL}_${FIRSTP}-${LASTP} #_Zoom${ZOOM}_ML${INTERFML}
	else
		CROPDIR=/NoCrop
fi

# Check GeocMethod : if you process a MassProcessing, I guess you intend to make MSBAS, hence FORCE is required
if [ ${GEOCMETHD} == "ClosestMassProc" ]
	then
		EchoTeeRed " OK you want to keep geocoded pixels as close as possible as original ones although you run a Mass Process."
		EchoTeeRed "   Be aware that you wan't be able to do MSBAS because other modes will be in different grid."
		EchoTeeRed "   It will be ok for a SBAS with only this mode though. You know what you are doing..."
		GEOCMETHD="Closest"
	else 
		if [ ${GEOCMETHD} != "Forced" ] 
			then 
				EchoTeeRed "Geocoded pixels not forced to fixed grid. You wan't be able to run MSBAS. If you want it anyway, change GEOCMETHD to ClosestMassProc." 
				exit 0
			else  
				EchoTeeRed "HOPE YOU HAVE CHECKED THE SIZE OF YOUR GEOCODED PIXELS AND THE COORDINATES OF YOUR FINAL PRODUCTS' CORNERS." 
		fi
fi
echo 
echo 


# Define Dir where data are/will be cropped
INPUTDATA=${DATAPATH}/${SATDIR}/${TRKDIR}/${CROPDIR}
mkdir -p ${INPUTDATA}

# Supermaster directory name based on date given in LaunchParameters file
if [ ${SATDIR} == "S1" ] ; then 
		EchoTeeRed "S1 data can't be coregistered on a SUPERMASTER for SuperMaster_MassProc.sh."
		EchoTeeRed " Pairs will be processed separately and compared to each other after geocoding."
		SUPERMASNAME=`ls ${INPUTDATA} | ${PATHGNU}/grep ${SUPERMASTER} | cut -d . -f 1` 		 # i.e. if S1 is given in the form of date, MASNAME is now the full name of the image anyway
	else
		SUPERMASNAME=${SUPERMASTER} 
fi	
SUPERMASDIR=${SUPERMASNAME}.csl

# Check required dir:
#####################
	# Where data will be processed for the coregistration computation
	if [ -d "${PROROOTPATH}/" ]
	then
 	  echo "  // OK: a directory exist where I can create a processing dir." 
	else
		PROROOTPATH="$(${PATHGNU}/gsed s/-Data_Share1/-Data_Share1-1/ <<<$PROROOTPATH)"
	   if [ -d "${PROROOTPATH}/" ]
			then
  	 			echo "  // Double mount of hp-storeesay. Renamed dir with -1"
 	  		else 
  	 			echo " "
  	 			echo "  // NO directory ${PROROOTPATH}/ where I can create a processing dir. Can't run..." 
   				echo "  // Check parameters files and  change hard link if needed."
  	 			exit 1
 	  	fi
	fi

	# Path to data
	if [ -d "${DATAPATH}" ]
	then
	   echo "  // OK: a directory exist where data are supposed to be stored." 
	   mkdir -p ${PROPATH}
	else
	   DATAPATH="$(${PATHGNU}/gsed s/-Data_Share1/-Data_Share1-1/ <<<$DATAPATH)"
	   if [ -d "${DATAPATH}/" ]
			then
				echo "  // Double mount of hp-storeesay. Renamed dir with -1"
			else 
	 			echo "  // "
	   			echo "  // NO expected data directory. Can't run..." 
	   			echo "  // PLEASE REFER TO SCRIPT and  change hard link if needed"
	   			exit 1
		fi
	fi
	
	if [ -d "${DEMDIR}" ]
	then
	   echo "  // OK: a directory exist where DEM is supposed to be stored." 
	else
		DEMDIR="$(${PATHGNU}/gsed s/-Data_Share1/-Data_Share1-1/ <<<$DEMDIR)"
	   if [ -d "${DEMDIR}/" ]
			then
				echo "  // Double mount of hp-storeesay. Renamed dir with -1"
			else 
	  			echo " "
	   			echo "  // NO expected DEM directory. Can't run..." 
	   			echo "  // PLEASE REFER TO SCRIPT and  change hard link if needed"
	   			exit 1		
	   	fi
	fi

	# Define Super Master Crop Dir and place where original data are
	if [ ${CROP} == "CROPyes" ]
		then
			SMCROPDIR=SMCrop_SM_${SUPERMASTER}_${REGION}_${FIRSTL}-${LASTL}_${FIRSTP}-${LASTP}   #_Zoom${ZOOM}_ML${INTERFML}
		else
			SMCROPDIR=SMNoCrop_SM_${SUPERMASTER}  #_Zoom${ZOOM}_ML${INTERFML}
	fi
	# Resampled data on SuperMaster in csl format are stored in 
	OUTPUTDATA=${RESAMPDATPATH}/${SATDIR}/${TRKDIR}/${SMCROPDIR}

EchoTee "" 
EchoTee "---------------------------------------------------------------------"
EchoTee " Suppose resampled data to SM are stored somewhere on ${OUTPUTDATA}"
EchoTee "         If not change hard link in parameters file"
EchoTee ""
EchoTee " Suppose data will be processed somewhere in ${PROPATH}/"
EchoTee "         If not change hard link in parameters file"
EchoTee " Suppose processed data will be stored somewhere in ${MASSPROCESSPATH}/"
EchoTee " Suppose processing zone UTM 35 - cfr envi headers"
EchoTee "---------------------------------------------------------------------"
EchoTee ""



# Path to resampled data  
	if [ -d "${OUTPUTDATA}" ]  # Path to dir where resampled data are stored.
	then
	   echo "  // OK: a directory exist where Resampled data on Super Master ${SUPERMASTER} are stored ." 
	   echo "  //    They were most probably computed wth a script CIS_sat_SuperMasterCoreg.sh"
	   mkdir -p ${PROPATH}
	else
	   echo " "
	   echo "  // NO expected ${OUTPUTDATA} directory."
	   echo "  // Can't run wthout these Resampled data on Super Master ${MAS}" 
	   echo "  // PLEASE REFER TO SCRIPT and  change hard link if needed,"
	   echo "  // or run the appropriate script such as CIS_sat_SuperMasterCoreg.sh "
	   exit 1
	fi


# Path to where mass processing results will be sored
if [ -d "${MASSPROCESSPATH}" ]
then
   echo "  // OK: a directory exist where Mass Processing results can be stored. "
else
   echo "  // "
   echo "  // NO expected directory where Mass Processing results can be stored. Can't run..." 
   echo "  // PLEASE REFER TO SCRIPT and  change hard link if needed or create dir."
   exit 1
fi


	
# Let's Go:
###########	
 	if [ "${SATDIR}" == "S1" ] && [ "${ZOOM}" != "1" ] ; then EchoTeeRed "Sentinel data processing only possible with zoom factor 1" ; exit 0 ; fi

# Prepare
	# Create working dirs if does not exist yet
	RUNDIR=${PROPATH}/${SMCROPDIR}_Zoom${ZOOM}_ML${INTERFML}
	mkdir -p ${RUNDIR}

	MASSPROCESSPATHLONG=${MASSPROCESSPATH}/${SATDIR}/${TRKDIR}/${SMCROPDIR}_Zoom${ZOOM}_ML${INTERFML}	# i.e. now as written here
	mkdir -p ${MASSPROCESSPATHLONG}


for PAIRTODETREND in `cat ${PAIRFILE}` 
do 
	# Get it detrended
	##################
	cd ${MASSPROCESSPATHLONG}/${PAIRTODETREND}/i12
	
	#change path in /InSARProducts/bestPlaneRemoval.txt
	ChangeParam "File to be corrected" ${MASSPROCESSPATHLONG}/${PAIRTODETREND}/i12/InSARProducts/bestPlaneRemoval.txt bestPlaneRemoval.txt
	
	bestPlaneRemoval2 ${MASSPROCESSPATHLONG}/${PAIRTODETREND}/i12/InSARProducts/bestPlaneRemoval.txt
	# create the figure
	deformationMap.interpolated.flattened.ras.sh
	
	# Geocode the detrended (and detrended and interpolated	if applicable)
	######################################################################
	# From fct ManageGeocoded
	
	# Supposedly all is geocoded but the residuals detrended (and interpolated if applicable) 
					#  SLRDEM, MASAMPL, SLVAMPL, COH, INTERF, FILTINTERF, RESINTERF, UNWPHASE
	FILESTOGEOC=`echo "NO NO NO NO NO NO YES NO"`
	# should run GeocUTM ${FILESTOGEOC} but one need only the exec part because param file was normally adjusted in geoProjectionParameters.txt.
	# Need adjust path below: 
	
	if [ ${RADIUSMETHD} == "LetCIS" ] 
		then
			# Let CIS Choose what is the best radius, that is 2 times the distance to the nearest neighbor
			geoProjection -rk ${RUNDIR}/i12/TextFiles/geoProjectionParameters.txt	| tee -a ${LOGFILE}
		else 
			# Force radius: force radius to RADIUSMETHD times the distance to the nearest neighbor. Default value (i.e. LetCIS) is 2)
			geoProjection -rk -f=${RADIUSMETHD} ${RUNDIR}/i12/TextFiles/geoProjectionParameters.txt	| tee -a ${LOGFILE}
	fi

	# get size of geocoded product
	GEOPIXW=`GetParamFromFile "X size of geoprojected products" geoProjectionParameters.txt`
 	GEOPIXL=`GetParamFromFile "Y size of geoprojected products" geoProjectionParameters.txt`	
 	
 	# ajuster path ci-dessous
 	case ${INTERPOL} in 
			"AFTER")  
				if [ ${REMOVEPLANE} == "DETREND" ] 
						then 
							EchoTee "Request interpolation after geocoding."
							PATHDEFOGEOMAP=deformationMap.flattened.${PROJ}.${GEOPIXSIZE}x${GEOPIXSIZE}.bil
							fillGapsInImage ${RUNDIR}/i12/GeoProjection/${PATHDEFOGEOMAP} ${GEOPIXW} ${GEOPIXL}   
							#PATHDEFOGEOMAP=deformationMap.flattened.${PROJ}.${GEOPIXSIZE}x${GEOPIXSIZE}.bil.interpolated	
						else 
							EchoTee "Request interpolation after geocoding."
							PATHDEFOGEOMAP=deformationMap.${PROJ}.${GEOPIXSIZE}x${GEOPIXSIZE}.bil
							fillGapsInImage ${RUNDIR}/i12/GeoProjection/${PATHDEFOGEOMAP} ${GEOPIXW} ${GEOPIXL}   
							#PATHDEFOGEOMAP=deformationMap.${PROJ}.${GEOPIXSIZE}x${GEOPIXSIZE}.bil.interpolated	
				fi ;;
			"BOTH")  
				if [ ${REMOVEPLANE} == "DETREND" ] 
						then 
							EchoTee "Request interpolation before and after geocoding."
							PATHDEFOGEOMAP=deformationMap.interpolated.flattened.${PROJ}.${GEOPIXSIZE}x${GEOPIXSIZE}.bil
							fillGapsInImage ${RUNDIR}/i12/GeoProjection/${PATHDEFOGEOMAP} ${GEOPIXW} ${GEOPIXL}
							#PATHDEFOGEOMAP=deformationMap.interpolated.flattened.${PROJ}.${GEOPIXSIZE}x${GEOPIXSIZE}.bil.interpolated   
						else 
							EchoTee "Request interpolation before and after geocoding."
							PATHDEFOGEOMAP=deformationMap.interpolated.${PROJ}.${GEOPIXSIZE}x${GEOPIXSIZE}.bil
							fillGapsInImage ${RUNDIR}/i12/GeoProjection/${PATHDEFOGEOMAP} ${GEOPIXW} ${GEOPIXL}
							#PATHDEFOGEOMAP=deformationMap.interpolated.${PROJ}.${GEOPIXSIZE}x${GEOPIXSIZE}.bil.interpolated   
				fi ;;
			"BEFORE") 
				EchoTee "Do not request interpolation after geocoding" 
				#PATHDEFOGEOMAP=deformationMap.${PROJ}.${GEOPIXSIZE}x${GEOPIXSIZE}.bil
				;;		
		esac
	
		# need to adjust plots and naming ?
	


done 
