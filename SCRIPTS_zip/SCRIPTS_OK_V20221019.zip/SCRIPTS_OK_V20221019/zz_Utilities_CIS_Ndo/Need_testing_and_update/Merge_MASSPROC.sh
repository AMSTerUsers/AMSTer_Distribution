#!/bin/bash
######################################################################################
# This script aims at merging 2 dir with MASSPROCESS results (containing Geocoded/, 
#   GeocodedRasters/, and pairs dirs)
# Duplicated file will not be moved. 
#
# parameters: 	- Dir to add (with full path)
#				- target dir that contains already some MASSPROCESS results (with full path)
#
# I know, it is a bit messy and can be improved.. when time. But it works..
# N.d'Oreye, v 1.0 2019/10/10 -                         
######################################################################################

SOURCEDIR=$1 	# e.g. SAR_MASSPROCESS/SAT/TRK_MODE_rem1/
TARGETDIR=$2	# e.g. SAR_MASSPROCESS/SAT/TRK_MODE/

PRODUCTS="Ampli Coh Defo DefoInterpol DefoInterpolDetrend DefoInterpolx2Detrend InterfFilt InterfResid UnwrapPhase"

cd ${SOURCEDIR}/Geocoded
	for DIRS in ${PRODUCTS}
	   do
		#mv ${DIRS}/* ${TARGETDIR}/Geocoded/${DIRS}/	  # Attention it may cause error "mv : Argument list too long "
		#find ${SOURCEDIR}/Geocoded/${DIRS}/* -type f -exec sh -c 'mv "$@" "$0"' ${TARGETDIR}/Geocoded/${DIRS}/	 {} +  # fatser but overwrites existing files 
		if [ -d ${DIRS} ] 
			then
				cd ${DIRS}
				for FILES in `ls *`
					do 
						if [ ! -f ${TARGETDIR}/Geocoded/${DIRS}/${FILES} ] ; then mv ${FILES} ${TARGETDIR}/Geocoded/${DIRS}/ ; fi
				done 
				cd ..
		fi
	done
#rm -Rf ${SOURCEDIR}/Geocoded

cd ${SOURCEDIR}/GeocodedRasters
	for DIRS in ${PRODUCTS}
	   do
		#mv ${DIRS}/* ${TARGETDIR}/GeocodedRasters/${DIRS}/	  # Attention it may cause error "mv : Argument list too long "
		#find ${SOURCEDIR}/GeocodedRasters/${DIRS}/* -type f -exec sh -c 'mv "$@" "$0"' ${TARGETDIR}/GeocodedRasters/${DIRS}/	 {} + # fatser but overwrites existing files 
		if [ -d ${DIRS} ] 
			then
				cd ${DIRS}
				for FILES in `ls *`
					do 
						if [ ! -f ${TARGETDIR}/GeocodedRasters/${DIRS}/${FILES} ] ; then mv ${FILES} ${TARGETDIR}/GeocodedRasters/${DIRS}/ ; fi
				done 
				cd ..
		fi
	done
#rm -Rf ${SOURCEDIR}/GeocodedRasters

cd ${SOURCEDIR}/

	for FILES in `ls *.txt`
		do 
			if [ ! -f ${TARGETDIR}/${FILES} ] ; then mv ${FILES} ${TARGETDIR}/ ; fi
	done 
	
	for DIRS in `ls -d * | ${PATHGNU}/grep -v Geocoded`
		do 
			if [ ! -d ${TARGETDIR}/${DIRS} ] ; then mv ${DIRS} ${TARGETDIR}/ ; fi
	done 
