#!/opt/local/bin/python
######################################################################################
# This script computes the histogram of a binary float32 file. 
#
# Parameters: -	FILETOANALYSE  
#
# Hardcoded:  - NBINS
#			  - range 
#			  - remove zeros if desired
# 
# Dependencies:	- python3.10 and modules below (see import)
#
# New in Distro V 1.0:	- 
#
# launch command : python thisscript.py param1 param2
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# Nicolas d'Oreye, (c)2016-18
######################################################################################

import numpy as np
import sys
from numpy import *
import matplotlib.pyplot as plt

filetoprocess = sys.argv[1]



print("")
print ("File to analyse: %s" % (filetoprocess))
#print ("Number of bins: %s" % (numberofbins))
print("")


A = np.fromfile("%s" % (filetoprocess),dtype='float32')

# replace zeros with NaN
A[A == 0] = np.nan


#plt.hist(A[~np.isnan(A)] , 100)
plt.hist(A * 1000, 100, range=[-25, 25])

#plt.show()

plt.savefig('Histo.pdf')

#C.tofile("%s"".CropLastCol" % (filetoprocess))
