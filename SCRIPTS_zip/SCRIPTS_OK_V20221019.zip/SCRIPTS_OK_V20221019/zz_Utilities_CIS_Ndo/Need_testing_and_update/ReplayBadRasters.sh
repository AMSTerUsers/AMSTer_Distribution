#!/bin/bash
# Script aims at replaying process that led to bad rasters. 
# List of images to replay must be in file set in param 1. It is created eg. by 
# running in PrblmRasters the following : ls *.ras > Replay.txt and remove all
# characters after the slave date. 
#
# Parameters:	- list of images to replay
#				- destination dir where to move pairs mass processed to replay (eg REPLAY_VVP_ML20)
#
# Must be launched from SAR_MASSPORCESS/SAT/TRK/DIR_WHERE_DATA_ARE

LISTTOREPLAY=$1
DESTINATIONDIR=$2

for DIRTOMOVE in `cat ${LISTTOREPLAY}`
do 
	mv ${DIRTOMOVE} ${DESTINATIONDIR} 
done



