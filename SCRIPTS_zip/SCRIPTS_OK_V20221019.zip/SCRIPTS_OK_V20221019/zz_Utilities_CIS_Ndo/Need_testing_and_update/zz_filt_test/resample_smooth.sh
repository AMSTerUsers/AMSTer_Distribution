#!/bin/bash
# Resample and smooth using gmt
# Usage: resample_smooth.sh filelist
#   For ecxample resample_smooth.sh *8.rev
############# HG may 2016
FILTVAL=51   # width of median filter

FLST=`ls $*`

for f in $FLST
do
  fout=${f}_filt.rev
  gmt grdfilter $f -Dp -Fm${FILTVAL} -G${fout}=gd:ENVI
done

