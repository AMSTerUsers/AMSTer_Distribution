#!/bin/bash
# Resample and smooth using gmt

f=20160411_20160427_HA-32m_BT-16d_deformationMap.UTM.8x8.rev
fout=20160411_20160427_HA-32m_BT-16d_deformationMap.UTM.8x8_filt.rev

gmt grdinfo $f # check if it can be read

# Try grdsample directly (maybe grfilter must be used first)
#gmt grdsample $f -G${f}_out.rev -V -n  # Nope

gmt grdfilter $f -Dp -Fm50 -G${fout}=gd:ENVI

#### Plotting for verification

# New file
R="-R703004/712804/9715996/9726996"
gmt makecpt -Crainbow -T-0.0549650341272/0.0744057148695/0.0001 > g.cpt
gmt grdimage ${fout} $R -JX15/15 -E50 -K -P -B300 -Cg.cpt -X1.5i -Y1.25i > ${fout}.ps
open ${fout}.ps
#gmt psscale -Cg.cpt -D5.1i/1.35i/2.88i/0.4i -O -K -I0.3 -Ac -Bx1000 -By+lm >> 50new.ps

############### Run a loop to test the median filter value
TVALS="1 3 5 11 51 101 1001"
for T in $TVALS; do
  fout=20160411_20160427_HA-32m_BT-16d_deformationMap.UTM.8x8_filt${T}.rev
  gmt grdfilter $f -Dp -Fm${T} -G${fout}=gd:ENVI   
  gmt grdimage ${fout} $R -JX15/15 -K -P -B2000WSne -Cg.cpt -X1.5i -Y1.25i > ${fout}.ps
  #gmt grdimage ${fout} $R -JX15/15 -E50 -K -P -B1000 -Cg.cpt -X1.5i -Y1.25i > ${fout}.ps
done
open *ps
