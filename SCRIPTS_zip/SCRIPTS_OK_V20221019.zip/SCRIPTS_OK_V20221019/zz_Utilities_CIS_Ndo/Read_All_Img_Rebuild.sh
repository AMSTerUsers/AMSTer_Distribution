#!/bin/bash
# -----------------------------------------------------------------------------------------
#
# VERSION TO REBUILD MISSING BURSTS - muste be launched after having removed links to images withouts bursts from SAR_CAL/S1_REGION/NoCrop
#
# This script is aiming at reading all images from a given dir and store them in csl 
#      format where they will be used by the cis automated scripts. 
# The script will sort S1 images in Asc and Desc specific dir. 
#
#
# Parameters : - path to dir with the raw archives to read.   
#              - path to dir where images in csl format will be stored
#              - satellite (to know which dir naming format is used)
#			   - kml file and path of footprint of zone of interest (optional but useful eg for S1)
#			   - for S1 : force reading data in yyyy directories if this param is "ForceAllYears" 
#
#
# Dependencies:	- .bashrc is sourced for safe use in cronjob
#   			- gnu sed and awk for more compatibility. 
# 				- path to sentinel orbits must be in bashrc with a line such as : 
#					export S1_PRECISES_ORBITS_DIR=/...your path to .../S1_ORB/AUX_POEORB
#				  Also, it is recommended to get a cronjob to download them every day.
#   			- functions "say" for Mac or "espeak" for Linux, but might not be mandatory
# 				- for S1 images : a preferred polarisation mode so restrict the reading (hard coded). If missing, it will read and stitch all polarisations 
#				- for S1 images : List_All_S1_ImgSize.sh
#					
#
# New in V1.0 Beta:	- Based on developpement verions 3.2
#                   - cosmetic cleaning and commenting for distribution purpose. 
#        V1.0.1 beta: - Reading S1 with bulk reader was in the "case" loop reulting in infinite loop
#					  -	Move S1 data older than 6 month in /_yyyy. 
#                     - Can force to Read S1 images also from /_yyyy if 5th param is "ForceAllYears" 
#        V1.0.2 beta: - Change S1 orbit dir name and info about hard coded path
#        V1.0.3 beta: - Correct bug in relaunch in case each link in CSL has not its data in _MODE_TRK
#        V1.1.0 beta: - check for temporary orbit and rename accordingly
#        V2.0.0 beta: - check S1 links before reading images 
#                     - Do not change S1 dir when orbits are updated. Rather take into account the log file from CIS V20180620
#                     - Take care of the Fast24 S1 images from the log file from CIS V20180620
#        V2.0.1 beta: - test if dir with recent data is empty before attempting S1Reading
#                     - avoid unecessary error message when no data to process
#        V2.1.0 beta: - Download S1 orbits if image missing orbit is older than 31 days then 
#                       attempt to read again all images (only once !)
#        V2.1.1 beta: - Allow CSL dir without NoCrop for CSK
#        V2.1.2 beta: - take state variable for PATHGNU etc
#                     - espeak instead of say if Linux 
#        V2.1.3 beta: - mv updated files 
#					  - several bugs corrected in managing mv files related to updated orbits
#        V2.1.4 beta: - path naming for linux and mac                      
#        V2.1.5 beta: - bug in fct SpeakOut
#        V2.1.6 beta: - check OS muste be after sourcing bashrc 
#        V2.1.7 beta: - function file was not eval
#        V2.2.0 beta: - reads ERS
#        V2.3.0 beta: - stitch and check master size - if wrong, re-stitch master 
#					  - force S1 reader at given pol
#        V2.4.0 beta: - delete bursts after assembling bursts to save disk space. MODIF CANCELLED 
#					  - force reading only INITPOL as hard coded varaiable 
#        V2.4.1 beta: - List and store the size of S1 masters in NoCrop/List_Master_Sizes.txt. 
#						It is always good to look at it to ensure that no bursts are missing in some images
#        V2.4.2 beta: - Delete data that are already in SAR_CSL/S1/REGION/Quarantained when reporcessing. I.e. if after reading data, 
#  						incompleted or bad data are detected, drop the image.csl in /Quarantained and they will be discarded at all further readings
#        V2.4.3 beta: - cancel S1 burst removal after stitching ! 
#					  - list nr of S1 bursts in files in SAR_CSL/S1/REGION/NoCrop for each image
#        V2.4.4 beta: - discard $PATHFIND which was useless 
#
# CSL InSAR Suite utilities. 
# NdO (c) 2016/02/29 - could make better with more functions... when time.
# -----------------------------------------------------------------------------------------
PRG=`basename "$0"`
VER="v2.4.4 Beta CIS script utilities"
AUT="Nicolas d'Oreye, (c)2016-2018, Last modified on June 117, 2020"
echo " "
echo "${PRG} ${VER}, ${AUT}"
echo " "

RAW=$1					# path to dir with the raw archives to read (unzipped for S1 !)
CSL=$2					# path to dir where images in csl format will be stored
SAT=$3					# satellite
KMLS1=$4				# for S1 or recent other Datareader
FAY=$5					# for S1 : force reading data in yyyy directories if is "ForceAllYears" 

# vvv ----- Hard coded lines to check --- vvv 
source /$HOME/.bashrc 
INITPOL=VV  # to spare HD space, force to read only the most common momde. If you want all mode, keep this variable empty 
# Setup disk paths for processing in Luxembourg. Adjust accordingly if you run several 
FCTFILE=${PATH_SCRIPTS}/SCRIPTS_OK/FUNCTIONS_FOR_CIS.sh		
# ^^^ ----- Hard coded lines to check -- ^^^ 

RESAMPLED="${PATH_1650}/SAR_SM/RESAMPLED/"
SAR_MASSPROCESS="${PATH_3601}/SAR_MASSPROCESS/" 

# Check OS
OS=`uname -a | cut -d " " -f 1 `
echo "Running on ${OS}"
echo

source ${FCTFILE}

CSLEND=`echo -n ${CSL} | tail -c 7`
if [ "${CSLEND}" != "/NoCrop" ] && [ ${SAT} != "CSK" ]; then echo "Check your CSL dir. It must end with NoCrop instead of ${CSLEND}" ; exit 0 ; fi

# Must be defined in .bashrc
ENVORB=${ENVISAT_PRECISES_ORBITS_DIR}
SENTIORB=${S1_PRECISES_ORBITS_DIR}

function SpeakOut()
	{
	unset MESSAGE 
	local MESSAGE
	MESSAGE=$1
	# Check OS
	OS=`uname -a | cut -d " " -f 1 `

	case ${OS} in 
		"Linux") 
			espeak "${MESSAGE}" ;;
		"Darwin")
			say "${MESSAGE}" 	;;
		*)
			echo "${MESSAGE}" 	;;
	esac			
	}

if [ $# -lt 3 ] ; then echo “Usage $0 PATH_TO_RAW_IMG PATH_TO_CSL_STORAGE SATELLITE [KML] [ForceAllYears]”; exit; fi


RUNDATE=`date "+ %m_%d_%Y_%Hh%Mm" | ${PATHGNU}/gsed "s/ //g"`
LOGFILE=${CSL}/LogFile_ReadAll_${RUNDATE}.txt

if [ ${SAT} == "ENVISAT" ] && [ ! -d ${ENVORB} ]
		then
			echo "No precise orbit dir for ENVISAT. Continue anyway though better check !"
			SpeakOut "No precise orbit dir for ENVISAT. Continue anyway though better check !"
fi		

if [ ${SAT} == "S1" ] && [ $# -lt 4 ]
		then
			echo "Probably no kml (with path!) contouring the area of interest for S1 data. You do not want to process the full images, don't you ?!"
			SpeakOut "Please provide a kml contouring the area of interest for S1 data. Do not forget the path..."
			exit
fi		
if [ ${SAT} == "S1" ] && [ ! -d ${SENTIORB} ] 
		then
			echo "No precise orbit directory for sentinel 1 data. Check .bashrc. Exit"
			SpeakOut "No precise orbit directory for sentinel 1 data. Check bash rc."
			exit
fi		

echo ""
# Check required dir:
#####################

# Path where to store data in csl format 
if [ -d "${CSL}" ]
then
   echo "" > ${LOGFILE}
   EchoTee " OK: a directory exist where I can store the data in csl format." 
   EchoTee "     They will be strored in ${CSL}"
   if [ ${SAT} == "S1" ] 
   	  then EchoTee "     as link for each images. Data are stored in _Asc_TRK and Desc_TRK corresponding dir." 
   fi
   EchoTee ""
else
   echo " "
   echo " NO expected ${CSL} directory."
   echo " I will create a new one. I guess it is the first run for that mode." 
   echo ""
   mkdir -p ${CSL}
   echo "" > ${LOGFILE}
   EchoTee " NO expected ${CSL} directory. I created a new one. " 
 
fi

EchoTee "  // Command line used and parameters:"
EchoTee "  // $(dirname $0)/${PRG} $1 $2 $3 $4 $5"
EchoTee "  // ${VER}"
EchoTee ""

# Path to original raw data 
if [ -d "${RAW}/" ]
then
   EchoTee " OK: a directory exist where I guess raw data are stored." 
   EchoTee "      I guess images are in ${RAW}."    
   EchoTee ""
else
   EchoTee " "
   EchoTee " NO directory ${RAW}/ where I can find raw data. Can't run..." 
   exit 1
fi

function GetDate()
	{
	unset DIRNAME
	local DIRNAME=$1
	echo "${DIRNAME}" | cut -d _ -f6
	}

function GetDateEnvisat()
	{
	unset DIRNAME
	local DIRNAME=$1
	cd ${DIRNAME}
	ls *.N1 | cut -d _ -f3 | cut -c 7-14
	}
function GetDateERS()
	{
	unset DIRNAME
	local DIRNAME=$1
	cd ${DIRNAME}/SCENE1
	grep -aEo "[0-9]{17}" LEA_01.001 | head -1 | cut -c 1-8
	}

	
function ChangeInPlace()
	{
	unset ORIGINAL
	unset NEW
	unset FILE
	local ORIGINAL=$1
	local NEW=$2
	local FILE=$3
	if [ $# -lt 4 ]
		then
   			EchoTee "=> Change ${ORIGINAL}"	
			EchoTee "   with ${NEW}"
			EchoTee "   in  ${FILE} "
			EchoTee ""
			${PATHGNU}/gsed -i "s%${ORIGINAL}%${NEW}%" ${FILE}
   		else 
   			local OCCURENCE=$4	# If a 4th argument is provided it will change the ORIGINAL that appears on the OCCURENCEth position in the FILE 
   			EchoTee "=> Change ${ORIGINAL}"
			EchoTee "   with ${NEW}"
			EchoTee "   in  ${FILE} "
			EchoTee ""
			${PATHGNU}/gsed -i "s%${ORIGINAL}%${NEW}%${OCCURENCE}" ${FILE}
    fi
	}	
	
# Let's Go:
###########	
cd ${CSL}				

if [ ${SAT} == "S1" ] 						
then
		# Use bulk reader
		cd ${CSL}
		PARENTCSL="$(dirname "$CSL")"  # get the parent dir, one level up
		REGION=`basename ${PARENTCSL}`
		# Check if links in ${PARENTCSL} points toward files (must be in ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/)
		# if not, remove broken link
		EchoTee "Remove possible broken links"
		for LINKS in `ls -d *.csl 2> /dev/null`
			do
				find -L ${LINKS} -type l ! -exec test -e {} \; -exec rm {} \; # first part stays silent if link is ok (or is not a link but a file or dir); answer the name of the link if the link is broken. Second part removes link if broken 
		done

		if [ "${FAY}" == "ForceAllYears" ]
			then 
				EchoTee ""
				EchoTeeYellow "Read recent images"	
				if [ `ls -d ${RAW}/*.SAFE 2> /dev/null | wc -l` -le 0 ] ; then 
					EchoTee "No recent data."
					touch ${CSL}/S1DataReaderLog.txt
				else
					S1DataReader -p ${RAW} ${CSL} ${KMLS1} P=${INITPOL} 
					cp ${CSL}/S1DataReaderLog.txt ${CSL}/S1DataReaderLog_Recent.txt 
					EchoTee ""
					EchoTeeYellow "Read older images"
					# Read in ${RAW}_FORMER/${YYYY}
					if [ -d ${RAW}_FORMER ] 
						then	
							S1DataReader -p ${RAW}_FORMER ${CSL} ${KMLS1} P=${INITPOL}
							cp ${CSL}/S1DataReaderLog.txt ${CSL}/S1DataReaderLog_Former.txt
					fi
					cat ${CSL}/S1DataReaderLog_Recent.txt ${CSL}/S1DataReaderLog_Former.txt > ${CSL}/S1DataReaderLog.txt
					rm -f ${CSL}/S1DataReaderLog_Recent.txt ${CSL}/S1DataReaderLog_Former.txt
				fi
			else 
				EchoTeeYellow "Read only recent images"	
				if [ `ls -d ${RAW}/*.SAFE 2> /dev/null | wc -l` -le 0 ] ; then 
   					EchoTee "No recent data."
   					touch ${CSL}/S1DataReaderLog.txt
				else
					S1DataReader -p ${RAW} ${CSL} ${KMLS1}	P=${INITPOL} 
				fi						
		fi
		EchoTee ""
		EchoTee "All S1 img read; now moving images > 6 months in : "
		EchoTee "     ${RAW}_FORMER/_YYYY"
		EchoTee ""
		cd ${RAW}
		
		if [ `ls -d ${RAW}/*.SAFE 2> /dev/null | wc -l` -le 0 ] ; then 
					EchoTee "No recent data ; nothing to move."
			else
				for FILESAFE in `ls -d *.SAFE`
					do
						YEARFILE=`echo ${FILESAFE} | cut -c 18-21`
						MMFILE=`echo ${FILESAFE} | cut -c 22-23 | ${PATHGNU}/gsed 's/^0*//'`
						DATEFILE=`echo "${YEARFILE} + ( ${MMFILE} / 12 ) - 0.0001" | bc -l` # 0.0001 to avoid next year in december
						YRNOW=`date "+ %Y"`	
						MMNOW=`date "+ %-m"`					
						DATENOW=`echo "${YRNOW} + ( ${MMNOW} / 12 )" | bc -l`
						DATEHALFYRBFR=`echo "${DATENOW} - 0.5" | bc -l`
						TST=`echo "${DATEFILE} < ${DATEHALFYRBFR}" | bc -l`
						if [ ${TST} -eq 1 ]
							then
								mkdir -p ${RAW}_FORMER/_${YEARFILE}
								mv ${FILESAFE} ${RAW}_FORMER/_${YEARFILE}
						fi
				done
		fi
		
		cd ${CSL}
		echo 
		
		# sort Asc and Desc orbits
		EchoTee ""
		EchoTee "Now sorting S1 :"
		EchoTee "Because S1 mass reading copes with both Asc and Desc orbits and for each Orbit Track at the same time, I will sort them out here for you using links in corresponding dirs."
		EchoTeeRed "Do not remove image files from ${CSL} !!"
		EchoTee ""		
		for S1IMGPATH in ${CSL}/*.csl  # list actually the former links and the new dir if new images were read
			do
				S1IMG=`echo ${S1IMGPATH##*/}` 				# Trick to get only name without path
				S1TRK=`echo ${S1IMG} | cut -d _ -f 2` 		# Get the orbit nr
				S1MODE=`echo ${S1IMG} | cut -d _ -f 4 | cut -c 1` # Get the Asc or Desc mode
				mkdir -p ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop
				if [ ! -d ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG} ]
					then
							# There is no  ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG} DIR yet, hence it is a new img; move new img there
							mv ${S1IMG} ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/ 
							#and create a link
							ln -s ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG} ${CSL} 
					else 
						# Rebuild missing frames/bursts
						SIZEFRMAES=`ls ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG}/Data/Frame?.csl/Data/*.${INITPOL} | wc -c`
						
						if [ -d ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG}/Data ] && [ ${SIZEFRMAES} -eq 0 ]
							then 
								rm -Rf ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG}/Data/Frame*
								for FRAME in `find  ${CSL}/${S1IMG}/Data/* -name "Frame*"`
									do 
										mv ${FRAME} ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG}/Data/
								done
								rm -Rf ${S1IMG}
								ln -s ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG} ${CSL}
						fi
					
				fi  
				
		done
		echo 
# Do not test if there are files in ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/ without links in ${PARENTCSL}.
# Shouldn't be a problem because in such a case, without link in PARENTCSL, it dowload the image again. 

		# Stitch bursts and check size. Re-read if size (in bytes) of image with stitched bursts is not compliant with cols x rows x 8 
		# It will only stitch modes as expressed in a table that is expected here : 
		EchoTee ""
		EchoTee "Now stiches all bursts of S1 images "
		EchoTee "  and check if size is compliant with number or lines and columns. If not, re-stitch the image "

		EchoTee "Then check the size of all master images and store that info in NoCrop/List_Master_Sizes.txt. "
		EchoTee "  You may want to check it to ensure that no bursts are missing in some images. "
		EchoTee ""
		EchoTee "Then delete data that are in quarantained in SAR_CSL/S1/region/Quarantained. "
		EchoTee ""	
		EchoTee "Then list bursts for each image in files. "
		EchoTee ""	
		
		for TRACKS in `ls -d ${PARENTCSL}_* `  # all tracks without parent dir
			do 
				cd ${TRACKS}/NoCrop
				EchoTee ""	
				EchoTee "Check mode ${TRACKS}: "
				EchoTee "----------------------"	
				Check_All_S1_ImgReadSize.sh ${INITPOL}
				List_All_S1_ImgSize.sh
				if [ -d ${TRACKS}/Quarantained ] ; then 
					cd ${TRACKS}/Quarantained
					for IMGQUARANTAINED in `ls -d *.csl `
						do
						rm -Rf ${TRACKS}/NoCrop/${IMGQUARANTAINED}
					done
				fi
				List_S1_Frames_Swaths_Bursts.sh
		done

		EchoTee ""	
		cd ${CSL} 		
		# Clear all processes which include images for which Fast 24 frame was updated in RESAMPLED, SAR_MASSPROCESS
		# Because the S1Reader output a new line for each updated frame of the same image, let's uniq the log file
		cat ${CSL}/S1DataReaderLog.txt | uniq > ${CSL}/S1DataReaderLog_${RUNDATE}.txt

			if [ -s ${CSL}/S1DataReaderLog_${RUNDATE}.txt ]; then 
				EchoTee "List all processes to clean which include images for which Fast 24 frame was updated in RESAMPLED, SAR_MASSPROCESS"
				for IMGTOCLEAN in `cat ${CSL}/S1DataReaderLog_${RUNDATE}.txt`
					do
						DATEIMGTOCLEAN=`echo "${IMGTOCLEAN}" | cut -d _ -f3 `
						
						cd ${RESAMPLED}/S1
						EchoTee "${IMGTOCLEAN} was updated (Fast-24h frames were replaced by ArchNorm ones)"
						EchoTee "List all processing involving ${DATEIMGTOCLEAN} (i.e. ${IMGTOCLEAN}) from RESAMPLED"
						find ${REGION}* -name "*${DATEIMGTOCLEAN}*" -a -prune >> ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}.txt

						cd ${SAR_MASSPROCESS}/S1/
						EchoTee "List all processing involving ${DATEIMGTOCLEAN} (i.e. ${IMGTOCLEAN}) from SAR_MASSPROCESS"
						find ${REGION}* -name "*${DATEIMGTOCLEAN}*" -a -prune  >> ${CSL}/FAST24_CleanMASSPROCESS_${RUNDATE}.txt 
				done
				echo 

				# Move files - this could be deleted later I guess 		
				EchoTee "Move (may prefer delete ?) all processes in RESAMPLED, SAR_MASSPROCESS which include images for which Fast 24 frame were updated."
				EchoTee "   Move them in ${RESAMPLED}/S1_CLN/CLEANED_FAST24/"
				EchoTee "            and ${SAR_MASSPROCESS}/S1_CLN/CLEANED_FAST24/"

				for FILESTOCLEAN in `cat  ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}.txt`
				do
					PATHFILESTOCLEAN=$(dirname "${FILESTOCLEAN}")
					mkdir -p ${RESAMPLED}/S1_CLN/CLEANED_FAST24/${PATHFILESTOCLEAN}
					mv -f ${RESAMPLED}/S1/${FILESTOCLEAN} ${RESAMPLED}/S1_CLN/CLEANED_FAST24/${FILESTOCLEAN}			
				done

				for FILESTOCLEAN in `cat  ${CSL}/FAST24_CleanMASSPROCESS_${RUNDATE}.txt`
				do
					PATHFILESTOCLEAN=$(dirname "${FILESTOCLEAN}")
					mkdir -p ${SAR_MASSPROCESS}/S1_CLN/CLEANED_FAST24/${PATHFILESTOCLEAN}
					mv -f ${SAR_MASSPROCESS}/S1/${FILESTOCLEAN} ${SAR_MASSPROCESS}/S1_CLN/CLEANED_FAST24/${FILESTOCLEAN} 
				done
			else 
				EchoTee " No Fast-24h frames replaced by ArchNorm ones."
			fi
		echo 
	
		EchoTee "Run the check of S1 orbits"
		EchoTee "--------------------------"
		echo
			S1OrbitUpdater ${CSL} | tee  ${CSL}/UpdatabelOrbits_${RUNDATE}.txt
			# Test if orbits are missing :
			cat ${CSL}/UpdatabelOrbits_${RUNDATE}.txt | ${PATHGNU}/grep "No precise orbit file found in local data base for this image" -B 1 | ${PATHGNU}/grep -v "No precise orbit file found in local data base for this image" | cut -d _ -f3 >  ${CSL}/NoPreciseOrbitsFoundFor_${RUNDATE}.txt
			rm  ${CSL}/UpdatabelOrbits_${RUNDATE}.txt
			# One should check here if some images are less than 1 months old. If yes, there must be a problem with orbits download
			echo
			 EchoTee "Check if files that could have been updated and were not are older than 30 days."
			 EchoTee " This would mean that there is a problem with orbits " 
			# get the list of YYYYmm of missing orbits from ${CSL}/NoPreciseOrbitsFoundFor_${RUNDATE}.txt
			if [ -s ${CSL}/NoPreciseOrbitsFoundFor_${RUNDATE}.txt ] ; then
				cat ${CSL}/NoPreciseOrbitsFoundFor_${RUNDATE}.txt | ${PATHGNU}/gawk -F '/' '{print $NF}' | cut -c 1-6 | sort | uniq > ${CSL}/OrbitsToDownload_${RUNDATE}.txt
				
				# If at least one orbit to download exists, then try to re-download the whole orbits using CSL function 
				if [ -s ${CSL}/OrbitsToDownload_${RUNDATE}.txt ] ; then
					updateS1PrecisesOrbits
				fi
# Could also try to download only the orbits from the month of the img that is missing the orbit (but need first to fix Gille's script) 				
#				 for ORBTODWNLOAD in `cat ${CSL}/OrbitsToDownload_${RUNDATE}.txt`
# 					do
# 						# Try to download orbits again
# 						sentinel1_orbit-downloader.sh ${ORBTODWNLOAD}
# 				done
				for DATETOCHECK in `cat ${CSL}/NoPreciseOrbitsFoundFor_${RUNDATE}.txt`
					do
						TODAY=`date +%s`  							# Today as seconds since 1970-01-01
						DOITOCHECK=`date -d "${DATETOCHECK}" +%s`	# Date to check as seconds since 1970-01-01 
						DIFFSEC=`echo "( ${TODAY} - ${DOITOCHECK} )" | bc `
						DIFFDAYS=`echo "( ${DIFFSEC} / 86400 )" | bc `
						echo "Date diff : ${TODAY} - ${DOITOCHECK} = ${DIFFSEC}" 
						if [ ${DIFFSEC} -le 2678400 ] # if diff is less than 31 days in sec : ok 
							then 
								EchoTeeYellow " Image without updated orbit (${DATETOCHECK}) is less than 31 days old. Might not be a problem "
							else
								EchoTeeRed " Image without updated orbit (${DATETOCHECK}) is older than 31 days. "
								EchoTeeRed " ${DIFFDAYS} days old without updated orbits is abnormal. Tried to get orbits and relaunch."
								SpeakOut "Image ${DATETOCHECK} without updated orbit is ${DIFFDAYS} days old, that is older than 31 days. Tried to get orbits and relaunch."
								# Flag to relaunch Read_All_Img
								REPLAY=ReplayYes
						fi  
				done
			fi
		echo
		# Clear all processes which include images for which orbit was updated in RESAMPLED, SAR_MASSPROCESS
			cp ${CSL}/S1OrbitUpdaterLog.txt ${CSL}/S1OrbitUpdaterLog_${RUNDATE}.txt

			if [ -s ${CSL}/S1OrbitUpdaterLog_${RUNDATE}.txt ]; then 
				EchoTee "List all processes to clean which include images for which orbit was updated in RESAMPLED, SAR_MASSPROCESS"
				for IMGTOCLEAN in `cat ${CSL}/S1OrbitUpdaterLog_${RUNDATE}.txt`
					do
 						DATEIMGTOCLEAN=`echo "${IMGTOCLEAN}" | cut -d _ -f3 `

 						cd ${RESAMPLED}/S1
						EchoTee "Orbit of ${IMGTOCLEAN} was updated. "
						EchoTee "List all processing involving ${DATEIMGTOCLEAN} (i.e. ${IMGTOCLEAN}) from RESAMPLED/S1/${REGION}*"
						find ${REGION}* -name "*${DATEIMGTOCLEAN}*" -a -prune >> ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}_tmp.txt 
						cd ${SAR_MASSPROCESS}/S1
						EchoTee "List all processing involving ${DATEIMGTOCLEAN} (i.e. ${IMGTOCLEAN}) from SAR_MASSPROCESS/S1/${REGION}*"
						find ${REGION}* -name "*${DATEIMGTOCLEAN}*" -a -prune >> ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}_tmp.txt 
				done
				echo 
				
				sort ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}_tmp.txt | uniq > ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}.txt
				sort ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}_tmp.txt | uniq > ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}.txt
				
				rm -f ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}_tmp.txt ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}_tmp.txt
				
				# Move files - this could be deleted later I guess; in such a case you may prefer delete from the find cmd line above
# If you do not want to remove updated images from RESAMPLED and/or SAR_MASSPROCESS, uncomment the echo lines and comment the mv lines below 
				EchoTee "Move (may prefer delete ?) all processes in RESAMPLED, SAR_MASSPROCESS which include images for which orbits were updated"
				EchoTee "   Move them in ${RESAMPLED}/S1_CLN/CLEANED_ORB/"
				EchoTee "            and ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/"

				for FILESTOCLEAN in `cat  ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}.txt`
				do
					PATHFILESTOCLEAN=$(dirname "${FILESTOCLEAN}")
					mkdir -p ${RESAMPLED}/S1_CLN/CLEANED_ORB/${PATHFILESTOCLEAN}
					# echo "Image ${FILESTOCLEAN} updated. Should move ${RESAMPLED}/S1/${FILESTOCLEAN} to ${RESAMPLED}/S1_CLN/CLEANED_ORB/${PARENTCSL}_${S1MODE}_${S1TRK}/"
					mv -f ${RESAMPLED}/S1/${FILESTOCLEAN} ${RESAMPLED}/S1_CLN/CLEANED_ORB/${FILESTOCLEAN}
				done

				for FILESTOCLEAN in `cat  ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}.txt`
				do
					PATHFILESTOCLEAN=$(dirname "${FILESTOCLEAN}")
					mkdir -p ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${PATHFILESTOCLEAN}
					# echo "Image ${FILESTOCLEAN} updated. Should move  ${SAR_MASSPROCESS}/S1/${FILESTOCLEAN} to ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${PARENTCSL}_${S1MODE}_${S1TRK}/"
					mv -f ${SAR_MASSPROCESS}/S1/${FILESTOCLEAN} ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${FILESTOCLEAN}
				done
				rm -f ${CSL}/S1OrbitUpdaterLog.txt ${CSL}/S1DataReaderLog.txt
			else 
				EchoTee " No orbits updated."
			fi
		
	
else 
		# Do not use Bulk Readr; compare instead with existing images and read only teh new ones
		# Read existing raw archives
		ls ${RAW}* | ${PATHGNU}/grep -v ".txt" | ${PATHGNU}/grep -v ".png" | ${PATHGNU}/grep -v ".tmp" | ${PATHGNU}/grep -v ".dat"  | ${PATHGNU}/grep -v ".gz" > List_raw.txt

		# read images already in csl format
		case ${SAT} in
			"TDX") 
				# suppose that BRX is ok if BTX is present
				ls ${CSL}/BTX* | ${PATHGNU}/grep -v ".txt" > List_csl.txt;;
			"ENVISAT") 
				# Need the dir and date for comarison
				ls ${CSL} | ${PATHGNU}/grep -v ".txt" > List_csl_dates.txt
				echo "Ignore error msg below vvvvvvvv (ls: cannot access '*.N1': No such file or directory)"
				for DATECSL in `cat -s List_csl_dates.txt`
					do	
						DATE=`echo ${DATECSL} | cut -d . -f 1`
												ls -R ${RAW} *.N1 | ${PATHGNU}/grep ${DATE} | cut -d _ -f7 >> List_csl.txt
					done
				echo "Ignore error msg above ^^^^^^"
					;;
			*) 	
				#ls ${CSL}/* | ${PATHGNU}/grep -v ".txt" > List_csl.txt
				ls ${CSL} | ${PATHGNU}/grep -v ".txt" > List_csl.txt
				;;
		esac

		# Search for only the new ones to be processed:
		#    In List_csl.txt names are date.csl, 
		#    while in List_raw.txt names are a complex dir name that includes date somewhere
		cp -f List_raw.txt Img_To_Read.txt
		for LINE in `cat -s List_csl.txt`
			do	
				DATE=`echo ${LINE} | cut -d . -f1`
				grep -v ${DATE} Img_To_Read.txt > Img_To_Read_tmp.txt
				cp -f Img_To_Read_tmp.txt Img_To_Read.txt
			done
		rm -f Img_To_Read_tmp.txt

		EchoTee ""
		EchoTee "Reading..."
		for IMGDIR in `cat -s Img_To_Read.txt`
		do	
				case ${SAT} in
					"RADARSAT") 
								IMG=`GetDate ${IMGDIR}`
								RSAT2DAtaReader ${CSL}/Read_${IMG}.txt -create
								ChangeInPlace PathToRSAT2Directory ${RAW}/${IMGDIR}  ${CSL}/Read_${IMG}.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}.txt
								RSAT2DAtaReader ${CSL}/Read_${IMG}.txt	
								EchoTee "Image ${IMG} red"
								;;
					"CSK") 
								IMG=`GetDate ${IMGDIR}`
								CSKDataReader ${CSL}/Read_${IMG}.txt -create
								ChangeInPlace PathToHDF5File ${RAW}/${IMGDIR}/*.h5  ${CSL}/Read_${IMG}.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}.txt
								CSKDataReader ${CSL}/Read_${IMG}.txt
								TRKHEADING=`updateParameterFile ${CSL}/${IMG}.csl/Info/SLCImageInfo.txt Heading | cut -d c -f1`
								TRKHEADING=${TRKHEADING}c
								SCENELOCATION=`updateParameterFile ${CSL}/${IMG}.csl/Info/SLCImageInfo.txt "Scene location"`
								EchoTee " Track of ${IMG} : ${TRKHEADING}" 
								EchoTee "Image ${IMG} red"
								EchoTee "Image ${IMG} : ${TRKHEADING}  : ${SCENELOCATION}" >> List_Files_Trk_Location_${RUNDATE}.txt
								;;
					"TSX") 
								IMG=`GetDate ${IMGDIR}`
								if
									test -d ${RAW}/${IMGDIR}/TSX-1.SAR.L1B
									then 
										TSXDIR=`cd ${RAW}/${IMGDIR}/TSX-1.SAR.L1B/; ls -d $PWD/T*/`	
										TSXDIR=`echo ${TSXDIR} | ${PATHGNU}/gsed -e 's/\/$//g'`    # need to remove ending slash
											 # Actual path to the data. 
											 # NB: This assumes there is only one subdir that starts with T in the Terrasar data dir
									else 
										TSXDIR=`cd ${RAW}/${IMGDIR}/; ls -d $PWD/T*/`	
										TSXDIR=`echo ${TSXDIR} | ${PATHGNU}/gsed -e 's/\/$//g'`    # need to remove ending slash
											 # Actual path to the data. 
											 # NB: This assumes there is only one subdir that starts with T in the Terrasar data dir
								fi

								TSXDataReader ${CSL}/Read_${IMG}.txt -create
								ChangeInPlace PathToTSXDir ${TSXDIR} ${CSL}/Read_${IMG}.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}.txt
								TSXDataReader ${CSL}/Read_${IMG}.txt
								EchoTee "Image ${IMG} red"
								;;
					"TSXfromTDX") 
								IMG=`GetDate ${IMGDIR}`
								if
									test -d ${RAW}/${IMGDIR}/TSX-1.SAR.L1B
									then 
										ls -d ${RAW}/${IMGDIR}/TSX-1.SAR.L1B/T*/ > tmp.txt	
									else 
										ls -d ${RAW}/${IMGDIR}/T*/ > tmp.txt	
								fi
								TSXDIR_BTX=`grep BTX tmp.txt | ${PATHGNU}/gsed -e 's/\/$//g'`    # need to remove ending slash
						
								# Read first (Transmit) image
								TSXDataReader ${CSL}/Read_${IMG}_BTX.txt -create
								ChangeInPlace "NO        " "YES      " ${CSL}/Read_${IMG}_BTX.txt
								ChangeInPlace PathToTSXDir ${TSXDIR_BTX} ${CSL}/Read_${IMG}_BTX.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}_BTX.txt
								# if 
		# 							test ! -d ${CSL}/BTX/
		# 							then 
		# 								mkdir ${CSL}/BTX/
		# 						fi
								TSXDataReader ${CSL}/Read_${IMG}_BTX.txt
								EchoTee "Frist Image ${IMG}_BTX red"
								;;
						"TDX")
								IMG=`GetDate ${IMGDIR}`
								if
									test -d ${RAW}/${IMGDIR}/TSX-1.SAR.L1B
									then 
										ls -d ${RAW}/${IMGDIR}/TSX-1.SAR.L1B/T*/ > tmp.txt	
									else 
										ls -d ${RAW}/${IMGDIR}/T*/ > tmp.txt	
								fi
								TSXDIR_BTX=`grep BTX tmp.txt | ${PATHGNU}/gsed -e 's/\/$//g'`    # need to remove ending slash
								TSXDIR_BRX=`grep BRX tmp.txt | ${PATHGNU}/gsed -e 's/\/$//g'`    # need to remove ending slash
											 # Actual path to the data. 
											 # NB: This assumes there is only two subdir that starts with T in the Terrasar data dir
								# Read second (recieve) image
								TSXDataReader ${CSL}/Read_${IMG}_BRX.txt -create
								ChangeInPlace "NO        " "YES      " ${CSL}/Read_${IMG}_BRX.txt
								ChangeInPlace PathToTSXDir ${TSXDIR_BRX} ${CSL}/Read_${IMG}_BRX.txt
								ChangeInPlace outputFilePath ${CSL}/BRX/${IMG} ${CSL}/Read_${IMG}_BRX.txt
								if 
									test ! -d ${CSL}/BRX/
									then 
										mkdir ${CSL}/BRX/
								fi
								TSXDataReader ${CSL}/Read_${IMG}_BRX.txt
								EchoTee "Frist Image ${IMG}_BRX red"
								;;
					"ENVISAT") 
								IMG=`GetDateEnvisat ${RAW}/${IMGDIR}`
								EnviSATDataReader ${CSL}/Read_${IMG}.txt -create
								EchoTee "${RAW}/${IMGDIR}/*.N1"
								ChangeInPlace PathToEnviSATDataFile ${RAW}/${IMGDIR}/*.N1 ${CSL}/Read_${IMG}.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}.txt
								ChangeInPlace DORIS_DirectoryPath ${ENVORB} ${CSL}/Read_${IMG}.txt
								EnviSATDataReader ${CSL}/Read_${IMG}.txt
								EchoTee "Image ${IMG} red"
								;;
					"ERS") 
								IMG=`GetDateERS ${RAW}/${IMGDIR}`
								ERSDataReader ${CSL}/Read_${IMG}.txt -create
								#EchoTee "${RAW}/${IMGDIR}/*.N1"
								ChangeInPlace PathToDirectory ${RAW}/${IMGDIR}/SCENE1 ${CSL}/Read_${IMG}.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}.txt
								#ChangeInPlace DORIS_DirectoryPath ${ENVORB} ${CSL}/Read_${IMG}.txt
								ERSDataReader ${CSL}/Read_${IMG}.txt
								EchoTee "Image ${IMG} red"
								;;
					#"S1") 		EchoTee "Using here the native bulk reader for S1"
					#			;;				
				esac	
		done
fi

if [ "${REPLAY}" == "ReplayYes" ] 
	then 
		EchoTeeRed "Seems that you encountered problems with missing orbits. Try to relaunch current script"
		# First one need to neutralize the replay possibility to avoid infinite loop
		${PATHGNU}/gsed "s/REPLAY=ReplayYes/REPLAY=ReplayNo/" $(dirname $0)/${PRG} >  TMP_${PRG}
		 chmod +x TMP_${PRG}
		 ./TMP_${PRG} ${RAW} ${CSL} ${SAT} ${KMLS1} ${FAY} 
		 rm TMP_${PRG}
		# Flag to avoid infinite loop in case of unsolvable problme
		EchoTeeRed "Hope that re-reading the images after new orbits download(s) helped..."

fi
echo
EchoTee "------------------------------------"
EchoTee "All img read"
EchoTee "------------------------------------"

