#!/bin/bash
# -----------------------------------------------------------------------------------------
# This script is aiming at preparing the MSBAS data sets and computing baselines table
#   Data must be already in csl format. 
# Can force using a given super master if one do not want to compute a new one while just 
#   adding an image to a large existing data base.
# Will add manual pairs if an appropriate file is provided (see New in V2.0 below)
#      
#
# Parameters : - path to dir with the csl dataset prepared for MSBAS (lns creaetd by lns_All_img.sh)
#              - max Bp
#              - Max Btemp
#              - Min Bp - obsolate since V3.0
#              - Min Btemp - obsolate since V3.0
#              - Date of SuperMaster       
#
# Dependencies:	- gnu sed and awk for more compatibility.
#    			- functions "say" for Mac or "espeak" for Linux, but might not be mandatory
#				- CIS tools: baselinePlot (D. Derauw from MasTer Engine V20220510)
# 				Obsolate since V3.0
#    			- script build_bperp_file.sh (which needs plotspan.sh )
#				- CIS tools: initiateBaselinesComputation... (L. Libert) 
#
# New in Distro V 1.0:	- Based on developpement version 3.3 and Beta V1.2
# New in Distro V 2.0:	- If a file named table_BpMin_BpMax_Btmin_Btmax_AdditionalPairs.txt exists 
#						  in SETi dir with a list of pairs in the form  
#						  "DateMaster	   DateSlave	   Bp	   Bt", without header, 
#						  it will paste these pairs to the table_BpMin_BpMax_Btmin_Btmax.txt.
#						  This is usefull when some pairs above Bp and Bt must be kept in the  
#						  beseline ployt to ensure trianlgle closure or time continuity
# New in Distro V 2.1:	- Remove header of table with additional pairs if any
# New in Distro V 2.2:	- if do not want to recomputer a super master, ensure that a SM date was provied. 
# New in Distro V 2.3:	- correction of test for nr of parameters (thanks to A. Dille)
# New in Distro V 3.0:	- use tool developped by DD instead of those by L. Libert. 
#						- make the baseline plot using baselinePlot instead of build_bperp_file.sh and plot_span.sh
# New in Distro V 3.1:	- Create a initBaseline.txt file as needed by the computeBaselinesPlotFile to be allowed to keep some old tools  
# New in Distro V 3.2:	- Now actually work with old and new version of Master Engine, that is with D Derauw or L Libert tools for baseline plotting.
#						  New is faster and more accurate, Old allows comuting tables with minimum Bt and Bp other than 0 
# New in Distro V 3.3:	- typo on searching for baselinePlot2 instead of baselinePlot and wrong call of second if at double test
# New in Distro V 3.4:	- prepare bperp_file.txt and SM_Approx_baselines.txt also when using new tools for baseline plots for further plots if needed
# New in Distro V 3.5:	- Big bug correction: some files where not replaced but data were added making them to grow infinitely and slowing up the process... 
# New in Distro V 3.6:	- ignore empty lines in pairs file
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/07 - could make better with more functions... when time.
# -----------------------------------------------------------------------------------------
PRG=`basename "$0"`
VER="Distro V3.6 MasTer script utilities"
AUT="Nicolas d'Oreye, (c)2016-2019, Last modified on Oct 04, 2022"
echo " "
echo "${PRG} ${VER}, ${AUT}"
echo " "

if [ $# -lt 3 ] ; then echo “Usage $0 path_to_SETi MaxBp MaxBt [DateSuperMaster]”; exit; fi

if [ $# -eq 3 ] || [ $# -eq 4 ] # New tools only require 3 or 4 param
	then 
		echo "Try to process with MasTer Engine tools from May 2022; Check if required files are available"
		SET=$1					# path to dir with the csl dataset prepared for MSBAS
		BP=$2					# Max Bperp
		BT=$3					# Max Btemp
		SMFORCED=$4				# SM date
		if [ `baselinePlot | wc -l` -eq 0 ] 
			then 
				echo "MasTer Engine tools from May 2022 does not exist yet"
				echo "Set Min Bp and Bt to zero and use old tools." 
				VERTOOL="OLD"
		fi
		BPMIN=0				# Min Bperp
		BTMIN=0				# Min Btemp
		VERTOOL="NEW"
	else
		if [ $# -eq 5 ] || [ $# -eq 6 ]  # Old tools  require 5 or 6 param
			then 
				if [ `baselinePlot | wc -l` -eq 0 ] 
					then 
						echo "Process with MasTer Engine tools before May 2022"	
						SET=$1					# path to dir with the csl dataset prepared for MSBAS
						BP=$2					# Max Bperp
						BT=$3					# Max Btemp
						BPMIN=$4				# Min Bperp
						BTMIN=$5				# Min Btemp
						SMFORCED=$6				# SM date
						VERTOOL="OLD"					
					else
						echo "You have MasTer Engine tools from May 2022 but entered parameters as for old tools"
						if [ "$4" -eq "0" ] && [ "$5" -eq "0" ] 
							then
								echo "But you use Min BP or BT == zero. Hence you can to use new tools." 
								SET=$1					# path to dir with the csl dataset prepared for MSBAS
								BP=$2					# Max Bperp
								BT=$3					# Max Btemp
								BPMIN=0				# Min Bperp
								BTMIN=0				# Min Btemp
								SMFORCED=$6				# SM date

								VERTOOL="NEW"
							else
								echo "But you asked for Min BP or BT other than zero. Hence you indeed need to use old tools." 
								SET=$1					# path to dir with the csl dataset prepared for MSBAS
								BP=$2					# Max Bperp
								BT=$3					# Max Btemp
								BPMIN=$4				# Min Bperp
								BTMIN=$5				# Min Btemp
								SMFORCED=$6				# SM date

								VERTOOL="OLD"
						fi
				fi
		fi
 fi


cd ${SET}

if [ "${VERTOOL}" == "OLD" ] ; then rm -f approximateBaselinesTable.txt initBaselines.txt ; fi

function SpeakOut()
	{
	unset MESSAGE 
	local MESSAGE
	MESSAGE=$1
	# Check OS
	OS=`uname -a | cut -d " " -f 1 `

	case ${OS} in 
		"Linux") 
			espeak "${MESSAGE}" ;;
		"Darwin")
			say "${MESSAGE}" 	;;
		*)
			echo "${MESSAGE}" 	;;
	esac			
	}

if [ "${VERTOOL}" == "OLD" ] 
	then
		timeSorting ${SET}
		initiateBaselinesComputation ${SET}
		approximateBaselines ${SET}/setParametersFile.txt
		
		updateParameterFile ${SET}/setParametersFile.txt "Minimum baseline [m]" ${BPMIN}
		updateParameterFile ${SET}/setParametersFile.txt "Maximum baseline [m]" ${BP}
		updateParameterFile ${SET}/setParametersFile.txt "Minimum temporal delay [days]" ${BTMIN}
		updateParameterFile ${SET}/setParametersFile.txt "Maximum temporal delay [days]" ${BT}
		
		updateParameterFile ${SET}/setParametersFile.txt "Path to triangle table containing baseline and delay values" ${SET}/approximateBaselinesTable.txt
		
		selectInterferometricPairs ${SET}/setParametersFile.txt
fi

# ask if one wants to re-compute a SM. If not it will keep the one that is already 
#                 in the setParametersFile.txt. Use this option ONLY when it is about adding new data to an existing dataset

SpeakOut "Do you want to search for a new Super Master?" 
while true; do
    read -p "Do you want to search for a new Super Master? (say no only when it is about adding new data to an existing dataset): "  yn
    case $yn in
        [Yy]* ) 
			if [ "${VERTOOL}" == "OLD" ] 
				then
					globalMaster ${SET}/approximateBaselinesTable.txt 
		         	# Get the supermaster
		 			SM=`grep "Path to global master" ${SET}/setParametersFile.txt | cut -d* -f1 | ${PATHGNU}/gsed 's/\t//g' | ${PATHGNU}/gsed 's/.$//' | ${PATHGNU}/gawk -F '/' '{print $NF}' | cut -d . -f 1`
		 			echo "New Super Master is  ${SM}."
				else
					baselinePlot ${SET} ${SET} BpMax=${BP} dTMax=${BT}  # second call of ${SET} is to output results in current dir
					SM=`grep "Identified Super Master" ${SET}/allPairsListing.txt | cut -d ":" -f2 | ${PATHGNU}/gsed 's/\t//g' | ${PATHGNU}/gsed 's/ //g'`
 					echo "BaselinePlot computed. New Super Master is  ${SM}."
 			fi
        	break ;;
        [Nn]* ) 
 			if [ "${VERTOOL}" == "OLD" ] 
				then
					if [ $# -lt 6 ] ; then echo “Usage $0 path_to_SETi MaxBp MaxBt MinBp MinBt DateSuperMaster, PLEASE PROVIDE A SUPER MASTER”; exit; fi
 
					echo "Use the Super Master set as last parameter in the current run, that is  ${SMFORCED}"
					echo "Let's check what is in setParametersFile.txt :"
					grep "Path to global master" ${SET}/setParametersFile.txt
					echo ""
					if [ -z ${SMFORCED} ]
						then # no FORMCED SM provided; will take it from existing setParametersFile.txt
							echo "No SuperMaster provided in the command line; shall take it from the setParametersFile.txt. Hope it is the good one."
							SM=`grep "Path to global master" ${SET}/setParametersFile.txt | cut -d* -f1 | ${PATHGNU}/gsed 's/\t//g' | ${PATHGNU}/gsed 's/.$//' | ${PATHGNU}/gawk -F '/' '{print $NF}' | cut -d . -f 1`
						else 
							echo "Shall take the Super Master provided in the command line"
							SM=${SMFORCED}
					fi
 
 				else
       				if [ $# -lt 4 ] ; then echo “Usage $0 path_to_SETi MaxBp MaxBt DateSuperMaster, PLEASE PROVIDE A SUPER MASTER”; exit; fi

					if [ -s ${SET}/allPairsListing.txt ] 
						then 
							echo "Use the Super Master set as last parameter in the current run, that is  -${SMFORCED}-"
							echo "Let's check what is in ${SET}/allPairsListing.txt :"
							SM=`grep "Identified Super Master" ${SET}/allPairsListing.txt | head -1 | cut -d ":" -f2 | ${PATHGNU}/gsed 's/\t//g' | ${PATHGNU}/gsed 's/ //g'`
							echo "Super Master is -${SM}-."
							echo ""
					
							baselinePlot ${SET} ${SET} BpMax=${BP} dTMax=${BT}  # second call of ${SET} is to output results in current dir
					
							if [ "${SMFORCED}" != "${SM}" ]
								then 
									echo "Warning: you asked for keeping the SuperMaster but the existing SM (${SM}) does not fit with the provided one (${SMFORCED})..."
									echo "Will use the one provided. Please check"
									# change SM in files allPairsListing.txt, selectedPairsListing_BpMax=400_BTMax=400.txt (wich is linked to selectedPairsListing.txt) and baselinePlot.gnuplot
									${PATHGNU}/gsed -i "s/Identified Super Master: ${SM}/Identified Super Master: ${SMFORCED}/" ${SET}/allPairsListing.txt
									${PATHGNU}/gsed -i "s/Identified Super Master: ${SM}/Identified Super Master: ${SMFORCED}/" ${SET}/selectedPairsListing_BpMax=${BP}_BTMax=${BT}.txt
									${PATHGNU}/gsed -i "s/${SM}/${SMFORCED}/" ${SET}/baselinePlot.gnuplot
									# Redo the plots       					
									${PATHGNU}/gnuplot baselinePlot.gnuplot
							fi
						else
							echo "Super Master not computed yet. Compute it again and force to ${SMFORCED}."
							baselinePlot ${SET} ${SET} BpMax=${BP} dTMax=${BT}  # second call of ${SET} is to output results in current dir
							SM=`grep "Identified Super Master" ${SET}/allPairsListing.txt  | head -1 | cut -d ":" -f2 | ${PATHGNU}/gsed 's/\t//g' | ${PATHGNU}/gsed 's/ //g'`
							echo "New Super Master is  ${SM} though will be forced to ${SMFORCED}"			
							# change SM in files allPairsListing.txt, selectedPairsListing_BpMax=400_BTMax=400.txt (wich is linked to selectedPairsListing.txt) and baselinePlot.gnuplot
							${PATHGNU}/gsed -i "s/Identified Super Master: ${SM}/Identified Super Master: ${SMFORCED}/" ${SET}/allPairsListing.txt
							${PATHGNU}/gsed -i "s/Identified Super Master: ${SM}/Identified Super Master: ${SMFORCED}/" ${SET}/selectedPairsListing_BpMax=${BP}_BTMax=${BT}.txt
							${PATHGNU}/gsed -i "s/${SM}/${SMFORCED}/" ${SET}/baselinePlot.gnuplot
							# Redo the plots       					
							${PATHGNU}/gnuplot baselinePlot.gnuplot
					fi
			fi
			
			break ;;
        * ) echo "Please answer yes or no.";;
    esac
done


if [ "${VERTOOL}" == "OLD" ] 
	then
		# if a file named table_BpMin_BpMax_Btmin_Btmax_AdditionalPairs.txt exists, 
		# add these pairs to the table 
		if [ -s ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt ] 
			then
				# remove header if any from additional pairs list
				if [ `grep "Master" ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt | wc -c` -gt 0 ] 
					then 
						tail -n +3 ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt > ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs_tmp.txt
						mv -f ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs_tmp.txt ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt
				fi 
				# remove header from main table
				tail -n +3 table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt > table_${BPMIN}_${BP}_${BTMIN}_${BT}_tmp.txt
		
				cat table_${BPMIN}_${BP}_${BTMIN}_${BT}_tmp.txt table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt > table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
				#ensure that there is no duplicate
				sort table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt | uniq > table_${BPMIN}_${BP}_${BTMIN}_${BT}_tmp.txt
				# add header
		
				echo "  Master	   Slave	 Bperp	 Delay" > table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
				echo "" >> table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
				cat table_${BPMIN}_${BP}_${BTMIN}_${BT}_tmp.txt >> table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
				rm table_${BPMIN}_${BP}_${BTMIN}_${BT}_tmp.txt
		fi

		# Prepare bperp_file.txt for plot and plot it.
		build_bperp_file.sh  ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt ${SM}
		# open  ${SET}/span.jpg

		# Rename bperp_file.txt for further use
		#echo " If run script on Windows hp server, ignore following errors dues to permissions prblms"
		#echo  "$(tput setaf 1)$(tput setab 7) If run script on Windows hp server, ignore following errors dues to permissions prblms $(tput sgr 0)"	
		mv bperp_file.txt bperp_file_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
		#mv span.txt span_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
		#mv span1.txt span1_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
	else
		# if a file named table_BpMin_BpMax_Btmin_Btmax_AdditionalPairs.txt exists, 
		# add these pairs to the table 
		if [ -s ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt ] 
			then
				# remove header if any from additional pairs list
				if [ `${PATHGNU}/grep "Master" ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt | wc -c` -gt 0 ] 
					then 
						tail -n +3 ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt > ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs_tmp.txt
						mv -f ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs_tmp.txt ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt
				fi 
				# Keep original table for debug
				cp table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt table_${BPMIN}_${BP}_${BTMIN}_${BT}_BEFORE_ADDING_PAIRS.txt
		
				# remove header from main table
				tail -n +3 table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt > table_${BPMIN}_${BP}_${BTMIN}_${BT}_tmp.txt
		
				cat table_${BPMIN}_${BP}_${BTMIN}_${BT}_tmp.txt table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt > table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
				#ensure that there is no duplicate
				sort table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt | uniq > table_${BPMIN}_${BP}_${BTMIN}_${BT}_tmp.txt
				# add header
		
				echo "  Master	   Slave	 Bperp	 Delay" > table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
				echo "" >> table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
				cat table_${BPMIN}_${BP}_${BTMIN}_${BT}_tmp.txt >> table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
				rm table_${BPMIN}_${BP}_${BTMIN}_${BT}_tmp.txt
		
				## NEED ALSO TO UPDATE THE selectedAcquisitionsSpatialRepartition_BpMax=${BP}_BTMax=${BT}.txt and selectedPairsListing_BpMax=${BP}_BTMax=${BT}.txt FOR PLOTTING
				#chech that all images listed in table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt has an entry in selectedAcquisitionsSpatialRepartition_BpMax=${BP}_BTMax=${BT}.txt. If not, get it from acquisitionsRepartition.txt
				# save it with new name for not mixing up files and plots
				cp -f selectedAcquisitionsSpatialRepartition_BpMax=${BP}_BTMax=${BT}.txt selectedAcquisitionsSpatialRepartition_BpMax=${BP}_BTMax=${BT}_ADD_PAIRS.txt
				# get all dates sorted and uniq (8 characters long string):
				${PATHGNU}/grep -o '\<.\{8\}\>' table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt | sort | uniq > ListNewDates.txt
				while read -r NEWDATE
					do 
						# if NEWDATE is NOT in selectedAcquisitionsSpatialRepartition_BpMax=${BP}_BTMax=${BT}_ADD_PAIRS.txt, add it
						if ! ${PATHGNU}/grep -q ${NEWDATE} "selectedAcquisitionsSpatialRepartition_BpMax=${BP}_BTMax=${BT}_ADD_PAIRS.txt"
							then
								echo "${NEWDATE} not yet in selectedAcquisitionsSpatialRepartition_BpMax=${BP}_BTMax=${BT}_ADD_PAIRS.txt; add it"
								${PATHGNU}/grep ${NEWDATE} acquisitionsRepartition.txt >> selectedAcquisitionsSpatialRepartition_BpMax=${BP}_BTMax=${BT}_ADD_PAIRS.txt
						fi
				done < ListNewDates.txt 
		
				## update the selectedPairsListing_BpMax=${BP}_BTMax=${BT}.txt
				# save it with new name for not mixing up files and plots
				cp -f selectedPairsListing_BpMax=${BP}_BTMax=${BT}.txt selectedPairsListing_BpMax=${BP}_BTMax=${BT}_ADD_PAIRS.txt
				while read -r NEWMAS NEWSLAV DUMMY1 DUMMY2
					do 
						${PATHGNU}/grep ${NEWMAS} allPairsListing.txt | ${PATHGNU}/grep ${NEWSLAV}  >> selectedPairsListing_BpMax=${BP}_BTMax=${BT}_ADD_PAIRS.txt
				done < ${SET}/table_${BPMIN}_${BP}_${BTMIN}_${BT}_AdditionalPairs.txt 
		
				#replot the table with additional pairs
				cp -f ${SET}/baselinePlot.gnuplot ${SET}/baselinePlot_ADD_PAIRS.gnuplot
				#edit baselinePlot_ADD_PAIRS.gnuplot
				${PATHGNU}/gsed -i "s/selectedAcquisitionsSpatialRepartition.txt/selectedAcquisitionsSpatialRepartition_BpMax=${BP}_BTMax=${BT}_ADD_PAIRS.txt/" ${SET}/baselinePlot_ADD_PAIRS.gnuplot
				${PATHGNU}/gsed -i "s/selectedPairsListing.txt/selectedPairsListing_BpMax=${BP}_BTMax=${BT}_ADD_PAIRS.txt/" ${SET}/baselinePlot_ADD_PAIRS.gnuplot
				${PATHGNU}/gsed -i "s/imageSpatialLocalization/imageSpatialLocalization_ADD_PAIRS/" ${SET}/baselinePlot_ADD_PAIRS.gnuplot
				${PATHGNU}/gsed -i "s/baselinePlot/baselinePlot_ADD_PAIRS/" ${SET}/baselinePlot_ADD_PAIRS.gnuplot
				# replot		
				gnuplot ${SET}/baselinePlot_ADD_PAIRS.gnuplot
		fi

		# Create a initBaselines.txt from allPairsLisint.txt
		#####################################################
		cp allPairsListing.txt initBaselines.txt
		# shape the file
		# remove header, sort, remove leading spaces
		${PATHGNU}/grep -v "#" initBaselines.txt | sort | ${PATHGNU}/gsed "s/^[ \t]*//" > initBaselines_sorted.txt
		#get date of first image 
		FIRSTIMG=`cat initBaselines_sorted.txt | head -1 | ${PATHGNU}/grep -Eo "[0-9]{8} " | head -1`
		# keep only lines starting with FIRSTIMG and keep only col 1 (MAS), 2 (SLV), 3 (BP), and -4 (-Bt) tab separated
		cat initBaselines_sorted.txt | ${PATHGNU}/grep "^${FIRSTIMG}*" | ${PATHGNU}/gawk -v OFS='\t' '{print $1,	$2,	$8,	-$9}' > initBaselines.txt 

		rm -f ListNewDates.txt initBaselines_sorted.txt 

		# Create files for further plots as prepared in build_bperp_files.sh 
		# SM_Approx_baselines.txt and  bperp_file.txt
		# (would be too slow to run it here because it would make the plots again)
		####################################################################
		cp table_${BPMIN}_${BP}_${BTMIN}_${BT}.txt bperp_file.tmp
 
		# get rid of header
		tail -n +3 bperp_file.tmp > bperp_file

		cp allPairsListing.txt SM_Approx_baselines.txt
		# shape the file
		# remove header, sort, remove leading spaces
		${PATHGNU}/grep -v "#" SM_Approx_baselines.txt | sort | ${PATHGNU}/gsed "s/^[ \t]*//" > SM_Approx_baselines_sorted.txt
		# keep only lines containing SM and keep only col 1 (MAS), 2 (SLV), 3 (BP), and -4 (-Bt) tab separated
		cat SM_Approx_baselines_sorted.txt | ${PATHGNU}/grep "${SM}" | ${PATHGNU}/gawk -v OFS='\t' '{print $1,	$2,	$8,	-$9}' > SM_Approx_baselines.txt
		rm -f SM_Approx_baselines_sorted.txt

		rm -f  bperp_file.txt

		i=1
		while read MAS SLV BpPAIR BtPAIR
		do
				echo "Processing pair ${MAS} ${SLV}"
				echo " --> Bp and Bt are  ${BpPAIR} ${BtPAIR}" 
				# Get Bt and Bp for Master-SM pair
				if [ "${MAS}" == "" ] && [ "${SLV}" == "" ]
					then 
						echo "Ignore empty lines"
					else
						if [ ${MAS} == ${SM} ]
							then 
								BpMAS=0
								BtMAS=0
							else 
								BpMAS=`grep ${MAS} SM_Approx_baselines.txt | cut -f3`
								BtMAS=`grep ${MAS} SM_Approx_baselines.txt | cut -f4`
								if [ ${MAS} -ge ${SM} ]
									then 
									 BtMAS=`echo "(${BtMAS} * -1)" | bc -l `
									 BpMAS=`echo "(${BpMAS} * -1)" | bc -l `
								fi
						fi
						echo " --> Bp and Bt of master_Superaster ${MAS}_${SM} are ${BpMAS} ${BtMAS}" 
						# Get Bt and Bp for Slave-SM pair
						if [ ${SLV} == ${SM} ]
							then 
								BpSLV=0	
								BtSLV=0
							else 
								BpSLV=`grep ${SLV} SM_Approx_baselines.txt | cut -f3`		
								BtSLV=`grep ${SLV} SM_Approx_baselines.txt | cut -f4`
								if [ ${SLV} -ge ${SM} ]
									then 
										BtSLV=`echo "(${BtSLV} * -1)" | bc -l `
										BpSLV=`echo "(${BpSLV} * -1)" | bc -l `
								fi
						fi 	
						echo " --> Bp and Bt of slave_Superaster ${SLV}_${SM} are ${BpSLV} ${BtSLV}" 
						echo "${i}  ${MAS}  ${SLV}  ${BtPAIR}  ${BpPAIR}  ${BtMAS}  ${BtSLV}  ${BpMAS}  ${BpSLV}" >> bperp_file.txt
						i=`expr "$i" + 1`
				fi
				
		done < bperp_file

		cp SM_Approx_baselines.txt SM_Approx_baselines_${BPMIN}_${BP}_${BTMIN}_${BT}.txt
		cp bperp_file.txt bperp_file_${BPMIN}_${BP}_${BTMIN}_${BT}.txt

		# Create files for further plots as prepared in plotspan.sh 
		# span.txt and span1.txt
		# (would be too slow to run it here because it would make the plots again)
		####################################################################

		rm -f span.txt span1.txt 

		#while read n m s bp t t1 t2 b1 b2
		while read n m s t bp t1 t2 b1 b2
		do

			yyyy=`echo $m | cut -b 1-4`
			mm=`echo $m | cut -b 5-6`
			dd=`echo $m | cut -b 7-8`

			# date in decimal year : depends on leap year or not. DOY is decreased by 0.5 to mimick noon and avoid prblm at first or last day
			leapm=`${PATHGNU}/date --date="${yyyy}1231" +%j`
			mastertemp=`${PATHGNU}/date --date="${yyyy}${mm}${dd}" +%j`
			master=`echo ${mastertemp} ${leapm} ${yyyy} | ${PATHGNU}/gawk '{printf("%f",(($1-0.5)/$2) + $3);}'` 
			#master=`echo $yyyy $mm $dm | ${PATHGNU}/gawk '{printf("%.17g\n",$1+(($2-1)*30.25+$3)/365);}'` 

			yyyy=`echo $s | cut -b 1-4`
			mm=`echo $s | cut -b 5-6`
			dd=`echo $s | cut -b 7-8`

			leaps=`${PATHGNU}/date --date="${yyyy}1231" +%j`
			slavetemp=`${PATHGNU}/date --date="${yyyy}${mm}${dd}" +%j`
			slave=`echo ${slavetemp} ${leaps} ${yyyy} | ${PATHGNU}/gawk '{printf("%f",(($1-0.5)/$2) + $3);}'` 
			#slave=`echo $yyyy $mm $dm | ${PATHGNU}/gawk '{printf("%.17g\n",$1+(($2-1)*30.25+$3)/365);}'` 

			delta=`echo $master, $slave | ${PATHGNU}/gawk '{printf("%f",$2-$1)}'` 

			bpdelta=`echo $b1, $b2 | ${PATHGNU}/gawk '{printf("%f",$2-$1)}'`

			echo $master $b1 $delta $bpdelta >> span.txt

			md=`echo $master $delta | ${PATHGNU}/gawk '{printf("%f",$1+$2)}'`
			bpd=`echo $b1 $bpdelta | ${PATHGNU}/gawk '{printf("%f",$1+$2)}'`

			echo $master $b1 >> span1.txt
			echo $md $bpd >> span1.txt

			let "i=i+1"

		done < bperp_file_${BPMIN}_${BP}_${BTMIN}_${BT}.txt

		mv span.txt span_${BPMIN}_${BP}_${BTMIN}_${BT}.txt 
		mv span1.txt span1_${BPMIN}_${BP}_${BTMIN}_${BT}.txt 

fi

echo "All done; hope it worked"

