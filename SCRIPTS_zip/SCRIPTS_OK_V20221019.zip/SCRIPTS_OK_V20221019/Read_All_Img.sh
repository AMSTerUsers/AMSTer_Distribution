#!/bin/bash
# -----------------------------------------------------------------------------------------
# This script is aiming at reading all images from a given dir and store them in csl 
#      format where they will be used by the cis automated scripts. 
# The script will sort S1 images in Asc and Desc specific dir. 
#
#
# Parameters : - path to dir with the raw archives to read.   
#              - path to dir where images in csl format will be stored (usuallu must end with /NoCrop)
#              - satellite (to know which dir naming format is used)
#			   - kml file and path of footprint of zone of interest (optional but useful eg for S1)
#			   - for S1 : force reading data in yyyy directories if this param is "ForceAllYears" 
#
#
# Dependencies:	- CIS and CIS Tools, at least V20190716. 
#				- gnu sed and awk for more compatibility
#   			- functions "say" for Mac or "espeak" for Linux, but might not be mandatory
#				- FUNCTIONS_FOR_CIS.sh
#				- for S1 images :  	Check_All_S1_ImgReadSize.sh
#									List_All_S1_ImgSize.sh
#									List_S1_Frames_Swaths_Bursts.sh
#
# Hard coded:	- Path to .bashrc (sourced for safe use in cronjob)
#				    Path to sentinel orbits must be in that bashrc with a line such as : 
#					export S1_PRECISES_ORBITS_DIR=/...your path to .../S1_ORB/AUX_POEORB
#				  Also, it is recommended to get a cronjob to download them every day.
# 				- For S1 or SAOCOM images : a preferred polarisation mode so restrict the reading. 
#				  If missing, it will read and stitch all polarisations. 
#				- some DIR where data and products are stored
#
# New in Distro V 1.0:	- Based on developpement version 3.2 and Beta V2.4.5
#				V1.1.0: - change TDX handling...
#				V1.1.1: - TDX handling cope with several orb in same batch of read
#						- TSXfomrTDX is obsolate. Take images from TDXimages_TX for getting only the TSX masters 
#				V1.2.0: - check that no Mass processing is running before moving products that used updated Fast24 images to S1_CLN dir 
#						  or before moving products that used updated orbits images to S1_CLN dir
#				V1.3.0: - clean log files of more than 30 days
#				V1.4.0: - exit renalming of TDX when old format is encountered and let user to cope with it waiting for new version of reader
#				V1.4.1: - Clean old log files ORB_CleanRESAMPLED_*
#				V1.4.2: - discard $PATHFIND which was useless
#				V1.5.0: - When using S1, check empty file .../SAR_CSL/S1/REGION/NoCrop/DoNotUpdateProducts_Date_RNDM.txt that is created 
#						  when processing SinglePair(NoUnwrap).sh or SuperMasterCoreg.sh or SuperMaster_MassProc.sh is running using S1 data of the same mode. 
#						  If such a file exists and is not older than 1440 min, it will skip the cleaning of products using updated S1 orbits and/or fast24 data, if any, 
#						  and store the date of updated orbits (or fast24 imgs) in a file so that it can clean them at next run.  
#						WARNING: empty file .../SAR_CSL/S1/REGION/NoCrop/DoNotUpdateProducts_Date_RNDM.txt are cleaned at normal termination of the processes or if these processes 
#								 were terminated using CTRL-C. It is NOT deleted if processes are terminated using kill. If a file is older than one day, it must be a ghost files and wil be ignored. 
#				V1.5.1: - Skip S1 burst listing if SM mode
#				V1.5.2: - Compliant with SAOCOM images, though only in bulk reading and without polarisation selection
#				V1.5.3: - a space was missing in test for WS or SM in line 428 leading to always considering WS and hence attempting stitching bust even for S1 SM 
#						  and test was inverted
#						- update test for FAST24 to new messages logged in S1DataReaderLog.txt
#						- S1OrbitUpdater needs -u option because new S1DataReader doesn't update the orbits. Other option would be to run first updateS1PrecisesOrbits which updates the orb database 
#				V1.6.0: - Read S1 HH if INITPOL=VV not found
#				V2.0.0:	- Update S1 orb before reading and no more use of S1OrbitUpdater because now S1DataReader is doing the job. 
#						- clean empty log files with updated FAST24 and Orbits if no images were updated
#				V2.0.1:	- if, because of S1 orb update, a pair MAS_SLV was already updated for the MAS and is now updated for the SLV, the MAS_SLV dir exist already. Rename it first as MAS_SLV_1st_update
#				V2.0.2:	- improve backup of existing updated pair dir but also backup now existing updated file images 
#				V2.1.0:	- Add ALOS2
#						- ignore zip files as well while listing images
#				V2.2.0:	- change S1 orbit update function (from at least MasterEngine20210505) to cope with new ESA orbits. Note that these orbits are now taken from ASF. 
#							See procedure here: https://wiki.earthdata.nasa.gov/display/EL/How+To+Access+Data+With+cURL+And+Wget
#						  Ensure that you have now S1_ORBITS_DIR as state variable for path to dir where orbits are stored (./AUX_POEORB and ./AUX_RESORB) instead of S1_PRECISES_ORBITS_DIR  
#				V2.2.1:	- Use S1DateReader with new option -p to prevent reading S1 images without restituted or precise orbits. This is recommended since March 2021 when S1 images started to be distributed with orginal orbits of poor quality.  
#				V2.2.2:	- bug in S1 orbit dirname
#				V2.2.3:	- clean List_IMG_pol_HH_*.txt files older than threshold
#				V2.2.4:	- case insensitive searching while looking for updated S1 orbits
#				V2.2.5:	- allows skipping updating S1 orbits using parameter -n 
#						- check that basename of RAW dir is not in the form of _YYYY, which would mean that it only reads images from _FORMER dir and hence must not be moved again to _FORMER
#				V2.3.0:	- from MasterEngine V20211125, option -p is not necessary anymore
#				V2.4.0:	- Updated orbits : now  it performs the update of the local S1 orbit dir only since the last available precise orbit date.
#						  If you need to perform the update of the whole data base change line 342 (call of updateS1Orbits fct). Note that if ForceAllYears is requested, it will also update the whole local S1 orbit data base.
#						- New version (April 2022) of MasTer Engine works again with ESA S1 orbits. To use ASF orbits, add -ASF parameter at S1DataReader call in line 336  
#						- do not keep log of images with other polarisation (${CSL}/List_IMG_pol_HH_${RUNDATE}.txt) if empty
#				V2.4.1:	- Store version of MasTer Engine used to read the images using  fct GetMasTerEngineVersion. Param LASTVERSIONCIS is the last created dir of MasTer Engine source 
#				V2.4.2:	- mute error while using find function (eg after updating an orbit during a first run of the script i.e. when no former RESAMPLED/ nor SAR_MASSPROCESS/ dir exist for that target) by using 2>/dev/null.  
#				V2.5.0:	- Read ICEYE images
#				V2.6.0:	- Debug usage of ForceAllYears for non ICEYE data
#				V2.7.0:	- exit if no geoid available (i.e. if no file in EARTH_GRAVITATIONAL_MODELS_DIR)
# New in Distro V2.8.0: - remove stray \ before _ while calling grep to cope with new grep syntax and avoid waring
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/02/29 - could make better... when time.
# -----------------------------------------------------------------------------------------
PRG=`basename "$0"`
VER="Distro V2.8.0 MasTer script utilities"
AUT="Nicolas d'Oreye, (c)2016-2019, Last modified on Sept 21, 2022"
echo " "
echo "${PRG} ${VER}, ${AUT}"
echo "Processing launched on $(date) " 
echo " "

RAW=$1					# path to dir with the raw archives to read (unzipped for S1 !)
CSL=$2					# path to dir where images in csl format will be stored (usuallu must end with /NoCrop)
SAT=$3					# satellite
KMLS1=$4				# for S1 or recent other Datareader
FAY=$5					# for S1 or ICEYE : force reading data in yyyy directories if is "ForceAllYears" or -n to skip S1 orbit update OR force (re)reading all ICEYE images in dir 
NOORB=$6				# for S1 : -n to skip S1 orbit update

source /$HOME/.bashrc 

# vvv ----- Hard coded lines to check --- vvv 
INITPOL=VV  # Only needed for S1 ; to spare HD space, force to read only the most common mode. If you want all modes, keep this variable empty 
INITPOLSAOCOM=VV  # Only needed for SAOCOM ; to spare HD space, force to read only the most common mode. If you want all modes, keep this variable empty 

RESAMPLED="${PATH_1650}/SAR_SM/RESAMPLED/"
SAR_MASSPROCESS="${PATH_3601}/SAR_MASSPROCESS/" 
# ^^^ ----- Hard coded lines to check -- ^^^ 

FCTFILE=${PATH_SCRIPTS}/SCRIPTS_OK/FUNCTIONS_FOR_CIS.sh		

# do not run if no EARTH_GRAVITATIONAL_MODELS_DIR available
if [ `ls "${EARTH_GRAVITATIONAL_MODELS_DIR}" 2>/dev/null | wc -w ` -eq 0 ] ;  then echo "No EARTH_GRAVITATIONAL_MODELS_DIR ; can't run." ; exit ; fi

# Check OS
OS=`uname -a | cut -d " " -f 1 `
echo "Running on ${OS}"
echo

source ${FCTFILE}

CSLEND=`echo -n ${CSL} | tail -c 7`
if [ "${CSLEND}" != "/NoCrop" ] && [ ${SAT} != "CSK" ]; then echo "Check your CSL dir. It must end with NoCrop instead of ${CSLEND}" ; exit 0 ; fi

# Must be defined in .bashrc
ENVORB=${ENVISAT_PRECISES_ORBITS_DIR}
#SENTIORB=${S1_PRECISES_ORBITS_DIR}
SENTIORB=${S1_ORBITS_DIR}

function SpeakOut()
	{
	unset MESSAGE 
	local MESSAGE
	MESSAGE=$1

	case ${OS} in 
		"Linux") 
			espeak "${MESSAGE}" ;;
		"Darwin")
			say "${MESSAGE}" 	;;
		*)
			echo "${MESSAGE}" 	;;
	esac			
	}

if [ $# -lt 3 ] ; then echo "Usage $0 PATH_TO_RAW_IMG PATH_TO_CSL_STORAGE SATELLITE [KML] [ForceAllYears]"; exit; fi


RUNDATE=`date "+ %m_%d_%Y_%Hh%Mm" | ${PATHGNU}/gsed "s/ //g"`
RNDM1=`echo $(( $RANDOM % 10000 ))`
LOGFILE=${CSL}/LogFile_ReadAll_${RUNDATE}.txt

if [ ${SAT} == "ENVISAT" ] && [ ! -d ${ENVORB} ]
		then
			echo "No precise orbit dir for ENVISAT. Continue anyway though better check !"
			SpeakOut "No precise orbit dir for ENVISAT. Continue anyway though better check !"
fi		

if [ ${SAT} == "S1" ] && [ $# -lt 4 ]
		then
			echo "Probably no kml (with path!) contouring the area of interest for S1 data. You do not want to process the full images, don't you ?!"
			SpeakOut "Please provide a kml contouring the area of interest for S1 data. Do not forget the path..."
			exit
fi		
if [ ${SAT} == "S1" ] && [ ! -d ${SENTIORB} ] 
		then
			echo "No precise orbit directory for sentinel 1 data. Check .bashrc. Exit"
			SpeakOut "No precise orbit directory for sentinel 1 data. Check bash rc."
			exit
fi		

if [ ${SAT} == "ICEYE" ] 
	then 
		if [ $# -eq 4  ] 
			then
				FAY=${KMLS1}				# trick to get the 4th param for ICEYE as ForceAllYears if any
			else 
				FAY=""
		fi
fi		


echo ""
# Check required dir:
#####################

# Path where to store data in csl format 
if [ -d "${CSL}" ]
then
   echo "" > ${LOGFILE}
   EchoTee " OK: a directory exist where I can store the data in csl format." 
   EchoTee "     They will be strored in ${CSL}"
   if [ ${SAT} == "S1" ] 
   	  then EchoTee "     as link for each images. Data are stored in _Asc_TRK and Desc_TRK corresponding dir." 
   fi
   if [ ${SAT} == "TDX" ] 
   	  then EchoTee "     as link for each images. Data are stored in _TX (for transmit) and _RX (for receive) corresponding dir." 
   fi
   EchoTee ""
else
   echo " "
   echo " NO expected ${CSL} directory."
   echo " I will create a new one. I guess it is the first run for that mode." 
   echo ""
   mkdir -p ${CSL}
   echo "" > ${LOGFILE}
   EchoTee " NO expected ${CSL} directory. I created a new one. " 
 
fi

EchoTee "  // Command line used and parameters:"
EchoTee "  // $(dirname $0)/${PRG} $1 $2 $3 $4 $5"
EchoTee "  // ${VER}"
EchoTee ""

# Path to original raw data 
if [ -d "${RAW}/" ]
then
   EchoTee " OK: a directory exist where I guess raw data are stored." 
   EchoTee "      I guess images are in ${RAW}."    
   EchoTee ""
else
   EchoTee " "
   EchoTee " NO directory ${RAW}/ where I can find raw data. Can't run..." 
   exit 1
fi

function GetDate()
	{
	unset DIRNAME
	local DIRNAME=$1
	echo "${DIRNAME}" | cut -d _ -f6
	}

function GetDateEnvisat()
	{
	unset DIRNAME
	local DIRNAME=$1
	cd ${DIRNAME}
	ls *.N1 | cut -d _ -f3 | cut -c 7-14
	}
function GetDateERS()
	{
	unset DIRNAME
	local DIRNAME=$1
	cd ${DIRNAME}/SCENE1
	grep -aEo "[0-9]{17}" LEA_01.001 | head -1 | cut -c 1-8
	}
function GetDateALOS2()
	{
	unset DIRNAME
	local DIRNAME=$1
	echo -n 20 ; echo "${DIRNAME}" | tail -c 7
	}
	
function ChangeInPlace()
	{
	unset ORIGINAL
	unset NEW
	unset FILE
	local ORIGINAL=$1
	local NEW=$2
	local FILE=$3
	if [ $# -lt 4 ]
		then
   			EchoTee "=> Change ${ORIGINAL}"	
			EchoTee "   with ${NEW}"
			EchoTee "   in  ${FILE} "
			EchoTee ""
			${PATHGNU}/gsed -i "s%${ORIGINAL}%${NEW}%" ${FILE}
   		else 
   			local OCCURENCE=$4	# If a 4th argument is provided it will change the ORIGINAL that appears on the OCCURENCEth position in the FILE 
   			EchoTee "=> Change ${ORIGINAL}"
			EchoTee "   with ${NEW}"
			EchoTee "   in  ${FILE} "
			EchoTee ""
			${PATHGNU}/gsed -i "s%${ORIGINAL}%${NEW}%${OCCURENCE}" ${FILE}
    fi
	}	
	
# Change parameters in Parameters txt files
# function ChangeParamRead()
# 	{
# 	unset CRITERIA NEW 
# 	local CRITERIA
# 	local NEW	
# 	CRITERIA=$1
# 	NEW=$2
# 	
# 	unset KEY ORIGINAL
# 	local KEY
# 	local ORIGINAL
# 	
# 	KEY=`echo ${CRITERIA} | tr ' ' _`
# 	
# 	ORIGINAL=`updateParameterFile ${CSL}/Read_${IMG}.txt ${KEY} ${NEW}`
# 	EchoTee "=> Change in ${parameterFilePath}"
# 	EchoTee "...Key = ${CRITERIA} "
# 	EchoTee "...Former Value =  ${ORIGINAL}"
# 	EchoTee "    --> New Value =  ${NEW}  \n"
# 	}
# 	

	
# Let's Go:
###########	
cd ${CSL}				
# 		Use fct GetMasTerEngineVersion to get the date of the last version of MasTerEngine as param LASTVERSIONCIS
GetMasTerEngineVersion

case ${SAT} in
	"SAOCOM")
		PARENTCSL="$(dirname "$CSL")"  # get the parent dir, one level up
		REGION=`basename ${PARENTCSL}`

		# Check if links in ${PARENTCSL} points toward files (must be in ${PARENTCSL}_${TRK}/NoCrop/)
		# if not, remove broken link
		EchoTee "Remove possible broken links"
		for LINKS in `ls -d *.csl 2> /dev/null`
			do
				find -L ${LINKS} -type l ! -exec test -e {} \; -exec rm {} \; # first part stays silent if link is ok (or is not a link but a file or dir); answer the name of the link if the link is broken. Second part removes link if broken 
		done
		
		SAOCOMDataReader ${RAW} ${CSL} ${KMLS1} #P=${INITPOLSAOCOM}

		EchoTee ""
		EchoTee "All SAOCOM img read; now sorting Asc and Desc images  "
		EchoTee "  because mass reading copes with both orbits at the same time. "
		EchoTeeRed "Do not remove image files (links) from ${CSL} !!"
		EchoTee ""		
		for SAOCOMIMGPATH in ${CSL}/*.csl  # list actually the former links and the new dir if new images were read
			do
				SAOCOMIMG=`echo ${SAOCOMIMGPATH##*/}` 				# Trick to get only name without path
				SAOCOMMODE=`echo ${SAOCOMIMG} | cut -d _ -f 3 | cut -d . -f1` # Get the Asc or Desc mode
				SAOCOMDATE=`echo ${SAOCOMIMG} | cut -d _ -f 2` # Get the date
				
				mkdir -p ${PARENTCSL}_${SAOCOMMODE}/NoCrop
				if [ ! -d ${PARENTCSL}_${SAOCOMMODE}/NoCrop/${SAOCOMDATE}.csl ]
					then
							# There is no  ${PARENTCSL}_${SAOCOMMODE}/NoCrop/${SAOCOMDATE} DIR yet, hence it is a new img; move new img there
							mv ${SAOCOMIMGPATH} ${PARENTCSL}_${SAOCOMMODE}/NoCrop/${SAOCOMDATE}.csl 
							#and create a link
							ln -s ${PARENTCSL}_${SAOCOMMODE}/NoCrop/${SAOCOMDATE}.csl ${SAOCOMIMGPATH} 
							echo "Last created MasTer Engine source dir suggest reading with ME version: ${LASTVERSIONCIS}" > ${PARENTCSL}_${SAOCOMMODE}/NoCrop/${SAOCOMIMG}/Read_w_MasTerEngine_V.txt
				fi  
		done
		echo 
		;;
	"S1") # Use bulk reader
		# first update the orbit table 
		#updateS1PrecisesOrbits  	# obsolate
		
		if [ "${FAY}" == "-n" ] || [ "${NOORB}" == "-n"  ]
			then		
				EchoTee "Request to skip local S1 orbit data base update"
			else 
				EchoTee "Request to update local S1 orbit data base. This will be performed since the last available precise orbit date"
				# Since V April 2022, MasTer Engine uses again ESA orbits. Add -ASF param below if want to take orbits from ASF site
				if [ "${FAY}" == "ForceAllYears" ]
					then 
						updateS1Orbits from=20140101	# Update the whole local S1 orbit data base
					else 
						updateS1Orbits					# Update only the local S1 orbit data base since the last available precise orbit date
				fi
		fi
		
		PARENTCSL="$(dirname "$CSL")"  # get the parent dir, one level up
		REGION=`basename ${PARENTCSL}`
		# Check if links in ${PARENTCSL} points toward files (must be in ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/)
		# if not, remove broken link
		EchoTee "Remove possible broken links"
		for LINKS in `ls -d *.csl 2> /dev/null`
			do
				find -L ${LINKS} -type l ! -exec test -e {} \; -exec rm {} \; # first part stays silent if link is ok (or is not a link but a file or dir); answer the name of the link if the link is broken. Second part removes link if broken 
		done

		if [ "${FAY}" == "ForceAllYears" ]
			then 
				EchoTee ""
				EchoTeeYellow "Read recent images"	
				if [ `ls -d ${RAW}/*.SAFE 2> /dev/null | wc -l` -le 0 ] ; then 
					EchoTee "No recent data."
					touch ${CSL}/S1DataReaderLog.txt
				else
					S1DataReader ${RAW} ${CSL} ${KMLS1} P=${INITPOL}
					cp ${CSL}/S1DataReaderLog.txt ${CSL}/S1DataReaderLog_Recent.txt 
				fi	
				EchoTee ""
				EchoTeeYellow "Read older images"
				# Read in ${RAW}_FORMER/${YYYY}
				if [ -d ${RAW}_FORMER ] 
					then	
						S1DataReader ${RAW}_FORMER ${CSL} ${KMLS1} P=${INITPOL}
						cp ${CSL}/S1DataReaderLog.txt ${CSL}/S1DataReaderLog_Former.txt
				fi
				cat ${CSL}/S1DataReaderLog_Recent.txt ${CSL}/S1DataReaderLog_Former.txt > ${CSL}/S1DataReaderLog.txt
				rm -f ${CSL}/S1DataReaderLog_Recent.txt ${CSL}/S1DataReaderLog_Former.txt
				
			else 
				EchoTeeYellow "Read only recent images"	
				if [ `ls -d ${RAW}/*.SAFE 2> /dev/null | wc -l` -le 0 ] ; then 
   					EchoTee "No recent data."
   					touch ${CSL}/S1DataReaderLog.txt
				else
					S1DataReader ${RAW} ${CSL} ${KMLS1}	P=${INITPOL}
				fi						
		fi

		# Check if some data with pol != initpol
		# list all 3 lines with other pol, extract only those with the dates, which are those also TOPSAR string, then get only the file names 
		${PATHGNU}/grep -B 3 "Available polarizations are: HH" ${CSL}/S1DataReaderLog.txt  |  ${PATHGNU}/grep "TOPSAR" | cut -d " " -f 6  > ${CSL}/List_IMG_pol_HH_${RUNDATE}.txt
		
		if [ -s ${CSL}/List_IMG_pol_HH_${RUNDATE}.txt ]
			then
				mkdir -p ${RAW}_FORMER/___tmp_img_pol_HH
				# move all the HH files in a temp dir where they will be read
				while read -r FILEHHPO
				do	
					mv ${RAW}/${FILEHHPO} ${RAW}_FORMER/___tmp_img_pol_HH
				done < ${CSL}/List_IMG_pol_HH_${RUNDATE}.txt
		
				cd  ${RAW}_FORMER/___tmp_img_pol_HH
				S1DataReader ${RAW} ${CSL} ${KMLS1}	P=HH 

				# get them back
				while read -r FILEHHPO
				do	
					mv ${RAW}_FORMER/___tmp_img_pol_HH/${FILEHHPO} ${RAW}
				done < ${CSL}/List_IMG_pol_HH_${RUNDATE}.txt
				cd ${CSL}
			else
				# if file is empty, delete it
				rm -f ${CSL}/List_IMG_pol_HH_${RUNDATE}.txt
		fi	

		EchoTee ""
		EchoTee "All S1 img read; now moving images > 6 months in : "
		EchoTee "     ${RAW}_FORMER/_YYYY"
		EchoTee ""
		cd ${RAW}
		
		TESTDIR=`basename ${RAW}`
		if [[ $(echo $TESTDIR | ${PATHGNU}/grep -Eo "_[0-9]{4}") ]]
			then
				# Dir name contains only _yyyy and hence it is probably run to read only data in _FORMER/_YYYY dir. No need to move to FORMER then
				EchoTee "Probably reading data from _FORMER/_YYYY dir. No need to move them to FORMER again then." 
			else
				if [ `ls -d ${RAW}/*.SAFE 2> /dev/null | wc -l` -le 0 ] ; then 
							EchoTee "No recent data ; nothing to move."
					else
						for FILESAFE in `ls -d *.SAFE`
							do
								YEARFILE=`echo ${FILESAFE} | cut -c 18-21`
								MMFILE=`echo ${FILESAFE} | cut -c 22-23 | ${PATHGNU}/gsed 's/^0*//'`
								DATEFILE=`echo "${YEARFILE} + ( ${MMFILE} / 12 ) - 0.0001" | bc -l` # 0.0001 to avoid next year in december
								YRNOW=`date "+ %Y"`	
								MMNOW=`date "+ %-m"`					
								DATENOW=`echo "${YRNOW} + ( ${MMNOW} / 12 )" | bc -l`
								DATEHALFYRBFR=`echo "${DATENOW} - 0.5" | bc -l`
								TST=`echo "${DATEFILE} < ${DATEHALFYRBFR}" | bc -l`
								if [ ${TST} -eq 1 ]
									then
										mkdir -p ${RAW}_FORMER/_${YEARFILE}
										mv ${FILESAFE} ${RAW}_FORMER/_${YEARFILE}
								fi
						done
				fi
		fi
		
		cd ${CSL}
		echo 
		
		# sort Asc and Desc orbits
		EchoTee ""
		EchoTee "Now sorting S1 :"
		EchoTee "Because S1 mass reading copes with both Asc and Desc orbits and for each Orbit Track at the same time, I will sort them out here for you using links in corresponding dirs."
		EchoTeeRed "Do not remove image files from ${CSL} !!"
		EchoTee ""		
		for S1IMGPATH in ${CSL}/*.csl  # list actually the former links and the new dir if new images were read
			do
				S1IMG=`echo ${S1IMGPATH##*/}` 				# Trick to get only name without path
				S1TRK=`echo ${S1IMG} | cut -d _ -f 2` 		# Get the orbit nr
				S1MODE=`echo ${S1IMG} | cut -d _ -f 4 | cut -c 1` # Get the Asc or Desc mode
				mkdir -p ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop
				if [ ! -d ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG} ]
					then
							# There is no  ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG} DIR yet, hence it is a new img; move new img there
							mv ${S1IMG} ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/ 
							#and create a link
							ln -s ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG} ${CSL} 
							echo "Last created MasTer Engine source dir suggest reading with ME version: ${LASTVERSIONCIS}" > ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/${S1IMG}/Read_w_MasTerEngine_V.txt
				fi  
		done
		echo 
		# Do not test if there are files in ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/ without links in ${PARENTCSL}.
		# Shouldn't be a problem because in such a case, without link in PARENTCSL, it dowload the image again. 

		# Stitch bursts and check size. Re-read if size (in bytes) of image with stitched bursts is not compliant with cols x rows x 8 
		# It will only stitch modes as expressed in a table that is expected here : 
		EchoTee ""
		EchoTee "Now stiches all bursts of S1 images (if wide swath) "
		EchoTee "  and check if size is compliant with number or lines and columns. If not, re-stitch the image "

		EchoTee "Then check the size of all master images and store that info in NoCrop/List_Master_Sizes.txt. "
		EchoTee "  You may want to check it to ensure that no bursts are missing in some images. "
		EchoTee ""
		EchoTee "Then delete data that are in quarantained in SAR_CSL/S1/region/Quarantained. "
		EchoTee ""	
		EchoTee "Then list bursts for each image in files. "
		EchoTee ""	
		
		for TRACKS in `ls -d ${PARENTCSL}_* `  # all tracks without parent dir
			do 
				cd ${TRACKS}/NoCrop
				EchoTee ""	
				EchoTee "Check mode ${TRACKS}: "
				EchoTee "----------------------"	
				Check_All_S1_ImgReadSize.sh ${INITPOL}
				cd ${TRACKS}/NoCrop
				List_All_S1_ImgSize.sh
				if [ -d ${TRACKS}/Quarantained ] ; then 
					cd ${TRACKS}/Quarantained
					for IMGQUARANTAINED in `ls -d *.csl `
						do
						rm -Rf ${TRACKS}/NoCrop/${IMGQUARANTAINED}
					done
				fi
				
				cd ${TRACKS}/NoCrop
				FIRSTIMG=`find . -type f -name "SLCImageInfo.txt" -print -quit`
				CHECKWS=`grep "Beam" ${FIRSTIMG} | ${PATHGNU}/gsed 's@^[^0-9]*\([0-9]\+\).*@\1@'`
				if [ "${CHECKWS}" != "0" ] 
					then 
						EchoTee "S1 is SM; skip burst listing"
					else 
						EchoTee "S1 is wide swath; proceed to burst listing"
						List_S1_Frames_Swaths_Bursts.sh
				fi
		done

		EchoTee ""	
		cd ${CSL} 		
		# Clear all processes which include images for which Fast 24 frame was updated in RESAMPLED, SAR_MASSPROCESS
		# BELOW NEEDED UPDATE in V1.5.3
		# Because the S1Reader output a new line for each updated frame of the same image, let's uniq the log file
		#	cat ${CSL}/S1DataReaderLog.txt | uniq > ${CSL}/S1DataReaderLog_${RUNDATE}.txt
		# new:	
		# serach for lines with info about FAST24 img,i.e. "Fast-24h frame %d replaced by Normal Archive one in image %s\n"
		${PATHGNU}/grep "Fast-24h frame" ${CSL}/S1DataReaderLog.txt > ${CSL}/S1DataReaderLog_FAST24.txt
		# uniq just in case 
		cat ${CSL}/S1DataReaderLog_FAST24.txt | uniq > ${CSL}/S1DataReaderLog_FAST24_${RUNDATE}.txt
		
			if [ -s ${CSL}/S1DataReaderLog_FAST24_${RUNDATE}.txt ]; then 
				EchoTee "List all processes to clean which include images for which Fast 24 frame was updated in RESAMPLED, SAR_MASSPROCESS"
				for IMGTOCLEAN in `cat ${CSL}/S1DataReaderLog_FAST24_${RUNDATE}.txt`
					do
						DATEIMGTOCLEAN=`echo "${IMGTOCLEAN}" | cut -d _ -f3 `
						
						cd ${RESAMPLED}/S1
						EchoTee "${IMGTOCLEAN} was updated (Fast-24h frames were replaced by ArchNorm ones)"
						EchoTee "List all processing involving ${DATEIMGTOCLEAN} (i.e. ${IMGTOCLEAN}) from RESAMPLED"

						#find ${REGION}* -name "*${DATEIMGTOCLEAN}*" -a -prune >> ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}.txt
						find ${REGION}* -name "*${DATEIMGTOCLEAN}*" -a -prune 2>/dev/null  >> ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}_tmp.txt

						cd ${SAR_MASSPROCESS}/S1/
						EchoTee "List all processing involving ${DATEIMGTOCLEAN} (i.e. ${IMGTOCLEAN}) from SAR_MASSPROCESS"
						#find ${REGION}* -name "*${DATEIMGTOCLEAN}*" -a -prune  >> ${CSL}/FAST24_CleanMASSPROCESS_${RUNDATE}.txt 
						find ${REGION}* -name "*${DATEIMGTOCLEAN}*" -a -prune 2>/dev/null  >> ${CSL}/FAST24_CleanMASSPROCESS_${RUNDATE}_tmp.txt 
				done
				echo 
				# add possible former list that was postponed because a run was in progress	
				cat ${CSL}/FAST24_CleanRESAMPLED_TODO_NEXT_TIME.txt ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}_tmp.txt 2>/dev/null | sort | uniq > ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}.txt
				cat ${CSL}/FAST24_CleanMASSPROCESS_TODO_NEXT_TIME.txt ${CSL}/FAST24_CleanMASSPROCESS_${RUNDATE}_tmp.txt 2>/dev/null | sort | uniq > ${CSL}/FAST24_CleanMASSPROCESS_${RUNDATE}.txt
				
				rm -f ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}_tmp.txt ${CSL}/FAST24_CleanMASSPROCESS_${RUNDATE}_tmp.txt 
				
				# Move files - this could be deleted later I guess 		
				# Check first that no one is using it 
				
#				# Check that no SuperMaster_MassProc.sh is running with a LaunchCISparam_..txt from S1. Maybe not the best test...
#				CHECKMP=`ps -eaf | ${PATHGNU}/grep SuperMaster_MassProc.sh | ${PATHGNU}/grep -v "grep SuperMaster_MassProc.sh" | ${PATHGNU}/grep LaunchCISparam_  | ${PATHGNU}/grep "/S1/" | wc -l`
#				if [ ${CHECKMP} -eq 0 ] 
#					then 				
						EchoTee "Move (may prefer delete ?) all processes in RESAMPLED, SAR_MASSPROCESS which include images for which Fast 24 frame were updated."
						EchoTee "   Move them in ${RESAMPLED}/S1_CLN/CLEANED_FAST24/"
						EchoTee "            and ${SAR_MASSPROCESS}/S1_CLN/CLEANED_FAST24/"

				# get all modes in ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}.txt
				${PATHGNU}/gsed 's%\/.*%%' ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}.txt | sort | uniq > TRKDIR_list_${RUNDATE}_${RNDM1}.txt
				DATAPATH="$(dirname "$PARENTCSL")"  # get the parent dir, one level up

				for TRKDIR in `cat TRKDIR_list_${RUNDATE}_${RNDM1}.txt`
				do 
				# If no ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/DoNotUpdateProducts_*_*.txt of less than 1 day (1440 min) then can remove products 
				# Note that we consider that if DoNotUpdateProducts_*_*.txt are odler than 1440 min, they must be ghost file and will be ignored. 
					CHECKFLAGUSAGE=`find ${DATAPATH}/${TRKDIR}/NoCrop/ -maxdepth 1 -name "DoNotUpdateProducts_*_*.txt" -type f -mmin -1440 | wc -l`
					if [ ${CHECKFLAGUSAGE} -eq 0 ]
						then 
							# ok no process running since less than 1 day: can proceed to cleaning
#							#for FILESTOCLEAN in `cat  ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}.txt`
							for FILESTOCLEAN in `grep ${TRKDIR} ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}.txt`
							do
								PATHFILESTOCLEAN=$(dirname "${FILESTOCLEAN}")
								mkdir -p ${RESAMPLED}/S1_CLN/CLEANED_FAST24/${PATHFILESTOCLEAN}
								mv -f ${RESAMPLED}/S1/${FILESTOCLEAN} ${RESAMPLED}/S1_CLN/CLEANED_FAST24/${FILESTOCLEAN}			
							done

#							#for FILESTOCLEAN in `cat  ${CSL}/FAST24_CleanMASSPROCESS_${RUNDATE}.txt`
							for FILESTOCLEAN in `grep ${TRKDIR} ${CSL}/FAST24_CleanMASSPROCESS_${RUNDATE}.txt`
							do
								PATHFILESTOCLEAN=$(dirname "${FILESTOCLEAN}")
								mkdir -p ${SAR_MASSPROCESS}/S1_CLN/CLEANED_FAST24/${PATHFILESTOCLEAN}
								mv -f ${SAR_MASSPROCESS}/S1/${FILESTOCLEAN} ${SAR_MASSPROCESS}/S1_CLN/CLEANED_FAST24/${FILESTOCLEAN} 
							done

							# because products were cleaned, one can discard the list (if any) of products to clean 
							rm -f ${CSL}/FAST24_CleanRESAMPLED_TODO_NEXT_TIME.txt
							rm -f ${CSL}/FAST24_CleanMASSPROCESS_TODO_NEXT_TIME.txt
					else 
						#EchoTee " A SuperMaster_MassProc.sh seems to be using a LaunchParam_....txt file. To avoid possible clash, we postpone here the move of old products using outdated fast24 images"
						EchoTee " A process seems to be using data from ${TRKDIR}. To avoid possible clash, we postpone here the move of old products using images with outdated fast24 images"
						RUNPROC=`find ${DATAPATH}/${TRKDIR}/NoCrop/ -maxdepth 1 -name "DoNotUpdateProducts_*_*.txt" -type f -mmin -1440`
						EchoTee "  Running process : ${RUNPROC}"
						
						# store/add them in a file for next run  
						cat ${CSL}/FAST24_CleanRESAMPLED_${RUNDATE}.txt >> ${CSL}/FAST24_CleanRESAMPLED_TODO_NEXT_TIME.txt
						cat ${CSL}/FAST24_CleanMASSPROCESS_${RUNDATE}.txt >> ${CSL}/FAST24_CleanMASSPROCESS_TODO_NEXT_TIME.txt
						# sort and uniq
						sort ${CSL}/FAST24_CleanRESAMPLED_TODO_NEXT_TIME.txt | uniq > ${CSL}/FAST24_CleanRESAMPLED_TODO_NEXT_TIME.clean.txt
						sort ${CSL}/FAST24_CleanMASSPROCESS_TODO_NEXT_TIME.txt | uniq > ${CSL}/FAST24_CleanMASSPROCESS_TODO_NEXT_TIME.clean.txt
						mv -f ${CSL}/FAST24_CleanRESAMPLED_TODO_NEXT_TIME.clean.txt ${CSL}/FAST24_CleanRESAMPLED_TODO_NEXT_TIME.txt
						mv -f ${CSL}/FAST24_CleanMASSPROCESS_TODO_NEXT_TIME.clean.txt ${CSL}/FAST24_CleanMASSPROCESS_TODO_NEXT_TIME.txt

					fi
				done
				rm -f TRKDIR_list_${RUNDATE}_${RNDM1}.txt
			else 
				EchoTee " No Fast-24h frames replaced by ArchNorm ones."
				# file is hence empty
				rm -f ${CSL}/S1DataReaderLog_FAST24_${RUNDATE}.txt
			fi
		echo 
	
		EchoTee "Run the check of S1 orbits"
		EchoTee "--------------------------"
		echo
			${PATHGNU}/grep -iB 3 "precise orbit update performed" ${CSL}/S1DataReaderLog.txt | ${PATHGNU}/grep Start | ${PATHGNU}/grep -Eo "[0-9]{8}T" | cut -d T -f1 | uniq > ${CSL}/S1DataReaderLog_NEWORB.txt
			# uniq just in case (contains then ony lines such as: 20200923) 
			cat ${CSL}/S1DataReaderLog_NEWORB.txt | uniq > ${CSL}/S1DataReaderLog_NEWORB_${RUNDATE}.txt


#			#S1OrbitUpdater ${CSL} -u | tee  ${CSL}/UpdatabelOrbits_${RUNDATE}.txt
#			# Test if orbits are missing :
#			cat ${CSL}/UpdatabelOrbits_${RUNDATE}.txt | ${PATHGNU}/grep "No precise orbit file found in local data base for this image" -B 1 | ${PATHGNU}/grep -v "No precise orbit file found in local data base for this image" | cut -d _ -f3 >  ${CSL}/NoPreciseOrbitsFoundFor_${RUNDATE}.txt
#			rm  ${CSL}/UpdatabelOrbits_${RUNDATE}.txt
#			# One should check here if some images are less than 1 months old. If yes, there must be a problem with orbits download
#			echo
#			 EchoTee "Check if files that could have been updated and were not are older than 30 days."
#			 EchoTee " This would mean that there is a problem with orbits " 
#			# get the list of YYYYmm of missing orbits from ${CSL}/NoPreciseOrbitsFoundFor_${RUNDATE}.txt
#			if [ -s ${CSL}/NoPreciseOrbitsFoundFor_${RUNDATE}.txt ] ; then
#				cat ${CSL}/NoPreciseOrbitsFoundFor_${RUNDATE}.txt | ${PATHGNU}/gawk -F '/' '{print $NF}' | cut -c 1-6 | sort | uniq > ${CSL}/OrbitsToDownload_${RUNDATE}.txt
#				
#				# If at least one orbit to download exists, then try to re-download the whole orbits using CSL function 
#				if [ -s ${CSL}/OrbitsToDownload_${RUNDATE}.txt ] ; then
#					updateS1PrecisesOrbits
#				fi
#
#				for DATETOCHECK in `cat ${CSL}/NoPreciseOrbitsFoundFor_${RUNDATE}.txt`
#					do
#						TODAY=`date +%s`  							# Today as seconds since 1970-01-01
#						DOITOCHECK=`date -d "${DATETOCHECK}" +%s`	# Date to check as seconds since 1970-01-01 
#						DIFFSEC=`echo "( ${TODAY} - ${DOITOCHECK} )" | bc `
#						DIFFDAYS=`echo "( ${DIFFSEC} / 86400 )" | bc `
#						echo "Date diff : ${TODAY} - ${DOITOCHECK} = ${DIFFSEC}" 
#						if [ ${DIFFSEC} -le 2678400 ] # if diff is less than 31 days in sec : ok 
#							then 
#								EchoTeeYellow " Image without updated orbit (${DATETOCHECK}) is less than 31 days old. Might not be a problem "
# 							else
# 								EchoTeeRed " Image without updated orbit (${DATETOCHECK}) is older than 31 days. "
# 								EchoTeeRed " ${DIFFDAYS} days old without updated orbits is abnormal. Tried to get orbits and relaunch."
# 								SpeakOut "Image ${DATETOCHECK} without updated orbit is ${DIFFDAYS} days old, that is older than 31 days. Tried to get orbits and relaunch."
# 								# Flag to relaunch Read_All_Img
# 								REPLAY=ReplayYes
# 						fi  
# 				done
# 			fi
#		echo
		# Clear all processes which include images for which orbit was updated in RESAMPLED, SAR_MASSPROCESS
#			cp ${CSL}/S1OrbitUpdaterLog.txt ${CSL}/S1OrbitUpdaterLog_${RUNDATE}.txt

			if [ -s ${CSL}/S1DataReaderLog_NEWORB_${RUNDATE}.txt ] ; then # still contains then ony lines such as: ---> Frame already present in image S1B_21_20200923_D.csl.
				EchoTee "List all processes to clean which include images for which orbit was updated in RESAMPLED, SAR_MASSPROCESS"
				for DATEIMGTOCLEAN in `cat ${CSL}/S1DataReaderLog_NEWORB_${RUNDATE}.txt`
					do
 #						DATEIMGTOCLEAN=`echo "${IMGTOCLEAN}" | cut -d _ -f3 `

 						cd ${RESAMPLED}/S1
						EchoTee "Orbit of ${DATEIMGTOCLEAN} was updated. "
						EchoTee "List all processing involving ${DATEIMGTOCLEAN}from RESAMPLED/S1/${REGION}*"
						find ${REGION}* -name "*${DATEIMGTOCLEAN}*" -a -prune 2>/dev/null >> ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}_tmp.txt 
						cd ${SAR_MASSPROCESS}/S1
						EchoTee "List all processing involving ${DATEIMGTOCLEAN} from SAR_MASSPROCESS/S1/${REGION}*"
						find ${REGION}* -name "*${DATEIMGTOCLEAN}*" -a -prune 2>/dev/null >> ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}_tmp.txt 
				done
				echo 
				# add possible former list that was postponed because a run was in progress	
				cat ${CSL}/ORB_CleanRESAMPLED_TODO_NEXT_TIME.txt ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}_tmp.txt 2>/dev/null | sort | uniq > ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}.txt
				cat ${CSL}/ORB_CleanMASSPROCESS_TODO_NEXT_TIME.txt ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}_tmp.txt 2>/dev/null | sort | uniq > ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}.txt
				
				rm -f ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}_tmp.txt ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}_tmp.txt
				
				# Move files - this could be deleted later I guess; in such a case you may prefer delete from the find cmd line above
	
#				# Check that no SuperMaster_MassProc.sh is running with a LaunchCISparam_..txt from S1. Maybe not the best test...
#				CHECKMP=`ps -eaf | ${PATHGNU}/grep SuperMaster_MassProc.sh | ${PATHGNU}/grep -v "grep SuperMaster_MassProc.sh" | ${PATHGNU}/grep LaunchCISparam_  | ${PATHGNU}/grep "/S1/" | wc -l`
#				if [ ${CHECKMP} -eq 0 ] 
#					then 			

						EchoTee "Move (may prefer delete ?) all processes in RESAMPLED, SAR_MASSPROCESS which include images for which orbits were updated"
						EchoTee "   Move them in ${RESAMPLED}/S1_CLN/CLEANED_ORB/"
						EchoTee "            and ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/"


				# get all modes in ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}.txt
				${PATHGNU}/gsed 's%\/.*%%' ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}.txt | sort | uniq > TRKDIR_list_${RUNDATE}_${RNDM1}.txt
				DATAPATH="$(dirname "$PARENTCSL")"  # get the parent dir, one level up

				for TRKDIR in `cat TRKDIR_list_${RUNDATE}_${RNDM1}.txt`
				do 
				# If no ${PARENTCSL}_${S1MODE}_${S1TRK}/NoCrop/DoNotUpdateProducts_*_*.txt of less than 1 day (1440 min) then can remove products 
				# Note that we consider that if DoNotUpdateProducts_*_*.txt are odler than 1440 min, they must be ghost file and will be ignored. 
					CHECKFLAGUSAGE=`find ${DATAPATH}/${TRKDIR}/NoCrop/ -maxdepth 1 -name "DoNotUpdateProducts_*_*.txt" -type f -mmin -1440 | wc -l`
					if [ ${CHECKFLAGUSAGE} -eq 0 ]
						then 
							# ok no process running since less than 1 day: can proceed to cleaning
										#for FILESTOCLEAN in `cat  ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}.txt`
										for FILESTOCLEAN in `grep ${TRKDIR} ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}.txt`
										do
											PATHFILESTOCLEAN=$(dirname "${FILESTOCLEAN}")
											mkdir -p ${RESAMPLED}/S1_CLN/CLEANED_ORB/${PATHFILESTOCLEAN}
											# echo "Image ${FILESTOCLEAN} updated. Should move ${RESAMPLED}/S1/${FILESTOCLEAN} to ${RESAMPLED}/S1_CLN/CLEANED_ORB/${PARENTCSL}_${S1MODE}_${S1TRK}/"
											mv -f ${RESAMPLED}/S1/${FILESTOCLEAN} ${RESAMPLED}/S1_CLN/CLEANED_ORB/${FILESTOCLEAN}
										done

										#for FILESTOCLEAN in `cat  ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}.txt`
										for FILESTOCLEAN in `grep ${TRKDIR}  ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}.txt`
										do
											# if a pair MAS_SLV was already updated for the MAS and is now updated for the SLV, the MAS_SLV dir exist already. Rename it first as MAS_SLV_1st_update
											if [ -d ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${FILESTOCLEAN} ]
												then 
													mv -f ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${FILESTOCLEAN} ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${FILESTOCLEAN}_1st_update
													mv -f ${SAR_MASSPROCESS}/S1/${FILESTOCLEAN} ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${FILESTOCLEAN}
												else 
													PATHFILESTOCLEAN=$(dirname "${FILESTOCLEAN}")
													
													if [ -s ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${FILESTOCLEAN} ] 
														then 
															FILESTOCLEANEXT="${FILESTOCLEAN##*.}" # extention only
															FILESTOCLEANNOEXT="${FILESTOCLEAN%.*}" # path and name without extention
															mv -f ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${FILESTOCLEAN} ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${FILESTOCLEANNOEXT}_1st_update.${FILESTOCLEANEXT}
													fi
													mkdir -p ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${PATHFILESTOCLEAN}
													# echo "Image ${FILESTOCLEAN} updated. Should move  ${SAR_MASSPROCESS}/S1/${FILESTOCLEAN} to ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${PARENTCSL}_${S1MODE}_${S1TRK}/"
													mv -f ${SAR_MASSPROCESS}/S1/${FILESTOCLEAN} ${SAR_MASSPROCESS}/S1_CLN/CLEANED_ORB/${FILESTOCLEAN}
											fi
										done
										
										# because products were cleaned, one can discard the list (if any) of products to clean 
										rm -f ${CSL}/ORB_CleanRESAMPLED_TODO_NEXT_TIME.txt
										rm -f ${CSL}/ORB_CleanMASSPROCESS_TODO_NEXT_TIME.txt
						else 
							# Some processes are running. Let's wait next run to clean the products. 
							# Store them in ${CSL}/ORB_CleanRESAMPLED_TODO_NEXT_TIME.txt and ${CSL}/ORB_CleanMASSPROCESS_TODO_NEXT_TIME.txt
							EchoTee " A process seems to be using data from ${S1TRK}. To avoid possible clash, we postpone here the move of old products using images with outdated orbits."
							# store/add them in a file for next run  
							cat ${CSL}/ORB_CleanRESAMPLED_${RUNDATE}.txt >> ${CSL}/ORB_CleanRESAMPLED_TODO_NEXT_TIME.txt
							cat ${CSL}/ORB_CleanMASSPROCESS_${RUNDATE}.txt >> ${CSL}/ORB_CleanMASSPROCESS_TODO_NEXT_TIME.txt
							# sort and uniq
							sort ${CSL}/ORB_CleanRESAMPLED_TODO_NEXT_TIME.txt | uniq > ${CSL}/ORB_CleanRESAMPLED_TODO_NEXT_TIME.clean.txt
							sort ${CSL}/ORB_CleanMASSPROCESS_TODO_NEXT_TIME.txt | uniq > ${CSL}/ORB_CleanMASSPROCESS_TODO_NEXT_TIME.clean.txt
							mv -f ${CSL}/ORB_CleanRESAMPLED_TODO_NEXT_TIME.clean.txt ${CSL}/ORB_CleanRESAMPLED_TODO_NEXT_TIME.txt
							mv -f ${CSL}/ORB_CleanMASSPROCESS_TODO_NEXT_TIME.clean.txt ${CSL}/ORB_CleanMASSPROCESS_TODO_NEXT_TIME.txt
					fi
				done
				rm -f TRKDIR_list_${RUNDATE}_${RNDM1}.txt

			else 
				EchoTee " No orbits updated."
				# file is hence empty 
				rm -f ${CSL}/S1DataReaderLog_NEWORB_${RUNDATE}.txt
			fi
		;;
		
	"TDX") 	# because TDX format change all the time, use here the bulk reader that will take care of the dir structure
			# Not sure if it will take care of images already read...
			
			EchoTee "It will read all the TDX images from the dir. It is your responsability to ensure that they all cover the same footprint, though Lat and Long of center of scene is provided as text file for check."
			
			PARENTCSL="$(dirname "$CSL")"  # get the parent dir, one level up
			REGION=`basename ${PARENTCSL}`
			# Check if links in ${PARENTCSL} points toward files (must be in ${PARENTCSL}_TX/NoCrop/  or ${PARENTCSL}_RX/NoCrop/ )
			# if not, remove broken link
			EchoTee "Remove possible broken links"
			
			for LINKS in `ls -d */*.csl 2> /dev/null`
				do
					find -L ${LINKS} -type l ! -exec test -e {} \; -exec rm {} \; # first part stays silent if link is ok (or is not a link but a file or dir); answer the name of the link if the link is broken. Second part removes link if broken 
			done
			
			EchoTee "Read images"
			TSXDataReader ${RAW} ${CSL}
			
			# TDX images may be acquired in different frames on the sam date. Unfortunately the dir are numbered with increasing nr. 
			# Lets sort them out and rename 
# 			for DUPLICATESIMG in `ls -d ${CSL}/*`  
# 			do
# 				SUFFIX=`echo ${CSL}/${DUPLICATESIMG} | cut -d _ -f 4`
# 				if [ ${SUFFIX} != "" ] || [ ${SUFFIX} != "1" ]					  				# now in the form of _n  (_2 from example above if duplicates exists)
# 					then 
# 						NAMETOSUFFIX=`echo ${CSL}/${DUPLICATESIMG}  | cut -d _ -f 1-3`
# 						if [ ! -d ${CSL}/${NAMETOSUFFIX}_1 ]
# 							then 
# 								mv 	${CSL}/${DUPLICATESIMG} ${CSL}/${NAMETOSUFFIX}_1
# 							else 
# 								# check that it is similar footprint than what is in _1. 
# 								# Check coord of master
# 								TDXCENTERLON=`echo ${CSL}/${DUPLICATESIMG}/*.master.csl/Info/SLCImageInfo.txt  | cut -d: -f2 | ${PATHGNU}/grep -Eo '[+-]?[0-9]+([.][0-9]+)?' | tr '\n' ' ' | tr -d '[:space:]'; echo "" | xargs printf "%.*f\n" 2` # select Long as integer with sign
# 								TDXCENTERLAT=`echo ${CSL}/${DUPLICATESIMG}/*.master.csl/Info/SLCImageInfo.txt  | cut -d: -f3 | ${PATHGNU}/grep -Eo '[+-]?[0-9]+([.][0-9]+)?' | tr '\n' ' ' | tr -d '[:space:]'; echo "" | xargs printf "%.*f\n" 2` # select Lat as integer with sign
# 								# Check coord of master in _1
# 								TDXCENTERLO1=`echo ${CSL}/${NAMETOSUFFIX}_1/*.master.csl/Info/SLCImageInfo.txt  | cut -d: -f2 | ${PATHGNU}/grep -Eo '[+-]?[0-9]+([.][0-9]+)?' | tr '\n' ' ' | tr -d '[:space:]'; echo "" | xargs printf "%.*f\n" 2` # select Long as integer with sign
# 								TDXCENTERLA1=`echo ${CSL}/${NAMETOSUFFIX}_1/*.master.csl/Info/SLCImageInfo.txt  | cut -d: -f3 | ${PATHGNU}/grep -Eo '[+-]?[0-9]+([.][0-9]+)?' | tr '\n' ' ' | tr -d '[:space:]'; echo "" | xargs printf "%.*f\n" 2` # select Lat as integer with sign
# 								echo "Footprints of first image and second image are "
# 								if [ ${TDXCENTERLON} == ${TDXCENTERLO1}] && [ ${TDXCENTERLAT} == ${TDXCENTERLA1}]
# 									then 
# 										mv 	${CSL}/${DUPLICATESIMG} ${CSL}/${NAMETOSUFFIX}_1
# 									else 
# 										if [ ! -d ${CSL}/${NAMETOSUFFIX}_2 ]
# 											then 
# 												mv ${CSL}/${DUPLICATESIMG} ${CSL}/${NAMETOSUFFIX}_2
# 											else 
# 												echo "Seems that you have more than 3 images acquired on the same date ? Check or change script in line 530"
# 												exit 0
# 										fi
# 								fi
# 						fi
# 				fi
# 			done		
		
			EchoTee ""
			EchoTee "All TDX img read; now sorting images in : "
			EchoTee "     ${PARENTCSL}_info_orbits_TX/NoCrop/ for master.csl (i.e. transmitting sat)"
			EchoTee "     or ${PARENTCSL}_info_orbits_RX/NoCrop/ for slave.csl (i.e. receiveing sat)"
			EchoTee "  and rename as date.csl "
			EchoTee ""
			
			rm -f Center_Of_Scene.txt
		
#			for TDXIMGPATH in ${CSL}/*/*.csl  # list actually the former links and the new dir if new images were read
			for TDXIMGPATH in `find ${CSL} -name "*.csl" -type d  -print`  # list actually the former links and the new dir if new images were read
				do
					PATHPAIRSTDX="$(dirname "$TDXIMGPATH")"	  				# get the parent dir
					PAIRSTDX=`basename ${PATHPAIRSTDX}`						# one level above parent dir
					# test if PAIRSTDX is NoCrop, which would mean this is an old format
					if [ ${PAIRSTDX} == "NoCrop" ] 
						then 
							# old format
							echo "old format - sort yourself the data" 
							echo "Sort yourself ${TDXIMGPATH}" >> ERROR.txt
							continue
						else 

							TDXIMG=`echo ${TDXIMGPATH##*/}` 						# Trick to get only name without path
							#TDXPATH=												# one level up, i.e. path to TDXIMG
							TDXDATE=`echo ${TDXIMG} | cut -d _ -f 1` 				# Get the date
							TDXSAT=`echo ${TDXIMG} | cut -d _ -f 2 | cut -d. -f1` 	# Get the sat (TSXi or TDXi)
							TDXMODE=`echo ${TDXIMG} | cut -d . -f 2` 				# Get the master or slave mode
					
							# if more than one image with the same date 
							TDXDIRENDNAME=`echo "${PAIRSTDX}" | cut -d _ -f 2-4` 			# Get the end of dir name (eg TDM_PM). Set f at 2-4 instead of 2-3 just in case
																							# there is more than one img and hence end with _n  (eg TDM_PM_2)
							TDXDUPLICATETMP=`echo "${PAIRSTDX}" | cut -d _ -f 4` 	  		# Get the dupliation nr in case of several img on the same day  (2 from example above)

							if [ "${TDXDUPLICATETMP}" == "" ]					  				# now in the form of _n  (_2 from example above if duplicates exists)
								then 
									TDXDUPLICATE=""
								else 
									TDXDUPLICATE=_${TDXDUPLICATETMP}
							fi
													 
							TDXBIS=`echo ${TDXDIRENDNAME} | cut -d_ -f 2` # Get Bistatic (BS) or Poursuite Mode (PM)

							TDXSCENEID=`updateParameterFile ${TDXIMGPATH}/Info/SLCImageInfo.txt "Scene ID"`
							TDXSCENELOC=`updateParameterFile ${TDXIMGPATH}/Info/SLCImageInfo.txt "Scene location"`
							TDXORBMODE=`echo ${TDXSCENEID} | cut -d_ -f3` 	# A or D
							echo "Scene ID is: ${TDXSCENEID}"
							TDXORBNR=`echo "${TDXSCENEID}" | ${PATHGNU}/grep -Eo "_[0-9]{3}_" ` # select _ORBnr_, that is the only number of 3 digits framed by _ in the scene ID

							TDXBW=`updateParameterFile ${TDXIMGPATH}/Info/SLCImageInfo.txt "Range bandwidth" ` # band width in Hz
							TDXBWMHZ=`echo "(${TDXBW} /1000000)" | bc  ` # band width in Mhz

							TDXCENTERLON=`echo ${TDXSCENELOC} | cut -d: -f2 | ${PATHGNU}/grep -Eo '[+-]?[0-9]+([.][0-9]+)?' | tr '\n' ' ' | tr -d '[:space:]'; echo "" ` # select Long as integer with sign
							TDXCENTERLAT=`echo ${TDXSCENELOC} | cut -d: -f3 | ${PATHGNU}/grep -Eo '[+-]?[0-9]+([.][0-9]+)?' | tr '\n' ' ' | tr -d '[:space:]'; echo "" ` # select Lat as integer with sign

							if [ ${TDXMODE} == "master" ] ; then TDXCODE=TX ; else TDXCODE=RX ; fi
					
							TDXDIR=${PARENTCSL}_${TDXBWMHZ}Mhz_${TDXBIS}_${TDXORBMODE}${TDXORBNR}${TDXCODE}${TDXDUPLICATE}/NoCrop

							if [ ! -d ${TDXDIR}/${TDXIMG} ]
								then
									echo "Center of ${TDXDATE}_${TDXORBMODE}${TDXORBNR}${TDXBWMHZ}Mhz_${TDXBIS}${TDXDUPLICATE} Scene  Lat: ${TDXCENTERLAT}  Long: ${TDXCENTERLON}" >> Center_Of_Scene.txt
									mkdir -p ${TDXDIR}

									# There is no  ${PARENTCSL}_${TDXORBMODE}_${TDXORBNR}_Lat${TDXCENTERLAT}_Long${TDXCENTERLON}_${TDXCODE}/NoCrop/${TDXIMG} DIR yet, hence it is a new img; move new img there
									mv ${TDXIMGPATH} ${TDXDIR}/${TDXDATE}.csl 
									#and create a link
									ln -s ${TDXDIR}/${TDXDATE}.csl ${CSL}/${TDXDATE}_${TDXDIRENDNAME}/${TDXDATE}_${TDXSAT}.${TDXMODE}.csl
									echo "Last created MasTer Engine source dir suggest reading with ME version: ${LASTVERSIONCIS}" > ${TDXDIR}/${TDXDATE}.csl/${TDXDATE}/Read_w_MasTerEngine_V.txt							
							fi  
					fi	# test old or recent format						
			done	
			echo

		;;
	"ICEYE")
		PARENTCSL="$(dirname "$CSL")"  # get the parent dir, one level up
		REGION=`basename ${PARENTCSL}`
		# Check if links in ${PARENTCSL} points toward files (must be in ${PARENTCSL}_${ICYMODE}_${ICYTRK}_${ICYINCID}deg/NoCrop/)
		# if not, remove broken link
		EchoTee "Remove possible broken links"
		for LINKS in `ls -d *.csl 2> /dev/null`
			do
				find -L ${LINKS} -type l ! -exec test -e {} \; -exec rm {} \; # first part stays silent if link is ok (or is not a link but a file or dir); answer the name of the link if the link is broken. Second part removes link if broken 
		done
			
		if [ "${FAY}" == "ForceAllYears" ]
			then 
				EchoTeeYellow "Read all images in ${RAW}"
				ICEYEDataReader ${RAW} ${CSL} -r
			else 
				EchoTeeYellow "Read only new images in ${RAW} not yet in ${PARENTCSL}"
				ICEYEDataReader ${RAW} ${CSL} 
		fi
		EchoTee ""
		EchoTee "All ICEYE img read; now sorting them by mode, track and incidence "
		EchoTee ""
		cd ${CSL}
		for ICYIMGPATH in `find ${CSL} -name "*.csl" -print`  # list actually the former links and the new dir if new images were read
			do
				ICYIMG=`echo ${ICYIMGPATH##*/}` 				# Trick to get only name without path
				ICYDATE=`updateParameterFile ${ICYIMGPATH}/Info/SLCImageInfo.txt "Acquisition date"` 					# Get date
				ICYMODE=`updateParameterFile ${ICYIMGPATH}/Info/SLCImageInfo.txt "Heading direction" | cut -c 1` 		# Get the orbit mode (Asc or Des)
				ICYTYPE=`updateParameterFile ${ICYIMGPATH}/Info/SLCImageInfo.txt "Product ID"` 						# Stripmap or SpotlightHigh
				ICYLOOK=`updateParameterFile ${ICYIMGPATH}/Info/SLCImageInfo.txt "Look direction" | cut -c 1` 		# L(eft) or R(ight)
				ICYINCID=`updateParameterFile ${ICYIMGPATH}/Info/SLCImageInfo.txt "Incidence angle at median slant range" | $PATHGNU/gawk '{print int($1+0.5)}' ` 		# incidence angle (rounded)
				ICYTRK=${ICYTYPE}_${ICYLOOK}L
				mkdir -p ${PARENTCSL}_${ICYMODE}_${ICYTRK}_${ICYINCID}deg/NoCrop
				if [ ! -d ${PARENTCSL}_${ICYMODE}_${ICYTRK}_${ICYINCID}deg/NoCrop/${ICYDATE}.csl ]
					then
						# There is no  ${PARENTCSL}_${ICYMODE}_${ICYTRK}_${ICYINCID}deg/NoCrop/${ICYDATE}.csl DIR yet, hence it is a new img; move new img there
							mv ${ICYIMG} ${PARENTCSL}_${ICYMODE}_${ICYTRK}_${ICYINCID}deg/NoCrop/${ICYDATE}.csl 
							#and create a link
							ln -s ${PARENTCSL}_${ICYMODE}_${ICYTRK}_${ICYINCID}deg/NoCrop/${ICYDATE}.csl ${CSL}/${ICYIMG} 
							echo "Last created MasTer Engine source dir suggest reading with ME version: ${LASTVERSIONCIS}" > ${PARENTCSL}_${ICYMODE}_${ICYTRK}_${ICYINCID}deg/NoCrop/${ICYDATE}.csl/Read_w_MasTerEngine_V.txt
				fi  
		done
		echo 		
		;; 		
	*) 	# Do not use Bulk Reader; compare instead with existing images and read only teh new ones
		# Read existing raw archives
		ls ${RAW}* | ${PATHGNU}/grep -v ".txt" | ${PATHGNU}/grep -v ".png" | ${PATHGNU}/grep -v ".tmp" | ${PATHGNU}/grep -v ".dat"  | ${PATHGNU}/grep -v ".gz" | ${PATHGNU}/grep -v ".sh" | ${PATHGNU}/grep -v ".zip"> List_raw.txt

		# read images already in csl format
		case ${SAT} in
			"ENVISAT") 
				# Need the dir and date for comarison
				ls ${CSL} | ${PATHGNU}/grep -v ".txt" > List_csl_dates.txt
				echo "Ignore error msg below vvvvvvvv (ls: cannot access '*.N1': No such file or directory)"
				for DATECSL in `cat -s List_csl_dates.txt`
					do	
						DATE=`echo ${DATECSL} | cut -d . -f 1`
						ls -R ${RAW} *.N1 | ${PATHGNU}/grep ${DATE} | cut -d _ -f7 >> List_csl.txt
					done
				echo "Ignore error msg above ^^^^^^"
					;;
			*) 	
				#ls ${CSL}/* | ${PATHGNU}/grep -v ".txt" > List_csl.txt
				ls ${CSL} | ${PATHGNU}/grep -v ".txt" > List_csl.txt
				;;
		esac

		# Search for only the new ones to be processed:
		#    In List_csl.txt names are date.csl, 
		#    while in List_raw.txt names are a complex dir name that includes date somewhere
		cp -f List_raw.txt Img_To_Read.txt
		for LINE in `cat -s List_csl.txt`
			do	
				DATE=`echo ${LINE} | cut -d . -f1`
				grep -v ${DATE} Img_To_Read.txt > Img_To_Read_tmp.txt
				cp -f Img_To_Read_tmp.txt Img_To_Read.txt
			done
		rm -f Img_To_Read_tmp.txt

		EchoTee ""
		EchoTee "Reading..."
		for IMGDIR in `cat -s Img_To_Read.txt`
		do	
				case ${SAT} in
					"RADARSAT") 
								IMG=`GetDate ${IMGDIR}`
								RSAT2DAtaReader ${CSL}/Read_${IMG}.txt -create
								ChangeInPlace PathToRSAT2Directory ${RAW}/${IMGDIR}  ${CSL}/Read_${IMG}.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}.txt
								RSAT2DAtaReader ${CSL}/Read_${IMG}.txt	
								echo "Last created MasTer Engine source dir suggest reading with ME version: ${LASTVERSIONCIS}" > ${CSL}/${IMG}/Read_w_MasTerEngine_V.txt
								EchoTee "Image ${IMG} red"
								;;
					"CSK") 
								IMG=`GetDate ${IMGDIR}`
								CSKDataReader ${CSL}/Read_${IMG}.txt -create
								ChangeInPlace PathToHDF5File ${RAW}/${IMGDIR}/*.h5  ${CSL}/Read_${IMG}.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}.txt
								CSKDataReader ${CSL}/Read_${IMG}.txt
								TRKHEADING=`updateParameterFile ${CSL}/${IMG}.csl/Info/SLCImageInfo.txt Heading | cut -d c -f1`
								TRKHEADING=${TRKHEADING}c
								SCENELOCATION=`updateParameterFile ${CSL}/${IMG}.csl/Info/SLCImageInfo.txt "Scene location"`
								echo "Last created MasTer Engine source dir suggest reading with ME version: ${LASTVERSIONCIS}" > ${CSL}/${IMG}/Read_w_MasTerEngine_V.txt
								EchoTee " Track of ${IMG} : ${TRKHEADING}" 
								EchoTee "Image ${IMG} red"
								EchoTee "Image ${IMG} : ${TRKHEADING}  : ${SCENELOCATION}" >> List_Files_Trk_Location_${RUNDATE}.txt
								;;
					"TSX") 
								IMG=`GetDate ${IMGDIR}`
								if
									test -d ${RAW}/${IMGDIR}/TSX-1.SAR.L1B
									then 
										TSXDIR=`cd ${RAW}/${IMGDIR}/TSX-1.SAR.L1B/; ls -d $PWD/T*/`	
										TSXDIR=`echo ${TSXDIR} | ${PATHGNU}/gsed -e 's/\/$//g'`    # need to remove ending slash
											 # Actual path to the data. 
											 # NB: This assumes there is only one subdir that starts with T in the Terrasar data dir
									else 
										TSXDIR=`cd ${RAW}/${IMGDIR}/; ls -d $PWD/T*/`	
										TSXDIR=`echo ${TSXDIR} | ${PATHGNU}/gsed -e 's/\/$//g'`    # need to remove ending slash
											 # Actual path to the data. 
											 # NB: This assumes there is only one subdir that starts with T in the Terrasar data dir
								fi

								TSXDataReader ${CSL}/Read_${IMG}.txt -create
								ChangeInPlace PathToTSXDir ${TSXDIR} ${CSL}/Read_${IMG}.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}.txt
								TSXDataReader ${CSL}/Read_${IMG}.txt
								echo "Last created MasTer Engine source dir suggest reading with ME version: ${LASTVERSIONCIS}" > ${CSL}/${IMG}/Read_w_MasTerEngine_V.txt
								EchoTee "Image ${IMG} red"
								;;
# 					"TSXfromTDX") 
# 								IMG=`GetDate ${IMGDIR}`
# 								if
# 									test -d ${RAW}/${IMGDIR}/TSX-1.SAR.L1B
# 									then 
# 										ls -d ${RAW}/${IMGDIR}/TSX-1.SAR.L1B/T*/ > tmp.txt	
# 									else 
# 										ls -d ${RAW}/${IMGDIR}/T*/ > tmp.txt	
# 								fi
# 								TSXDIR_BTX=`grep BTX tmp.txt | ${PATHGNU}/gsed -e 's/\/$//g'`    # need to remove ending slash
# 						
# 								# Read first (Transmit) image
# 								TSXDataReader ${CSL}/Read_${IMG}_BTX.txt -create
# 								ChangeInPlace "NO        " "YES      " ${CSL}/Read_${IMG}_BTX.txt
# 								ChangeInPlace PathToTSXDir ${TSXDIR_BTX} ${CSL}/Read_${IMG}_BTX.txt
# 								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}_BTX.txt
# 								# if 
# 		# 							test ! -d ${CSL}/BTX/
# 		# 							then 
# 		# 								mkdir ${CSL}/BTX/
# 		# 						fi
# 								TSXDataReader ${CSL}/Read_${IMG}_BTX.txt
# 								EchoTee "Frist Image ${IMG}_BTX red"
# 								;;
					"ENVISAT") 
								IMG=`GetDateEnvisat ${RAW}/${IMGDIR}`
								EnviSATDataReader ${CSL}/Read_${IMG}.txt -create
								EchoTee "${RAW}/${IMGDIR}/*.N1"
								ChangeInPlace PathToEnviSATDataFile ${RAW}/${IMGDIR}/*.N1 ${CSL}/Read_${IMG}.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}.txt
								ChangeInPlace DORIS_DirectoryPath ${ENVORB} ${CSL}/Read_${IMG}.txt
								EnviSATDataReader ${CSL}/Read_${IMG}.txt
								echo "Last created MasTer Engine source dir suggest reading with ME version: ${LASTVERSIONCIS}" > ${CSL}/${IMG}/Read_w_MasTerEngine_V.txt
								EchoTee "Image ${IMG} red"
								;;
					"ERS") 
								IMG=`GetDateERS ${RAW}/${IMGDIR}`
								ERSDataReader ${CSL}/Read_${IMG}.txt -create
								#EchoTee "${RAW}/${IMGDIR}/*.N1"
								ChangeInPlace PathToDirectory ${RAW}/${IMGDIR}/SCENE1 ${CSL}/Read_${IMG}.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}.txt
								#ChangeInPlace DORIS_DirectoryPath ${ENVORB} ${CSL}/Read_${IMG}.txt
								ERSDataReader ${CSL}/Read_${IMG}.txt
								echo "Last created MasTer Engine source dir suggest reading with ME version: ${LASTVERSIONCIS}" > ${CSL}/${IMG}/Read_w_MasTerEngine_V.txt
								EchoTee "Image ${IMG} red"
								;;
								
					"ALOS2") 
								IMG=`GetDateALOS2 ${RAW}/${IMGDIR}`
								ALOSDataReader ${CSL}/Read_${IMG}.txt -create
								ChangeInPlace PathToDirectory ${RAW}/${IMGDIR}  ${CSL}/Read_${IMG}.txt
								VOLALPSR=`basename ${RAW}/${IMGDIR}/VOL-ALOS*`
								ChangeInPlace "VOL-ALPSR..." ${VOLALPSR} ${CSL}/Read_${IMG}.txt
								ChangeInPlace outputFilePath ${CSL}/${IMG} ${CSL}/Read_${IMG}.txt
								ALOSDataReader ${CSL}/Read_${IMG}.txt
								echo "Last created MasTer Engine source dir suggest reading with ME version: ${LASTVERSIONCIS}" > ${CSL}/${IMG}/Read_w_MasTerEngine_V.txt
								EchoTee "Image ${IMG} red"
								;;
					#"S1") 		EchoTee "Using here the native bulk reader for S1"
					#			;;	

# Prefer Bulk reader					
# 					"SAOCOM") 
# 								IMG=`GetDate ${IMGDIR}`
# 								SAOCOMDataReader ${CSL}/Read_${IMG}.txt -create
# 								ChangeParamRead "SAOCOM data directory path (directory containing the manifest.safe file)" ${RAW}/${IMGDIR}/*.h5 
# 								ChangeParamRead "outputFilePath" ${CSL}/${IMG} 
# 								SAOCOMDataReader ${CSL}/Read_${IMG}.txt
# 								TRKHEADING=`updateParameterFile ${CSL}/${IMG}.csl/Info/SLCImageInfo.txt Heading | cut -d c -f1`
# 								TRKHEADING=${TRKHEADING}c
# 								SCENELOCATION=`updateParameterFile ${CSL}/${IMG}.csl/Info/SLCImageInfo.txt "Scene location"`
# 								EchoTee " Track of ${IMG} : ${TRKHEADING}" 
# 								EchoTee "Image ${IMG} red"
# 								EchoTee "Image ${IMG} : ${TRKHEADING}  : ${SCENELOCATION}" >> List_Files_Trk_Location_${RUNDATE}.txt
# 								;;								
				esac	
		done
		;;
esac
#fi

if [ "${REPLAY}" == "ReplayYes" ] 
	then 
		EchoTeeRed "Seems that you encountered problems with missing orbits. Try to relaunch current script"
		# First one need to neutralize the replay possibility to avoid infinite loop
		${PATHGNU}/gsed "s/REPLAY=ReplayYes/REPLAY=ReplayNo/" $(dirname $0)/${PRG} >  TMP_${PRG}
		 chmod +x TMP_${PRG}
		 ./TMP_${PRG} ${RAW} ${CSL} ${SAT} ${KMLS1} ${FAY} 
		 rm TMP_${PRG}
		# Flag to avoid infinite loop in case of unsolvable problme
		EchoTeeRed "Hope that re-reading the images after new orbits download(s) helped..."

fi
echo

# remove old logs > MAXLOG defined below (in days), e.g. 60 days or any other value
MAXLOG=40

cd ${CSL}
find . -maxdepth 1 -name "LogFile_ReadAll_*.txt" -type f -mtime +${MAXLOG} -exec rm -f {} \;
if [ ${SAT} = "S1" ] ; then 
	find . -maxdepth 1 -name "NoPreciseOrbitsFoundFor_*.txt" -type f -mtime +${MAXLOG} -exec rm -f {} \;
	find . -maxdepth 1 -name "ORB_CleanMASSPROCESS_*.txt" -type f -mtime +${MAXLOG} -exec rm -f {} \;
	find . -maxdepth 1 -name "ORB_CleanRESAMPLED_*.txt" -type f -mtime +${MAXLOG} -exec rm -f {} \;	
	find . -maxdepth 1 -name "OrbitsToDownload_*.txt" -type f -mtime +${MAXLOG} -exec rm -f {} \;
	find . -maxdepth 1 -name "S1DataReaderLog_*.txt" -type f -mtime +${MAXLOG} -exec rm -f {} \;
	find . -maxdepth 1 -name "S1OrbitUpdaterLog_*.txt" -type f -mtime +${MAXLOG} -exec rm -f {} \;
	find . -maxdepth 1 -name "List_IMG_pol_HH_*.txt" -type f -mtime +${MAXLOG} -exec rm -f {} \;

fi

# For S1 images, check if images exist with pol  different from INITPOL
#if [ ${SAT} = "S1" ] ; then 
	# Read S1DataReaderLog.txt and search for images without INIPO
#fi

EchoTee "------------------------------------"
EchoTee "All img read"
EchoTee "------------------------------------"

