#!/bin/bash
# Script to run in cronjob for processing Einstein Telescope Site images:
# Runs a mass processing after having checked that no other process is using the same param file (on this computer). 
#
# NOTE: because Einstein_S1_Step1_Read_SMCoreg_Pairs.sh uses RadAll_Img.sh, which also move updated prelim orbit images at all levels in _CLN dir,
#       and coregister images on super masters, one check that it is not running anymore before starting.
#
#
# New in Distro V 2.0.0 20201104 :	- move all parameters at the beginning
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------
source $HOME/.bashrc

cd
TODAY=`date`

echo "Starting $0"

# Some variables 
################

# Max  baseline (for buliding msbas files)
BP=20
BT=400

STEP1="Einstein_S1_Step1_Read_SMCoreg_Pairs.sh"

# some files and PATH
#####################
TABLEASC=$PATH_1650/SAR_SM/MSBAS/Einstein/set1/table_0_${BP}_0_${BT}.txt
TABLEDESC=$PATH_1650/SAR_SM/MSBAS/Einstein/set3/table_0_${BP}_0_${BT}.txt
#TABLEDESC2=$PATH_1650/SAR_SM/MSBAS/Einstein/set4/table_0_${BP}_0_${BT}.txt

PARAMPROCESSASC=$PATH_1650/Param_files_SuperMaster/S1/Einstein_A_88/LaunchCISparam_S1_Einstein_A_88_Zoom1_ML2_MassProc.txt
PARAMPROCESSDESC=$PATH_1650/Param_files_SuperMaster/S1/Einstein_D_37/LaunchCISparam_S1_Einstein_D_37_Zoom1_ML2_MassProc.txt
#PARAMPROCESSDESC2=$PATH_1650/Param_files_SuperMaster/S1/Einstein_D_139/LaunchCISparam_S1_Einstein_D_139_Zoom1_ML2_MassProc.txt

MASSPROCESSASCDIR=$PATH_3602/SAR_MASSPROCESS_2/S1/Einstein_A_88/SMNoCrop_SM_20200822_Zoom1_ML2
MASSPROCESSDESCDIR=$PATH_3602/SAR_MASSPROCESS_2/S1/Einstein_D_37/SMNoCrop_SM_20181110_Zoom1_ML2
#MASSPROCESSDESCDIR2=$PATH_3602/SAR_MASSPROCESS_2/S1/Einstein_D_139/SMNoCrop_SM_20181211_Zoom1_ML2


# Prepare stuffs
################
PARAMASCNAME=`basename ${PARAMPROCESSASC}`
PARAMDESCNAME=`basename ${PARAMPROCESSDESC}`
#PARAMDESCNAME2=`basename ${PARAMPROCESSDESC2}`

# Check that no other processes are running
###########################################

# Check that Step 1 (Read and Coreg) is finished
CHECKREAD=`ps -eaf | ${PATHGNU}/grep ${STEP1} | ${PATHGNU}/grep -v "grep " | wc -l`

# Let's go
##########
if [ ${CHECKREAD} -eq 0 ] 
	then 
		# OK, no more Step1 is running: 
		# Check that no other SuperMaster automatic Ascending and Desc mass processing uses the LaunchCISparam_.txt yet
		CHECKASC=`ps -eaf | ${PATHGNU}/grep SuperMaster_MassProc.sh | ${PATHGNU}/grep -v "grep "  | ${PATHGNU}/grep ${PARAMASCNAME} | wc -l`
		CHECKDESC=`ps -eaf | ${PATHGNU}/grep SuperMaster_MassProc.sh | ${PATHGNU}/grep -v "grep " | ${PATHGNU}/grep ${PARAMDESCNAME} | wc -l`
		#CHECKDESC2=`ps -eaf | ${PATHGNU}/grep SuperMaster_MassProc.sh | ${PATHGNU}/grep -v "grep " | ${PATHGNU}/grep ${PARAMDESCNAME2} | wc -l`

		if [ ${CHECKASC} -lt 1 ] 
			then 
				# No process running yet
				if [ ! -s  ${MASSPROCESSASCDIR}/_Asc_last_MassRun.txt ] ; then touch ${MASSPROCESSASCDIR}/_Asc_last_MassRun.txt ; fi
					echo "Asc run on ${TODAY}"  >>  ${MASSPROCESSASCDIR}/_Asc_last_MassRun.txt
				$PATH_SCRIPTS/SCRIPTS_OK/SuperMaster_MassProc.sh ${TABLEASC} ${PARAMPROCESSASC} > /dev/null 2>&1 &
			else 
				echo "Asc attempt aborted on ${TODAY} because other Mass Process in progress"  >>  ${MASSPROCESSASCDIR}/_Asc_last_aborted.txt
		fi
		# if running yet we will try again tomorrow

		if [ ${CHECKDESC} -lt 1 ] 
			then 
				# No process running yet
				if [ ! -s  ${MASSPROCESSASCDIR}/_Desc_last_Mass.txt ] ; then touch ${MASSPROCESSASCDIR}/_Desc_last_Mass.txt ; fi
					echo "Desc run on ${TODAY}"  >>  ${MASSPROCESSDESCDIR}/_Desc_last_Mass.txt
				$PATH_SCRIPTS/SCRIPTS_OK/SuperMaster_MassProc.sh ${TABLEDESC} ${PARAMPROCESSDESC} > /dev/null 2>&1 &
			else 
				echo "Desc attempt aborted on ${TODAY} because other Mass Process in progress"  >>  ${MASSPROCESSDESCDIR}/_Desc_last_aborted.txt
		fi
# 		if [ ${CHECKDESC2} -lt 1 ] 
# 			then 
# 				# No process running yet
# 				echo "Desc run on ${TODAY}"  >>  ${MASSPROCESSDESCDIR2}/_Desc_last_Mass.txt
# 				$PATH_SCRIPTS/SCRIPTS_OK/SuperMaster_MassProc.sh ${TABLEDESC2} ${PARAMPROCESSDESC2} > /dev/null 2>&1 &
# 			else 
# 				echo "Desc attempt aborted on ${TODAY} because other Mass Process in progress"  >>  ${MASSPROCESSDESCDIR2}/_Desc_last_aborted.txt
# 		fi

	else 
		# Step1 is still running: abort and wait for tomorrow
		echo "Step2 aborted on ${TODAY} because ${STEP1} is still running: wait for tomorrow"  >>  ${MASSPROCESSASCDIR}/_aborted_because_Read_inProgress.txt
		echo "Step2 aborted on ${TODAY} because ${STEP1} is still running: wait for tomorrow"  >>  ${MASSPROCESSDESCDIR}/_aborted_because_Read_inProgress.txt
#		echo "Step2 aborted on ${TODAY} because ${STEP1} is still running: wait for tomorrow"  >>  ${MASSPROCESSDESCDIR2}/_aborted_because_Read_inProgress.txt

		exit 0
fi

