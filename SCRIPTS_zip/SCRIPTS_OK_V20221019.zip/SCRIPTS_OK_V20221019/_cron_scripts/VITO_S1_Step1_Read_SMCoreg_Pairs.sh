#!/bin/bash
# Script to run in cronjob for processing Waremme region (Be) :
# Read images, corigister them on a super master and compute the compatible pairs.
# It also creates a common baseline plot for  ascending and descending modes. 
#
# NOTE:	This script requires several adjustments in script body if transferred to another target. 
#		See all infos about Tracks and Sets
#
# New in Distro V 2.0.0 20201104 :	- move most of the parameters at the beginning
# New in Distro V 2.0.0 20220602 :	- use new Prepa_MSBAS.sh compatible with D Derauw and L. Libert tools for Baseline Ploting
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------

source $HOME/.bashrc

# Some variables 
################
# Max  baseline (for buliding msbas files)
BP=20
BT=400

#super masters
SMASC1=20200822		# A_88
SMASC2=20190417		# A_161

SMDESC1=20181110		# D_37
#SMDESC2=20181211		# D_139

# DO NOT FORGET TO ADJUST ALSO THE SET BELOWS IN SCRIPT

# some files and PATH
#####################
#SAR_DATA
DIRSARDATA=$PATH_3600/SAR_DATA/S1/S1-DATA-LUXEMBOURG-SLC.UNZIP
#SAR_CSL
DIRSARCSL=$PATH_3601/SAR_CSL_Other_Zones/S1/VITO
#SETi DIR
DIRSET=$PATH_1650/SAR_SM/MSBAS/VITO

#kml file
KMLFILE=$PATH_3601/SAR_CSL_Other_Zones/S1/VITO/VITO.kml

#Launch param files
PARAMCOREGASC1=$PATH_1650/Param_files_SuperMaster/S1/VITO_A_88/LaunchCISparam_S1_VITO_A_88_Zoom1_ML2_Coreg.txt 
#PARAMCOREGASC2=$PATH_1650/Param_files_SuperMaster/S1/VITO_A_161/LaunchCISparam_S1_VITO_A_161_Zoom1_ML2_Coreg.txt

PARAMCOREGDESC1=$PATH_1650/Param_files_SuperMaster/S1/VITO_D_37/LaunchCISparam_S1_VITO_D_37_Zoom1_ML2_Coreg.txt

NEWASCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/VITO_A_88/SMNoCrop_SM_${SMASC1}
NEWDESCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/VITO_D_37/SMNoCrop_SM_${SMDESC1}

#Color table 
#COLORTABLE=$PATH_SCRIPTS/SCRIPTS_OK/ColorTable_AADD.txt	# for 4 data sets
#COLORTABLE=$PATH_SCRIPTS/SCRIPTS_OK/ColorTable_ADD.txt	# for 3 data sets
COLORTABLE=$PATH_SCRIPTS/SCRIPTS_OK/ColorTable_AD.txt	# for 2 data sets

# Prepare stuffs
################
echo "Starting $0" > ${DIRSARCSL}/Last_Run_Cron_Step1.txt
date >> ${DIRSARCSL}/Last_Run_Cron_Step1.txt

# Let's go
##########

# Read all S1 images for that footprint
$PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh ${DIRSARDATA} ${DIRSARCSL}/NoCrop S1 ${KMLFILE} > /dev/null 2>&1
#$PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh ${DIRSARDATA} ${DIRSARCSL}/NoCrop S1 ${KMLFILE} ForceAllYears > /dev/null 2>&1

# Coregister all images on the super master 
# in Ascending mode 
$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh ${PARAMCOREGASC1} &
#$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh ${PARAMCOREGASC2} &

wait

# in Descending mode 
$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh ${PARAMCOREGDESC1} &

 
# Search for pairs
##################
# Link all images to corresponding set dir
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh ${DIRSARCSL}_A_88/NoCrop ${DIRSET}/set1 S1 > /dev/null 2>&1  &
#$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh ${DIRSARCSL}_A_161/NoCrop ${DIRSET}/set2 S1 > /dev/null 2>&1  &
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh ${DIRSARCSL}_D_37/NoCrop ${DIRSET}/set3 S1 > /dev/null 2>&1  &

wait

# Compute pairs 
# Compute pairs only if new data is identified
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh ${DIRSET}/set1 ${BP} ${BT} ${SMASC1} > /dev/null 2>&1  &
#	echo "n" | Prepa_MSBAS.sh ${DIRSET}/set2 ${BP} ${BT} ${SMASC2} > /dev/null 2>&1  &
fi
if [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh ${DIRSET}/set3 ${BP} ${BT} ${SMDESC1} > /dev/null 2>&1  &
fi
wait

# Plot baseline plot with all modes 
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] || [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 

	if [ `baselinePlot | wc -l` -eq 0 ] 
		then
			# use MasTer Engine before May 2022
			mkdir -p ${DIRSET}/BaselinePlots_S1_set_1_3
			cd ${DIRSET}/BaselinePlots_S1_set_1_3

			echo "${DIRSET}/set1" > ModeList.txt
		#	echo "${DIRSET}/set2" >> ModeList.txt
			echo "${DIRSET}/set3" >> ModeList.txt
		##	echo "${DIRSET}/set4" >> ModeList.txt

			$PATH_SCRIPTS/SCRIPTS_OK/plot_Multi_span.sh ModeList.txt 0 ${BP} 0 ${BT} ${COLORTABLE}
		else
			# use MasTer Engine > May 2022
			mkdir -p ${DIRSET}/BaselinePlots_set1_set3
			cd ${DIRSET}/BaselinePlots_set1_set3
 
			echo "${DIRSET}/set1" > ModeList.txt
			echo "${DIRSET}/set3" >> ModeList.txt
 
			plot_Multi_BaselinePlot.sh ${DIRSET}/BaselinePlots_set1_set3/ModeList.txt
 	fi			
fi

echo "Ending $0" >> ${DIRSARCSL}/Last_Run_Cron_Step1.txt
date >> ${DIRSARCSL}/Last_Run_Cron_Step1.txt




