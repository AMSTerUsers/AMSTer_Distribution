#!/bin/bash
# Script to run in cronjob for processing VVP images:
# Read images, check if nr of bursts and corners coordinates are OK, 
# corigister them on a super master and compute the compatible pairs.
# It also creates a common baseline plot for  ascending and descending modes. 

# New in Distro V 2.0.0 20220517 :	-use new Prepa_MSBAS.sh based on DD tools instead of L. Libert tools
# New in Distro V 2.1.0 20220602 :	- use new Prepa_MSBAS.sh compatible with D Derauw and L. Libert tools for Baseline Ploting
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------


source $HOME/.bashrc

BP=20
NEWASCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/DRC_VVP_A_174/SMNoCrop_SM_20150310
NEWDESCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/DRC_VVP_D_21/SMNoCrop_SM_20151014


# Read all S1 images for that footprint
#######################################
 $PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh $PATH_3600/SAR_DATA/S1/S1-DATA-DRCONGO-SLC.UNZIP $PATH_1650/SAR_CSL/S1/DRC_VVP/NoCrop S1 $PATH_1650/SAR_CSL/S1/DRC_VVP/VVP.kml > /dev/null 2>&1

# Check nr of bursts and coordinates of corners. If not as expected, move img in temp quatantine and log that. Check regularily: if not updated after few days, it means that image is bad or zip file not correctly downloaded
################################################
# Asc ; bursts size and coordinates are obtained by running e.g.:  _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/DRC_VVP_A_174/NoCrop/S1B_174_20210928_A.csl Dummy
_Check_ALL_S1_SizeAndCoord_InDir.sh $PATH_1650/SAR_CSL/S1/DRC_VVP_A_174/NoCrop 16 28.7532 -2.4225 30.2811 -2.0896 28.4441 -0.9607 29.9705 -0.6309 

# Desc ; bursts size and coordinates are obtained by running e.g.: _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/DRC_VVP_D_21/NoCrop/S1B_21_20211105_D.csl Dummy
# Beware D21 are using 17 or 18 burst. The 18th to the SW is however useless, hence check on range from 17 bursts then check the images in __TMP_QUARANTINE with 18 bursts coordinates. 
#        If OK, put them back in NoCrop dir. If not, keep them in original __TMP_QUARANTINE
_Check_ALL_S1_SizeAndCoord_InDir.sh $PATH_1650/SAR_CSL/S1/DRC_VVP_D_21/NoCrop 17 30.4780 -1.0622 28.2704 -0.5847 30.1797 -2.4732 27.9701 -1.9911

_Check_ALL_S1_SizeAndCoord_InDir.sh $PATH_1650/SAR_CSL/S1/DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE 18 30.4842 -1.0624  28.2689 -0.5833 30.1857 -2.4740 27.9684 -1.9903
	mv $PATH_1650/SAR_CSL/S1/DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE/*.csl $PATH_1650/SAR_CSL/S1/DRC_VVP_D_21/NoCrop/ 2>/dev/null
	mv $PATH_1650/SAR_CSL/S1/DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE/__TMP_QUARANTINE/*.csl $PATH_1650/SAR_CSL/S1/DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE/ 2>/dev/null
	mv $PATH_1650/SAR_CSL/S1/DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE/*.txt $PATH_1650/SAR_CSL/S1/DRC_VVP_D_21/NoCrop/ 2>/dev/null
	rm -R $PATH_1650/SAR_CSL/S1/DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE/__TMP_QUARANTINE 2>/dev/null

# Coregister all images on the super master 
###########################################
# in Ascending mode 
 $PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/S1/DRC_VVP_Asc_A_174/LaunchCISparam_S1_VVP_Asc_Zoom1_ML8_snaphu_square_Coreg.txt &
# in Descending mode 
 $PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/S1/DRC_VVP_D_21/LaunchCISparam_S1_VVP_Desc21_Zoom1_ML8_snaphu_square_Coreg.txt &



# Search for pairs
##################
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_1650/SAR_CSL/S1/DRC_VVP_A_174/NoCrop $PATH_1650/SAR_SM/MSBAS/VVP/set6 S1 > /dev/null 2>&1  &
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_1650/SAR_CSL/S1/DRC_VVP_D_21/NoCrop $PATH_1650/SAR_SM/MSBAS/VVP/set7 S1 > /dev/null 2>&1 &
wait

# Compute pairs only if new data is identified
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/VVP/set6 ${BP} 400 20150310 > /dev/null 2>&1  &
fi
if [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/VVP/set7 ${BP} 400 20151014 > /dev/null 2>&1  &
fi
wait

# Plot baseline plot with both modes 
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] || [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 

	if [ `baselinePlot | wc -l` -eq 0 ] 
		then
			# use MasTer Engine before May 2022	
			mkdir -p $PATH_1650/SAR_SM/MSBAS/VVP/BaselinePlots_set6_set7
			cd $PATH_1650/SAR_SM/MSBAS/VVP/BaselinePlots_set6_set7

			echo "$PATH_1650/SAR_SM/MSBAS/VVP/set6" > ModeList.txt
			echo "$PATH_1650/SAR_SM/MSBAS/VVP/set7" >> ModeList.txt

			plot_Multi_BaselinePlot.sh $PATH_1650/SAR_SM/MSBAS/VVP/BaselinePlots_set6_set7/ModeList.txt
		else
			# use MasTer Engine > May 2022
			mkdir -p $PATH_1650/SAR_SM/MSBAS/VVP/BaselinePlots_set6_set7
			cd $PATH_1650/SAR_SM/MSBAS/VVP/BaselinePlots_set6_set7
 
			echo "$PATH_1650/SAR_SM/MSBAS/VVP/set6" > ModeList.txt
			echo "/$PATH_1650/SAR_SM/MSBAS/VVP/set7" >> ModeList.txt
 
			plot_Multi_BaselinePlot.sh $PATH_1650/SAR_SM/MSBAS/VVP/BaselinePlots_set6_set7/ModeList.txt
 	fi

fi

