#!/bin/bash
# Script to run in cronjob for processing VVP images:
# Read images, corigister them on a super master and compute the compatible pairs.
# It also creates a common baseline plot for  ascending and descending modes. 

# New in Distro V 2.0.0 20220602 :	- use new Prepa_MSBAS.sh compatible with D Derauw and L. Libert tools for Baseline Ploting
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------
source $HOME/.bashrc

# ADAPT HERE BELOW
DWNLOADDIR=Auto_Curl

BP=150
NEWASCPATH=$PATH_1650/SAR_SM/RESAMPLED/CSK/Virunga_Asc/SMNoCrop_SM_20160627
NEWDESCPATH=$PATH_1650/SAR_SM/RESAMPLED/CSK/Virunga_Desc/SMNoCrop_SM_20160105

mkdir -p $PATH_3601/SAR_DATA_Other_Zones/CSK/SuperSite/${DWNLOADDIR}_DATED

echo "//Unzipping files in $PATH_3601/SAR_DATA_Other_Zones/CSK/SuperSite/${DWNLOADDIR}/tmp"
# Unzip and Rename 
cd $PATH_3601/SAR_DATA_Other_Zones/CSK/SuperSite/${DWNLOADDIR}
ls *.zip >> All_zip.txt

if [ ! -s Already_Unzip.txt ] ; then touch Already_Unzip.txt ; fi

#Remove from All_files.txt each line that contains what is in lines of Already_Unzip.txt
#---------------------------------------------------------------------------------------
grep -Fv -f Already_Unzip.txt All_zip.txt > To_Unzip.txt 

cat To_Unzip.txt  >> Already_Unzip.txt

mkdir -p $PATH_3601/SAR_DATA_Other_Zones/CSK/SuperSite/${DWNLOADDIR}/tmp

if [ -s "To_Unzip.txt" ] 
	then 
		for FILESTOUNZIP in `cat To_Unzip.txt` 
			do 
				unzip ${FILESTOUNZIP} 
		done
	else 
		echo "No new data; exit"
		rm -f To_Unzip.txt All_zip.txt
		rm -Rf $PATH_3601/SAR_DATA_Other_Zones/CSK/SuperSite/${DWNLOADDIR}/tmp
		exit 0
fi
echo "//  Files unzipped"

echo "//Renaming RAW files with date in $PATH_3601/SAR_DATA_Other_Zones/CSK/SuperSite/${DWNLOADDIR}_DATED"
cd $PATH_3601/SAR_DATA_Other_Zones/CSK/SuperSite/${DWNLOADDIR}/tmp
# All files are one level too high in a dir named workspace-blabla. ghet them one level below
for WORKSPACEFILES in `find . -maxdepth 1 -type d -name "workspace*"` 
	do 
		cd ${WORKSPACEFILES}
		IMGDIR=`ls -d *.h5`
		cd ${IMGDIR}
		DATE=`echo *.h5 | cut -d _ -f 9 | cut -c 1-8`
		echo "Dir ${WORKSPACEFILES} has been renamed ${DATE}" > ${WORKSPACEFILES}.txt
		cd ..
		mv ${IMGDIR} ${DATE}
		mv ./${DATE} $PATH_3601/SAR_DATA_Other_Zones/CSK/SuperSite/${DWNLOADDIR}_DATED
		cd ..
		rm -Rf ${WORKSPACEFILES}
		
done

cd ..
rm -R ./tmp
rm -f To_Unzip.txt All_zip.txt
echo "//  RAW files renamed with date in $PATH_3601/SAR_DATA_Other_Zones/CSK/SuperSite/${DWNLOADDIR}_DATED"


# Read all CSK images for that footprint
#######################################
 echo "//Reading RAW images (Asc adn Desc) as .csl in $PATH_1650/SAR_CSL/CSK/Virunga"
 $PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh $PATH_3601/SAR_DATA_Other_Zones/CSK/SuperSite/${DWNLOADDIR}_DATED $PATH_1650/SAR_CSL/CSK/Virunga CSK > /dev/null 2>&1

 echo "//Sorting images.csl in Asc and Desc directories"
 cd $PATH_1650/SAR_CSL/CSK/Virunga
 ReadModeCSK.sh Virunga

 echo "//Coregistering images..."
# Coregister all images on the super master 
###########################################
# in Ascending mode 
 $PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/CSK/Virunga_Asc/LaunchCISparam_SuperMaster_CSK_Virunga_Asc_Full_Zoom1_ML45_KEEP_Coreg.txt &
# in Descending mode 
 $PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/CSK/Virunga_Desc/LaunchCISparam_SuperMaster_CSK_Virunga_Desc_Full_Zoom1_ML47_Coreg.txt &


 echo "//Searching pairs and plotting baselines graphs"
# Search for pairs
##################
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_1650/SAR_CSL/CSK/Virunga_Asc/NoCrop $PATH_1650/SAR_SM/MSBAS/VVP/set1 CSK > /dev/null 2>&1  &
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_1650/SAR_CSL/CSK/Virunga_Desc/NoCrop $PATH_1650/SAR_SM/MSBAS/VVP/set2 CSK > /dev/null 2>&1 &
wait

# Compute pairs only if new data is identified
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/VVP/set1 ${BP} 150 20160627 > /dev/null 2>&1  &
fi
if [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/VVP/set2 ${BP} 200 20160105 > /dev/null 2>&1  &
fi
wait

# Plot baseline plot with both modes 
 if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] || [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 

	if [ `baselinePlot | wc -l` -eq 0 ] 
		then
			# use MasTer Engine before May 2022
			mkdir -p $PATH_1650/SAR_SM/MSBAS/VVP/BaselinePlots_set1_set2
			cd $PATH_1650/SAR_SM/MSBAS/VVP/BaselinePlots_set1_set2

			echo "$PATH_1650/SAR_SM/MSBAS/VVP/set1" > ModeList.txt
			echo "$PATH_1650/SAR_SM/MSBAS/VVP/set2" >> ModeList.txt

			# huggly trick
			#cp /$PATH_1650/SAR_SM/MSBAS/VVP/set2/table_0_150_0_200.txt /$PATH_1650/SAR_SM/MSBAS/VVP/set2/table_0_150_0_150.txt
			#$PATH_SCRIPTS/SCRIPTS_OK/plot_Multi_span.sh ModeList.txt 0 ${BP} 0 150 $PATH_SCRIPTS/SCRIPTS_OK/ColorTable_AD.txt			

			${PATH_SCRIPTS}/SCRIPTS_OK/plot_Multi_span_multi_Baselines.sh ModeList.txt 0 ${BP} 0 150 ${PATH_SCRIPTS}/SCRIPTS_OK/ColorTable_AD.txt 0 ${BP} 0 200

		else
			# use MasTer Engine > May 2022
			mkdir -p $PATH_1650/SAR_SM/MSBAS/VVP/BaselinePlots_set1_set2
			cd $PATH_1650/SAR_SM/MSBAS/VVP/BaselinePlots_set1_set2
 
			echo "$PATH_1650/SAR_SM/MSBAS/VVP/set1" > ModeList.txt
			echo "/$PATH_1650/SAR_SM/MSBAS/VVP/set2" >> ModeList.txt
 
			plot_Multi_BaselinePlot.sh $PATH_1650/SAR_SM/MSBAS/VVP/BaselinePlots_set1_set2/ModeList.txt
 	fi
 fi

