#!/bin/bash
# Script to run in cronjob for processing Waremme region (Be) :
# Runs a mass processing after having checked that no other process is using the same param file (on this computer). 
#
# NOTE: because VITO_S1_Step1_Read_SMCoreg_Pairs.sh uses RadAll_Img.sh, which also move updated prelim orbit images at all levels in _CLN dir,
#       and coregister images on super masters, one check that it is not running anymore before starting.
#
#
# New in Distro V 2.0.0 20201104 :	- move all parameters at the beginning
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------
source $HOME/.bashrc

cd
TODAY=`date`

echo "Starting $0"

# Some variables 
################

# Max  baseline (for buliding msbas files)
BP=20
BT=400

STEP1="VITO_S1_Step1_Read_SMCoreg_Pairs.sh"

# some files and PATH
#####################
TABLEASC=$PATH_1650/SAR_SM/MSBAS/VITO/set1/table_0_${BP}_0_${BT}.txt
TABLEDESC=$PATH_1650/SAR_SM/MSBAS/VITO/set3/table_0_${BP}_0_${BT}.txt

PARAMPROCESSASC1=$PATH_1650/Param_files_SuperMaster/S1/VITO_A_88/LaunchCISparam_S1_VITO_A_88_Zoom1_ML2_MassProc.txt
#PARAMPROCESSASC2=$PATH_1650/Param_files_SuperMaster/S1/VITO_A_161/LaunchCISparam_S1_VITO_A_161_Zoom1_ML2_MassProc.txt

PARAMPROCESSDESC=$PATH_1650/Param_files_SuperMaster/S1/VITO_D_37/LaunchCISparam_S1_VITO_D_37_Zoom1_ML2_MassProc.txt

MASSPROCESSASCDIR1=$PATH_3602/SAR_MASSPROCESS_2/S1/VITO_A_88/SMNoCrop_SM_20200822_Zoom1_ML2
MASSPROCESSASCDIR2=$PATH_3602/SAR_MASSPROCESS_2/S1/VITO_A_161/SMNoCrop_SM_20200822_Zoom1_ML2

MASSPROCESSDESCDIR=$PATH_3602/SAR_MASSPROCESS_2/S1/VITO_D_37/SMNoCrop_SM_20181110_Zoom1_ML2


# Prepare stuffs
################
PARAMASCNAME1=`basename ${PARAMPROCESSASC1}`
PARAMASCNAME2=`basename ${PARAMPROCESSASC2}`
PARAMDESCNAME=`basename ${PARAMPROCESSDESC}`

# Check that no other processes are running
###########################################

# Check that Step 1 (Read and Coreg) is finished
CHECKREAD=`ps -eaf | ${PATHGNU}/grep ${STEP1} | ${PATHGNU}/grep -v "grep " | wc -l`

# Let's go
##########
if [ ${CHECKREAD} -eq 0 ] 
	then 
		# OK, no more Step1 is running: 
		# Check that no other SuperMaster automatic Ascending and Desc mass processing uses the LaunchCISparam_.txt yet
		CHECKASC1=`ps -eaf | ${PATHGNU}/grep SuperMaster_MassProc.sh | ${PATHGNU}/grep -v "grep "  | ${PATHGNU}/grep ${PARAMASCNAME1} | wc -l`
		CHECKASC2=`ps -eaf | ${PATHGNU}/grep SuperMaster_MassProc.sh | ${PATHGNU}/grep -v "grep "  | ${PATHGNU}/grep ${PARAMASCNAME2} | wc -l`
		CHECKDESC=`ps -eaf | ${PATHGNU}/grep SuperMaster_MassProc.sh | ${PATHGNU}/grep -v "grep " | ${PATHGNU}/grep ${PARAMDESCNAME} | wc -l`
		#CHECKDESC2=`ps -eaf | ${PATHGNU}/grep SuperMaster_MassProc.sh | ${PATHGNU}/grep -v "grep " | ${PATHGNU}/grep ${PARAMDESCNAME2} | wc -l`

		if [ ${CHECKASC1} -lt 1 ] 
			then 
				# No process running yet
				if [ ! -s  ${MASSPROCESSASCDIR1}/_Asc_last_MassRun.txt ] ; then touch ${MASSPROCESSASCDIR1}/_Asc_last_MassRun.txt ; fi
					echo "Asc 88 run on ${TODAY}"  >>  ${MASSPROCESSASCDIR1}/_Asc_last_MassRun.txt
				$PATH_SCRIPTS/SCRIPTS_OK/SuperMaster_MassProc.sh ${TABLEASC1} ${PARAMPROCESSASC1} > /dev/null 2>&1 &
			else 
				echo "Asc attempt aborted on ${TODAY} because other Mass Process in progress"  >>  ${MASSPROCESSASCDIR1}/_Asc_last_aborted.txt
		fi
		# if running yet we will try again tomorrow

		if [ ${CHECKASC2} -lt 1 ] 
			then 
				# No process running yet
				if [ ! -s  ${MASSPROCESSASCDIR2}/_Asc_last_MassRun.txt ] ; then touch ${MASSPROCESSASCDIR2}/_Asc_last_MassRun.txt ; fi
					echo "Asc 161 run on ${TODAY}"  >>  ${MASSPROCESSASCDIR2}/_Asc_last_MassRun.txt
				$PATH_SCRIPTS/SCRIPTS_OK/SuperMaster_MassProc.sh ${TABLEASC2} ${PARAMPROCESSASC2} > /dev/null 2>&1 &
			else 
				echo "Asc attempt aborted on ${TODAY} because other Mass Process in progress"  >>  ${MASSPROCESSASCDIR2}/_Asc_last_aborted.txt
		fi
		# if running yet we will try again tomorrow


		if [ ${CHECKDESC} -lt 1 ] 
			then 
				# No process running yet
				if [ ! -s  ${MASSPROCESSASCDIR}/_Desc_last_Mass.txt ] ; then touch ${MASSPROCESSASCDIR}/_Desc_last_Mass.txt ; fi
					echo "Desc run on ${TODAY}"  >>  ${MASSPROCESSDESCDIR}/_Desc_last_Mass.txt
				$PATH_SCRIPTS/SCRIPTS_OK/SuperMaster_MassProc.sh ${TABLEDESC} ${PARAMPROCESSDESC} > /dev/null 2>&1 &
			else 
				echo "Desc attempt aborted on ${TODAY} because other Mass Process in progress"  >>  ${MASSPROCESSDESCDIR}/_Desc_last_aborted.txt
		fi
# 		if [ ${CHECKDESC2} -lt 1 ] 
# 			then 
# 				# No process running yet
# 				echo "Desc run on ${TODAY}"  >>  ${MASSPROCESSDESCDIR2}/_Desc_last_Mass.txt
# 				$PATH_SCRIPTS/SCRIPTS_OK/SuperMaster_MassProc.sh ${TABLEDESC2} ${PARAMPROCESSDESC2} > /dev/null 2>&1 &
# 			else 
# 				echo "Desc attempt aborted on ${TODAY} because other Mass Process in progress"  >>  ${MASSPROCESSDESCDIR2}/_Desc_last_aborted.txt
# 		fi

	else 
		# Step1 is still running: abort and wait for tomorrow
		echo "Step2 aborted on ${TODAY} because ${STEP1} is still running: wait for tomorrow"  >>  ${MASSPROCESSASCDIR1}/_aborted_because_Read_inProgress.txt
		echo "Step2 aborted on ${TODAY} because ${STEP1} is still running: wait for tomorrow"  >>  ${MASSPROCESSASCDIR2}/_aborted_because_Read_inProgress.txt

		echo "Step2 aborted on ${TODAY} because ${STEP1} is still running: wait for tomorrow"  >>  ${MASSPROCESSDESCDIR}/_aborted_because_Read_inProgress.txt
#		echo "Step2 aborted on ${TODAY} because ${STEP1} is still running: wait for tomorrow"  >>  ${MASSPROCESSDESCDIR2}/_aborted_because_Read_inProgress.txt

		exit 0
fi

