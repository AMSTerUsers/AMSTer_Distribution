#!/bin/bash
# Script to run in cronjob for processing LUX images:
# Runs a mass processing after having checked that no other process is using the same param file (on this computer). 
#
# NOTE: because LUX_S1_Step1_Read_SMCoreg_Pairs.sh uses RadAll_Img.sh, which also move updated prelim orbit images at all levels in _CLN dir,
#       and coregister images on super masters, one check that it is not running anymore before starting.
#
#
# New in Distro V 2.0.0 20201104 :	- move all parameters at the beginning
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------
source $HOME/.bashrc

cd
TODAY=`date`

echo "Starting $0"

# Some variables 
################

# Max  baseline (for buliding msbas files)
BP=20
BT=400

STEP1="Lux_S1_Step1_Read_SMCoreg_Pairs.sh"

# some files and PATH
#####################
TABLEASC=$PATH_1650/SAR_SM/MSBAS/LUX/set2/table_0_${BP}_0_${BT}.txt
TABLEDESC=$PATH_1650/SAR_SM/MSBAS/LUX/set6/table_0_${BP}_0_${BT}.txt

PARAMPROCESSASC=$PATH_1650/Param_files_SuperMaster/S1/LUX_A_88/LaunchCISparam_S1_LUX_A_88_Zoom1_ML4_MassProc_Mask.txt
PARAMPROCESSDESC=$PATH_1650/Param_files_SuperMaster/S1/LUX_D_139/LaunchCISparam_S1_LUX_D_139_Zoom1_ML4_MassProc_Mask.txt

MASSPROCESSASCDIR=$PATH_3601/SAR_MASSPROCESS/S1/LUX_A_88/SMNoCrop_SM_20170627_Zoom1_ML4
MASSPROCESSDESCDIR=$PATH_3601/SAR_MASSPROCESS/S1/LUX_D_139/SMNoCrop_SM_20161109_Zoom1_ML4

# Prepare stuffs
################
PARAMASCNAME=`basename ${PARAMPROCESSASC}`
PARAMDESCNAME=`basename ${PARAMPROCESSDESC}`

# Check that no other processes are running
###########################################

# Check that Step 1 (Read and Coreg) is finished
CHECKREAD=`ps -eaf | ${PATHGNU}/grep ${STEP1} | ${PATHGNU}/grep -v "grep " | wc -l`

# Let's go
##########
if [ ${CHECKREAD} -eq 0 ] 
	then 
		# OK, no more Step1 is running: 
		# Check that no other SuperMaster automatic Ascending and Desc mass processing uses the LaunchCISparam_.txt yet
		CHECKASC=`ps -eaf | ${PATHGNU}/grep SuperMaster_MassProc.sh | ${PATHGNU}/grep -v "grep "  | ${PATHGNU}/grep ${PARAMASCNAME} | wc -l`
		CHECKDESC=`ps -eaf | ${PATHGNU}/grep SuperMaster_MassProc.sh | ${PATHGNU}/grep -v "grep " | ${PATHGNU}/grep ${PARAMDESCNAME} | wc -l`
		if [ ${CHECKASC} -lt 1 ] 
			then 
				# No process running yet
				echo "Asc run on ${TODAY}"  >>  ${MASSPROCESSASCDIR}/_Asc_last_MassRun.txt
				$PATH_SCRIPTS/SCRIPTS_OK/SuperMaster_MassProc.sh ${TABLEASC} ${PARAMPROCESSASC} > /dev/null 2>&1 &
			else 
				echo "Asc attempt aborted on ${TODAY} because other Mass Process in progress"  >>  ${MASSPROCESSASCDIR}/_Asc_last_aborted.txt
		fi
		# if running yet we will try again tomorrow

		if [ ${CHECKDESC} -lt 1 ] 
			then 
				# No process running yet
				echo "Desc run on ${TODAY}"  >>  ${MASSPROCESSDESCDIR}/_Desc_last_Mass.txt
				$PATH_SCRIPTS/SCRIPTS_OK/SuperMaster_MassProc.sh ${TABLEDESC} ${PARAMPROCESSDESC} > /dev/null 2>&1 &
			else 
				echo "Desc attempt aborted on ${TODAY} because other Mass Process in progress"  >>  ${MASSPROCESSDESCDIR}/_Desc_last_aborted.txt
		fi
	else 
		# Step1 is still running: abort and wait for tomorrow
		echo "Step2 aborted on ${TODAY} because ${STEP1} is still running: wait for tomorrow"  >>  ${MASSPROCESSASCDIR}/_aborted_because_Read_inProgress.txt
		echo "Step2 aborted on ${TODAY} because ${STEP1} is still running: wait for tomorrow"  >>  ${MASSPROCESSDESCDIR}/_aborted_because_Read_inProgress.txt

		exit 0
fi

