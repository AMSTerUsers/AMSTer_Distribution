#!/bin/bash
# Script to run in cronjob for processing COMRES island images:
# Read images, corigister them on a super master and compute the compatible pairs.
# It also creates a common baseline plot for  ascending and descending modes. 

# New in Distro V 2.0.0 20220602 :	- use new Prepa_MSBAS.sh compatible with D Derauw and L. Libert tools for Baseline Ploting
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------

source $HOME/.bashrc

echo "Starting $0" > $PATH_1650/SAR_CSL/S1/KARTHALA_SM/Last_Run_Cron_Step1.txt
date >> $PATH_1650/SAR_CSL/S1/KARTHALA_SM/Last_Run_Cron_Step1.txt

# SM mode

BP=50
BT=150
NEWASCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/KARTHALA_SM_A_86/SMCrop_SM_20220713_ComoresIsland_-11.94--11.34_43.22-43.53
#NEWDESCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/KARTHALA_SM_D_151/SMNoCrop_SM_20181013

# Read all S1 images for that footprint
#######################################
$PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh $PATH_3600/SAR_DATA/S1/S1-DATA-KARTHALA_SM-SLC.UNZIP $PATH_1650/SAR_CSL/S1/KARTHALA_SM/NoCrop S1 ${PATH_1650}/kml/Karthala/Karthala_crop.kml  > /dev/null 2>&1

# Coregister all images on the super master 
###########################################
# in Ascending mode 
$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/S1/KARTHALA_SM_A_86/LaunchCISparam_S1_SM_Karthala_Asc_Zoom1_ML5_Coreg.txt &
# in Descending mode 
#$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/S1/PF_SM_D_151/LaunchCISparam_S1_SM_Reunion_Desc_Zoom1_ML8_Coreg.txt &

# Search for pairs
##################
# Link all images to corresponding set dir
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_1650/SAR_CSL/S1/KARTHALA_SM/NoCrop $PATH_1650/SAR_SM/MSBAS/KARTHALA/set1 S1 > /dev/null 2>&1  &
#$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_1650/SAR_CSL/S1/PF_SM_D_151/NoCrop $PATH_1650/SAR_SM/MSBAS/PF/set2 S1 > /dev/null 2>&1 &
wait

# Compute pairs 
# Compute pairs only if new data is identified
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/KARTHALA/set1 ${BP} ${BT} 20220713 > /dev/null 2>&1  &
fi
#if [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
#	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/PF/set2 ${BP} 50 20181013 > /dev/null 2>&1  &
#fi
wait

# Plot baseline plot with both modes 
# if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] || [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
# 
# 	if [ `baselinePlot | wc -l` -eq 0 ] 
# 		then
# 			# use MasTer Engine before May 2022
# 			mkdir -p $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_S1_set_1_2
# 			cd $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_S1_set_1_2
# 
# 			echo "$PATH_1650/SAR_SM/MSBAS/PF/set1" > ModeList.txt
# 			echo "$PATH_1650/SAR_SM/MSBAS/PF/set2" >> ModeList.txt
# 
# 			$PATH_SCRIPTS/SCRIPTS_OK/plot_Multi_span.sh ModeList.txt 0 ${BP} 0 50   $PATH_SCRIPTS/SCRIPTS_OK/ColorTable_AD.txt
# 		else
# 			# use MasTer Engine > May 2022
# 			mkdir -p $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_set1_set2
# 			cd $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_set1_set2
#  
# 			echo "$PATH_1650/SAR_SM/MSBAS/PF/set1" > ModeList.txt
# 			echo "$PATH_1650/SAR_SM/MSBAS/PF/set2" >> ModeList.txt
#  
# 			plot_Multi_BaselinePlot.sh $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_set1_set2/ModeList.txt
#  	fi
# 
# fi

echo "Ending $0" >> $PATH_1650/SAR_CSL/S1/KARTHALA_SM/Last_Run_Cron_Step1.txt
date >> $PATH_1650/SAR_CSL/S1/KARTHALA_SM/Last_Run_Cron_Step1.txt
