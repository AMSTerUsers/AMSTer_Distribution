#!/bin/bash
# Script to run in cronjob for processing Nyiragongo and Nyamulagira Crater amplitude images
# updated on Aug. 12 2021 by NdO to account for the new way of cropping the images with the most recent version of CIS Master Engine. Also takes the new Super Master for Nyam  

source $HOME/.bashrc

# Suppose that images were downloaded from super site using secp and then read and sorted manually using 
# ReadDateCSK.sh then Prepa_CSK_SuperSite.sh

# ALL2GIFF
# Asc Nyigo Crater - in background so that it can start at the same time the descending
/$PATH_SCRIPTS/SCRIPTS_OK/ALL2GIF.sh 20160627 /$PATH_1650/Param_files_SuperMaster/CSK/Virunga_Asc/LaunchCISparam_CSK_Virunga_Asc_Nyigo_Zoom1_ML1_snaphu_Shadows.txt 800 1150 & 
# Desc Nyigo Crater - in background so that it can start at the same time the descending
# Date label position was updated to account for the new way of cropping the images with the most recent version of CIS Master Engine   
/$PATH_SCRIPTS/SCRIPTS_OK/ALL2GIF.sh 20160105 /$PATH_1650/Param_files_SuperMaster/CSK/Virunga_Desc/LaunchCISparam_CSK_Virunga_Desc_NyigoCrater_Zoom1_ML1_snaphu_SHADOWS.txt 600 500 &

# Asc Nyam - in background so that it can start at the same time the descending
/$PATH_SCRIPTS/SCRIPTS_OK/ALL2GIF.sh 20160627 /$PATH_1650/Param_files_SuperMaster/CSK/Virunga_Asc/LaunchCISparam_CSK_Virunga_Asc_NyamCrater2_Zoom1_ML1_snaphu_Shadows.txt 1100 900 & 
# Desc Nyam - in background so that it can start at the same time the descending
/$PATH_SCRIPTS/SCRIPTS_OK/ALL2GIF.sh 20160105 /$PATH_1650/Param_files_SuperMaster/CSK/Virunga_Desc/LaunchCISparam_CSK_Virunga_Desc_NyamCrater2_Zoom1_ML1_snaphu_SHADOWS.txt 1450 750 & 

