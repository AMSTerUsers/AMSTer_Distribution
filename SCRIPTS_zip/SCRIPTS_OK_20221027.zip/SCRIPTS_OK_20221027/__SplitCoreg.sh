#!/bin/bash
# This script aims at splitting a mass COREGISTRATION process in several parts. 
#
# Attention : processes will be shared between several disks. Check their availability and if sufficient space. 
#
# Parameters are:
#       - List of images to coregister and to be splitted (must be in the form of name if S1 (e.g. S1x_Trk_DATE_AD.csl) or dates if not S1, in 1 col)
#		- Parameters file (incl path) to be used
#       - Nr of parallel splitted processes
#       - FORCES1DEM: if  FORCE, then recompute DEM for each S1 wide swath image 
#
# Dependencies:	- gnu sed and awk for more compatibility. 
#   			- seq
#               - Appel's osascript for opening terminal windows if OS is Mac
#               - x-termoinal-emulator for opening terminal windows if OS is Linux
#			    - say for Mac or espeak for Linux
#				- scripts LaunchTerminal.sh, MasterDEM.sh and of course SuperMaster_MassProc.sh
#
# Hard coded:	- List and path to available disks (in two places ! See script)
#
# New in Distro V 1.0:	- Based on developpement __SplitSession.sh version 1.9
# New in Distro V 1.0:	- was missing Param file in PROPATH
#						- uniform path to HOMEDATA disk
# 						- read more param... just in case 
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2017/12/29 - could make better... when time.
# -----------------------------------------------------------------------------------------
PRG=`basename "$0"`
VER="Distro V2.0 MasTer script utilities"
AUT="Nicolas d'Oreye, (c)2016-2019, Last modified on Sept 28, 2022"
echo " "
echo "${PRG} ${VER}, ${AUT}"
echo "Processing launched on $(date) " 
echo " "

# vvv ----- Hard coded lines to check --- vvv 
# See list of disks below
# ^^^ ----- Hard coded lines to check -- ^^^ 

LISTTOCOREG=$1 		# List of images to coregister and to be splitted (must be in the form of name if S1 (e.g. S1x_Trk_DATE_AD.csl) or dates if not S1, in 1 col)
PARAMFILEPATH=$2 	# Usual Parameter file
N=$3 				# eg 5 if you have 100 pairs and want process 5 terminals, each processing 20 pairs
FORCES1DEM=$4		# For S1 processing : if FORCE, then recompute DEM for each S1 image 


if [ $# -lt 3 ] 
	then 
		echo “Usage $0 LIST_OF_IMGNAME.csl_TO_COREG PARAM_FILEPATH NUMBER_OF_PARALLEL_PROCESSES [FORCE]” 
		echo "That is if you have 100 pairs to coreg and chose 5 parallel processes, "
		echo "     it will compute 5 sets of 20 pairs in 5 terminal windows."
		exit
fi

PARAMPATH=`dirname ${PARAMFILEPATH}`
PARAMFILE=`basename ${PARAMFILEPATH}`
PARAMEXT="${PARAMFILEPATH##*.}"

TABLEPATH=`dirname ${LISTTOCOREG}`
TABLEFILE=`basename ${LISTTOCOREG}`
TABLEEXT="${LISTTOCOREG##*.}"

RNDM=`echo $(( $RANDOM % 10000 ))`

# Check OS
OS=`uname -a | cut -d " " -f 1 `
echo "Running on ${OS}"
echo

# Setup disk paths for processing in Luxembourg. Adjust accordingly if you run several 
case ${OS} in 
	"Linux") 
		#PATH1650="/mnt/nfs1650"
		#PATH3600="/mnt/nfs3600"
		#PATH3601="/mnt/nfs3601"
		#PATH3602="/mnt/nfs3602"
		PATH1650=${PATH_1650} 
		PATH3600=${PATH_3600}
		PATH3601=${PATH_3601}
		PATH3602=${PATH_3602}
		PATHSYNODATA=${PATH_SynoData}
		PATHSYNOCONGO="/mnt/syno_congo"
		PATHSYNOSAR="/mnt/syno_sar" 
		PATHHOMEDATA=${PATH_HOMEDATA}
		;;
	"Darwin")
		PATH1650=${PATH_1650} 
		PATH3600=${PATH_3600}
		PATH3601=${PATH_3601}
		PATH3602=${PATH_3602}
		PATHSYNODATA=${PATH_SynoData}
		PATHSYNOCONGO="/Volumes/DataRDC"
		PATHSYNOSAR="/Volumes/DataSAR" 
		;;
esac			

function GetParam()
	{
	unset PARAM 
	PARAM=$1
	PARAM=`${PATHGNU}/grep -m 1 ${PARAM} ${PARAMFILEPATH} | cut -f1 -d \# | ${PATHGNU}/gsed "s/	//g" | ${PATHGNU}/gsed "s/ //g"`
	eval PARAM=${PARAM}
	echo ${PARAM}
	}

function SpeakOut()
	{
	unset MESSAGE 
	local MESSAGE
	MESSAGE=$1
	case ${OS} in 
		"Linux") 
			espeak "${MESSAGE}" ;;
		"Darwin")
			say "${MESSAGE}" 	;;
		*)
			echo "${MESSAGE}" 	;;
	esac			
	}
	
SUPERMASTER=`GetParam SUPERMASTER`			# SUPERMASTER, date of the super master as selected by Prepa_MSBAS.sh in
											# e.g. /Volumes/hp-1650-Data_Share1/SAR_SUPER_MASTERS/MSBAS/VVP/seti/setParametersFile.txt

PROROOTPATH=`GetParam PROROOTPATH`			# PROROOTPATH, path to dir where data will be processed in sub dir named by the sat name. 
DATAPATH=`GetParam DATAPATH`				# DATAPATH, path to dir where data are stored 
RESAMPDATPATH=`GetParam RESAMPDATPATH`		# RESAMPDATPATH, path to dir where resampled data will be stored 

CROP=`GetParam "CROP,"`						# CROP, CROPyes or CROPno 
SATDIR=`GetParam "SATDIR,"`					# Satellite system. E.g. RADARSAT (must be the same as dirname structure)
TRKDIR=`GetParam "TRKDIR,"`					# Processing directory and dir where data are stored E.g. RS2_UF (must be the same as dirname structure)
ZOOM=`GetParam "ZOOM,"`						# ZOOM, zoom factor used while cropping
INTERFML=`GetParam "INTERFML,"`				#  multilook factor for final interferometric products

FIRSTL=`GetParam "FIRSTL,"`					# Crop limits: first line to use
LASTL=`GetParam "LASTL,"`					# Crop limits: last line to use
FIRSTP=`GetParam "FIRSTP,"`					# Crop limits: first point (row) to use
LASTP=`GetParam "LASTP,"`					# Crop limits: last point (row) to use
REGION=`GetParam "REGION,"`					# REGION, Text description of area for dir naming


# More Param to be sure... 
DEMDIR=`GetParam DEMDIR`					# DEMDIR, path to dir where DEM is stored
RECOMPDEM=`GetParam "RECOMPDEM,"`			# RECOMPDEM, recompute DEM even if already there (FORCE), or trust the one that would exist (KEEP)
SIMAMP=`GetParam "SIMAMP,"`					# SIMAMP, (SIMAMPno or SIMAMPyes). Option to compute simulated amplitude during Extenral DEM generation - usually not needed.
POP=`GetParam "POP,"`						# POP, option to pop up figs or not (POPno or POPyes)
FIG=`GetParam "FIG,"`						# FIG, option to compute or not the quick look using cpxfiddle (FIGno or FIGyes)
MLAMPLI=`GetParam "MLAMPLI,"`				# MLAMPLI, Multilooking factor for amplitude images reduction (used for coregistration - 4-6 is appropriate). If rectangular pixel, it will be multiplied by corresponding ratio.
PIXSHAPE=`GetParam "PIXSHAPE,"`				# PIXSHAPE, pix shape for products : SQUARE or ORIGINALFORM   
CALIBSIGMA=`GetParam "CALIBSIGMA,"`			# CALIBSIGMA, if SIGMAYES it will output sigma nought calibrated amplitude file at the insar product generation step  
COH=`GetParam "COH,"`						# Coarse coregistration correlation threshold  
CCOHWIN=`GetParam "CCOHWIN,"`     			# CCOHWIN, Coarse coreg window size (64 by default but may want less for very small crop)
CCDISTANCHOR=`GetParam "CCDISTANCHOR,"`		# CCDISTANCHOR, Coarse registration range & az distance between anchor points [pix]
FCOH=`GetParam "FCOH,"`						# Fine coregistration correlation threshold 
FCOHWIN=`GetParam "FCOHWIN,"`				# FCOHWIN, Fine coregistration window size (size in az or rg is computed based on Az/Rg ratio) 
FCDISTANCHOR=`GetParam "FCDISTANCHOR,"`		# FCDISTANCHOR, Fine registration range & az distance between anchor points [pix]
PROCESSMODE=`GetParam "PROCESSMODE,"`		# PROCESSMODE, DEFO to produce DInSAR or TOPO to produce DEM
INITPOL=`GetParam "INITPOL,"`		        # INITPOL, force polarisation at initInSAR for InSAR processing. If it does not exists it will find the first compatible MAS-SLV pol. 
LLRGCO=`GetParam "LLRGCO,"`					# LLRGCO, Lower Left Range coord offset for final interferometric products generation. Used mainly for Shadow measurements
LLAZCO=`GetParam "LLAZCO,"`					# LLAZCO, Lower Left Azimuth coord offset for final interferometric products generation. Used mainly for Shadow measurements
COHESTIMFACT=`GetParam "COHESTIMFACT,"`		# COHESTIMFACT, Coherence estimator window size
FILTFACTOR=`GetParam "FILTFACTOR,"`			# Range and Az filtering factor for interfero
POWSPECSMOOTFACT=`GetParam "POWSPECSMOOTFACT,"`	# POWSPECSMOOTFACT, Power spectrum filtering factor (for adaptative filtering)
APPLYMASK=`GetParam "APPLYMASK,"`			# APPLYMASK, Apply mask before unwrapping (APPLYMASKyes or APPLYMASKno)
if [ ${APPLYMASK} == "APPLYMASKyes" ] 
 then 
  PATHTOMASK=`GetParam "PATHTOMASK,"`			# PATHTOMASK, geocoded mask file name and path
 else 
  PATHTOMASK=`echo "NoMask"`
fi
SKIPUW=`GetParam "SKIPUW,"`					# SKIPUW, SKIPyes skips unwrapping and geocode all available products
DEMNAME=`GetParam "DEMNAME,"`				# DEMNAME, name of DEM inverted by lines and columns
MASSPROCESSPATH=`GetParam MASSPROCESSPATH`	# MASSPROCESSPATH, path to dir where all processed pairs will be stored in sub dir named by the sat/trk name (SATDIR/TRKDIR)
# End of more Param to be sure... 


FCTFILE=`GetParam FCTFILE`					# FCTFILE, path to file where all functions are stored

PATHFCTFILE=${FCTFILE%/*}

PROPATH=${PROROOTPATH}/${SATDIR}/${TRKDIR}/MASSCOREG
mkdir -p ${PROPATH}

# Update some infos
	if [ ${CROP} == "CROPyes" ]
		then
			SMCROPDIR=SMCrop_SM_${SUPERMASTER}_${REGION}_${FIRSTL}-${LASTL}_${FIRSTP}-${LASTP}   #_Zoom${ZOOM}_ML${INTERFML}
		else
			SMCROPDIR=SMNoCrop_SM_${SUPERMASTER}  #_Zoom${ZOOM}_ML${INTERFML}
	fi


# Create (if not done yet) the RESAMPDATPATH dirs
mkdir -p ${RESAMPDATPATH}
mkdir -p ${RESAMPDATPATH}/${SATDIR}
mkdir -p ${RESAMPDATPATH}/${SATDIR}/${TRKDIR}
mkdir -p ${RESAMPDATPATH}/${SATDIR}/${TRKDIR}/${SMCROPDIR}


cd ${PROPATH}

# Do not check what exists yet as it be done in SuperMasterCoreg.sh. 
# This is not optimum as if can dedicate a session to a set of data already processed but that is the user responsibility... 

function ChangeProcessPlace()
	{
	unset FILE
	ORIGINAL=`cat ${PARAMFILEPATH} | ${PATHGNU}/grep PROROOTPATH `
	local NEW=$1
	local FILE=$2
   	echo "      Shall process ${i}th set of pairs in  ${NEW}_${RNDM}"
	${PATHGNU}/gsed -i "s%${ORIGINAL}%${NEW}_${RNDM} 			# PROROOTPATH, path to dir where data will be processed in sub dir named by the sat name (SATDIR).%" ${FILE}

	}
# Nr of images:
NRIMG=`wc -l < ${LISTTOCOREG}`
# Nr of images per session 
IMGPERSET=`echo "(${NRIMG} + ${N} - 1) / ${N}" | bc` # bash solution for ceiling... 

# Split img file in N
for i in `seq 1 ${N}`
do
	NEWIMGFILE=${PROPATH}/${TABLEFILE}_Part${i}_${RNDM}.${TABLEEXT}

	TOHEAD=`echo "(${i} * ${IMGPERSET}) " | bc` 
	TOTAIL=`echo "${IMGPERSET} " | bc` 
	
	if [ ${TOHEAD} -gt ${NRIMG} ] 
		then 
			LASTSET=`echo "${TOHEAD} - ${NRIMG}" | bc` 
			TOTAIL=`echo "${IMGPERSET} - ${LASTSET}" | bc`
	fi
	
	# Ensure here also that SM is not in file...  
	cat ${LISTTOCOREG} | head -${TOHEAD} | tail -${TOTAIL} | grep -v ${SUPERMASTER} > ${NEWIMGFILE}
	
	
done

# Split Parameter file i order to process in several dir
echo "-------------------------------------------"
echo "Disk space available on your drives are : "
df -h
echo "-------------------------------------------"
echo "Where do you want to process the ${i} set of ${PAIRSPERSET} pairs: "
echo "  1) = hp-1600"
echo "  2) = hp-D3600"
echo "  3) = hp-D3601"
echo "  4) = hp-D3602"
echo "  5) = Doris_10T"
echo "  6) = SAR_20T_N1"
echo "  7) = syno_data"
echo "  8) = syno_sar"
echo "  9) = syno_congo (do not use !)"
echo "  10) = HOMEDATA (Linux)"
echo "  11) = HOME"

cp ${PARAMFILEPATH} ${PROPATH}/${PARAMFILE}

for i in `seq 1 ${N}`
do
	NEWPARAMFILE=${PROPATH}/${PARAMFILE}_Part${i}_${RNDM}.${PARAMEXT}
	cp ${PROPATH}/${PARAMFILE} ${NEWPARAMFILE}

		while true; do
			read -p "Provide the number of disk from list above and ensure there is enough space: "  DISK
			case $DISK in
				"1") 
					DISKPATH=/${PATH1650}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"2") 
					DISKPATH=/${PATH3600}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"3") 
					DISKPATH=/${PATH3601}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"4") 
					DISKPATH=/${PATH3602}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"5") 
					mkdir -p /Volumes/Lacie10TB/PROCESS/CIS 								# Hookled on Mac Pro only
					DISKPATH=/Volumes/Lacie10TB/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"6") 
					mkdir -p /Volumes/SAR_20T_N1/PROCESS/CIS								# Hookled on Mac Pro only
					DISKPATH=/Volumes/SAR_20T_N1/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"7") 
					mkdir -p /${PATHSYNODATA}/PROCESS/CIS
					DISKPATH=/${PATHSYNODATA}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"8") 
					mkdir -p /${PATHSYNOSAR}/PROCESS/CIS
					DISKPATH=/${PATHSYNOSAR}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;				
				"9") 
					mkdir -p /${PATHSYNOCONGO}/PROCESS/CIS
					DISKPATH=/${PATHSYNOCONGO}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;				
				"10") 
					mkdir -p ${PATHHOMEDATA}/PROCESS/CIS
					DISKPATH=${PATHHOMEDATA}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"11") 
					mkdir -p ${HOME}/PROCESS/CIS
					DISKPATH=${HOME}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				* ) 
					echo "Unknown; try again"
					;;
			esac
		done
		ChangeProcessPlace ${DISKPATH} ${NEWPARAMFILE}
		DISKPATH[$i]=${DISKPATH}
		echo "	${i}th processing will be on disk DISKPATH[$i], that is ${DISKPATH[$i]} "
done

echo ""

echo "-------------------------------------------"
while true ; do
	read -p "Do you want to run the Mass Coregistration in separate Terminal windows ? "  yn
	case $yn in
		[Yy]* ) 
			# launch the processing in separate Terminal windows
			echo "OK, I launch them for you now..."
			for i in `seq 1 ${N}`
 			do
 				sleep 5
 				case ${OS} in 
					"Linux") 
						eval MYDISPLAY=`who -m | cut -d "(" -f 2  | cut -d ")" -f 1`
						echo "  // Your current session runs on DISPLAY ${MYDISPLAY}"

						export DISPLAY=${MYDISPLAY} ; x-terminal-emulator -e ${PATHFCTFILE}/LaunchTerminal.sh ${PATHFCTFILE}/SuperMasterCoreg.sh ${PROPATH}/${PARAMFILE}_Part${i}_${RNDM}.${PARAMEXT} ${FORCES1DEM} ${PROPATH}/${TABLEFILE}_Part${i}_${RNDM}.${TABLEEXT} &
						;;
					"Darwin")
 						osascript -e 'tell app "Terminal"
 						do script "SuperMasterCoreg.sh '"${PROPATH}/${PARAMFILE}_Part${i}_${RNDM}.${PARAMEXT} ${FORCES1DEM} ${PROPATH}/${TABLEFILE}_Part${i}_${RNDM}.${TABLEEXT}"'"
 						end tell'
 						;;
					*)
						echo "I can't figure out what is you opeating system. Please check"
						exit 0
						;;
				esac	
 			done 
			break ;;
		[Nn]* ) 
			echo ""
			echo "OK, launch them manually when you are ready"    
			break ;;
    	* ) echo "Please answer yes or no." ;;	
    esac	
done

echo
echo "WAIT FOR FINISHING WORK IN ALL TERMINALS" 

# Some cleaning 
while true ; do
	read -p "WHEN ALL COREGISTRATIONS ARE DONE !! : Do you want to clean ${PROPATH} ? "  yn
		case $yn in
		[Yy]* ) 
			echo "Remove this: "
			ls -l ${PROPATH}
			rm -Rf ${PROPATH}
			break ;;
		[Nn]* ) 
			echo "OK, clean manually this:"    
			ls -l ${PROPATH}
			break ;;
    	* ) echo "Please answer yes [Yy] or no [Nn]." ;;	
    esac	
done
	
echo 
		
# Some cleaning 
while true ; do
	read -p "WHEN ALL PROCESSES ARE DONE !! : Do you want to clean Processing dirs ? "  yn
		case $yn in
		[Yy]* ) 
			for i in `seq 1 ${N}`
				do
					echo "Removing  ${DISKPATH[$i]}*"
					rm -Rf ${DISKPATH[$i]}*
					echo
			done
			break ;;
		[Nn]* ) 
			echo "OK, clean manually this:"    
			for i in `seq 1 ${N}`
				do
					echo "${DISKPATH[$i]}*"
			done
			break ;;
    	* ) echo "Please answer yes [Yy] or no [Nn]." ;;	
    esac	
done
