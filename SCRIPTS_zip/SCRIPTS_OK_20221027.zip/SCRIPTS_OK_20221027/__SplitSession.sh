#!/bin/bash
# This script aims at splitting a mass process in several parts. 
#
# Attention : processes will be shared between several disks. Check their availability and if sufficient space. 
#
# Parameters are:
#       - Table to be splitted
#		- Parameters file (incl path) to be used
#       - Nr of parallel splitted processes
#		- optional: -list=filename to use list of pairs or 
#					-f to force checking existing pairs based on Geocoded/DefoInterpolx2Detrend)
#
# Dependencies:	- gnu sed and awk for more compatibility. 
#   			- seq
#               - Appel's osascript for opening terminal windows if OS is Mac
#               - x-termoinal-emulator for opening terminal windows if OS is Linux
#			    - say for Mac or espeak for Linux
#				- scripts LaunchTerminal.sh, MasterDEM.sh and of course SuperMaster_MassProc.sh
#
# Hard coded:	- List and path to available disks (in two places ! See script)
#
# New in Distro V 1.0:	- Based on developpement version and Beta V3.0
# New in Distro V 1.1: - if launched with option -f, it forces to create the list of existing 
#						 pairs based on the files in Geocoded/DefoInterpolx2Detrend 
#						 instead of on the list of pair dirs. 
#					   - do not list _CheckResults dir while building existing pairs list
# New in Distro V 1.2: - if launched with option -list=filename, it forces to compute only pairs 
#						 in provided list (filename MUST be in the form of list of MASTER_SLAVE dates)
#					   - fix find with maxdepth
# New in Distro V 1.3: - add new disks
# New in Distro V 1.4: - path to gnu ${PATHGNU}/grep
# New in Distro V 1.5: - creates MASSPROCESSPATH tree if does not exist
# New in Distro V 1.6: - update path to disks using state variables for 1650-3602
# New in Distro V 1.7: - replace ls by find to avoid "too long argument" error 
# New in Distro V 1.8: - remove stray \ before _ while calling grep to cope with new grep syntax and avoid waring
# New in Distro V 1.9: - launch x-terminal-emulator with current DISPLAY
#					   - SUPERMASTER was read twice 
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2017/12/29 - could make better... when time.
# -----------------------------------------------------------------------------------------
PRG=`basename "$0"`
VER="Distro V1.9 MasTer script utilities"
AUT="Nicolas d'Oreye, (c)2016-2019, Last modified on Sept 26, 2022"
echo " "
echo "${PRG} ${VER}, ${AUT}"
echo "Processing launched on $(date) " 
echo " "

# vvv ----- Hard coded lines to check --- vvv 
# See list of disks below
# ^^^ ----- Hard coded lines to check -- ^^^ 

TABLEFILEPATH=$1 	# eg /Users/doris/NAS/hp-1650-Data_Share1/SAR_SM/MSBAS/Limbourg/set1/table_0_450_0_250.txt
PARAMFILEPATH=$2 	# Usual Parameter file
N=$3 				# eg 5 if you have 100 pairs and want process 5 terminals, each processing 20 pairs
LISTOFPROCESSED=$4	# if -f, it forces to create the list of existing pairs based on the files in Geocoded/DefoInterpolx2Detrend 
					# if -list=filename, it forces to compute only pairs in provided list (filename MUST be in the form of list of MASTER_SLAVE dates)

if [ $# -lt 3 ] 
	then 
		echo “Usage $0 PARAM_FILEPATH TABLE_FILEPATH NUMBER_OF_PARALLEL_PROCESSES” 
		echo "That is if you have 100 pairs to process and chose 5 parallel processes, "
		echo "     it will compute 5 sets of 20 pairs in 5 terminal windows."
		exit
fi

if [ $# -eq 4 ]
	then 
		case ${LISTOFPROCESSED} in 
			"-f") # get the list of proecessed pairs from Geocoded/DefoInterpolx2Detrend
				LISTOFPROCESSED=YES ;;
			"-list="*)  # Do not compute list of processed pairs to compute wich is still to process because the list of pairs to process is provided instead
			 	LISTOFPROCESSED=FILE
			 	PATHTOPAIRLIST=`echo ${LISTOFPROCESSED} | cut -d = -f2 `
			 	# check that list is of correct form
				PAIRDATE=`head -1 ${PATHTOPAIRLIST} | ${PATHGNU}/grep -Eo "[0-9]{8}_[0-9]{8}"`  # get date_date
				TESTPAIR=`head -1 ${PATHTOPAIRLIST} | ${PATHGNU}/gsed "s/${PAIRDATE}//g" | wc -m` # check that there is nothing esle than PAIRDATE

				if [ `echo "${PAIRDATE}" | wc -m` == 18 ] && [ ${TESTPAIR} == 1 ] 
					then 
						echo "Valid pair files to process"  
					else 
						echo "Invalid pair files to process; must be in the form of DATE_DATE. Exit" 
						exit 0 
				fi
			 	;;
			 	
			*)	# not sure what is wanted hence keep default processing 
				echo "Not sure what your 4th parameter is. "
				echo "  This option must be -f to search for list of processed pairs in Geocoded/DefoInterpolx2Detrend or "
				echo "                      -file=list to provide a list of pairs to process.  " 
				echo "Since the 4th parameter provided is of none of these forms, let's keep default processing, "
				echo "  i.e. compute the list of preocessed pairs from the pair dirs in SAR_MASSPROCESS" 
				LISTOFPROCESSED=NO ;;	
		esac  
	else 
		LISTOFPROCESSED=NO
fi 


PARAMPATH=`dirname ${PARAMFILEPATH}`
PARAMFILE=`basename ${PARAMFILEPATH}`
PARAMEXT="${PARAMFILEPATH##*.}"

RNDM=`echo $(( $RANDOM % 10000 ))`

# Check OS
OS=`uname -a | cut -d " " -f 1 `
echo "Running on ${OS}"
echo

# Setup disk paths for processing in Luxembourg. Adjust accordingly if you run several 
case ${OS} in 
	"Linux") 
		#PATH1650="/mnt/nfs1650"
		#PATH3600="/mnt/nfs3600"
		#PATH3601="/mnt/nfs3601"
		#PATH3602="/mnt/nfs3602"
		PATH1650=${PATH_1650} 
		PATH3600=${PATH_3600}
		PATH3601=${PATH_3601}
		PATH3602=${PATH_3602}
		PATHSYNODATA=${PATH_SynoData} 
		PATHSYNOCONGO="/mnt/syno_congo"
		PATHSYNOSAR="/mnt/syno_sar" 
		PATHHOMEDATA=${PATH_HOMEDATA}
		;;
	"Darwin")
		PATH1650=${PATH_1650} 
		PATH3600=${PATH_3600}
		PATH3601=${PATH_3601}
		PATH3602=${PATH_3602}
		PATHSYNODATA=${PATH_SynoData}
		PATHSYNOCONGO="/Volumes/DataRDC"
		PATHSYNOSAR="/Volumes/DataSAR" ;;
esac			

function GetParam()
	{
	unset PARAM 
	PARAM=$1
	PARAM=`${PATHGNU}/grep -m 1 ${PARAM} ${PARAMFILEPATH} | cut -f1 -d \# | ${PATHGNU}/gsed "s/	//g" | ${PATHGNU}/gsed "s/ //g"`
	eval PARAM=${PARAM}
	echo ${PARAM}
	}

function SpeakOut()
	{
	unset MESSAGE 
	local MESSAGE
	MESSAGE=$1
	case ${OS} in 
		"Linux") 
			espeak "${MESSAGE}" ;;
		"Darwin")
			say "${MESSAGE}" 	;;
		*)
			echo "${MESSAGE}" 	;;
	esac			
	}
	
SUPERMASTER=`GetParam SUPERMASTER`			# SUPERMASTER, date of the super master as selected by Prepa_MSBAS.sh in
											# e.g. /Volumes/hp-1650-Data_Share1/SAR_SUPER_MASTERS/MSBAS/VVP/seti/setParametersFile.txt

PROROOTPATH=`GetParam PROROOTPATH`			# PROROOTPATH, path to dir where data will be processed in sub dir named by the sat name. 
MASSPROCESSPATH=`GetParam MASSPROCESSPATH`	# MASSPROCESSPATH, path to dir where all processed pairs will be stored in sub dir named by the sat/trk name (SATDIR/TRKDIR)

CROP=`GetParam "CROP,"`						# CROP, CROPyes or CROPno 
SATDIR=`GetParam "SATDIR,"`					# Satellite system. E.g. RADARSAT (must be the same as dirname structure)
TRKDIR=`GetParam "TRKDIR,"`					# Processing directory and dir where data are stored E.g. RS2_UF (must be the same as dirname structure)
ZOOM=`GetParam "ZOOM,"`						# ZOOM, zoom factor used while cropping
INTERFML=`GetParam "INTERFML,"`				#  multilook factor for final interferometric products

FIRSTL=`GetParam "FIRSTL,"`					# Crop limits: first line to use
LASTL=`GetParam "LASTL,"`					# Crop limits: last line to use
FIRSTP=`GetParam "FIRSTP,"`					# Crop limits: first point (row) to use
LASTP=`GetParam "LASTP,"`					# Crop limits: last point (row) to use
REGION=`GetParam "REGION,"`					# REGION, Text description of area for dir naming

FCTFILE=`GetParam FCTFILE`					# FCTFILE, path to file where all functions are stored

PATHFCTFILE=${FCTFILE%/*}

PROPATH=${PROROOTPATH}/${SATDIR}/${TRKDIR}/MASSPROC
mkdir -p ${PROPATH}
cd ${PROPATH}

TABLEPATH=`dirname ${TABLEFILEPATH}`
TABLEFILE=`basename ${TABLEFILEPATH}`
TABLEEXT="${TABLEFILEPATH##*.}"

# Update some infos
	if [ ${CROP} == "CROPyes" ]
		then
			SMCROPDIR=SMCrop_SM_${SUPERMASTER}_${REGION}_${FIRSTL}-${LASTL}_${FIRSTP}-${LASTP}   #_Zoom${ZOOM}_ML${INTERFML}
		else
			SMCROPDIR=SMNoCrop_SM_${SUPERMASTER}  #_Zoom${ZOOM}_ML${INTERFML}
	fi


# First check existing pairs before splitting into sub-lists
	# Existing pairs
# 	if [ -d ${MASSPROCESSPATH}/${SATDIR}/${TRKDIR}/${SMCROPDIR}_Zoom${ZOOM}_ML${INTERFML} ] ; then 
# 		cd ${MASSPROCESSPATH}/${SATDIR}/${TRKDIR}/${SMCROPDIR}_Zoom${ZOOM}_ML${INTERFML}
# 		 if [ "${SATDIR}" == "S1" ]
# 			then 
# 				ls -d * | ${PATHGNU}/grep -v ".txt"  | ${PATHGNU}/grep -v "Geocoded" | cut -d _ -f 3,7 > ${PROPATH}/ExistingPairs_${RNDM}.txt
# 			else 
# 				ls -d * | ${PATHGNU}/grep -v ".txt"  | ${PATHGNU}/grep -v "Geocoded" > ${PROPATH}/ExistingPairs_${RNDM}.txt
# 		fi
# 	fi

mkdir -p ${MASSPROCESSPATH}
mkdir -p ${MASSPROCESSPATH}/${SATDIR}
mkdir -p ${MASSPROCESSPATH}/${SATDIR}/${TRKDIR}
mkdir -p ${MASSPROCESSPATH}/${SATDIR}/${TRKDIR}/${SMCROPDIR}_Zoom${ZOOM}_ML${INTERFML}

cd ${MASSPROCESSPATH}/${SATDIR}/${TRKDIR}/${SMCROPDIR}_Zoom${ZOOM}_ML${INTERFML}

#if [ -d ${MASSPROCESSPATH}/${SATDIR}/${TRKDIR}/${SMCROPDIR}_Zoom${ZOOM}_ML${INTERFML} ] ; then cd ${MASSPROCESSPATH}/${SATDIR}/${TRKDIR}/${SMCROPDIR}_Zoom${ZOOM}_ML${INTERFML} ; fi
case ${LISTOFPROCESSED} in 
			"YES")
				# force to build the list of existing pairs based on the files in Geocoded/DefoInterpolx2Detrend
				rm -f ${PROPATH}/ExistingPairs_${RNDM}.txt
				for GEOCODEDPAIR in `find ${MASSPROCESSPATH}/${SATDIR}/${TRKDIR}/${SMCROPDIR}_Zoom${ZOOM}_ML${INTERFML}/Geocoded/DefoInterpolx2Detrend/ -maxdepth 1 -type f -name "*deg"` ; do 
					echo "${GEOCODEDPAIR}" | ${PATHGNU}/grep -Eo "[0-9]{8}_[0-9]{8}">> ${PROPATH}/ExistingPairs_${RNDM}.txt # select date_date where date is 8 numbers
				done ;;
			"NO")
				# force to build the list of existing pairs based on the list of pair dirs in MASSPROCESSPATHLONG
				# If MASSPROCESSPATHLONG contains subdir, check pairs already processed (in the form of date_date ; also for S1) :
				if find "${MASSPROCESSPATH}/${SATDIR}/${TRKDIR}/${SMCROPDIR}_Zoom${ZOOM}_ML${INTERFML}" -mindepth 1 -print -quit | ${PATHGNU}/grep -q . ; then 
					if [ "${SATDIR}" == "S1" ]
							then 
								#ls -d * | ${PATHGNU}/grep -v ".txt"  | ${PATHGNU}/grep -v "Geocoded" | ${PATHGNU}/grep -v "_CheckResults" | cut -d _ -f 3,7 > ${PROPATH}/ExistingPairs_${RNDM}.txt
								find -maxdepth 1 -type d -name "*"  | ${PATHGNU}/grep -v ".txt"  | ${PATHGNU}/grep -v "Geocoded" | ${PATHGNU}/grep -v "_CheckResults" | cut -d _ -f 3,7 > ${PROPATH}/ExistingPairs_${RNDM}.txt
							else 
								#ls -d * | ${PATHGNU}/grep -v ".txt"  | ${PATHGNU}/grep -v "Geocoded" | ${PATHGNU}/grep -v "_CheckResults" > ${PROPATH}/ExistingPairs_${RNDM}.txt
								find -maxdepth 1 -type d -name "*"  | ${PATHGNU}/grep -v ".txt"  | ${PATHGNU}/grep -v "Geocoded" | ${PATHGNU}/grep -v "_CheckResults" > ${PROPATH}/ExistingPairs_${RNDM}.txt
					fi
				fi	;;
			"FILE")	
				# will use PATHTOPAIRLIST as PairsToProcess_${RNDM}.txt, hence create dummy ExistingPairs_${RNDM}.txt
				touch ${PROPATH}/ExistingPairs_${RNDM}.txt
				;;
esac

cd ${PROPATH}
if [  ${LISTOFPROCESSED} == "FILE" ]
	then 
		# assign the list of pairs to process as the list provided in 4th param
		cp ${PATHTOPAIRLIST} ${PROPATH}/PairsToProcess_${RNDM}.txt
		TABLEFILE=PairsToProcess_${RNDM}.txt
		TABLEFILEPATH=${PROPATH}/${TABLEFILE}
	else 
		# Compatible Pairs (in the form of "date_date"; also for S1):
		 if ${PATHGNU}/grep -q Delay "${TABLEFILEPATH}"
			then
				# If TABLEFILEPATH = table from Prepa_MSBAS.sh, it contains the string "Delay", then
				# Remove header and extract only the pairs in ${TABLEFILEPATH}
				cat ${TABLEFILEPATH} | tail -n+3 | cut -f 1-2 | ${PATHGNU}/gsed "s/\t/_/g" > ${TABLEFILE}_NoBaselines_${RNDM}.txt 
			else
				# If PAIRFILE = list of images to play, it contains already only the dates
				cp ${TABLEFILEPATH} ${TABLEFILE}_NoBaselines_${RNDM}.txt
		 fi

		# Search for only the new ones to be processed:
		if [ -s ExistingPairs_${RNDM}.txt ]
			then
				${PATHGNU}/grep -Fxvf ExistingPairs_${RNDM}.txt ${TABLEFILE}_NoBaselines_${RNDM}.txt > PairsToProcess_${RNDM}.txt
			else
				cp ${TABLEFILE}_NoBaselines_${RNDM}.txt PairsToProcess_${RNDM}.txt
		fi

		TABLEFILE=PairsToProcess_${RNDM}.txt
		TABLEFILEPATH=${PROPATH}/${TABLEFILE}
fi

sort ${TABLEFILE} > ${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT} # sort by MASTERS

TABLEFILEPATHNOHEADER=`echo ${PROPATH}/${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT}`
PAIRS=`wc -l < ${TABLEFILEPATHNOHEADER}`

# list of number of pairs using a given image as master as [nr master]
cat ${PROPATH}/${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT} | cut -c 1-8 | sort | uniq -c > ${PROPATH}/${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT}_LISTMASTERSCOUNTED.txt

PAIRSPERSET=`echo "(${PAIRS} + ${N} - 1) / ${N}" | bc` # bash solution for ceiling... 

function ChangeProcessPlace()
	{
	unset FILE
	ORIGINAL=`cat ${PARAMFILEPATH} | ${PATHGNU}/grep PROROOTPATH `
	local NEW=$1
	local FILE=$2
   	echo "      Shall process ${i}th set of pairs in  ${NEW}_${RNDM}"
	${PATHGNU}/gsed -i "s%${ORIGINAL}%${NEW}_${RNDM} 			# PROROOTPATH, path to dir where data will be processed in sub dir named by the sat name (SATDIR).%" ${FILE}

	}

# Split Pair file in order to process in several dir by looking for each master and keep all the pairs as long as total < PAIRSPERSET
for i in `seq 1 ${N}`
do
	NEWPAIRFILE=${PROPATH}/${TABLEFILE}_Part${i}_${RNDM}.${TABLEEXT}
	l=0
	cat ${PROPATH}/${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT}_LISTMASTERSCOUNTED.txt | while read nandmas
	do
		# nr of pairs for a given master "MASINSET"
		NROFPAIRSWITHMAS=`echo ${nandmas} | cut -d' ' -f1`
		# master date which is present "NROFPAIRSWITHMAS" times
		MASINSET=`echo ${nandmas} | cut -d' ' -f2`	
		# nr of lines in ith NEWPAIRFILE
		l=`echo "( ${l} + ${NROFPAIRSWITHMAS} ) " | bc`
		if [ ${i} -lt ${N} ] 
			then # ensure that set is smaller than total/N
				if [ ${l} -lt ${PAIRSPERSET} ] 
					then 		
						#copy all pairs with starting master 
						echo "Shall write ${NROFPAIRSWITHMAS} pairs starting with master ${MASINSET} in new ${i}th table" 
						cat ${TABLEFILEPATHNOHEADER} | ${PATHGNU}/grep ^${MASINSET} >> ${NEWPAIRFILE} 
						# and remove that master from list to split
						cat ${PROPATH}/${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT}_LISTMASTERSCOUNTED.txt | ${PATHGNU}/grep -v ${MASINSET} > ${PROPATH}/${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT}_LISTMASTERSCOUNTED.txt.tmp
						rm ${PROPATH}/${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT}_LISTMASTERSCOUNTED.txt
						mv ${PROPATH}/${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT}_LISTMASTERSCOUNTED.txt.tmp ${PROPATH}/${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT}_LISTMASTERSCOUNTED.txt
				fi	
			else # get all the remaining pairs, even if goes beyone max nr of per set
				echo "Shall write ${NROFPAIRSWITHMAS} pairs starting with master ${MASINSET} in the last new ${i}th table" 
				cat ${TABLEFILEPATHNOHEADER} | ${PATHGNU}/grep ^${MASINSET} >> ${NEWPAIRFILE} 
		fi
	done
done

rm ${PROPATH}/${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT}_LISTMASTERSCOUNTED.txt ${PROPATH}/${TABLEFILE}_NOHEAD_${RNDM}.${TABLEEXT}
echo ""

if [ "${SATDIR}" != "S1" ] 
	then
		SpeakOut "For processing other than S1, better first compute the DEM (and mask) anyway; mass processes should be start after. Do you want to run DEM first?" 
			while true; do
				read -p "For processing other than S1, better first compute the DEM (and mask) anyway; mass processes should be start after. Do you want to run DEM first?"  yn
				case $yn in
					[Yy]* ) 
						echo 
						echo "********************************************************************"
						echo "DO NOT START NEXT STEPS OF _SPILTSESSIONS.SH BEFORE DEM IS FINISHED"
						echo "********************************************************************"
						case ${OS} in 
							"Linux") 
								eval MYDISPLAY=`who -m | cut -d "(" -f 2  | cut -d ")" -f 1`
								echo "  // Your current session runs on DISPLAY ${MYDISPLAY}"

								export DISPLAY=${MYDISPLAY} ; x-terminal-emulator -e ${PATHFCTFILE}/LaunchTerminal.sh ${PATHFCTFILE}/MasterDEM.sh ${SUPERMASTER} ${PARAMPATH}/${PARAMFILE} &
								;;
							"Darwin")
								osascript -e 'tell app "Terminal"
								do script "MasterDEM.sh '"${SUPERMASTER} ${PARAMPATH}/${PARAMFILE}"'"
								end tell'		;;
							*)
								echo "I can't figure out what is you opeating system. Please check"
								exit 0
								;;
						esac						
						break ;;
					[Nn]* ) break ;;
					* ) 
						echo "Please answer yes or no.";;
				esac
			done
	else 
		echo "For S1 processing, ensure you ran SuperMasterCoreg.sh first to ensure proper DEM (and mask). "
fi

# Now one can put it safely to KEEP.   
ORIGINALMODE=`cat ${PARAMFILEPATH} | ${PATHGNU}/grep RECOMPDEM `
${PATHGNU}/gsed "s%${ORIGINALMODE}%KEEP		# RECOMPDEM, recompute DEM or mask in slant range even if already there (FORCE), or check the one that would exist (KEEP). %" ${PARAMFILEPATH} > ${PROPATH}/${PARAMFILE}
echo ""

# Split Parameter file i order to process in several dir
echo "-------------------------------------------"
echo "Disk space available on your drives are : "
df -h
echo "-------------------------------------------"
echo "Where do you want to process the ${i} set of ${PAIRSPERSET} pairs: "
echo "  1) = hp-1600"
echo "  2) = hp-D3600"
echo "  3) = hp-D3601"
echo "  4) = hp-D3602"
echo "  5) = Doris_10T"
echo "  6) = SAR_20T_N1"
echo "  7) = syno_data"
echo "  8) = syno_sar"
echo "  9) = syno_congo (do not use !)"
echo "  10) = HOMEDATA (Linux)"
echo "  11) = HOME"

for i in `seq 1 ${N}`
do
	NEWPARAMFILE=${PROPATH}/${PARAMFILE}_Part${i}_${RNDM}.${PARAMEXT}
	cp ${PROPATH}/${PARAMFILE} ${NEWPARAMFILE}

		while true; do
			read -p "Provide the number of disk from list above and ensure there is enough space: "  DISK
			case $DISK in
				"1") 
					DISKPATH=/${PATH1650}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"2") 
					DISKPATH=/${PATH3600}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"3") 
					DISKPATH=/${PATH3601}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"4") 
					DISKPATH=/${PATH3602}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"5") 
					mkdir -p /Volumes/Lacie10TB/PROCESS/CIS 								# Hookled on Mac Pro only
					DISKPATH=/Volumes/Lacie10TB/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"6") 
					mkdir -p /Volumes/SAR_20T_N1/PROCESS/CIS								# Hookled on Mac Pro only
					DISKPATH=/Volumes/SAR_20T_N1/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"7") 
					mkdir -p /${PATHSYNODATA}/PROCESS/CIS
					DISKPATH=/${PATHSYNODATA}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"8") 
					mkdir -p /${PATHSYNOSAR}/PROCESS/CIS
					DISKPATH=/${PATHSYNOSAR}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;				
				"9") 
					mkdir -p /${PATHSYNOCONGO}/PROCESS/CIS
					DISKPATH=/${PATHSYNOCONGO}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;				
				"10") 
					mkdir -p ${PATHHOMEDATA}/PROCESS/CIS
					DISKPATH=${PATHHOMEDATA}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				"11") 
					mkdir -p ${HOME}/PROCESS/CIS
					DISKPATH=${HOME}/PROCESS/CIS/${SATDIR}_${TRKDIR}_Part_${i}
					break ;;
				* ) 
					echo "Unknown; try again"
					;;
			esac
		done
		ChangeProcessPlace ${DISKPATH} ${NEWPARAMFILE}
		DISKPATH[$i]=${DISKPATH}
		echo "	${i}th processing will be on disk DISKPATH[$i], that is ${DISKPATH[$i]} "
done

echo ""

echo "-------------------------------------------"
while true ; do
	read -p "Do you want to run the Mass Processing in separate Terminal windows ? "  yn
	case $yn in
		[Yy]* ) 
			# launch the processing in separate Terminal windows
			echo "OK, I launch them for you now..."
			for i in `seq 1 ${N}`
 			do
 				sleep 5
 				case ${OS} in 
					"Linux") 
						eval MYDISPLAY=`who -m | cut -d "(" -f 2  | cut -d ")" -f 1`
						echo "  // Your current session runs on DISPLAY ${MYDISPLAY}"

						export DISPLAY=${MYDISPLAY} ; x-terminal-emulator -e ${PATHFCTFILE}/LaunchTerminal.sh ${PATHFCTFILE}/SuperMaster_MassProc.sh ${PROPATH}/${TABLEFILE}_Part${i}_${RNDM}.${TABLEEXT} ${PROPATH}/${PARAMFILE}_Part${i}_${RNDM}.${PARAMEXT} &
						# without terminals
						#${PATHFCTFILE}/SuperMaster_MassProc.sh ${PROPATH}/${TABLEFILE}_Part${i}_${RNDM}.${TABLEEXT} ${PROPATH}/${PARAMFILE}_Part${i}_${RNDM}.${PARAMEXT} &
						;;
					"Darwin")
 						osascript -e 'tell app "Terminal"
 						do script "SuperMaster_MassProc.sh '"${PROPATH}/${TABLEFILE}_Part${i}_${RNDM}.${TABLEEXT} ${PROPATH}/${PARAMFILE}_Part${i}_${RNDM}.${PARAMEXT}"'"
 						end tell'
 						;;
					*)
						echo "I can't figure out what is you opeating system. Please check"
						exit 0
						;;
				esac	
 			done 
			break ;;
		[Nn]* ) 
			echo ""
			echo "OK, launch them manually when you are ready"    
			break ;;
    	* ) echo "Please answer yes or no." ;;	
    esac	
done

echo
echo "WAIT FOR FINISHING WORK IN ALL TERMINALS" 

# Some cleaning 
while true ; do
	read -p "WHEN ALL PROCESSES ARE DONE !! : Do you want to clean ${PROPATH} ? "  yn
		case $yn in
		[Yy]* ) 
			echo "Remove this: "
			ls -l ${PROPATH}
			rm -Rf ${PROPATH}
			break ;;
		[Nn]* ) 
			echo "OK, clean manually this:"    
			ls -l ${PROPATH}
			break ;;
    	* ) echo "Please answer yes [Yy] or no [Nn]." ;;	
    esac	
done
	
echo 
		
# Some cleaning 
while true ; do
	read -p "WHEN ALL PROCESSES ARE DONE !! : Do you want to clean Processing dirs ? "  yn
		case $yn in
		[Yy]* ) 
			for i in `seq 1 ${N}`
				do
					echo "Removing  ${DISKPATH[$i]}*"
					rm -Rf ${DISKPATH[$i]}*
					echo
			done
			break ;;
		[Nn]* ) 
			echo "OK, clean manually this:"    
			for i in `seq 1 ${N}`
				do
					echo "${DISKPATH[$i]}*"
			done
			break ;;
    	* ) echo "Please answer yes [Yy] or no [Nn]." ;;	
    esac	
done
