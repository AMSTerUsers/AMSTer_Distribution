#!/bin/bash
# -----------------------------------------------------------------------------------------
# This script is aiming at plotting the baseline of all the pairs for which links to deformation 
#   are stored in subdirs of WHERE_MSBAS_IS_PROCESSED/Modes. 
#   Pairs characteristics are taken from first Mode. 
#
#  MUST BE RUN FROM WHERE_MSBAS_IS_PROCESSED
#
# Parameters : - path to SAR_SM/MSBAS/REGION/set"i" where "i" is the first mode in MSBAS processing
#              - mode (as for Prepa_MSBAS.sh; e.g. DefoInterpolx2Detrend)
#              - number of mode in MSBAS processing (given by the number at the end of MODE subdir)
#
# Dependencies:	- gsed
#
# Hard coded:	- Some hard coded info about plot style : title, range, font, color...
#
# New in Distro V 1.0:	- Based on developpement version and Beta V1.2
# New in Distro V 1.1:	- add creation date label
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/04/28 - could make better... when time.
# -----------------------------------------------------------------------------------------
PRG=`basename "$0"`
VER="Distro V1.1 MasTer script utilities"
AUT="Nicolas d'Oreye, (c)2016-2019, Last modified on Dec 10, 2020"
echo " "
echo "${PRG} ${VER}, ${AUT}"
echo " "


PATHTOSET=$1      # e.g. /Volumes/hp-1650-Data_Share1/SAR_SM/MSBAS/VVP/set6
MODE=$2		# e.g. DefoInterpolx2Detrend
IEMODE=$3	# e.g. 1

RUNDIR="$(pwd)"
cp ${PATHTOSET}/initBaselines.txt ${RUNDIR}/initBaselines.txt

cd ${RUNDIR}/${MODE}${IEMODE}

# test sat
#SAT=`ls *deg | head -1 | grep S1 | wc -w`  # 1 if S1, 0 instead

echo "	Master	Slave	Bperp		Delay" > ${RUNDIR}/TableFromMode_${MODE}${IEMODE}.txt
echo ""  >> ${RUNDIR}/TableFromMode_${MODE}${IEMODE}.txt

for img in `ls *deg`
	do 
		MASDATE=${img#*deg_} 
		MASDATE=`echo $MASDATE | cut -d _ -f 1`

		SLVDATE=${img#*deg_} 
		SLVDATE=`echo $SLVDATE | cut -d _ -f 2`

		BP=${img#*Bp} ; 
		BP=`echo $BP | cut -d m -f 1  | xargs printf "%.*f\n" 0`

		BT=${img#*BT} 
		BT=`echo $BT | cut -d d -f 1`

		echo "${MASDATE}	${SLVDATE}	${BP}		${BT}" >> ${RUNDIR}/TableFromMode_${MODE}${IEMODE}.txt
done 

cd ${RUNDIR}

	echo "ComputeBaselinesPlotFile TableFromMode_${MODE}${IEMODE}.txt"
	computeBaselinesPlotFile ${RUNDIR}/TableFromMode_${MODE}${IEMODE}.txt
	
	# X axis is in time format and delay must be given in second
	# Y axis origin is the position at the time of first acquisition
	${PATHGNU}/gnuplot << EOF
		set xdata time
		set timefmt "%Y%m%d"
		set format x "%d %m %Y"
		set title "Spatial and temporal baselines \nfrom ${MODE}${IEMODE}"
		set xlabel "Time [dd/mm/yyyy] "
		set ylabel "Position [m]"
		set autoscale
#		set yrange [-2000:2000] 
		
		set ytics font "Helvetica,20" 
		set xtics 5184000 font "Helvetica,20" rotate by 45 right     # every 2 months
#		set xtics 1209600 font "Helvetica,20" rotate by 45 right     # every 2 weeks
#		set xtics 3456000 font "Helvetica,20" rotate by 45 right     # every two months
#		set xtics 1728000 font "Helvetica,20" rotate by 45 right     # every month
		set mxtics 8 
						
		set output "span_FlatArrow_${BP}m_${BT}days_${MODE}${IEMODE}.eps" 
		set term postscript color enhanced "Helvetica,20"

		set style arrow 1 back nofilled nohead linetype 3 linecolor rgb "red"  linewidth 2.0 size screen 0.008,90.0,90.0

		set timestamp "Created by MasTer at ECGS on: %d/%m/%y %H:%M " font "Helvetica,8" textcolor rgbcolor "#2a2a2a" 

		#plot 'dataBaselinesPlot.txt' u 1:2:3:4 with vectors arrowstyle 1 title 'set1'
		plot 'dataBaselinesPlot.txt' u 1:2:3:4 with vectors arrowstyle 1 notitle 
EOF
	
rm  ${RUNDIR}/initBaselines.txt
