#!/bin/bash
######################################################################################
# This script is aiming at copying the jpg and binaries + hdr from a given mode 
#      in _AMPLI in original dir.
#
# Parameters :  - ORIGIN dir (usually TARGET dir from ALL2GIF.sh script)
#					Usually something like ..YourPath.../SAR_SM/AMPLITUDES/SAT/TRK/REGION
#
# Dependencies:	 none
#
# New in Distro V 1.0:	- Based on developpement version 1.2 and Beta V1.0.2
# New in Distro V 1.1:	- Also for S1 calibarted images
# New in Distro V 1.2:	- mute error if no sigma0 images
#						- report if dir is missing jpg file 
# New in Distro V 1.3:	- proper path to list of missing files
# 
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2017/10/09 - could make better... when time.
######################################################################################
PRG=`basename "$0"`
VER="Distro V1.3 MasTer script utilities"
AUT="Nicolas d'Oreye, (c)2016-2019, Last modified on Nov 10, 2020"
echo " "
echo "${PRG} ${VER}, ${AUT}"
echo " " 

ORIGIN=$1  # Usually something like ..YourPath.../SAR_SM/AMPLITUDES/SAT/TRK/REGION

if [ $# -lt 1 ] ; then echo “Usage $0 ORIGINDIR”; exit; fi

cd ${ORIGIN}

mkdir -p _AMPLI

DESTINATION=${ORIGIN}/_AMPLI/

ls | ${PATHGNU}/grep -v txt | ${PATHGNU}/grep -v _AMPLI  > DirList.txt

echo "Missing jpg file in :" > ${ORIGIN}/_Missing_files.txt
for DIR in `cat DirList.txt`
do
	cd ${DIR}/i12/InSARProducts
	if [ `ls *.jpg 2>/dev/null | wc -l` -eq 0 ] 
		then 
			echo "Missing jpg in ${DIR}" 
			echo "${DIR}" >> ${ORIGIN}/_Missing_files.txt
		else 
			for file in *.jpg 
				do 
					PREFIXFIG=`basename ${file} | cut -c 1-2`
					if [ ${PREFIXFIG} == "S1" ] # For S1, remove info about S1A or S1B in naming to avoid unsorted images in gif			
						then
							IMAGE=`echo ${file} | sed "s/S1A_//" | sed "s/S1B_//"`
							cp -n ${file} ${DESTINATION}/${IMAGE} 
							# ln -sf ${DESTINATION}/${IMAGE} ${DESTINATION}/${file} # Keep track of original name - do not use while it duplicates the images in the gif
						else
							cp -n ${file} ${DESTINATION}
					fi
				done
			for file in *.mod.fl?p.hdr ; do cp -n ${file} ${DESTINATION} ; done
			for file in *.mod.fl?p ; do cp -n ${file} ${DESTINATION} ; done
			if [ `ls *.sigma0.* 2>/dev/null | wc -l` -ge 1 ] 
				then 
					for file in *.sigma0.fl?p ; do cp -n ${file} ${DESTINATION} ; done 
			fi
			for file in incidence.fl?p ; do cp -n ${file} ${DESTINATION} ; done
			for file in incidence.fl?p.hdr ; do cp -n ${file} ${DESTINATION} ; done
	fi
	cd ${ORIGIN}
done

rm DirList.txt


