#!/bin/bash
# Script to run in cronjob for processing VVP images:
# Read images, check if nr of bursts and corners coordinates are OK, 
# corigister them on a super master and compute the compatible pairs.
# It also creates a common baseline plot for  ascending and descending modes. 

# New in Distro V 2.0.0 20220517 :	-use new Prepa_MSBAS.sh based on DD tools instead of L. Libert tools
# New in Distro V 2.1.0 20220602 :	- use new Prepa_MSBAS.sh compatible with D Derauw and L. Libert tools for Baseline Ploting
# New in Distro V 3.0.0 20221215 :	- restart from scratch, using new Copernicus DEM (2014) referenced to Ellipsoid
#									- more path and variable in param at the beginning of the script
# New in Distro V 3.0.0 20230104 :	- Use Read_All_Img.sh V3 which requires 3 more parameters (POl + paths  to RESAMPLED and to SAR_MASSPROCESS) 
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------


source $HOME/.bashrc

# Some variables
#################

BP=20
BT=400

SMASC=20150310
SMDESC=20151014

# Path to RAW data
PATHRAW=$PATH_3600/SAR_DATA/S1/S1-DATA-DRCONGO-SLC.UNZIP

# Path to SAR_CSL data
PATHCSL=$PATH_1660/SAR_CSL/S1

# Path to RESAMPLED data
NEWASCPATH=$PATH_3610/SAR_SM/RESAMPLED/S1/DRC_VVP_A_174/SMNoCrop_SM_20150310
NEWDESCPATH=$PATH_3610/SAR_SM/RESAMPLED/S1/DRC_VVP_D_21/SMNoCrop_SM_20151014

# Path to Seti
PATHSETI=$PATH_1660/SAR_SM/MSBAS


# Parameters files for Coregistration
PARAMASC=$PATH_DataSAR/SAR_AUX_FILES/Param_files_SuperMaster/S1/DRC_VVP_A_174/LaunchMEparam_S1_VVP_Asc_Zoom1_ML4_snaphu_square_Coreg.txt
PARAMDESC=$PATH_DataSAR/SAR_AUX_FILES/Param_files_SuperMaster/S1/DRC_VVP_D_21/LaunchMEparam_S1_VVP_Desc21_Zoom1_ML4_snaphu_square_Coreg.txt


# Read all S1 images for that footprint
#######################################
 $PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh ${PATHRAW} ${PATHCSL}/DRC_VVP/NoCrop S1 ${PATHCSL}/DRC_VVP/VVP.kml VV ${PATH_3610}/SAR_SM/RESAMPLED/ ${PATH_HOMEDATA}/SAR_MASSPROCESS/  > /dev/null 2>&1

# Check nr of bursts and coordinates of corners. If not as expected, move img in temp quatantine and log that. Check regularily: if not updated after few days, it means that image is bad or zip file not correctly downloaded
################################################
# Asc ; bursts size and coordinates are obtained by running e.g.:  _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/DRC_VVP_A_174/NoCrop/S1B_174_20210928_A.csl Dummy
_Check_ALL_S1_SizeAndCoord_InDir.sh ${PATHCSL}/DRC_VVP_A_174/NoCrop 16 28.7532 -2.4225 30.2811 -2.0896 28.4441 -0.9607 29.9705 -0.6309 

# Desc ; bursts size and coordinates are obtained by running e.g.: _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/DRC_VVP_D_21/NoCrop/S1B_21_20211105_D.csl Dummy
# Beware D21 are using 17 or 18 burst. The 18th to the SW is however useless, hence check on range from 17 bursts then check the images in __TMP_QUARANTINE with 18 bursts coordinates. 
#        If OK, put them back in NoCrop dir. If not, keep them in original __TMP_QUARANTINE
_Check_ALL_S1_SizeAndCoord_InDir.sh ${PATHCSL}/DRC_VVP_D_21/NoCrop 17 30.4780 -1.0622 28.2704 -0.5847 30.1797 -2.4732 27.9701 -1.9911

_Check_ALL_S1_SizeAndCoord_InDir.sh ${PATHCSL}/DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE 18 30.4842 -1.0624  28.2689 -0.5833 30.1857 -2.4740 27.9684 -1.9903
	mv ${PATHCSL}/DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE/*.csl ${PATHCSL}/DRC_VVP_D_21/NoCrop/ 2>/dev/null
	mv ${PATHCSL}/DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE/__TMP_QUARANTINE/*.csl ${PATHCSL}DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE/ 2>/dev/null
	mv ${PATHCSL}/DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE/*.txt ${PATHCSL}/DRC_VVP_D_21/NoCrop/ 2>/dev/null
	rm -R $PATH_1660/SAR_CSL/S1/DRC_VVP_D_21/NoCrop/__TMP_QUARANTINE/__TMP_QUARANTINE 2>/dev/null

# Coregister all images on the super master 
###########################################
# in Ascending mode 
 $PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh ${PARAMASC} &
# in Descending mode 
 $PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh ${PARAMDESC} &



# Search for pairs
##################
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh ${PATHCSL}/DRC_VVP_A_174/NoCrop ${PATHSETI}/VVP/set6 S1 > /dev/null 2>&1  &
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh ${PATHCSL}/DRC_VVP_D_21/NoCrop ${PATHSETI}/VVP/set7 S1 > /dev/null 2>&1 &
wait

# Compute pairs only if new data is identified
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh ${PATHSETI}/VVP/set6 ${BP} ${BT} ${SMASC} > /dev/null 2>&1  &
fi
if [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh ${PATHSETI}/VVP/set7 ${BP} ${BT} ${SMDESC} > /dev/null 2>&1  &
fi
wait

# Plot baseline plot with both modes 
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] || [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 

	if [ `baselinePlot | wc -l` -eq 0 ] 
		then
			# use MasTer Engine before May 2022	
			mkdir -p ${PATHSETI}/VVP/BaselinePlots_set6_set7
			cd ${PATHSETI}/VVP/BaselinePlots_set6_set7

			echo "${PATHSETI}/VVP/set6" > ModeList.txt
			echo "${PATHSETI}/VVP/set7" >> ModeList.txt

			plot_Multi_BaselinePlot.sh ${PATHSETI}/VVP/BaselinePlots_set6_set7/ModeList.txt
		else
			# use MasTer Engine > May 2022
			mkdir -p ${PATHSETI}/VVP/BaselinePlots_set6_set7
			cd ${PATHSETI}/VVP/BaselinePlots_set6_set7
 
			echo "${PATHSETI}/VVP/set6" > ModeList.txt
			echo "${PATHSETI}/VVP/set7" >> ModeList.txt
 
			plot_Multi_BaselinePlot.sh ${PATHSETI}/VVP/BaselinePlots_set6_set7/ModeList.txt
 	fi

fi

