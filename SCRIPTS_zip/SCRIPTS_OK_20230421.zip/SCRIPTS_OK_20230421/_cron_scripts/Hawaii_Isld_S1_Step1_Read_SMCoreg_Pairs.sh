#!/bin/bash
# Script to run in cronjob for processing Hawaii Ilslnd images:
# Read images, corigister them on a super master and compute the compatible pairs.
# It also creates a common baseline plot for  ascending and descending modes. 

# New in Distro V 2.0.0 20220602 :	- use new Prepa_MSBAS.sh compatible with D Derauw and L. Libert tools for Baseline Ploting
# New in Distro V 3.0.0 20230104 :	- Use Read_All_Img.sh V3 which requires 3 more parameters (POl + paths  to RESAMPLED and to SAR_MASSPROCESS) 

#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------
source $HOME/.bashrc

BP=50
BT=50
NEWASCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/Hawaii_Isld_A_124/SMNoCrop_SM_
NEWDESCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/Hawaii_Isld_D_87/SMNoCrop_SM_


# Read all S1 images for that footprint
#######################################
 $PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh $PATH_3601/SAR_DATA_Other_Zones/S1/S1-DATA-HAWAII-SLC.UNZIP $PATH_3601/SAR_CSL_Other_Zones/S1/Hawaii_Isld/NoCrop S1 $PATH_3601/SAR_CSL_Other_Zones/S1/Hawaii_Isld/Hawaii_Isld.kml VV ${PATH_3602}/SAR_SM_Other_Zones/RESAMPLED/ ${PATH_3601}/SAR_MASSPROCESS/  > /dev/null 2>&1

# Coregister all images on the super master 
###########################################
# in Ascending mode 
 $PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/S1/Hawaii_Isld_A_124/LaunchCISparam_S1_Hawaii_Isld_Asc_Zoom1_ML4_original_Coreg.txt &
# in Descending mode 
 $PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/S1/Hawaii_Isld_D_87/LaunchCISparam_S1_Hawaii_Isld_Desc_Zoom1_ML4_original_Coreg.txt &



# Search for pairs
##################
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_3601/SAR_CSL_Other_Zones/S1/Hawaii_Isld_A_124/NoCrop $PATH_1650/SAR_SM/MSBAS/Hawaii/set1 S1 > /dev/null 2>&1  &
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_3601/SAR_CSL_Other_Zones/S1/Hawaii_Isld_D_87/NoCrop $PATH_1650/SAR_SM/MSBAS/Hawaii/set2 S1 > /dev/null 2>&1 &
wait

# Compute pairs only if new data is identified
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/Hawaii/set1 ${BP} ${BT} 20190521 > /dev/null 2>&1  &
fi
if [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/Hawaii/set2 ${BP} ${BT} 20190524 > /dev/null 2>&1  &
fi
wait

# Plot baseline plot with both modes 
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] || [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
	if [ `baselinePlot | wc -l` -eq 0 ] 
		then
			# use MasTer Engine before May 2022
			mkdir -p $PATH_1650/SAR_SM/MSBAS/Hawaii/BaselinePlots_S1_set_1_2
			cd $PATH_1650/SAR_SM/MSBAS/Hawaii/BaselinePlots_S1_set_1_2

			echo "$PATH_1650/SAR_SM/MSBAS/Hawaii/set1" > ModeList.txt
			echo "/$PATH_1650/SAR_SM/MSBAS/Hawaii/set2" >> ModeList.txt

			$PATH_SCRIPTS/SCRIPTS_OK/plot_Multi_span.sh ModeList.txt 0 ${BP} 0 ${BT}   $PATH_SCRIPTS/SCRIPTS_OK/ColorTable_AD.txt
		else
			# use MasTer Engine > May 2022
			mkdir -p $PATH_1650/SAR_SM/MSBAS/Hawaii/BaselinePlots_set1_set2
			cd $PATH_1650/SAR_SM/MSBAS/Hawaii/BaselinePlots_set1_set2
 
			echo "$PATH_1650/SAR_SM/MSBAS/Hawaii/set1" > ModeList.txt
			echo "/$PATH_1650/SAR_SM/MSBAS/Hawaii/set2" >> ModeList.txt
 
			plot_Multi_BaselinePlot.sh $PATH_1650/SAR_SM/MSBAS/Hawaii/BaselinePlots_set1_set2/ModeList.txt
 	fi

fi

