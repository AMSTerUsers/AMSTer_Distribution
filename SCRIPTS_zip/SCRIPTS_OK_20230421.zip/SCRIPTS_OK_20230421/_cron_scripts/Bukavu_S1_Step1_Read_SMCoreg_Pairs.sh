#!/bin/bash
# Script to run in cronjob for processing Bukavu images:
# Read images, corigister them on a super master and compute the compatible pairs.
# It also creates a common baseline plot for  ascending and descending modes. 

# New in Distro V 2.0.0 20220602 :	- use new Prepa_MSBAS.sh compatible with D Derauw and L. Libert tools for Baseline Ploting
# New in Distro V 3.0.0 20230104 :	- Use Read_All_Img.sh V3 which requires 3 more parameters (POl + paths  to RESAMPLED and to SAR_MASSPROCESS) 
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------
source $HOME/.bashrc

# Read all S1 images for that footprint
#######################################
# No ${PATH_3601}/SAR_MASSPROCESS/  because not processed
${PATH_SCRIPTS}/SCRIPTS_OK/Read_All_Img.sh /$PATH_3600/SAR_DATA/S1/S1-DATA-DRCONGO-SLC.UNZIP /$PATH_1650/SAR_CSL/S1/DRC_Bukavu/NoCrop S1 /$PATH_1650/SAR_CSL/S1/DRC_Bukavu/BUK.kml VV ${PATH_1650}/SAR_SM/RESAMPLED/ > /dev/null 2>&1

# Coregister all images on the super master 
###########################################
# in Ascending mode 
#/Users/doris/PROCESS/SCRIPTS_OK/SuperMasterCoreg.sh /Volumes/hp-1650-Data_Share1/Param_files_SuperMaster/S1/Bukavu_Asc_174/LaunchCISparam_S1_BukavuAsc_Zoom1_ML2.txt &
# in Descending mode 
#/Users/doris/PROCESS/SCRIPTS_OK/SuperMasterCoreg.sh /Users/doris/PROCESS/SCRIPTS_OK/Param_files_SuperMaster/S1/Bukavu_Desc_21/LaunchCISparam_S1_Bukavu_Desc__Zoom1_ML2.txt &

# Search for pairs
##################
# Link all images to corresponding set dir
${PATH_SCRIPTS}/SCRIPTS_OK/lns_All_Img.sh /$PATH_1650/SAR_CSL/S1/DRC_Bukavu_A_174/NoCrop /$PATH_1650/SAR_SM/MSBAS/Bukavu/set3 S1 > /dev/null 2>&1  &
${PATH_SCRIPTS}/SCRIPTS_OK/lns_All_Img.sh /$PATH_1650/SAR_CSL/S1/DRC_Bukavu_D_21/NoCrop /$PATH_1650/SAR_SM/MSBAS/Bukavu/set4 S1 > /dev/null 2>&1 &
wait

# Compute pairs 
echo "n" | Prepa_MSBAS.sh /$PATH_1650/SAR_SM/MSBAS/Bukavu/set3 60 60 20160608 > /dev/null 2>&1  &
echo "n" | Prepa_MSBAS.sh /$PATH_1650/SAR_SM/MSBAS/Bukavu/set4 80 100 20160517 > /dev/null 2>&1  &

wait

# Plot baseline plot with both modes 
# mkdir -p /Volumes/hp-1650-Data_Share1/SAR_SM/MSBAS/Bukavu/BaselinePlots_S1_set_3_4
# cd /Volumes/hp-1650-Data_Share1/SAR_SM/MSBAS/Bukavu/BaselinePlots_S1_set_3_4
# 
# echo "/Volumes/hp-1650-Data_Share1/SAR_SM/MSBAS/Bukavu/set3" > ModeList.txt
# echo "/Volumes/hp-1650-Data_Share1/SAR_SM/MSBAS/Bukavu/set4" >> ModeList.txt
# 
# /Users/doris/PROCESS/SCRIPTS_OK/plot_Multi_span_multi_Baselines.sh ModeList.txt 0 60 0 60 /Users/doris/PROCESS/SCRIPTS_OK/ColorTable_AD.txt 0 80 0 100

	if [ `baselinePlot | wc -l` -eq 0 ] 
		then
			# use MasTer Engine before May 2022
			mkdir -p $PATH_1650/SAR_SM/MSBAS/Bukavu/BaselinePlots_S1_set_3_4
			cd $PATH_1650/SAR_SM/MSBAS/Bukavu/BaselinePlots_S1_set_3_4

			echo "$PATH_1650/SAR_SM/MSBAS/Bukavu/set3" > ModeList.txt
			echo "$PATH_1650/SAR_SM/MSBAS/Bukavu/set4" >> ModeList.txt

			 ${PATH_SCRIPTS}/SCRIPTS_OK/plot_Multi_span.sh ModeList.txt 0 60 0 60 ${PATH_SCRIPTS}/SCRIPTS_OK/ColorTable_AD.txt		
		else
			# use MasTer Engine > May 2022
			mkdir -p $PATH_1650/SAR_SM/MSBAS/Bukavu/BaselinePlots_set3_set4
			cd $PATH_1650/SAR_SM/MSBAS/Bukavu/BaselinePlots_set3_set4
 
			echo "$PATH_1650/SAR_SM/MSBAS/Bukavu/set3" > ModeList.txt
			echo "$PATH_1650/SAR_SM/MSBAS/Bukavu/set4" >> ModeList.txt
 
			plot_Multi_BaselinePlot.sh $PATH_1650/SAR_SM/MSBAS/Bukavu/BaselinePlots_set3_set4/ModeList.txt
 	fi
