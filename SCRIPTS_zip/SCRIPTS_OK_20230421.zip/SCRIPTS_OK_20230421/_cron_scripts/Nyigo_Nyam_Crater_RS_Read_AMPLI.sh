#!/bin/bash
# Script to run in cronjob for processing Nyiragongo and Nyamulagira Crater amplitude images

source $HOME/.bashrc

# Read all RS images for these footprints
# Asc UF
/$PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh $PATH_3600/SAR_DATA/RADARSAT/RS2_UF_Asc $PATH_1650/SAR_CSL/RADARSAT/RS2_UF_Asc/NoCrop RADARSAT > /dev/null 2>&1
# Desc F2F 
/$PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh $PATH_3600/SAR_DATA/RADARSAT/RS2_F2F_Desc $PATH_1650/SAR_CSL/RADARSAT/RS2_F2F_Desc/NoCrop RADARSAT > /dev/null 2>&1


# ALL2GIFF
# Asc UF Nyigo Crater - in background so that it can start at the same time the descending
/$PATH_SCRIPTS/SCRIPTS_OK/ALL2GIF.sh 20151201 /$PATH_SCRIPTS/SCRIPTS_OK/Param_files/RS/RS2_UH_Asc36deg/LaunchCISparam_RS_UH_NyigoCrater_Zoom1_ML1_snaphu_ORIGINAL.txt 280 400 & 
# Asc UF Nyam - in background so that it can start at the same time the descending
/$PATH_SCRIPTS/SCRIPTS_OK/ALL2GIF.sh 20151201 /$PATH_SCRIPTS/SCRIPTS_OK/Param_files/RS/RS2_UH_Asc36deg/LaunchCISparam_RS_UH_Nyam_Zoom1_ML1_snaphu.txt 530 1300 & 
# Desc F2F Nyigo Crater - in background so that it can start at the same time the descending
/$PATH_SCRIPTS/SCRIPTS_OK/ALL2GIF.sh 20100328 /$PATH_SCRIPTS/SCRIPTS_OK/Param_files/RS/RS2_F2F_Desc40deg/LaunchCISparam_RS_F2F_NyigoCrater_Zoom1_ML1_snaphu.txt 260 200 &
# Desc F2F Nyam - in background so that it can start at the same time the descending
/$PATH_SCRIPTS/SCRIPTS_OK/ALL2GIF.sh 20100328 /$PATH_SCRIPTS/SCRIPTS_OK/Param_files/RS/RS2_F2F_Desc40deg/LaunchCISparam_RS_F2F_Nyam_Zoom1_ML1_snaphu.txt 800 1220 & 

