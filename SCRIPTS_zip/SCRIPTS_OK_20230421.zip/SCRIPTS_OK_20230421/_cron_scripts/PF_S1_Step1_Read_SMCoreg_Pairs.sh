#!/bin/bash
# Script to run in cronjob for processing PITON DE LA FOURNAISE images:
# Read images, check if nr of bursts and corners coordinates are OK (for IW), 
# corigister them on a super master and compute the compatible pairs.
# It also creates a common baseline plot for  ascending and descending modes. 

# New in Distro V 2.0.0 20220602 :	- use new Prepa_MSBAS.sh compatible with D Derauw and L. Libert tools for Baseline Ploting
# New in Distro V 3.0.0 20230104 :	- Use Read_All_Img.sh V3 which requires 3 more parameters (POl + paths  to RESAMPLED and to SAR_MASSPROCESS) 
# New in Distro V 3.1.0 20230316 :	- Set double criteria 
#									- remove S1B and multiple baseline plot since only one is available
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------

source $HOME/.bashrc

echo "Starting $0" > $PATH_1650/SAR_CSL/S1/PF_IW/Last_Run_Cron_Step1.txt
date >> $PATH_1650/SAR_CSL/S1/PF_IW/Last_Run_Cron_Step1.txt

# IW mode

BP=70
BT=70

BP2=90
BT2=70
DATECHG=20220501

#####NEWASCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/PF_IW_A_144/SMNoCrop_SM_20180831
NEWDESCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/PF_IW_D_151/SMNoCrop_SM_20200622

# Read all S1 images for that footprint
#######################################
$PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh $PATH_3601/SAR_DATA_Other_Zones/S1/S1-DATA-REUNION-SLC.UNZIP $PATH_1650/SAR_CSL/S1/PF_IW/NoCrop S1 ${PATH_1650}/kml/Reunion/Reunion_Island.kml VV ${PATH_1650}/SAR_SM/RESAMPLED/ ${PATH_3601}/SAR_MASSPROCESS/ > /dev/null 2>&1

# Check nr of bursts and coordinates of corners. If not as expected, move img in temp quatantine and log that. Check regularily: if not updated after few days, it means that image is bad or zip file not correctly downloaded
################################################
# Asc ; bursts size and coordinates are obtained by running e.g.:  _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/PF_IW_A_144/NoCrop/S1A_144_20211225_A.csl Dummy
#####_Check_ALL_S1_SizeAndCoord_InDir.sh $PATH_1650/SAR_CSL/S1/PF_IW_A_144/NoCrop 10 54.6377 -21.8412 56.2373 -21.4598 54.3887 -20.8858 55.9777 -20.50789
# Desc ; bursts size and coordinates are obtained by running e.g.: _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/PF_IW_D_151/NoCrop/S1A_151_20211214_D.csl Dummy
# Beware D151 are using 9 or 8 burst. The extra burst is however useless, hence check on range from 9 bursts then check the images in __TMP_QUARANTINE with 8 bursts coordinates. 
#        If OK, put them back in NoCrop dir. If not, keep them in original __TMP_QUARANTINE
_Check_ALL_S1_SizeAndCoord_InDir.sh $PATH_1650/SAR_CSL/S1/PF_IW_D_151/NoCrop 9 56.7687 -20.9831 55.1337 -20.6023 56.5533 -21.8321 54.9081 -21.4484

_Check_ALL_S1_SizeAndCoord_InDir.sh $PATH_1650/SAR_CSL/S1/PF_IW_D_151/NoCrop/__TMP_QUARANTINE 8 56.7695 -20.9828 55.1343 -20.6019 56.5541 -21.8318 54.9087 -21.4480
	mv $PATH_1650/SAR_CSL/S1/PF_IW_D_151/NoCrop/__TMP_QUARANTINE/*.csl $PATH_1650/SAR_CSL/S1/PF_IW_D_151/NoCrop/ 2>/dev/null
	mv $PATH_1650/SAR_CSL/S1/PF_IW_D_151/NoCrop/__TMP_QUARANTINE/__TMP_QUARANTINE/*.csl $PATH_1650/SAR_CSL/S1/PF_IW_D_151/NoCrop/__TMP_QUARANTINE/ 2>/dev/null
	mv $PATH_1650/SAR_CSL/S1/PF_IW_D_151/NoCrop/__TMP_QUARANTINE/*.txt $PATH_1650/SAR_CSL/S1/PF_IW_D_151/NoCrop/ 2>/dev/null
	rm -R $PATH_1650/SAR_CSL/S1/PF_IW_D_151/NoCrop/__TMP_QUARANTINE/__TMP_QUARANTINE 2>/dev/null

# Coregister all images on the super master 
###########################################
# in Ascending mode 
#####$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/S1/PF_IW_A_144/LaunchCISparam_S1_IW_Reunion_Asc_Zoom1_ML2_Coreg.txt &
# in Descending mode 
$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/S1/PF_IW_D_151/LaunchCISparam_S1_IW_Reunion_Desc_Zoom1_ML2_Coreg.txt &

# Search for pairs
##################
# Link all images to corresponding set dir
#####$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_1650/SAR_CSL/S1/PF_IW_A_144/NoCrop $PATH_1650/SAR_SM/MSBAS/PF/set3 S1 > /dev/null 2>&1  &
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_1650/SAR_CSL/S1/PF_IW_D_151/NoCrop $PATH_1650/SAR_SM/MSBAS/PF/set4 S1 > /dev/null 2>&1 &
wait

# Compute pairs 
# Compute pairs only if new data is identified
#####if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] ; then 
#####	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/PF/set3 ${BP} ${BT} 20180831 > /dev/null 2>&1  &
#####fi
if [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/PF/set4 ${BP} ${BT} 20200622 ${BP2} ${BT2} ${DATECHG} > /dev/null 2>&1  &
fi
wait

# Plot baseline plot with both modes 
#####if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] || [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
#####
#####	if [ `baselinePlot | wc -l` -eq 0 ] 
#####		then
#####			# use MasTer Engine before May 2022
#####			mkdir -p $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_S1_set_3_4
#####			cd $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_S1_set_3_4
#####
#####			echo "$PATH_1650/SAR_SM/MSBAS/PF/set3" > ModeList.txt
#####			echo "/$PATH_1650/SAR_SM/MSBAS/PF/set4" >> ModeList.txt
#####
#####			$PATH_SCRIPTS/SCRIPTS_OK/plot_Multi_span.sh ModeList.txt 0 ${BP} 0 ${BT}   $PATH_SCRIPTS/SCRIPTS_OK/ColorTable_AD.txt
#####		else
#####			# use MasTer Engine > May 2022
#####			mkdir -p $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_set3_set4
#####			cd $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_set3_set4
##### 
#####			echo "$PATH_1650/SAR_SM/MSBAS/PF/set3" > ModeList.txt
#####			echo "/$PATH_1650/SAR_SM/MSBAS/PF/set4" >> ModeList.txt
##### 
#####			plot_Multi_BaselinePlot.sh $PATH_1650/SAR_SM/MSBAS/VPFVP/BaselinePlots_set3_set4/ModeList.txt
##### 	fi
#####fi

echo "Ending $0" >> $PATH_1650/SAR_CSL/S1/PF_IW/Last_Run_Cron_Step1.txt
date >> $PATH_1650/SAR_CSL/S1/PF_IW/Last_Run_Cron_Step1.txt
