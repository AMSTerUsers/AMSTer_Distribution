#!/bin/bash
# Script to run in cronjob for processing PITON DE LA FOURNAISE images:
# Read images, corigister them on a super master and compute the compatible pairs.
# It also creates a common baseline plot for  ascending and descending modes. 

# New in Distro V 2.0.0 20220602 :	- use new Prepa_MSBAS.sh compatible with D Derauw and L. Libert tools for Baseline Ploting
# New in Distro V 3.0.0 20230104 :	- Use Read_All_Img.sh V3 which requires 3 more parameters (POl + paths  to RESAMPLED and to SAR_MASSPROCESS) 
# New in Distro V 3.1.0 20230316 :	- Set double criteria 
#									- remove S1B and multiple baseline plot since only one is available
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------

source $HOME/.bashrc

echo "Starting $0" > $PATH_1650/SAR_CSL/S1/PF_SM/Last_Run_Cron_Step1.txt
date >> $PATH_1650/SAR_CSL/S1/PF_SM/Last_Run_Cron_Step1.txt

# SM mode

BP=50
BT=50

BP2=90
BT2=50
DATECHG=20220501


NEWASCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/PF_SM_A_144/SMNoCrop_SM_20190808
####NEWDESCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/PF_SM_D_151/SMNoCrop_SM_20181013

# Read all S1 images for that footprint
#######################################
$PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh $PATH_3601/SAR_DATA_Other_Zones/S1/S1-DATA-REUNION_SM-SLC.UNZIP $PATH_1650/SAR_CSL/S1/PF_SM/NoCrop S1 ${PATH_1650}/kml/Reunion/Reunion_Island.kml VV ${PATH_1650}/SAR_SM/RESAMPLED/ ${PATH_3601}/SAR_MASSPROCESS/  > /dev/null 2>&1

# Coregister all images on the super master 
###########################################
# in Ascending mode 
$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/S1/PF_SM_A_144/LaunchCISparam_S1_SM_Reunion_Asc_Zoom1_ML8_Coreg.txt &
# in Descending mode 
####$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh $PATH_1650/Param_files_SuperMaster/S1/PF_SM_D_151/LaunchCISparam_S1_SM_Reunion_Desc_Zoom1_ML8_Coreg.txt &

# Search for pairs
##################
# Link all images to corresponding set dir
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_1650/SAR_CSL/S1/PF_SM_A_144/NoCrop $PATH_1650/SAR_SM/MSBAS/PF/set1 S1 > /dev/null 2>&1  &
####$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh $PATH_1650/SAR_CSL/S1/PF_SM_D_151/NoCrop $PATH_1650/SAR_SM/MSBAS/PF/set2 S1 > /dev/null 2>&1 &
wait

# Compute pairs 
# Compute pairs only if new data is identified
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/PF/set1 ${BP} ${BT} 20190808  ${BP2} ${BT2} ${DATECHG} > /dev/null 2>&1  &
fi
####if [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
####	echo "n" | Prepa_MSBAS.sh $PATH_1650/SAR_SM/MSBAS/PF/set2 ${BP} ${BT} 20181013 > /dev/null 2>&1  &
####fi
wait

##### Plot baseline plot with both modes 
####if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] || [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
####
####	if [ `baselinePlot | wc -l` -eq 0 ] 
####		then
####			# use MasTer Engine before May 2022
####			mkdir -p $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_S1_set_1_2
####			cd $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_S1_set_1_2
####
####			echo "$PATH_1650/SAR_SM/MSBAS/PF/set1" > ModeList.txt
####			echo "$PATH_1650/SAR_SM/MSBAS/PF/set2" >> ModeList.txt
####
####			$PATH_SCRIPTS/SCRIPTS_OK/plot_Multi_span.sh ModeList.txt 0 ${BP} 0 ${BT}   $PATH_SCRIPTS/SCRIPTS_OK/ColorTable_AD.txt
####		else
####			# use MasTer Engine > May 2022
####			mkdir -p $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_set1_set2
####			cd $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_set1_set2
#### 
####			echo "$PATH_1650/SAR_SM/MSBAS/PF/set1" > ModeList.txt
####			echo "$PATH_1650/SAR_SM/MSBAS/PF/set2" >> ModeList.txt
#### 
####			plot_Multi_BaselinePlot.sh $PATH_1650/SAR_SM/MSBAS/PF/BaselinePlots_set1_set2/ModeList.txt
#### 	fi
####
####fi

echo "Ending $0" >> $PATH_1650/SAR_CSL/S1/PF_SM/Last_Run_Cron_Step1.txt
date >> $PATH_1650/SAR_CSL/S1/PF_SM/Last_Run_Cron_Step1.txt
