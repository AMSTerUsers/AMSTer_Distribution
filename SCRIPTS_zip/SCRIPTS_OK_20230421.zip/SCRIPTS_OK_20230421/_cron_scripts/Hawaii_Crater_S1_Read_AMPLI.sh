#!/bin/bash
# Script to run in cronjob for processing Hawaii Kilauea Crater amplitude images
#
# New in Distro V 3.0.0 20230104 :	- Use Read_All_Img.sh V3 which requires 3 more parameters (POl + paths  to RESAMPLED and to SAR_MASSPROCESS) 

source $HOME/.bashrc

# Read all S1 images for these footprints
# Kilauea
# NO SAR_MASSPROCESS provided because only for shadows
/$PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh /$PATH_3601/SAR_DATA_Other_Zones/S1/S1-DATA-HAWAII-SLC.UNZIP /$PATH_3601/SAR_CSL_Other_Zones/S1/Hawaii_LL/NoCrop S1 /$PATH_3601/SAR_CSL_Other_Zones/S1/Hawaii_LL/Hawaii_LL.kml VV ${PATH_3602}/SAR_SM_Other_Zones/RESAMPLED/   > /dev/null 2>&1


# ALL2GIFF
# Asc - in background so that it can start at the same time the descending
/$PATH_SCRIPTS/SCRIPTS_OK/ALL2GIF.sh 20170706 /$PATH_1650/Param_files_SuperMaster/S1/Hawaii_LL_A_124/LaunchCISparam_S1_HawaiiLLAsc_Zoom1_ML1_original_FOR_SHADOWS.txt 4860 1050 & 
# Desc - in background so that it can startNyam ascending
/$PATH_SCRIPTS/SCRIPTS_OK/ALL2GIF.sh 20170428 /$PATH_1650/Param_files_SuperMaster/S1/Hawaii_LL_D_87/LaunchCISparam_S1_Hawaii_LLDesc_Zoom1_ML1_original_FOR_SHADOWSl.txt 480 930 &

# need to wait for both to be done before going further
wait 
