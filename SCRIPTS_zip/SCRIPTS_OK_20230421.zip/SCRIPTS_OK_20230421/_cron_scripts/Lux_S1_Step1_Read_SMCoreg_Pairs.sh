#!/bin/bash
# Script to run in cronjob for processing Lux images:
# Read images, check if nr of bursts and corners coordinates are OK, 
# corigister them on a super master and compute the compatible pairs.
# It also creates a common baseline plot for  ascending and descending modes. 
#
# NOTE:	This script requires several adjustments in script body if transferred to another target. 
#		See all infos about Tracks and Sets
#
# New in Distro V 2.0.0 20201104 :	- move most of the parameters at the beginning
# New in Distro V 2.1.0 20201104 :	- check S1 nr of bursts and corner coordinates
# New in Distro V 2.0.0 20220602 :	- use new Prepa_MSBAS.sh compatible with D Derauw and L. Libert tools for Baseline Ploting
# New in Distro V 2.0.1 20220726 :	- store SAR_CSL data from LUX in 3602 instead of 1650
# New in Distro V 3.0.0 20230104 :	- Use Read_All_Img.sh V3 which requires 3 more parameters (POl + paths  to RESAMPLED and to SAR_MASSPROCESS) 

#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2016/03/25 - could make better... when time.
# -----------------------------------------------------------------------------------------

source $HOME/.bashrc

# Some variables 
################
# Max  baseline (for buliding msbas files)
BP=20
BT=400

#super masters
SMASC1=20170429
SMASC2=20170627
SMASC3=20180110

SMDESC1=20170904
SMDESC2=20170720
SMDESC3=20161109

# DO NOT FORGET TO ADJUST ALSO THE SET BELOWS IN SCRIPT

# some files and PATH
#####################
#SAR_DATA
DIRSARDATA=$PATH_3600/SAR_DATA/S1/S1-DATA-LUXEMBOURG-SLC.UNZIP
#SAR_CSL
DIRSARCSL=$PATH_3602/SAR_CSL_Other_Zones_2/S1/LUX
#SETi DIR
DIRSET=$PATH_1650/SAR_SM/MSBAS/LUX

#kml file
KMLFILE=$PATH_3602/SAR_CSL_Other_Zones_2/S1/LUX/Lux.kml

#Launch param files
PARAMCOREGASC1=$PATH_1650/Param_files_SuperMaster/S1/LUX_A_15/LaunchCISparam_S1_LUX_A_15_Zoom1_ML4_Coreg.txt 
PARAMCOREGASC2=$PATH_1650/Param_files_SuperMaster/S1/LUX_A_88/LaunchCISparam_S1_LUX_A_88_Zoom1_ML4_Coreg.txt 
PARAMCOREGASC3=$PATH_1650/Param_files_SuperMaster/S1/LUX_A_161/LaunchCISparam_S1_LUX_A_161_Zoom1_ML4_Coreg.txt

PARAMCOREGDESC1=$PATH_1650/Param_files_SuperMaster/S1/LUX_D_37/LaunchCISparam_S1_LUX_D_37_Zoom1_ML4_Coreg.txt
PARAMCOREGDESC2=$PATH_1650/Param_files_SuperMaster/S1/LUX_D_66/LaunchCISparam_S1_LUX_D_66_Zoom1_ML4_Coreg.txt
PARAMCOREGDESC3=$PATH_1650/Param_files_SuperMaster/S1/LUX_D_139/LaunchCISparam_S1_LUX_D_139_Zoom1_ML4_Coreg.txt

NEWASCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/LUX_A_88/SMNoCrop_SM_20170627
NEWDESCPATH=$PATH_1650/SAR_SM/RESAMPLED/S1/LUX_D_139/SMNoCrop_SM_20161109

#Color table 
COLORTABLE=$PATH_SCRIPTS/SCRIPTS_OK/ColorTable_AAADDD.txt	# for 6 data sets


# Prepare stuffs
################
echo "Starting $0" > ${DIRSARCSL}/Last_Run_Cron_Step1.txt
date >> ${DIRSARCSL}/Last_Run_Cron_Step1.txt

# Let's go
##########

# Read all S1 images for that footprint
$PATH_SCRIPTS/SCRIPTS_OK/Read_All_Img.sh ${DIRSARDATA} ${DIRSARCSL}/NoCrop S1 ${KMLFILE} VV ${PATH_1650}/SAR_SM/RESAMPLED/ ${PATH_3601}/SAR_MASSPROCESS/  > /dev/null 2>&1

# Check nr of bursts and coordinates of corners. If not as expected, move img in temp quatantine and log that. Check regularily: if not updated after few days, it means that image is bad or zip file not correctly downloaded
################################################
# Asc 15 ; bursts size and coordinates are obtained by running e.g.:  _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/LUX_A_15/NoCrop/S1B_15_20211011_A.csl Dummy
_Check_ALL_S1_SizeAndCoord_InDir.sh ${DIRSARCSL}_A_15/NoCrop 9 6.8222 48.8229 8.1231 48.9859 6.3521 50.3266 7.6950 50.4909
# Asc 88 ; bursts size and coordinates are obtained by running e.g.:  _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/LUX_A_88/NoCrop/S1B_88_20210922_A.csl Dummy
_Check_ALL_S1_SizeAndCoord_InDir.sh ${DIRSARCSL}_A_88/NoCrop 28 4.8726 48.4861 8.3603 48.8898 4.3200 50.2640 7.9401 50.6697
# Asc 161; bursts size and coordinates are obtained by running e.g.:  _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/LUX_A_161//NoCrop/S1B_161_20211114_A.csl Dummy
_Check_ALL_S1_SizeAndCoord_InDir.sh ${DIRSARCSL}_A_161/NoCrop 9 5.1415 48.8124 6.2892 48.9329 4.7493 50.3204 5.9337 50.4407

# Desc D_37; bursts size and coordinates are obtained by running e.g.:  _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/LUX_D_37/NoCrop/S1B_37_20211106_D.csl Dummy
_Check_ALL_S1_SizeAndCoord_InDir.sh ${DIRSARCSL}_D_37/NoCrop 18  7.3254 50.2898 4.7552 50.5903 6.8375 48.7272 4.3505 49.0257
# Desc D_66; bursts size and coordinates are obtained by running e.g.: _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/LUX_D_66/NoCrop/S1B_66_20211120_D.csl Dummy
_Check_ALL_S1_SizeAndCoord_InDir.sh ${DIRSARCSL}_D_66/NoCrop 5 8.7356 49.6224 7.5958 49.7399 8.5171 48.7748 7.3971 48.8924
# Beware D_66 are using 5 or 6 burst. The extra burst might be useless (not used anyway for routine processing). Nevertheless, check on range from 5 bursts then check the images in __TMP_QUARANTINE with 6 bursts coordinates. 
#        If OK, put them back in NoCrop dir. If not, keep them in original __TMP_QUARANTINE
_Check_ALL_S1_SizeAndCoord_InDir.sh ${DIRSARCSL}_D_66/NoCrop/__TMP_QUARANTINE 6 8.7924 49.7862 7.6075 49.9079 8.5304 48.7728 7.3702 48.8946
	mv ${DIRSARCSL}_D_66/NoCrop/__TMP_QUARANTINE/*.csl ${DIRSARCSL}_D_66/NoCrop/ 2>/dev/null
	mv ${DIRSARCSL}_D_66/NoCrop/__TMP_QUARANTINE/__TMP_QUARANTINE/*.csl ${DIRSARCSL}_D_66/NoCrop/__TMP_QUARANTINE/ 2>/dev/null
	mv ${DIRSARCSL}_D_66/NoCrop/__TMP_QUARANTINE/*.txt ${DIRSARCSL}_D_66/NoCrop/ 2>/dev/null
	rm -R ${DIRSARCSL}_D_66/NoCrop/__TMP_QUARANTINE/__TMP_QUARANTINE 2>/dev/null
# Desc D_139; bursts size and coordinates are obtained by running e.g.:  _Check_S1_SizeAndCoord.sh /Volumes/hp-1650-Data_Share1/SAR_CSL/S1/LUX_D_139/NoCrop/S1B_139_20211125_D.csl Dummy
_Check_ALL_S1_SizeAndCoord_InDir.sh ${DIRSARCSL}_D_139/NoCrop 20 8.1682 50.3200 5.7136 50.5824 7.6730 48.5892 5.3056 48.8511

# Coregister all images on the super master 
# in Ascending mode 
$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh ${PARAMCOREGASC1} &
$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh ${PARAMCOREGASC2} &
$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh ${PARAMCOREGASC3} &

wait

# in Descending mode 
$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh ${PARAMCOREGDESC1} &
$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh ${PARAMCOREGDESC2} &
$PATH_SCRIPTS/SCRIPTS_OK/SuperMasterCoreg.sh ${PARAMCOREGDESC3} &

# Search for pairs
##################
# Link all images to corresponding set dir
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh ${DIRSARCSL}_A_15/NoCrop ${DIRSET}/set1 S1 > /dev/null 2>&1  &
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh ${DIRSARCSL}_A_88/NoCrop ${DIRSET}/set2 S1 > /dev/null 2>&1  &
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh ${DIRSARCSL}_A_161/NoCrop ${DIRSET}/set3 S1 > /dev/null 2>&1  &
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh ${DIRSARCSL}_D_37/NoCrop ${DIRSET}/set4 S1 > /dev/null 2>&1  &
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh ${DIRSARCSL}_D_66/NoCrop ${DIRSET}/set5 S1 > /dev/null 2>&1  &
$PATH_SCRIPTS/SCRIPTS_OK/lns_All_Img.sh ${DIRSARCSL}_D_139/NoCrop ${DIRSET}/set6 S1 > /dev/null 2>&1  &

wait

# Compute pairs 
# Compute pairs only if new data is identified
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh ${DIRSET}/set1 ${BP} ${BT} ${SMASC1} > /dev/null 2>&1  &
	echo "n" | Prepa_MSBAS.sh ${DIRSET}/set2 ${BP} ${BT} ${SMASC2} > /dev/null 2>&1  &
	echo "n" | Prepa_MSBAS.sh ${DIRSET}/set3 ${BP} ${BT} ${SMASC3} > /dev/null 2>&1  &
fi
if [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 
	echo "n" | Prepa_MSBAS.sh ${DIRSET}/set4 ${BP} ${BT} ${SMDESC1} > /dev/null 2>&1  &
	echo "n" | Prepa_MSBAS.sh ${DIRSET}/set5 ${BP} ${BT} ${SMDESC2} > /dev/null 2>&1  &
	echo "n" | Prepa_MSBAS.sh ${DIRSET}/set6 ${BP} ${BT} ${SMDESC3} > /dev/null 2>&1  &
fi
wait

# Plot baseline plot with all modes 
if [ ! -s ${NEWASCPATH}/_No_New_Data_Today.txt ] || [ ! -s ${NEWDESCPATH}/_No_New_Data_Today.txt ] ; then 

	if [ `baselinePlot | wc -l` -eq 0 ] 
		then
			# use MasTer Engine before May 2022
			mkdir -p ${DIRSET}/BaselinePlots_S1_set_1to6
			cd ${DIRSET}/BaselinePlots_S1_set_1to6

			echo "${DIRSET}/set1" > ModeList.txt
			echo "${DIRSET}/set2" >> ModeList.txt
			echo "${DIRSET}/set3" >> ModeList.txt
			echo "${DIRSET}/set4" >> ModeList.txt
			echo "${DIRSET}/set5" >> ModeList.txt
			echo "${DIRSET}/set6" >> ModeList.txt

			$PATH_SCRIPTS/SCRIPTS_OK/plot_Multi_span.sh ModeList.txt 0 ${BP} 0 ${BT} ${COLORTABLE}
		else
			# use MasTer Engine > May 2022
			mkdir -p ${DIRSET}/BaselinePlots_set1_to_set6
			cd ${DIRSET}/BaselinePlots_set1_to_set6
 
			echo "${DIRSET}/set1" > ModeList.txt
			echo "${DIRSET}/set2" >> ModeList.txt
			echo "${DIRSET}/set3" >> ModeList.txt
			echo "${DIRSET}/set4" >> ModeList.txt
			echo "${DIRSET}/set5" >> ModeList.txt
			echo "${DIRSET}/set6" >> ModeList.txt
 
			plot_Multi_BaselinePlot.sh ${DIRSET}/BaselinePlots_set1_to_set6/ModeList.txt		
	fi	
fi

echo "Ending $0" >> ${DIRSARCSL}/Last_Run_Cron_Step1.txt
date >> ${DIRSARCSL}/Last_Run_Cron_Step1.txt




