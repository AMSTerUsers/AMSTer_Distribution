#!/bin/bash
# Script to run in cronjob for processing VVP images:
# prepare and run MSBAS only if no other mass process in progress and if new pairs are available.
# It also plots several time series and double differences 
#
# NOTE:This script is entended to be launched from Mac Pro (see mounting point as /Volumes/hp-D...)
#      If one wants to do it from Linux, one must change the links (see __Update_links_Mac_vs_Linux.sh)
#      and change the mounting disks below


source $HOME/.bashrc

cd

TODAY=`date`

BP=20

# some files and PATH
#####################
S1ASC=$PATH_3601/SAR_MASSPROCESS/S1/DRC_VVP_A_174/SMNoCrop_SM_20150310_Zoom1_ML8
S1DESC=$PATH_3601/SAR_MASSPROCESS/S1/DRC_VVP_D_21/SMNoCrop_SM_20151014_Zoom1_ML8
MSBASDIR=$PATH_3602/MSBAS/_VVP_S1_Auto_${BP}m_400days
eval MSBASDIR=${MSBASDIR}

# Path to list of points for which one wants to get the time series plots
TIMESERIESPTSDESCR=$PATH_SCRIPTS/SCRIPTS_OK/_cron_scripts/Points_TS_VVP.txt
# Remove header and naming in 1st col from Pts list
${PATHGNU}/gsed '1d' "${TIMESERIESPTSDESCR}" > $PATH_SCRIPTS/SCRIPTS_OK/_cron_scripts/Cln.txt
${PATHGNU}/gsed  -i -r 's/(\s+)?\S+//1' $PATH_SCRIPTS/SCRIPTS_OK/_cron_scripts/Cln.txt

# remove 3rd col
#${PATHGNU}/gsed  -i -r 's/(\s+)?\S+//3' /Users/doris/PROCESS/SCRIPTS_OK/_cron_scripts/Cln.txt
TIMESERIESPTS=$PATH_SCRIPTS/SCRIPTS_OK/_cron_scripts/Cln.txt

#R_FLAG
# Order
ORDER=2
# Lambda
LAMBDA=0.04

cd ${MSBASDIR}

function PlotAllLOSasc()
	{
	unset X1 Y1 X2 Y2 DESCRIPTION
	local X1=$1
	local Y1=$2
	local X2=$3
	local Y2=$4
	local DESCRIPTION=$5
	
	cd ${MSBASDIR}/zz_LOS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/
	mkdir -p ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/_Time_series
	
	${PATH_SCRIPTS}/SCRIPTS_OK/PlotTS.sh ${X1} ${Y1} ${X2} ${Y2} -f # remove -f if does not want the linear fit
	rm plotTS*.gnu timeLine*.png 

	mv timeLine${X1}_${Y1}.eps ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/${DESCRIPTION}_timeLine_${X1}_${Y1}_Auto_${ORDER}_${LAMBDA}_VVP.eps
	mv timeLine${X2}_${Y2}.eps ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/${DESCRIPTION}_timeLine_${X2}_${Y2}_Auto_${ORDER}_${LAMBDA}_VVP.eps
	mv timeLine${X1}_${Y1}_${X2}_${Y2}.eps ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/${DESCRIPTION}_timeLine_${X1}_${Y1}_${X2}_${Y2}_Auto_${ORDER}_${LAMBDA}_VVP.eps

	mv timeLine${X1}_${Y1}.txt ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/_Time_series/
	mv timeLine${X2}_${Y2}.txt ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/_Time_series/
	mv timeLine${X1}_${Y1}_${X2}_${Y2}.txt ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/_Time_series/
	
	# add map tag in fig
	convert -density 300 -rotate 90 -trim ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/${DESCRIPTION}_timeLine_${X1}_${Y1}_${X2}_${Y2}_Auto_${ORDER}_${LAMBDA}_VVP.eps ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/${DESCRIPTION}_timeLine_${X1}_${Y1}_${X2}_${Y2}_Auto_${ORDER}_${LAMBDA}_VVP.jpg
	convert ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/${DESCRIPTION}_timeLine_${X1}_${Y1}_${X2}_${Y2}_Auto_${ORDER}_${LAMBDA}_VVP.jpg ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/${DESCRIPTION}_timeLines_Loca_${X1}_${Y1}_${X2}_${Y2}.jpg -gravity northwest -geometry +250+150 -composite ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/${DESCRIPTION}_timeLine_${X1}_${Y1}_${X2}_${Y2}_Auto_${ORDER}_${LAMBDA}_VVP_Combi_Asc.jpg
	
	#mv ${MSBASDIR}/timeLine_UD_${X1}_${Y1}_${X2}_${Y2}_Auto_${ORDER}_${LAMBDA}_VVP.txt ${MSBASDIR}/zz_UD_EW_TS_Auto_${ORDER}_${LAMBDA}_VVP/${DESCRIPTION}_timeLines_UD_${X1}_${Y1}_${X2}_${Y2}_Auto_${ORDER}_${LAMBDA}_VVP.txt
	#mv ${MSBASDIR}/timeLine_EW_${X1}_${Y1}_${X2}_${Y2}_Auto_${ORDER}_${LAMBDA}_VVP.txt ${MSBASDIR}/zz_UD_EW_TS_Auto_${ORDER}_${LAMBDA}_VVP/${DESCRIPTION}_timeLines_EW_${X1}_${Y1}_${X2}_${Y2}_Auto_${ORDER}_${LAMBDA}_VVP.txt
	
	rm -f ${MSBASDIR}/zz_LOS_TS_Asc_Auto_${ORDER}_${LAMBDA}_VVP/${DESCRIPTION}_timeLine_${X1}_${Y1}_${X2}_${Y2}_Auto_${ORDER}_${LAMBDA}_VVP.jpg

	}

	

# May want to add other pts 
function WhichPlotsLOSasc()
	{
	PlotAllLOSasc 777 1050 738 1050 _Accross_Airport
	PlotAllLOSasc 688 1025 784 1076 _GomaW_GisenyiE
	PlotAllLOSasc 556 948 784 1076 _SakeW_GisenyiE
	PlotAllLOSasc 556 948 813 951 _SakeW_Nyigo_2002_WestFlow
	PlotAllLOSasc 769 875 769 892 _Accross_Nyigo_NW_SW
	PlotAllLOSasc 773 875 773 892 _Accross_Nyigo_N_S
	PlotAllLOSasc 773 881 774 887 _Accross_Nyigo_Crater_NS
	PlotAllLOSasc 763 877 770 879 _Accross_Nyigo_Rim_NWSE
	PlotAllLOSasc 762 877 775 877 _Accross_Nyigo_Rim_EW_N
	PlotAllLOSasc 769 890 777 890 _Accross_Nyigo_Rim_EW_S
	PlotAllLOSasc 720 753 720 768 _Accross_Nyam_Crater_NS
	PlotAllLOSasc 715 767 726 767 _Accross_Nyam_Crater_Depression_EW
	PlotAllLOSasc 717 767 726 755 _Accross_Nyam_Crater_SWNE
	PlotAllLOSasc 715 749 727 770 _Accross_Nyam_Summit_NWSE
	PlotAllLOSasc 715 746 738 782 _Accross_Nyam_NWSE
	PlotAllLOSasc 719 765 736 782 _Accross_Nyam_Depression_SEFlank
	PlotAllLOSasc 714 745 724 756 _Accross_Nyam_NWflank_NpitCrater
	PlotAllLOSasc 734 780 633 883 _Nyam_SEflank_S_2006Flow
	PlotAllLOSasc 734 780 557 948 _Nyam_SEflank_Sake
	PlotAllLOSasc 594 756 734 780 _Nyam_1994Wflow_SEflank
	PlotAllLOSasc 606 938 813 950 _Nyam_1986Sflow_Nyigo_2002Wflow
	PlotAllLOSasc 808 605 830 605 _Accross_91_94_Flow_left
	PlotAllLOSasc 830 605 851 605 _Accross_91_94_Flow_right
	PlotAllLOSasc 818 605 844 605 _Accross_91_94_Flow
	PlotAllLOSasc 661 991 597 963 _BlgArea_NthSakeBay
	}
WhichPlotsLOSasc
