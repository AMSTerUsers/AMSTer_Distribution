#!/bin/bash
# Script to rename (in parameters text files) external HD path such as /$PATH_1650 into hp-1650-Data_Share1 (from OSX) 
#    in order to be readable for CIS when CIS does not interprete links in parameters files. 
#
# This may have an interest in case of replaying some steps in MASS_PROCESS directories 
#
# Need to be run in dir where all files are stored in /SUBDIRS/i12/TextFiles/InSARParameters.txt, 
#   e.g. /.../SAR_SM/RESAMPLED/SAT/TRK/CROPDIR/
#
# Parameters : - none  
#
# Dependencies:	- gnu sed and awk for more compatibility. 
#
# Hard coded:	- Path to disks and volumes to rename
#
# New in Distro V 1.0:	- Based on developpement version and Beta V1.0.0
#               V1.0.1: - also for usage in SAR_MASSPROCESS (avoid dir with Geocoded etc..)
#
# MasTer: InSAR Suite automated Mass processing Toolbox. 
# NdO (c) 2018/03/29 - could make better... when time.
# -----------------------------------------------------------------------------------------
PRG=`basename "$0"`
VER="Distro V1.0 MasTer script utilities"
AUT="Nicolas d'Oreye, (c)2016-2019, Last modified on Dec 05, 2019"
echo " "
echo "${PRG} ${VER}, ${AUT}"
echo " " 

NEWDIR="$(pwd)"

ls -d */ | ${PATHGNU}/grep -v ModulesForCoreg  | ${PATHGNU}/grep -v _Check  | ${PATHGNU}/grep -v Geocoded  | ${PATHGNU}/grep -v __Back    > Files_To_Rename.txt

# Test if process CSL images (for DEM infos) or RESAMPLED images
TSTDIR=`tail -1 Files_To_Rename.txt`

if [ -d ${TSTDIR}/i12/TextFiles ] 
	then  
		echo "I guess we are renaming path in RESAMPLED directories..."
		for DIR in `cat -s Files_To_Rename.txt` 
		do 
			cd ${DIR}/i12/TextFiles
			cp -n InSARParameters.txt InSARParameters_original_ExtHDpath.txt # do not copy if exist already
			${PATHGNU}/gsed -e 	"s%\/\$PATH_1650%\/Volumes\/hp-1650-Data_Share1%g 
								 s%\/\$PATH_3600%\/Volumes\/hp-D3600-Data_Share1%g 
								 s%\/\$PATH_3601%\/Volumes\/hp-D3601-Data_RAID6%g 
								 s%\/\$PATH_3602%\/Volumes\/hp-D3602-Data_RAID5%g" InSARParameters_original_ExtHDpath.txt > InSARParameters.txt
			if [ -s geoProjectionParameters.txt ] ; then
				cp -n geoProjectionParameters.txt geoProjectionParameters_original_ExtHDpath.txt # do not copy if exist already
				${PATHGNU}/gsed -e 	"s%\/\$PATH_1650%\/Volumes\/hp-1650-Data_Share1%g 
									 s%\/\$PATH_3600%\/Volumes\/hp-D3600-Data_Share1%g 
									 s%\/\$PATH_3601%\/Volumes\/hp-D3601-Data_RAID6%g 
									 s%\/\$PATH_3602%\/Volumes\/hp-D3602-Data_RAID5%g" geoProjectionParameters_original_ExtHDpath.txt > geoProjectionParameters.txt
			fi
			echo "Files in ${DIR}/i12/TextFiles renamed."
			cd ${NEWDIR}
		done 
	else   
		if [ -d ${TSTDIR}/Info ] 
			then 
				echo "I guess we are renaming path in CSL images directories..."
				for DIR in `cat -s Files_To_Rename.txt` 
					do 
						cd ${DIR}/Info
						for MASKSANDDEM in `ls *.txt | ${PATHGNU}/grep -v readme | ${PATHGNU}/grep -v SLC | ${PATHGNU}/grep -v Pattern | ${PATHGNU}/grep -v original` 
							do
								cp -n ${MASKSANDDEM} ${MASKSANDDEM}_original_ExtHDpath.txt # do not copy if exist already
								${PATHGNU}/gsed -e 	"s%\/\$PATH_1650%\/Volumes\/hp-1650-Data_Share1%g 
													 s%\/\$PATH_3600%\/Volumes\/hp-D3600-Data_Share1%g 
													 s%\/\$PATH_3601%\/Volumes\/hp-D3601-Data_RAID6%g 
													 s%\/\$PATH_3602%\/Volumes\/hp-D3602-Data_RAID5%g" ${MASKSANDDEM}_original_ExtHDpath.txt > ${MASKSANDDEM}
							done
						echo "Files in ${DIR}/Info renamed."
						cd ${NEWDIR}
				done 		
			else 
				echo "Not sure what kind of files you want to modify. Please revise path and adapt script"
		fi
	fi
		
rm -f Files_To_Rename.txt

