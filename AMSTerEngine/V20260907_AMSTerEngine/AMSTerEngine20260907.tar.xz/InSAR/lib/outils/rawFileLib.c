
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  rawFileLib.c
//  EnviSATDataReader
//
//  Created by Dominique Derauw on 30/06/16.
//
//

#include "rawFileLib.h"

rawFileDescriptor *allocFileDescriptor(void)
{
    rawFileDescriptor *aFileDescriptor ;

    if((aFileDescriptor = malloc(sizeof(rawFileDescriptor))) == NULL)
        return((rawFileDescriptor *)NULL) ;
    aFileDescriptor->f = NULL ;
    aFileDescriptor->accessPath = NULL ;
    aFileDescriptor->directoryPath = NULL ;
    aFileDescriptor->fileName = NULL ;
    aFileDescriptor->fileLength = 0 ;
    aFileDescriptor->mode = allocStringOfLength(3) ;
    aFileDescriptor->mode[0] = '\0' ;
    aFileDescriptor->byteOrder = isArchBigEndian() ;
    aFileDescriptor->fileByteOrder = -1 ;
    aFileDescriptor->swapBytes = 0 ;
    aFileDescriptor->xDim = 0 ;
    aFileDescriptor->yDim = 0 ;
    aFileDescriptor->xLowerIndex = 0 ;
    aFileDescriptor->yLowerIndex = 0 ;
    aFileDescriptor->x0 = 0. ;
    aFileDescriptor->y0 = 0. ;
    aFileDescriptor->xSampling = 0. ;
    aFileDescriptor->ySampling = 0. ;
    aFileDescriptor->excludingValue = NULL ;
    aFileDescriptor->typeSize = (size_t)0 ;
    aFileDescriptor->aoi = NULL ;
    aFileDescriptor->data = NULL ;
    aFileDescriptor->indexedData = NULL ;
    aFileDescriptor->flag = 0 ;

    return (aFileDescriptor) ;
}

rawFileDescriptor *allocFileDescriptorForPath(char *aPath)
{
    rawFileDescriptor *aFileDescriptor ;

	aPath = expandEnvironmentVariablesInPath(aPath) ;
    aFileDescriptor = allocFileDescriptor() ;

    aFileDescriptor->accessPath = initStringWithString(aPath) ;
    aFileDescriptor->directoryPath = getDirectoryPathFromPath(aPath) ;
    aFileDescriptor->fileName = getFileNameFromPath(aPath) ;

    free(aPath) ;

    return (aFileDescriptor) ;
}

void setRawFilePath(rawFileDescriptor *aFileDescriptor, char *newFullPath)
{
    if (aFileDescriptor->accessPath) {
        free(aFileDescriptor->accessPath) ;
    }    
    if (aFileDescriptor->directoryPath) {
        free(aFileDescriptor->directoryPath) ;
    }    
    if (aFileDescriptor->fileName) {
        free(aFileDescriptor->fileName) ;
    }

    aFileDescriptor->accessPath = initStringWithString(newFullPath) ;
    aFileDescriptor->directoryPath = getDirectoryPathFromPath(newFullPath) ;
    aFileDescriptor->fileName = getFileNameFromPath(newFullPath) ;
}

void setRawFileDimensions(rawFileDescriptor *aFileDescriptor, int xDim, int yDim)
{
    aFileDescriptor->xDim = xDim ;
    aFileDescriptor->yDim = yDim ;
}

void setRawFileLowerIndexes(rawFileDescriptor *aFileDescriptor, int xLowerIndex, int yLowerIndex)
{
    aFileDescriptor->xLowerIndex = xLowerIndex ;
    aFileDescriptor->yLowerIndex = yLowerIndex ;
}

void setRawFileType(rawFileDescriptor *aFileDescriptor, size_t typeSize)
{
    aFileDescriptor->typeSize = typeSize ;
}

void setRawFileOrigin(rawFileDescriptor *aFileDescriptor, int x0, int y0)
{
    aFileDescriptor->x0 = x0 ;
    aFileDescriptor->y0 = y0 ;
}

void setRawFileSampling(rawFileDescriptor *aFileDescriptor, int xSampling, int ySampling)
{
    aFileDescriptor->xSampling = xSampling ;
    aFileDescriptor->ySampling = ySampling ;
}

void setRawFileAoI(rawFileDescriptor *aFileDescriptor, quadrilateral *aoi)
{
    int i ;

    if (aFileDescriptor->aoi == NULL) {
        aFileDescriptor->aoi = allocQuadrilateral() ;
    }
    for (i = 0; i < aFileDescriptor->aoi->N; i++) {
        aFileDescriptor->aoi->P[i].x = aoi->P[i].x ;
        aFileDescriptor->aoi->P[i].y = aoi->P[i].y ;
    }
}

void setRawFileAoIWithValues(rawFileDescriptor *aFileDescriptor, int xMin, int yMin, int xMax, int yMax)
{
    if (aFileDescriptor->aoi == NULL) {
        aFileDescriptor->aoi = allocQuadrilateral() ;
    }
    aFileDescriptor->aoi->P[0].x = aFileDescriptor->aoi->P[3].x = xMin ;
    aFileDescriptor->aoi->P[1].x = aFileDescriptor->aoi->P[2].x = xMax ;
    aFileDescriptor->aoi->P[0].y = aFileDescriptor->aoi->P[1].y = yMin ;
    aFileDescriptor->aoi->P[2].y = aFileDescriptor->aoi->P[3].y = yMax ;
}

/* Open file for reading setting read pointer at the begining of the file */
rawFileDescriptor *openRawFileForReading(rawFileDescriptor *aFileDescriptor)
{
    if (aFileDescriptor == NULL) {
        return (NULL) ;
    }
    if (!fileExistsAtPath(aFileDescriptor->accessPath)) {
        return (NULL) ;
    }
    if(!isReadAccessGrantedAtPath(aFileDescriptor->accessPath))
        return(NULL) ;

    if (aFileDescriptor->directoryPath == NULL) {
        aFileDescriptor->directoryPath = getDirectoryPathFromPath(aFileDescriptor->accessPath) ;
    }
    if (aFileDescriptor->fileName == NULL) {
        aFileDescriptor->fileName = getFileNameFromPath(aFileDescriptor->accessPath) ;
    }
    if (aFileDescriptor->f) {
        fclose(aFileDescriptor->f) ;
        aFileDescriptor->f = NULL ;
    }
    if (aFileDescriptor->f == NULL ) {
        aFileDescriptor->f = fopen(aFileDescriptor->accessPath, "r") ;
    }

    fseeko(aFileDescriptor->f, (off_t)0, SEEK_END) ;
    aFileDescriptor->fileLength = ftell(aFileDescriptor->f) ;
    fseeko(aFileDescriptor->f, (off_t)0, SEEK_SET) ;
    sprintf(aFileDescriptor->mode, "r") ;
    clearerr(aFileDescriptor->f) ;

    return (aFileDescriptor) ;
}

rawFileDescriptor *openRawFileForWriting(rawFileDescriptor *aFileDescriptor)
{
    if (aFileDescriptor == NULL) {
        return (NULL) ;
    }
    if(!isWriteAccessGrantedAtPath(aFileDescriptor->accessPath))
        return(NULL) ;

    if (aFileDescriptor->directoryPath == NULL) {
        aFileDescriptor->directoryPath = getDirectoryPathFromPath(aFileDescriptor->accessPath) ;
    }
    if (aFileDescriptor->fileName == NULL) {
        aFileDescriptor->fileName = getFileNameFromPath(aFileDescriptor->accessPath) ;
    }
    if (aFileDescriptor->f == NULL ) {
        if((aFileDescriptor->f = fopen(aFileDescriptor->accessPath, "w")) == NULL) {
            return(NULL) ;
        }
    }

    fseeko(aFileDescriptor->f, (off_t)0, SEEK_SET) ;
    sprintf(aFileDescriptor->mode, "w") ;
    clearerr(aFileDescriptor->f) ;

    return (aFileDescriptor) ;
}

rawFileDescriptor *openRawFileForReadingAndWriting(rawFileDescriptor *aFileDescriptor)
{
    if (aFileDescriptor == NULL) {
        return (0) ;
    }

    if (aFileDescriptor->directoryPath == NULL) {
        aFileDescriptor->directoryPath = getDirectoryPathFromPath(aFileDescriptor->accessPath) ;
    }
    if(!isReadAccessGrantedAtPath(aFileDescriptor->directoryPath) || !isWriteAccessGrantedAtPath(aFileDescriptor->directoryPath)) {
        return(0) ;
    }
    
    if (aFileDescriptor->fileName == NULL) {
        aFileDescriptor->fileName = getFileNameFromPath(aFileDescriptor->accessPath) ;
    }
    
    if (aFileDescriptor->f) {
        fclose(aFileDescriptor->f) ;
        aFileDescriptor->f = NULL ;
    }

    if(fileExistsAtPath(aFileDescriptor->accessPath)) {
        aFileDescriptor->f = fopen(aFileDescriptor->accessPath, "r+") ;
        sprintf(aFileDescriptor->mode, "r+") ;
        fseeko(aFileDescriptor->f, (off_t)0, SEEK_END) ;
        aFileDescriptor->fileLength = ftell(aFileDescriptor->f) ;
    }
    else {
        if((aFileDescriptor->f = fopen(aFileDescriptor->accessPath, "w+")) == NULL) {
            return (0) ;
        }
        aFileDescriptor->fileLength = 0 ;
        sprintf(aFileDescriptor->mode, "w+") ;
    }

    fseeko(aFileDescriptor->f, (off_t)0, SEEK_SET) ;
    clearerr(aFileDescriptor->f) ;

    return (aFileDescriptor) ;
}

rawFileDescriptor *openRawFileForReadingAtPath(char *aPath)
{
    rawFileDescriptor	*aFileDescriptor ;

	aPath = expandEnvironmentVariablesInPath(aPath) ;
    if (aPath == NULL) {
        return(NULL) ;
    }

    if(isDir(aPath)) {
        free(aPath) ;
        return(NULL) ;
    }
    if(!fileExistsAtPath(aPath)) {
        free(aPath) ;
        return(NULL) ;
    }
    else {
        if(!isReadAccessGrantedAtPath(aPath)) {
            free(aPath) ;
            return(NULL) ;
        }
        aFileDescriptor = allocFileDescriptor() ;

        aFileDescriptor->directoryPath = getDirectoryPathFromPath(aPath) ;
        aFileDescriptor->fileName = getFileNameFromPath(aPath) ;
        aFileDescriptor->accessPath = allocStringOfLength(strlen(aFileDescriptor->directoryPath) + strlen(aFileDescriptor->fileName)) ;
        sprintf(aFileDescriptor->accessPath, "%s%s", aFileDescriptor->directoryPath, aFileDescriptor->fileName) ;
        if ((aFileDescriptor->f = fopen(aFileDescriptor->accessPath, "r")) == NULL) {
            free(aPath) ;
            printf("-/->Failed to open file: %s\n", aFileDescriptor->accessPath) ;
            ase("\t-/-> Stopping here.\n") ;
        }
        fseeko(aFileDescriptor->f, (off_t)0, SEEK_END) ;
        aFileDescriptor->fileLength = ftell(aFileDescriptor->f) ;
        fseeko(aFileDescriptor->f, (off_t)0, SEEK_SET) ;
        sprintf(aFileDescriptor->mode, "r") ;
    }
    clearerr(aFileDescriptor->f) ;
    free(aPath) ;

    return aFileDescriptor ;
}

rawFileDescriptor *openRawFileForWritingAtPath(char *aPath)
{
    rawFileDescriptor	*aFileDescriptor ;

	aPath = expandEnvironmentVariablesInPath(aPath) ;
    if (aPath == NULL) {
        return((rawFileDescriptor *)NULL) ;
    }

    if(isDir(aPath)) {
        free(aPath) ;
        return((rawFileDescriptor *)NULL) ;
    }
    if(fileExistsAtPath(aPath)) {
        if(!isWriteAccessGrantedAtPath(aPath)) {
            free(aPath) ;
            return((rawFileDescriptor *)NULL) ;
        }
    }

    aFileDescriptor = allocFileDescriptor() ;

    aFileDescriptor->directoryPath = getDirectoryPathFromPath(aPath) ;
    if (!isDir(aFileDescriptor->directoryPath)) {
        free(aPath) ;
        freeRawFileDescriptor(aFileDescriptor) ;
        return (NULL) ;
    }
    else {
        if (!isWriteAccessGrantedAtPath(aFileDescriptor->directoryPath)) {
            free(aPath) ;
            freeRawFileDescriptor(aFileDescriptor) ;
            return (NULL) ;
        }
    }
    
    aFileDescriptor->fileName = getFileNameFromPath(aPath) ;
    aFileDescriptor->accessPath = allocStringOfLength(strlen(aFileDescriptor->directoryPath) + strlen(aFileDescriptor->fileName)) ;
    sprintf(aFileDescriptor->accessPath, "%s%s", aFileDescriptor->directoryPath, aFileDescriptor->fileName) ;
    aFileDescriptor->f = fopen(aFileDescriptor->accessPath, "w") ;
    if(aFileDescriptor->f == NULL) {
        freeRawFileDescriptor(aFileDescriptor) ;
        free(aPath) ;
        return((rawFileDescriptor *)NULL) ;
    }

    aFileDescriptor->fileLength = 0 ;
    fseeko(aFileDescriptor->f, (off_t)0, SEEK_SET) ;
    sprintf(aFileDescriptor->mode, "w") ;

    clearerr(aFileDescriptor->f) ;
    free(aPath) ;

    return aFileDescriptor ;
}


rawFileDescriptor *openRawFileForReadingAndWritingAtPath(char *aPath)
{
    char *aDir ;
    rawFileDescriptor	*aFileDescriptor ;

	aPath = expandEnvironmentVariablesInPath(aPath) ;
    if (aPath == NULL) {
        return((rawFileDescriptor *)NULL) ;
    }

    if(isDir(aPath)) {
        free(aPath) ;
        return((rawFileDescriptor *)NULL) ;
    }
    if(fileExistsAtPath(aPath)) {
        if(!isWriteAccessGrantedAtPath(aPath) || !isReadAccessGrantedAtPath(aPath)) {
            free(aPath) ;
            return((rawFileDescriptor *)NULL) ;
        }
    }
    else {
        aDir = getDirectoryPathFromPath(aPath) ;
        if(!isWriteAccessGrantedAtPath(aDir) || !isReadAccessGrantedAtPath(aDir)) {
            free(aDir) ;
            free(aPath) ;
            return((rawFileDescriptor *)NULL) ;
        }
        free(aDir) ;
    }

    aFileDescriptor = allocFileDescriptor() ;

    aFileDescriptor->directoryPath = getDirectoryPathFromPath(aPath) ;
    aFileDescriptor->fileName = getFileNameFromPath(aPath) ;
    aFileDescriptor->accessPath = initStringWith2Strings(aFileDescriptor->directoryPath, aFileDescriptor->fileName) ;
    if(fileExistsAtPath(aFileDescriptor->accessPath)) {
        aFileDescriptor->f = fopen(aPath, "r+") ;
        fseeko(aFileDescriptor->f, (off_t)0, SEEK_END) ;
        aFileDescriptor->fileLength = ftell(aFileDescriptor->f) ;
        fseeko(aFileDescriptor->f, (off_t)0, SEEK_SET) ;
        sprintf(aFileDescriptor->mode, "r+") ;
    }
    else {
        aFileDescriptor->f = fopen(aPath, "w+") ;
        aFileDescriptor->fileLength = 0 ;
        fseeko(aFileDescriptor->f, (off_t)0, SEEK_SET) ;
        sprintf(aFileDescriptor->mode, "w+") ;
    }

    clearerr(aFileDescriptor->f) ;
    free(aPath) ;

    return aFileDescriptor ;
}

rawFileDescriptor *createRawFileForReadingAndWritingAtPath(char *aPath)
{
    char *aDir ;
    rawFileDescriptor	*aFileDescriptor ;

 	aPath = expandEnvironmentVariablesInPath(aPath) ;
    if (aPath == NULL) {
        return((rawFileDescriptor *)NULL) ;
    }

    if(isDir(aPath)) {
        free(aPath) ;
        return((rawFileDescriptor *)NULL) ;
    }
    if(fileExistsAtPath(aPath)) {
        if(!isWriteAccessGrantedAtPath(aPath) || !isReadAccessGrantedAtPath(aPath)) {
            free(aPath) ;
            return((rawFileDescriptor *)NULL) ;
        }
        unlink(aPath) ;
    }
    else {
        aDir = getDirectoryPathFromPath(aPath) ;
        if(!isWriteAccessGrantedAtPath(aDir) || !isReadAccessGrantedAtPath(aDir)) {
            free(aPath) ;
            return((rawFileDescriptor *)NULL) ;
        }
        free(aDir) ;
    }

    aFileDescriptor = allocFileDescriptor() ;

    aFileDescriptor->directoryPath = getDirectoryPathFromPath(aPath) ;
    aFileDescriptor->fileName = getFileNameFromPath(aPath) ;
    aFileDescriptor->accessPath = initStringWith2Strings(aFileDescriptor->directoryPath, aFileDescriptor->fileName) ;
    aFileDescriptor->f = fopen(aPath, "w+") ;
    fseeko(aFileDescriptor->f, (off_t)0, SEEK_SET) ;
    sprintf(aFileDescriptor->mode, "w+") ;

    free(aPath) ;
    clearerr(aFileDescriptor->f) ;

    return aFileDescriptor ;
}

void freeRawFileDescriptor(rawFileDescriptor *aFileDescriptor)
{
    if(aFileDescriptor != NULL) {
        closeRawFile(aFileDescriptor) ;
        if(aFileDescriptor->accessPath != NULL) {
            free(aFileDescriptor->accessPath) ;
            aFileDescriptor->accessPath = NULL ;
        }
        if(aFileDescriptor->directoryPath != NULL) {
            free(aFileDescriptor->directoryPath) ;
            aFileDescriptor->directoryPath = NULL ;
        }
        if(aFileDescriptor->fileName != NULL) {
            free(aFileDescriptor->fileName) ;
            aFileDescriptor->fileName = NULL ;
        }
        if (aFileDescriptor->aoi != NULL) {
            freePolygon(aFileDescriptor->aoi) ;
            aFileDescriptor->aoi = NULL ;
        }
        if (aFileDescriptor->excludingValue) {
            free(aFileDescriptor->excludingValue) ;
            aFileDescriptor->excludingValue = NULL ;
        }
        if (aFileDescriptor->indexedData && aFileDescriptor->typeSize) {
            freeMatrixOfType(aFileDescriptor->indexedData, aFileDescriptor->yLowerIndex, aFileDescriptor->xLowerIndex, aFileDescriptor->typeSize) ;
            aFileDescriptor->indexedData = NULL ;
        }
        if (aFileDescriptor->mode) {
            free(aFileDescriptor->mode) ;
            aFileDescriptor->mode = NULL ;
        }
        free(aFileDescriptor) ;
    }
}

void closeRawFile(rawFileDescriptor *aFileDescriptor)
{
    if(aFileDescriptor->f) {
        fflush(aFileDescriptor->f) ;
        fclose(aFileDescriptor->f) ;
        aFileDescriptor->f = NULL ;
    }
}

