
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  slantRangeDEM
//
//  Created by Dominique Derauw on 21/05/13.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "slantRangeDEMLib.h"



int slantRangeDEM(CSVStruct *clCSV)
{
    char saveMapping, *keyVal, *floatFilesDir, *DEMFilePath ;
    int i ;
	keyValue *parametersList ;
	CSLImage *masterImage ;
    externalDEMStruct *externalDEM ;
    maskStruct **mask ;
	satRef *satRefMaster ;
    geoProj *gP ;
	time_t startTime, endTime ;
    InSARParametersStruct *pInSAR = NULL ;


    if(clCSV->numberOfEntries == 1) {
		slantRangeDEMUsage() ;
    }
	if(isArgumentPresentInCSV(clCSV, "help") || isFlagPresentInCSV(clCSV, "h")) {
		slantRangeDEMUsage() ;
    }
	
	if(isArgumentPresentInCSV(clCSV, "-create")) {
		createSRDParameterFileAtPath(clCSV->stringVal[1]) ;
		exit(0) ;
	}
	
	time(&startTime) ;
    genFloatNaN() ;
    
    /* Read slantRangDEM parameter file */
    parametersList = readParameterFileAtPath(clCSV->stringVal[1]) ;

    /* Check if InSAR parameter file is given as input parameter */
    if (clCSV->numberOfEntries > 2) {
        pInSAR = readInSARParametersFileAtPath(clCSV->stringVal[2]) ;
    }
    
    if (pInSAR) {
        setStringValForKeyIn(parametersList, pInSAR->masterImage->imageDirectoryPath, "Reference slant range image path in CSL format") ;
        setStringValForKeyIn(parametersList, pInSAR->externalReferenceDEM, "Georeferenced DEM file path") ;
        setIntValForKeyIn(parametersList, pInSAR->red.Fra, "Range reduction factor") ;
        setIntValForKeyIn(parametersList, pInSAR->red.Faz, "Azimuth reduction factor") ;
        freeInSARParametersStruct(pInSAR) ;
    }

    
   
    /* Get reference image structures */
    keyVal = getStringValForKeyIn(parametersList, "Reference") ;
    if (plError == KEY_VALUE_NOT_FOUND) {
        ase("\t-/-> /* Reference slant range image path in CSL format */ missing in parameter file\n") ;
    }
    if (!(masterImage = getCSLImageStructureAtPath(keyVal))) {
        printf("\t-/-> No .csl image at path %s\n", keyVal) ;
        ase("\t-/-> Failed to read .csl reference image structure \n") ;
    }
        
    /* Open external DEM file */
    DEMFilePath = getStringValForKeyIn(parametersList, "Georeferenced DEM file path") ;
    if (!(externalDEM = openExternalDEMFile(DEMFilePath, clCSV))) {
        ase("External DEM file not available at indicated path") ;
    }

    /* Open mask files if any */
    mask = openExternalMaskFiles(parametersList) ;
    
    /* Get float files directory if any */
    floatFilesDir = getStringValForKeyIn(parametersList, "External float files directory") ;    
    saveMapping = (mask || isDir(floatFilesDir))? 1 : 0 ;
    
    /* Slant range referencing of external DEM */
    printf("slantRangeDEM running.\n") ;
    printf("Projection of external DEM %s on .csl slant range image %s.\n\n", externalDEM->DEMName, masterImage->imageDirectoryPath) ;
    satRefMaster = slantRangeReferencingOfDEM(externalDEM, masterImage, parametersList) ;
    
    /* Initialize slant range projection */
    gP = initSlantRangeProjection(satRefMaster, masterImage, parametersList, saveMapping) ;
    
    /* Slant range projection of DEM */
    slantRangeDEMProjection(gP, externalDEM) ;

    /* Generate simulated amplitude image */
    if (externalDEM->flag & _AMPLITUDE_SIMULATION_) {
        printf("\n\n---> Amplitude image simulation\n") ;
        simulMod(gP, satRefMaster) ;
    }
    
    /* Mask projection */
    if (mask) {
        slantRangeMaskProjection(gP, externalDEM, mask) ;
    }

    /* External float files projection */
    externalFloatFilesProjection(gP, externalDEM, floatFilesDir) ;

   /* Gradients projection */
    if (externalDEM->flag & _GRADIENTS_PROJECTION_) {
        slantRangeGradientsProjection(gP, externalDEM) ;
    }

    
    /* Close all */
    unlinkTemporaryFiles(gP) ;
	gP->files->DEM = NULL ;
    gP->files->xRef = NULL ;
    gP->files->yRef = NULL ;
    gP->files->xRadius = NULL ;
    gP->files->yRadius = NULL ;
    gP->files->mask = NULL ;
    freeGeoProj(gP) ;
    freeInfoImage(satRefMaster->gR->params->info) ;
    freeSatRef(satRefMaster) ;
    freeExternalDEMStruct(externalDEM) ;
    freeKeyValueList(parametersList) ;
    freeCSLImageStructure(masterImage) ;
    
	time(&endTime) ;
	duration(startTime, endTime) ;
    return 0;
}


void slantRangeDEMUsage(void)
{
    printf("Usage: slantRangeDEM /pathTo/parameterFile [-create] [-s]\n\n") ;
    printf("This routine transforms a georeferenced DEM into \na slant range DEM with respect to a given SAR image.\n\n") ;
    printf("First parameter must be the full path to the parameter file.\n") ;
    printf("If adding the keyword -create, an example parameter file \nwill be created at indicated path.\n") ;
    printf("-s : A simulated amplitude image is generated.\n") ;
    
    exit(0) ;
}

keyValue *createSRDParameterList(void)
{
    keyValue *parameterList ;
    
    parameterList = allocAKeyValuePair() ;
    setStringValForKeyIn(parameterList, "Slant range DEM generation", "") ;
    setStringValForKeyIn(parameterList, "**************************", "") ;
    setStringValForKeyIn(parameterList, "masterImagePath", "Reference slant range image path in CSL format") ;
    setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, "External DEM", "") ;
    setStringValForKeyIn(parameterList, "************", "") ;
    setStringValForKeyIn(parameterList, "File path", "Georeferenced DEM file path") ;
    setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, "Resampling parameters", "") ;
    setStringValForKeyIn(parameterList, "*********************", "") ;
    setStringValForKeyIn(parameterList, "TRI", "Resampling method : TRI = Triangulation; AV = weighted average; NN = nearest neighbour") ;
    setStringValForKeyIn(parameterList, "LORENTZ", "Weighting method : ID = inverse distance; LORENTZ = lorentzian") ;
    setStringValForKeyIn(parameterList, "1.0", "ID smoothing factor") ;
    setStringValForKeyIn(parameterList, "1.0", "ID weighting exponent") ;
    setStringValForKeyIn(parameterList, "0.7", "FWHM : Lorentzian Full Width at Half Maximum") ;
    setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, "Reduction factors", "") ;
    setStringValForKeyIn(parameterList, "*****************", "") ;
    setStringValForKeyIn(parameterList, "5", "Range reduction factor") ;
    setStringValForKeyIn(parameterList, "5", "Azimuth reduction factor") ;
    setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, "Masks characteristics", "") ;
    setStringValForKeyIn(parameterList, "*********************", "") ;
    setStringValForKeyIn(parameterList, "Each mask must be binary and given in longitude - latitude coordinate (WGS84)", "") ;
    setStringValForKeyIn(parameterList, "File path", "Mask file path 1: Geographical mask (water bodies, ...)") ;
    setStringValForKeyIn(parameterList, "1", "Masking value 1") ;
    setStringValForKeyIn(parameterList, "File path", "Mask file path 2: Thresholded coherence mask") ;
    setStringValForKeyIn(parameterList, "1", "Masking value 2") ;
    setStringValForKeyIn(parameterList, "File path", "Mask file path 3: Detrend masked areas") ;
    setStringValForKeyIn(parameterList, "0", "Masking value 3") ;
    setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, "Following masks must all be in given directory and be named as eventMaskYYYYMMDDThhmmss_YYYYMMDDThhmmss", "") ;
    setStringValForKeyIn(parameterList, "perDateMaskFileDirectory", "Per date detrend mask files directory") ;
    setStringValForKeyIn(parameterList, "0", "Event masks masking value") ;
    setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, "External float files", "") ;
    setStringValForKeyIn(parameterList, "********************", "") ;
    setStringValForKeyIn(parameterList, "Directory path", "External float files directory") ;
 
//    setStringValForKeyIn(parameterList, "Models", "") ;
//    setStringValForKeyIn(parameterList, "*****", "") ;
//    setStringValForKeyIn(parameterList, "modelsDirectory", "Models directory") ;

    return parameterList ;
}


void createSRDParameterFileAtPath(char *aPath)
{
    keyValue *parameterList ;

    parameterList = createSRDParameterList() ;
    
	writeParameterFileAtPath(parameterList, aPath) ;
    freeKeyValueList(parameterList) ;
}


externalDEMStruct *openExternalDEMFile(char *DEMFilePath, CSVStruct *clCSV)
{
    char *DEMPath ;
    int unsigned anInt ;
    externalDEMStruct *externalDEM ;
    rawFileDescriptor *externalDEMDataFile ;

    if (!(DEMPath = getGeoreferencedDataFilePath(DEMFilePath))) {
        return (NULL) ;
    }
    if (!(externalDEMDataFile = getGeoreferencedDataFile(DEMPath))) {
        return (NULL) ;
    }

    if((externalDEM = calloc(1, sizeof(externalDEMStruct))) == NULL) {
        ase("Failed to allocate externalDEM structure") ;
    }
    externalDEM->DEMPath = DEMPath ;
    externalDEM->dataFile = NULL ;
    externalDEM->flag = 0 ;
    externalDEM->DEMName = getFileNameFromPath(DEMPath) ;
    externalDEM->dataFile = externalDEMDataFile ;
    /* Flag setting */
    externalDEM->flag |= _PROJECT_DEM_ ;
    externalDEM->flag |= (externalDEM->dataFile->flag & _FLIP_DATA_)? _FLIP_DEM_ : externalDEM->flag ;
    externalDEM->holeFillingFactor = 1.2 ;
    externalDEM->flag |= (isFlagPresentInCSV(clCSV, "f"))? _FILL_HOLES_ : externalDEM->flag ;
    externalDEM->flag |= (isFlagPresentInCSV(clCSV, "n"))? _NEAREST_NEIGHBOR_ : externalDEM->flag ;
    externalDEM->flag |= (isFlagPresentInCSV(clCSV, "k"))? _KEEP_EXTRACTED_DEM_ : externalDEM->flag ;
    externalDEM->flag |= (isFlagPresentInCSV(clCSV, "s"))? _AMPLITUDE_SIMULATION_ : externalDEM->flag ;
    if ((anInt = isArgumentPresentInCSV(clCSV, "-f="))) {
        sscanf(clCSV->stringVal[anInt] + 3, "%lf", &externalDEM->holeFillingFactor) ;
        anInt = _FILL_HOLES_ ;
        externalDEM->flag &= ~anInt ;
    }
    externalDEM->layoverThreshold = .1 ; 
    if ((anInt = isArgumentPresentInCSV(clCSV, "-l="))) {
        sscanf(clCSV->stringVal[anInt] + 3, "%lf", &externalDEM->layoverThreshold) ;
    }

    return (externalDEM) ;
}

  
/* Masks characteristics reading */
maskStruct **openExternalMaskFiles(keyValue *parametersList) {
    char *aPath, maskingValue[4] ;
    char *maskPath[3] ;
    char aKey[32] ;
    int unsigned maskType[4] ;
    int i, j ;
    maskStruct **mask = NULL ;
    CSVStruct *perDateMasks, *maskList = NULL ;

    /* Mask types */
    maskType[0] = _IS_GEOGRAPHICAL_MASK_ ;
    maskType[1] = _IS_THRESHOLD_MASK_ ;
    maskType[2] = _IS_DETREND_MASK_ ;
    maskType[3] = _IS_EVENT_MASK_ ;

    /* Build masks list */
    aPath = getStringValForKeyIn(parametersList, "Mask file path 1") ;
    maskPath[0] = getGeoreferencedDataFilePath(aPath) ;    
    aPath = getStringValForKeyIn(parametersList, "Mask file path 2") ;
    maskPath[1] = getGeoreferencedDataFilePath(aPath) ;    
    aPath = getStringValForKeyIn(parametersList, "Mask file path 3") ;
    maskPath[2] = getGeoreferencedDataFilePath(aPath) ;    
    aPath = getStringValForKeyIn(parametersList, "Per date detrend mask files directory") ;
    for ( i = 0; i < 3; i++) {
        maskingValue[i] = 0 ;
        if (maskPath[i]) {
            sprintf(aKey, "Masking value %1d", i + 1) ; 
            maskingValue[i] = (char)getIntValForKeyIn(parametersList, aKey) ;
            maskList = addStringValInCSVStruct(maskPath[i], maskList) ;
            free(maskPath[i]) ;
        }
    }
    maskingValue[i] = 0 ;
    
    if (isDir(aPath)) {
        if((perDateMasks = recursiveSearchOfFileInDir("eventMask", aPath))) {
            maskingValue[i] = (char)getIntValForKeyIn(parametersList, "Event masks masking value") ;
            for ( i = 0; i < perDateMasks->numberOfEntries; i++) {
                if((aPath = getGeoreferencedDataFilePath(perDateMasks->stringVal[i]))) {
                    maskList = addStringValInCSVStruct(aPath, maskList) ;
                }
            }
            freeCSVStruct(perDateMasks) ;
        }
    }

    if (maskList) {
        if ((mask = malloc(maskList->numberOfEntries * sizeof(mask[0]))) == NULL) {
            ase("\t-/-> Failed to allocate masks file list\n") ;
        }

        for (i = j = 0; i < maskList->numberOfEntries; i++) {
            if ((mask[i] = malloc(sizeof(mask[0][0]))) == NULL) {
                ase("\t-/-> Failed to allocate mask structure\n") ;
            }
            
            if ((mask[i]->dataFile = getGeoreferencedDataFile(maskList->stringVal[i]))) {
                mask[i]->flag = 0 ;
                mask[i]->maskName = initStringWithString(getPointerToFileNameInPath(maskList->stringVal[i])) ;

                if (mask[i]->dataFile->typeSize != 1) {
                    printf("\t-/-> Wrong mask given in input.\n\t%s\n", aPath) ;
                    ase("\t-/-> Mask file must be a file of byte values") ;
                }

                /* Flag and masking value setting */
                if (i < 3) {
                    while (j < 3 && !maskPath[j]) {
                        j++ ;
                    }
                    if (j < 3) {
                        mask[i]->maskVal = maskingValue[j] ;
                        mask[i]->flag = mask[i]->flag | maskType[j] ;
                        j++ ;
                    }
                }
                
                mask[i]->flag |= (mask[i]->dataFile->flag & _FLIP_DATA_)? _FLIP_MASK_ : mask[i]->flag ;
                if (isSubStringPresentInString(maskList->stringVal[i], "eventMask")) {
                    mask[i]->flag = mask[i]->flag | _IS_EVENT_MASK_ ;
                    mask[i]->maskVal = maskingValue[3] ;
                }
            }
            else {
                printf("\t-/-> Failed to open mask file:") ;
                ase(maskList->stringVal[i]) ;
            }
        }
        mask[i - 1]->flag |= _IS_LAST_MASK_ ;
        freeCSVStruct(maskList) ;
    }

    return (mask) ;
}


void freeExternalDEMStruct(externalDEMStruct *externalDEM)
{
    if (externalDEM->dataFile) {
        freeRawFileDescriptor(externalDEM->dataFile) ;
    }
    if (externalDEM->DEMPath) {
        free(externalDEM->DEMPath) ;
    }
    if (externalDEM->DEMName) {
        free(externalDEM->DEMName) ;
    }   
    
    free(externalDEM) ;
}

satRef *slantRangeReferencingOfDEM(externalDEMStruct *externalDEM, CSLImage *masterImage, keyValue *parameterList)
{
    char *aPath, startingPoint ;
    int anIndex, normalizationFactor ;
    size_t dataTypeSize ;
    long seekval ;
    size_t iX, iY, iX0, iY0, iXMax, iYMax, xDim, yDim, xDim0, yDim0 ;
    float *xRef, *yRef, *H, isRangeIncreasing ;
    float *xRadius, *yRadius, d1, d2 ;
    float X0 = 0.0, noVal ;
    float *yRef_1, *yRef1, *aFloatPointer ;
    double xSampling, xMaxSampling, xAverageSampling, layoverThreshold ;
    double yMaxSampling, yAverageSampling ;
    double longitude, latitude ;
 	double *llh, *xy ;
    void *externalDEMLine = NULL ;
    SLCImageInfo *referenceInfoImage ;
    polygon *aoi ;
	geoRef *geoRefMaster ;
	satRef *satRefMaster ;
    progressCounter *aCounter ;
    keyValue *externalDEMDescription ;

//    updateSceneAverageHeight(masterImage, externalDEM) ;
    referenceInfoImage = readAndInitInfoImageInCSLImage(masterImage) ;

    /* Area of interest delineation */
    aoi = circumscribedRectangleOfPolygon(referenceInfoImage->loc) ;
    if(!polygonesIntersects(aoi, externalDEM->dataFile->aoi))
        ase("Nothing to project. External DEM have no intersection with targeted SAR image") ;

    for (anIndex = 0; anIndex < 4; anIndex++) {
        aoi->P[anIndex].x = floor((aoi->P[anIndex].x - externalDEM->dataFile->x0) / externalDEM->dataFile->xSampling) ;
        aoi->P[anIndex].y = floor((aoi->P[anIndex].y - externalDEM->dataFile->y0) / externalDEM->dataFile->ySampling) ;
    }

    /* We enlarge the extracted DEM because image localization is based on average height which is not necessarly representative of the whole area */
    iX0 = (aoi->P[0].x - 50 < 0)? 0 : (size_t)aoi->P[0].x - 50 ;
    iY0 = (aoi->P[0].y - 50 < 0)? 0 : (size_t)aoi->P[0].y - 50 ;
    iXMax = (aoi->P[2].x + 50 > externalDEM->dataFile->xDim)? externalDEM->dataFile->xDim - 1 : (size_t)aoi->P[2].x + 50 ;
    iYMax = (aoi->P[2].y + 50 > externalDEM->dataFile->yDim)? externalDEM->dataFile->yDim - 1 : (size_t)aoi->P[2].y + 50 ;

    /* External DEM dimensions */
    xDim0 = externalDEM->dataFile->xDim ;
    yDim0 = externalDEM->dataFile->yDim ;
    dataTypeSize = externalDEM->dataFile->typeSize ;
    /* Extracted DEM dimensions */
    xDim = iXMax - iX0 + 1 ;
    yDim = iYMax - iY0 + 1 ;

    /* Initialize back and forth referencing for master image */
	geoRefMaster = allocAndInitGeorefStructureForTargetEllipsoid(referenceInfoImage, referenceInfoImage->ellRef) ;
	satRefMaster = allocAndInitSatRefWithGeoRefStructure(geoRefMaster) ;
    if (externalDEM->dataFile->excludingValue) {
        noVal = satRefMaster->params->DEMExcludingValue = *((float *)(externalDEM->dataFile->excludingValue)) ;
    }
    else {
        noVal = satRefMaster->params->DEMExcludingValue = floatNaN ;
    }
    

    /* Create temporary files for writing */
    aPath = initStringWith2Strings(masterImage->dataDirectoryPath, "/xRef") ;
    satRefMaster->files->xRef = openRawFileForReadingAndWritingAtPath(aPath) ;
    satRefMaster->files->xRef->xDim = xDim ;
    satRefMaster->files->xRef->yDim = yDim ;
    free(aPath) ;
    aPath = initStringWith2Strings(masterImage->dataDirectoryPath, "/yRef") ;
    satRefMaster->files->yRef = openRawFileForReadingAndWritingAtPath(aPath) ;
    satRefMaster->files->yRef->xDim = xDim ;
    satRefMaster->files->yRef->yDim = yDim ;
    free(aPath) ;
    aPath = initStringWith2Strings(masterImage->dataDirectoryPath, "/externalDEM") ;
    satRefMaster->files->DEM = openRawFileForReadingAndWritingAtPath(aPath) ;
    satRefMaster->files->DEM->xDim = xDim ;
    satRefMaster->files->DEM->yDim = yDim ;
    free(aPath) ;
    aPath = initStringWith2Strings(masterImage->dataDirectoryPath, "/xRadius") ;
    satRefMaster->files->xRadius = openRawFileForReadingAndWritingAtPath(aPath) ;
    satRefMaster->files->xRadius->xDim = xDim ;
    satRefMaster->files->xRadius->yDim = yDim ;
    free(aPath) ;
    aPath = initStringWith2Strings(masterImage->dataDirectoryPath, "/yRadius") ;
    satRefMaster->files->yRadius = openRawFileForReadingAndWritingAtPath(aPath) ;
    satRefMaster->files->yRadius->xDim = xDim ;
    satRefMaster->files->yRadius->yDim = yDim ;
    free(aPath) ;

    /* Update and save external DEM characterisitics */
    externalDEM->dataFile->xDim = xDim ;
    externalDEM->dataFile->yDim = yDim ;
    externalDEM->dataFile->x0 += iX0 * externalDEM->dataFile->xSampling ;
    externalDEM->dataFile->y0 += iY0 * externalDEM->dataFile->ySampling ;

    if (externalDEM->flag & _KEEP_EXTRACTED_DEM_) {
        externalDEMDescription = allocAKeyValuePair() ;
        setStringValForKeyIn(externalDEMDescription, "Extracted external DEM", "") ;
        setStringValForKeyIn(externalDEMDescription, "**********************", "") ;
        setStringValForKeyIn(externalDEMDescription, "externalDEM", "File name") ;
        setIntValForKeyIn(externalDEMDescription, xDim, "X dimension") ;
        setIntValForKeyIn(externalDEMDescription, yDim, "Y dimension") ;
        setDoubleValForKeyIn(externalDEMDescription, 180./PI * externalDEM->dataFile->x0, "xMin") ;
        setDoubleValForKeyIn(externalDEMDescription, 180./PI * externalDEM->dataFile->y0, "yMin") ;
        setDoubleValForKeyIn(externalDEMDescription, 180./PI * (externalDEM->dataFile->x0 + xDim * externalDEM->dataFile->xSampling), "xMax") ;
        setDoubleValForKeyIn(externalDEMDescription, 180./PI * (externalDEM->dataFile->y0 + yDim * externalDEM->dataFile->ySampling), "yMax") ;
        setDoubleValForKeyIn(externalDEMDescription, 180./PI * externalDEM->dataFile->xSampling, "X Sampling") ;
        setDoubleValForKeyIn(externalDEMDescription, 180./PI * externalDEM->dataFile->ySampling, "Y Sampling") ;
        aPath = initStringWith2Strings(masterImage->infoDirectoryPath, "/externalDEM.txt") ;
        writeParameterFileAtPath(externalDEMDescription, aPath) ;
        free(aPath) ;
        freeKeyValueList(externalDEMDescription) ;
    }

    /* Initialization of vectors */
    xRadius = vectorFloat(iX0, iXMax) ;
    yRadius = vectorFloat(iX0, iXMax) ;
    xRef = vectorFloat(iX0, iXMax) ;
    yRef = vectorFloat(iX0, iXMax) ;
    yRef_1 = vectorFloat(iX0, iXMax) ;
    yRef1 = vectorFloat(iX0, iXMax) ;
    H = vectorFloat(iX0, iXMax) ;
    llh = vectorDouble(0, 2) ;					/* This is a Lon-Lat-H vector */
	xy = vectorDouble(0, 1) ;					/* This is a 2D vector for rang-azimuth localization of a point */


    /* latitude and longitude initialization */
    latitude = llh[1] = externalDEM->dataFile->y0 ;
    longitude = llh[0] = externalDEM->dataFile->x0 ;

    /* Determine if range is increasing or decreasing with longitude for null altitude */
    /* This will be used to exclude layerover points */
    llh[2] = 0 ;
    rangeAzimuthReferencingOfpoint(llh, xy, satRefMaster) ;
    xRef[iX0] = (float)xy[0] ;
    llh[0] = externalDEM->dataFile->x0 + (iXMax) * externalDEM->dataFile->xSampling ;
    rangeAzimuthReferencingOfpoint(llh, xy, satRefMaster) ;
    xRef[iXMax] = (float)xy[0] ;

    isRangeIncreasing = ((xRef[iXMax] - xRef[iX0]) < 0.)? -1 : 1 ;

    /* Layover threshold is computed as 10% pixel layover in destination range sampling */
    layoverThreshold = -externalDEM->layoverThreshold * getDoubleValForKeyIn(parameterList, "Range reduction factor") * referenceInfoImage->rangeResolutionCell ;


    /* Initialize positionning into external DEM data file */
    seekval = (externalDEM->flag & _FLIP_DEM_)? (long)((yDim0 - 1 - iY0) * xDim0 + iX0) * dataTypeSize : (long)(iY0 * xDim0 + iX0) * sizeof(float) ;
    if(fseek(externalDEM->dataFile->f, seekval, SEEK_SET) == -1) {
        ase("Failed to seek into external DEM file") ;
    }
    seekval = (externalDEM->flag & _FLIP_DEM_)? (-xDim0 - xDim) * dataTypeSize : (xDim0 - xDim) * sizeof(float) ;

    /* Allocating line of external DEM if required */
    if (dataTypeSize != sizeof(float) || externalDEM->dataFile->byteOrder != isArchBigEndian()) {
        externalDEMLine = vectorOfType(0, xDim - 1, dataTypeSize) ;
    }

    /* Slant range referencing loop */
    /* **************************** */
    printf("Slant range referencing of external DEM:\n") ;

    aCounter = initProgressCounterWithMinMaxValue(iY0, iYMax) ;
    xMaxSampling = yMaxSampling = xAverageSampling = yAverageSampling = 0. ;
    normalizationFactor = 0 ;
    /* Loop on Latitude */
    for (iY = iY0; iY <= iYMax; iY++) {
        /* Initialize longitude */
        longitude = externalDEM->dataFile->x0 ;
        llh[0] = longitude ;

        /* Read line of local heights line */
        if (dataTypeSize != sizeof(float) || externalDEM->dataFile->byteOrder != isArchBigEndian()) {
            if (xDim != fread(externalDEMLine, dataTypeSize, xDim, externalDEM->dataFile->f)) {
                ase("Failed to read into external DEM file") ;
            }
            for (iX = 0; iX < xDim; iX++) {
                if (externalDEM->dataFile->byteOrder != isArchBigEndian()) {
                    swapByteStructOfType(externalDEMLine + iX * dataTypeSize, dataTypeSize) ;
                }
                if (dataTypeSize == 2) {
                    H[iX0 + iX] = (float)(*(short *)((externalDEMLine + iX * dataTypeSize))) ;
                }
                else {
                    H[iX0 + iX] = (*(float *)((externalDEMLine + iX * dataTypeSize))) ;
                }
            }
        }
        else {
            if (xDim != fread(&H[iX0], sizeof(float), xDim, externalDEM->dataFile->f)) {
                ase("Failed to read into external DEM file") ;
            }
        }

        /* Loop on longitude */
        startingPoint = 1 ;
        for (iX = iX0; iX <= iXMax; iX++) {
            if (!areFloatValsEquals(H[iX], noVal)) {
                /* Update local height */
                llh[2] = H[iX] ;
                rangeAzimuthReferencingOfpoint(llh, xy, satRefMaster) ;

                xRef[iX] = (float)xy[0] ;
                yRef[iX] = (float)xy[1] ;

                /* Memorize starting point of line */
                if (startingPoint) {
                    X0 = xRef[iX] ;
                    startingPoint = 0 ;
                }

                /* Detect if layover occur */
                xSampling = (double)(xRef[iX] - X0) ;
                if (xSampling * isRangeIncreasing < layoverThreshold) {
                    xRef[iX] = noVal ;
                    yRef[iX] = noVal ;
                }
                else {
                    X0 = xRef[iX] ;
                }
            }
            else {
                xRef[iX] = noVal ;
                yRef[iX] = noVal ;
            }

            /* update longitude */
            longitude += externalDEM->dataFile->xSampling ;
            llh[0] = longitude ;
        }
        /* Save referencing lines */
        if ((fwrite(&xRef[iX0], sizeof(float), xDim, satRefMaster->files->xRef->f) != xDim)) {
            ase("Failed to write line in xReferencing file") ;
        }
        if ((fwrite(&yRef[iX0], sizeof(float), xDim, satRefMaster->files->yRef->f) != xDim)) {
            ase("Failed to write line in yReferencing file") ;
        }
        if ((fwrite(&H[iX0], sizeof(float), xDim, satRefMaster->files->DEM->f) != xDim)) {
            ase("Failed to write line in extracted DEM file") ;
        }

        /* Update latitude */
        latitude += externalDEM->dataFile->ySampling ;
        llh[1] = latitude ;

        /* Update positionning into DEM file */
        fseek(externalDEM->dataFile->f, seekval, SEEK_CUR) ;

        updateProgressCounterForIndex(aCounter, iY) ;
    }
    updateProgressCounterForIndex(aCounter, iY) ;

    /* Flush all files */
    fflush(satRefMaster->files->xRef->f) ;
    fflush(satRefMaster->files->yRef->f) ;
    fflush(satRefMaster->files->DEM->f) ;

    /* Now that the external DEM exists, we associate it to the input file to be projected */
    satRefMaster->files->input = openRawFileForReadingAtPath(satRefMaster->files->DEM->accessPath) ;
    satRefMaster->files->input->xDim = xDim ;
    satRefMaster->files->input->yDim = yDim ;


    /* Now, we will reread yReferencing to compute average and max y sampling as also local interpolation radius */
    fseek(satRefMaster->files->xRef->f, 0L, SEEK_SET) ;
    fseek(satRefMaster->files->yRef->f, 0L, SEEK_SET) ;

    xMaxSampling = xAverageSampling = normalizationFactor = 0. ;
    for (iY = iY0; iY <= iYMax; iY++) {
        fread(&xRef[iX0], sizeof(float), xDim, satRefMaster->files->xRef->f) ;
        for (iX = iX0 + 1; iX < iXMax; iX++) {
            /* We will estimate X local interpolation radius */
            if (!areFloatValsEquals(xRef[iX], noVal)) {
                d1 = (areFloatValsEquals(xRef[iX - 1], noVal))? 0 : fabsf(xRef[iX] - xRef[iX - 1]) ;
                d2 = (areFloatValsEquals(xRef[iX + 1], noVal))? 0 : fabsf(xRef[iX] - xRef[iX + 1]) ;

                if (externalDEM->flag & _FILL_HOLES_) {
                    xRadius[iX] = (d1 < d2)? d2 : d1 ;
                    xRadius[iX] *= externalDEM->holeFillingFactor ;
                }
                else {
                    xRadius[iX] = (d1)? (d1 > d2)? (d2)? d2 : d1 : d1 : d2 ;
                    if (!(externalDEM->flag & _NEAREST_NEIGHBOR_)) {
                        xRadius[iX] *= externalDEM->holeFillingFactor ;
                    }
                }
                xAverageSampling += xRadius[iX] ;
                xMaxSampling = (xMaxSampling < xRadius[iX])? xRadius[iX] : xMaxSampling ;
                normalizationFactor++ ;
            }
            else
                xRadius[iX] = noVal ;
        }
        xRadius[iX0] = xRadius[iX0 + 1] ;
        xRadius[iX] = xRadius[iX - 1] ;
        fwrite(xRadius + iX0, sizeof(float), xDim, satRefMaster->files->xRadius->f) ;
    }
    if (!xMaxSampling) {
        ase("Nothing was referenced...\nStrange....") ;
    }
    xAverageSampling /= normalizationFactor ;

    yMaxSampling = yAverageSampling = normalizationFactor = 0. ;
    fread(yRef_1 + iX0, sizeof(float), xDim, satRefMaster->files->yRef->f) ;
    fread(yRef + iX0, sizeof(float), xDim, satRefMaster->files->yRef->f) ;
    fwrite(yRadius + iX0, sizeof(float), xDim, satRefMaster->files->yRadius->f) ;
    for (iY = iY0 + 2; iY <= iYMax; iY++) {
        fread(yRef1 + iX0, sizeof(float), xDim, satRefMaster->files->yRef->f) ;
        for (iX = iX0; iX <= iXMax; iX++) {
            if (!areFloatValsEquals(yRef[iX], noVal)) {
                /* We will estimate Y local interpolation radius */
                d1 = (areFloatValsEquals(yRef_1[iX], noVal))? 0 : fabsf(yRef[iX] - yRef_1[iX]) ;
                d2 = (areFloatValsEquals(yRef1[iX], noVal))? 0 : fabsf(yRef[iX] - yRef1[iX]) ;

                if (externalDEM->flag & _FILL_HOLES_) {
                    yRadius[iX] = (d1 < d2)? d2 : d1 ;
                    yRadius[iX] *= externalDEM->holeFillingFactor ;
                }
                else {
                    yRadius[iX] = (d1)? (d1 > d2)? (d2)? d2 : d1 : d1 : d2 ;
                    if (!(externalDEM->flag & _NEAREST_NEIGHBOR_)) {
                        yRadius[iX] *= externalDEM->holeFillingFactor ;
                    }
                }

                /* Measure of max and average ySampling */
                yAverageSampling += yRadius[iX] ;
                yMaxSampling = (yMaxSampling < yRadius[iX])? yRadius[iX] : yMaxSampling ;
                normalizationFactor++ ;
            }
            else
                yRadius[iX] = noVal ;
        }
        fwrite(yRadius + iX0, sizeof(float), xDim, satRefMaster->files->yRadius->f) ;

        /* Line shift */
        aFloatPointer = yRef_1 ;
        yRef_1 = yRef ;
        yRef = yRef1 ;
        yRef1 = aFloatPointer ;
    }
    yAverageSampling /= normalizationFactor ;

    /* We replicate first and last lines */
    fwrite(yRadius + iX0, sizeof(float), xDim, satRefMaster->files->yRadius->f) ;
    fseek(satRefMaster->files->yRadius->f, xDim * sizeof(float), SEEK_SET) ;
    fread(yRadius + iX0, sizeof(float), xDim, satRefMaster->files->yRadius->f) ;
    rewind(satRefMaster->files->yRadius->f) ;
    fwrite(yRadius + iX0, sizeof(float), xDim, satRefMaster->files->yRadius->f) ;

    /* Save max and average samplings */
    satRefMaster->params->xAverageSampling = (float)xAverageSampling ;
    satRefMaster->params->yAverageSampling = (float)yAverageSampling ;
    satRefMaster->params->xMaxSampling = (float)xMaxSampling ;
    satRefMaster->params->yMaxSampling = (float)yMaxSampling ;

    printf("\nReferencing X average sampling: %f\n", satRefMaster->params->xAverageSampling) ;
    printf("Referencing Y average sampling: %f\n", satRefMaster->params->yAverageSampling) ;
    printf("Referencing X max sampling: %f\n", satRefMaster->params->xMaxSampling) ;
    printf("Referencing Y max sampling: %f\n", satRefMaster->params->yMaxSampling) ;

    freeVectorFloat(xRef, iX0) ;
    freeVectorFloat(yRef, iX0) ;
    freeVectorFloat(yRef_1, iX0) ;
    freeVectorFloat(yRef1, iX0) ;
    freeVectorFloat(H, iX0) ;
    freeVectorFloat(xRadius, iX0) ;
    freeVectorFloat(yRadius, iX0) ;
    freeVectorDouble(llh, 0) ;
    freeVectorDouble(xy, 0) ;
    freeProgressCounter(aCounter) ;
    freePolygon(aoi) ;
    if (externalDEMLine) {
        freeVectorOfType(externalDEMLine, 0, dataTypeSize) ;
    }

    return (satRefMaster) ;
}


geoProj *initSlantRangeProjection(satRef *satRefMaster, CSLImage *masterImage, keyValue *parametersList, char saveMapping)
{
    char *aPath ;
    int xDim, yDim ;
    geoProj *gP ;

    /* Slant range projection initialization */
    gP = allocGeoProj() ;


    /* Projection parameters reading */
	gP->params->resamplingMethod = initStringWithString(getStringValForKeyIn(parametersList, "Resampling method")) ;
    gP->params->weightingMethod = initStringWithString(getStringValForKeyIn(parametersList, "Weighting method")) ;
	gP->params->smoothingFactor = getDoubleValForKeyIn(parametersList, "ID smoothing factor") ;
	gP->params->exponent = getDoubleValForKeyIn(parametersList, "ID weighting exponent") ;
	gP->params->FWHM = getDoubleValForKeyIn(parametersList, "FWHM") ;
    gP->params->HWHM = gP->params->FWHM / 2. ;
    gP->params->isDEMPresent = 1 ;
    gP->params->flag |= (saveMapping)? _SAVE_MAPPING_ : gP->params->flag ;
    gP->params->DEMExcludingValue = satRefMaster->params->DEMExcludingValue ;

    /* Projected DEM will use the same excluding value */
    gP->params->noVal = gP->params->DEMExcludingValue ;

    /* Files association */
    gP->files->DEM = satRefMaster->files->DEM ;
    gP->files->xRef = satRefMaster->files->xRef ;
    gP->files->yRef = satRefMaster->files->yRef ;
    gP->files->xRadius = satRefMaster->files->xRadius ;
    gP->files->yRadius = satRefMaster->files->yRadius ;

    /* Input file opening */
    /* All others will be freed while the geoRef structure will */
    gP->files->input = openRawFileForReadingAtPath(satRefMaster->files->input->accessPath) ;
    gP->files->input->xDim = satRefMaster->files->input->xDim ;
    gP->files->input->yDim = satRefMaster->files->input->yDim ;

    /* Create projection matrix file */
    aPath = initStringWith2Strings(masterImage->dataDirectoryPath, "/projMat") ;
    if((gP->files->M = openRawFileForReadingAndWritingAtPath(aPath)) == NULL)
        ase("Failed to open/create Projection matrix file\n") ;
    free(aPath) ;

    /* create outputFile */
    aPath = initStringWith2Strings(masterImage->dataDirectoryPath, "/externalSlantRangeDEM") ;
    if((gP->files->output = openRawFileForReadingAndWritingAtPath(aPath)) == NULL)
        ase("Failed to open/create external slant range DEM file\n") ;
    free(aPath) ;

    /* Define projection sampling */
    gP->params->xSampling = round(getFloatValForKeyIn(parametersList, "Range reduction factor")) ;
    gP->params->ySampling = round(getFloatValForKeyIn(parametersList, "Azimuth reduction factor"))  ;

    /* Read projection frame or define it as the reference slant range image frame plus an additional border */
    gP->frame->xMin = - 5 * gP->params->xSampling ;
    if (isKeyValPresent(parametersList, "xMin")) {
        gP->frame->xMin = getIntValForKeyIn(parametersList, "xMin") ;
    }
    gP->frame->xMax = (satRefMaster->frame->xMax / (int)gP->params->xSampling + 5) * (int)gP->params->xSampling ;
    if (isKeyValPresent(parametersList, "xMax")) {
        gP->frame->xMax = getIntValForKeyIn(parametersList, "xMax") ;
    }
    gP->frame->yMin = - 5 * gP->params->ySampling ;
    if (isKeyValPresent(parametersList, "yMin")) {
        gP->frame->yMin = getIntValForKeyIn(parametersList, "yMin") ;
    }
    gP->frame->yMax = (satRefMaster->frame->yMax / (int)gP->params->ySampling + 5) * (int)gP->params->ySampling ;
    if (isKeyValPresent(parametersList, "yMax")) {
        gP->frame->yMax = getIntValForKeyIn(parametersList, "yMax") ;
    }

    /* Define slant range product size */
    xDim = gP->frame->xMax - gP->frame->xMin + 1 ;
    yDim = gP->frame->yMax - gP->frame->yMin + 1 ;
    gP->params->xDimM = div(xDim, gP->params->xSampling).quot + (div(xDim, gP->params->xSampling).rem != 0) ;
    gP->params->yDimM = div(yDim, gP->params->ySampling).quot + (div(yDim, gP->params->ySampling).rem != 0) ;
//	gP->params->xDimM = floor((gP->frame->xMax - gP->frame->xMin) / gP->params->xSampling) + 1 ;
//	gP->params->yDimM = floor((gP->frame->yMax - gP->frame->yMin) / gP->params->ySampling) + 1 ;

    /* Define search radius */
    gP->params->xRadius = satRefMaster->params->xAverageSampling ;
    gP->params->yRadius = satRefMaster->params->yAverageSampling ;

    /* Update parameters list */
    setStringValForKeyIn(parametersList, "", "") ;
    setStringValForKeyIn(parametersList, "Slant range projection frame", "") ;
    setStringValForKeyIn(parametersList, "****************************", "") ;
    setDoubleValForKeyIn(parametersList, gP->frame->xMin, "xMin") ;
    setDoubleValForKeyIn(parametersList, gP->frame->xMax, "xMax") ;
    setDoubleValForKeyIn(parametersList, gP->frame->yMin, "yMin") ;
    setDoubleValForKeyIn(parametersList, gP->frame->yMax, "yMax") ;
    setStringValForKeyIn(parametersList, "", "") ;
    setIntValForKeyIn(parametersList, gP->params->xSampling, "X sampling of projected product [pix]") ;
    setIntValForKeyIn(parametersList, gP->params->ySampling, "Y sampling of projected product [pix]") ;
    setIntValForKeyIn(parametersList, gP->params->xDimM, "X size of projected products [pix]") ;
    setIntValForKeyIn(parametersList, gP->params->yDimM, "Y size of projected products [pix]") ;
    setStringValForKeyIn(parametersList, "", "") ;
    if (isnan(gP->params->DEMExcludingValue)) {
        setStringValForKeyIn(parametersList, "NaN", "Slant range DEM excluding value") ;
    }
    else {
        setFloatValForKeyIn(parametersList, gP->params->DEMExcludingValue, "Slant range DEM excluding value") ;
    }
    

    aPath = initStringWith2Strings(masterImage->infoDirectoryPath, "/externalSlantRangeDEM.txt") ;
    writeParameterFileAtPath(parametersList, aPath) ;
    free(aPath) ;

    return (gP) ;
}

void slantRangeDEMProjection(geoProj *gP, externalDEMStruct *externalDEM)
{
    /* We project external DEM into slant range, saving mapping if required */
    geoProjection(gP) ;
    if (!(externalDEM->flag & _KEEP_EXTRACTED_DEM_)) {
        unlink(gP->files->input->accessPath) ;
    }
}

void slantRangeMaskProjection(geoProj *gP, externalDEMStruct *externalDEM, maskStruct **mask)
{
    char unsigned *byteMaskLine, orVal ;
    char **byteMask, maskVal, combine ;
    char *aPath, *outputDir ;
    char goOn ;
    size_t Nx, Ny, yIndex, i ;
    size_t iX, iY ;
    size_t xDimIn, yDimIn ;
    size_t xDimOut, yDimOut ;
    float *aMaskLine ;
    gridMap *maskGrid ;
    rawFileDescriptor *extractedMask, *outputMask ;
    maskStruct *thisMask ;

    /* First, trash existing slantRangeMask if existing */
    outputDir = initStringWithString(gP->files->output->directoryPath) ;
    aPath = initStringWith2Strings(outputDir, "slantRangeMask") ;
    if(fileExistsAtPath(aPath)) {
        unlink(aPath) ;
    }
    free(aPath) ;

    /* Input extracted masks will have same dimension than extracted DEM */
    xDimIn = gP->files->input->xDim ;
    yDimIn = gP->files->input->yDim ;
    /* Output masks will have same dimension than slant range projected DEM */
    xDimOut = gP->params->xDimM ;
    yDimOut = gP->params->yDimM ;

    /* Mask projection */
    i = -1 ;
    do {
        i++ ;
        thisMask = mask[i] ;
        goOn = !(thisMask->flag & _IS_LAST_MASK_) ;
        orVal = 1 ;
        /* We allocate and read the external data */
        thisMask->dataFile->indexedData = matrixOfType(0, thisMask->dataFile->yDim - 1, 0, thisMask->dataFile->xDim - 1, 1) ;
        if(fread(thisMask->dataFile->indexedData[0], 1, thisMask->dataFile->fileLength, thisMask->dataFile->f) != thisMask->dataFile->fileLength) {
            ase("Failed to read mask file");
        }

        /* We create a grid which is the external mask */
        Nx = thisMask->dataFile->xDim ;
        Ny = thisMask->dataFile->yDim ;
        maskGrid = createFloatGridOfSize(Nx, Ny, 1, 1) ;

        /* In case of detrend or event mask, areas outside of the given mask are not masked */
        maskGrid->outVal = (thisMask->flag & _IS_DETREND_MASK_ || thisMask->flag & _IS_EVENT_MASK_)? 0 : 1 ;

        maskVal = thisMask->maskVal ; 
        byteMask = (char **)thisMask->dataFile->indexedData ;
        /* Transfer mask values to grid */
        for (iY = 0; iY < Ny; iY++) {
            yIndex = (thisMask->flag & _FLIP_MASK_)? Ny - iY - 1 : iY ;
            for (iX = 0; iX < Nx; iX++) {
                maskGrid->floatVal[iX][iY] = (byteMask[yIndex][iX] == maskVal)? 1. : 0. ;
            }
        }

        freeMatrixOfType(thisMask->dataFile->indexedData, 0, 0, 1) ;
        thisMask->dataFile->indexedData = NULL ;

        /* Computing external DEM to mask transform */
        maskGrid->T = matrixDouble(0, 1, 0, 2) ;
        maskGrid->T[0][0] = externalDEM->dataFile->xSampling / thisMask->dataFile->xSampling ;
        maskGrid->T[1][1] = externalDEM->dataFile->ySampling / thisMask->dataFile->ySampling ;
        maskGrid->T[0][1] = maskGrid->T[1][0] =  0. ;
        maskGrid->T[0][2] = (externalDEM->dataFile->x0 - thisMask->dataFile->x0) / thisMask->dataFile->xSampling ;
        maskGrid->T[1][2] = (externalDEM->dataFile->y0 - thisMask->dataFile->y0) / thisMask->dataFile->ySampling ;

        /* Create mask file to be projected */
        aPath = initStringWith2Strings(gP->files->input->directoryPath, "extractedMask") ;
        extractedMask = openRawFileForReadingAndWritingAtPath(aPath) ;
        extractedMask->xDim = xDimIn ;
        extractedMask->yDim = yDimIn ;
        free(aPath) ;

        aMaskLine = vectorFloat(0, xDimIn) ;
        for (iY = 0; iY < yDimIn; iY++) {
            for (iX = 0; iX < xDimIn; iX++) {
                aMaskLine[iX] = nearestNeighbourInterpolationOfGridForImageCoordinate(maskGrid, iX, iY) ;
            }
            fwrite(aMaskLine, sizeof(float), xDimIn, extractedMask->f) ;
        }
        freeVectorFloat(aMaskLine, 0) ;
        fflush(extractedMask->f) ;
        freeGridMap(maskGrid) ;

        /* Free existing input/output to reallocate them */
        freeRawFileDescriptor(gP->files->input) ;
        freeRawFileDescriptor(gP->files->output) ;
        gP->files->input = NULL ;
        gP->files->output = NULL ;

        /* The mask to be projected is the extractedMask */
        gP->files->input = extractedMask ;

        /* We will project it under the name tempMask */
        aPath = initStringWith2Strings(outputDir, "tempMask") ;
        if((gP->files->output = openRawFileForReadingAndWritingAtPath(aPath)) == NULL) {
            ase("Failed to create slant range projected mask file\n") ;
        }
        free(aPath) ;

        gP->files->output->xDim = xDimOut ;
        gP->files->output->yDim = yDimOut ;
        gP->params->noVal = (thisMask->flag & _IS_DETREND_MASK_ || thisMask->flag & _IS_EVENT_MASK_)? 0 : 1 ;

        /* Mask projection */
        printf("\n\n---> Projection of mask %s...\n", thisMask->maskName) ;
        sprintf(gP->params->resamplingMethod, "NN") ;
        resamplingUsingSavedMapping(gP) ;

        /* We can now trash the extracted mask */
        unlink(gP->files->input->accessPath) ;

        /* Convert projected mask to byte */
        rewind(gP->files->output->f) ;
        if (thisMask->flag & _IS_EVENT_MASK_) {
            aPath = initStringWith2Strings(outputDir, thisMask->maskName) ;
            combine = 0 ;
        }
        else {
            aPath = initStringWith2Strings(outputDir, "slantRangeMask") ;
            combine = fileExistsAtPath(aPath) ;
        }

        outputMask = openRawFileForReadingAndWritingAtPath(aPath) ;
        free(aPath) ;
        aMaskLine = vectorFloat(0, xDimOut) ;
        byteMaskLine = vectorUChar(0, xDimOut) ;
        orVal = (thisMask->flag & _IS_GEOGRAPHICAL_MASK_)? 1 : (thisMask->flag & _IS_THRESHOLD_MASK_)? 2 : 4 ;
        for (iY = 0; iY < yDimOut; iY++) {
            fread(aMaskLine, sizeof(float), xDimOut, gP->files->output->f) ;
            memset(byteMaskLine, 0, xDimOut) ;
            if (combine) {
                fread(byteMaskLine, 1, xDimOut, outputMask->f) ;
                fseek(outputMask->f, iY * xDimOut, SEEK_SET) ;
            }
            for (iX = 0; iX < xDimOut; iX++) {
                byteMaskLine[iX] |= (aMaskLine[iX] > .5)? orVal : 0 ;
            }
            
            fwrite(byteMaskLine, 1, xDimOut, outputMask->f) ;
        }
        freeVectorFloat(aMaskLine, 0) ;
        freeVectorUChar(byteMaskLine, 0) ;
        freeRawFileDescriptor(outputMask) ;

        /* Close the float version of the projected mask and trash it */
        closeRawFile(gP->files->output) ;
        unlink(gP->files->output->accessPath) ;

        freeRawFileDescriptor(thisMask->dataFile) ;
        free(thisMask->maskName) ;
        free(thisMask) ;
        mask[i] = NULL ;
    } while (goOn) ;

    free(outputDir) ;
    free(mask) ;
    *(&mask) = NULL ;
}


void externalFloatFilesProjection(geoProj *gP, externalDEMStruct *externalDEM, char *floatFilesDir)
{
    char *aPath, *outputDir, *thisFilePath, *thisFileName ;
    size_t Nx, Ny, yIndex, i ;
    size_t iX, iY ;
    size_t xDimIn, yDimIn ;
    size_t xDimOut, yDimOut ;
    float **floatMatrix, *aFloatLine ;
    double xP, yP ;
    gridMap *floatGrid ;
    rawFileDescriptor *thisFile, *extractedFloatFile ;
    CSVStruct *filesList ;

    if (!isDir(floatFilesDir)) {
        return ;
    }

    outputDir = initStringWithString(gP->files->output->directoryPath) ;

    /* Extracted float files will have same dimension than extracted DEM */
    xDimIn = gP->files->input->xDim ;
    yDimIn = gP->files->input->yDim ;
    /* Projected float files will have same dimension than slant range projected DEM */
    xDimOut = gP->params->xDimM ;
    yDimOut = gP->params->yDimM ;

    filesList = getDirectoryListing(floatFilesDir) ;

    for (i = 0; i < filesList->numberOfEntries; i++) {
//        stripExtensionAtEndOfPath(filesList->stringVal[i]) ;
        if((thisFilePath = getGeoreferencedDataFilePath(filesList->stringVal[i]))) {
            thisFile = getGeoreferencedDataFile(thisFilePath) ;
            if (thisFile->typeSize == 4) {
                thisFileName = getFileNameFromPath(filesList->stringVal[i]) ;
                
                printf("\n\t--> Reading georeferenced float file %s\n", thisFileName) ;
                /* We allocate and read the external float file */
                floatMatrix = thisFile->indexedData = (float **)matrixOfType(0, thisFile->yDim - 1, 0, thisFile->xDim - 1, 4) ;
                if(fread(thisFile->indexedData[0], 1, thisFile->fileLength, thisFile->f) != thisFile->fileLength) {
                    ase("Failed to read float file");
                }
                
                /* We create a grid which is the external float file */
                Nx = thisFile->xDim ;
                Ny = thisFile->yDim ;
                floatGrid = createFloatGridOfSize(Nx, Ny, 1, 1) ;
                
                /* Transfer float file values to grid */
                for (iY = 0; iY < Ny; iY++) {
                    yIndex = (thisFile->flag & _FLIP_DATA_)? Ny - iY - 1 : iY ;
                    for (iX = 0; iX < Nx; iX++) {
                        floatGrid->floatVal[iX][iY] = floatMatrix[yIndex][iX] ;
                    }
                }

                freeMatrixOfType(thisFile->indexedData, 0, 0, 4) ;
                thisFile->indexedData = NULL ;
                
                /* Computing external DEM to float file transform */
                floatGrid->T = matrixDouble(0, 1, 0, 2) ;
                floatGrid->T[0][0] = externalDEM->dataFile->xSampling / thisFile->xSampling ;
                floatGrid->T[1][1] = externalDEM->dataFile->ySampling / thisFile->ySampling ;
                floatGrid->T[0][1] = floatGrid->T[1][0] =  0. ;
                floatGrid->T[0][2] = (externalDEM->dataFile->x0 - thisFile->x0) / thisFile->xSampling ;
                floatGrid->T[1][2] = (externalDEM->dataFile->y0 - thisFile->y0) / thisFile->ySampling ;
                
                /* Create float file to be projected */
                aPath = initStringWith2Strings(gP->files->input->directoryPath, "extractedFloatFile") ;
                extractedFloatFile = openRawFileForReadingAndWritingAtPath(aPath) ;
                extractedFloatFile->xDim = xDimIn ;
                extractedFloatFile->yDim = yDimIn ;
                free(aPath) ;

                aFloatLine = vectorFloat(0, xDimIn) ;
                for (iY = 0; iY < yDimIn; iY++) {
                    yP = (double)iY ;
                    for (iX = 0; iX < xDimIn; iX++) {
                        xP = (double)iX ;
                        aFloatLine[iX] = weightedExtrapolationOfGridForImageCoordinate(floatGrid, xP, yP) ;
                    }
                    fwrite(aFloatLine, sizeof(float), xDimIn, extractedFloatFile->f) ;
                }
                freeVectorFloat(aFloatLine, 0) ;
                fflush(extractedFloatFile->f) ;
                freeGridMap(floatGrid) ;

                /* Free existing input/output to reallocate them */
                freeRawFileDescriptor(gP->files->input) ;
                freeRawFileDescriptor(gP->files->output) ;
                gP->files->input = NULL ;
                gP->files->output = NULL ;

                /* The file to be projected is the extractedFloatFile */
                gP->files->input = extractedFloatFile ;

                /* We will project it under the name tempMask */
                aPath = initStringWith3Strings(outputDir, thisFileName, ".slantRange") ;
                if((gP->files->output = openRawFileForReadingAndWritingAtPath(aPath)) == NULL) {
                    ase("Failed to create slant range projected mask file\n") ;
                }
                free(aPath) ;

                gP->files->output->xDim = xDimOut ;
                gP->files->output->yDim = yDimOut ;
                gP->params->noVal = 0 ;

                /* Float file projection */
                printf("\n\n---> Projection of float file %s...\n", thisFilePath) ;
                sprintf(gP->params->resamplingMethod, "TRI") ;
                resamplingUsingSavedMapping(gP) ;

                /* We can now trash the extracted float file */
                unlink(gP->files->input->accessPath) ;

                /* And free what must be freed */
                free(thisFileName) ;
            }
            freeRawFileDescriptor(thisFile) ;
            free(thisFilePath) ;
        }
    }

    freeCSVStruct(filesList) ;
    free(outputDir) ;
}

void slantRangeGradientsProjection(geoProj *gP, externalDEMStruct *externalDEM)
{
       /* Free existing input/output to reallocate them */
        freeRawFileDescriptor(gP->files->input) ;
        freeRawFileDescriptor(gP->files->output) ;
        gP->files->input = NULL ;
        gP->files->output = NULL ;

}



void simulMod(geoProj *gP, satRef *sR)
{
    char *aPath ;
    size_t iX, iY ;
    float	*h, *mod ;
    double	azimuthPosition, rangePosition, rangeSampling, Dh, dhMin, dhMax, incidenceAngle ;
    rawFileDescriptor *simulatedAmplitude ;

    /* Create output file */
    aPath = initStringWith2Strings(gP->files->output->directoryPath, "simulatedAmplitude") ;
    simulatedAmplitude = openRawFileForWritingAtPath(aPath) ;

    /* Initialize local height vector */
    h = vectorFloat(0, gP->params->xDimM) ;

    /* Initialize simulated amplitude vector */
    mod = vectorFloat(0, gP->params->xDimM) ;

    /* Compute range sampling */
    rangeSampling = sR->params->info->rangeResolutionCell * gP->params->xSampling ;

    fseek(gP->files->output->f, SEEK_SET, 0) ;
    /* Loop on azimuth */
    for (iY = 0; iY < gP->params->yDimM; iY++) {

        /* Read heights */
        if((fread(h, sizeof(float), gP->params->xDimM, gP->files->output->f)) != gP->params->xDimM)
            ase("Failed to read local height values") ;

        /* Compute state vector at azimuth position */
        azimuthPosition = gP->frame->yMin + iY * gP->params->ySampling ;
        calcStateVect(sR->params->info->S, azimuthPosition, sR->params->info) ;

        /* Loop on range */
        for (iX = 0; iX < gP->params->xDimM - 1; iX++) {

            /* Compute local incidence angle on flat Earth */
            rangePosition = gP->frame->xMin + iX * gP->params->ySampling ;
            earthRadiusAtPoint(rangePosition, azimuthPosition, 0., sR->gR) ;
            incidenceAngle = sR->solving->alpha ;

            /* Compute local height variation */
            Dh = h[iX + 1] - h[iX] ;
            dhMin = -rangeSampling * cos(incidenceAngle) ; dhMax = rangeSampling / sin(incidenceAngle) ;
            Dh = (Dh < dhMin)? dhMin : (Dh > dhMax)? dhMax : Dh ;

            /* Compute simulated amplitude */
            mod[iX] = sqrt(pow(rangeSampling, 2.) + 2. * cos(incidenceAngle) * rangeSampling * Dh + pow(Dh, 2.)) / sin(incidenceAngle) ;
        }
        mod[iX] = mod[iX - 1] ;

        /* Save amplitudes */
        if((fwrite(mod, sizeof(float), gP->params->xDimM, simulatedAmplitude->f)) != gP->params->xDimM)
            ase("Failed to save simulated amplitude") ;
    }
    freeRawFileDescriptor(simulatedAmplitude) ;
}

void unlinkTemporaryFiles(geoProj *gP)
{
    char *aPath ;
/*
    aPath = initStringWithString(gP->files->input->accessPath) ;
    unlink(aPath) ;
    free(aPath) ;
*/
    aPath = initStringWithString(gP->files->xRef->accessPath) ;
    unlink(aPath) ;
    free(aPath) ;

    aPath = initStringWithString(gP->files->yRef->accessPath) ;
    unlink(aPath) ;
    free(aPath) ;

    aPath = initStringWithString(gP->files->M->accessPath) ;
    unlink(aPath) ;
    free(aPath) ;

    if (gP->files->xRadius) {
        aPath = initStringWithString(gP->files->xRadius->accessPath) ;
        unlink(aPath) ;
        free(aPath) ;
    }

    if (gP->files->yRadius) {
        aPath = initStringWithString(gP->files->yRadius->accessPath) ;
        unlink(aPath) ;
        free(aPath) ;
    }
}




/* This function updates the scene average height using a first intersection between scene and external DEM */
/* This particularly usefull when scene average height is not defined leading to a range shifted localization of given kml or aoi */
double updateSceneAverageHeight(CSLImage *masterImage, externalDEMStruct *externalDEM)
{
    size_t anIndex, N, M, iX, iY ;
    size_t iX0, iY0, iXMax, iYMax, xDim0, yDim0, xDim ;
    size_t dataTypeSize ;
    long seekval ;
    float *H, noVal; 
    double avg, sum ;
    double sceneAverageHeight = 0 ;
    void *externalDEMLine = NULL ;
    polygon *aoi ;
    SLCImageInfo *referenceInfoImage ;

    referenceInfoImage = readAndInitInfoImageInCSLImage(masterImage) ;
    genFloatNaN() ;

    /* Area of interest delineation */
    aoi = circumscribedRectangleOfPolygon(referenceInfoImage->loc) ;
    if(!polygonesIntersects(aoi, externalDEM->dataFile->aoi))
        ase("Nothing to project. External DEM have no intersection with targeted SAR image") ;

    for (anIndex = 0; anIndex < 4; anIndex++) {
        aoi->P[anIndex].x = floor((aoi->P[anIndex].x - externalDEM->dataFile->x0) / externalDEM->dataFile->xSampling) ;
        aoi->P[anIndex].y = floor((aoi->P[anIndex].y - externalDEM->dataFile->y0) / externalDEM->dataFile->ySampling) ;
    }

    iX0 = (aoi->P[0].x < 0)? 0 : (size_t)aoi->P[0].x ;
    iY0 = (aoi->P[0].y < 0)? 0 : (size_t)aoi->P[0].y ;
    iXMax = (aoi->P[2].x > externalDEM->dataFile->xDim)? externalDEM->dataFile->xDim - 1 : (size_t)aoi->P[2].x ;
    iYMax = (aoi->P[2].y > externalDEM->dataFile->yDim)? externalDEM->dataFile->yDim - 1 : (size_t)aoi->P[2].y ;

    /* External DEM dimensions */
    xDim0 = externalDEM->dataFile->xDim ;
    yDim0 = externalDEM->dataFile->yDim ;
    xDim = iXMax - iX0 + 1 ;
    dataTypeSize = externalDEM->dataFile->typeSize ;

    H = vectorFloat(iX0, iXMax) ;
    noVal = *((float *)(externalDEM->dataFile->excludingValue)) ;

    /* Initialize positionning into external DEM data file */
    seekval = (externalDEM->flag & _FLIP_DEM_)? (long)((yDim0 - 1 - iY0) * xDim0 + iX0) * dataTypeSize : (long)(iY0 * xDim0 + iX0) * sizeof(float) ;
    if(fseek(externalDEM->dataFile->f, seekval, SEEK_SET) == -1)
        ase("Failed to seek into external DEM file") ;
    seekval = (externalDEM->flag & _FLIP_DEM_)? (-xDim0 - xDim) * dataTypeSize : (xDim0 - xDim) * sizeof(float) ;

    /* Allocating line of external DEM if required */
    if (dataTypeSize != sizeof(float) || externalDEM->dataFile->byteOrder != isArchBigEndian()) {
        externalDEMLine = vectorOfType(0, xDim - 1, dataTypeSize) ;
    }

    avg = 0 ;
    M = 0 ;
    for (iY = iY0; iY <= iYMax; iY++) {
        /* Read line of local heights line */
        if (dataTypeSize != sizeof(float) || externalDEM->dataFile->byteOrder != isArchBigEndian()) {
            if (xDim != fread(externalDEMLine, dataTypeSize, xDim, externalDEM->dataFile->f)) {
                ase("Failed to read into external DEM file") ;
            }
            for (iX = 0; iX < xDim; iX++) {
                if (externalDEM->dataFile->byteOrder != isArchBigEndian()) {
                    swapByteStructOfType(externalDEMLine + iX * dataTypeSize, dataTypeSize) ;
                }
                if (dataTypeSize == 2) {
                    H[iX0 + iX] = (float)(*(short *)((externalDEMLine + iX * dataTypeSize))) ;
                }
                else {
                    H[iX0 + iX] = (*(float *)((externalDEMLine + iX * dataTypeSize))) ;
                }
            }
        }
        else {
            if (xDim != fread(&H[iX0], sizeof(float), xDim, externalDEM->dataFile->f)) {
                ase("Failed to read into external DEM file") ;
            }
        }
        sum = 0 ;
        N = 0 ;
        for (iX = iX0; iX <= iXMax; iX++) {
            if (!areFloatValsEquals(H[iX], noVal) && !areFloatValsEquals(H[iX], floatNaN)) {
                sum += H[iX] ;
                N++ ;
            }
        }
        if (N) {
            avg += sum / N ;
            M ++ ;
        }
        

        /* Update positionning into DEM file */
        fseek(externalDEM->dataFile->f, seekval, SEEK_CUR) ;
    }
    sceneAverageHeight = avg / M ;
    freeInfoImage(referenceInfoImage) ;

    return(sceneAverageHeight) ;
}

/* Simply returns the full path to the external geoprojected data file (DEM, model or mask) taking environment variable into account */
/* Input can be the full path itself or simply the name of the external file provided the requested environment variable is defined */
/* Detection of requested file is simply performed base on the existence of a .hdr or a .txt associated file */
/* Returns NULL if not found */
char *getGeoreferencedDataFilePath(char *filePath)
{
    char *aPath = NULL ;

    /* Test if filePath is the full file path to the requested file */
    if (!fileExistsAtPath(filePath)) {
        aPath = initStringWith2Strings("${EXTERNAL_MASKS_DIR}/", getPointerToFileNameInPath(filePath)) ;
        if (!fileExistsAtPath(aPath)) {
            free(aPath) ;
            aPath = initStringWith2Strings("${EXTERNAL_DEMS_DIR}/", getPointerToFileNameInPath(filePath)) ;
            if (!fileExistsAtPath(aPath)) {
                free(aPath) ;
                aPath = initStringWith2Strings("${EXTERNAL_MODELS_DIR}/", getPointerToFileNameInPath(filePath)) ;
                if (!fileExistsAtPath(aPath)) {
                    free(aPath) ;
                    aPath = NULL ;
                }
            }
        }
    }
    else {
        aPath = initStringWithString(filePath) ;
    }
    
    if (!correspondingFileWithExtensionExists(aPath, "txt") && !correspondingFileWithExtensionExists(aPath, "hdr")) {
        if (aPath) {
            free(aPath) ;
            aPath = NULL ;
       }                
    }
    

    return(aPath) ;
}


/* Open georeferenced data file. Data itself is not read */
/* Georeferenced data files are either float (DEM, models) or byte files (masks) */
rawFileDescriptor *getGeoreferencedDataFile(char *aPath)
{
    char *aString, *hdrFilePath ;
    rawFileDescriptor *dataFile ;
    keyValue *header = NULL ;

    if ((dataFile = openRawFileForReadingAtPath(aPath))) {
        hdrFilePath = getENVIHeaderPathOfFile(dataFile->accessPath) ;
        if (hdrFilePath) {
            header = readENVIHeader(hdrFilePath) ;

            dataFile->xDim = getIntValForKeyIn(header, "samples") ;
            dataFile->yDim = getIntValForKeyIn(header, "lines") ;

            dataFile->x0 = PI/180. * getDoubleValForKeyIn(header, "Lower left pixel X coordinate") ;
            dataFile->y0 = PI/180. * getDoubleValForKeyIn(header, "Lower left pixel Y coordinate") ;
            dataFile->xSampling = PI/180. * getDoubleValForKeyIn(header, "X sampling") ;
            dataFile->ySampling = PI/180. * getDoubleValForKeyIn(header, "Y sampling") ;
            dataFile->typeSize = getIntValForKeyIn(header, "data type") ;
            dataFile->byteOrder = getIntValForKeyIn(header, "byte order") ;
            dataFile->flag |= _FLIP_DATA_ ;

            aString = getStringValForKeyIn(header, "data ignore value") ;
        }
        else {
            free(hdrFilePath) ;
            hdrFilePath = initStringWith2Strings(dataFile->accessPath, ".txt") ;
            if (hdrFilePath) {
                header = readParameterFileAtPath(hdrFilePath) ;
                    
                dataFile->xDim = getIntValForKeyIn(header, "X (longitude) dimension") ;
                dataFile->yDim = getIntValForKeyIn(header, "Y (latitude) dimension") ;

                dataFile->x0 = PI/180. * getDoubleValForKeyIn(header, "Lower left corner longitude") ;
                dataFile->y0 = PI/180. * getDoubleValForKeyIn(header, "Lower left corner latitude") ;
                dataFile->xSampling = PI/180. * getDoubleValForKeyIn(header, "Longitude sampling") ;
                dataFile->ySampling = PI/180. * getDoubleValForKeyIn(header, "Latitude sampling") ;
                dataFile->typeSize = (dataFile->fileLength == dataFile->xDim * dataFile->yDim)? 1 : 4 ;
                dataFile->byteOrder = isArchBigEndian() ;
                aString = getStringValForKeyIn(header, "Excluding value") ;
            }
        }

        if (aString) {
            if (!strncmp(aString, "NaN", 3) || !strncmp(aString, "NAN", 3) || !strncmp(aString, "nan", 3)) {
                dataFile->excludingValue = malloc(sizeof(float)) ;
                *((float *)(dataFile->excludingValue)) = genFloatNaN() ;
            }
            else {
                switch (dataFile->typeSize) {
                    case 1:
                        dataFile->excludingValue = malloc(1) ;
                        sscanf(aString, "%hhd ", (char signed *)dataFile->excludingValue) ;
                        break;
                    
                    case 2:
                        dataFile->excludingValue = malloc(2) ;
                        sscanf(aString, "%hd ", (short signed *)dataFile->excludingValue) ;
                        break;

                    case 3:
                        dataFile->excludingValue = malloc(sizeof(int)) ;
                        sscanf(aString, "%d ", (int signed *)dataFile->excludingValue) ;
                        break;

                    case 4:
                        dataFile->excludingValue = malloc(sizeof(float)) ;
                        sscanf(aString, "%f ", (float *)dataFile->excludingValue) ;
                        break;

                    default:
                        break;
                }
            }
        }
        else {
            /* If we deal with a float file, its default excluding value is nan */
            if (dataFile->typeSize == 4) {
                dataFile->excludingValue = malloc(sizeof(float)) ;
                *((float *)(dataFile->excludingValue)) = genFloatNaN() ;
            }
        }
    
        dataFile->typeSize = (dataFile->typeSize == 3)? 4 : dataFile->typeSize ;

        dataFile->aoi = allocQuadrilateral() ;
        dataFile->aoi->P[0].x = dataFile->aoi->P[3].x = dataFile->x0 ;
        dataFile->aoi->P[0].y = dataFile->aoi->P[1].y = dataFile->y0 ;
        dataFile->aoi->P[1].x = dataFile->aoi->P[2].x = dataFile->x0 + (dataFile->xDim - 1) * dataFile->xSampling ;
        dataFile->aoi->P[2].y = dataFile->aoi->P[3].y = dataFile->y0 + (dataFile->yDim - 1) * dataFile->ySampling ;

        free(hdrFilePath) ;
        freeKeyValueList(header) ;
    }

    return (dataFile) ;
}

