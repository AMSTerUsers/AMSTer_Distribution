
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  InSARGeoProjection.c
 *  geoProjection
 *
 *  Created by Dominique Derauw on 22/11/11.
 *  Copyright 2011 Dominique Derauw. All rights reserved.
 *
 */

#include "InSARGeoProjectionLib.h"


/* main programm start */
int geoProjectionMain(CSVStruct *csv_CL)
{
	char *geoProjParamsPath = NULL, geoProjParametersFileFound, *aPath ;
	int	currentDirectoryFdesc, i, j ;
    int unsigned anInt ;
    int ETADFlags ;
    div_t qr ;
	InSARParametersStruct *pInSAR ;
	geoRef *pGeoRef ;
	geoProj	*pGeoProj ;
	keyValue *geoProjParams ;
	time_t startTime, endTime ;

	geoProjParametersFileFound = 0 ;
	currentDirectoryFdesc = open(".", O_RDONLY) ;
	fchdir(currentDirectoryFdesc) ;

	if(isArgumentPresentInCSV(csv_CL, "help") || isFlagPresentInCSV(csv_CL, "h"))
	   geoProjectionHelp() ;

	i = 1 ;
	while (i < csv_CL->numberOfEntries) {
		geoProjParamsPath = initStringWithString(csv_CL->stringVal[i]) ;
		if(fileExistsAtPath(geoProjParamsPath)) {
			geoProjParametersFileFound = 1 ;
			break ;
		}
		i++ ;
		free(geoProjParamsPath) ;
	}
	if(!geoProjParametersFileFound) {
		geoProjParamsPath = initStringWithString("./TextFiles/geoProjectionParameters.txt") ;
		if(!fileExistsAtPath(geoProjParamsPath)) {
			free(geoProjParamsPath) ;
			geoProjParamsPath = initStringWithString("./geoProjectionParameters.txt") ;
			if(!fileExistsAtPath(geoProjParamsPath)) {
			    free(geoProjParamsPath) ;
				geoProjectionHelp() ;
            }
		}
		geoProjParametersFileFound = 1 ;
	}
	time(&startTime) ;

    printf("\n---> Starting geoProjection process\n") ;
	/* Read the geoprojection parameters file */
	geoProjParams = readParameterFileAtPath(geoProjParamsPath) ;
    if (!geoProjParams) {
        printf("\t-/-> Failed to read geoProjectionParameters at path %s\n", geoProjParamsPath) ;
        ase("\n") ;
    }
    printf("\t---> geoProjection parameters read\n") ;
    

	/* Read InSAR parameters file */
    aPath = getStringValForKeyIn(geoProjParams, "InSAR parameters file") ;
	pInSAR = readInSARParametersFileAtPath(aPath) ;
    if (!pInSAR) {
        printf("\t-/-> Failed to read geoProjectionParameters at path %s\n", aPath) ;
        ase("\n") ;
    }
    printf("\t---> InSAR parameters read\n") ;
    pInSAR->flag |= (isFlagPresentInCSV(csv_CL, "e"))? _EXTERNAL_DEM_REPROJECTION_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv_CL, "f"))? _FILL_HOLES_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv_CL, "g"))? _ON_GEOID_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv_CL, "n"))? _NEAREST_NEIGHBOR_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv_CL, "p"))? _POLINSAR_PRODUCTS_PROJECTION_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv_CL, "k"))? pInSAR->flag : _COPY_SM2M_PROCESSING_PARAMETERS_ ;
    pInSAR->flag |= (isFlagPresentInCSV(csv_CL, "s"))? _SAVE_MAPPING_ : pInSAR->flag ;

    if (isFlagPresentInCSV(csv_CL, "r")) {
        pInSAR->flag |= _FLIP_  ;
        pInSAR->flag |= (isArgumentPresentInCSV(csv_CL, "-ESRI"))? _ESRI_HEADER_ : pInSAR->flag ;
    }
    pInSAR->flag |= (isFlagPresentInCSV(csv_CL, "C"))? _CLEAN_PROJECTION_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv_CL, "i"))? _USE_INSAR_KML_ : pInSAR->flag ;

    /* ETAD layers loading if dealing with S1 */
    i = isArgumentPresentInCSV(csv_CL, "-ETAD") ;
    if (i && pInSAR->masterInfo->sensorID == __SENTINEL1__) {
        if (isETADPresentInCSLImage(pInSAR->masterImage)) {
            j = 0 ;
            sscanf(csv_CL->stringVal[i], "-ETAD%d", &j) ;
            if (strlen(csv_CL->stringVal[i]) > 5) {   
                qr = div(j, 10) ;
                ETADFlags = (qr.rem)? _ETAD_FM_MISMATCH_CORRECTION_AZ_ : 0 ;
                qr = div(qr.quot, 10) ;
                ETADFlags |= (qr.rem)? _ETAD_DOPPLER_RANGE_SHIFT_RG_ : 0 ;
                qr = div(qr.quot, 10) ;
                ETADFlags |= (qr.rem)? _ETAD_BISTATIC_CORRECTION_AZ_ : 0 ;
                qr = div(qr.quot, 10) ;
                ETADFlags |= (qr.rem)? _ETAD_GEODETIC_CORRECTION_AZ_ : 0 ;
                qr = div(qr.quot, 10) ;
                ETADFlags |= (qr.rem)? _ETAD_GEODETIC_CORRECTION_RG_ : 0 ;
                qr = div(qr.quot, 10) ;
                ETADFlags |= (qr.rem)? _ETAD_IONOSPHERIC_CORRECTION_RG_ : 0 ;
                qr = div(qr.quot, 10) ;
                ETADFlags |= (qr.rem)? _ETAD_TROPOSPHERIC_CORRECTION_RG_ : 0 ;
            }
            else {
                ETADFlags = _ETAD_SUM_OF_CORRECTIONS_RG_ | _ETAD_SUM_OF_CORRECTIONS_AZ_ ;
            }

            printf("\t---> Loading requested ETAD layers\n") ;
            free(pInSAR->masterInfo) ;
            pInSAR->masterInfo = mergeFrameInfo(pInSAR->masterImage, NULL) ;
           
            loadETADLayersIntoBursts(pInSAR->masterInfo, ETADFlags) ;
            pInSAR->flag |= (ETADFlags)? _ETAD_CORRECTION_ : 0 ;
            printf("\n") ;
        }
    }
    

    printf("\nGeo-projection of InSAR products\n") ;
    /* In case of projection on geoid, one can force geoprojection on an inflated geoid up to a given average height */
    if ((i = isArgumentPresentInCSV(csv_CL, "-g="))) {
        sscanf(csv_CL->stringVal[i] + 3, "%lf", &pInSAR->masterInfo->sceneAverageHeight) ;
        pInSAR->flag |= _ON_GEOID_ ;
    }
    if (pInSAR->flag & _ON_GEOID_) {
        printf("Geoprojection will be performed on an inflated ellipsoid up to an average height of %lf [m]\n", pInSAR->masterInfo->sceneAverageHeight) ;
    }

    /* First, we initializa the geoReferencing structure on the chosen ellipsoid */
    printf("\t---> Initializing georeferencing\n") ;
    pGeoRef = initGeoRefStructure(geoProjParams, pInSAR) ;
    if ((i = isArgumentPresentInCSV(csv_CL, "-f="))) {
        sscanf(csv_CL->stringVal[i] + 3, "%f", &pGeoRef->params->holeFillingFactor) ;
        anInt = _FILL_HOLES_ ;
        pInSAR->flag &= ~anInt ;
    }

	/* Alloc and initialize a geoProj structure with read parameters */
    /* Open/create reference and mapping files in the chosen geoProjection directory*/
    printf("\t---> Initializing geoprojection\n") ;
	pGeoProj = initGeoProjStructure(geoProjParams, pInSAR) ;

	/* Georeferencing files are common to geoProj and geoRef structures */
    pGeoRef->files->xRef = pGeoProj->files->xRef ;
    pGeoRef->files->yRef = pGeoProj->files->yRef ;
    pGeoRef->files->xRadius = pGeoProj->files->xRadius ;
    pGeoRef->files->yRadius = pGeoProj->files->yRadius ;

	/* Excluding values and masks are common to both processes */
    /* Excluding value used for external slant range DEM projection prevails */
	pGeoRef->params->DEMExcludingValue = pGeoProj->params->DEMExcludingValue = pInSAR->DEMExcludingValue ;
	pGeoRef->params->maxVal = pGeoProj->params->maxVal ;
	pGeoRef->params->minVal = pGeoProj->params->minVal ;
	pGeoRef->params->withMasking = pGeoProj->params->withMasking ;
	pGeoRef->files->mask = pGeoProj->files->mask ;


	/* Now we perform the georeferencing */
    if (!pGeoProj->files->M->fileLength) {
        geoReferenceDEM(pGeoRef, pInSAR->flag) ;
    }
    else {
        printf("\t---> Geo-referencing apparently already done\n") ;
    }

	/* DEM used for georeferencing will be used for geoprojection */
	pGeoProj->files->DEM = pGeoRef->files->DEM ;
	pGeoProj->params->isDEMPresent = !(pInSAR->flag & _ON_GEOID_) ;

	/* If projection frame is not given, we have to recompute it from the DEM */
	if((pGeoProj->frame->xMax == 0.) && (pGeoProj->frame->xMin == 0.) && (pGeoProj->frame->yMax == 0.) && (pGeoProj->frame->yMin == 0.)) {
		/* But we do it only if georeferencing was not already performed */
		if((pGeoRef->frame->xMax == 0.) && (pGeoRef->frame->xMin == 0.) && (pGeoRef->frame->yMax == 0.) && (pGeoRef->frame->yMin == 0.)) {
			computeFrameFromGeoRef(pGeoRef) ;
		}
		memcpy(pGeoProj->frame, pGeoRef->frame, sizeof(geoRefFrame)) ;
		roundGeoProjFrame(pGeoProj) ;
	}
	else {
		/* We consider that the read frame is the one to consider */
		roundGeoProjFrame(pGeoProj) ;
	}

    updateGeoProjectionParametersFile(pGeoProj, geoProjParams) ;
    writeParameterFileAtPath(geoProjParams, geoProjParamsPath) ;
    saveInSARParametersFileAtPath(pInSAR, getStringValForKeyIn(geoProjParams, "InSAR parameters file")) ;
    
    /* Georeference required products */
    if (pInSAR->flag & _POLINSAR_PRODUCTS_PROJECTION_) {
        geoProjectPolInSARProducts(pInSAR, pGeoProj, geoProjParams) ;
    }
    else {
        geoProjectInSARProducts(pInSAR, pGeoProj, geoProjParams) ;
    }

    unlink(pGeoRef->files->xRadius->accessPath) ;
    unlink(pGeoRef->files->yRadius->accessPath) ;
    unlink(pGeoRef->files->xRef->accessPath) ;
    unlink(pGeoRef->files->yRef->accessPath) ;
    
    closeRawFile(pGeoProj->files->M) ;
    unlink(pGeoProj->files->M->accessPath) ;
	pGeoProj->files->DEM = NULL ;
    pGeoProj->files->xRef = NULL ;
    pGeoProj->files->yRef = NULL ;
    pGeoProj->files->xRadius = NULL ;
    pGeoProj->files->yRadius = NULL ;
    pGeoProj->files->mask = NULL ;
	freeGeoProj(pGeoProj) ;

    freeKeyValueList(geoProjParams) ;
    free(geoProjParamsPath) ;
    freeInSARParametersStruct(pInSAR) ;
    

	time(&endTime) ;
	duration(startTime, endTime) ;
	return(0) ;
}


void geoProjectionHelp()
{
	printf("Usage:\ngeoProjection [-erfnpk] [-f=fillingFactor] [/pathTo/geoProjectionParameters.txt] \n\n") ;

    printf("\t-e : External slant range DEM will also be reprojected.\n") ;
    printf("\t-C : Clean geoProjection: If previous geoProjection took place, existing mapping is recomputed and area of interest is reset.\n") ;
    printf("\t-i : If present, the kml used for limiting InSAR processing will be used to determine the geoProjection area of interest\n") ;
    printf("\t-r : Projected data will be flipped vertically and an ENVI header will be created\n") ;
    printf("\t     If willing an ESRI header, add option -E. \n") ;
    printf("\t-f : Force to fill holes as much as possible. This may introduce some unwanted distortions.\n") ;
    printf("\t-f=x : Allows forcing a hole filling factor, where x is a float. \n\tRadii will be computed as x times the distance to the nearest neighbor.\n") ;
    printf("\t-n : Force to compute radius up to nearest neighbor. Speed up the processing while leaving more holes.\n") ;
    printf("\t-p : If presents, all PolInSAR products will be projected. This option prevent classical InSAR products to be projected\n") ;
    printf("\t-k : By default, if InSAR processing was performed with respect to a global master, \n\tparameters used for global master geoprojection will be used. \n\tIf using option -k option, user-defined parameters are kept unchanged\n\n") ;
    printf("\t-ETAD: If dealing with Sentinel1 data and if ETAD data is present within the master, geo-referencing will take ETAD required layers into account.\n") ;    
    printf("\t-ETADiiiiiii: If willing to select used layers, use binary notation with iiiiiii = \n") ;   
    printf("\t\t   _ETAD_TROPOSPHERIC_CORRECTION_RG_\n") ;
    printf("\t\t | _ETAD_IONOSPHERIC_CORRECTION_RG_\n") ;
    printf("\t\t | _ETAD_GEODETIC_CORRECTION_RG_\n") ;
    printf("\t\t | _ETAD_GEODETIC_CORRECTION_AZ_\n") ;
    printf("\t\t | _ETAD_BISTATIC_CORRECTION_AZ_\n") ;
    printf("\t\t | _ETAD_DOPPLER_RANGE_SHIFT_RG_\n") ;
    printf("\t\t | _ETAD_DOPPLER_RANGE_SHIFT_AZ_\n") ;
    printf("\t eg -ETAD1110010 for range corrections only.\n\n") ; 
    printf("If used with no parameters, the routine will look for \na geoProjectionParameters.txt file within the working directory\nor within the ./TextFiles subdirectory\n") ;
	printf("Any other path to a text file containing geoProjection parameters can be given as first parameter\n") ;
	printf("The routine will perform the geoProjection of all InSAR products\n") ;
    printf("Remark:  By default, if geoProjection is performed using a reference DEM associated to global master image,\nit will be the geoprojection parameters used for the global master - master pair that will be used.\n") ;
    printf("To prevent this, use the -k option to force using the given geoProjection parameters file\n") ;
	exit(0) ;
}


void geoProjectPolInSARProducts(InSARParametersStruct *pInSAR, geoProj *pGeoProj, keyValue *geoProjParams)
{
    char *InSARProductsDir ;
    struct lmp *table ;
    CSVStruct *filePath ;

    /* First, verify if mapping already exists */
    if (pGeoProj->files->M->fileLength) {
        /* If yes, it means that the DEM was already geoproject */
        printf("\nExisting mapping will be used:\n\t--> %s\n", pGeoProj->files->M->accessPath) ;
    }
    else {
        /* If not, generate and save the required mapping */
        findInterveningPoints(pGeoProj) ;
        table = allocProjectionTable(pGeoProj) ;
        weightCalculation(table, pGeoProj) ;
        saveProjectionTable(table, pGeoProj) ;

        /* Free what must be freed */
        freeRawFileDescriptor(pGeoProj->files->input) ;
        freeProjectionTable(table) ;
    }

    InSARProductsDir = initStringWith2Strings(pInSAR->whereAmI, "InSARProducts") ;
    /* Project amplitude files */
    if (!strncmp(getStringValForKeyIn(geoProjParams, "Geoproject master amplitude"), "YES", 3) || !strncmp(getStringValForKeyIn(geoProjParams, "Geoproject slave amplitude"), "YES", 3)) {
        if((filePath = recursiveSearchOfFilesWithExtensionInDir("mod", InSARProductsDir))) {
            projectPolarimetricFileSeries(filePath, pInSAR, pGeoProj) ;
            freeCSVStruct(filePath) ;
        }
    }

    /* Project Alpha files */
    if((filePath = recursiveSearchOfFileInDir("Alpha", InSARProductsDir))) {
        projectPolarimetricFileSeries(filePath, pInSAR, pGeoProj) ;
        freeCSVStruct(filePath) ;
    }

    /* Project Entropy files */
    if((filePath = recursiveSearchOfFileInDir("Entropy", InSARProductsDir))) {
        projectPolarimetricFileSeries(filePath, pInSAR, pGeoProj) ;
        freeCSVStruct(filePath) ;
    }

    /* Project Anisotropy files */
        if((filePath = recursiveSearchOfFileInDir("Anisotropy", InSARProductsDir))) {
    projectPolarimetricFileSeries(filePath, pInSAR, pGeoProj) ;
        freeCSVStruct(filePath) ;
    }

    /* Project optimizedCoherence files */
    if (!strncmp(getStringValForKeyIn(geoProjParams, "Geoproject coherence"), "YES", 3)) {
        if((filePath = recursiveSearchOfFileInDir("optimizedCoherence", InSARProductsDir))) {
            projectPolarimetricFileSeries(filePath, pInSAR, pGeoProj) ;
            freeCSVStruct(filePath) ;
        }
    }

    /* Project optimizedInterferogram files */
    if (!strncmp(getStringValForKeyIn(geoProjParams, "Geoproject interferogram"), "YES", 3)) {
        if((filePath = recursiveSearchOfFileInDir("optimizedInterferogram", InSARProductsDir))) {
            projectPolarimetricFileSeries(filePath, pInSAR, pGeoProj) ;
            freeCSVStruct(filePath) ;
        }
    }

    free(InSARProductsDir) ;
}

void projectPolarimetricFileSeries(CSVStruct *filePath, InSARParametersStruct *pInSAR, geoProj *pGeoProj)
{
    char *geoProjDir, *outputFilePath, *genericExtension, *newFilePath ;
    int i ;

    /* Get output files directory and generic extension */
    geoProjDir = pGeoProj->files->geoProjDir ;
    genericExtension = pGeoProj->files->genericExtension ;

    for (i = 0; i < filePath->numberOfEntries; i++) {
        if((pGeoProj->files->input = openRawFileForReadingAtPath(filePath->stringVal[i])) == NULL)
            ase("Failed to open input file\n") ;
        pGeoProj->files->input->xDim = (pInSAR->interf).lenr ;
        pGeoProj->files->input->yDim = (pInSAR->interf).lena ;

        /* Create output file stream */
        outputFilePath = initStringWith3Strings(geoProjDir, getFileNameFromPath(filePath->stringVal[i]), genericExtension) ;
        if((pGeoProj->files->output = openRawFileForReadingAndWritingAtPath(outputFilePath)) == NULL)
            ase("Failed to create projected file\n") ;

        /* Master amplitude geoprojection */
        printf("\nImage projection: %s\n", getPointerToFileNameInPath(filePath->stringVal[i]));
        resamplingUsingSavedMapping(pGeoProj) ;

        if (pInSAR->flag & _FLIP_) {
            verticalFlipOfDataOfTypeAtPath(outputFilePath, pGeoProj->params->xDimM, pGeoProj->params->yDimM, _IN_PLACE_) ;
            if (pInSAR->flag & _ESRI_HEADER_) {
                generateESRIHeaderForGeoProjectedProductAtPath(outputFilePath, pGeoProj) ;
            }
            else {
                generateENVIHeaderForGeoProjectedProductAtPath(outputFilePath, pInSAR->geo, pGeoProj, pInSAR) ;
            }
            newFilePath = initStringWith2Strings(outputFilePath, ".bil") ;
            rename(outputFilePath, newFilePath) ;
            free(newFilePath) ;
        }

        /* Free what must be freed */
        free(outputFilePath) ;
        freeRawFileDescriptor(pGeoProj->files->input) ;
        freeRawFileDescriptor(pGeoProj->files->output) ;
        pGeoProj->files->input = NULL ;
        pGeoProj->files->output = NULL ;
    }
}

void geoProjectInSARProducts(InSARParametersStruct *pInSAR, geoProj *pGeoProj, keyValue *geoProjParams)
{
    char *geoProjDir, *genericExtension, *aDir, *aFilePath ;
    char *InSARProductsDir ;
    char *aKey, *aValue ;
    int i ;
	struct lmp *table ;
    CSVStruct *fileList ;

    /* Get output files directory and generic extension */
    geoProjDir = pGeoProj->files->geoProjDir ;
    genericExtension = pGeoProj->files->genericExtension ;
    InSARProductsDir = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts") ;

	/* First, verify if mapping already exists */
    if (pGeoProj->files->M->fileLength) {
        /* If yes, it means that the DEM was already geoproject */
        printf("\nExisting mapping will be used:\n\t--> %s\n", pGeoProj->files->M->accessPath) ;
    }
    else {
        /* If not, generate and save the required mapping */
        printf("\n\t---> Geoprojection mapping generation\n") ;
        findInterveningPoints(pGeoProj) ;
        table = allocProjectionTable(pGeoProj) ;
        weightCalculation(table, pGeoProj) ;
        saveProjectionTable(table, pGeoProj) ;

        /* Free what must be freed */
        freeProjectionTable(table) ;
    }

    /* Measurement Projection */
    aKey = initStringWithString("Geoproject measurement") ;
    if ((aValue = getStringValForKeyIn(geoProjParams, aKey))) {
        if (!strncmp(aValue, "YES", 3)) {
            /* Open input file */
            if (!fileExistsAtPath((pInSAR->srDEM).filePath)) {
                printf("\nMeasurement geoprojection cancelled (missing file)\n") ;
            }
            else {
                if((pGeoProj->files->input = openRawFileForReadingAtPath((pInSAR->srDEM).filePath)) == NULL)
                    ase("Failed to open measurement file\n") ;
                pGeoProj->files->input->xDim = (pInSAR->srDEM).lenr ;
                pGeoProj->files->input->yDim = (pInSAR->srDEM).lena ;
                
                /* Measurement geoprojection */
                printf("\nMeasurement projection:\n");
                geoProjectInputProduct(pInSAR, geoProjDir, pGeoProj, genericExtension) ;
                freeRawFileDescriptor(pGeoProj->files->input) ;
                pGeoProj->files->input = NULL ;
            }
            free(aKey) ;
        }
    }

    if(pInSAR->flag & _EXTERNAL_DEM_REPROJECTION_) {
        nonMaskedMappingComputation(pGeoProj) ;
        /* Open input file */
        if (!fileExistsAtPath(pInSAR->externalSlantRangeDEMFile->accessPath)) {
            printf("\nExternal slant range DEM re-projection cancelled (missing file)\n") ;
        }
        else {
            if((pGeoProj->files->input = openRawFileForReadingAtPath(pInSAR->externalSlantRangeDEMFile->accessPath)) == NULL)
                ase("Failed to open external slant range DEM file\n") ;
            pGeoProj->files->input->xDim = pInSAR->externalSlantRangeDEMFile->xDim ;
            pGeoProj->files->input->yDim = pInSAR->externalSlantRangeDEMFile->yDim ;

            /* Master amplitude geoprojection */
            printf("\nExternal slant range DEM re-projection:\n");
            geoProjectInputProduct(pInSAR, geoProjDir, pGeoProj, genericExtension) ;
            freeRawFileDescriptor(pGeoProj->files->input) ;
            pGeoProj->files->input = NULL ;
        }
    }

    /* Master amplitude geoprojection */
    if ((aValue = getStringValForKeyIn(geoProjParams, "Geoproject master amplitude"))) {
        if (!strncmp(aValue, "YES", 3)) {
            nonMaskedMappingComputation(pGeoProj) ;
            /* Open input file */
            if (!fileExistsAtPath((pInSAR->mod1).filePath)) {
                printf("\nMaster amplitude geoprojection cancelled (missing file)\n") ;
            }
            else {
                if((pGeoProj->files->input = openRawFileForReadingAtPath((pInSAR->mod1).filePath)) == NULL) {
                    ase("Failed to open slant range master amplitude file\n") ;
                }
                pGeoProj->files->input->xDim = (pInSAR->mod1).lenr ;
                pGeoProj->files->input->yDim = (pInSAR->mod1).lena ;

                /* Master amplitude geoprojection */
                printf("\nMaster amplitude image projection:\n");
                geoProjectInputProduct(pInSAR, geoProjDir, pGeoProj, genericExtension) ;
                freeRawFileDescriptor(pGeoProj->files->input) ;
                pGeoProj->files->input = NULL ;
            }
        }
    }

    /* Slave amplitude geoprojection */
    if ((aValue = getStringValForKeyIn(geoProjParams, "Geoproject slave amplitude"))) {
        if (!strncmp(aValue, "YES", 3)) {
            nonMaskedMappingComputation(pGeoProj) ;
            /* Open input file */
            if (!fileExistsAtPath((pInSAR->mod2).filePath) || !pInSAR->mod2.lena || !pInSAR->mod2.lenr) {
                printf("\nSlave amplitude geoprojection cancelled (missing file)\n") ;
            }
            else {
                if((pGeoProj->files->input = openRawFileForReadingAtPath((pInSAR->mod2).filePath)) == NULL)
                    ase("Failed to open slant range slave amplitude file\n") ;
                pGeoProj->files->input->xDim = (pInSAR->mod2).lenr ;
                pGeoProj->files->input->yDim = (pInSAR->mod2).lena ;

                /* Slave amplitude geoprojection */
                printf("\nSlave amplitude image projection:\n");
                geoProjectInputProduct(pInSAR, geoProjDir, pGeoProj, genericExtension) ;
                freeRawFileDescriptor(pGeoProj->files->input) ;
                pGeoProj->files->input = NULL ;
            }
        }
    }

    /* Coherence geoprojection */
    if ((aValue = getStringValForKeyIn(geoProjParams, "Geoproject coherence"))) {
        if (!strncmp(aValue, "YES", 3)) {
            nonMaskedMappingComputation(pGeoProj) ;
            printf("\nCoherence projection:\n");
            /* Open input file */
            aFilePath = initStringWithString((pInSAR->coh).filePath) ;
            if (!fileExistsAtPath(aFilePath)) {
                printf("\t-/-> Requested coherence file not found: %s\n", aFilePath) ;
                printf("\t---> Looking for files with generic name \"coherence\"\n") ;
                free(aFilePath) ;
                aFilePath = initStringWithString("coherence") ;
                if (! isFilePresentInSubDir("coherence", pInSAR->whereAmI)) {
                    free(aFilePath) ;
                    aFilePath = NULL ;
                    printf("\n\t-/-> Coherence geoprojection cancelled (missing file)\n") ;
                }
            }
            if(aFilePath) {
                pGeoProj->files->input = allocFileDescriptor() ;
                pGeoProj->files->input->directoryPath = getDirectoryPathFromPath((pInSAR->coh).filePath) ;
                pGeoProj->files->input->fileName = getFileNameFromPath(aFilePath) ;
                pGeoProj->files->input->xDim = (pInSAR->coh).lenr ;
                pGeoProj->files->input->yDim = (pInSAR->coh).lena ;
                pGeoProj->files->input->fileLength = (pInSAR->coh).lenr * (pInSAR->coh).lena * sizeof(float) ;

                /* Coherence amplitude geoprojection */
                geoProjectInputProduct(pInSAR, geoProjDir, pGeoProj, genericExtension) ;
                closeRawFile(pGeoProj->files->input) ;

                /* masked coherence geoprojection if present*/
                aDir = getDirectoryPathFromPath((pInSAR->coh).filePath) ;
                aFilePath = initStringWith2Strings(aDir, "/maskedCoherence") ;
                free(aDir) ;
                if(fileExistsAtPath(aFilePath)) {
                    setRawFilePath(pGeoProj->files->input, aFilePath) ;
                    openRawFileForReading(pGeoProj->files->input) ;
                    printf("\nMasked coherence projection:\n");
                    geoProjectInputProduct(pInSAR, geoProjDir, pGeoProj, genericExtension) ;
                }
                freeRawFileDescriptor(pGeoProj->files->input) ;
                pGeoProj->files->input = NULL ;
            }
            free(aFilePath) ;
        }
    }


    /* Interferogram geoprojection */
    if ((aValue = getStringValForKeyIn(geoProjParams, "Geoproject interferogram"))) {
        if (!strncmp(aValue, "YES", 3)) {
            nonMaskedMappingComputation(pGeoProj) ;
            printf("\nInterferogram projection:\n");
            /* Open input file */
            aFilePath = initStringWithString((pInSAR->interf).filePath) ;
            if (!fileExistsAtPath(aFilePath)) {
                printf("\t-/-> Requested interferogram file not found: %s\n", aFilePath) ;
                printf("\t---> Looking for files with generic name \"interf\"\n") ;
                free(aFilePath) ;
                aFilePath = initStringWithString("interf") ;
                if (! isFilePresentInSubDir("interf", pInSAR->whereAmI)) {
                    free(aFilePath) ;
                    aFilePath = NULL ;
                    printf("\n\t-/-> interferogram geoprojection cancelled (missing file)\n") ;
                }
            }
            if(aFilePath) {
                pGeoProj->files->input = allocFileDescriptor() ;
                pGeoProj->files->input->directoryPath = getDirectoryPathFromPath((pInSAR->interf).filePath) ;
                pGeoProj->files->input->fileName = getFileNameFromPath(aFilePath) ;
                pGeoProj->files->input->xDim = (pInSAR->coh).lenr ;
                pGeoProj->files->input->yDim = (pInSAR->coh).lena ;
                pGeoProj->files->input->fileLength = (pInSAR->coh).lenr * (pInSAR->coh).lena * sizeof(float) ;

                /* Interferogram geoprojection */
                geoProjectInputProduct(pInSAR, geoProjDir, pGeoProj, genericExtension) ;
                freeRawFileDescriptor(pGeoProj->files->input) ;
                pGeoProj->files->input = NULL ;
            }
            free(aFilePath) ;
        }
    }

    /* Residual interferogram geoprojection */
    if ((aValue = getStringValForKeyIn(geoProjParams, "Geoproject residual interferogram"))) {
        if (!strncmp(aValue, "YES", 3)) {
            nonMaskedMappingComputation(pGeoProj) ;
            printf("\nResidual interferogram projection:\n");
            /* Open input file */
            aFilePath = initStringWithString((pInSAR->residualPhase).filePath) ;
            if (!fileExistsAtPath(aFilePath)) {
                printf("\t-/-> Requested residual phase file not found: %s\n", aFilePath) ;
                printf("\t---> Looking for files with generic name \"residualInterferogram\"\n") ;
                free(aFilePath) ;
                aFilePath = initStringWithString("residualInterferogram") ;
                if (! isFilePresentInSubDir("residualInterferogram", pInSAR->whereAmI)) {
                    free(aFilePath) ;
                    aFilePath = NULL ;
                    printf("\n\t-/-> Residual interferogram geoprojection cancelled (missing file)\n") ;
                }
            }
            if(aFilePath) {
                pGeoProj->files->input = allocFileDescriptor() ;
                pGeoProj->files->input->directoryPath = getDirectoryPathFromPath((pInSAR->residualPhase).filePath) ;
                pGeoProj->files->input->fileName = getFileNameFromPath(aFilePath) ;
                pGeoProj->files->input->xDim = (pInSAR->coh).lenr ;
                pGeoProj->files->input->yDim = (pInSAR->coh).lena ;
                pGeoProj->files->input->fileLength = (pInSAR->coh).lenr * (pInSAR->coh).lena * sizeof(float) ;

                /* Residual interferogram geoprojection */
                geoProjectInputProduct(pInSAR, geoProjDir, pGeoProj, genericExtension) ;
                freeRawFileDescriptor(pGeoProj->files->input) ;
                pGeoProj->files->input = NULL ;
            }
            free(aFilePath) ;
        }
    }

    /* Unwrapped phase geoprojection */
    if ((aValue = getStringValForKeyIn(geoProjParams, "Geoproject unwrapped phase"))) {
        if (!strncmp(aValue, "YES", 3)) {
            nonMaskedMappingComputation(pGeoProj) ;
            /* Open input file */
            if (!fileExistsAtPath((pInSAR->dephi).filePath)) {
                printf("\nUnwrapped phase geoprojection cancelled (missing file)\n") ;
            }
            else {
                if((pGeoProj->files->input = openRawFileForReadingAtPath((pInSAR->dephi).filePath)) == NULL)
                    ase("Failed to open unwrapped phase file\n") ;
                pGeoProj->files->input->xDim = (pInSAR->dephi).lenr ;
                pGeoProj->files->input->yDim = (pInSAR->dephi).lena ;

                /* Unwrapped phase geoprojection */
                printf("\nUnwrapped phase projection:\n");
                geoProjectInputProduct(pInSAR, geoProjDir, pGeoProj, genericExtension) ;
                freeRawFileDescriptor(pGeoProj->files->input) ;
                pGeoProj->files->input = NULL ;
            }
        }
    }

    /* Incidence file geoprojection */
    /* Systematically projected if present */

    freeRawFileDescriptor(pGeoProj->files->input) ;
    pGeoProj->files->input = allocFileDescriptor() ;
    pGeoProj->files->input->directoryPath = initStringWithString(InSARProductsDir) ;
    pGeoProj->files->input->fileName = initStringWithString("ncidence") ;
            pGeoProj->files->input->xDim = (pInSAR->interf).lenr ;
            pGeoProj->files->input->yDim = (pInSAR->interf).lena ;
    pGeoProj->files->input->fileLength = (pInSAR->coh).lenr * (pInSAR->coh).lena * sizeof(float) ;
        
            /* Incidence angle geoprojection */
            nonMaskedMappingComputation(pGeoProj) ;
    printf("\nLocal incidence angle file projection:\n");
            geoProjectInputProduct(pInSAR, geoProjDir, pGeoProj, genericExtension) ;
            freeRawFileDescriptor(pGeoProj->files->input) ;
    pGeoProj->files->input = NULL ;


	pGeoProj->files->input = NULL ;
	pGeoProj->files->output = NULL ;

    free(InSARProductsDir) ;
}

void updateGeoProjectionParametersFile(geoProj *pGeoProj, keyValue *geoProjParams)
{
	setDoubleValForKeyIn(geoProjParams, pGeoProj->frame->xMax, "xMax") ;
	setDoubleValForKeyIn(geoProjParams, pGeoProj->frame->xMin, "xMin") ;
	setDoubleValForKeyIn(geoProjParams, pGeoProj->frame->yMax, "yMax") ;
	setDoubleValForKeyIn(geoProjParams, pGeoProj->frame->yMin, "yMin") ;
    setIntValForKeyIn(geoProjParams, pGeoProj->params->xDimM, "X size") ;
    setIntValForKeyIn(geoProjParams, pGeoProj->params->yDimM, "Y size") ;
    if (pGeoProj->params->isUTM) {
        setStringValForKeyIn(geoProjParams, pGeoProj->params->UTMZone, "UTM zone") ;
    }
}

geoRef *initGeoRefStructure(keyValue *geoProjParams, InSARParametersStruct *pInSAR)
{
    char *aPath ;
	geoRef *geo ;
    SLCImageInfo *referenceInfoImage ;
    ellipsoid *ellProj ;
    polygon *aoi ;
    keyValue *referenceGeoProjParams ;
    coord2D *aPoint ;

    referenceInfoImage = pInSAR->masterInfo ;
    referenceGeoProjParams = geoProjParams ;

    /* If InSAR processing was performed with respect to a global master, we will use most of the parameters used for global master geoprojection */
    if (pInSAR->SM2MpInSAR) {
        referenceInfoImage = pInSAR->SM2MpInSAR->masterInfo ;
        if (pInSAR->flag & _COPY_SM2M_PROCESSING_PARAMETERS_) {        
            if ((aPath = initStringWith2Strings(pInSAR->SM2MPath, "/TextFiles/geoProjectionParameters.txt")) != NULL) {
                referenceGeoProjParams = readParameterFileAtPath(aPath) ;
                free(aPath) ;
            }
        }    
    }

    /* Read Datum */
    if((ellProj = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL) {
        ase("Failed to allocate projection ellipsoid pointer\n") ;
    }
    sprintf(ellProj->ellipsoidID, "%s", getStringValForKeyIn(referenceGeoProjParams, "Ellipsoid ID")) ;
    ellProj->a = getDoubleValForKeyIn(referenceGeoProjParams, "Semi major axis") ;
    ellProj->b = getDoubleValForKeyIn(referenceGeoProjParams, "Semi minor axis") ;
    ellProj->X0 = getDoubleValForKeyIn(referenceGeoProjParams, "X0") ;
    ellProj->Y0 = getDoubleValForKeyIn(referenceGeoProjParams, "Y0") ;
    ellProj->Z0 = getDoubleValForKeyIn(referenceGeoProjParams, "Z0") ;
    ellProj->f_1 = ellProj->a / (ellProj->a - ellProj->b) ;
    ellProj->e2 = (pow(ellProj->a, 2.) - pow(ellProj->b, 2.)) / pow(ellProj->a, 2.) ;

	/* Initialize georeferencing on target ellipsoid */
	geo = allocAndInitGeorefStructureForTargetEllipsoid(referenceInfoImage, ellProj) ;
    initGeoRefSolvingOnEllipsoid(geo->solving, geo->params->ellProj) ;

    /* Associate this geoRef structure with the one in the InSAR parameters */
    if (pInSAR->geo) {
        freeGeoRef(pInSAR->geo) ; 
    }
    pInSAR->geo = geo ;

    /* Select DEM file */
    if (!strncmp(getStringValForKeyIn(referenceGeoProjParams, "Use external DEM"), "YES", 3) && !(pInSAR->flag & _ON_GEOID_)) {
        /* Test if requested external slant range DEM file is present */
        if (!fileExistsAtPath(pInSAR->externalSlantRangeDEMFile->accessPath)) {
            /* We will verify if an external DEM is associated with the master image and recreate an external slant range DEM if possible */
            if (!getReferenceCSLImage(pInSAR)) {
                ase("No external DEM available within reference master image.\nPlease run slantRangeDEM first.\n") ;
            }
            generateExternalSlantRangeDEM(pInSAR) ;
        }
        pInSAR->flag |= _USE_EXTERNAL_DEM_ ;
    }

    if (pInSAR->flag & _ON_GEOID_) {
        geo->files->DEM = allocFileDescriptor() ;
        geo->files->DEM->xDim = ((pInSAR->interf).lenr)? (pInSAR->interf).lenr : (pInSAR->mod1).lenr ;
        geo->files->DEM->yDim = ((pInSAR->interf).lena)? (pInSAR->interf).lena : (pInSAR->mod1).lena ;
    }
    else {
        if(pInSAR->flag & _USE_EXTERNAL_DEM_) {
            if((geo->files->DEM = openRawFileForReadingAtPath((pInSAR->externalSlantRangeDEMFile)->accessPath)) == NULL) {
                ase("Failed to open external slant range DEM for geoReferencing\n") ;
            }
            geo->files->DEM->xDim = (pInSAR->externalSlantRangeDEMFile)->xDim ;
            geo->files->DEM->yDim = (pInSAR->externalSlantRangeDEMFile)->yDim ;
        }
        else {
            if((geo->files->DEM = openRawFileForReadingAtPath((pInSAR->srDEM).filePath)) == NULL)
                ase("Failed to open slant range DEM for geoReferencing\n") ;
            geo->files->DEM->xDim = (pInSAR->srDEM).lenr ;
            geo->files->DEM->yDim = (pInSAR->srDEM).lena ;
        }
    }
	geo->params->xReductionFactor = (float)(pInSAR->red).Fra ;
	geo->params->yReductionFactor = (float)(pInSAR->red).Faz ;

    /* Compute the lower left coordinate of original InSAR products */
    geo->params->x0 = (pInSAR->sup).Sgra + (pInSAR->coh).spi / 2 + (pInSAR->coh).cor / 2 + (pInSAR->red).Fra / 2. ;
    geo->params->y0 = (pInSAR->sup).Sbaz + (pInSAR->coh).spi / 2 + (pInSAR->coh).coa / 2 + (pInSAR->red).Faz / 2. ;

    /* If homemade phase unwrapping took place for generating reference DEM, correct for size reduction */
    if (pInSAR->cohder.lenr && pInSAR->cohder.lena && !(pInSAR->flag & _USE_EXTERNAL_DEM_)) {
        geo->params->x0 += (pInSAR->red).Fra * ((pInSAR->cohder).spi / 2 + (pInSAR->cohder).cor / 2) ;
        geo->params->y0 += (pInSAR->red).Faz * ((pInSAR->cohder).spi / 2 + (pInSAR->cohder).coa / 2) ;
    }

    geo->params->refXShift = 0 ;
    geo->params->refYShift = 0 ;
    /* Compute suystematic referencing shift to be applied to cope with referencing to lower-left corner of geoprojected pixel in place of pixel centre */
/*
    if (pInSAR->flag | _FLIP_) {
        if(!strncmp(getStringValForKeyIn(referenceGeoProjParams, "Chosen projection"), "UTM", 3)) {
            refXSampling = getDoubleValForKeyIn(referenceGeoProjParams, "Easting sampling") ;
            refYSampling = getDoubleValForKeyIn(referenceGeoProjParams, "Northing sampling") ;
        }
        else {
            refXSampling = getDoubleValForKeyIn(referenceGeoProjParams, "Longitude sampling") / 3600. ;
            refYSampling = getDoubleValForKeyIn(referenceGeoProjParams, "Latitude sampling")  / 3600. ;
        }

        geo->params->refXShift = .5 * refXSampling ;
        geo->params->refYShift = -.5 * refYSampling ;
    }
*/

    /* Select projection type */
    if ((geo->params->isUTM = !strncmp(getStringValForKeyIn(referenceGeoProjParams, "Chosen projection"), "UTM", 3))) {
        geo->params->UTMZone = initUTMReferencingOnEllipsoid(ellProj) ;

        if (pInSAR->flag & _CLEAN_PROJECTION_) {
            printf("\t---> Reseting projection area.\n") ;
            setStringValForKeyIn(referenceGeoProjParams, "pathToKmlFile", "Path to a kml") ;
        }
        aPath = getStringValForKeyIn(referenceGeoProjParams, "Path to a kml") ;
        if (pInSAR->flag & _USE_INSAR_KML_) {
            aPath = pInSAR->aoiKml ;
            printf("\t---> Setting projection area to used kml for InSAR processing\n") ;
            setStringValForKeyIn(referenceGeoProjParams, aPath, "Path to a kml") ;
        }
        if ((aoi = getRectangularAoIFromKMLFile(aPath))) {
            convertAoIFromDeg2Rad(aoi) ;
            aPoint = getCentreOfPolygon(aoi) ;
            updateUTMZoneForReferencePoint(aPoint->x, aPoint->y, geo->params->UTMZone) ;
            freePolygon(aoi) ;
            free(aPoint) ;
        }
        else {
            if (!updateUTMZone(getStringValForKeyIn(referenceGeoProjParams, "UTM zone"), geo->params->UTMZone)) {
                updateUTMZoneForSLCImage(geo, geo->params->UTMZone) ;
            }
        }
    }

    free(ellProj) ;
    if (referenceGeoProjParams != geoProjParams) {
        freeKeyValueList(referenceGeoProjParams) ;
    }
	return(geo) ;
}

void computeFrameFromGeoRef(geoRef *pGeoRef)
{
	char unsigned firstPointFound, *isMasked ;
	int iX, iY, xDim, yDim ;
	float xMin, xMax, yMin, yMax ;
	float *xRef, *yRef ;
	float *InSARHeight ;

	xDim = pGeoRef->files->DEM->xDim ;
	yDim = pGeoRef->files->DEM->yDim ;
	xRef = vectorFloat(0, xDim - 1) ;
	yRef = vectorFloat(0, xDim - 1) ;
	InSARHeight = vectorFloat(0, xDim - 1) ;
	isMasked = vectorUChar(0, xDim - 1) ;
    xMin = xMax = yMin = yMax = 0 ;

	fseek(pGeoRef->files->xRef->f, 0, SEEK_SET) ;
	fseek(pGeoRef->files->yRef->f, 0, SEEK_SET) ;
	fseek(pGeoRef->files->DEM->f, 0, SEEK_SET) ;
	firstPointFound = 0 ;
	for(iY = 0; iY < yDim; iY++) {
		fread(xRef, sizeof(float), xDim, pGeoRef->files->xRef->f) ;
		fread(yRef, sizeof(float), xDim, pGeoRef->files->yRef->f) ;
		fread(InSARHeight, sizeof(float), xDim, pGeoRef->files->DEM->f) ;
		if(pGeoRef->params->withMasking) {
			fread(isMasked, 1, pGeoRef->files->mask->xDim, pGeoRef->files->mask->f) ;
        }
		for(iX = 0; iX < xDim; iX++) {
			if(!(isMasked[iX] & 0b00001001) && (InSARHeight[iX] != pGeoRef->params->DEMExcludingValue) && (InSARHeight[iX] > pGeoRef->params->minVal) && (InSARHeight[iX] < pGeoRef->params->maxVal)) {
				if(!firstPointFound) {                                                                           // Pour la première itération, on enregistre les coordonnées du point
					xMax = xMin = xRef[iX] ;
					yMax = yMin = yRef[iX] ;
					firstPointFound = 1 ;
				}
				else {                                                                                          // Ensuite on compare avec les coordonnées des autres points pour trouver les frontières de la scène
					xMax = (xRef[iX] > xMax)? xRef[iX] : xMax ;
					xMin = (xRef[iX] < xMin)? xRef[iX] : xMin ;
					yMax = (yRef[iX] > yMax)? yRef[iX] : yMax ;
					yMin = (yRef[iX] < yMin)? yRef[iX] : yMin ;
				}
			}
		}
	}
	pGeoRef->frame->xMax = xMax ;
	pGeoRef->frame->xMin = xMin ;
	pGeoRef->frame->yMax = yMax ;
	pGeoRef->frame->yMin = yMin ;

    freeVectorUChar(isMasked, 0) ;
    freeVectorFloat(InSARHeight, 0) ;
    freeVectorFloat(xRef, 0) ;
    freeVectorFloat(yRef, 0) ;
}

void geoReferenceDEM(geoRef *pGeoRef, int unsigned  flag)                                                                           // Conversion des coordonnées cartésiennes en coordonnées longitude-latitude et calcul des latitudes et longitudes min/max
{
    char unsigned initBorders, *isMasked ;
	int iX, iY, xDim, yDim ;
	float *InSARHeight, noVal, x0, y0 ;
    float *xRef, *yRef ;
    float *yRef_1, *yRef1, *aFloatPointer ;
    float *xRadius, *yRadius, d1, d2 ;
	float xMin, xMax, yMin, yMax ;
    double xMaxSampling, xAverageSampling ;
    double yMaxSampling, yAverageSampling ;
    double normalizationFactor ;
	double rangeIndex, azimuthIndex, azimuthIndex0 ;
	double longitude, latitude ;
    coord2D ETADShifts ;
    size_t xDim_ul ;
	geoRefSolving *gRSolving ;
	progressCounter *aCounter ;
    SLCImageInfo *masterInfo ;
    rawFileDescriptor *mask ;

	xDim = pGeoRef->files->DEM->xDim ;                                                                          // Dimensions du DEM
	yDim = pGeoRef->files->DEM->yDim ;
	pGeoRef->files->xRef->xDim = xDim ;                                                                         // Dimensions du x referencing file sont les mêmes que celles du DEM
	pGeoRef->files->xRef->yDim = yDim ;
	pGeoRef->files->yRef->xDim = xDim ;                                                                         // Dimension du y referencing file sont les mêmes que celles du DEM
	pGeoRef->files->yRef->yDim = yDim ;
    xDim_ul = (size_t)xDim ;

	gRSolving = pGeoRef->solving ;
    masterInfo = pGeoRef->params->info ;
    mask = pGeoRef->files->mask ;
/*
    if(!(fileLength = pGeoRef->files->DEM->fileLength)) {
        fileLength = pGeoRef->files->DEM->xDim * pGeoRef->files->DEM->yDim * sizeof(float) ;
    }
	if((pGeoRef->files->xRef->fileLength == fileLength) && (pGeoRef->files->yRef->fileLength == fileLength) && (pGeoRef->files->xRadius->fileLength == fileLength) && (pGeoRef->files->yRadius->fileLength == fileLength)) {
		printf("Georeferencing apparently already done\n(xRef and yRef files exist and have the same dimension than the DEM)\n") ;
		return ;
	}
*/
	InSARHeight = vectorFloat(0, xDim) ;
    isMasked = vectorUChar(0, xDim - 1) ;
    for(iX = 0; iX < xDim; iX++) {
        InSARHeight[iX] = masterInfo->sceneAverageHeight ;
    }

    xRef = vectorFloat(0, xDim) ;
    yRef = vectorFloat(0, xDim) ;
    yRef_1 = vectorFloat(0, xDim) ;
    yRef1 = vectorFloat(0, xDim) ;
    xRadius = vectorFloat(0, xDim) ;
    yRadius = vectorFloat(0, xDim) ;

    noVal = pGeoRef->params->DEMExcludingValue ;

	printf("\n\t---> Slant range DEM georeferencing\n") ;
	aCounter = initProgressCounterWithMinMaxValue(0, yDim - 1) ;
    if (pGeoRef->files->DEM->f != NULL) {
        fseek(pGeoRef->files->DEM->f, 0, SEEK_SET) ;
    }
	x0 = pGeoRef->params->x0 ;
	y0 = pGeoRef->params->y0 ;
    initBorders = 1 ;
    xMin = xMax = yMin = yMax = 0 ;
    xMaxSampling = yMaxSampling = xAverageSampling = yAverageSampling = 0 ;

	for(iY = 0; iY < yDim; iY++) {
		/* Update state vect and georeferencing for this azimuth line */
		azimuthIndex0 = (double)(y0 + iY * pGeoRef->params->yReductionFactor) ;                                 // Image pleine résolution
        if(azimuthIndex0 != gRSolving->S->azimuthPosition) {
            calcStateVect(gRSolving->S, azimuthIndex0, masterInfo) ;
            initOnSphereSolving(gRSolving) ;                                                            // Initialisation du géoréférencement => permet de déterminer les coordonnées cartésiennes d'un point dans le système de référence géocentrique
        }

//        azimuthIndex += 0.5 * (double)pGeoRef->params->yReductionFactor ;        

		/* read a line of InSAR height (if no DEM provided, InSARHeight is zero) */
        if (pGeoRef->files->DEM->f != NULL) {
            if(fread(InSARHeight, sizeof(float), xDim, pGeoRef->files->DEM->f) != xDim_ul)
                ase("Failed to read InSAR DEM") ;
        }        

        if(pGeoRef->params->withMasking) {
            fread(isMasked, sizeof(char unsigned), mask->xDim, mask->f) ;
        }    

        for(iX = 0; iX < xDim; iX++) {
            if (!(isMasked[iX] & 0b0001001) 
            &&  !areFloatValsEquals(InSARHeight[iX], noVal) 
            &&  (InSARHeight[iX] > pGeoRef->params->minVal) 
            &&  (InSARHeight[iX] < pGeoRef->params->maxVal)) {
                rangeIndex = (double)(x0 + iX * pGeoRef->params->xReductionFactor) ;
//                rangeIndex += 0.5 * (double)pGeoRef->params->xReductionFactor ;  
                azimuthIndex = azimuthIndex0 ;

                if (flag & _ETAD_CORRECTION_) {
                    ETADShifts = ETADGeoreferencingShift(rangeIndex, azimuthIndex, masterInfo) ;
                    rangeIndex -= ETADShifts.x * masterInfo->rangeSamplingFrequency ;
                    azimuthIndex -= ETADShifts.y / masterInfo->lineTimeInterval ;
                }
                
                pGeoRef->solving->Rt = earthRadiusAtPoint(rangeIndex, azimuthIndex, InSARHeight[iX], pGeoRef) ;             // Calcul du rayon terrestre au point donné

                /* Commented because done during the computation of the local Earth radius */
//                onSpherePoint = onSphereSolvingForPoint(P2[0], P2[1], InSARHeight[iX], pGeoRef) ;               // Coordonnées cartésiennes du point P2
//                onEllipsoidProjection(onEllipsoidPoint, onSpherePoint, gRSolving) ;                             // Projection du point sur l'ellipsoide afin de déterminer ses coordonnées longitude-latitude

                XYZ2LonLat(&longitude, &latitude, gRSolving->Pg, gRSolving) ;
                if(pGeoRef->params->isUTM) {
                    lonLat2UTMOnEllipsoid(&longitude, &latitude, pGeoRef->params->UTMZone) ;
                }
                else {
                    longitude *= 180./PI ;                                                                      // Conversion des radians en degrés
                    latitude *= 180./PI ;
                }

                xRef[iX] = longitude + pGeoRef->params->refXShift ;                                                                          // Les fichiers de références contiennent soit la latitude, soit la longitude
                yRef[iX] = latitude + pGeoRef->params->refYShift;

                if(initBorders) {                                                                               // initBorders = 1 à la première itération
                    xMax = xMin = longitude ;
                    yMax = yMin = latitude ;
                    initBorders = 0 ;
                }
                else {
                    xMax = (longitude > xMax)? longitude : xMax ;
                    xMin = (longitude < xMin)? longitude : xMin ;
                    yMax = (latitude > yMax)? latitude : yMax ;
                    yMin = (latitude < yMin)? latitude : yMin ;
                }
            }
            else {
                xRef[iX] = yRef[iX] = pGeoRef->params->DEMExcludingValue ;
            }
		}
		fwrite(xRef, sizeof(float), xDim, pGeoRef->files->xRef->f) ;
		fwrite(yRef, sizeof(float), xDim, pGeoRef->files->yRef->f) ;
		updateProgressCounterForIndex(aCounter, iY) ;
	}
	updateProgressCounterForIndex(aCounter, iY) ;
    freeProgressCounter(aCounter) ;
    fflush(pGeoRef->files->xRef->f) ;
    fflush(pGeoRef->files->yRef->f) ;
    
    /* Now, we will reread X and Y referencing to compute interpolation radius */
    fseek(pGeoRef->files->xRef->f, 0L, SEEK_SET) ;
    fseek(pGeoRef->files->yRef->f, 0L, SEEK_SET) ;

    xMaxSampling = xAverageSampling = normalizationFactor = 0. ;
    for (iY = 0; iY < yDim; iY++) {
        fread(xRef, sizeof(float), xDim, pGeoRef->files->xRef->f) ;
        for (iX = 1; iX < xDim - 1; iX++) {
            /* We will estimate X local interpolation radius */
            if (!areFloatValsEquals(xRef[iX], noVal)) {
                d1 = (areFloatValsEquals(xRef[iX - 1], noVal))? 0 : fabsf(xRef[iX] - xRef[iX - 1]) ;
                d2 = (areFloatValsEquals(xRef[iX + 1], noVal))? 0 : fabsf(xRef[iX] - xRef[iX + 1]) ;

                if (flag & _FILL_HOLES_) {
                    xRadius[iX] = (d1 < d2)? d2 : d1 ;
                    xRadius[iX] *= 1.2 ;
                }
                else {
                    xRadius[iX] = (d1)? (d1 > d2)? (d2)? d2 : d1 : d1 : d2 ;
                    if (!(flag & _NEAREST_NEIGHBOR_)) {
                        xRadius[iX] *= pGeoRef->params->holeFillingFactor ;
                    }
                }
                xAverageSampling += xRadius[iX] ;
                xMaxSampling = (xMaxSampling < xRadius[iX])? xRadius[iX] : xMaxSampling ;
                normalizationFactor++ ;
            }
            else
                xRadius[iX] = noVal ;
        }
        xRadius[0] = xRadius[1] ;
        xRadius[iX] = xRadius[iX - 1] ;
        fwrite(xRadius, sizeof(float), xDim, pGeoRef->files->xRadius->f) ;
    }
    xAverageSampling /= normalizationFactor ;

    fread(yRef_1, sizeof(float), xDim, pGeoRef->files->yRef->f) ;
    fread(yRef, sizeof(float), xDim, pGeoRef->files->yRef->f) ;
    fwrite(yRadius, sizeof(float), xDim, pGeoRef->files->yRadius->f) ;
    yMaxSampling = yAverageSampling = normalizationFactor = 0. ;
    for (iY = 2; iY < yDim; iY++) {
        fread(yRef1, sizeof(float), xDim, pGeoRef->files->yRef->f) ;
        for (iX = 0; iX < xDim; iX++) {
            if (!areFloatValsEquals(yRef[iX], noVal)) {
                /* We will estimate Y local interpolation radius */
                d1 = (areFloatValsEquals(yRef_1[iX], noVal))? 0 : fabsf(yRef[iX] - yRef_1[iX]) ;
                d2 = (areFloatValsEquals(yRef1[iX], noVal))? 0 : fabsf(yRef[iX] - yRef1[iX]) ;

                if (flag & _FILL_HOLES_) {
                    yRadius[iX] = (d1 < d2)? d2 : d1 ;
                    yRadius[iX] *= 1.2 ;
                }
                else {
                    yRadius[iX] = (d1)? (d1 > d2)? (d2)? d2 : d1 : d1 : d2 ;
                    if (!(flag & _NEAREST_NEIGHBOR_)) {
                        yRadius[iX] *= pGeoRef->params->holeFillingFactor ;
                    }
                }
                yAverageSampling += yRadius[iX] ;
                yMaxSampling = (yMaxSampling < yRadius[iX])? yRadius[iX] : yMaxSampling ;
                normalizationFactor++ ;
           }
            else
                yRadius[iX] = noVal ;
        }
        fwrite(yRadius, sizeof(float), xDim, pGeoRef->files->yRadius->f) ;

        /* Line shift */
        aFloatPointer = yRef_1 ;
        yRef_1 = yRef ;
        yRef = yRef1 ;
        yRef1 = aFloatPointer ;
    }
    yAverageSampling /= normalizationFactor ;

    /* We replicate first and last lines */
    fwrite(yRadius, sizeof(float), xDim, pGeoRef->files->yRadius->f) ;
    fseek(pGeoRef->files->yRadius->f, xDim * sizeof(float), SEEK_SET) ;
    fread(yRadius, sizeof(float), xDim, pGeoRef->files->yRadius->f) ;
    fseek(pGeoRef->files->yRef->f, 0, SEEK_SET) ;
    fwrite(yRadius, sizeof(float), xDim, pGeoRef->files->yRadius->f) ;

    /* Save frame */
	pGeoRef->frame->xMax = xMax ;
	pGeoRef->frame->xMin = xMin ;
	pGeoRef->frame->yMax = yMax ;
	pGeoRef->frame->yMin = yMin ;

    /* Save max and average samplings */
    pGeoRef->params->xAverageSampling = (float)xAverageSampling ;
    pGeoRef->params->yAverageSampling = (float)yAverageSampling ;
    pGeoRef->params->xMaxSampling = (float)xMaxSampling ;
    pGeoRef->params->yMaxSampling = (float)yMaxSampling ;

    printf("\nReferencing X average sampling: %f\n", pGeoRef->params->xAverageSampling) ;
    printf("Referencing Y average sampling: %f\n", pGeoRef->params->yAverageSampling) ;
    printf("Referencing X max sampling: %f\n", pGeoRef->params->xMaxSampling) ;
    printf("Referencing Y max sampling: %f\n", pGeoRef->params->yMaxSampling) ;

    fflush(pGeoRef->files->xRef->f) ;
    fflush(pGeoRef->files->yRef->f) ;

    freeVectorUChar(isMasked, 0) ;
	freeVectorFloat(InSARHeight, 0) ;
    freeVectorFloat(xRef, 0) ;
    freeVectorFloat(yRef, 0) ;
    freeVectorFloat(yRef_1, 0) ;
    freeVectorFloat(yRef1, 0) ;
    freeVectorFloat(xRadius, 0) ;
    freeVectorFloat(yRadius, 0) ;
}

void cropInSARProducts(InSARParametersStruct *pInSAR)
{
	int	iY, xDim, yDim, Da, Dr ;
	float **source ;
	rawFileDescriptor *aFile ;

	xDim = pInSAR->srDEM.lenr ;
	yDim = pInSAR->srDEM.lena ;
	Dr = (pInSAR->mod1.lenr - xDim) / 2 ;
	Da = (pInSAR->mod1.lena - yDim) / 2 ;

    source = matrixFloat(0, pInSAR->mod1.lena - 1, 0, pInSAR->mod1.lenr - 1) ;

    /* If no unwrapped slant range DEM available ... */
    if(!fileExistsAtPath(pInSAR->srDEM.filePath)) {
        /* Check if an external slant range DEM is available. If not, exit. If yes use it */
        if(!fileExistsAtPath(pInSAR->externalSlantRangeDEMFile->accessPath)) {
            ase("No slant range DEM available for geoprojection\n") ;
        }
        else {
            printf("External slant range DEM will be used for geoprojection") ;
            printf("Cropping external slant range DEM\n") ;
            if(!((aFile = openRawFileForReadingAndWritingAtPath((pInSAR->externalSlantRangeDEMFile)->accessPath)) == NULL)) {
                fread((float *)source[0], sizeof(float), (pInSAR->mod1).lena * (pInSAR->mod1).lenr, aFile->f) ;
                fseek(aFile->f, 0L, SEEK_SET) ;
                for(iY = 0; iY < yDim; iY++) {
                    fwrite((float *)&source[Da + iY][Dr], xDim, sizeof(float), aFile->f) ;
                }
                freeRawFileDescriptor(aFile) ;
            }
            pInSAR->externalSlantRangeDEMFile->xDim = xDim ;
            pInSAR->externalSlantRangeDEMFile->yDim = yDim ;
        }
        pInSAR->flag |= _USE_EXTERNAL_DEM_ ;
    }

		if(xDim != pInSAR->mod1.lenr) {
		printf("Cropping master amplitude image\n") ;
		if(!((aFile = openRawFileForReadingAndWritingAtPath((pInSAR->mod1).filePath)) == NULL)) {
			fread((float *)source[0], sizeof(float), (pInSAR->mod1).lena * (pInSAR->mod1).lenr, aFile->f) ;
			fseek(aFile->f, 0L, SEEK_SET) ;
			for(iY = 0; iY < yDim; iY++) {
				fwrite((float *)&source[Da + iY][Dr], xDim, sizeof(float), aFile->f) ;
			}
			freeRawFileDescriptor(aFile) ;
		}
		pInSAR->mod1.lenr = xDim ;
		pInSAR->mod1.lena = yDim ;
	}

	if(xDim != pInSAR->mod2.lenr) {
		printf("Cropping slave amplitude image\n") ;
		if(!((aFile = openRawFileForReadingAndWritingAtPath((pInSAR->mod2).filePath)) == NULL)) {
			fread((float *)source[0], sizeof(float), (pInSAR->mod2).lena * (pInSAR->mod2).lenr, aFile->f) ;
			fseek(aFile->f, 0L, SEEK_SET) ;
			for(iY = 0; iY < yDim; iY++) {
				fwrite((float *)&source[Da + iY][Dr], xDim, sizeof(float), aFile->f) ;
			}
			freeRawFileDescriptor(aFile) ;
		}
		pInSAR->mod2.lenr = xDim ;
		pInSAR->mod2.lena = yDim ;
	}

	if(xDim != pInSAR->coh.lenr) {
		printf("Cropping coherence image\n") ;
		if(!((aFile = openRawFileForReadingAndWritingAtPath((pInSAR->coh).filePath)) == NULL)) {
			fread((float *)source[0], sizeof(float), (pInSAR->coh).lena * (pInSAR->coh).lenr, aFile->f) ;
			fseek(aFile->f, 0L, SEEK_SET) ;
			for(iY = 0; iY < yDim; iY++) {
				fwrite((float *)&source[Da + iY][Dr], xDim, sizeof(float), aFile->f) ;
			}
			freeRawFileDescriptor(aFile) ;
		}
		pInSAR->coh.lenr = xDim ;
		pInSAR->coh.lena = yDim ;
    }

    if(xDim != pInSAR->interf.lenr) {
		printf("Cropping interferogram\n") ;
		if(!((aFile = openRawFileForReadingAndWritingAtPath((pInSAR->interf).filePath)) == NULL)) {
			fread((float *)source[0], sizeof(float), (pInSAR->interf).lena * (pInSAR->interf).lenr, aFile->f) ;
			fseek(aFile->f, 0L, SEEK_SET) ;
			for(iY = 0; iY < yDim; iY++) {
				fwrite((float *)&source[Da + iY][Dr], xDim, sizeof(float), aFile->f) ;
			}
			freeRawFileDescriptor(aFile) ;
		}
		if(!((aFile = openRawFileForReadingAndWritingAtPath((pInSAR->filter).filePath)) == NULL)) {
			fread((float *)source[0], sizeof(float), (pInSAR->interf).lena * (pInSAR->interf).lenr, aFile->f) ;
			fseek(aFile->f, 0L, SEEK_SET) ;
			for(iY = 0; iY < yDim; iY++) {
				fwrite((float *)&source[Da + iY][Dr], xDim, sizeof(float), aFile->f) ;
			}
			freeRawFileDescriptor(aFile) ;
		}
		pInSAR->interf.lenr = xDim ;
		pInSAR->interf.lena = yDim ;
	}
}


void createGeoProjectionParametersFileAtPath(char *InSARPath)
{
    char aPath[_MAX_PATH_LENGTH_], *geoProjectionDir ;
    keyValue *paramList ;

    geoProjectionDir = initStringWith2Strings(InSARPath, "/GeoProjection") ;

    paramList = allocAKeyValuePair() ;

    setStringValForKeyIn(paramList, "Geoprojection parameters file", "") ;
    setStringValForKeyIn(paramList, "*****************************", "") ;
    setStringValForKeyIn(paramList, "", "") ;
    sprintf(aPath, "%s/TextFiles/InSARParameters.txt", InSARPath) ;
    setStringValForKeyIn(paramList, aPath, "InSAR parameters file") ;
    setStringValForKeyIn(paramList, "UTM", "Chosen projection (UTM or GEC)") ;

    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Projection ellipsoid", "") ;
    setStringValForKeyIn(paramList, "********************", "") ;
    setStringValForKeyIn(paramList, "WGS84", "Ellipsoid ID") ;
    setStringValForKeyIn(paramList, "6378137.0", "Semi major axis") ;
    setStringValForKeyIn(paramList, "6356752.314245179295540", "Semi minor axis") ;
    setStringValForKeyIn(paramList, "0", "X0") ;
    setStringValForKeyIn(paramList, "0", "Y0") ;
    setStringValForKeyIn(paramList, "0", "Z0") ;

    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Geographical projection parameters (GEC)", "") ;
    setStringValForKeyIn(paramList, "**********************************", "") ;
    setStringValForKeyIn(paramList, "2", "Longitude sampling [arc second]") ;
    setStringValForKeyIn(paramList, "2", "Latitude sampling [arc second]") ;
//    setStringValForKeyIn(paramList, "0.0007", "Longitude interpolation radius [dd]") ;
//    setStringValForKeyIn(paramList, "0.0007", "Latitude interpolation radius [dd]") ;

    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "UTM projection parameters", "") ;
    setStringValForKeyIn(paramList, "*************************", "") ;
    setStringValForKeyIn(paramList, "50", "Easting sampling [m]") ;
    setStringValForKeyIn(paramList, "50", "Northing sampling [m]") ;
    setStringValForKeyIn(paramList, "", "UTM zone : If defining an UTM area of interest by values, UTM zone can be forced.") ;
//    setStringValForKeyIn(paramList, "70", "Easting interpolation radius [m]") ;
//    setStringValForKeyIn(paramList, "70", "Northing interpolation radius [m]") ;

    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Resampling parameters", "") ;
    setStringValForKeyIn(paramList, "*********************", "") ;
    setStringValForKeyIn(paramList, "TRI", "Resampling method : TRI = Triangulation; AV = weighted average; NN = nearest neighbour") ;
    setStringValForKeyIn(paramList, "LORENTZ", "Weighting method : ID = inverse distance; LORENTZ = lorentzian") ;
    setStringValForKeyIn(paramList, "1.0", "ID smoothing factor") ;
    setStringValForKeyIn(paramList, "1.0", "ID weighting exponent") ;
    setStringValForKeyIn(paramList, "0.5", "FWHM : Lorentzian Full Width at Half Maximum") ;
    setStringValForKeyIn(paramList, "none", "Masking: Use of slant range mask or zoneMap for measurement geo-projection ([mask] or [zoneMap])") ;
    setStringValForKeyIn(paramList, "1", "Zone index if [zoneMap] is selected for masking") ;
    setStringValForKeyIn(paramList, "NaN", "No data value") ;
    setStringValForKeyIn(paramList, "NaN", "Excluding height value") ;
    setStringValForKeyIn(paramList, "-400.", "Minimal height value") ;
    setStringValForKeyIn(paramList, "8000.", "Maximal height value") ;

    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Geoprojection frame", "") ;
    setStringValForKeyIn(paramList, "*******************", "") ;
    setStringValForKeyIn(paramList, "Area of Interest can be given as a kml file or be predefined in geoProjection units. (kml prevails)", "") ;
    setStringValForKeyIn(paramList, "pathToKmlFile", "Path to a kml file defining the geoProjection area") ;
    setStringValForKeyIn(paramList, "0.", "xMin") ;
    setStringValForKeyIn(paramList, "0.", "xMax") ;
    setStringValForKeyIn(paramList, "0.", "yMin") ;
    setStringValForKeyIn(paramList, "0.", "yMax") ;
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "0", "X size of geoprojected products [pix]") ;
    setStringValForKeyIn(paramList, "0", "Y size of geoprojected products [pix]") ;


    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Geoprojected result files", "") ;
    setStringValForKeyIn(paramList, "*************************", "") ;
    setStringValForKeyIn(paramList, "YES/NO flags can be set here to select products to be geoprojected", "") ;

    setStringValForKeyIn(paramList, "YES", "Use external DEM as reference (if NO, the computed InSAR DEM will be used") ;
    setStringValForKeyIn(paramList, "YES", "Geoproject measurement (slant range topography or deformation map)") ;
    setStringValForKeyIn(paramList, "YES", "Geoproject master amplitude") ;
    setStringValForKeyIn(paramList, "YES", "Geoproject slave amplitude") ;
    setStringValForKeyIn(paramList, "YES", "Geoproject coherence") ;
    setStringValForKeyIn(paramList, "NO", "Geoproject interferogram") ;
    setStringValForKeyIn(paramList, "YES", "Geoproject residual interferogram") ;
    setStringValForKeyIn(paramList, "YES", "Geoproject unwrapped phase") ;
    setStringValForKeyIn(paramList, geoProjectionDir, "Geoprojected products directory") ;
//    setStringValForKeyIn(paramList, genericExtension, "Geoprojected products generic extension") ;

    sprintf(aPath, "%s/TextFiles/geoProjectionParameters.txt", InSARPath) ;
    writeParameterFileAtPath(paramList, aPath) ;
    freeKeyValueList(paramList) ;

    free(geoProjectionDir) ;
}

geoProj *initGeoProjStructure(keyValue *geoProjParams, InSARParametersStruct *pInSAR)
{
    char *genericExtension, *geoProjDir ;
    char **fileList ;
    char *aString, *aPath, zoneMap, *maskPath ;
    char unsigned *maskLine ;
    int unsigned *zoneMapLine, zoneIndex ;
    int xDim, yDim ;
    int dX, dY, iX, iY ;
    int numberOfFiles ;
    size_t xDim_st, yDim_st ;
    geoProj *pGeoProj ;
    rawFileDescriptor *mask ;
    keyValue *referenceGeoProjParams ;
    polygon *aoi ;
    CSVStruct *aCSV = NULL ;

    /* If InSAR processing was performed with respect to a global master, we will use most of the parameters used for global master geoprojection */
    referenceGeoProjParams = geoProjParams ;
    if (pInSAR->SM2MpInSAR && (pInSAR->flag & _COPY_SM2M_PROCESSING_PARAMETERS_)) {
        if ((aPath = initStringWith2Strings(pInSAR->SM2MPath, "/TextFiles/geoProjectionParameters.txt")) != NULL) {
            referenceGeoProjParams = readParameterFileAtPath(aPath) ;
            free(aPath) ;
        }
    }

    pGeoProj = allocGeoProj() ;

    /* Select projection type, get output files directory and generic extension */
    geoProjDir = pGeoProj->files->geoProjDir = initStringWith2Strings(getStringValForKeyIn(geoProjParams, "Geoprojected products directory"), "/") ;
    pGeoProj->params->isUTM = !strncmp(getStringValForKeyIn(referenceGeoProjParams, "Chosen projection"), "UTM", 3) ;
    if(pGeoProj->params->isUTM) {
        pGeoProj->params->xSampling = getDoubleValForKeyIn(referenceGeoProjParams, "Easting sampling") ;
        pGeoProj->params->ySampling = getDoubleValForKeyIn(referenceGeoProjParams, "Northing sampling") ;
        aCSV = addStringValInCSVStruct(".UTM.", aCSV) ;
    }
    else {
        pGeoProj->params->xSampling = getDoubleValForKeyIn(referenceGeoProjParams, "Longitude sampling") ;
        pGeoProj->params->ySampling = getDoubleValForKeyIn(referenceGeoProjParams, "Latitude sampling") ;
        aCSV = addStringValInCSVStruct(".GEC.", aCSV) ;
    }
    aCSV = addFloatValInCSVStruct(pGeoProj->params->xSampling, aCSV) ;
    aCSV = addStringValInCSVStruct("x", aCSV) ;
    aCSV = addFloatValInCSVStruct(pGeoProj->params->ySampling, aCSV) ;
    genericExtension = getStringFromCSV(aCSV) ;
    pGeoProj->files->genericExtension = initStringWithString(genericExtension) ;
    freeCSVStruct(aCSV) ;
    
    if (!pGeoProj->params->isUTM) {
        pGeoProj->params->xSampling /= 3600. ;
        pGeoProj->params->ySampling /= 3600. ;
    }
    
    
    /* Select reference DEM */
    xDim = pInSAR->srDEM.lenr ;
    yDim = pInSAR->srDEM.lena ;
    if ((pInSAR->flag & _USE_EXTERNAL_DEM_)) {
        xDim = pInSAR->externalSlantRangeDEMFile->xDim ;
        yDim = pInSAR->externalSlantRangeDEMFile->yDim ;
    }

    /* If flat projection on geoid is selected, fictive DEM have same dimension than InSAR products */
    if (pInSAR->flag & _ON_GEOID_) {
        xDim = (pInSAR->interf.lenr)? pInSAR->interf.lenr : pInSAR->mod1.lenr ;
        yDim = (pInSAR->interf.lena)? pInSAR->interf.lena : pInSAR->mod1.lena ;
    }
    xDim_st = (size_t)xDim ;
    yDim_st = (size_t)yDim ;

    /* Create X referencing file */
    aPath = initStringWith2Strings(geoProjDir, "xRef") ;
    if((pGeoProj->files->xRef = openRawFileForReadingAndWritingAtPath(aPath)) == NULL) {
        perror("Failed to open/create X referencing file\n") ;
        exit(-1) ;
    }
    pGeoProj->files->xRef->xDim = xDim_st ;
    pGeoProj->files->xRef->yDim = yDim_st ;
    free(aPath) ;
    
    /* Create Y referencing file */
    aPath = initStringWith2Strings(geoProjDir, "yRef") ;
    if((pGeoProj->files->yRef = openRawFileForReadingAndWritingAtPath(aPath)) == NULL) {
        perror("Failed to open/create Y referencing file\n") ;
        exit(-1) ;
    }
    pGeoProj->files->yRef->xDim = xDim_st ;
    pGeoProj->files->yRef->yDim = yDim_st ;
    free(aPath) ;

    /* Create X radius file */
    aPath = initStringWith2Strings(geoProjDir, "xRadius") ;
    if((pGeoProj->files->xRadius = openRawFileForReadingAndWritingAtPath(aPath)) == NULL) {
        perror("Failed to open/create X radius file\n") ;
        exit(-1) ;
    }
    pGeoProj->files->xRadius->xDim = xDim_st ;
    pGeoProj->files->xRadius->yDim = yDim_st ;
    free(aPath) ;

    /* Create Y radius file */
    aPath = initStringWith2Strings(geoProjDir, "yRadius") ;
    if((pGeoProj->files->yRadius = openRawFileForReadingAndWritingAtPath(aPath)) == NULL) {
        perror("Failed to open/create Y radius file\n") ;
        exit(-1) ;
    }
    pGeoProj->files->yRadius->xDim = xDim_st ;
    pGeoProj->files->yRadius->yDim = yDim_st ;
    free(aPath) ;

    /* If clean projection requested, first verify if mapping exists. If so, trash it */
    /* Trash also all existing results with requested extension */
    if (pInSAR->flag & _CLEAN_PROJECTION_) {
//        unlink(aFilePath) ;
        fileList = getDirectoryContentAtPath(geoProjDir, &numberOfFiles) ;
        for (iX = 0; iX < numberOfFiles; iX++) {
            if (isSubStringPresentInString(getPointerToFileExtensionInPath(fileList[iX]), genericExtension)) {
                aPath = initStringWith2Strings(geoProjDir, fileList[iX]) ;
                unlink(aPath) ;
                free(aPath) ;
            }
            free(fileList[iX]) ;
        }
        free(fileList) ;
    }
    /* Open/Create projection matrix file */
    aPath = initStringWith3Strings(geoProjDir, "projMat", pGeoProj->files->genericExtension) ;
    if((pGeoProj->files->M = openRawFileForReadingAndWritingAtPath(aPath)) == NULL) {
        ase("Failed to open/create Projection matrix file\n") ;
    }
    free(aPath) ;

    /* Read frame values */
    aPath = getStringValForKeyIn(referenceGeoProjParams, "Path to a kml") ;
    if (pInSAR->flag & _USE_INSAR_KML_) {
        aPath = pInSAR->aoiKml ;
    }
    if ((aoi = getRectangularAoIFromKMLFile(aPath))) {
        if (pGeoProj->params->isUTM) {
            convertAoIFromDeg2Rad(aoi) ;
            for (iX = 0; iX < aoi->N; iX++) {
                lonLat2UTMOnEllipsoid(aoi->V[iX], aoi->V[iX] + 1, pInSAR->geo->params->UTMZone) ;
            }
        }
        pGeoProj->frame->xMax = aoi->P[2].x ;
        pGeoProj->frame->xMin = aoi->P[0].x ;
        pGeoProj->frame->yMax = aoi->P[2].y ;
        pGeoProj->frame->yMin = aoi->P[0].y ;
        
        freePolygon(aoi) ;
    }
    else {
        /* If clean projection is requested, force recalculate geo-referencing and mapping */
        if (pInSAR->flag & _CLEAN_PROJECTION_) {
            pGeoProj->files->M->fileLength = 0 ;
            pGeoProj->frame->xMax = 0 ;
            pGeoProj->frame->xMin = 0 ;
            pGeoProj->frame->yMax = 0 ;
            pGeoProj->frame->yMin = 0 ;
        }
        else {
            pGeoProj->frame->xMax = getDoubleValForKeyIn(referenceGeoProjParams, "xMax") ;
            pGeoProj->frame->xMin = getDoubleValForKeyIn(referenceGeoProjParams, "xMin") ;
            pGeoProj->frame->yMax = getDoubleValForKeyIn(referenceGeoProjParams, "yMax") ;
            pGeoProj->frame->yMin = getDoubleValForKeyIn(referenceGeoProjParams, "yMin") ;
        }
    }

    if (pGeoProj->params->isUTM) {
        sprintf(pGeoProj->params->UTMZone, "%2d%1s", pInSAR->geo->params->UTMZone->indiceZoneLonUTM, pInSAR->geo->params->UTMZone->zoneLatUTM) ;
    }

    /* Define pixel shift to cope with (Q)GIS */
    /* 20230818: Correction. Shifts reset to zero. No half pixel shift required */
    pGeoProj->params->dX = 0 ;
    pGeoProj->params->dY = 0 ;

    /* Read projection parameters */
    pGeoProj->params->resamplingMethod = initStringWithString(getStringValForKeyIn(referenceGeoProjParams, "Resampling method")) ;
    pGeoProj->params->weightingMethod = initStringWithString(getStringValForKeyIn(referenceGeoProjParams, "Weighting method")) ;
    pGeoProj->params->smoothingFactor = getDoubleValForKeyIn(referenceGeoProjParams, "ID smoothing factor") ;
    pGeoProj->params->exponent = getDoubleValForKeyIn(referenceGeoProjParams, "ID weighting exponent") ;
    pGeoProj->params->FWHM = getDoubleValForKeyIn(referenceGeoProjParams, "FWHM") ;
    pGeoProj->params->HWHM = pGeoProj->params->FWHM / 2. ;

    /* Read excluding value */
    aString = getStringValForKeyIn(referenceGeoProjParams, "Excluding height value") ;
    if (plError != KEY_VALUE_NOT_FOUND) {
        if (!strncmp(aString, "NaN", 3)) {
            pGeoProj->params->DEMExcludingValue = floatNaN ;
        }
        else
            pGeoProj->params->DEMExcludingValue = getFloatValForKeyIn(referenceGeoProjParams, "Excluding height value") ;
    }

    /* Read no data value */
    aString = getStringValForKeyIn(referenceGeoProjParams, "No data value") ;
    if (plError != KEY_VALUE_NOT_FOUND) {
        if (!strncmp(aString, "NaN", 3)) {
            pGeoProj->params->noVal = floatNaN ;
        }
        else
            pGeoProj->params->noVal = getFloatValForKeyIn(referenceGeoProjParams, "No data value") ;
    }

    pGeoProj->params->minVal = getFloatValForKeyIn(referenceGeoProjParams, "Minimal height value") ;
    pGeoProj->params->maxVal = getFloatValForKeyIn(referenceGeoProjParams, "Maximal height value") ;

    /* Determine if we deal with a zone map or an already built mask for mask creation/reading */
    pGeoProj->params->withMasking = 0 ;
    zoneMap = 0 ;
    maskPath = NULL ;
    if (!strncmp(getStringValForKeyIn(geoProjParams, "Masking"), "zone", 4)) {
        maskPath = initStringWith2Strings(pInSAR->dephi.filePath, "%s.zoneMap") ;
        zoneMap = 1 ;
    }
    if (!strncmp(getStringValForKeyIn(geoProjParams, "Masking"), "mask", 4)) {
        maskPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/slantRangeMask") ;
    }

    if((pGeoProj->params->withMasking = fileExistsAtPath(maskPath))) {
        pGeoProj->params->withMasking = (zoneMap)? 1 : 2 ;
        pGeoProj->files->mask = openRawFileForReadingAtPath(maskPath) ;
        pGeoProj->files->mask->xDim = xDim_st ;
        pGeoProj->files->mask->yDim = yDim_st ;

        /* If we deal with a zone map, create corresponding mask */
        if (zoneMap) {
            maskLine = vectorUChar(0, xDim - 1) ;
            zoneIndex = (int unsigned)getIntValForKeyIn(geoProjParams, "Zone index") ;
            zoneMapLine = vectorIntUnsigned(0, xDim - 1) ;
            aPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/zoneFileMask") ;
            mask = openRawFileForReadingAndWritingAtPath(aPath) ;
            free(aPath) ;
            mask->xDim = xDim_st ;
            mask->yDim = yDim_st ;

            /* If using an external DEM, take centering shift into account with respect to home made phase unwrapping */
            dX = (xDim - pInSAR->srDEM.lenr) / 2 ;
            dY = (yDim - pInSAR->srDEM.lena) / 2 ;

            /* Init mask line to 1 to ensure performing masking */
            for (iX = 0; iX < xDim; iX++) {
                maskLine[iX] = 1 ;
            }

            /* First lines are mask to cope with homemade phase unwrapping */
            for (iY = 0; iY < dY; iY++) {
                fwrite(maskLine, 1, xDim_st, mask->f) ;
            }

            /* We now compute requested mask with respect to chosen zone index */
            for (; iY < yDim - dY; iY++) {
                fread(zoneMapLine, sizeof(int unsigned), pGeoProj->files->mask->xDim, pGeoProj->files->mask->f) ;

                /* We mask left border */
                for (iX = 0; iX < dX; iX++) {
                    maskLine[iX] = 1 ;
                }
                
                for (; iX < (int)pGeoProj->files->mask->xDim + dX; iX++) {
                    maskLine[iX] = (zoneMapLine[iX] == zoneIndex)? 0 : 1 ;
                }

                /* We mask right border */
                for (; iX < xDim; iX++) {
                    maskLine[iX] = 1 ;
                }

                fwrite(maskLine, 1, xDim_st, mask->f) ;
            }

            /* Last lines are mask to cope with homemade phase unwrapping */
            for (iX = 0; iX < xDim; iX++) {
                maskLine[iX] = 1 ;
            }
            for (; iY < yDim; iY++) {
                fwrite(maskLine, 1, xDim_st, mask->f) ;
            }
            fflush(mask->f) ;

            freeVectorShort((short *)zoneMapLine, 0) ;

            freeRawFileDescriptor(pGeoProj->files->mask) ;
            pGeoProj->files->mask = mask ;
            freeVectorUChar(maskLine, 0) ;
        }
    }

    if (referenceGeoProjParams != geoProjParams) {
        setStringValForKeyIn(geoProjParams, getStringValForKeyIn(referenceGeoProjParams, "Use external DEM"), "Use external DEM") ;
        freeKeyValueList(referenceGeoProjParams) ;
    }

    free(maskPath) ;
    free(genericExtension) ;

    return(pGeoProj) ;
}


void generateESRIHeaderForGeoProjectedProductAtPath(char *aPath, geoProj *pGeoProj)
{
    char *outputPath ;
    rawFileDescriptor *outputFile ;

    outputPath = initStringWith2Strings(aPath, ".hdr") ;
    outputFile = openRawFileForWritingAtPath(outputPath) ;
    free(outputPath) ;

    if (isArchBigEndian()) {
        fprintf(outputFile->f, "BYTEORDER         M\n") ;
    }
    else {
        fprintf(outputFile->f, "BYTEORDER         I\n") ;
    }

    fprintf(outputFile->f, "LAYOUT            BIL\n") ;
    fprintf(outputFile->f, "NCOLS             %ld\n", pGeoProj->params->xDimM) ;
    fprintf(outputFile->f, "NROWS             %ld\n", pGeoProj->params->yDimM) ;
    fprintf(outputFile->f, "NBANDS            1\n") ;
    fprintf(outputFile->f, "NBITS             32\n") ;
    fprintf(outputFile->f, "PIXELTYPE         FLOAT\n") ;
    if (pGeoProj->params->isUTM) {
        fprintf(outputFile->f, "UTMZONE           %s\n", pGeoProj->params->UTMZone) ;
    }
    fprintf(outputFile->f, "ULXMAP            %lf\n", pGeoProj->frame->xMin) ;
    fprintf(outputFile->f, "ULYMAP            %lf\n", pGeoProj->frame->yMax) ;

    fprintf(outputFile->f, "XDIM              %lf\n", pGeoProj->params->xSampling) ;
    fprintf(outputFile->f, "YDIM              %lf\n", pGeoProj->params->ySampling) ;
    fprintf(outputFile->f, "NODATA            NAN\n") ;

    freeRawFileDescriptor(outputFile) ;
}



void generateENVIHeaderForGeoProjectedProductAtPath(char *aPath, geoRef *pGeoRef, geoProj *pGeoProj, InSARParametersStruct *pInSAR)
{
    char *outputPath ;
    char *aString ;
    char *description ;
    char masterTime[80], slaveTime[80] ;
    double xMin, yMax ;
    rawFileDescriptor *outputFile ;
    SLCImageInfo *master, *slave ;

    master = pInSAR->masterInfo ;
    slave = pInSAR->slaveInfo ;
    genAcquisitionTimeFromDate(master) ;
    strftime(masterTime,80,"%H:%M:%S", master->acquisitionTime_tm) ;
    genAcquisitionTimeFromDate(slave) ;
    strftime(slaveTime,80,"%H:%M:%S", slave->acquisitionTime_tm) ;

    outputPath = initStringWith2Strings(aPath, ".hdr") ;
    outputFile = openRawFileForWritingAtPath(outputPath) ;
    free(outputPath) ;

    fprintf(outputFile->f, "ENVI\n") ;
    aString = initStringWithString(outputFile->fileName) ;
    stripExtensionAtEndOfPath(aString) ;
    description = allocStringOfLength(2048) ;
    sprintf(description, "%s\nInSAR processing:\nMaster sensor = %s\tSlave sensor = %s\nMaster acquisition time = %sT%s\t Slave acquisition time = %sT%s\nHeading direction = %s", aString, master->platformName, slave->platformName, master->acquisitionDate, masterTime, slave->acquisitionDate, slaveTime, master->heading) ;
    fprintf(outputFile->f, "File type = ENVI Standard\n") ;
    fprintf(outputFile->f, "Description = {%s}\n", description) ;
    fprintf(outputFile->f, "Header offset = 0\n") ;
    fprintf(outputFile->f, "Bands = 1\n") ;
    fprintf(outputFile->f, "Data type = 4\n") ;

    if (isArchBigEndian()) {
        fprintf(outputFile->f, "byte order = 1\n") ;
    }
    else {
        fprintf(outputFile->f, "byte order = 0\n") ;
    }

    fprintf(outputFile->f, "Samples = %ld\n", pGeoProj->params->xDimM) ;
    fprintf(outputFile->f, "Lines = %ld\n", pGeoProj->params->yDimM) ;
    xMin = pGeoProj->frame->xMin - pGeoProj->params->dX * pGeoProj->params->xSampling ;
    yMax = pGeoProj->frame->yMax - pGeoProj->params->dY * pGeoProj->params->ySampling ;

    if (pGeoProj->params->isUTM) {
        fprintf(outputFile->f, "Map info = {UTM, 1.0, 1.0, ") ;
        fprintf(outputFile->f, "%lf, %lf, ", xMin, yMax) ;
        fprintf(outputFile->f, "%lf, %lf, ", pGeoProj->params->xSampling, pGeoProj->params->ySampling) ;
        fprintf(outputFile->f, "%d, ", pGeoRef->params->UTMZone->indiceZoneLonUTM) ;
        if (pGeoRef->params->UTMZone->indiceZoneLatUTM < 12) {
            fprintf(outputFile->f, "South, ") ;
        }
        else {
            fprintf(outputFile->f, "North, ") ;
        }
        fprintf(outputFile->f, "WGS84, units=Meters}\n") ;
    }
    else {
        fprintf(outputFile->f, "Map info = {Geographic Lat/Lon, 1.0, 1.0, ") ;
        fprintf(outputFile->f, "%lf, %lf, ", xMin, yMax) ;
        fprintf(outputFile->f, "%lf, %lf, ", pGeoProj->params->xSampling, pGeoProj->params->ySampling) ;
        fprintf(outputFile->f, "WGS84, units=Degrees}\n") ;
    }
    fprintf(outputFile->f, "Data ignore value = NAN\n") ;

    free(aString) ;
    free(description) ;
    freeRawFileDescriptor(outputFile) ;
}



void geoProjectInputProduct(InSARParametersStruct *pInSAR, char *geoProjDir, geoProj *pGeoProj, char *genericExtension)
{
    char *filePath, *referenceFileName, *extension ;
    int i ;
    size_t referenceFileLength ;
    CSVStruct *fileList ;

    referenceFileName = initStringWithString(pGeoProj->files->input->fileName) ;
    referenceFileLength = pGeoProj->files->input->fileLength ;
    stripAllExtensions(referenceFileName) ;
    fileList = listFilesWithNameInDir(referenceFileName, pGeoProj->files->input->directoryPath) ;

    if (fileList) {
        /* First, exclude .flip or .flop products */
        for (i = 0; i < fileList->numberOfEntries; i++) {
            extension = getPointerToLastFileExtensionInPath(fileList->stringVal[i]) ;
            if (isSubStringPresentInString(extension, "flip") || isSubStringPresentInString(extension, "flop")) {
                removeStringValAtIndexInCSVStruct(i, fileList) ;
                i-- ;
            }
        }
        for (i = 0; i < fileList->numberOfEntries; i++) {
            filePath = fileList->stringVal[i] ;
            if (fileExistsAtPath(filePath)) {
                closeRawFile(pGeoProj->files->input) ;
                setRawFilePath(pGeoProj->files->input, filePath) ;
                openRawFileForReading(pGeoProj->files->input) ;
                if (pGeoProj->files->input->fileLength == referenceFileLength) {
                    printf("\t--> %s\n", pGeoProj->files->input->fileName) ;
                    geoProjectProduct(pInSAR, geoProjDir, pGeoProj, genericExtension) ;
                }
            }
        }
    closeRawFile(pGeoProj->files->input) ;

        freeCSVStruct(fileList) ;
    }
    
    closeRawFile(pGeoProj->files->input) ;
    free(referenceFileName) ;
}

void geoProjectProduct(InSARParametersStruct *pInSAR, char *geoProjDir, geoProj *pGeoProj, char *genericExtension)
{
    char *outputFilePath, *testPath ;

    /* Create output file stream */
    outputFilePath = initStringWith3Strings(geoProjDir, pGeoProj->files->input->fileName, genericExtension) ;

    if ((pInSAR->flag & _FLIP_)) {
       testPath = initStringWith2Strings(outputFilePath, ".bil") ;
    }
    else {
        testPath = initStringWithString (outputFilePath) ;
    }

    if (!fileExistsAtPath(testPath)) {
        if((pGeoProj->files->output = openRawFileForReadingAndWritingAtPath(outputFilePath)) == NULL) {
            sprintf(ertex, "Failed to create projected file at path %s \n", outputFilePath) ;
            ase(ertex) ;
        }

        printf("\t") ;
        resamplingUsingSavedMapping(pGeoProj) ;
        closeRawFile(pGeoProj->files->output) ;
        flipGeoprojectedProduct(pInSAR, pGeoProj) ;

        freeRawFileDescriptor(pGeoProj->files->output) ;
    }
    else {
        printf("\tSkipping resampling. geoprojected file already existing.\n") ;
    }

    free(outputFilePath) ;
    free(testPath) ;
}

void flipGeoprojectedProduct(InSARParametersStruct *pInSAR, geoProj *pGeoProj)
{
    char *newFilePath ;

    if (pInSAR->flag & _FLIP_) {
        printf("\t---> Flipping data and generating ENVI header for %s\n", pGeoProj->files->output->fileName) ;
        verticalFlipOfDataOfTypeAtPath(pGeoProj->files->output->accessPath, pGeoProj->params->xDimM, pGeoProj->params->yDimM, _IN_PLACE_) ;
        if (pInSAR->flag & _ESRI_HEADER_) {
            generateESRIHeaderForGeoProjectedProductAtPath(pGeoProj->files->output->accessPath, pGeoProj) ;
        }
        else {
            generateENVIHeaderForGeoProjectedProductAtPath(pGeoProj->files->output->accessPath, pInSAR->geo, pGeoProj, pInSAR) ;
        }
        newFilePath = initStringWith2Strings(pGeoProj->files->output->accessPath, ".bil") ;
        printf("\t---> renaming file : %s\n\n", newFilePath) ;
        if (rename(pGeoProj->files->output->accessPath, newFilePath) < 0) {
            perror("Failed to rename file in \".bil\" ") ;
        }

        free(newFilePath) ;
    }
}


/* Recompute mapping if requested */
/* This must be performed if masking is applied in measurement geoprojection */
/* To prevent masking all other products, a non masked mapping is computed */
void nonMaskedMappingComputation(geoProj *pGeoProj)
{
    struct lmp *table ;

    /* If masking with slant range mask was requested it is now done. */
    if (pGeoProj->params->withMasking == 2) {
        /* So, remove mapping and recomputed it without masking in order to geoproject the other products */
        closeRawFile(pGeoProj->files->M) ;
        unlink(pGeoProj->files->M->accessPath) ;
        if(!openRawFileForReadingAndWriting(pGeoProj->files->M)) {
            ase("Failed to open/create Projection matrix file\n") ;
        }
        
        printf("\n\n---> Calculate non-masked projection map\n") ;
        pGeoProj->params->withMasking = 0 ;
        findInterveningPoints(pGeoProj) ;
        table = allocProjectionTable(pGeoProj) ;
        weightCalculation(table, pGeoProj) ;
        saveProjectionTable(table, pGeoProj) ;
        
        freeProjectionTable(table) ;
        pGeoProj->params->withMasking = 0 ;
    }
}

