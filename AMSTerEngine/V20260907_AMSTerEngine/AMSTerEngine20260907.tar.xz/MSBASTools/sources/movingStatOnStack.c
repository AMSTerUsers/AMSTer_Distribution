
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  movingStatOnStack
//
//  Created by Dominique Derauw on 28/11/21.
//  Copyright © 2021 Dominique Derauw - SAREOS. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "fileAccessLib.h"
#include "rawFileLib.h"
#include "paramLib.h"
#include "ENVIHeaderManagement.h"
#include "aoiHandling.h"
#include "projUTM.h"
#include "ellipsoid.h"
#include "matrixObjects.h"
#include "geoRefUTM.h"
#include "matrixPile.h"
#include "counters.h"

void movingStatOnStackUsage(void)  ;


int main(int argc, const char * argv[]) {
    char *directory, extension[5], **dirList ;
    char *avgDir, *sigmaDir, *medianDir, *maskDir ;
    char *filePath, *kmlPath, isRaw, itsOk ;
    char time[7] ;
    char unsigned **mask, **mask2 = NULL ;
    int testOk ;
    int i, j, k, l, N ;
    int xDim, yDim ;
    int dx, dy, xDimZone, yDimZone ;
    int date ;
    long seekVal ;
    float ***imageStack, **slice, **avg, **sigma, **median, ***kPointers ; 
    float *maxCoh, *maxSigma ;
    double xSampling, ySampling, refEasting, refNorthing ;
    point2D aPoint ;
    rawFileDescriptor *outputFile, *inputFile ;
    CSVStruct *fileList ;
    polygon *aoi = NULL, *rectangularAoI ;
    keyValue *ENVIHeader, *referenceENVIHeader ;
    UTMZoneStruct *UTMZone ;
    ellipsoid *WGS84Ellipsoid ;
    floatVector *stackColumn ;
    progressCounter *counter ;
    struct rlimit limit ;

    /* Increase the system limit number of openfiles */
    if(!getrlimit(RLIMIT_NOFILE, &limit)) {
        //        printf("rlim_cur = %llu\t rlim_max = %llu\n", limit.rlim_cur, limit.rlim_max) ;
        limit.rlim_cur = limit.rlim_max ;
        
        if(setrlimit(RLIMIT_NOFILE, &limit)) {
            printf("\n\t-/-> Failed to raise limit the maximum number of files that the process can open.\n") ;
            printf("\t---> Continuing though. Will see...\n") ;
        }
    }
    else {
        printf("\n\t-/-> Failed to raise limit the maximum number of files that the process can open.\n") ;
        printf("\t---> Continuing though. Will see...\n") ;
    }

    if (argc == 1 || isFlagPresent(argc, argv, "h")) {
        movingStatOnStackUsage() ;
    }
    if (!isDir((char *)argv[1])) {
        printf("First parameter is not a valid directory path:\n%s\n", argv[1]) ;
        movingStatOnStackUsage() ;
    }

    maxCoh = maxSigma = NULL ;
    if ((i = isArgumentPresent(argc, argv, "--mask"))) {
        genFloatNaN() ;
        if (argc > i + 1) {
            maxCoh = vectorFloat(0, 0) ;
            maxSigma = vectorFloat(0, 0) ;
            sscanf(argv[i + 1], "%f", maxCoh) ;
            maxSigma[0] = FLT_MAX ;
        }
        if (argc > i + 2) {
            sscanf(argv[i + 2], "%f", maxSigma) ;
        }
    }
 
    /* Check if we deal with raw or ENVi formatted data */
    xDim = yDim = 0 ;
    if ((i = isArgumentPresent(argc, argv, "xDim="))) {
        sscanf(argv[i] + 5, "%d", &xDim) ;
    }
    
    if ((i = isArgumentPresent(argc, argv, "yDim="))) {
        sscanf(argv[i] + 5, "%d", &yDim) ;
    }
    isRaw = (xDim && yDim)? 1 : 0 ;
    

    directory = initStringWithString((char *)argv[1]) ;
    avgDir = initStringWith2Strings(directory, "/MovingAverage") ;
    if (!isDir(avgDir)) {
        if(mkdir((const char *)avgDir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create image directory at path %s\n", avgDir) ;
            ase(ertex) ;
        }
    }
    
    sigmaDir = initStringWith2Strings(directory, "/MovingSigma") ;
    if (!isDir(sigmaDir)) {
        if(mkdir((const char *)sigmaDir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create image directory at path %s\n", sigmaDir) ;
            ase(ertex) ;
        }
    }
    medianDir = initStringWith2Strings(directory, "/MovingMedian") ;
    if (!isDir(medianDir)) {
        if(mkdir((const char *)medianDir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create image directory at path %s\n", medianDir) ;
            ase(ertex) ;
        }
    }
    
    maskDir = initStringWith2Strings(directory, "/Mask") ;
    if (!isDir(maskDir) && maxCoh) {
        if(mkdir((const char *)maskDir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create image directory at path %s\n", maskDir) ;
            ase(ertex) ;
        }
    }
    
    if (!isRaw) {
        /* Init WGS84 ellipsoid */
        if((WGS84Ellipsoid = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL) {
            perror("Failed to allocate WGS84 reference ellipsoid\n") ;
            exit(-1) ;
        }
        WGS84Ellipsoid->a = 6.378137000000000e+06 ;
        WGS84Ellipsoid->b = 6.356752314245000e+06 ; // Predefined as WGS84
        WGS84Ellipsoid->f_1 = WGS84Ellipsoid->a / (WGS84Ellipsoid->a  - WGS84Ellipsoid->b) ;
        WGS84Ellipsoid->e2 = (pow(WGS84Ellipsoid->a, 2.) - pow(WGS84Ellipsoid->b, 2.)) / pow(WGS84Ellipsoid->a, 2.) ;
        WGS84Ellipsoid->X0 = WGS84Ellipsoid->Y0 = WGS84Ellipsoid->Z0 = 0. ;
    
        if ((fileList = listFilesWithExtensionInDir("hdr", directory)) == NULL) {
            printf("\t-/-> No ENVI header .hdr file found in input directory\n") ;
            movingStatOnStackUsage() ;
        }
    
        /* We consider the first header as the reference one to get main parameters */
        if((referenceENVIHeader = readENVIHeader(fileList->stringVal[0])) == NULL) {
            perror("Failed to read ENVI header") ;
            return (-1) ;
        }
        xDim = xDimZone = getIntValForKeyIn(referenceENVIHeader, "samples") ;
        yDim = yDimZone = getIntValForKeyIn(referenceENVIHeader, "lines") ;
        xSampling = getDoubleValForKeyIn(referenceENVIHeader, "X sampling") ;
        ySampling = getDoubleValForKeyIn(referenceENVIHeader, "Y sampling") ;
        refEasting = getDoubleValForKeyIn(referenceENVIHeader, "Easting") ;
        refNorthing = getDoubleValForKeyIn(referenceENVIHeader, "Northing") ;
        
        /* Clean file listing keeping only files sharing the same header */
        for ( i = 0; i < fileList->numberOfEntries; i++) {
            if((ENVIHeader = readENVIHeader(fileList->stringVal[i])) == NULL) {
                perror("Failed to read ENVI header") ;
                return (-1) ;
            }
            testOk = (xDim == getIntValForKeyIn(ENVIHeader, "samples")) ;
            testOk &= (yDim == getIntValForKeyIn(ENVIHeader, "lines")) ;
            testOk &= (xSampling == getIntValForKeyIn(ENVIHeader, "X sampling")) ;
            testOk &= (ySampling == getIntValForKeyIn(ENVIHeader, "Y sampling")) ;
            testOk &= (refEasting == getIntValForKeyIn(ENVIHeader, "Easting")) ;
            testOk &= (refNorthing == getIntValForKeyIn(ENVIHeader, "Northing")) ;
            if (!testOk) {
                removeStringValAtIndexInCSVStruct(i, fileList) ;
                i-- ;
            }
            freeKeyValueList(ENVIHeader) ;
        }
        
        /* Determine area of interest */
        dx = dy = 0 ;
        i = 2 ;
        while (i < argc && !aoi) {
            aoi = getRectangularAoIFromKMLFile((char *)argv[i]) ;
            i++ ;
        }
        if(aoi) {
            convertAoIFromDeg2Rad(aoi) ;
            
            UTMZone = initUTMReferencingOnEllipsoid(WGS84Ellipsoid) ;
            aPoint.p.x = aoi->P[0].x ;
            aPoint.p.y = aoi->P[0].y ;
            UTMZoneForLonLatPoint(&aPoint, UTMZone) ;
            for (i = 0; i < aoi->N; i++) {
                lonLat2UTMOnEllipsoid(aoi->V[i], aoi->V[i] + 1, UTMZone) ;
            }
            rectangularAoI = circumscribedRectangleOfPolygon(aoi) ;
            freePolygon(aoi) ;
            aoi = rectangularAoI ;
            
            dx = (int)round((aoi->P[0].x - refEasting) / xSampling) ;
            dy = (int)round((aoi->P[0].y - refNorthing) / ySampling) + yDim ;
            dx = (dx < 0)? 0 : ((dx > xDim)? 0 : dx) ;
            dy = (dy < 0)? 0 : ((dy > yDim)? 0 : dy) ;
            xDimZone = (int)round((aoi->P[2].x - aoi->P[0].x) / xSampling) + 1 ;
            yDimZone = (int)round((aoi->P[2].y - aoi->P[0].y) / ySampling) + 1 ;
            xDimZone = (xDimZone > xDim)? xDim : xDimZone ;
            yDimZone = (yDimZone > yDim)? yDim : yDimZone ;
            refEasting += dx * xSampling ;
            dy = yDim -dy - yDimZone ;
            refNorthing -= dy * ySampling ;
            setIntValForKeyIn(referenceENVIHeader, UTMZone->indiceZoneLatUTM, "indiceZoneLatUTM") ;
            freeUTMZone(UTMZone) ;
            freePolygon(aoi) ;
        }
    }
    else {
        if ((fileList = getDirectoryListing(directory)) == NULL) {
            printf("\t-/-> No stack to process\n") ;
            movingStatOnStackUsage() ;
        }
        dx = dy = 0 ;
        xDimZone = xDim ;
        yDimZone = yDim ;

        /* Clean file listing keeping only files sharing the requested dimensions */
        for ( i = 0; i < fileList->numberOfEntries; i++) {
            if (isDir(fileList->stringVal[i])){
                removeStringValAtIndexInCSVStruct(i, fileList) ;
                i-- ;
            }
            else {
                if (!(inputFile = openRawFileForReadingAtPath(fileList->stringVal[i]))){
                    ase("\t-/-> Failed to open raw file.\n") ;
                }
                if (inputFile->fileLength != xDim * yDim * 4) {
                    printf("\t-/-> Skipping file %s.\n\tFile does not have the requested dimensions\n", fileList->stringVal[i]) ;
                    removeStringValAtIndexInCSVStruct(fileList, i) ;
                    freeRawFileDescriptor(inputFile) ;
                    i-- ;
                }
            }
        }
        if (!fileList->numberOfEntries) {
            ase("\t-/-> No files aving the requested dimensions\n") ;
        }
    }

 

    /* Determine stack size */
    N = fileList->numberOfEntries ;
    if ((testOk = isArgumentPresent(argc, argv, "N="))) {
        sscanf(argv[testOk] + 2, "%d", &N) ;
        if (maxCoh) {
            mask2 = matrixUChar(0, yDimZone - 1, 0, xDimZone - 1) ;
            for (i = 0; i < yDimZone; i++) {
                for (j = 0; j < xDimZone; j++) {
                    mask2[i][j] = 1 ;
                }
            }
        }    
    }
    
    /* Allocate image stack */
    imageStack = matrixPileFloat(-1, N - 1, 0, yDimZone - 1, 0, xDimZone - 1) ;
    slice = matrixFloat(0, yDimZone - 1, 0, xDimZone - 1) ;
    avg = matrixFloat(0, yDimZone - 1, 0, xDimZone - 1) ;
    sigma = matrixFloat(0, yDimZone - 1, 0, xDimZone - 1) ;
    median = matrixFloat(0, yDimZone - 1, 0, xDimZone - 1) ;
    if (maxCoh) {
        mask = matrixUChar(0, yDimZone - 1, 0, xDimZone - 1) ;
    }
    
    stackColumn = allocFloatVectorWithIndexes(0, N - 1) ;
    kPointers = malloc((N + 1) * sizeof(float **)) ;
    for(k = -1; k < N; k++) {
        kPointers[k + 1] = imageStack[k] ;
    }

    outputFile = allocFileDescriptor() ;
    outputFile->typeSize = 4 ;
    outputFile->xDim = xDimZone ;
    outputFile->yDim = yDimZone ;

    if (!isRaw) {
        setIntValForKeyIn(referenceENVIHeader, xDimZone, "samples") ;
        setIntValForKeyIn(referenceENVIHeader, yDimZone, "lines") ;
        setFloatValForKeyIn(referenceENVIHeader, refEasting, "Easting of reference pixel") ;
        setFloatValForKeyIn(referenceENVIHeader, refNorthing, "Northing of reference pixel") ;
    }

    /* Read the first N - 1 layers */
    for (k = 0; k < N - 1; k++) {
        if (isRaw) {
            inputFile = openRawFileForReadingAtPath(fileList->stringVal[k]) ;
        }
        else {
            stripExtensionAtEndOfPath(fileList->stringVal[k]) ;
            if(fileExistsAtPath(fileList->stringVal[k])) {
                inputFile = openRawFileForReadingAtPath(fileList->stringVal[k]) ;
            }
            else {
                filePath = initStringWith2Strings(fileList->stringVal[k], ".bin") ;
                if (!(inputFile = openRawFileForReadingAtPath(filePath))){
                    ase("\t-/-> No file found corresponding to ENVI header...\n") ;
                }
                free(filePath) ;
            }
        }
        
        for (i = 0; i < yDimZone; i++) {
            seekVal = ((i + dy) * xDim + dx) * sizeof(float) ;
            fseek(inputFile->f, seekVal, SEEK_SET) ;
            fread(imageStack[k][i], sizeof(float), xDimZone, inputFile->f) ;
        }
        freeRawFileDescriptor(inputFile) ;
    }
    
    counter = initProgressCounterWithMinMaxValue(N-1, fileList->numberOfEntries) ;
    for (k = N - 1; k < fileList->numberOfEntries; k++) {
        sprintf(extension, "%d", k - N + 1) ;

        if (isRaw) {
            inputFile = openRawFileForReadingAtPath(fileList->stringVal[k]) ;
        }
        else {
            stripExtensionAtEndOfPath(fileList->stringVal[k]) ;
            if(fileExistsAtPath(fileList->stringVal[k])) {
                inputFile = openRawFileForReadingAtPath(fileList->stringVal[k]) ;
            }
            else {
                filePath = initStringWith2Strings(fileList->stringVal[k], ".bin") ;
                if (!(inputFile = openRawFileForReadingAtPath(filePath))){
                    ase("\t-/-> No file found corresponding to ENVI header...\n") ;
                }
                free(filePath) ;
            }
        }

        for (i = 0; i < yDimZone; i++) {
            seekVal = ((i + dy) * xDim + dx) * sizeof(float) ;
            fseek(inputFile->f, seekVal, SEEK_SET) ;
            fread(imageStack[N-1][i], sizeof(float), xDimZone, inputFile->f) ;
        }
        freeRawFileDescriptor(inputFile) ;

        /* Stat computation */
        for (i = 0; i < yDimZone; i++) {
            for (j = 0; j < xDimZone; j++) {
                for (l = 0; l < N; l++) {
                    stackColumn->v[l] = imageStack[l][i][j] ;
                }
                stackColumn->histMin = stackColumn->histMax = 0 ;
                statOnVectorFloat(stackColumn) ;
                avg[i][j] = stackColumn->average ;
                sigma[i][j] = stackColumn->standardDeviation ;
                median[i][j] = stackColumn->median ;
                if (maxCoh) {
                    mask[i][j] = (isnan(median[i][j]))? floatNaN : (median[i][j] < maxCoh[0] && sigma[i][j] < maxSigma[0])? 0 : 1 ;
                    if(mask2) {
                        mask2[i][j] = (mask[i][j] && mask2[i][j]) ;
                    }
                }
            }
        }

        filePath = initStringWith3Strings(avgDir, "/avg.", extension) ;
        setRawFilePath(outputFile, filePath) ;
        openRawFileForWriting(outputFile) ;
        fwrite(avg[0], sizeof(float), xDimZone * yDimZone, outputFile->f) ;
        if (!isRaw) {
            writeENVIHeaderAtPath(filePath, referenceENVIHeader) ;
        }
        closeRawFile(outputFile) ;
        free(filePath) ;

        filePath = initStringWith3Strings(sigmaDir, "/sigma.", extension) ;
        setRawFilePath(outputFile, filePath) ;
        openRawFileForWriting(outputFile) ;
        fwrite(sigma[0], sizeof(float), xDimZone * yDimZone, outputFile->f) ;
        if (!isRaw) {
            writeENVIHeaderAtPath(filePath, referenceENVIHeader) ;
        }        closeRawFile(outputFile) ;
        free(filePath) ;

        filePath = initStringWith3Strings(medianDir, "/median.", extension) ;
        setRawFilePath(outputFile, filePath) ;
        openRawFileForWriting(outputFile) ;
        fwrite(median[0], sizeof(float), xDimZone * yDimZone, outputFile->f) ;
        if (!isRaw) {
            writeENVIHeaderAtPath(filePath, referenceENVIHeader) ;
        }        closeRawFile(outputFile) ;
        free(filePath) ;

        if (maxCoh) {
            filePath = initStringWith3Strings(maskDir, "/mask.", extension) ;
            setRawFilePath(outputFile, filePath) ;
            openRawFileForWriting(outputFile) ;
            fwrite(mask[0], sizeof(char), xDimZone * yDimZone, outputFile->f) ;
            if (!isRaw) {
                setIntValForKeyIn(referenceENVIHeader, 1,"data type") ;
                writeENVIHeaderAtPath(filePath, referenceENVIHeader) ;
                setIntValForKeyIn(referenceENVIHeader, 4,"data type") ;
            }
            closeRawFile(outputFile) ;
            free(filePath) ;
        }
        

        /* pointer rotation */
        for (l = -1; l < N - 1; l++) {
            imageStack[l] = imageStack[l + 1] ;
        }
        imageStack[l] = imageStack[-1] ;

        updatePointProgressCounterForIndex(counter, k) ;
    }
    updatePointProgressCounterForIndex(counter, k) ;

    if (mask2) {
        filePath = initStringWith2Strings(maskDir, "/mask.bin") ;
        setRawFilePath(outputFile, filePath) ;
        openRawFileForWriting(outputFile) ;
        fwrite(mask2[0], sizeof(char), xDimZone * yDimZone, outputFile->f) ;
        if (!isRaw) {
            setIntValForKeyIn(referenceENVIHeader, 1,"data type") ;
            writeENVIHeaderAtPath(filePath, referenceENVIHeader) ;
            setIntValForKeyIn(referenceENVIHeader, 4,"data type") ;
        }
        closeRawFile(outputFile) ;
        free(filePath) ;
    }


    /* Restoring kPointers */
    for(k = -1; k < N; k++) {
        imageStack[k] = kPointers[k + 1] ;
    }

    freeCSVStruct(fileList) ;
    freeMatrixFloat(slice, 0, 0) ;
    freeMatrixFloat(avg, 0, 0) ;
    freeMatrixFloat(sigma, 0, 0) ;
    freeMatrixFloat(median, 0, 0) ;
    if (maxCoh) {
        freeMatrixUChar(mask, 0, 0) ;
        free(maskDir) ;
    }
    
    freeMatrixPileFloat(imageStack, -1, 0, 0) ;
    freeFloatVector(stackColumn) ;
    free(avgDir) ;
    free(sigmaDir) ;
    if (!isRaw) {
        freeKeyValueList(referenceENVIHeader) ;
    }
    free(kPointers) ;
    freeProgressCounter(counter) ;
    freeRawFileDescriptor(outputFile) ;

    return 0;
}

void movingStatOnStackUsage(void) 
{
    printf("Usage: movingStatOnStack /pathToDir/imagesStack [kml] [N=n] --mask masxCoh [maxSigma]\n") ;
    printf("movingStatOnStack, as its name states it, computes some basic stats on a moving window acroos a stack of images.\n") ;
    printf("Computed stats are: the (moving) average, corresponding (moving) standard deviation and (moving) median images\n") ;
    printf("All images of the stack are supposed to be in ENVI format and geoprojected in UTM coordinates\n") ;
    printf("First parameter must be the path to the dir where are saved all images of the stack\n") ;
    printf("Optional parameters are:\n") ;
    printf("A kml to limit processing on a given window\n") ;
    printf("N=n where n is the number of images considered in the moving window. If not given, the whole stack is considered\n") ;
    printf("If using keyword --mask a mask will be generated setting to zero values of the median below a given threshold.\n") ;
    printf("Thiscan be combined with values also below a given sigma dispersion\n") ;
    printf("If N is used, several masks will be generated, one for each sequence of N images.\n") ;
    printf("A global mask will then be generated considering as masked pixels, those that are masked in any of the previously generated masks.\n") ;
    printf("\n") ;
    exit(0) ;
}