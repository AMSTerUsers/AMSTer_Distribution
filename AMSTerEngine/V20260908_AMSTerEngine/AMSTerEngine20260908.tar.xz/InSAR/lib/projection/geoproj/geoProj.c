
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  geoProj.c
 *  slant2GroundProj
 *
 *  Created by Dominique Derauw on 30/08/08.
 *  Copyright 2008 Dominique Derauw. All rights reserved.
 *
 */

/* This source file is based on former developments and gathers in a single library all the required function to perform Geoprojection */
/* Functions are build to be independent of the projection geometry */
/* Georeferencing files are passed as parameters and projection is performed correspondingly */


#include "geoProj.h"

void geoProjection(geoProj *gP)
{
    struct lmp		*table ;

	findInterveningPoints(gP) ;
    table = allocProjectionTable(gP) ;
    weightCalculation(table, gP) ;
    if (gP->params->flag & _SAVE_MAPPING_) {
        saveProjectionTable(table, gP) ;
    }
    if(!strncmp(&gP->params->resamplingMethod[3], "+", 1)) additiveResampling(table, gP) ;
    else resampling(table, gP) ;

    freeProjectionTable(table) ;
}


/* Finding intervening points */
void	findInterveningPoints(geoProj *gP)
{
    unsigned char	*M, radiusOk ;
    int unsigned iX, iY, pourvingt = 0 ;
    int		k, l, xMin, xMax, yMin, yMax, mapIndex ;
    long unsigned volume ;
    float	baRatio, a2, yEll ;
    float	*X, *Y, *Z ;
    float   *xR, *yR, xRadius, yRadius ;
	geoProjPar *proj ;
	rawFileDescriptor *xRef, *yRef, *DEM ;
    rawFileDescriptor *xRFile, *yRFile ;

    printf("\n\t--->Looking for intervening points...") ;

	proj = gP->params ;
    xRef = gP->files->xRef ;
    yRef = gP->files->yRef ;
    xRFile = gP->files->xRadius ;
    yRFile = gP->files->yRadius ;
	DEM = gP->files->DEM ;
    radiusOk = (xRFile && yRFile) ;

    /* Local memory allocation */
    M = vectorUChar(0, proj->xDimM * proj->yDimM - 1) ;
    X = vectorFloat(0, xRef->xDim - 1) ;
    Y = vectorFloat(0, yRef->xDim - 1) ;
	Z = vectorFloat(0, xRef->xDim - 1) ;
    xR = yR = NULL ;
    if (radiusOk) {
        xR = vectorFloat(0, xRFile->xDim - 1) ;
        yR = vectorFloat(0, yRFile->xDim - 1) ;
    }

    /* Initialization */
    for(iX = 0; iX < xRef->xDim; iX++) Z[iX] = 0. ;
    for(iX = 0; iX < proj->xDimM * proj->yDimM; iX++) M[iX] = 0 ;
    volume = 0 ;                                                                      // Projection Matrice volume

    /* Files rewind */
    if(fseek(xRef->f, 0L, SEEK_SET)) {                                                      // fseek retourne la valeur 0 s'il réussit et une valeur non-nulle sinon.
        ase("Fail to seek into X referencing file") ;
    }
    if(fseek(yRef->f, 0L, SEEK_SET))
        ase("Fail to seek into Y referencing file") ;
    if (radiusOk) {
        if(fseek(xRFile->f, 0L, SEEK_SET))
            ase("Fail to seek into X radius file") ;
        if(fseek(yRFile->f, 0L, SEEK_SET))
            ase("Fail to seek into Y radius file") ;
    }

    for(iY = 0; iY < xRef->yDim; iY++) {
        if (fread((float *)X, sizeof(float), xRef->xDim, xRef->f) != xRef->xDim) {          // Lecture longitude
            ase("Failed to read X referencing file") ;
        }
        if (fread((float *)Y, sizeof(float), yRef->xDim, yRef->f) != xRef->xDim) {          // Lecture latitude
            ase("Failed to read Y referencing file") ;
        }

        if (radiusOk) {
            if (fread((float *)xR, sizeof(float), xRFile->xDim, xRFile->f) != xRFile->xDim) {          // X radius reading
                ase("Failed to read X radius file") ;
            }
            if (fread((float *)yR, sizeof(float), yRFile->xDim, yRFile->f) != yRFile->xDim) {          // Y radius reading
                ase("Failed to read Y radius file") ;
            }
        }

		if(proj->isDEMPresent) {                                                            // Lecture hauteur
			fseek(DEM->f, iY * DEM->xDim * sizeof(float), SEEK_SET) ;
            if (fread((float *)Z, sizeof(float), DEM->xDim, DEM->f) != DEM->xDim) {
                ase("Failed to read DEM file") ;
            }
		}

#pragma omp parallel num_threads(maxThreads)
#pragma omp for schedule(auto) private(xRadius, yRadius, baRatio, a2, xMin, xMax, yEll, yMin, yMax, k, l) reduction (+: volume )

        for(iX = 0; iX < xRef->xDim; iX++) {
            if(!areFloatValsEquals(X[iX], proj->DEMExcludingValue) 
            && !areFloatValsEquals(Z[iX], proj->DEMExcludingValue) 
            && (Z[iX] >= proj->minVal) && 
            (Z[iX] <= proj->maxVal)) {        // minVal et maxVal définissent un intervalle de hauteur en dehors duquel les points ne sont pas géoprojetés.
                X[iX] -= gP->frame->xMin ;                                                                   // On soustrait la valeur de la coordonnées minimale
                Y[iX] -= gP->frame->yMin ;

                /* Radii selection */
                if (radiusOk) {
                    xRadius = (areFloatValsEquals(xR[iX], proj->DEMExcludingValue))? proj->xRadius : xR[iX] ;
                    yRadius = (areFloatValsEquals(yR[iX], proj->DEMExcludingValue))? proj->yRadius : yR[iX] ;
                }
                else {
                    xRadius = proj->xRadius ;
                    yRadius = proj->yRadius ;
                }

                baRatio = yRadius / xRadius ;                                               // xRadius et yRadius sont les dimensions de la zone (ellipse) dans laquelle on cherche les intervening points.
                a2 = pow(xRadius, 2.) ;

                xMin = divr(X[iX] - xRadius, proj->xSampling).q ;                                  // divr = division modulaire (quotient et reste)
                xMax = divr(X[iX] + xRadius, proj->xSampling).q ;                                      // Bornes en x de l'ellipse de recherche des intervening points
                for(k = xMin ; k <= xMax ; k++) {
                    if((k >= 0) && (k < (int)proj->xDimM)) {
                        yEll = baRatio * sqrtf(a2 - powf(X[iX] - k * proj->xSampling, 2.)) ;
                        yMin = divr(Y[iX] - yEll, proj->ySampling).q ;                                   // Bornes en y (dépendantes de la valeur de x) de l'ellipse de recherche des intervening points dans la grille finale
                        yMax = divr(Y[iX] + yEll, proj->ySampling).q ;
                        for(l = yMin; l <= yMax; l++) {

                            /* We find the first intervening points up to maxNumberOfInterveningPoints */
                            if((l >= 0) && (l < (int)proj->yDimM)) {
                                mapIndex = l * proj->xDimM + k ;
#pragma omp critical (geoProjInterveningPointCount)
{
                                if (M[mapIndex] < proj->maxNumberOfInterveningPoints) {
                                    M[mapIndex]++ ;                                                  // Chaque point de la grille finale contenu dans l'ellipse est incrémenté. M est la matrice de comptage des intervening points pour chaque points de la grille finale.
                                    volume ++ ;                                                           // volume donne le nombre total d'intervening points
                                }
}
                            }
                        }
                    }
                }
            }
        }
        if(20 * (iY + 1) / xRef->yDim > pourvingt) {                                                         // Pour montrer la progression de la recherche
            pourvingt = 20 * (iY + 1) / xRef->yDim ;
            printf(".") ;
            fflush(stdout) ;
        }
    }
    proj->volume = volume ;
    if (gP->files->M->f != NULL) {                                                                          // On écrit la matrice de projection M dans le fichier correspondant
        fseek(gP->files->M->f, 0L, SEEK_SET) ;
        fwrite((unsigned char *)M, sizeof(unsigned char), proj->yDimM * proj->xDimM, gP->files->M->f) ;
        fflush(gP->files->M->f) ;
    }
    printf("\n") ;

    freeVectorFloat(X, 0) ;
    freeVectorFloat(Y, 0) ;
    freeVectorFloat(Z, 0) ;
    freeVectorUChar(M, 0) ;
    if (radiusOk) {
        freeVectorFloat(xR, 0) ;
        freeVectorFloat(yR, 0) ;
    }
}


/* Allocation of the projection table */
struct lmp	*allocProjectionTable(geoProj *gP)
{
    struct lmp	*m ;

    printf("\t---> Projection table allocation: ") ;

    if((m = (struct lmp *)calloc((unsigned)gP->params->volume, sizeof(struct lmp))) == NULL) {
        perror("\t-/-> Projection table allocation error") ;
        exit(-1) ;
    }
    printf("\t ---> Total number of intervening points = %ld\n\t\t\tCorresponding allocated memory = %ld\n", (long)gP->params->volume, gP->params->volume * sizeof(struct lmp)) ;
    return(m) ;
}


/* ----------------- Desallocation de mémoire pour la matrice de projection ----------------- */

void	freeProjectionTable(struct lmp *m)
{
    free((void *)(m)) ;
}



/* ----------------- Calcul des pondérations par inverse de la distance ----------------- */
void    weightCalculation(struct lmp *table, geoProj *gP)
{
    unsigned char	*M, *ML, radiusOk ;
    int unsigned iX, iY, pourcent = 0 ;
	char	isID, isGauss, isLorentz ;
    int		k, ik, l, xMin, xMax, yMin, yMax, mapIndex ;
    int ompCheck ;
    int unsigned *MC ;
    long unsigned indice, *MD ;
    float	baRatio, a2, yEll ;
    float	*X, *Y, *Z, nX, nY ;
    float   *xR, *yR, xRadius, yRadius ;
    double	distance, dx, dy, bx = 0.0, by = 0.0 ;
	geoProjPar	*proj ;
	rawFileDescriptor *xRef, *yRef, *DEM ;
    rawFileDescriptor *xRFile, *yRFile ;

    printf("\t---> Weights calculation:\n") ;

	proj = gP->params ;
	xRef = gP->files->xRef ;
	yRef = gP->files->yRef ;
    xRFile = gP->files->xRadius ;
    yRFile = gP->files->yRadius ;
	DEM = gP->files->DEM ;
    radiusOk = (xRFile && yRFile) ;

    M = vectorUChar(0, proj->xDimM * proj->yDimM - 1) ;         /* The counting matrix (will be rebuild to register exactly the same intervening point sequence */
    ML = vectorUChar(0, proj->xDimM - 1) ;
    MC = vectorIntUnsigned(0, proj->xDimM * proj->yDimM - 1) ;
    MD = vectorLongUnsigned(0, proj->yDimM) ;

    /* Rewind counting matrix file */
    fseek(gP->files->M->f, 0L, SEEK_SET) ;

    /* Compute cumulated index for indexing the whole mapping */
    ik = MD[0] = 0 ;
    for(iY = 0; iY < proj->yDimM; iY++) {
        fread((unsigned char *)ML, sizeof(unsigned char), proj->xDimM, gP->files->M->f) ;                                  // ML lit une par une les lignes de la matrice de projection M
        MC[ik] = 0 ;
        for(iX = 1; iX < proj->xDimM; iX++) {
            MC[ik + iX] = MC[ik + iX - 1] + ML[iX - 1] ;
        }
        ik += proj->xDimM ;
        MD[iY + 1] = MD[iY] + MC[ik - 1] + ML[proj->xDimM - 1];
    }
    freeVectorUChar(ML, 0) ;

    /* Local memory allocation */
    X = vectorFloat(0, xRef->xDim - 1) ;                                                            // Matrice longitude
    Y = vectorFloat(0, yRef->xDim - 1) ;                                                            // Matrice latitude
	Z = vectorFloat(0, xRef->xDim - 1) ;                                                                        // Matrice hauteur
    xR = yR = NULL ;
    if (radiusOk) {
        xR = vectorFloat(0, xRFile->xDim - 1) ;
        yR = vectorFloat(0, yRFile->xDim - 1) ;
    }

    /* Initialization */
    for(iX = 0; iX < xRef->xDim; iX++) Z[iX] = 0. ;

    /* Files rewind */
    if(fseek(xRef->f, 0L, SEEK_SET)) {                                                      // fseek retourne la valeur 0 s'il réussit et une valeur non-nulle sinon.
        ase("Fail to seek into X referencing file") ;
    }
    if(fseek(yRef->f, 0L, SEEK_SET))
        ase("Fail to seek into Y referencing file") ;
    if (radiusOk) {
        if(fseek(xRFile->f, 0L, SEEK_SET))
            ase("Fail to seek into X radius file") ;
        if(fseek(yRFile->f, 0L, SEEK_SET))
            ase("Fail to seek into Y radius file") ;
    }

	isID = !strncmp(proj->weightingMethod, "ID", 2) ;
	isGauss = !strncmp(proj->weightingMethod, "GA", 2) ;
	isLorentz = !strncmp(proj->weightingMethod, "LO", 2) ;

	/* If gaussian-like psf, coefficients of the gaussian are computed */
	if(isGauss) {
		bx = 2. * sqrt(log(2.)) / proj->rx3db * proj->xSampling ;                                               // ???
		by = 2. * sqrt(log(2.)) / proj->ry3db * proj->ySampling ;
	}

    for(iY = 0; iY < xRef->yDim; iY++) {
        if (fread((float *)X, sizeof(float), xRef->xDim, xRef->f) != xRef->xDim) {          // Lecture longitude
            ase("Failed to read X referencing file") ;
        }
        if (fread((float *)Y, sizeof(float), yRef->xDim, yRef->f) != xRef->xDim) {          // Lecture latitude
            ase("Failed to read Y referencing file") ;
        }

        if (radiusOk) {
            if (fread((float *)xR, sizeof(float), xRFile->xDim, xRFile->f) != xRFile->xDim) {          // X radius reading
                ase("Failed to read X radius file") ;
            }
            if (fread((float *)yR, sizeof(float), yRFile->xDim, yRFile->f) != yRFile->xDim) {          // Y radius reading
                ase("Failed to read Y radius file") ;
            }
        }

        if(proj->isDEMPresent) {
			fseek(DEM->f, iY * DEM->xDim * sizeof(float), SEEK_SET) ;
            if (fread((float *)Z, sizeof(float), DEM->xDim, DEM->f) != DEM->xDim) {                             // Lecture ligne DEM (hauteur)
                ase("Failed to read DEM file") ;
            }
		}

#pragma omp parallel num_threads(maxThreads)
#pragma omp for schedule(auto) private(xRadius, yRadius, baRatio, a2, xMin, xMax, yEll, yMin, yMax, k, l, indice, nX, nY, dx, dy, distance, mapIndex, ompCheck)
        for(iX = 0; iX < xRef->xDim; iX++) {
			if(!areFloatValsEquals(X[iX], proj->DEMExcludingValue) 
            && !areFloatValsEquals(Z[iX], proj->DEMExcludingValue) 
            && (Z[iX] >= proj->minVal) 
            && (Z[iX] <= proj->maxVal)) {
                X[iX] -= gP->frame->xMin ;
                Y[iX] -= gP->frame->yMin ;

                /* Radii selection */
                if (radiusOk) {
                    xRadius = (areFloatValsEquals(xR[iX], proj->DEMExcludingValue))? proj->xRadius : xR[iX] ;
                    yRadius = (areFloatValsEquals(yR[iX], proj->DEMExcludingValue))? proj->yRadius : yR[iX] ;
                }
                else {
                    xRadius = proj->xRadius ;
                    yRadius = proj->yRadius ;
                }

                baRatio = yRadius / xRadius ;                                               // xRadius et yRadius sont les dimensions de la zone (ellipse) dans laquelle on cherche les intervening points.
                a2 = powf(xRadius, 2.) ;

                xMin = divr(X[iX] - xRadius, proj->xSampling).q ;                                  // divr = division modulaire (quotient et reste)
                xMax = divr(X[iX] + xRadius, proj->xSampling).q ;                                      // Bornes en x de l'ellipse de recherche des intervening points

                nX = X[iX] / proj->xSampling ;
                nY = Y[iX] / proj->ySampling ;

                /* We look for all target point within the ellipse around starting point (i,j) */
                for(k = xMin ; k <= xMax ; k++) {
                    if((k >= 0) && (k < (int)proj->xDimM)) {
                        yEll = baRatio * sqrt(a2 - pow(X[iX] - k * proj->xSampling, 2.)) ;
                        yMin = divr(Y[iX] - yEll, proj->ySampling).q ;
                        yMax = divr(Y[iX] + yEll, proj->ySampling).q ;
                        for(l = yMin; l <= yMax; l++) {
                            if((l >= 0) && (l < (int)proj->yDimM)) {
                                mapIndex = l * proj->xDimM + k ;
                                ompCheck = 0 ;
#pragma omp critical (geoProjInterveningPointWeight)    /* M[mapIndex] must be protected in case un other thread is indexing it. Test is done to check this thread indexed it */
{
                                if (M[mapIndex] < proj->maxNumberOfInterveningPoints) {
                                    M[mapIndex]++ ;
                                    indice = MD[l] + MC[mapIndex] ;
                                    MC[mapIndex]++ ;
                                    ompCheck = 1 ;
                                }
}
                                if(ompCheck) {
                                    dx = nX - k ;
                                    dy = nY - l ;
                                    distance = sqrt(pow(dx, 2.) + pow(dy, 2)) ;

                                    table[indice].l = iY ;
                                    table[indice].m = iX ;
                                    if(isID) table[indice].p = (float)(1. / pow(distance + proj->smoothingFactor, proj->exponent)) ;
                                    if(isLorentz) table[indice].p = (float)(1./(1. + pow(distance/proj->HWHM, 2.))) ;
                                    if(isGauss) table[indice].p = (float)(PI/4. / bx / by * (erf(bx * (dx + .5)) - erf(bx * (dx - .5))) * (erf(by * (dy + .5)) - erf(by * (dy - .5)))) ;
                                }
                            }
                        }
                    }
                }
            }
        }
        if(100 * (iY + 1) / xRef->yDim > pourcent) {
            pourcent = 100 * (iY + 1) / xRef->yDim ;
            printf("%2d%%  ", pourcent) ;
            if(pourcent == 10 * (pourcent / 10)) printf("\n") ;
            fflush(stdout) ;
        }
    }
    printf("\n") ;

    freeVectorUChar(M, 0) ;
    freeVectorIntUnsigned(MC, 0) ;
    freeVectorLongUnsigned(MD, 0) ;
    freeVectorFloat(X, 0) ;
    freeVectorFloat(Y, 0) ;
    freeVectorFloat(Z, 0) ;
    if (radiusOk) {
        freeVectorFloat(xR, 0) ;
        freeVectorFloat(yR, 0) ;
    }
}


/* Resampling */
void    resampling(struct lmp *table, geoProj *gP)
{
    unsigned char	*M, isAVG, isNN, isTRI ;
    int unsigned iX, iY, pourvingt = 0 ;
    int	k ;
    long unsigned indice ;
    float		*res, **X, **Y, norm, **source, val ;
	geoProjPar *proj ;
	rawFileDescriptor	*input, *output, *xRef, *yRef ;

	proj = gP->params ;
	input = gP->files->input ;                                                                                                  // input = slant range DEM
	output = gP->files->output ;
	xRef = gP->files->xRef ;
	yRef = gP->files->yRef ;

    isTRI = !strncmp(proj->resamplingMethod, "TRI", 3) ;                                                                        // Triangulation method
    isAVG = !strncmp(proj->resamplingMethod, "AV", 2) ;                                                                         // Weighted average
    isNN = !strncmp(proj->resamplingMethod, "NN", 2) ;                                                                          // Nearest neighbour
    if (!isTRI && !isAVG && !isNN) {
        isTRI = 1 ;
    }
    if(isTRI ) {
        fseek(xRef->f, 0L, SEEK_SET) ;
        fseek(yRef->f, 0L, SEEK_SET) ;
        X = matrixFloat(0, xRef->yDim - 1, 0, xRef->xDim - 1) ;
        Y = matrixFloat(0, yRef->yDim - 1, 0, yRef->xDim - 1) ;
        for(iY = 0; iY < input->yDim; iY++) {
            fread((float *)X[iY], sizeof(float), xRef->xDim, xRef->f) ;
            fread((float *)Y[iY], sizeof(float), yRef->xDim, yRef->f) ;
        }
    }
    else X = Y = (float **)NULL ;

    source = readSource(gP) ;                                                                                                   // source = fichier en input = DEM
    printf("Resampling ") ;

    M = vectorUChar(0, proj->xDimM - 1) ;
    fseek(gP->files->M->f, 0L, SEEK_SET) ;
    res = vectorFloat(0, proj->xDimM - 1) ;
    indice = 0 ;
    for(iY = 0; iY < proj->yDimM; iY++) {
        if (fread((unsigned char *)M, sizeof(unsigned char), proj->xDimM, gP->files->M->f) != proj->xDimM) {
            sprintf(ertex, "projectionLib: Failed to read projection matrix file (line %d / %ld)", iY, proj->yDimM) ;
            ase(ertex) ;
        }
        for(iX = 0; iX < proj->xDimM; iX++) {
            res[iX] = gP->params->noVal ;
            norm = 0. ;
            if (isNN) {                                                                                                         // Cas de la méthode du nearest neighbour
                for(k = 0; k < M[iX]; k++) {
                    if (table[indice].p > norm) {
                        res[iX] = source[table[indice].l][table[indice].m] ;
                        norm = table[indice].p ;
                    }
                    indice ++ ;
                }
            }
            else {
                if(isTRI && (M[iX] > 2)) {
                    res[iX] = triangulation(table, indice, M[iX], iX, iY, gP, source, X, Y) ;                                       // ???
                    if(!areFloatValsEquals(res[iX], gP->params->noVal)) {
                        indice += M[iX] ;
                    }
                }
                if(isAVG || (isTRI && areFloatValsEquals(res[iX], gP->params->noVal))) {
                    res[iX] = 0 ;
                    for(k = 0; k < M[iX]; k++) {
                        val = source[table[indice].l][table[indice].m] ;
                        if (!areFloatValsEquals(val, gP->params->noVal)) {
                            res[iX] += table[indice].p * val ;
                            norm += table[indice].p ;
                        }
                        indice ++ ;
                    }
                    res[iX] = (norm)? res[iX] / norm : gP->params->noVal ;
                }
            }
        }
        if (fwrite((float *)res, sizeof(float), proj->xDimM, output->f) != proj->xDimM) {
            sprintf(ertex, "projectionLib: Failed to save projected file (processed line %d / %ld)", iY, proj->yDimM) ;
            ase(ertex) ;
        }
        if(pourvingt < (20 * (iY + 1) / proj->yDimM)) {
            pourvingt = 20 * (iY + 1) / proj->yDimM ;
            printf(".") ;
            fflush(stdout) ;
        }
    }
    printf("\n") ;
    fflush(output->f) ;

    if (isTRI) {
        freeMatrixFloat(X, 0, 0) ;
        freeMatrixFloat(Y, 0, 0) ;
    }
    
    freeVectorFloat(res, 0) ;
    freeMatrixFloat(source, 0, 0) ;
    freeVectorUChar(M, 0) ;
}


/* Resampling using saved mapping */
void    resamplingUsingSavedMapping(geoProj *gP)
{
    unsigned char	*interveningPointsCount, isAVG, isNN, isTRI ;
    size_t pourvingt = 0 , numberOfInterveningPointsForThisRow;
    size_t k, index, i, *startIndex ;
	size_t	iX, iY, seekVal ;
    float	*res, **X, **Y, norm, **source, val ;
	geoProjPar *proj ;
	rawFileDescriptor	*input, *output, *xRef, *yRef ;
	struct lmp *interveningPoint = NULL ;

	proj = gP->params ;
	input = gP->files->input ;
	output = gP->files->output ;
	xRef = gP->files->xRef ;
	yRef = gP->files->yRef ;

    isTRI = !strncmp(proj->resamplingMethod, "TRI", 3) ;
    isAVG = !strncmp(proj->resamplingMethod, "AV", 2) ;
    isNN = !strncmp(proj->resamplingMethod, "NN", 2) ;
    if (!isTRI && !isAVG && !isNN) {
        isTRI = 1 ;
    }

    if(isTRI) {
        fseek(xRef->f, 0L, SEEK_SET) ;
        fseek(yRef->f, 0L, SEEK_SET) ;
        X = matrixFloat(0, xRef->yDim - 1, 0, xRef->xDim - 1) ;
        Y = matrixFloat(0, yRef->yDim - 1, 0, yRef->xDim - 1) ;
        for(iY = 0; iY < input->yDim; iY++) {
            fread((float *)X[iY], sizeof(float), xRef->xDim, xRef->f) ;
            fread((float *)Y[iY], sizeof(float), yRef->xDim, yRef->f) ;
        }
    }
    else X = Y = (float **)NULL ;

	/* Allocation of a vector that will contain a raw of intervening point counts */
	interveningPointsCount = vectorUChar(0, proj->xDimM - 1) ;

    /* Allocation of a vector that will contain the start index of intervening points for each target point of a raw (required for omp) */
    startIndex = vectorLongUnsigned(0,  proj->xDimM - 1) ;

    source = readSource(gP) ;
    printf("Resampling ") ;

	/* Initialize seekVal for pointing on first intervening point of the considered row */
	seekVal = proj->xDimM * proj->yDimM ;
    fseek(gP->files->M->f, 0L, SEEK_SET) ;
    res = vectorFloat(0, proj->xDimM - 1) ;


    for(iY = 0; iY < proj->yDimM; iY++) {
		/* Seek at correct position into count matrix for reading */
		fseek(gP->files->M->f, (long)iY * proj->xDimM, SEEK_SET) ;
		fread(interveningPointsCount, 1, proj->xDimM, gP->files->M->f) ;

 		/* Count number of intervening points for this row and start index of intervening point for a given target */
		numberOfInterveningPointsForThisRow = interveningPointsCount[0] ;
        startIndex[0] = 0 ;
		for(iX = 1; iX < proj->xDimM; iX++) {
            numberOfInterveningPointsForThisRow += interveningPointsCount[iX] ;
            startIndex[iX] = startIndex[iX - 1] +  interveningPointsCount[iX - 1] ;
        }

		/* Allocate corresponding vector of intervening points and read it */
		interveningPoint = malloc(sizeof(struct lmp) * numberOfInterveningPointsForThisRow) ;
		fseek(gP->files->M->f, seekVal, SEEK_SET) ;
        if ((fread(interveningPoint, sizeof(struct lmp), numberOfInterveningPointsForThisRow, gP->files->M->f)) != numberOfInterveningPointsForThisRow) {
            ase("Failed to read in matrix projection file\n") ;
        }
    
        index = 0 ;

#pragma omp parallel num_threads(maxThreads)
#pragma omp for schedule(auto) private(index, norm, i, k, val)
        for(iX = 0; iX < proj->xDimM; iX++) {
            /* In case of using omp, index is private and must thus be initialized for each thread */
            index = startIndex[iX] ;

            res[iX] = gP->params->noVal ;
            norm = 0. ;
            if (isNN) {
                for(k = 0; k < interveningPointsCount[iX]; k++) {
                    if (interveningPoint[index].p > norm) {
                        res[iX] = source[interveningPoint[index].l][interveningPoint[index].m] ;
                        norm = interveningPoint[index].p ;
                    }
                    index ++ ;
                }
            }
            else {
                if(isTRI && (interveningPointsCount[iX] > 2)) {
                    res[iX] = triangulation(interveningPoint, index, interveningPointsCount[iX], iX, iY, gP, source, X, Y) ;
                    if(!areFloatValsEquals(res[iX], gP->params->noVal)) {
                        index += interveningPointsCount[iX] ;
                    }
                }
                if(isAVG || (isTRI && areFloatValsEquals(res[iX], gP->params->noVal))) {
                    res[iX] = 0 ;
                    for(k = 0; k < interveningPointsCount[iX]; k++) {
                        val = source[interveningPoint[index].l][interveningPoint[index].m] ;
                        if (!areFloatValsEquals(val, gP->params->noVal)) {
                            res[iX] += interveningPoint[index].p * val ;
                            norm += interveningPoint[index].p ;
                        }
                        index++ ;
                    }
                    res[iX] = (norm)? res[iX] / norm : gP->params->noVal ;
                }
            }
        }

		seekVal += sizeof(struct lmp) * numberOfInterveningPointsForThisRow ;
        fwrite((float *)res, sizeof(float), proj->xDimM, output->f) ;
        if(pourvingt < (20 * (iY + 1) / proj->yDimM)) {
            pourvingt = 20 * (iY + 1) / proj->yDimM ;
            printf(".") ;
            fflush(stdout) ;
        }
        if(interveningPoint != NULL) free(interveningPoint) ;
    }
    printf("\n") ;
    fflush(output->f) ;

    if (isTRI) {
        freeMatrixFloat(X, 0, 0) ;
        freeMatrixFloat(Y, 0, 0) ;
    }
    
    freeVectorFloat(res, 0) ;
    freeMatrixFloat(source, 0, 0) ;
    freeVectorUChar(interveningPointsCount, 0) ;
    freeVectorLongUnsigned(startIndex, 0) ;
}


/* Resampling */
/* Additive resampling considers simply that all components must be added and not averaged */
/* This is the case for resampling backscattered energy */
/* On the opposite, Heights must be averaged */
void    additiveResampling(struct lmp *table, geoProj *gP)
{
    unsigned char	*M, isAVG, isTRI ;
    int unsigned iX, iY, pourvingt = 0 ; 
    int	k, indice ;
    float		*res, **X, **Y, **source, val ;
	geoProjPar *proj ;
	rawFileDescriptor	*input, *output, *xRef, *yRef ;

	proj = gP->params ;
	input = gP->files->input ;
	output = gP->files->output ;
	xRef = gP->files->xRef ;
	yRef = gP->files->yRef ;

    isTRI = !strncmp(proj->resamplingMethod, "TRI", 3) ;                                                                        // Triangulation method
    isAVG = !strncmp(proj->resamplingMethod, "AV", 2) ;      
    if(isTRI) {
        fseek(xRef->f, 0L, SEEK_SET) ;
        fseek(yRef->f, 0L, SEEK_SET) ;
        X = matrixFloat(0, xRef->yDim - 1, 0, xRef->xDim - 1) ;
        Y = matrixFloat(0, yRef->yDim - 1, 0, yRef->xDim - 1) ;
        for(iY = 0; iY < input->yDim; iY++) {
            fread((float *)X[iY], sizeof(float), xRef->xDim, xRef->f) ;
            fread((float *)Y[iY], sizeof(float), yRef->xDim, yRef->f) ;
        }
    }
    else X = Y = (float **)NULL ;

    source = readSource(gP) ;
    printf("Resampling ") ;

    M = vectorUChar(0, proj->xDimM) ;
    fseek(gP->files->M->f, 0L, SEEK_SET) ;
    fseek(output->f, 0L, SEEK_SET) ;
    res = vectorFloat(0, proj->xDimM) ;
    indice = 0 ;
    for(iY = 0; iY < proj->yDimM; iY++) {
        fread((unsigned char *)M, sizeof(unsigned char), proj->xDimM, gP->files->M->f) ;
        for(iX = 0; iX < proj->xDimM; iX++) {
            res[iX] = gP->params->noVal ;
            if(isTRI && (M[iX] > 2)) {
                res[iX] = addititveTriangulation(table, indice, M[iX], iX, iY, gP, source, X, Y) ;
                if(!areFloatValsEquals(res[iX], gP->params->noVal)) {
                    indice += M[iX] ;
                }
            }
            if(isAVG || (isTRI && areFloatValsEquals(res[iX], gP->params->noVal))) {
                    res[iX] = 0 ;
                    for(k = 0; k < M[iX]; k++) {
                        val = source[table[indice].l][table[indice].m] ;
                        if (!areFloatValsEquals(val, gP->params->noVal)) {
                            res[iX] += table[indice].p * val ;
                        }
                        indice ++ ;
                    }
                    res[iX] = (res[iX])? res[iX] : gP->params->noVal ;
            }
        }
        fwrite((float *)res, sizeof(float), proj->xDimM, output->f) ;
        if(pourvingt < (20 * (iY + 1) / proj->yDimM)) {
            pourvingt = 20 * (iY + 1) / proj->yDimM ;
            printf(".") ;
            fflush(stdout) ;
        }
    }
    printf("\n") ;
    fflush(output->f) ;

    freeVectorFloat(res, 0) ;
    freeMatrixFloat(source, 0, 0) ;
    freeVectorUChar(M, 0) ;
}



/* interpolation par triangulation */
float	triangulation(struct lmp *table, long unsigned tableIndex, unsigned char M, int iX, int iY, geoProj *gP, float **source, float **X, float **Y)
{
    int		i, j, k ;
    long unsigned ii, ij, ik ;
    float	Z1, Z2, Z3, weighting, norm ;
    float	X0, Y0, X1, Y1, X2, Y2, X3, Y3, C1, C2, C3, determinant ;
    float	res, val ;

    X0 = iX * gP->params->xSampling + gP->frame->xMin ;
    Y0 = iY * gP->params->ySampling + gP->frame->yMin ;
    res = 0 ;
    norm = 0. ;
    for(i = 0; i < M - 2; i++) {
        ii = tableIndex + i ;
        Z1 = source[table[ii].l][table[ii].m] ;
        X1 = X[table[ii].l][table[ii].m] - X0 ;
        Y1 = Y[table[ii].l][table[ii].m] - Y0 ;
        for(j = i + 1; j < M - 1; j++) {
            ij = tableIndex + j ;
            Z2 = source[table[ij].l][table[ij].m] ;
            X2 = X[table[ij].l][table[ij].m] - X0 ;
            Y2 = Y[table[ij].l][table[ij].m] - Y0 ;
            C3 = X1 * Y2 - X2 * Y1 ;
            for(k = j + 1; k < M; k++) {
                ik = tableIndex + k ;
                Z3 = source[table[ik].l][table[ik].m] ;
                X3 = X[table[ik].l][table[ik].m] - X0 ;
                Y3 = Y[table[ik].l][table[ik].m] - Y0 ;
                weighting = table[ii].p * table[ij].p * table[ik].p ;
                C1 = X2 * Y3 - X3 * Y2 ;
                C2 = X3 * Y1 - X1 * Y3 ;
                determinant = C1 + C2 + C3 ;
                if(isIncludedInTriangle(C3, C1, C2)) {
                    val = C1 * Z1 + C2 * Z2 + C3 * Z3 ;
                    if (!areFloatValsEquals(val, gP->params->noVal)) {
                        res += weighting * val / determinant ;
                        norm += weighting ;
                    }
                }
            }
        }
    }
    res = (norm)? res / norm : gP->params->noVal ;

    return res ;
}

/* interpolation par triangulation */
/* Additive Triangulation is the complement to additiveResampling, considering estimated values must be added and not averaged */
float	addititveTriangulation(struct lmp *table, long unsigned tableIndex, unsigned char M, int iX, int iY, geoProj *gP, float **source, float **X, float **Y)
{
    int		i, j, k ;
    long unsigned ii, ij, ik ;
    float	Z1, Z2, Z3, weighting ;
    float	X0, Y0, X1, Y1, X2, Y2, X3, Y3, C1, C2, C3, determinant ;
    float	res, val ;

    X0 = iX * gP->params->xSampling + gP->frame->xMin ;
    Y0 = iY * gP->params->ySampling + gP->frame->yMin ;
    res = 0 ;

    for(i = 0; i < M - 2; i++) {
        ii = tableIndex + i ;
        X1 = X[table[ii].l][table[ii].m] - X0 ;
        Y1 = Y[table[ii].l][table[ii].m] - Y0 ;
        Z1 = source[table[ii].l][table[ii].m] ;
        for(j = i + 1; j < M - 1; j++) {
            ij = tableIndex + j ;
            X2 = X[table[ij].l][table[ij].m] - X0 ;
            Y2 = Y[table[ij].l][table[ij].m] - Y0 ;
            Z2 = source[table[ij].l][table[ij].m] ;
            C3 = X1 * Y2 - X2 * Y1 ;
            for(k = j + 1; k < M; k++) {
                ik = tableIndex + k ;
                X3 = X[table[ik].l][table[ik].m] - X0 ;
                Y3 = Y[table[ik].l][table[ik].m] - Y0 ;
                Z3 = source[table[ik].l][table[ik].m] ;
                weighting = table[ii].p * table[ij].p * table[ik].p ;
                C1 = X2 * Y3 - X3 * Y2 ;
                C2 = X3 * Y1 - X1 * Y3 ;
                determinant = C1 + C2 + C3 ;
//                if((fabs(determinant) > limite) && appartenanceAuTriangle(C3, C1, C2)) {
                if(isIncludedInTriangle(C3, C1, C2)) {
                    val = C1 * Z1 + C2 * Z2 + C3 * Z3 ;
                    if (!areFloatValsEquals(val, gP->params->noVal)) {
                        res += weighting * val / determinant ;
                    }
                }
            }
        }
    }
    if (!res) {
        res = gP->params->noVal ;
    }
    
    return res ;
}

char	isIncludedInTriangle(double C1, double C2, double C3)
{
    char	res = 0 ;
    double	d ;

    d = C1 + C2 + C3 ;
    if (d < Chouillat) {                                /* We set a limit value to the determinant to avoid division by too small number leading to erroneous border values */
        C1 /= d ;
        C2 /= d ;
        C3 /= d ;
        res  = ((C1 >= 0.) && (C1 <= 1.))? 1 : 0 ;
        res *= ((C2 >= 0.) && (C2 <= 1.))? 1 : 0 ;
        res *= ((C3 >= 0.) && (C3 <= 1.))? 1 : 0 ;
    }

    return res ;                                                        // Si res = 1 le point est inclus dans le triangle, si res = 0 alors le point n'est pas inclus dans le triangle
}



float	**readSource(geoProj *gP)
{
    int unsigned iY ;
    int dX, dY, xDim, yDim ;
    float **source ;
    size_t seekVal ;

    /* Source file will be read and crop or extended to fit with DEM file */
    xDim = gP->files->DEM->xDim ;
    yDim = gP->files->DEM->yDim ;
    source = matrixFloat(0, yDim - 1, 0, xDim - 1) ;

    /* Rewind input file */
    if (fseek(gP->files->input->f, 0, SEEK_SET)) {
        ase("projectionLib: Failed to seek into source file") ;
    }

    /* Source files is considered as centred on DEM one */
    dX = (xDim - (int)gP->files->input->xDim) / 2 ;
    dY = (yDim - (int)gP->files->input->yDim) / 2 ;

    /* If dX and dY are smaller than zero, then, input is bigger than reference DEM */
    seekVal = 0 ;
    if (dX < 0 || dY < 0) {
        for(iY = 0; iY < yDim; iY++) {
            /* Seek into input file */
            seekVal = ((iY - dY) * gP->files->input->xDim - dX) * sizeof(float) ;
            if (fseek(gP->files->input->f, seekVal, SEEK_SET)) {
                ase("projectionLib: Failed to seek into source file") ;
            }

            /* Read line of data */
            if(fread((float *)source[iY], sizeof(float), xDim, gP->files->input->f) != xDim) {
                ase("projectionLib: Failed to read source file") ;
            }
        }
    }
    else {
        /* dimensions of input file are smaller or equal to the ones of the reference DEM */
        xDim = gP->files->input->xDim ;
        yDim = gP->files->input->yDim ;

        if (fseek(gP->files->input->f, seekVal, SEEK_SET)) {
            ase("projectionLib: Failed to seek into source file") ;
        }
        for(iY = 0; iY < yDim; iY++) {
            /* Read line of data */
            if(fread(source[iY + dY] + dX, sizeof(float), xDim, gP->files->input->f) != xDim) {
                printf("\nFailed to read source file:\n") ;
                printf("Source file name: %s\n", gP->files->input->fileName) ;
                printf("Source file directory: %s\n", gP->files->input->directoryPath) ;
                ase("I have to quit. Sorry... \n") ;
            }
        }
    }

    return source ;
}

/* geoProj structure allocation */
geoProj *allocGeoProj(void)
{
	geoProj *p ;

	if((p = malloc(sizeof(geoProj))) == NULL) {
		perror("Failed to allocate geoProj pointer") ;
		exit(-1) ;
	}

	if((p->params = malloc(sizeof(geoProjPar))) == NULL) {
		perror("Failed to allocate geoProjPar pointer") ;
		exit(-1) ;
	}

	if((p->frame = (geoProjFrame *)malloc(sizeof(geoProjFrame))) == NULL) {
		perror("Failed to allocate geoProjPar pointer") ;
		exit(-1) ;
	}
	p->frame->xMin = p->frame->xMax = p->frame->yMin = p->frame->yMax = 0.0 ;

	if((p->files = (geoProjFiles *)malloc(sizeof(geoProjFiles))) == NULL) {
		perror("Failed to allocate geoProjPar pointer") ;
		exit(-1) ;
	}
	p->files->input = NULL ;
	p->files->output = NULL ;
	p->files->DEM = NULL ;
    p->files->xRef = NULL ;
    p->files->yRef = NULL ;
    p->files->xRadius = NULL ;
    p->files->yRadius = NULL ;
	p->files->M = NULL ;
	p->files->IM = NULL ;
	p->files->mask = NULL ;
    p->files->geoProjDir = NULL ;
    p->files->genericExtension = NULL ;

    p->params->verticalFlip = 0 ;
    p->params->minVal = -9999 ;
    p->params->maxVal = 9999 ;
    p->params->isUTM = 0 ;
    p->params->isDEMPresent = 0 ;
    p->params->withMasking = 0 ;
    p->params->maxNumberOfInterveningPoints = 255 ;
    p->params->flag = 0 ;

	return(p) ;
}

void freeGeoProj(geoProj *p)
{
	if(p->params) {
        if (p->params->resamplingMethod) {
            free(p->params->resamplingMethod) ;
            p->params->resamplingMethod = NULL ;
        }

        if (p->params->weightingMethod) {
            free(p->params->weightingMethod) ;
            p->params->weightingMethod = NULL ;
        }

		free(p->params) ;
		p->params = NULL ;
	}

	if(p->files) {
        if (p->files->geoProjDir) {
            free(p->files->geoProjDir) ;
			p->files->geoProjDir = NULL ;
        }
        if (p->files->genericExtension) {
            free(p->files->genericExtension) ;
			p->files->genericExtension = NULL ;
        }
		if(p->files->input) {
			freeRawFileDescriptor(p->files->input) ;
			p->files->input = NULL ;
		}
		if(p->files->output) {
			freeRawFileDescriptor(p->files->output) ;
			p->files->output = NULL ;
		}
		if(p->files->DEM) {
			freeRawFileDescriptor(p->files->DEM) ;
			p->files->DEM = NULL ;
		}
        if(p->files->xRef) {
            freeRawFileDescriptor(p->files->xRef) ;
            p->files->xRef = NULL ;
        }
        if(p->files->yRef) {
            freeRawFileDescriptor(p->files->yRef) ;
            p->files->yRef = NULL ;
        }
        if(p->files->xRadius) {
            freeRawFileDescriptor(p->files->xRadius) ;
            p->files->xRadius = NULL ;
        }
        if(p->files->yRadius) {
            freeRawFileDescriptor(p->files->yRadius) ;
            p->files->yRadius = NULL ;
        }
		if(p->files->mask) {
			freeRawFileDescriptor(p->files->mask) ;
			p->files->mask = NULL ;
		}
		if(p->files->M) {
			freeRawFileDescriptor(p->files->M) ;
			p->files->M = NULL ;
		}
		if(p->files->IM) {
			freeRawFileDescriptor(p->files->IM) ;
			p->files->IM = NULL ;
		}
		free(p->files) ;
		p->files = NULL ;
	}

	if(p->frame) {
		free(p->frame) ;
		p->frame = NULL ;
	}

	free(p) ;
}


/* ----------------- Inverse projection matrix computation and saving ----------------- */
/* The inverse transform is simply computed sequencially, point by points, finding intervening points sequentially */
/* It is saved along with the matrix of the count of intervening points, which is computed in the same time */
/* No ordering process of intervening points is required like for computing the direct projection matrix */
void inverseProjectionMatrixComputation(geoProj *gP)
{
    unsigned char	**countMatrix, *mask ;
	char	isID, isGauss, isLorentz ;
    int unsigned iX, iY, pourcent = 0 ;
    int unsigned maxIndexOfInterveningPoints = 1000, curentInterveningPointIndex = 0 ;
    int		k, l, xMin, xMax, yMin, yMax ;
	long	seekVal ;
    float	baRatio, a2, yEll ;
    float	*X, *Y, *Z, nX, nY ;
    double	distance, dx, dx2, dy, bx = 0.0, by = 0.0 ;
	geoProjPar	*proj ;
	rawFileDescriptor *xRef, *yRef, *maskFile, *DEM ;
	struct lmp *table ;

    printf("Inverse matrix projection computation:\n") ;
    printf("Weights calculation:\n") ;

	proj = gP->params ;
	xRef = gP->files->xRef ;
	yRef = gP->files->yRef ;
	maskFile = gP->files->mask ;
	DEM = gP->files->DEM ;


	/* We first allocate a vector of intervening points that will be saved sequentially */
	if((table = malloc(sizeof(struct lmp) * maxIndexOfInterveningPoints)) == NULL)
		ase("Failed to allocate temporary vector of intervening points") ;
	/* Then we allocate vectors to read sequentially, the referencing files */
    X = vectorFloat(0, gP->files->input->xDim - 1) ;
    Y = vectorFloat(0, gP->files->input->xDim - 1) ;
	/* Next we allocate and initialize a vector to read sequentially the DEM if this latter is present */
	Z = vectorFloat(0, xRef->xDim - 1) ;
	for(iX = 0; iX < xRef->xDim; iX++) {
        Z[iX] = 0. ;
    }
	/* Next we allocate and initialize a vector to read sequentially the mask if this latter is present */
	mask = vectorUChar(0, xRef->xDim - 1) ;
	for(iX = 0; iX < xRef->xDim; iX++) {
        mask[iX] = 0 ;
    }
	/* Finally, we allocate and initialize the matrix for counting the intervening points */
    countMatrix = matrixUChar(0, gP->files->input->yDim - 1, 0, gP->files->input->xDim - 1) ;
    for(iY = 0; iY < gP->files->input->yDim; iY++) {
		for(iX = 0; iX < gP->files->input->xDim; iX++) {
            countMatrix[iY][iX] = 0 ;
        }
    }

    fseek(xRef->f, 0L, SEEK_SET) ;
    fseek(yRef->f, 0L, SEEK_SET) ;

	isID = !strncmp(proj->weightingMethod, "ID", 2) ;
	isGauss = !strncmp(proj->weightingMethod, "GA", 2) ;
	isLorentz = !strncmp(proj->weightingMethod, "LO", 2) ;

	/* If gaussian-like psf, coefficients of the gaussian are computed */
	if(isGauss) {
		bx = 2. * sqrt(log(2.)) / proj->rx3db * proj->xSampling ;
		by = 2. * sqrt(log(2.)) / proj->ry3db * proj->ySampling ;
	}

	/* We know the dimention of the matrix M. We thus know the seek value to start saving the inverse projection matrix */
	/* And leave place for saving the counting matrix M */
	seekVal = (long)gP->files->input->xDim * gP->files->input->yDim ;

    baRatio = proj->yRadius / proj->xRadius ;
    a2 = pow(proj->xRadius, 2.) ;
    for(iY = 0; iY < gP->files->input->yDim; iY++) {
        fread((float *)X, sizeof(float), gP->files->input->xDim, xRef->f) ;
        fread((float *)Y, sizeof(float), gP->files->input->xDim, yRef->f) ;
		if(proj->isDEMPresent) {
			fseek(DEM->f, iY * DEM->xDim * sizeof(float), SEEK_SET) ;
			fread((float *)Z, sizeof(float), DEM->xDim, DEM->f) ;
		}
		if(proj->withMasking)
			fread((float *)mask, sizeof(char unsigned), maskFile->xDim, maskFile->f) ;

        for(iX = 0; iX < gP->files->input->xDim; iX++) {
            if(!mask[iX] && !areFloatValsEquals(Z[iX], proj->DEMExcludingValue) && (Z[iX] >= proj->minVal) && (Z[iX] <= proj->maxVal)) {
                X[iX] -= gP->frame->xMin ; nX = X[iX] / proj->xSampling ;
                Y[iX] -= gP->frame->yMin ; nY = Y[iX] / proj->ySampling ;
                xMin = divr(X[iX] - proj->xRadius, proj->xSampling).q + 1 ;
                xMax = divr(X[iX] + proj->xRadius, proj->xSampling).q ;
                for(k = xMin ; k <= xMax ; k++) {
                    if((k >= 0) && (k < (int)proj->xDimM)) {
						dx = nX - k ;
                        dx2 = pow(dx, 2.) ;
                        yEll = baRatio * sqrt(a2 - pow(X[iX] - k * proj->xSampling, 2.)) ;
                        yMin = divr(Y[iX] - yEll, proj->ySampling).q + 1 ;
                        yMax = divr(Y[iX] + yEll, proj->ySampling).q ;
                        for(l = yMin; l <= yMax; l++) {
                            dy = nY - l ;
                            if((l >= 0) && (l < (int)proj->yDimM) && (countMatrix[iY][iX] < 255)) {
								/* An intervening point in (k;l) is detected, then: */
								countMatrix[iY][iX]++ ;
                                distance = sqrt(dx2 + dy * dy) ;
                                table[curentInterveningPointIndex].l = l ;
                                table[curentInterveningPointIndex].m = k ;
								if(isID) table[curentInterveningPointIndex].p = (float)(1. / pow(distance + proj->smoothingFactor, proj->exponent)) ;
								if(isLorentz) table[curentInterveningPointIndex].p = (float)(1./(1. + pow(distance/proj->HWHM, 2.))) ;
								if(isGauss) table[curentInterveningPointIndex].p = (float)(PI/4. / bx / by * (erf(bx * (dx + .5)) - erf(bx * (dx - .5))) * (erf(by * (dy + .5)) - erf(by * (dy - .5)))) ;
								curentInterveningPointIndex++ ;
								/* If maxInterveningPointIndex intervening points are found, we save them */
								if(curentInterveningPointIndex == maxIndexOfInterveningPoints) {
									fseek(gP->files->IM->f, seekVal, SEEK_SET) ;
									fwrite(table, sizeof(struct lmp), maxIndexOfInterveningPoints, gP->files->IM->f) ;
									fflush(gP->files->IM->f) ;
									seekVal += maxIndexOfInterveningPoints * sizeof(struct lmp) ;
									curentInterveningPointIndex = 0 ;
								}
							}
                        }
                    }
                }
            }
        }
        if(100 * (iY + 1) / gP->files->input->yDim > pourcent) {
            pourcent = 100 * (iY + 1) / gP->files->input->yDim ;
            printf("%2d%%  ", pourcent) ;
            if(pourcent == 10 * (pourcent / 10)) printf("\n") ;
            fflush(stdout) ;
        }
    }
	/* We flush and save the last found intervening points */
	fwrite(table, sizeof(struct lmp), curentInterveningPointIndex, gP->files->IM->f) ;
	/* Now, we save the counting matrix at the beginning of the file */
	fseek(gP->files->IM->f, 0L, SEEK_SET) ;
	fwrite(countMatrix[0], sizeof(char unsigned), gP->files->input->xDim * gP->files->input->yDim, gP->files->IM->f) ;

    freeMatrixUChar(countMatrix, 0, 0) ;
    freeVectorFloat(X, 0) ;
    freeVectorFloat(Y, 0) ;
    freeVectorFloat(Z, 0) ;
    freeVectorUChar(mask, 0) ;
	free(table) ;
    printf("\n") ;
}

long projectionTableSize(geoProj *pGeoProj)
{
    unsigned char	*ML ;
    size_t iX, iY ;

    pGeoProj->params->volume = 0 ;
	fseek(pGeoProj->files->M->f, 0L, SEEK_SET) ;
    ML = vectorUChar(0, pGeoProj->params->xDimM - 1) ;
    for(iY = 0; iY < pGeoProj->params->yDimM; iY++) {
        fread((unsigned char *)ML, sizeof(unsigned char), pGeoProj->params->xDimM, pGeoProj->files->M->f) ;
        for(iX = 0; iX < pGeoProj->params->xDimM; iX++) pGeoProj->params->volume += (long)ML[iY] ;
    }

	return(pGeoProj->params->volume) ;
}

void saveProjectionTable(struct lmp *table, geoProj *pGeoProj)
{
	fseek(pGeoProj->files->M->f, (long)pGeoProj->params->xDimM * (long)pGeoProj->params->yDimM, SEEK_SET) ;

	fwrite(table, pGeoProj->params->volume, sizeof(struct lmp), pGeoProj->files->M->f) ;
    fflush(pGeoProj->files->M->f) ;
}

struct lmp *readProjectionTable(geoProj *pGeoProj)
{
	struct lmp *table ;

	projectionTableSize(pGeoProj) ;
	table = allocProjectionTable(pGeoProj) ;
	fseek(pGeoProj->files->M->f, (long)pGeoProj->params->xDimM * (long)pGeoProj->params->yDimM, SEEK_SET) ;
	fread(table, pGeoProj->params->volume, sizeof(struct lmp), pGeoProj->files->M->f) ;

	return(table) ;
}

void roundGeoProjFrame(geoProj *pGeoProj)
{
	/* We round the frame limits with respect to the chosen sampling */
	pGeoProj->frame->xMax = pGeoProj->params->xSampling * (ceil(pGeoProj->frame->xMax / pGeoProj->params->xSampling) + pGeoProj->params->dX) ;
	pGeoProj->frame->xMin = pGeoProj->params->xSampling * (floor(pGeoProj->frame->xMin / pGeoProj->params->xSampling) + pGeoProj->params->dX) ;
	pGeoProj->frame->yMax = pGeoProj->params->xSampling * (ceil(pGeoProj->frame->yMax / pGeoProj->params->xSampling) + pGeoProj->params->dY) ;
	pGeoProj->frame->yMin = pGeoProj->params->xSampling * (floor(pGeoProj->frame->yMin / pGeoProj->params->xSampling) + pGeoProj->params->dY) ;

    pGeoProj->params->xDimM = pGeoProj->frame->dimX = (pGeoProj->frame->xMax - pGeoProj->frame->xMin) / pGeoProj->params->xSampling + 1 ;       // dimension du frame dans la grille finale
    pGeoProj->params->yDimM = pGeoProj->frame->dimY = (pGeoProj->frame->yMax - pGeoProj->frame->yMin) / pGeoProj->params->ySampling + 1 ;
}


void sortLMP(int n, struct lmp *sV, int unsigned *kV, int unsigned *lV)
{
/* Sorting routine of lmp struct vector starting from index 1 in ascending order */
    int		l, j, ir, i;
    int unsigned kVal, lVal, *kVect, *lVect ;
    struct lmp v1, *serie ;

    serie = sV - 1 ;
    kVect = kV - 1 ;
    lVect = lV - 1 ;

    l = (n >> 1) + 1 ;
    ir = n ;
    for(;;) {
        if(l>1) {
            l-- ;
            v1 = serie[l] ;
            kVal = kVect[l] ;
            lVal = lVect[l] ;
        }
        else {
            v1 = serie[ir] ;
            kVal = kVect[ir] ;
            lVal = lVect[ir] ;

            serie[ir] = serie[1] ;
            kVect[ir] = kVect[1] ;
            lVect[ir] = lVect[1] ;
            if(--ir == 1) {
                serie[1] = v1 ;
                kVect[1] = kVal ;
                lVect[1] = lVal ;
                return ;
            }
        }
        i = l ;
        j = l << 1 ;
        while(j <= ir) {
            if((j < ir) && serie[j].p < serie[j + 1].p) ++j ;
            if(v1.p < serie[j].p) {
                serie[i] = serie[j] ;
                kVect[i] = kVect[j] ;
                lVect[i] = lVect[j] ;
                j += (i=j) ;
            }
            else j = ir + 1 ;
        }
        serie[i] = v1 ;
        kVect[i] = kVal ;
        lVect[i] = lVal ;
    }

}
