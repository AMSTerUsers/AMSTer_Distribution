
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  interpol2.c
 *
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
 */

/* 
Interpolation d'une image complexe. L'interpollation proprement dite est mis sous forme d'une fonction.
Interpollation par blocs et création d'un fichier résultat "Nom.i". 
*/

#include "interpolation.h"

/* main programm start */
int interpolation(CSVStruct *csv)
{
    char *aPath = NULL, InSARParametersFileFound ;
    char *initialImageLocation, *newImageLocation ;
    int    currentDirectoryFdesc, i ;
    int maxMemAlloc ;
    double **T ;
    InSARParametersStruct    *pInSAR ;
    time_t startTime, endTime ;
    interpolationParameters *params ;
    SLCImageInfo *interpolatedSlaveInfo ;
    
    InSARParametersFileFound = 0 ;
    currentDirectoryFdesc = open(".", O_RDONLY) ;
    fchdir(currentDirectoryFdesc) ;
    
    if(isArgumentPresentInCSV(csv, "help") || isFlagPresentInCSV(csv, "h"))
        interpolationHelp() ;
    
    i = 1 ;
    while (i < csv->numberOfEntries) {
        aPath = initStringWithString(csv->stringVal[i]) ;
        if(fileExistsAtPath(aPath)) {
            InSARParametersFileFound = 1 ;
            break ;
        }
        i++ ;
    }
    if(!InSARParametersFileFound) {
        aPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
        if(!fileExistsAtPath(aPath)){
            free(aPath) ;
            aPath = initStringWithString("./InSARParameters.txt") ;
            if(!fileExistsAtPath(aPath))
                interpolationHelp() ;
        }
        InSARParametersFileFound = 1 ;
    }
    
    time(&startTime) ;
    pInSAR = readInSARParametersFileAtPath(aPath) ;

    /* Check if shifts with respect to main transform are requested */
    if ((i = isArgumentPresentInCSV(csv, "dx="))) {
        sscanf(csv->stringVal[i] + 3, "%lf", &(pInSAR->xShift)) ;
    }
    
    if ((i = isArgumentPresentInCSV(csv, "dy="))) {
        sscanf(csv->stringVal[i] + 3, "%lf", &(pInSAR->yShift)) ;
    }
    
    params = allocInterpolationParameters() ;
    params->pInSAR = pInSAR ;
    
    if((i = isArgumentPresentInCSV(csv, "M"))) {
        sscanf(csv->stringVal[i], "%*c%d", &maxMemAlloc) ;
        if (maxMemAlloc > 25 && maxMemAlloc < 36) {
            params->maxMemAlloc = maxMemAlloc ;
        }
    }
    
    /* Copy slave image structure within InSAR processing directory */
    initialImageLocation = initStringWithString(pInSAR->slaveImage->imageDirectoryPath) ;
    newImageLocation = initStringWithString(pInSAR->interpolatedSlave->imageDirectoryPath) ;
    copyCSLImage(initialImageLocation, newImageLocation, _CSLIMAGE_INFO_ | _CSLIMAGE_HEADERS_ | _CSLIMAGE_OVERWRITE_) ;
    
    /* Modify interpolated slave info to take interpolation into account */
    interpolatedSlaveInfo = readInfoImageInCSLImage(pInSAR->interpolatedSlave) ;
    interpolatedSlaveInfo->rangeResolutionCell = pInSAR->masterInfo->rangeResolutionCell ;
    interpolatedSlaveInfo->azimuthResolutionCell = pInSAR->masterInfo->azimuthResolutionCell ;
    interpolatedSlaveInfo->lineTimeInterval = pInSAR->masterInfo->lineTimeInterval ;
    interpolatedSlaveInfo->rangeSamplingFrequency = pInSAR->masterInfo->rangeSamplingFrequency ;
    memcpy(interpolatedSlaveInfo->slantRange, pInSAR->masterInfo->slantRange, 3 * sizeof(double)) ;
    memcpy(interpolatedSlaveInfo->incidenceAngle, pInSAR->masterInfo->incidenceAngle, 3 * sizeof(double)) ;
    T = combinedAffineTransform(pInSAR->slaveAffineTransform, pInSAR->masterAffineTransform) ;
    interpolatedSlaveInfo->FPAT += T[1][2] * interpolatedSlaveInfo->lineTimeInterval ;
    interpolatedSlaveInfo->LPAT -= T[1][2] * interpolatedSlaveInfo->lineTimeInterval ;
    freeMatrixDouble(T, 0, 0) ;
    saveInfoImageInCSLImage(interpolatedSlaveInfo, pInSAR->interpolatedSlave) ;
    
    if(isFlagPresentInCSV(csv, "A")) {
        interpolAllChannels(params) ;
    }
    else {
        interpolCurrentChannels(params) ;
    }
    
//    computeCommonSuperpositionOfImages(pInSAR) ;
    saveInSARParametersFileAtPath(pInSAR, aPath) ;

    freeInSARParametersStruct(pInSAR) ;
    freeInterpolationParameters(params) ;
    free(aPath) ;
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    return(0) ;
}


void interpolationHelp(void)
{
    printf("Usage:\ninterpolation [/pathTo/InSARParameters.txt] [-A]\n\n") ;
    printf("The interpolation routine will perform the complex interpolation of the slave\nimage using the affine transform given into the InSARparameters.txt file.\n") ;
    printf("\nIf used with no valid path to an InSARParameters.txt file,\n the routine will look for an \"InSARparameters.txt\" file\n") ;
    printf("within the working directory or within the ./TextFiles subdirectory.\n") ;
    printf("Any other path to a text file containing InSAR parameters can be given as\nfirst parameter.\n\n") ;
    printf("-A : All available polarization channels will be interpolated using the same transform\n");
    exit(0) ;
}

void interpolCurrentChannels(interpolationParameters *params)
{
    char *inputFilePath, *outputFilePath ;
    InSARParametersStruct    *pInSAR ;
    
    pInSAR = params->pInSAR ;
    
    /* If master image must be interpolated, we start with this one */
    if (pInSAR->masterInterpolation) {
        if (!isDir(pInSAR->interpolatedMaster->imageDirectoryPath)) {
            createCSLDirectoryStructureFor(pInSAR->interpolatedMaster, 0) ;
        }
        outputFilePath = initStringWith3Strings(pInSAR->interpolatedMaster->dataDirectoryPath, "/SLCData.", pInSAR->masterPolarizationChannel) ;
        if (!fileExistsAtPath(outputFilePath)) {
            /* Master image interpolation parameters initialization */
            params->xDimIn = params->xDimOut = (pInSAR->ima1).lenr ;
            params->yDimIn = params->yDimOut = (pInSAR->ima1).lena ;
            params->FDC[0] = pInSAR->chaz1.a0FDC ;
            params->FDC[1] = pInSAR->chaz1.a1FDC * 2. * pInSAR->rad.rangeResolutionCell / c0 ;
            params->FDC[2] = pInSAR->chaz1.a2FDC * pow(2. * pInSAR->rad.rangeResolutionCell / c0, 2.) ;
            params->PRF = (pInSAR->chaz1).PRF ;
            params->dXFDC = 0 ;
            params->verbose = 1 ;
            memcpy(params->affineTransform[0], pInSAR->masterAffineTransform[0], 6 * sizeof(double)) ;
            params->affineTransform[0][2] += params->pInSAR->xShift ;
            params->affineTransform[1][2] += params->pInSAR->yShift ;
            
            printf("\nInterpolation of the master image\n") ;
            printf("*********************************") ;
            inputFilePath = initStringWith3Strings(pInSAR->masterImage->dataDirectoryPath, "/SLCData.", pInSAR->masterPolarizationChannel) ;
            
            if((params->fIn = openRawFileForReadingAtPath(inputFilePath) ) == NULL) {
                sprintf(ertex, "Failed to open slave image file at path %s\n", inputFilePath) ;
                ase(ertex) ;
            }
            if((params->fOut = openRawFileForReadingAndWritingAtPath(outputFilePath)) == NULL) {
                sprintf(ertex, "Failed to create interpolated slave image file at path %s\n", outputFilePath) ;
                ase(ertex) ;
            }
            
            interpolationCore(params) ;
            
            freeRawFileDescriptor(params->fIn) ;
            freeRawFileDescriptor(params->fOut) ;
        }
        else {
            printf("-->\t Super Master interpolation apparently already done. Interpolated master file exists at requested path\n") ;
        }
        free(outputFilePath) ;
    }
    
    /* Slave interpolation */
    /* ******************* */
    /* First, create image container if required */
    if (!isDir(pInSAR->interpolatedSlave->imageDirectoryPath)) {
        createCSLDirectoryStructureFor(pInSAR->interpolatedSlave, 0) ;
    }
    /* Generate output file path taking selected polarization into account */
    outputFilePath = initStringWith3Strings(pInSAR->interpolatedSlave->dataDirectoryPath, "/SLCData.", pInSAR->slavePolarizationChannel) ;
    
    /* Slave image interpolation parameters initialization */
    params->xDimIn = (pInSAR->ima2).lenr ;
    params->yDimIn = (pInSAR->ima2).lena ;
    params->xDimOut = (pInSAR->ima2).lenr ;
    params->yDimOut = (pInSAR->ima2).lena ;
    params->FDC[0] = pInSAR->chaz2.a0FDC ;
    params->FDC[1] = pInSAR->chaz2.a1FDC * 2. * pInSAR->rad.rangeResolutionCell / c0 ;
    params->FDC[2] = pInSAR->chaz2.a2FDC * pow(2. * pInSAR->rad.rangeResolutionCell / c0, 2.) ;
    params->PRF = (pInSAR->chaz2).PRF ;
    params->dXFDC = 0 ;
    params->verbose = 1 ;
    
    /* Update slave image transform to take into account master transform if already applied */
    memcpy(params->affineTransform[0], pInSAR->slaveAffineTransform[0], 6 * sizeof(double)) ;
    if (pInSAR->masterAffineTransform) {
        freeMatrixDouble(params->affineTransform, 0, 0) ;
        params->affineTransform = combinedAffineTransform(pInSAR->slaveAffineTransform, pInSAR->masterAffineTransform) ;
    }
    
    printf("\nInterpolation of the slave image\n") ;
    printf("*********************************\n") ;
    /* Generate input file path taking selected polarization into account */
    inputFilePath = initStringWith3Strings(pInSAR->slaveImage->dataDirectoryPath, "/SLCData.", pInSAR->slavePolarizationChannel) ;
    
    if((params->fIn = openRawFileForReadingAtPath(inputFilePath) ) == NULL) {
        sprintf(ertex, "Failed to open slave image file at path %s\n", inputFilePath) ;
        ase(ertex) ;
    }
    
    if((params->fOut = openRawFileForReadingAndWritingAtPath(outputFilePath)) == NULL) {
        sprintf(ertex, "Failed to create interpolated slave image file at path %s\n", outputFilePath) ;
        ase(ertex) ;
    }
    
    interpolationCore(params) ;
}


void interpolAllChannels(interpolationParameters *params)
{
    char *inputFilePath, *outputFilePath ;
    int i ;
    CSVStruct *polMode ;
    InSARParametersStruct    *pInSAR ;
    
    pInSAR = params->pInSAR ;
    memcpy(params->affineTransform[0], pInSAR->slaveAffineTransform[0], 6 * sizeof(double)) ;
    
    /* If master images must be interpolated, we start with these ones */
    if (pInSAR->masterInterpolation) {
        /* First, create image container if required */
        if (!isDir(pInSAR->interpolatedMaster->imageDirectoryPath)) {
            createCSLDirectoryStructureFor(pInSAR->interpolatedMaster, 0) ;
        }
        
        /* Master image interpolation parameters initialization */
        params->xDimIn = params->xDimOut = (pInSAR->ima1).lenr ;
        params->yDimIn = params->yDimOut = (pInSAR->ima1).lena ;
        params->FDC[0] = pInSAR->chaz1.a0FDC ;
        params->FDC[1] = pInSAR->chaz1.a1FDC * 2. * pInSAR->rad.rangeResolutionCell / c0 ;
        params->FDC[2] = pInSAR->chaz1.a2FDC * pow(2. * pInSAR->rad.rangeResolutionCell / c0, 2.) ;
        params->PRF = (pInSAR->chaz1).PRF ;
        params->dXFDC = 0 ;
        params->verbose = 1 ;
        memcpy(params->affineTransform[0], pInSAR->masterAffineTransform[0], 6 * sizeof(double)) ;
        
        polMode = readCSVInString(pInSAR->masterInfo->polMode) ;
        
        printf("\nInterpolation of all %d channels of the master image using the same transform\n", polMode->numberOfEntries) ;
        printf("*****************************************************************************") ;
        
        for(i = 0; i < polMode->numberOfEntries; i++) {
            inputFilePath = initStringWith3Strings(pInSAR->masterImage->dataDirectoryPath, "/SLCData.", polMode->stringVal[i]) ;
            outputFilePath = initStringWith3Strings(pInSAR->interpolatedMaster->dataDirectoryPath, "/SLCData.", polMode->stringVal[i]) ;
            
            if (fileExistsAtPath(inputFilePath)) {
                if((params->fIn = openRawFileForReadingAtPath(inputFilePath) ) == NULL) {
                    sprintf(ertex, "Failed to open master image file at path %s\n", inputFilePath) ;
                    ase(ertex) ;
                }
                if((params->fOut = openRawFileForReadingAndWritingAtPath(outputFilePath)) == NULL) {
                    sprintf(ertex, "Failed to create interpolated master image file at path %s\n", outputFilePath) ;
                    ase(ertex) ;
                }
                
                interpolationCore(params) ;
                
                freeRawFileDescriptor(params->fIn) ;
                freeRawFileDescriptor(params->fOut) ;
            }
            free(inputFilePath) ;
            free(outputFilePath) ;
        }
        
        freeCSVStruct(polMode) ;
        
        /* Now, we update the slave image transform to take into account the master transform already applied */
        freeMatrixDouble(params->affineTransform, 0, 0) ;
        params->affineTransform = combinedAffineTransform(pInSAR->slaveAffineTransform, pInSAR->masterAffineTransform) ;
    }
    
    /* Slave interpolation */
    /* ******************* */
    /* First, create image container if required */
    if (!isDir(pInSAR->interpolatedSlave->imageDirectoryPath)) {
        createCSLDirectoryStructureFor(pInSAR->interpolatedSlave, 0) ;
    }
    
    /* Slave image interpolation parameters initialization */
    params->xDimIn = (pInSAR->ima2).lenr ;
    params->yDimIn = (pInSAR->ima2).lena ;
    params->xDimOut = (pInSAR->ima2).lenr ;
    params->yDimOut = (pInSAR->ima2).lena ;
    params->FDC[0] = pInSAR->chaz2.a0FDC ;
    params->FDC[1] = pInSAR->chaz2.a1FDC * 2. * pInSAR->rad.rangeResolutionCell / c0 ;
    params->FDC[2] = pInSAR->chaz2.a2FDC * pow(2. * pInSAR->rad.rangeResolutionCell / c0, 2.) ;
    params->PRF = (pInSAR->chaz2).PRF ;
    params->dXFDC = 0 ;
    params->verbose = 1 ;
    
    /* Update slave image transform to take into account master transform if already applied */
    memcpy(params->affineTransform[0], pInSAR->slaveAffineTransform[0], 6 * sizeof(double)) ;
    if (pInSAR->masterAffineTransform) {
        freeMatrixDouble(params->affineTransform, 0, 0) ;
        params->affineTransform = combinedAffineTransform(pInSAR->slaveAffineTransform, pInSAR->masterAffineTransform) ;
    }
    
    polMode = readCSVInString(pInSAR->slaveInfo->polMode) ;
    printf("\nInterpolation of all %d channels of the slave image using the same transform\n", polMode->numberOfEntries) ;
    printf("***************************************************************************") ;
    for(i = 0; i < polMode->numberOfEntries; i++) {
        inputFilePath = initStringWith3Strings(pInSAR->slaveImage->dataDirectoryPath, "/SLCData.", polMode->stringVal[i]) ;
        outputFilePath = initStringWith3Strings(pInSAR->interpolatedSlave->dataDirectoryPath, "/SLCData.", polMode->stringVal[i]) ;
        
        if (fileExistsAtPath(inputFilePath)) {
            if((params->fIn = openRawFileForReadingAtPath(inputFilePath) ) == NULL) {
                sprintf(ertex, "Failed to open slave image file at path %s\n", inputFilePath) ;
                ase(ertex) ;
            }
            if((params->fOut = openRawFileForReadingAndWritingAtPath(outputFilePath)) == NULL) {
                sprintf(ertex, "Failed to create interpolated slave image file at path %s\n", outputFilePath) ;
                ase(ertex) ;
            }
            
            interpolationCore(params) ;
            
            freeRawFileDescriptor(params->fIn) ;
            freeRawFileDescriptor(params->fOut) ;
            params->fIn = params->fOut = NULL ;
        }
        
        free(inputFilePath) ;
        free(outputFilePath) ;
    }
    
    freeCSVStruct(polMode) ;
}


void updateAoI(InSARParametersStruct *pInSAR)
{
    double **inverseTransform ;
    polygon *aoi ;
    
    inverseTransform = matrixDouble(0, 1, 0, 2) ;
    inversePlaneAffineTransform(pInSAR->masterAffineTransform, inverseTransform) ;
    aoi = planeAffineTransformOfPolygon(pInSAR->aoi, NULL, inverseTransform) ;
    
    pInSAR->sup.Sgra = (aoi->P[0].x > aoi->P[3].x)? (int)ceil(aoi->P[0].x) : (int)ceil(aoi->P[3].x) ;
    pInSAR->sup.Sgra *= (pInSAR->sup.Sgra > 0) ;
    pInSAR->sup.Sdra = (aoi->P[1].x > aoi->P[2].x)? (int)floor(aoi->P[2].x) : (int)floor(aoi->P[1].x) ;
    if(pInSAR->sup.Sdra >= pInSAR->ima1.lenr) pInSAR->sup.Sdra = pInSAR->ima1.lenr - 1 ;
    if(pInSAR->sup.Sdra >= pInSAR->ima2.lenr) pInSAR->sup.Sdra = pInSAR->ima2.lenr - 1 ;
    
    pInSAR->sup.Sbaz = (aoi->P[0].y > aoi->P[1].y)? (int)ceil(aoi->P[0].y) : (int)ceil(aoi->P[1].y) ;
    pInSAR->sup.Sbaz *= (pInSAR->sup.Sbaz > 0) ;
    pInSAR->sup.Shaz = (aoi->P[2].y > aoi->P[3].y)? (int)floor(aoi->P[3].y) : (int)floor(aoi->P[2].y) ;
    if(pInSAR->sup.Shaz >= pInSAR->ima1.lena) pInSAR->sup.Shaz = pInSAR->ima1.lena - 1 ;
    if(pInSAR->sup.Shaz >= pInSAR->ima2.lena) pInSAR->sup.Shaz = pInSAR->ima2.lena - 1 ;
    
    pInSAR->aoi->P[0].x = pInSAR->aoi->P[3].x = pInSAR->sup.Sgra ;
    pInSAR->aoi->P[1].x = pInSAR->aoi->P[2].x = pInSAR->sup.Sdra ;
    pInSAR->aoi->P[0].y = pInSAR->aoi->P[1].y = pInSAR->sup.Sbaz ;
    pInSAR->aoi->P[2].y = pInSAR->aoi->P[3].y = pInSAR->sup.Shaz ;
    
    freePolygon(aoi) ;
    freeMatrixDouble(inverseTransform, 0, 0) ;
}


/* main programm start */
void	interpolationCore(interpolationParameters *params)
{
	/* local variables declaration */
    char *aPath ;
	int 		k, yDimIn, yDimOut, elena, xDimIn, xDimOut, Rlenr, elenr, Nb, Ncol, Index ;
    int         iX, iY, iX0, iY0 ;
    int         xDim2, yDim2, dXOut, dYOut ;
    int         dXFDC ;
	off_t		Ldec ;
	float		c ;
	double		PRF2, a0FDC2, a1FDC2, a2FDC2, FDC ;
	double		Ax, Bx, Cx, D, xIndex ;
	double		Ay, By, Cy ;
    double      x0In, y0In, y2 ;
	complexFloat		*Ligne, **Ima;
	complexFloat		*u, zero, *nullLine, complexPhase ;
	CZTInterpolator	*V ;
	progressCounter *aCounter = NULL ;
    rawFileDescriptor *tempFile = NULL ;

/*----------------------------------  INITIALISATION  -----------------------------------*/

	PRF2 = params->PRF ;
    
    /* In case of Sentinel 1, PRF is different to azimuth frequency. This latter one being the inverse of the line time interval */
    /* For azimuth interpolation and spectrum centring, it is the azimuth frequency that have to be considered */
    PRF2 = 1. / params->pInSAR->slaveInfo->lineTimeInterval ;
    
	a0FDC2 = params->FDC[0] ;
	a1FDC2 = params->FDC[1] ;
	a2FDC2 = params->FDC[2] ;

	xDimIn = params->xDimIn ;
	yDimIn = params->yDimIn ;
	xDimOut = params->xDimOut ;
	yDimOut = params->yDimOut ;
    x0In = 0 ;
    y0In = 0 ;
    dXFDC = params->dXFDC ;
    
	Ax = params->affineTransform[0][0] ;
	Bx = params->affineTransform[0][1] ;
	Cx = params->affineTransform[0][2] ;
	Ay = params->affineTransform[1][0] ;
	By = params->affineTransform[1][1] ;
	Cy = params->affineTransform[1][2] ;

    if (params->verbose) {
        printf ("\nInterpolation of image: %s\n", params->fIn->accessPath) ;
        printf("Interpolated image file path: %s\n", params->fOut->accessPath) ;
        printf ("Applied transform :\n") ;
        printf ("*******************\n\n") ;
        printf ("x' = Ax.x + Bx.y + Cx\n") ;
        printf ("y' = Ay.x + By.y + Cy\n\n") ;
        printf ("Ax =%-22.15lf\tAy =%-22.15lf\n", Ax, Ay) ;
        printf ("Bx =%-22.15lf\tBy =%-22.15lf\n", Bx, By) ;
        printf ("Cx =%-22.15lf\tCy =%-22.15lf\n", Cx, Cy) ;
        
        printf( "\n================= Complex interpolation ================= \n" ) ;
    }

    /* If input and output files are the same but output dimensions differ from input one, a temp file is required */
    
    if (params->fIn == params->fOut && (xDimIn != xDimOut || yDimIn != yDimOut)) {
        aPath = initStringWith2Strings(params->fIn->directoryPath, "/tempFile") ;
        tempFile = createRawFileForReadingAndWritingAtPath(aPath) ;
        free(aPath) ;
        params->fOut = tempFile ;
    }

	/* Determination de la dimension des tableaux pour la fft : plus petite puissance de 2 superieure a Max_lenr	*/

	yDim2 = (yDimOut < yDimIn)? yDimIn : yDimOut ;
	xDim2 = (xDimOut < xDimIn)? xDimIn : xDimOut ;
	ceil2(&yDim2, &elena);
	ceil2(&xDim2, &elenr);
	dYOut = (yDim2 - yDimOut) ;
	dXOut = (xDim2 - xDimOut) ;
	iX0 = dXOut / 2 ;
	iY0 = dYOut / 2 ;
    zero.r = zero.i = 0.0 ;

/* ------------------------------------------------------------------------------------------------------------------------------- */
/* --							Interpolation complexe							-- */
/* ------------------------------------------------------------------------------------------------------------------------------- */

	/* Interpolation en range */
	/* ---------------------- */

    if (params->verbose) {
        printf("Interpolation along the range dimension: \n") ;
    }

	/* Interpolation proprement dite. */
	/* ______________________________ */
	Bx = Bx/By ;
	Ax = Ax - Bx * Ay ;
	Cx = Cx - Bx * Cy + (1 - Ax) * iX0 ;
    
	/* Allocation de mémoire */
	/* _____________________ */	
	nullLine = vectorComplexFloat(0, xDim2 - 1) ;
    for (iX = 0; iX < xDim2; iX++) {
        nullLine[iX] = zero ;
    }
    Ligne = vectorComplexFloat(0, xDim2 - 1) ;

    /* If transform is unitary in range, simply transfer input to output */
    if (Ax == 1. && Bx == 0. && Cx == 0.) {
        for(iY = 0; iY < yDimIn ; iY++) {
            Ldec = ((off_t)(iY + y0In) * params->xDimIn + x0In) * sizeof(complexFloat) ;
            fseeko(params->fIn->f, Ldec , 0) ;
            fread ((complexFloat *)(Ligne + iX0), sizeof(complexFloat), xDimIn, params->fIn->f) ;

            Ldec = (off_t)iY * xDimOut * sizeof(complexFloat) ;
            fseeko(params->fOut->f, Ldec, 0) ;
            fwrite((complexFloat *)(Ligne + iX0), sizeof(complexFloat), xDimOut, params->fOut->f) ;
        }
    }
    /* Else, proceed */
    else {
        if (params->verbose) {
            aCounter = initProgressCounterWithMinMaxValue(0, yDimIn - 1) ;
        }

        V = initInterpolator(xDim2, Ax) ;
        u = vectorComplexFloat(0, xDim2 - 1) ;
        for(iY = 0; iY < yDimIn ; iY++) {
            memcpy(Ligne, nullLine, xDim2 * sizeof(complexFloat)) ;
            memcpy(u, nullLine, xDim2 * sizeof(complexFloat)) ;

            Ldec = ((off_t)(iY + y0In) * params->xDimIn + x0In) * sizeof(complexFloat) ;
            fseeko(params->fIn->f, Ldec , 0) ;
            fread ((complexFloat *)&(Ligne[iX0]), sizeof(complexFloat), xDimIn, params->fIn->f) ;

            c = (2 * (iX0 / 2) != iX0)? 1 : -1. ;
            for(iX = iX0; iX < xDimIn + iX0; iX++) {
                c *= -1. ;
                u[iX].r = c * Ligne[iX].r ; 
                u[iX].i = c * Ligne[iX].i ; 
            }

            D = Bx * (iY + y0In) + Cx ;
            CZTInterpolation(u, Ax, D, V) ;

            for(iX = 0; iX < xDim2; iX++) {
                complexPhase.r = (float)cos(-(double)PI * (Ax * iX + D))/xDim2 ;
                complexPhase.i = (float)sin(-(double)PI * (Ax * iX + D))/xDim2 ;
                Ligne[iX] = mC(u[iX], complexPhase) ;
            }
            Ldec = (off_t)iY * xDimOut * sizeof(complexFloat) ;
            fseeko(params->fOut->f, Ldec, 0) ;
            fwrite((complexFloat *)(Ligne + iX0), sizeof(complexFloat), xDimOut, params->fOut->f) ;
            if (params->verbose) {
                updateProgressCounterForIndex(aCounter, iY) ;
            }
        }
        freeVectorComplexFloat(u, 0) ;
        freeCZTInterpolator(V) ;
        
        if (params->verbose) {
            printf("\n") ;
            freeProgressCounter(aCounter) ;
        }
    }
    
    fflush(params->fOut->f) ;
    
    freeVectorComplexFloat(Ligne, 0) ;
	freeVectorComplexFloat(nullLine, 0) ;

    if (Ay != 0. || By != 1. || Cy != 0.) {
        /* Interpolation en azimut */
        /* ----------------------- */
        if (params->verbose) {
            printf("Interpolation along the azimuth dimension : \n");
        }

        /* By default, processing is made on data blocs of max 4GB (2**32) */
        /* This value may be adapted through params->maxMemAlloc */
        
        Rlenr = (int)pow(2.,(double)(params->maxMemAlloc - elena)) / sizeof(complexFloat) ;
        Rlenr = (Rlenr < xDimOut)? Rlenr : xDimOut ;
        Nb = xDimOut/Rlenr ;
        Nb = ((xDimOut - Rlenr*(xDimOut/Rlenr)) == 0)? Nb : Nb+1 ;

        /* Allocation de mémoire */
        Ima = matrixComplexFloat(0, yDim2 - 1, 0, Rlenr - 1) ;
        u = vectorComplexFloat(0, yDim2 - 1) ;
        nullLine = vectorComplexFloat(0, yDim2 - 1) ;
        for (iY = 0; iY < yDim2; iY++) {
            nullLine[iY] = zero ;
        }
        
        V = initInterpolator(yDim2, By) ;

        /* Interpolation proprement dite. */
        /* ______________________________ */
        if (params->verbose) {
            aCounter = initProgressCounterWithMinMaxValue(0, xDimOut - 1) ;
        }


        for(k = 0; k < Nb; k++) {
            Ncol = (k == Nb - 1)? xDimOut - k * Rlenr : Rlenr ;
            Index = yDim2 - iY0 - 1 ;
            for(iY = 0; iY <= iY0 ; iY++, Index ++)
                for(iX = 0; iX < Rlenr; iX++)
                    Ima[iY][iX] = Ima[Index][iX] = zero ;

            Index = iY0 ;
            for(iY = 0; iY < yDimIn ; iY++, Index++) {
                Ldec = (off_t)(iY * xDimOut + k * Rlenr) * sizeof(complexFloat) ;
                fseeko(params->fOut->f, Ldec, 0) ;
                fread((complexFloat *)Ima[Index], sizeof(complexFloat), Ncol, params->fOut->f) ;
            }

            for(iX = 0; iX < Ncol ; iX++) {
                memcpy(u, nullLine, yDim2 * sizeof(complexFloat)) ;
                xIndex = (double)(iX + k * Rlenr) + x0In ;
                FDC = -(a0FDC2 + (xIndex + dXFDC) * a1FDC2 + pow((xIndex + dXFDC), 2.)* a2FDC2)/PRF2 + .5 ;

                for(iY = iY0; iY < yDimIn + iY0 ; iY++) {
                    complexPhase.r = (float)cos((double)PI*2. * FDC * iY) ;
                    complexPhase.i = (float)sin((double)PI*2. * FDC * iY) ;
                    u[iY] = mC(Ima[iY][iX], complexPhase) ;
                }
                
                D = Ay * xIndex + Cy + (1 -  By) * iY0 ;
                CZTInterpolation(u, By, D, V) ;

                for(iY = 0; iY < yDim2; iY++)
                {
                    y2 = iY * By + D ;
                    complexPhase.r = (float)cos(-(double)PI*2. * FDC * y2)/yDim2 ;
                    complexPhase.i = (float)sin(-(double)PI*2. * FDC * y2)/yDim2 ;
                    Ima[iY][iX] = mC(u[iY], complexPhase) ;
                }
                if (params->verbose) {
                    updateProgressCounterForIndex(aCounter, iX + k * Rlenr) ;
                }
            }

            Index = iY0 ;
            for(iY = 0; iY < yDimOut; iY++, Index++) {
                Ldec = (off_t)(iY * xDimOut + k * Rlenr) * sizeof(complexFloat) ;
                fseeko(params->fOut->f, Ldec, 0) ;
                fwrite((complexFloat *)Ima[Index], sizeof(complexFloat), Ncol, params->fOut->f) ;
            }
        }
        if (params->verbose) {
            printf("\n") ;
            freeProgressCounter(aCounter) ;
        }
        
        /* If a temporary file was created, it must be renamed with the name of the input file */
        if (tempFile) {
            unlink(params->fIn->accessPath) ;
            rename(tempFile->accessPath, params->fIn->accessPath) ;
            truncate(params->fIn->accessPath, xDimOut * yDimOut * sizeof(complexFloat)) ;
        }
        
        freeVectorComplexFloat(u, 0) ;
        freeVectorComplexFloat(nullLine, 0) ;

        freeMatrixComplexFloat(Ima, 0, 0) ;
        freeCZTInterpolator(V) ;
    }
}

interpolationParameters *allocInterpolationParameters (void)
{
    interpolationParameters *params ;
    
    if((params = malloc(sizeof(interpolationParameters))) == NULL) {
        perror("Failed to initialize interpolation") ;
        exit(-1) ;
    }
    params->verbose = 1 ;
    params->FDC = vectorDouble(0, 2) ;
    params->affineTransform = matrixDouble(0, 1, 0, 2) ;
    params->maxMemAlloc = MAXMEMALLOC ;
    params->dXFDC = 0 ;
    params->fIn = params->fOut = NULL ;
    params->flag = 0 ;
	
    return (params) ;
}

void freeInterpolationParameters(interpolationParameters *params)
{
    freeVectorDouble(params->FDC, 0) ;
    freeMatrixDouble(params->affineTransform, 0, 0) ;
    if (params->fIn) {
        freeRawFileDescriptor(params->fIn) ;
        params->fIn = NULL ;
    }
    if (params->fOut) {
        freeRawFileDescriptor(params->fOut) ;
    }
    free(params) ;
    
    *(&params) = NULL ;
}
