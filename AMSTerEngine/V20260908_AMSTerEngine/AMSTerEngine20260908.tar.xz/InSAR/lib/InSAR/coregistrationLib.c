
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  coregistrationLib.c
//  S1InSARDataReader
//
//  Created by Dominique Derauw a long long time ago.
//  Fully revised, corrected, refurbished, improved and reorganized in 2020
//  Copyright (c) 2020 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "coregistrationLib.h"



coregistrationResults *allocCoregistrationResults(void)
{
    coregistrationResults *corResults ;
    
    if ((corResults = malloc(sizeof(coregistrationResults))) == NULL) {
        perror("failed to allocate pointer to coregistration results") ;
        exit(-1) ;
    }
    
    corResults->T = matrixDouble(0, 1, 0, 2) ;
    
    corResults->numberOfRegisteredPoints = 0 ;
    corResults->coregistrationIndex = 0 ;
    corResults->sigmaX = corResults->sigmaXY = corResults->sigmaY = 0. ;
    corResults->xCoregistrationGrid = corResults->yCoregistrationGrid = NULL ;
    
    
    return (corResults) ;
}

void freeCoregistrationResults (coregistrationResults *corResults)
{
    /* Attention! coregistrationGrids are not freed here but when freeing the pointer to InSAR parameters */
    freeMatrixDouble(corResults->T, 0, 0) ;
    free(corResults) ;
}



coregistrationResults *coarseCoregistration(CSVStruct *csv)
{
    char *aPath = NULL, InSARParametersFileFound ;
    int    currentDirectoryFdesc, i ;
    int unsigned lowCutFilterWidth ;
    InSARParametersStruct    *pInSAR ;
    time_t startTime, endTime ;
    coregistrationResults *corResults ;
    
    InSARParametersFileFound = 0 ;
    currentDirectoryFdesc = open(".", O_RDONLY) ;
    fchdir(currentDirectoryFdesc) ;
    
    
    if(isArgumentPresentInCSV(csv, "help") || isFlagPresentInCSV(csv, "h")) {
        coarseCoregistrationHelp() ;
    }
    
    /* Determine if low frequencies must be cut during correlation process */
    lowCutFilterWidth = 4 ;
    if((i = (int)isArgumentPresentInCSV(csv, "l="))) {
        sscanf(csv->stringVal[i] + 2, "%d", &lowCutFilterWidth) ;
    }
    
    i = 1 ;
    while (i < csv->numberOfEntries) {
        aPath = initStringWithString(csv->stringVal[i]) ;
        if(fileExistsAtPath(aPath)) {
            InSARParametersFileFound = 1 ;
            break ;
        }
        i++ ;
        free(aPath) ;
    }
    if(!InSARParametersFileFound) {
        aPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
        if(!fileExistsAtPath(aPath)){
            free(aPath) ;
            aPath = initStringWithString("./InSARParameters.txt") ;
            if(!fileExistsAtPath(aPath))
                coarseCoregistrationHelp() ;
        }
        InSARParametersFileFound = 1 ;
    }
    time(&startTime) ;
    pInSAR = readInSARParametersFileAtPath(aPath) ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "-s"))? _SAVE_ITERMEDIATE_RESULTS_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "-f"))? _FULL_WINDOW_SEARCH_ : pInSAR->flag ;
    pInSAR->flag |= (isArgumentPresentInCSV(csv, "chut!"))? pInSAR->flag : _VERBOSE_ ;
    
    corResults = coarseCoregistrationCore(pInSAR, lowCutFilterWidth) ;
    computeCommonSuperpositionOfImages(pInSAR) ;
        
    saveInSARParametersFileAtPath(pInSAR, aPath) ;
    if ((pInSAR->flag & _VERBOSE_)) {
        time(&endTime) ;
        duration(startTime, endTime) ;
    }

    /* Should save here the coregistration grids before freeing them through pInSAR freeing */
    
    freeInSARParametersStruct(pInSAR) ;

    return(corResults) ;
}


void coarseCoregistrationHelp()
{
    printf("\nUsage:\n\ncoarseCoregistration [/pathTo/InSARParameters.txt] [-l N] [-f]\n\n") ;
    printf("This routine will perform the coarse registration of master \nand slave amplitude images.\n") ;
    printf("By default, search of anchor points is restricted within the \ninterval of width equal to the expected error and centered on the expected location\n") ;
    printf("To extend search on the full window, use the -f otion\n") ;
    printf("\nIf used with no parameters, the routine will look for an \"InSARparameters.txt\".\n") ;
    printf("file within the working directory or within the ./TextFiles subdirectory.\n") ;
    printf("Any other path to a text file containing InSAR parameters can be given as\nfirst parameter.\n\n") ;
    printf("If willing to add low cut frequency filtering, use l=N,\n with N being the half width of the filter in pixels.\nDefault is a 4 pixels\n") ;
    exit(0) ;
}

/* Fine Coregistration programm start */
coregistrationResults *fineCoregistration(CSVStruct *csv)
{
    char *aPath = NULL, InSARParametersFileFound ;
    int    currentDirectoryFdesc, i ;
    InSARParametersStruct    *pInSAR ;
    time_t startTime, endTime ;
    coregistrationResults *corResults ;
    
    InSARParametersFileFound = 0 ;
    currentDirectoryFdesc = open(".", O_RDONLY) ;
    fchdir(currentDirectoryFdesc) ;
    
    if(isArgumentPresentInCSV(csv, "help") || isFlagPresentInCSV(csv, "h"))
        fineCoregistrationHelp() ;
    
    i = 1 ;
    while (i < csv->numberOfEntries) {
        aPath = initStringWithString(csv->stringVal[i]) ;
        if(fileExistsAtPath(aPath)) {
            InSARParametersFileFound = 1 ;
            break ;
        }
        i++ ;
        free(aPath) ;
    }
    if(!InSARParametersFileFound) {
        aPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
        if(!fileExistsAtPath(aPath)){
            free(aPath) ;
            aPath = initStringWithString("./InSARParameters.txt") ;
            if(!fileExistsAtPath(aPath))
                fineCoregistrationHelp() ;
        }
        InSARParametersFileFound = 1 ;
    }
    time(&startTime) ;
    pInSAR = readInSARParametersFileAtPath(aPath) ;
    
    pInSAR->flag |= (isArgumentPresentInCSV(csv, "withTracking"))? WITH_TRACKING : pInSAR->flag ;
    pInSAR->flag |= (isArgumentPresentInCSV(csv, "spi"))? SQUARE_SPIRAL : pInSAR->flag ;
    pInSAR->flag |= (isArgumentPresentInCSV(csv, "chut!"))? pInSAR->flag : _VERBOSE_ ;
    pInSAR->flag |= (isArgumentPresentInCSV(csv, "-s"))? _SAVE_ITERMEDIATE_RESULTS_: pInSAR->flag ;

//    approxRt(pInSAR->masterInfo) ;
    corResults = fineCoregistrationCore(pInSAR) ;
    computeCommonSuperpositionOfImages(pInSAR) ;
    
    if ((pInSAR->flag & _VERBOSE_)) {
        computeBaseLineFromAffineTransform(pInSAR) ;
        time(&endTime) ;
        duration(startTime, endTime) ;
    }
    
    saveInSARParametersFileAtPath(pInSAR, aPath) ;
    freeInSARParametersStruct(pInSAR) ;
    
    return(corResults) ;
}


void fineCoregistrationHelp()
{
    printf("\nUsage:\nfineCoregistration [/pathTo/InSARParameters.txt]\n\n") ;
    printf("The fineCoregistration routine will perform the fine registration of master and\nslave images base on local coherence maximization.\n") ;
    printf("\nIf used with no parameters, the routine will look for an \"InSARparameters.txt\".\n") ;
    printf("file within the working directory or within the ./TextFiles subdirectory.\n") ;
    printf("Any other path to a text file containing InSAR parameters can be given as\nfirst parameter.\n\n") ;
    exit(0) ;
}

coregistrationResults *coarseCoregistrationCore(InSARParametersStruct *pInSAR, int unsigned lowCutFilterWidth)
{
    /* local variables declaration */
    char *InSARPath = NULL, *aPath ;
    char verbose, saveIntermediateResults ;
    int unsigned xDimMasterMod, yDimMasterMod, xDimSlaveMod, yDimSlaveMod, xWindowSize, yWindowSize ;
    int i, j ;
    int unsigned k, l ;
    int xIndex, yIndex ;
    int unsigned xIndexU, yIndexU ;
    int xGridMeshSize, yGridMeshSize ;
    int        *indx1, xWindowShift, yWindowShift ;
    int        y0Master, y0Slave, x0Master, x0Slave, x00Master, xSupDim, ySupDim ;
    int        NPligne, xN, yN, yReductionFactor, xReductionFactor ;
    int xError, yError ;
    int unsigned xIntMin, xIntMax, yIntMin, yIntMax, yMax, xMax ;
    long        seekVal ;
    float        max, maxmax ;
    float        **masterAmplitude , **slaveAmplitude, **lowCutFilter, *rangeLowCutFilter, *azimuthLowCutFilter ;
    float       **masterAmplitudeWindow, **slaveAmplitudeWindow, **correlationAmplitudeWindow ;
    float allZeros, meanCorr ;
    double        signe ;
    double        sigmaY, sigmaY2, sigmaX, sigmaX2, sigmaXY, sigmaXY2 ;
    double        correlationThreshold, yMaxFWHM, xMaxFWHM ;
    double        A, B, C, D, X0, Y0, z0_1, z00, z01, z_10, z10, A2, B2 ;
    double        By, Ay, Cy, Bx, Ax, Cx ;
    double        SxS, SyMxS, SxMxS ;
    double        SyS, SyMyS, SxMyS ;
    double        SyM, SxM, SxMyM, SyM2, SxM2 ;
    double      dx, dy, Sdy, Sdx, Sdy2, Sdx2 ;
    double        yMaster, ySlave, xMaster, xSlave, NPcor, Norm, norm1, norm2 ;
    double        **ML, *VLx, *VLz ;
    double        *masterWindowOrigin, *slaveWindowOrigin ;
    complexFloat **masterWindow, **slaveWindow, **centeringPhaseShift ;
    StructFFT    *FFTAzimut, *FFTRange ;
    gridMap     *xCoregistrationGrid, * yCoregistrationGrid ;
    coord2D     masterPoint, slavePoint, gridPoint ;
    
    rawFileDescriptor *masterWidowFile, *slaveWidowFile, *correlationWidowFile ;
    coregistrationResults *corResults ;
    
    /*----------------------------------  INITIALISATION  -----------------------------------*/
    saveIntermediateResults = (pInSAR->flag & _SAVE_ITERMEDIATE_RESULTS_) ;
    verbose = (pInSAR->flag & _VERBOSE_)? 1 : 0 ;
    
    /* In the following, we consider that the X dimension is along range and Y dimension is along azimuth */
    
    /* Read amplitude images dimentions */
    xDimMasterMod = (pInSAR->mod1).lenr ;
    yDimMasterMod = (pInSAR->mod1).lena ;
    xDimSlaveMod = (pInSAR->mod2).lenr ;
    yDimSlaveMod = (pInSAR->mod2).lena ;
    
    /* Read estimated errors */
    xError = pInSAR->corf.errra ;
    yError = pInSAR->corf.erraz ;
    
    /* If one of the modulus image has zero dimension, it means amplitudeImagesReduction was not run */
    if(yDimMasterMod * yDimSlaveMod * xDimMasterMod * xDimSlaveMod == 0)
        ase("Amplitude images not computed!\nRun amplitudeImageReduction first\n") ;
    
    /* Read correlation window size and adapt it if needed to be a power of 2 not lower than 16 pixels */
    xWindowSize = (pInSAR->corg).F_lenr ;
    yWindowSize = (pInSAR->corg).F_lena ;
    xWindowSize = (xWindowSize < 16)? 16 : xWindowSize ;
    yWindowSize = (yWindowSize < 16)? 16 : yWindowSize ;
    xWindowSize = ceil2ofIntVal(xWindowSize) ;
    yWindowSize = ceil2ofIntVal(yWindowSize) ;
    
    /* Compute valid zone interval */
    if (pInSAR->flag & _FULL_WINDOW_SEARCH_) {
        xIntMax = xWindowSize - xWindowSize / 8 - 1 ;
        xIntMin = xWindowSize / 8 + 1 ;
        yIntMax = yWindowSize - yWindowSize / 8 - 1 ;
        yIntMin = yWindowSize / 8 + 1 ;
    }
    else {
        xIntMin = xWindowSize / 2 - xError ;
        yIntMin = yWindowSize / 2 - yError ;
        xIntMax = xWindowSize / 2 + xError ;
        yIntMax = yWindowSize / 2 + yError ;
    }
    xIntMin = (xIntMin < 1)? 1 : xIntMin ;
    yIntMin = (yIntMin < 1)? 1 : yIntMin ;
    xIntMax = (xIntMax > xWindowSize - 2)? xWindowSize - 2 : xIntMax ;
    yIntMax = (yIntMax > yWindowSize - 2)? yWindowSize - 2 : yIntMax ;
    
    
    /* Read range and azimuth window shifts */
    xWindowShift = (pInSAR->corg).Depra ;
    yWindowShift = (pInSAR->corg).Depaz ;
    
    /* Read thresholds */
    correlationThreshold = (pInSAR->corg).seuilcoh ;
    xMaxFWHM = (pInSAR->corg).seuilra ;
    yMaxFWHM = (pInSAR->corg).seuilaz ;
    
    /* Read reduction factors used to generate the amplitude images */
    xReductionFactor = (pInSAR->red).Fra ;
    yReductionFactor = (pInSAR->red).Faz ;
    
    /* In case intermediate results must be saved, keep track of InSAR path */
    if (saveIntermediateResults) {
        InSARPath = getDirectoryPathFromPath(pInSAR->mod1.filePath) ;
        
        aPath = initStringWith2Strings(InSARPath, "/masterWindow") ;
        masterWidowFile = openRawFileForWritingAtPath(aPath) ;
        free(aPath) ;
        aPath = initStringWith2Strings(InSARPath, "/slaveWindow") ;
        slaveWidowFile = openRawFileForWritingAtPath(aPath) ;
        free(aPath) ;
        aPath = initStringWith2Strings(InSARPath, "/correlationWindow") ;
        correlationWidowFile = openRawFileForWritingAtPath(aPath) ;
        free(aPath) ;
        
        masterAmplitudeWindow = matrixFloat(0, yWindowSize - 1, 0, xWindowSize - 1) ;
        slaveAmplitudeWindow = matrixFloat(0, yWindowSize - 1, 0, xWindowSize - 1) ;
        correlationAmplitudeWindow = matrixFloat(0, yWindowSize - 1, 0, xWindowSize - 1) ;
    }
    else {
        masterWidowFile = slaveWidowFile = correlationWidowFile = NULL ;
        masterAmplitudeWindow = slaveAmplitudeWindow = correlationAmplitudeWindow = NULL ;
    }
    
    if (verbose) {
        printf("Coarse coregistration based on local maximization of correlation coefficient:\n\n") ;
        printf("Master image: %s\n", (pInSAR->ima1).filePath) ;
        printf("Slave image: %s\n", (pInSAR->ima2).filePath) ;
        printf("\nCorrelation treshold: %-f\n", correlationThreshold) ;
        printf("Half With at Half Maximum threshold of the correlation peak: %-f x %-f (range x azimuth pixels)\n", xMaxFWHM, yMaxFWHM) ;
        printf("Correlation window size: %d x %d ((range x azimuth pixels)\n", xWindowSize, yWindowSize) ;
        printf("Window shift: %d x %d ((range x azimuth pixels)\n", xWindowShift, yWindowShift) ;
        
        printf( "\n============================ PROCESS =================================\n" ) ;
    }
    
    /* Size of the common area of interest in amplitude images */
    xSupDim = (pInSAR->aoi->P[2].x - pInSAR->aoi->P[0].x + 1) / xReductionFactor ;
    ySupDim = (pInSAR->aoi->P[2].y - pInSAR->aoi->P[0].y + 1) / yReductionFactor ;
    
    /* Number of anchor points: */
    xN = (xSupDim - xWindowSize) / xWindowShift + 1 ;
    yN = (ySupDim - yWindowSize) / yWindowShift + 1 ;
    if (verbose) printf("Number of candidate anchor points: %-d X %-d = %-d\n", xN, yN, xN * yN) ;
    
    /* Reduced AoI origin */
    x0Master = pInSAR->aoi->P[0].x / xReductionFactor ;
    y0Master = pInSAR->aoi->P[0].y / yReductionFactor ;
    x0Master += (xSupDim - (xWindowSize + (xN - 1) * xWindowShift))/2 ;
    y0Master += (ySupDim - (yWindowSize + (yN - 1) * yWindowShift))/2 ;
    x00Master = x0Master ;
    
    /* Reduced AoI size */
    //    xSupDim = (xN - 1) * xWindowShift + xWindowSize ;
    //    ySupDim = (yN - 1) * yWindowShift + yWindowSize ;
    //    Norm = sqrt((double)xSupDim * ySupDim) ;
    Norm = 1. ;
    
    /* Coregistration grid allocation and initialization */
    xGridMeshSize = xWindowShift * xReductionFactor ;
    yGridMeshSize = yWindowShift * yReductionFactor ;
    xCoregistrationGrid = createFloatGridOfSize(xN, yN, xGridMeshSize, yGridMeshSize) ;
    yCoregistrationGrid = createFloatGridOfSize(xN, yN, xGridMeshSize, yGridMeshSize) ;
    xCoregistrationGrid->x0 = yCoregistrationGrid->x0 = xReductionFactor * ((double)(x0Master + xWindowSize/2)) ;
    xCoregistrationGrid->y0 = yCoregistrationGrid->y0 = yReductionFactor * ((double)(y0Master + yWindowSize/2)) ;
    xCoregistrationGrid->dimGridX = yCoregistrationGrid->dimGridX = pInSAR->ima1.lenr ;
    xCoregistrationGrid->dimGridY = yCoregistrationGrid->dimGridY = pInSAR->ima1.lena ;
    for (yIndex = 0; yIndex < yN; yIndex++) {
        for (xIndex = 0; xIndex < xN; xIndex++) {
            xCoregistrationGrid->floatVal[xIndex][yIndex] = floatInf ;
            yCoregistrationGrid->floatVal[xIndex][yIndex] = floatInf ;
        }
    }
    
    /* ------------------------------- memory allocation --------------------------------------*/
    masterAmplitude = matrixFloat(0, yWindowSize - 1, 0, xDimMasterMod - 1) ;
    slaveAmplitude = matrixFloat(0, yWindowSize - 1, 0, xDimSlaveMod - 1) ;
    masterWindow = matrixComplexFloat(0, yWindowSize - 1, 0, xWindowSize - 1) ;
    slaveWindow = matrixComplexFloat(0, yWindowSize - 1, 0, xWindowSize - 1) ;
    centeringPhaseShift = matrixComplexFloat(0, yWindowSize - 1, 0, xWindowSize - 1) ;
    masterWindowOrigin = vectorDouble(0, 1) ;
    slaveWindowOrigin = vectorDouble(0, 1) ;
    
    corResults = pInSAR->corResults ;
    if (pInSAR->corResults == NULL) {
        corResults = allocCoregistrationResults() ;
    }
    
    /* Low cut filter initialization */
    lowCutFilter = matrixFloat(0, yWindowSize - 1, 0, xWindowSize - 1) ;
    rangeLowCutFilter = vectorFloat(0, xWindowSize - 1) ;
    azimuthLowCutFilter = vectorFloat(0, yWindowSize - 1) ;
    
    lowCutFilterWidth = (xWindowSize < yWindowSize)? ((lowCutFilterWidth > xWindowSize / 2)? xWindowSize / 2 : lowCutFilterWidth) : ((lowCutFilterWidth > yWindowSize / 2)? yWindowSize / 2 : lowCutFilterWidth) ;
    for(xIndexU = 0; xIndexU < lowCutFilterWidth; xIndexU++)
        rangeLowCutFilter[xIndexU] = (float)((1. - cos(xIndexU * PI/(double)lowCutFilterWidth)) / 2.) ;
    for(; xIndexU < xWindowSize; xIndexU++)
        rangeLowCutFilter[xIndexU] =  1. ;
    
    for(yIndexU = 0; yIndexU < lowCutFilterWidth; yIndexU++)
        azimuthLowCutFilter[yIndexU] = (float)((1. - cos(yIndexU * PI/(double)lowCutFilterWidth)) / 2.) ;
    for(; yIndexU < yWindowSize; yIndexU++)
        azimuthLowCutFilter[yIndexU] =  1. ;
    
    for(k = 0; k < yWindowSize; k++)
        for(l = 0; l < xWindowSize; l++) {
            lowCutFilter[k][l] = azimuthLowCutFilter[k] * rangeLowCutFilter[l] ;
            centeringPhaseShift[k][l].r = (float)cos(-(double)PI * (k + l)) ;
            centeringPhaseShift[k][l].i = (float)sin(-(double)PI * (k + l)) ;
        }
    
    freeVectorFloat(rangeLowCutFilter, 0) ;
    freeVectorFloat(azimuthLowCutFilter, 0) ;
    
    ML = matrixDouble(1, 3, 1, 3) ;
    VLx = vectorDouble(1, 3) ;
    VLz = vectorDouble(1, 3) ;
    indx1 = vectorInt(1, 3) ;
    
    /* ------------------- Correlation ------------------- */
    if((pInSAR->masterAmplitudeImageFile = openRawFileForReadingAtPath((pInSAR->mod1).filePath)) == NULL)
        ase("Fail to open master amplitude image") ;
    if((pInSAR->slaveAmplitudeImageFile = openRawFileForReadingAtPath((pInSAR->mod2).filePath)) == NULL)
        ase("Fail to open slave amplitude image") ;
    
    SxS = SyMxS = SxMxS = 0. ;
    SyS = SyMyS = SxMyS = 0. ;
    SyM = SxM = SxMyM = SyM2 = SxM2 = NPcor = 0. ;
    Sdx = Sdy = Sdx2 = Sdy2 = 0. ;
    
    FFTRange = initFFT(xWindowSize, yWindowSize, ALONGX) ;
    FFTAzimut = initFFT(xWindowSize, yWindowSize, ALONGY) ;
    
    for(i = 0; i < yN; i++, y0Master += yWindowShift) {
        maxmax = 0. ;
        NPligne = 0 ;
        
        /* We reinitialize the range master origin and we localize the first slave window */
        /* In order to localize the slave window into the slave amplitude image, we need to convert the master image origin into full resolution coordinates */
        /* Then we can use the already know transform to locate it into the slave full resolution image and convert these coordinates into the reduced frame */
        x0Master = x00Master ;
        masterWindowOrigin[0] = (float)(x0Master * xReductionFactor) ;
        masterWindowOrigin[1] = (float)(y0Master * yReductionFactor) ;
        planeAffineTransformOfPoint(masterWindowOrigin, slaveWindowOrigin, pInSAR->slaveAffineTransform) ;
        y0Slave = (int)(slaveWindowOrigin[1] / yReductionFactor) ;
        
        /* We verify we are not outside the image */
        y0Slave = (y0Slave < 0)? 0: y0Slave ;
        if(y0Slave + yWindowSize > yDimSlaveMod - 1)
            y0Slave = yDimSlaveMod - 1 - yWindowSize ;
        
        /* Read input data */
        seekVal = (long)(y0Master * xDimMasterMod) * sizeof(float) ;
        fseek(pInSAR->masterAmplitudeImageFile->f, seekVal , 0) ;
        if (fread (masterAmplitude[0], sizeof(float), xDimMasterMod * yWindowSize, pInSAR->masterAmplitudeImageFile->f) != xDimMasterMod * yWindowSize) {
            ase("Failed to read in master amplitude image") ;
        }
        
        seekVal = (long)(y0Slave * xDimSlaveMod) * sizeof(float) ;
        fseek(pInSAR->slaveAmplitudeImageFile->f, seekVal , 0) ;
        if (fread (slaveAmplitude[0], sizeof(float), xDimSlaveMod * yWindowSize, pInSAR->slaveAmplitudeImageFile->f) != xDimSlaveMod * yWindowSize) {
            ase("Failed to read in slave amplitude image") ;
        }
        
        for(j = 0; j < xN; j++, x0Master += xWindowShift) {
            allZeros = 0 ;
            norm1 = norm2 = max = 0. ;
            masterWindowOrigin[0] = (float)(x0Master * xReductionFactor) ;
            planeAffineTransformOfPoint(masterWindowOrigin, slaveWindowOrigin, pInSAR->slaveAffineTransform) ;
            x0Slave = (int)(slaveWindowOrigin[0] / xReductionFactor) ;
            
            /* We verify we are not outside the image */
            if(x0Slave < 0)
                x0Slave = 0 ;
            if(x0Slave + xWindowSize > xDimSlaveMod - 1)
                x0Slave = xDimSlaveMod - 1 - xWindowSize ;
            
            for(k = 0; k < yWindowSize; k++) {
                for(l = 0; l < xWindowSize; l++) {
                    masterWindow[k][l].r = masterAmplitude[k][x0Master + l] ;
                    masterWindow[k][l].i = 0. ;
                    slaveWindow[k][l].r = slaveAmplitude[k][x0Slave + l] ;
                    slaveWindow[k][l].i = 0. ;
                    allZeros += masterWindow[k][l].r * slaveWindow[k][l].r ;
                }
            }
            if (allZeros) {
                if (saveIntermediateResults) {
                    for(k = 0; k < yWindowSize; k++) {
                        for(l=0; l < xWindowSize; l++) {
                            masterAmplitudeWindow[k][l] = masterWindow[k][l].r ;
                            slaveAmplitudeWindow[k][l] = slaveWindow[k][l].r ;
                        }
                    }
                }
                
                
                fftX(FORWARD_FFT, masterWindow[0], FFTRange) ;
                fftY(FORWARD_FFT, masterWindow[0], FFTAzimut) ;
                fftX(FORWARD_FFT, slaveWindow[0], FFTRange) ;
                fftY(FORWARD_FFT, slaveWindow[0], FFTAzimut) ;
                
                for(k = 0; k < yWindowSize; k++) {
                    for(l=0; l < xWindowSize; l++) {
                        masterWindow[k][l] = mRC(masterWindow[k][l], lowCutFilter[k][l]) ;
                        slaveWindow[k][l] = mRC(slaveWindow[k][l], lowCutFilter[k][l]) ;
                        norm1 += sqmC(masterWindow[k][l]) ;
                        norm2 += sqmC(slaveWindow[k][l]) ;
                    }
                }
                norm1 = sqrt(norm1 * norm2) / (xWindowSize * yWindowSize) ;
                
                for(k = 0; k < yWindowSize; k++) {
                    for(l = 0; l < xWindowSize; l++) {
                        masterWindow[k][l] = mC(slaveWindow[k][l], cC(masterWindow[k][l])) ;
                        masterWindow[k][l] = mC(masterWindow[k][l], centeringPhaseShift[k][l]) ;
                    }
                }
                fftX(INVERSE_FFT, masterWindow[0], FFTRange) ;
                fftY(INVERSE_FFT, masterWindow[0], FFTAzimut) ;
                
                yMax = xMax = 0 ;
                meanCorr = 0. ;
                for(k = 0; k < yWindowSize; k++) {
                    for(l = 0; l < xWindowSize; l++) {
                        masterWindow[k][l].r = modC(masterWindow[k][l]) / norm1 ;
                        meanCorr += masterWindow[k][l].r ;
                        if(max < masterWindow[k][l].r) {
                            max = masterWindow[k][l].r ;
                            yMax = k ;
                            xMax = l ;
                        }
                    }
                }
                meanCorr = 0.5 * meanCorr / xWindowSize / yWindowSize ;
                
                
                maxmax = (max>maxmax)? max : maxmax ;
                if ((max - meanCorr > correlationThreshold) && (yMax >= yIntMin) && (yMax <= yIntMax) && (xMax >= xIntMin) && (xMax <= xIntMax)) {
                    z0_1 = (double)masterWindow[yMax - 1][xMax].r - meanCorr ;
                    z00  = (double)masterWindow[yMax][xMax].r - meanCorr  ;
                    z01  = (double)masterWindow[yMax + 1][xMax].r - meanCorr ;
                    z_10 = (double)masterWindow[yMax][xMax - 1].r - meanCorr ;
                    z10  = (double)masterWindow[yMax][xMax + 1].r - meanCorr ;
                    A = ((log(z_10) + log(z10))/2. -  log(z00)) ;
                    B = ((log(z0_1) + log(z01))/2. -  log(z00)) ;
                    C = (log(z10) - log(z_10))/2. ;
                    D = (log(z01) - log(z0_1))/2. ;
                    
                    A2 = sqrt(-1./(2*A)) ;
                    B2 = sqrt(-1./(2*B)) ;
                    if((A2 < xMaxFWHM) && (B2 < yMaxFWHM))
                    {
                        X0 = -.5*C/A + xMax - xWindowSize/2 ;
                        Y0 = -.5*D/B + yMax - yWindowSize/2 ;
                        //                    Z0 = z00 * exp(-C*C/4*A - D*D/4*B) ;
                        
                        /* Detect if cycling occurred */
                        /*                    if (x0Slave + X0 - x0Master < -xWindowSize) {
                         X0 += xWindowSize ;
                         }
                         if (x0Slave + X0 - x0Master > xWindowSize) {
                         X0 -= xWindowSize ;
                         }
                         if (y0Slave + Y0 - y0Master < -yWindowSize) {
                         Y0 += yWindowSize ;
                         }
                         if (y0Slave + Y0 - y0Master > yWindowSize) {
                         Y0 -= yWindowSize ;
                         }
                         */
                        xMaster = xReductionFactor*((double)(x0Master + xWindowSize/2))/Norm ;
                        yMaster = yReductionFactor*((double)(y0Master + yWindowSize/2))/Norm ;
                        xSlave = xReductionFactor*((double)(x0Slave + xWindowSize/2) + X0)/Norm ;
                        ySlave = yReductionFactor*((double)(y0Slave + yWindowSize/2) + Y0)/Norm ;
                        
                        xCoregistrationGrid->floatVal[j][i] = xSlave * Norm ;
                        yCoregistrationGrid->floatVal[j][i] = ySlave * Norm ;
                        
                        SxS += xSlave ;
                        SyMxS += yMaster * xSlave ;
                        SxMxS += xMaster * xSlave ;
                        
                        SyS += ySlave ;
                        SyMyS += yMaster * ySlave ;
                        SxMyS += xMaster * ySlave ;
                        
                        SyM += yMaster ;
                        SxM += xMaster ;
                        SyM2 += yMaster * yMaster ;
                        SxM2 += xMaster * xMaster ;
                        SxMyM += yMaster * xMaster ;
                        NPcor += 1. ;
                        NPligne++ ;
                        
                        dx = xSlave - pInSAR->slaveAffineTransform[0][0] * xMaster - pInSAR->slaveAffineTransform[0][1] * yMaster ;
                        dy = ySlave - pInSAR->slaveAffineTransform[1][0] * xMaster - pInSAR->slaveAffineTransform[1][1] * yMaster ;
                        Sdx += dx ;
                        Sdy += dy ;
                        Sdx2 += pow(dx, 2.) ;
                        Sdy2 += pow(dy, 2.) ;
                        
                        if (saveIntermediateResults) {
                            for(k = 0; k < yWindowSize; k++) {
                                for(l=0; l<xWindowSize; l++) {
                                    correlationAmplitudeWindow[k][l] = masterWindow[k][l].r ;
                                }
                            }
                            fwrite(masterAmplitudeWindow[0], sizeof(float), xWindowSize * yWindowSize, masterWidowFile->f) ;
                            fwrite(slaveAmplitudeWindow[0], sizeof(float), xWindowSize * yWindowSize, slaveWidowFile->f) ;
                            fwrite(correlationAmplitudeWindow[0], sizeof(float), xWindowSize * yWindowSize, correlationWidowFile->f) ;
                            fflush(correlationWidowFile->f) ;
                            
                            printf("Intermediate result saved\nPress enter to compute next anchor point correlation\n") ;
                            getchar() ;
                            getchar() ;
                        }
                    }
                }
            }
        }
        if (verbose) printf("Line %-d; Number of found anchor points: %-d\t Correlation maximum = %-f\n",i, NPligne, maxmax) ;
    }
    VLx[1] = SyS ;
    VLx[2] = SyMyS ;
    VLx[3] = SxMyS ;
    
    VLz[1] = SxS ;
    VLz[2] = SyMxS ;
    VLz[3] = SxMxS ;
    
    ML[1][1] = NPcor ;
    ML[1][2] = ML[2][1] = SyM ;
    ML[1][3] = ML[3][1] = SxM ;
    ML[2][3] = ML[3][2] = SxMyM ;
    ML[2][2] = SyM2 ;
    ML[3][3] = SxM2 ;
    
    if (verbose) printf("\nCoregistration results:\n") ;
    if (verbose) printf("*************************\n") ;
    if (verbose) printf("Total number of anchor points: %-d .\n", (int)NPcor) ;
    
    corResults->numberOfRegisteredPoints = NPcor ;
    corResults->numberOfCandidatePoints = xN * yN ;
    corResults->sigmaX = corResults->sigmaY = corResults->sigmaXY = 0 ;
    
    /* If not enough points to compute  anew transform, update coregistration grids and display anchored points */
    if(NPcor < 4) {
        if (verbose) printf("Less than 4 points where anchored.\n") ;
        for (yIndex = 0; yIndex < yN; yIndex++) {
            gridPoint.y = (double)yIndex ;
            for (xIndex = 0; xIndex < xN; xIndex++) {
                gridPoint.x = (double)xIndex ;
                masterPoint = imageCoordinateForGridCoordinate(xCoregistrationGrid, gridPoint) ;
                planeAffineTransformOfCoord2D(&masterPoint, &slavePoint, pInSAR->slaveAffineTransform) ;
                
                /* If considered point was not coregistered, we assign it the value found for the global affine transform */
                if(xCoregistrationGrid->floatVal[xIndex][yIndex] == floatInf) {
                    xCoregistrationGrid->floatVal[xIndex][yIndex] = slavePoint.x ;
                    yCoregistrationGrid->floatVal[xIndex][yIndex] = slavePoint.y ;
                }
                else {
                    /* Else, we display anchored points */
                    xSlave = xCoregistrationGrid->floatVal[xIndex][yIndex] ;
                    ySlave = yCoregistrationGrid->floatVal[xIndex][yIndex] ;
                    if (verbose) printf("x1 = %f    x2 = %f    dx = %f\n", masterPoint.x, xSlave, masterPoint.x - xSlave) ;
                    if (verbose) printf("y1 = %f    y2 = %f    dy = %f\n\n", masterPoint.y, ySlave, masterPoint.y - ySlave) ;
                }
            }
        }
    }
    else {
        ludcmp(ML, 3, indx1, &signe) ;
        lubksb(ML, 3, indx1, VLz) ;
        lubksb(ML, 3, indx1, VLx) ;
        
        Bx = VLz[2] ;
        Ax = VLz[3] ;
        Cx = VLz[1] ;
        By = VLx[2] ;
        Ay = VLx[3] ;
        Cy = VLx[1] ;
        Cx *= Norm ;
        Cy *= Norm ;
        
        pInSAR->slaveAffineTransform[0][1] = Bx ;
        pInSAR->slaveAffineTransform[0][0] = Ax ;
        pInSAR->slaveAffineTransform[0][2] = Cx ;
        pInSAR->slaveAffineTransform[1][1] = By ;
        pInSAR->slaveAffineTransform[1][0] = Ay ;
        pInSAR->slaveAffineTransform[1][2] = Cy ;
        
        /* Affine transform precision estimation and gridd completion */
        sigmaY2 = sigmaX2 = sigmaXY2 = 0. ;
        
        for (yIndex = 0; yIndex < yN; yIndex++) {
            gridPoint.y = yIndex ;
            for (xIndex = 0; xIndex < xN; xIndex++) {
                gridPoint.x = xIndex ;
                masterPoint = imageCoordinateForGridCoordinate(xCoregistrationGrid, gridPoint) ;
                planeAffineTransformOfCoord2D(&masterPoint, &slavePoint, pInSAR->slaveAffineTransform) ;
                
                /* If considered point was not coregistered, we assign it the value found for the global affine transform */
                if(xCoregistrationGrid->floatVal[xIndex][yIndex] == floatInf) {
                    xCoregistrationGrid->floatVal[xIndex][yIndex] = slavePoint.x ;
                    yCoregistrationGrid->floatVal[xIndex][yIndex] = slavePoint.y ;
                }
                else {
                    /* Else, we compute the RMS error on anchored points */
                    xSlave = xCoregistrationGrid->floatVal[xIndex][yIndex] ;
                    ySlave = yCoregistrationGrid->floatVal[xIndex][yIndex] ;
                    sigmaX2 += pow((slavePoint.x - xSlave), 2.) ;
                    sigmaY2 += pow((slavePoint.y - ySlave), 2.) ;
                }
            }
        }
        sigmaXY2 = sigmaY2 + sigmaX2 ;
        sigmaY  = sqrt(sigmaY2 /(double)NPcor) ;
        sigmaX  = sqrt(sigmaX2 /(double)NPcor) ;
        sigmaXY = sqrt(sigmaXY2/(double)NPcor) ;

        if (verbose) printf("Found affine transform:\n") ;
        if (verbose) printf("x2 = Ax x1 + Bx y1 + Cx\n Ax = %-21.15f\tBx = %-21.15f\tCx = %-21.15f\n", Ax, Bx, Cx) ;
        if (verbose) printf("\ny2 = Ay x1 + By y1 + Cy\n Ay = %-21.15f\tBy = %-21.15f\tCy = %-21.15f\n", Ay, By, Cy) ;
        if (verbose) printf("\nsigmaRange = %-f\tsigmaAzimuth = %-f\tsigmaRangeAzimuth = %-f\n", sigmaX,sigmaY, sigmaXY) ;
        
        corResults->xTranslation = Sdx /= NPcor ;
        corResults->yTranslation = Sdy /= NPcor ;
        corResults->sigmaXTranslation = sqrt(Sdx2 / NPcor - pow(Sdx, 2.)) ;
        corResults->sigmaYTranslation = sqrt(Sdy2 / NPcor - pow(Sdy, 2.)) ;
        //        printf("\nTranslation: \ndx = %-21.15f\t sigmaX = %-21.15f\ndy = %-21.15f\t sigmaY = %-21.15f\n", Sdx, sqrt(Sdx2 - pow(Sdx, 2.)), Sdy, sqrt(Sdy2 - pow(Sdy, 2.))) ;
        
        corResults->sigmaX = sigmaX ;
        corResults->sigmaXY = sigmaXY ;
        corResults->sigmaY = sigmaY ;
        corResults->coregistrationIndex++ ;
        
        inversePlaneAffineTransform(pInSAR->slaveAffineTransform, pInSAR->inverseSlaveAffineTransform) ;
    }
    
    /* We transfer new coregistration grids into InSAR pointer */
    if (pInSAR->xCoregistrationGrid != NULL) {
        freeGridMap(pInSAR->xCoregistrationGrid) ;
    }
    pInSAR->xCoregistrationGrid = corResults->xCoregistrationGrid = xCoregistrationGrid ;
    
    if (pInSAR->yCoregistrationGrid != NULL) {
        freeGridMap(pInSAR->yCoregistrationGrid) ;
    }
    pInSAR->yCoregistrationGrid = corResults->yCoregistrationGrid = yCoregistrationGrid ;
    
    /* We transfer found transform to coregistration result structure */
    memcpy(corResults->T[0], pInSAR->slaveAffineTransform[0], 6 * sizeof(double)) ;
    
    freeRawFileDescriptor(pInSAR->masterAmplitudeImageFile) ;
    freeRawFileDescriptor(pInSAR->slaveAmplitudeImageFile) ;
    pInSAR->masterAmplitudeImageFile = NULL ;
    pInSAR->slaveAmplitudeImageFile = NULL ;
    
    freeFFT(FFTRange) ;
    freeFFT(FFTAzimut) ;
    freeVectorInt(indx1, 1) ;
    freeVectorDouble(VLx, 1) ;
    freeVectorDouble(VLz, 1) ;
    freeMatrixDouble(ML, 1, 1) ;
    
    freeMatrixFloat(masterAmplitude, 0, 0) ;
    freeMatrixFloat(slaveAmplitude, 0, 0) ;
    freeMatrixComplexFloat(masterWindow, 0, 0) ;
    freeMatrixComplexFloat(slaveWindow, 0, 0) ;
    freeMatrixFloat(lowCutFilter, 0, 0) ;
    
    if (saveIntermediateResults) {
        free(InSARPath) ;
        freeRawFileDescriptor(masterWidowFile) ;
        freeRawFileDescriptor(slaveWidowFile) ;
        freeRawFileDescriptor(correlationWidowFile) ;
        freeMatrixFloat(masterAmplitudeWindow, 0, 0) ;
        freeMatrixFloat(slaveAmplitudeWindow, 0, 0) ;
        freeMatrixFloat(correlationAmplitudeWindow, 0, 0) ;
    }
    
    return (corResults) ;
}




coregistrationResults *fineCoregistrationCore(InSARParametersStruct *pInSAR)
{
    /* local variables declaration */
    char    *aPath ;
    char    withTracking, squareSpiral, verbose ;
    int xDimMaster, xDimSlave, yDimSlave, xCorrelationWindowSize, yCorrelationWindowSize, spi ;
    int j, k, l, m, n ;
    int numberOfBlocs, blocIndex, numberOfAzimuthAnchorPointsPerBloc, azimuthAnchorPointIndexWithinBloc ;
    int masterBlocMinAzimuth, slaveBlocMinAzimuth, slaveBlocMaxAzimuth ;
    int masterWindowCentreXIndex, masterWindowCentreYIndex ;
    int unsigned slaveWindowCentreXIndex, slaveWindowCentreYIndex ;
    int unsigned masterBlocAzimuthSize, slaveBlocAzimuthSize, slaveBlocNewAzimuthSize ;
    int unsigned NPligne, xN, yN, iU, jU ;
    int azimuthError, rangeError ;
    int unsigned iXMaster, iYMaster, iXSlave, iYSlave ;
    int unsigned iXWindow, iYWindow ;
    int *indx1 ;
    int y0Master, x0Master, xWindowShift, yWindowShift ;
    int unsigned xSupDim, ySupDim, xWindowSize, yWindowSize ;
    int yMax, xMax ;
    int unsigned xIndex, yIndex ;
    int xGridMeshSize, yGridMeshSize ;
    off_t    Ldec1, Ldec2 ;
    float    masterNumerator, slaveNumerator, max, maxmax, denumerator ;
    float   interferogrampPhaseValue ;
    float    **coherenceMap ;
    float   **trackingResults = NULL ;
    float   **windowInterferogramPhase, **windowInterferogramAmplitude ;
    double signe, aDoubleValue ;
    double  sigmaY, sigmaY2, sigmaX, sigmaX2, sigmaXY, sigmaXY2 ;
    double    coherenceThreshold ;
    double    A, B, C, D, X0, Y0, Z0, z0_1, z00, z01, z_10, z10 ;
    double xShiftMax, yShiftMax ;
    double    By, Ay, Cy, Bx, Ax, Cx ;
    double    SxS, SyMxS, SxMxS ;
    double    SyS, SyMyS, SxMyS ;
    double    SyM, SxM, SxMyM, SyM2, SxM2 ;
    double  dx, dy, Sdy, Sdx, Sdy2, Sdx2 ;
    double    yMaster, ySlave, xMaster, xSlave, NPcor, Norm ;
    double    **ML, *VLx, *VLz ;
    double *masterWindowCentre, *slaveWindowCentre ;
    complexFloat **complexCoherenceMap ;
    complexFloat **masterImage, **slaveImage ;
    complexFloat numerator, interf, *orbitalPhase, flattenInterf ;
    div_t qr ;
    quadrilateral *masterBlocQuadrilateral, *slaveBlocQuadrilateral, *aoi0 ;
    rawFileDescriptor *trackedCoherence = NULL, *trackedInterferogram = NULL, *trackedMasterImageAmplitude = NULL, *trackedSlaveImageAmplitude = NULL ;
    rawFileDescriptor *azimuthShifts = NULL, *rangeShifts = NULL ;
    gridMap     *xCoregistrationGrid, * yCoregistrationGrid ;
    coord2D     masterPoint, slavePoint, gridPoint ;
    coregistrationResults *corResults ;
    progressCounter *counter = NULL ;
    size_t nRead ;
    rawFileDescriptor *aFile ;
    time_t now ;
    
    /*----------------------------------  INITIALISATION  -----------------------------------*/
    
    genFloatInf() ;
    time(&now) ;
    srandom((int unsigned)now) ;

    /* Read flags */
    withTracking = (pInSAR->flag & WITH_TRACKING) ;
    squareSpiral = (pInSAR->flag & SQUARE_SPIRAL) ;
    verbose = (pInSAR->flag & _VERBOSE_)? 1 : 0 ;
    
    
    /* Read images dimentions */
    xDimMaster = (pInSAR->ima1).lenr ;
    xDimSlave = (pInSAR->ima2).lenr ;
    yDimSlave = (pInSAR->ima2).lena ;
    
    /* Read correlation window size */
    xCorrelationWindowSize = (pInSAR->corf).F_lenr ;
    yCorrelationWindowSize = (pInSAR->corf).F_lena ;
    
    
    /* Read range and azimuth window shifts and displacement ranges */
    xWindowShift = (pInSAR->corf).Depra ;
    yWindowShift = (pInSAR->corf).Depaz ;
    rangeError = (pInSAR->corf).errra ;
    azimuthError = (pInSAR->corf).erraz ;

    /* We fix max shift location of Gaussian maximum to range and azimuth error with respect to previous coregistration */
    xShiftMax = (rangeError > 1) ?(double)rangeError - 1.: 1. ;
    yShiftMax = (azimuthError > 1)? (double)azimuthError - 1.: 1. ;
    
    /* Read thresholds */
    coherenceThreshold = (pInSAR->corf).seuilcoh ;
    
    /* Size of the common area of interest */
    aoi0 = getCopyOfPolygon(pInSAR->aoi) ;
    computeCommonSuperpositionOfImages(pInSAR) ;
    pInSAR->aoi->P[0].x = (aoi0->P[0].x > pInSAR->aoi->P[0].x)? aoi0->P[0].x : pInSAR->aoi->P[0].x ;
    pInSAR->aoi->P[0].y = (aoi0->P[0].y > pInSAR->aoi->P[0].y)? aoi0->P[0].y : pInSAR->aoi->P[0].y ;
    pInSAR->aoi->P[2].x = (aoi0->P[2].x < pInSAR->aoi->P[2].x)? aoi0->P[2].x : pInSAR->aoi->P[2].x ;
    pInSAR->aoi->P[2].y = (aoi0->P[2].y < pInSAR->aoi->P[2].y)? aoi0->P[2].y : pInSAR->aoi->P[2].y ;
    xSupDim = pInSAR->aoi->P[2].x - pInSAR->aoi->P[0].x + 1 ;
    ySupDim = pInSAR->aoi->P[2].y - pInSAR->aoi->P[0].y + 1 ;
    
    /* Size of the window used for local coherence maximum search: */
    //    coa = 2 * (coa / 2) + 1 ;
    //    cor = 2 * (cor / 2) + 1 ;
    spi = 1 ;
    if (squareSpiral) {
        spi = (pInSAR->coh).spi ;
        spi = 2 * (spi / 2) + 1 ;
        spi = (spi < 3)? 3 : spi ;
    }
    xWindowSize = xCorrelationWindowSize + 2 * rangeError + spi - 1 ;
    yWindowSize = yCorrelationWindowSize + 2 * azimuthError + spi - 1 ;
    
    /* Number of candidate anchor points: */
    xN = (xSupDim - xWindowSize) / xWindowShift + 1 ;
    yN = (ySupDim - yWindowSize) / yWindowShift + 1 ;
    
    /* Reduced AoI origin */
    x0Master = pInSAR->aoi->P[0].x ;
    y0Master = pInSAR->aoi->P[0].y ;
    x0Master += (xSupDim - (xWindowSize + (xN - 1) * xWindowShift)) / 2 ;
    y0Master += (ySupDim - (yWindowSize + (yN - 1) * yWindowShift)) / 2 ;
    
    /* Reduced AoI size */
    xSupDim = (xN - 1) * xWindowShift + xWindowSize ;
    ySupDim = (yN - 1) * yWindowShift + yWindowSize ;
    Norm = (double)xSupDim * ySupDim ;
    Norm = 1. ;
    
    /* Coregistration grid allocation and initialization */
    xGridMeshSize = xWindowShift ;
    yGridMeshSize = yWindowShift ;
    xCoregistrationGrid = createFloatGridOfSize(xN, yN, xGridMeshSize, yGridMeshSize) ;
    yCoregistrationGrid = createFloatGridOfSize(xN, yN, xGridMeshSize, yGridMeshSize) ;
    xCoregistrationGrid->x0 = yCoregistrationGrid->x0 = (double)(x0Master + xWindowSize/2) ;
    xCoregistrationGrid->y0 = yCoregistrationGrid->y0 = (double)(y0Master + yWindowSize/2) ;
    xCoregistrationGrid->dimGridX = yCoregistrationGrid->dimGridX = pInSAR->ima1.lenr ;
    xCoregistrationGrid->dimGridY = yCoregistrationGrid->dimGridY = pInSAR->ima1.lena ;
    for (yIndex = 0; yIndex < yN; yIndex++) {
        for (xIndex = 0; xIndex < xN; xIndex++) {
            xCoregistrationGrid->floatVal[xIndex][yIndex] = floatInf ;
            yCoregistrationGrid->floatVal[xIndex][yIndex] = floatInf ;
        }
    }
    
    /* Data will be read by blocs of a given number of azimuth lines */
    /* Max bloc size is given in header file */
    /* Compute the number of line a bloc of MAXBLOCSIZE size could contain */
    masterBlocAzimuthSize = (int)ldiv(MAXBLOCSIZE, xDimMaster * sizeof(complexFloat)).quot ;
    
    /* If AoI fits in a single bloc, consider only image number of lines */
    masterBlocAzimuthSize = (masterBlocAzimuthSize > ySupDim)? ySupDim : masterBlocAzimuthSize ;
    
    /* We limit azimuthBlocSize to an integer number of azimuth anchor points */
    numberOfAzimuthAnchorPointsPerBloc = (int)ldiv(masterBlocAzimuthSize - yWindowSize, (long)yWindowShift).quot + 1 ;
    masterBlocAzimuthSize = (numberOfAzimuthAnchorPointsPerBloc - 1) * yWindowShift + yWindowSize ;
    
    /* We compute the maximum slaveAzimuthBlocSize to take into account rotations and zooms leading to up to a 10% increase */
    slaveBlocAzimuthSize = masterBlocAzimuthSize + masterBlocAzimuthSize / 10 ;
    
    /* Compute number of blocs to be read, including the last one that can be incomplete */
    qr = div(yN, numberOfAzimuthAnchorPointsPerBloc) ;
    numberOfBlocs = (qr.rem)? qr.quot + 1 : qr.quot ;
    
    if (verbose) {
        printf("Fine coregistration based on local maximization of correlation coefficient:\n\n") ;
        printf("Master image: %s\n", (pInSAR->ima1).filePath) ;
        printf("Slave image: %s\n", (pInSAR->ima2).filePath) ;
        printf("Coherence treshold: %-f\n", coherenceThreshold) ;
        printf("Coherence estimator window size: %d x %d ((range x azimuth pixels)\n", xCorrelationWindowSize, yCorrelationWindowSize) ;
        printf("Window shift: %d x %d ((range x azimuth pixels)\n", xWindowShift, yWindowShift) ;
        printf("Number of candidate anchor points (range x azimuth): %-d X %-d = %-d\n", xN, yN, xN * yN) ;
        
        printf( "\n============================ PROCESS =================================\n" ) ;
    }
    else {
        counter = initProgressCounterWithMinMaxValue(0, yN - 1) ;
    }
    
    /* Open master and slave image files */
    if ((pInSAR->masterImageFile = openRawFileForReadingAtPath((pInSAR->ima1).filePath)) == NULL) {
        perror("Failed to open master imgae\n") ;
        exit(-1) ;
    }
    if ((pInSAR->slaveImageFile = openRawFileForReadingAtPath((pInSAR->ima2).filePath)) == NULL) {
        perror("Failed to open slave imgae\n") ;
        exit(-1) ;
    }
    
    /* Create tracking output result files */
    aPath = getDirectoryPathFromPath(pInSAR->interf.filePath) ;
    if (withTracking) {
        trackingResults = matrixFloat(0, 5, 0, xN - 1) ;
        sprintf (accessPath , "%s/%s", aPath , "trackedInterferogram") ;
        trackedInterferogram = openRawFileForWritingAtPath(accessPath) ;
        sprintf (accessPath , "%s/%s", aPath , "trackedCoherence") ;
        trackedCoherence = openRawFileForWritingAtPath(accessPath) ;
        sprintf (accessPath , "%s/%s", aPath , "azimuthShifts") ;
        azimuthShifts = openRawFileForWritingAtPath(accessPath) ;
        sprintf (accessPath , "%s/%s", aPath , "rangeShifts") ;
        rangeShifts = openRawFileForWritingAtPath(accessPath) ;
        sprintf (accessPath , "%s/%s", aPath , "trackedMasterImageAmplitude") ;
        trackedMasterImageAmplitude = openRawFileForWritingAtPath(accessPath) ;
        sprintf (accessPath , "%s/%s", aPath , "trackedSlaveImageAmplitude") ;
        trackedSlaveImageAmplitude = openRawFileForWritingAtPath(accessPath) ;
    }
    
    /* ------------------------------- memory allocation --------------------------------------*/
    masterImage = matrixComplexFloat(0, masterBlocAzimuthSize - 1, 0, xDimMaster - 1) ;
    slaveImage = matrixComplexFloat(0, slaveBlocAzimuthSize - 1, 0, xDimSlave - 1) ;
    coherenceMap = matrixFloat(-azimuthError, azimuthError, -rangeError, rangeError) ;
    complexCoherenceMap = matrixComplexFloat(-azimuthError, azimuthError, -rangeError, rangeError) ;
    orbitalPhase = vectorComplexFloat(0, xDimMaster - 1) ;
    windowInterferogramPhase = matrixFloat(0, yCorrelationWindowSize + spi - 1, 0, xCorrelationWindowSize + spi - 1) ;
    windowInterferogramAmplitude = matrixFloat(0, yCorrelationWindowSize + spi - 1, 0, xCorrelationWindowSize + spi - 1) ;
    corResults = pInSAR->corResults ;
    if (pInSAR->corResults == NULL) {
        corResults = allocCoregistrationResults() ;
    }
    
    ML = matrixDouble(1, 3, 1, 3) ;
    VLx = vectorDouble(1, 3) ;
    VLz = vectorDouble(1, 3) ;
    indx1 = vectorInt(1, 3) ;
    
    masterWindowCentre = vectorDouble(0, 1) ;
    slaveWindowCentre = vectorDouble(0, 1) ;
    masterBlocQuadrilateral = allocQuadrilateral() ;
    slaveBlocQuadrilateral = allocQuadrilateral() ;
    
    /* ------------------- Corelation ------------------- */
    
    SxS = SyMxS = SxMxS = 0 ;
    SyS = SyMyS = SxMyS = 0 ;
    SyM = SxM = SxMyM = SyM2 = SxM2 = NPcor = 0. ;
    Sdx = Sdy = Sdx2 = Sdy2 = 0. ;
    
    blocIndex = masterBlocMinAzimuth = slaveBlocMinAzimuth = 0 ;
    azimuthAnchorPointIndexWithinBloc = numberOfAzimuthAnchorPointsPerBloc - 1 ;
    for(iU = 0; iU < yN; iU++) {
        maxmax = 0. ;
        NPligne = 0 ;
        
        azimuthAnchorPointIndexWithinBloc++ ;
        if(azimuthAnchorPointIndexWithinBloc == numberOfAzimuthAnchorPointsPerBloc) {
            if(blocIndex == numberOfBlocs - 1)
                masterBlocAzimuthSize = (yN - iU - 1) * yWindowShift + yWindowSize ;
            
            /* Read bloc of data in master image */
            masterBlocMinAzimuth = y0Master + iU * yWindowShift ;
            Ldec1 = (off_t)masterBlocMinAzimuth * xDimMaster * sizeof(complexFloat) ;
            fseeko(pInSAR->masterImageFile->f, Ldec1, SEEK_SET) ;
            if(fread ((complexFloat *)masterImage[0], sizeof(complexFloat), masterBlocAzimuthSize * xDimMaster, pInSAR->masterImageFile->f) != masterBlocAzimuthSize * xDimMaster)
                ase("Failed to read data in master image file\n") ;
            
            /* Define masterBlocQuadrilateral, iU.e. the location of the bloc within the image */
            masterBlocQuadrilateral->P[0].x = masterBlocQuadrilateral->P[3].x = x0Master ;
            masterBlocQuadrilateral->P[1].x = masterBlocQuadrilateral->P[2].x = x0Master + xSupDim - 1 ;
            masterBlocQuadrilateral->P[0].y = masterBlocQuadrilateral->P[1].y = masterBlocMinAzimuth ;
            masterBlocQuadrilateral->P[2].y = masterBlocQuadrilateral->P[3].y = masterBlocMinAzimuth + masterBlocAzimuthSize - 1 ;
            /* Find corresponding slaveBlocQuadrilateral */
            planeAffineTransformOfPolygon(masterBlocQuadrilateral, slaveBlocQuadrilateral, pInSAR->slaveAffineTransform) ;
            
            /* Find azimuth range within slave image */
            aDoubleValue = yDimSlave ;
            for(j = 0; j < 4; j++) {
                aDoubleValue = (aDoubleValue < slaveBlocQuadrilateral->P[j].y)? aDoubleValue : slaveBlocQuadrilateral->P[j].y ;
            }
            slaveBlocMinAzimuth = (aDoubleValue < 0)? 0: (int)round(aDoubleValue) ;
            
            slaveBlocMaxAzimuth = 0 ;
            for(j = 0; j < 4; j++) {
                aDoubleValue = (aDoubleValue > slaveBlocQuadrilateral->P[j].y)? aDoubleValue : slaveBlocQuadrilateral->P[j].y ;
            }
            slaveBlocMaxAzimuth = (aDoubleValue > (double)yDimSlave - 1.)? yDimSlave - 1: (int)round(aDoubleValue) ;
            
            /* If slave bloc size bigger than expected, we reallocate it */
            slaveBlocNewAzimuthSize = slaveBlocMaxAzimuth - slaveBlocMinAzimuth + 1 ;
            if (slaveBlocNewAzimuthSize > slaveBlocAzimuthSize) {
                freeMatrixComplexFloat(slaveImage, 0, 0) ;
                slaveImage = matrixComplexFloat(0, slaveBlocNewAzimuthSize - 1, 0, xDimSlave - 1) ;
            }
            slaveBlocAzimuthSize = slaveBlocNewAzimuthSize ;
            
            /* Read slave Bloc */
            Ldec2 = (off_t)slaveBlocMinAzimuth * xDimSlave * sizeof(complexFloat) ;
            if(fseeko(pInSAR->slaveImageFile->f, Ldec2, SEEK_SET))
                ase("Failed to seek into slave image file") ;
            if((nRead = fread ((complexFloat *)slaveImage[0], sizeof(complexFloat), slaveBlocAzimuthSize * xDimSlave, pInSAR->slaveImageFile->f)) != slaveBlocAzimuthSize * xDimSlave) {
                printf("Number of read elements: %zu/%d\n", nRead, slaveBlocAzimuthSize * xDimSlave) ;
                if (errno == EFAULT) {
                    printf("Buf points outside the allocated address space\n") ;
                }
                ase("Failed to read data in slave image file\n") ;
            }
            
            blocIndex++;
            azimuthAnchorPointIndexWithinBloc = 0;
        }
        
        masterWindowCentreYIndex = azimuthAnchorPointIndexWithinBloc * yWindowShift + yWindowSize / 2 ;
        masterWindowCentre[1] = (double)(masterBlocMinAzimuth + masterWindowCentreYIndex) ;
        for(j = 0; j < xDimMaster; j++) {
            orbitalPhase[j] = complexOrbitalPhaseAtPoint((double)j, masterWindowCentre[1], pInSAR) ;
        }
        
        
        for(jU = 0; jU < xN; jU++) {
            masterWindowCentreXIndex = x0Master + jU * xWindowShift + xWindowSize / 2 ;
            masterWindowCentre[0] = (double)(masterWindowCentreXIndex) ;
            planeAffineTransformOfPoint(masterWindowCentre, slaveWindowCentre, pInSAR->slaveAffineTransform) ;
            
            slaveWindowCentreXIndex = (int)round(slaveWindowCentre[0]) ;
            slaveWindowCentreXIndex = (slaveWindowCentreXIndex < xWindowSize / 2)? xWindowSize / 2 : slaveWindowCentreXIndex ;
            slaveWindowCentreXIndex = (slaveWindowCentreXIndex > xDimMaster - xWindowSize / 2)? xDimMaster - xWindowSize / 2 : slaveWindowCentreXIndex ;
            
            slaveWindowCentreYIndex = (int)round(slaveWindowCentre[1]) - slaveBlocMinAzimuth ;
            slaveWindowCentreYIndex = (slaveWindowCentreYIndex < yWindowSize / 2)? yWindowSize / 2 : slaveWindowCentreYIndex ;
            slaveWindowCentreYIndex = (slaveWindowCentreYIndex > slaveBlocAzimuthSize - yWindowSize / 2)? slaveBlocAzimuthSize - yWindowSize / 2 : slaveWindowCentreYIndex ;

            if (withTracking) {
                trackingResults[2][jU] = trackingResults[3][jU] = floatNaN ;
            }

            max = 0. ;
            yMax = xMax = 0 ;
            for(k = -azimuthError; k <= azimuthError; k++) {
                for(l = -rangeError; l <= rangeError; l++) {
                    
                    if (squareSpiral) {
                        /* Compute the interferogram for the current window */
                        iYMaster = masterWindowCentreYIndex - yCorrelationWindowSize / 2 - spi / 2 + k ;
                        iYSlave = slaveWindowCentreYIndex - yCorrelationWindowSize / 2 - spi / 2 ;
                        for(m = 0; m < yCorrelationWindowSize + spi - 1; m++, iYMaster++, iYSlave++) {
                            iXMaster = masterWindowCentreXIndex - xCorrelationWindowSize / 2 - spi / 2 + l ;
                            iXSlave = slaveWindowCentreXIndex - xCorrelationWindowSize / 2 - spi / 2 ;
                            for(n = 0; n < xCorrelationWindowSize + spi - 1; n++, iXMaster++, iXSlave++) {
                                interf = mC(masterImage[iYMaster][iXMaster], cC(slaveImage[iYSlave][iXSlave])) ;
                                flattenInterf = mC(interf, cC(orbitalPhase[iXMaster])) ;
                                windowInterferogramPhase[m][n] = phiC(flattenInterf) ;
                                windowInterferogramAmplitude[m][n] = modC(flattenInterf) ;
                            }
                        }
                        
                    }
                    
                    iYMaster = masterWindowCentreYIndex - yCorrelationWindowSize / 2 + k ;
                    iYSlave = slaveWindowCentreYIndex - yCorrelationWindowSize / 2 ;
                    numerator.r = numerator.i = masterNumerator = slaveNumerator = 0. ;
                    for(m = 0; m < yCorrelationWindowSize; m++, iYMaster++, iYSlave++) {
                        iXMaster = masterWindowCentreXIndex - xCorrelationWindowSize / 2 + l ;
                        iXSlave = slaveWindowCentreXIndex - xCorrelationWindowSize / 2 ;
                        iYWindow = spi / 2 + m ;
                        for(n = 0; n < xCorrelationWindowSize; n++, iXMaster++, iXSlave++) {
                            if (squareSpiral) {
                                iXWindow = spi / 2 + n ;
                                interferogrampPhaseValue = windowInterferogramPhase[iYWindow][iXWindow] - squareSpiralPhaseUnwrapping(windowInterferogramPhase, spi, iYWindow, iXWindow) ;
                                numerator.r += cosf(interferogrampPhaseValue) * windowInterferogramAmplitude[iYWindow][iXWindow] ;
                                numerator.i += sinf(interferogrampPhaseValue) * windowInterferogramAmplitude[iYWindow][iXWindow] ;
                            }
                            else {
                                interf = mC(masterImage[iYMaster][iXMaster], cC(slaveImage[iYSlave][iXSlave])) ;
                                flattenInterf = mC(interf, cC(orbitalPhase[iXMaster])) ;
                                numerator.r += flattenInterf.r ;
                                numerator.i += flattenInterf.i ;
                            }
                            masterNumerator += sqmC(masterImage[iYMaster][iXMaster]) ;
                            slaveNumerator += sqmC(slaveImage[iYSlave][iXSlave]) ;
                        }
                    }
                    denumerator = sqrtf(masterNumerator * slaveNumerator) ;
                    coherenceMap[k][l] = (denumerator)? sqrtf(numerator.r * numerator.r + numerator.i * numerator.i)/denumerator : (float)(1.0e-10) ;
                    memcpy(complexCoherenceMap[k] + l, &numerator, sizeof(complexFloat)) ;
                    if (coherenceMap[k][l] > max) {
                        max = coherenceMap[k][l] ;
                        yMax = k ;
                        xMax = l ;
                        if (withTracking) {
                            trackingResults[0][jU] = max = coherenceMap[k][l] ;
                            trackingResults[1][jU] = phi(&numerator) ;
                            trackingResults[4][jU] = masterNumerator ;
                            trackingResults[5][jU] = slaveNumerator ;
                        }
                    }
                    
                }
            }

            if ((max < .999) && (max > coherenceThreshold) && (yMax > -azimuthError) && (yMax < azimuthError) && (xMax > -rangeError) && (xMax < rangeError)) {
                maxmax = (max>maxmax)? max : maxmax ;
                z0_1 = (double)coherenceMap[yMax - 1][xMax] ;
                z00 = (double)coherenceMap[yMax][xMax] ;
                z01 = (double)coherenceMap[yMax +1 ][xMax] ;
                z_10 = (double)coherenceMap[yMax][xMax - 1] ;
                z10 = (double)coherenceMap[yMax][xMax + 1] ;
                if(z0_1 && z00 && z01 && z_10 && z10) {
                    A = (log(z_10) + log(z10))/2. -  log(z00) ;
                    B = (log(z0_1) + log(z01))/2. -  log(z00) ;
                    if ((A < 0) && (B < 0)) {
                        C = (log(z10) - log(z_10))/2. ;
                        D = (log(z01) - log(z0_1))/2. ;
                        X0 = -.5 * C / A + (double)xMax ;
                        Y0 = -.5 * D / B + (double)yMax ;
                        if (fabs(X0) < xShiftMax && fabs(Y0) < yShiftMax) {
                                                    
                            Z0 = z00 * exp(-A * X0 * X0 - B * Y0 * Y0) ;

                            if ((pInSAR->flag & _SAVE_ITERMEDIATE_RESULTS_) && (aRandomNumberBetweenValues(0, 1) > .999)) {
                                sprintf (accessPath , "%s/cohTrack%dx%d.gnuplot", aPath , jU, iU) ;
                                aFile = openRawFileForWritingAtPath(accessPath) ;
                                fprintf(aFile->f, "# Anchor point (%d ; %d)\n", jU, iU) ;
                                fprintf(aFile->f, "# Gaussian centre estimate: (X0 ; X0) = (%5.2lf ; %5.2lf)\n", X0, Y0) ;
                                fprintf(aFile->f, "# Gaussian sigma estimates: (sX0 ; sY0) = (%5.2lf ; %5.2lf)\n", 1./sqrt(-A), 1./sqrt(-B)) ;
                                fprintf(aFile->f, "# Gaussian max value at centre: Z0 = %5.2lf\n\n", Z0) ;
                                fprintf(aFile->f, "# Coherence map:\n") ;
                                fprintf(aFile->f, "$cohMap << EOD\n") ;
                                for(k = -azimuthError; k <= azimuthError; k++) {
                                    for(l = -rangeError; l <= rangeError; l++) {
                                            fprintf(aFile->f, "\t%5.2lf", coherenceMap[k][l]) ;
                                    }
                                    fprintf(aFile->f, "\n") ;
                                }
                                fprintf(aFile->f, "EOD\n") ;
                                fprintf(aFile->f, "\n\n# Anchor point: \n") ;
                                fprintf(aFile->f, "x = %d\n", jU) ;
                                fprintf(aFile->f, "y = %d\n", iU) ;
                                fprintf(aFile->f, "# Gaussian def:\n") ;
                                fprintf(aFile->f, "X0 = %5.2lf + 3\n", X0) ;
                                fprintf(aFile->f, "Y0 = %5.2lf + 3\n", Y0) ;
                                fprintf(aFile->f, "sX0 = %5.2lf\n", 1./sqrt(-A)) ;
                                fprintf(aFile->f, "sY0 = %5.2lf\n", 1./sqrt(-B)) ;

                                fprintf(aFile->f, "outputFile = sprintf(\"./cohTrack%%dx%%d.png\", x, y)\n") ;
                                fprintf(aFile->f, "set output outputFile\n") ;
                                fprintf(aFile->f, "set terminal png size 640, 380 #transparent truecolor\n") ;
                                fprintf(aFile->f, "# set grid\n") ;
                                fprintf(aFile->f, "# set hidden3d\n") ;
                                fprintf(aFile->f, "set style line 1 palette pointsize 3 pointtype 7\n") ;
                                fprintf(aFile->f, "set isosamples 28\n") ;
                                fprintf(aFile->f, "set xrange [0 : %d]\n", 2 * rangeError) ;
                                fprintf(aFile->f, "set yrange [0 : %d]\n", 2 * azimuthError) ;
                                fprintf(aFile->f, "set view 20, 10, 1, 3\n") ;
                                fprintf(aFile->f, "set ticslevel 0.0\n") ;
                                fprintf(aFile->f, "set xtics (\"-3\" 0, \"-2\" 1, \"-1\" 2, \"0\" 3, \"1\" 4, \"2\" 5, \"3\" 6)\n") ;
                                fprintf(aFile->f, "set ytics (\"-3\" 0, \"-2\" 1, \"-1\" 2, \"0\" 3, \"1\" 4, \"2\" 5, \"3\" 6)\n") ;
                                fprintf(aFile->f, "splot '$cohMap' matrix with points ls 1, exp(-(x - X0)**2 / sX0**2 - (y - Y0)**2 / sY0**2)\n") ;



                                freeRawFileDescriptor(aFile) ;
                            }
                        


                            yMaster = (masterWindowCentre[1]) / Norm ;
                            xMaster = (masterWindowCentre[0]) / Norm ;
                            ySlave = ((double)(slaveWindowCentreYIndex + slaveBlocMinAzimuth) - Y0) / Norm ;
                            xSlave = (slaveWindowCentreXIndex - X0) / Norm ;
                            
                            xCoregistrationGrid->floatVal[jU][iU] = xSlave * Norm ;
                            yCoregistrationGrid->floatVal[jU][iU] = ySlave * Norm ;
                            
                            SxS += xSlave ;
                            SyMxS += yMaster * xSlave ;
                            SxMxS += xMaster * xSlave ;
                            
                            SyS += ySlave ;
                            SyMyS += yMaster * ySlave ;
                            SxMyS += xMaster * ySlave ;
                            
                            SyM += yMaster ;
                            SxM += xMaster ;
                            SyM2 += yMaster * yMaster ;
                            SxM2 += xMaster * xMaster ;
                            SxMyM += yMaster * xMaster ;
                            NPcor += 1. ;
                            NPligne++ ;
                            
                            //                        dx = xSlave - pInSAR->slaveAffineTransform[0][0] * xMaster - pInSAR->slaveAffineTransform[0][1] * yMaster ;
                            //                        dy = ySlave - pInSAR->slaveAffineTransform[1][0] * xMaster - pInSAR->slaveAffineTransform[1][1] * yMaster ;
                            dx = xSlave - xMaster ;
                            dy = ySlave - yMaster ;
                            Sdx += dx ;
                            Sdy += dy ;
                            Sdx2 += pow(dx, 2.) ;
                            Sdy2 += pow(dy, 2.) ;
                            
                            if (withTracking) {
                                /*
                                dx = xMax - X0 ;
                                dy = yMax - Y0 ;
                                k = (dx < 0)? xMax : xMax - 1 ;
                                l = (dy < 0)? yMax : yMax - 1 ;
                                numerator.r = (1. - dy) * (dx * complexCoherenceMap[k + 1][l].r + (1. - dx) * complexCoherenceMap[k][l].r) + dy * (dx * complexCoherenceMap[k + 1][l + 1].r + (1. - dx) * complexCoherenceMap[k][l + 1].r);
                                numerator.i = (1. - dy) * (dx * complexCoherenceMap[k + 1][l].i + (1. - dx) * complexCoherenceMap[k][l].i) + dy * (dx * complexCoherenceMap[k + 1][l + 1].i + (1. - dx) * complexCoherenceMap[k][l + 1].i);
                                
                                trackingResults[1][jU] = phi(&numerator) ;
                                */
                                trackingResults[2][jU] = (ySlave - yMaster) * Norm ;
                                trackingResults[3][jU] = (xSlave - xMaster) * Norm ;
                            }
                        }
                    }
                }
            }
        }
        if (withTracking) {
            fwrite((float *)trackingResults[0], sizeof(float), xN, trackedCoherence->f) ;
            fwrite((float *)trackingResults[1], sizeof(float), xN, trackedInterferogram->f) ;
            fwrite((float *)trackingResults[2], sizeof(float), xN, azimuthShifts->f) ;
            fwrite((float *)trackingResults[3], sizeof(float), xN, rangeShifts->f) ;
            fwrite((float *)trackingResults[4], sizeof(float), xN, trackedMasterImageAmplitude->f) ;
            fwrite((float *)trackingResults[5], sizeof(float), xN, trackedSlaveImageAmplitude->f) ;
        }
        if (verbose) {
            printf("Line %-d; Number of found anchor points: %-d\t Maximum coherence = %-f\n", iU, NPligne, maxmax) ;
        }
        else {
            updatePointProgressCounterForIndex(counter, iU) ;
        }
    }
    if (withTracking) {
        freeRawFileDescriptor(trackedCoherence) ;
        freeRawFileDescriptor(trackedInterferogram) ;
        freeRawFileDescriptor(trackedMasterImageAmplitude) ;
        freeRawFileDescriptor(trackedSlaveImageAmplitude) ;
        freeRawFileDescriptor(azimuthShifts) ;
        freeRawFileDescriptor(rangeShifts) ;
    }
    
    VLx[1] = SyS ;
    VLx[2] = SyMyS ;
    VLx[3] = SxMyS ;
    
    VLz[1] = SxS ;
    VLz[2] = SyMxS ;
    VLz[3] = SxMxS ;
    
    ML[1][1] = NPcor ;
    ML[1][2] = ML[2][1] = SyM ;
    ML[1][3] = ML[3][1] = SxM ;
    ML[2][3] = ML[3][2] = SxMyM ;
    ML[2][2] = SyM2 ;
    ML[3][3] = SxM2 ;
    
    if (verbose) {
        printf("\nCoregistration results:\n") ;
        printf("*************************\n") ;
        printf("Total number of anchor points: %-d .\n", (int)NPcor) ;
    }    
    corResults->numberOfRegisteredPoints = NPcor ;
    corResults->numberOfCandidatePoints = xN * yN ;
    corResults->sigmaX = corResults->sigmaY = corResults->sigmaXY = 0 ;
    
    /* If not enough points to compute a new transform, update coregistration grids and display anchored points */
    if(NPcor < 4) {
        if (verbose) printf("Less than 4 points where anchored.\n") ;
        for (yIndex = 0; yIndex < yN; yIndex++) {
            gridPoint.y = yIndex ;
            for (xIndex = 0; xIndex < xN; xIndex++) {
                gridPoint.x = xIndex ;
                masterPoint = imageCoordinateForGridCoordinate(xCoregistrationGrid, gridPoint) ;
                planeAffineTransformOfCoord2D(&masterPoint, &slavePoint, pInSAR->slaveAffineTransform) ;
                
                /* If considered point was not coregistered, we assign it the value found for the global affine transform */
                if(xCoregistrationGrid->floatVal[xIndex][yIndex] == floatInf) {
                    xCoregistrationGrid->floatVal[xIndex][yIndex] = slavePoint.x ;
                    yCoregistrationGrid->floatVal[xIndex][yIndex] = slavePoint.y ;
                }
                else {
                    /* Else, we display anchored points */
                    if (verbose) {
                        xSlave = xCoregistrationGrid->floatVal[xIndex][yIndex] ;
                        ySlave = yCoregistrationGrid->floatVal[xIndex][yIndex] ;
                        printf("x1 = %f    x2 = %f    dx = %f\n", masterPoint.x, xSlave, masterPoint.x - xSlave) ;
                        printf("y1 = %f    y2 = %f    dy = %f\n\n", masterPoint.y, ySlave, masterPoint.y - ySlave) ;
                    }
                }
            }
        }
    }
    else {
        ludcmp(ML, 3, indx1, &signe) ;
        lubksb(ML, 3, indx1, VLx) ;
        lubksb(ML, 3, indx1, VLz) ;
        
        Bx = VLz[2] ;
        Ax = VLz[3] ;
        Cx = VLz[1] ;
        By = VLx[2] ;
        Ay = VLx[3] ;
        Cy = VLx[1] ;
        Cx *= Norm ;
        Cy *= Norm ;
        
        
        pInSAR->slaveAffineTransform[0][1] = Bx ;
        pInSAR->slaveAffineTransform[0][0] = Ax ;
        pInSAR->slaveAffineTransform[0][2] = Cx ;
        pInSAR->slaveAffineTransform[1][1] = By ;
        pInSAR->slaveAffineTransform[1][0] = Ay ;
        pInSAR->slaveAffineTransform[1][2] = Cy ;
        
        /* Affine transform precision estimation and gridd completion */
        sigmaY2 = sigmaX2 = sigmaXY2 = 0. ;
        for (yIndex = 0; yIndex < yN; yIndex++) {
            gridPoint.y = yIndex ;
            for (xIndex = 0; xIndex < xN; xIndex++) {
                gridPoint.x = xIndex ;
                masterPoint = imageCoordinateForGridCoordinate(xCoregistrationGrid, gridPoint) ;
                planeAffineTransformOfCoord2D(&masterPoint, &slavePoint, pInSAR->slaveAffineTransform) ;
                
                /* If considered point was not coregistered, we assign it the value found for the global affine transform */
                if(xCoregistrationGrid->floatVal[xIndex][yIndex] == floatInf) {
                    xCoregistrationGrid->floatVal[xIndex][yIndex] = slavePoint.x ;
                    yCoregistrationGrid->floatVal[xIndex][yIndex] = slavePoint.y ;
                }
                else {
                    /* Else, we compute the RMS error on anchored points */
                    xSlave = xCoregistrationGrid->floatVal[xIndex][yIndex] ;
                    ySlave = yCoregistrationGrid->floatVal[xIndex][yIndex] ;
                    sigmaX2 += pow((slavePoint.x - xSlave), 2.) ;
                    sigmaY2 += pow((slavePoint.y - ySlave), 2.) ;
                }
            }
        }
        sigmaXY2 = sigmaY2 + sigmaX2 ;
        sigmaY  = sqrt(sigmaY2 /(double)NPcor) ;
        sigmaX  = sqrt(sigmaX2 /(double)NPcor) ;
        sigmaXY = sqrt(sigmaXY2/(double)NPcor) ;
        
        if (verbose) {
            printf("Found affine transform:\n") ;
            printf("x2 = Ax x1 + Bx y1 + Cx\n Ax = %-21.15f\tBx = %-21.15f\tCx = %-21.15f\n", Ax, Bx, Cx) ;
            printf("\ny2 = Ay x1 + By y1 + Cy\n Ay = %-21.15f\tBy = %-21.15f\tCy = %-21.15f\n", Ay, By, Cy) ;
            printf("\nsigmaRange = %-f\tsigmaAzimuth = %-f\tsigmaRangeAzimuth = %-f\n", sigmaX,sigmaY, sigmaXY) ;
        }
        
        corResults->xTranslation = Sdx /= NPcor / Norm ;
        corResults->yTranslation = Sdy /= NPcor / Norm ;
        corResults->sigmaXTranslation = sqrt(Sdx2 * pow(Norm, 2.) / NPcor - pow(Sdx, 2.)) ;
        corResults->sigmaYTranslation = sqrt(Sdy2 * pow(Norm, 2.) / NPcor - pow(Sdy, 2.)) ;
        if (verbose) {
            printf("\n\nTranslation: \ndx = %-21.15f\t sigmaX = %-21.15f\ndy = %-21.15f\t sigmaY = %-21.15f\n", Sdx, corResults->sigmaXTranslation, Sdy, corResults->sigmaYTranslation) ;
        }
        
        corResults->sigmaX = sigmaX ;
        corResults->sigmaXY = sigmaXY ;
        corResults->sigmaY = sigmaY ;
        corResults->coregistrationIndex++ ;
        
        inversePlaneAffineTransform(pInSAR->slaveAffineTransform, pInSAR->inverseSlaveAffineTransform) ;
    }
    
    /* We transfer new coregistration grids into InSAR pointer */
    if (pInSAR->xCoregistrationGrid != NULL) {
        freeGridMap(pInSAR->xCoregistrationGrid) ;
    }
    pInSAR->xCoregistrationGrid = corResults->xCoregistrationGrid = xCoregistrationGrid ;
    if (pInSAR->yCoregistrationGrid != NULL) {
        freeGridMap(pInSAR->yCoregistrationGrid) ;
    }
    pInSAR->yCoregistrationGrid = corResults->yCoregistrationGrid = yCoregistrationGrid ;
    
    /* We transfer found transform to coregistration result structure */
    memcpy(corResults->T[0], pInSAR->slaveAffineTransform[0], 6 * sizeof(double)) ;
    
    freeMatrixComplexFloat(masterImage, 0, 0) ;
    freeMatrixComplexFloat(slaveImage, 0, 0) ;
    freeMatrixFloat(coherenceMap, -azimuthError, -rangeError) ;
    freeMatrixComplexFloat(complexCoherenceMap, -azimuthError, -rangeError) ;
    freeVectorComplexFloat(orbitalPhase, 0) ;
    freeMatrixFloat(windowInterferogramPhase, 0, 0) ;
    freeMatrixFloat(windowInterferogramAmplitude, 0, 0) ;
    
    freeVectorInt(indx1, 1) ;
    freeVectorDouble(VLx, 1) ;
    freeVectorDouble(VLz, 1) ;
    freeMatrixDouble(ML, 1, 1) ;
    
    freeRawFileDescriptor(pInSAR->masterImageFile) ;
    pInSAR->masterImageFile = NULL ;
    freeRawFileDescriptor(pInSAR->slaveImageFile) ;
    pInSAR->slaveImageFile = NULL ;

    free(aPath) ;
    
    return (corResults) ;
}


