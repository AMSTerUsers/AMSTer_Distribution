
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  paramInSAR.h
 *  initInSAR
 *
 *  Created  a long time ago and upgraded by Dominique Derauw on Wed Oct 18 2011.
 *  Copyright (c) 1993 Dominique Derauw. All rights reserved.
 *
 */



/* ________________ InSAR parameters file reading  ________________ */

#include "paramInSAR.h"


InSARParametersStruct *allocInSARParametersStruct(void)
{
    InSARParametersStruct *pInSAR ;

    if ((pInSAR = (InSARParametersStruct *)calloc (1, sizeof(InSARParametersStruct))) == NULL) {
		sprintf (ertex, "Failed to allocated InSAR parameters structure") ;
		perror (ertex) ;
        exit(-1) ;
	}
    pInSAR->isBistaticPair = 0 ;
    pInSAR->masterImage = NULL ;
    pInSAR->masterInfo = NULL ;
    pInSAR->slaveImage = NULL ;
    pInSAR->interpolatedSlaveInfo = NULL ;
    pInSAR->slaveInfo = NULL ;
    pInSAR->orbitTypes = NULL ;
    pInSAR->aoiKml = NULL ;
    pInSAR->externalReferenceDEM = NULL ;
    pInSAR->thresholdedSlantRangeMask = NULL ;
    pInSAR->slantRangeMask = NULL ;
    pInSAR->geo = NULL ;
    pInSAR->flag = _VERBOSE_ ;

    /* Init coregistration result to null */
    pInSAR->corResults = NULL ;
    pInSAR->xCoregistrationGrid = NULL ;
    pInSAR->yCoregistrationGrid = NULL ;

    /* init coherence median filter to zero */
    pInSAR->coh.medianFilterSize = 0 ;

    /* Initialize master interpolation parameters */
    pInSAR->masterInterpolation = 0 ;
    pInSAR->interpolatedMaster = NULL ;

    pInSAR->SM2MPath = NULL ;
    pInSAR->SM2MpInSAR = NULL ;
    pInSAR->masterAffineTransform = allocUnitaryAffineTransform() ;
    pInSAR->xShift = 0 ;
    pInSAR->yShift = 0 ;

	initRawFileDescriptorsToNullInInSARParameterStructure(pInSAR) ;

    return (pInSAR) ;
}

InSARParametersStruct *allocAndinitInSARParametersStructAtPathForImages(char *InSARPath, CSLImage *master, CSLImage *slave, InSARParametersStruct *SM2MpInSAR, char isBistatic, char *preferredPolarization)
{
	char *aFilePath, *aFileName, *extension ;
    char isTDM = 0 ;
    int k, l, Fra, Faz ;
    int tempInt ;
    double xSampling, ySampling, delta, delta0, tempVal = 0 ; 
	InSARParametersStruct *pInSAR ;
	CSVStruct *csvInSARPath ;

    pInSAR = allocInSARParametersStruct() ;

    genFloatNaN() ;
    genFloatInf() ;

	pInSAR->masterImage = master ;
	pInSAR->slaveImage = slave ;

    /* Read master info and interpolate orbit */
	aFilePath = initStringWith2Strings((pInSAR->masterImage)->infoDirectoryPath, "/SLCImageInfo.txt") ;
	pInSAR->masterInfo = readInfoImageFromTextFile(aFilePath) ;
	free(aFilePath) ;
    orbitInterpolation(pInSAR->masterInfo) ;
    /* For compatibility with CSL CIS */
    if (!pInSAR->masterInfo->incidenceAngle[1]) {
        geolocateSceneOnEllipsoid(pInSAR->masterInfo, pInSAR->masterInfo->ellRef) ;
    }
    
//    sceneAverageHeightCrossCheck(pInSAR->masterInfo) ;

    /* Read slave info and interpolate orbit */
	aFilePath = initStringWith2Strings((pInSAR->slaveImage)->infoDirectoryPath, "/SLCImageInfo.txt") ;
	pInSAR->slaveInfo = readInfoImageFromTextFile(aFilePath) ;
	free(aFilePath) ;
    orbitInterpolation(pInSAR->slaveInfo) ;
    /* Determine which orbit type we are using */
    if (pInSAR->masterInfo->orbitTypeID && pInSAR->slaveInfo->orbitTypeID) {
        pInSAR->orbitTypes = initStringWith3Strings(pInSAR->masterInfo->orbitTypeID, " - ", pInSAR->slaveInfo->orbitTypeID) ;
    }
    
//    sceneAverageHeightCrossCheck(pInSAR->slaveInfo) ;

    /* Determine destination directory */
    if (InSARPath == NULL) {
        aFilePath = getDirectoryPathFromPath(pInSAR->masterImage->imageDirectoryPath) ;
        aFileName = initStringWith4Strings("i", pInSAR->masterInfo->acquisitionDate, "_", pInSAR->slaveInfo->acquisitionDate) ;
        InSARPath = initStringWith2Strings(aFilePath, aFileName) ;
        free(aFilePath) ;
        free(aFileName) ;
    }
    else {
        csvInSARPath = readCSVInString(InSARPath) ;
        if (csvInSARPath->numberOfEntries == 2) {
            free(InSARPath) ;
            aFileName = initStringWith4Strings("/i", pInSAR->masterInfo->acquisitionDate, "_", pInSAR->slaveInfo->acquisitionDate) ;
            InSARPath = initStringWith2Strings(csvInSARPath->stringVal[0], aFileName) ;
            free(aFileName) ;
        }
        freeCSVStruct(csvInSARPath) ;
    }
    aFilePath = expandEnvironmentVariablesInPath(InSARPath) ;
    pInSAR->whereAmI = initStringWithString(aFilePath) ;
    if (!strncmp(InSARPath, "./", 2)) {
        free(InSARPath) ;
        InSARPath = initStringWithString(aFilePath) ;
    }
    free(aFilePath) ;
    

    /* Select polarization scheme or check availability of requested one */
    checkPolScheme(pInSAR, preferredPolarization) ;

    /* Initialize image file path considering master and slave polarization */
	(pInSAR->ima1).filePath = initStringWith3Strings((pInSAR->masterImage)->dataDirectoryPath, "/SLCData.", pInSAR->masterPolarizationChannel) ;
	(pInSAR->ima1).lenr = pInSAR->masterInfo->rangeDimension ;
	(pInSAR->ima1).lena = pInSAR->masterInfo->azimuthDimension ;

    (pInSAR->ima2).filePath = initStringWith3Strings((pInSAR->slaveImage)->dataDirectoryPath, "/SLCData.", pInSAR->slavePolarizationChannel) ;
	(pInSAR->ima2).lenr = pInSAR->slaveInfo->rangeDimension ;
	(pInSAR->ima2).lena = pInSAR->slaveInfo->azimuthDimension ;

    /* If we deal with a bistatic pair, we recalculate the minimum slant range of the slave image */
    if (isBistatic) {
        pInSAR->slaveInfo->slantRange[0] = pInSAR->masterInfo->slantRange[0] + c0 * (pInSAR->slaveInfo->twoWayRangeTime[0] - pInSAR->masterInfo->twoWayRangeTime[0]) ;
        pInSAR->slaveInfo->slantRange[1] = pInSAR->slaveInfo->slantRange[0] + pInSAR->slaveInfo->rangeDimension / 2 * pInSAR->slaveInfo->rangeResolutionCell ;
        pInSAR->slaveInfo->slantRange[2] = pInSAR->slaveInfo->slantRange[0] + pInSAR->slaveInfo->rangeDimension * pInSAR->slaveInfo->rangeResolutionCell ;
    }
	pInSAR->ima1.z0 = pInSAR->masterInfo->slantRange[0] ;
	pInSAR->ima2.z0 = pInSAR->slaveInfo->slantRange[0] ;
    pInSAR->rad.azimuthResolutionCell = pInSAR->masterInfo->azimuthResolutionCell ;
    pInSAR->rad.rangeResolutionCell = pInSAR->masterInfo->rangeResolutionCell ;
	pInSAR->rad.nu = pInSAR->masterInfo->radarCarrierFrequency ;

    pInSAR->isBistaticPair = isBistatic ;
    pInSAR->kz0 = 2. * PI * (pInSAR->rad).nu / c0 ;
    if (!pInSAR->isBistaticPair) {
        pInSAR->kz0 *= 2. ;
    }

	/* Init area of interest parameters */
    pInSAR->aoi = allocPolygon(4) ;
	(pInSAR->sup).Sbaz = pInSAR->aoi->P[0].y = pInSAR->aoi->P[1].y = 0 ;
	(pInSAR->sup).Sgra = pInSAR->aoi->P[0].x = pInSAR->aoi->P[3].x = 0 ;
	(pInSAR->sup).Shaz = pInSAR->aoi->P[3].y = pInSAR->aoi->P[2].y = pInSAR->masterInfo->azimuthDimension - 1 ;
	(pInSAR->sup).Sdra = pInSAR->aoi->P[1].x = pInSAR->aoi->P[2].x = pInSAR->masterInfo->rangeDimension - 1 ;

	/* Init orbital parameters parameters */
	/* Earth centre to sensor distance */
	(pInSAR->S1).aS = 0. ;
	(pInSAR->S1).bS = 0. ;
    pInSAR->S1.RT = pInSAR->masterInfo->EarthRadiusAtSceneCenter ;

	/* Baseline parameters */
	pInSAR->B.T = matrixDouble(0, 1, 0, 2) ;

    /* Compute averaging factors to get aproxmately square pixels*/
    xSampling = pInSAR->masterInfo->rangeResolutionCell / sin(pInSAR->masterInfo->incidenceAngle[1] * PI/180.) ;
    ySampling = pInSAR->masterInfo->azimuthResolutionCell ;
    if (xSampling < ySampling) {
        tempVal = ySampling ;
        ySampling = xSampling ;
        xSampling = tempVal ;
    }
    k = 1 ;
    l = (int)divr(xSampling, ySampling).q ;
    while (k * l < 10) {
        k++ ;
        l = (int)divr(k * xSampling, ySampling).q ;
    }
    delta = fabs(k * xSampling - l * ySampling) ;
    l += (delta > .5 * ySampling)? 1 : 0 ;
    delta0 = fabs(k * xSampling - l * ySampling) ;
    Fra = k ;
    Faz = l ;

    k++ ;
    l = (int)divr(k * xSampling, ySampling).q ;
    while (k * l < 28) {
        delta = fabs(k * xSampling - l * ySampling) ;
        l += (delta > .5 * ySampling)? 1 : 0 ;
        delta = fabs(k * xSampling - l * ySampling) ;
        if (delta < delta0) {
            delta0 = delta ; 
            Fra = k ;
            Faz = l ; 
        }
        k++ ;
        l = (int)divr(k * xSampling, ySampling).q ;
    }
    if (tempVal) {
        tempInt = Faz ;
        Faz = Fra ;
        Fra = tempInt ;
    }

    (pInSAR->corf).F_lenr = k = Fra + 1 ;
    (pInSAR->corf).F_lena = l = Faz + 1 ;
    delta0 = fabs(k * xSampling - l * ySampling) ;
    while (k * l < 60) {
        delta = fabs(k * xSampling - l * ySampling) ;
        l += (delta > .5 * ySampling)? 1 : 0 ;
        delta = fabs(k * xSampling - l * ySampling) ;
        if (delta < delta0) {
            delta0 = delta ; 
            (pInSAR->corf).F_lenr = k ;
            (pInSAR->corf).F_lena = l ; 
        }
        k++ ;
        l = (int)divr(k * xSampling, ySampling).q ;
    }
    if (tempVal) {
        tempInt = (pInSAR->corf).F_lenr ;
        (pInSAR->corf).F_lenr = (pInSAR->corf).F_lena ;
        (pInSAR->corf).F_lena = tempInt ;
    }
    


	/* Init box averaging parameters */
    (pInSAR->red).Fra = Fra ;
    (pInSAR->red).Faz = Faz ;


    aFileName = getFileNameFromPath(master->imageDirectoryPath) ;
	stripExtensionAtEndOfPath(aFileName) ;
	extension = initStringWith3Strings(".", pInSAR->masterPolarizationChannel, ".mod") ;
	(pInSAR->mod1).filePath = initStringWith4Strings(InSARPath, "/InSARProducts/", aFileName, extension) ;
	free(aFileName) ;
	free(extension) ;
	(pInSAR->mod1).lenr = 0 ;
	(pInSAR->mod1).lena = 0 ;

	aFileName = getFileNameFromPath(slave->imageDirectoryPath) ;
	stripExtensionAtEndOfPath(aFileName) ;
	extension = initStringWith3Strings(".", pInSAR->slavePolarizationChannel, ".mod") ;
	(pInSAR->mod2).filePath = initStringWith4Strings(InSARPath, "/InSARProducts/", aFileName, extension) ;
	free(aFileName) ;
	free(extension) ;
	(pInSAR->mod2).lenr = 0 ;
	(pInSAR->mod2).lena = 0 ;


	/* Init coarse coregistration parameters */
    (pInSAR->corg).F_lenr = 64 ;
    (pInSAR->corg).F_lena = 64 ;
    (pInSAR->corg).Depra = 32 ;
    (pInSAR->corg).Depaz = 32 ;
    
	(pInSAR->corg).seuilcoh = .5 ;
	(pInSAR->corg).seuilra = 5 ;
	(pInSAR->corg).seuilaz = 5 ;

	/* Init fine coregistration parameters */
    (pInSAR->corf).errra = 3 ;
    (pInSAR->corf).erraz = 3 ;
    (pInSAR->corf).Depra = 20 ;
    (pInSAR->corf).Depaz = 20 ;

	(pInSAR->corf).seuilcoh = .5 ;

	/* Init interpolation parameters */
	/* Affine transform */
	pInSAR->slaveAffineTransform = matrixDouble(0, 1, 0, 2) ;
	pInSAR->inverseSlaveAffineTransform = matrixDouble(0, 1, 0, 2) ;

    /* Test if we deal with TDM PM or BS mode */
    /* We simply test if satellites are TSX and TDX with images acquired the same day */
    isTDM = ((pInSAR->masterInfo->sensorID == __TSX__ && pInSAR->slaveInfo->sensorID == __TDX__)
          || (pInSAR->masterInfo->sensorID == __TDX__ && pInSAR->slaveInfo->sensorID == __TSX__)) ;
    isTDM *= !strcmp(pInSAR->masterInfo->acquisitionDate, pInSAR->slaveInfo->acquisitionDate) ;

	/* Interpolated slave image initialization */
    pInSAR->interpolatedSlave = allocAndInitCSLImage() ;
    if (isTDM) {
        pInSAR->interpolatedSlave->imageDirectoryPath = initStringWithString(slave->imageDirectoryPath) ;
    }
    else {
        aFileName = getFileNameFromPath(slave->imageDirectoryPath) ;
        stripAllExtensions(aFileName) ;
        pInSAR->interpolatedSlave->imageDirectoryPath = initStringWith4Strings(InSARPath, "/InSARProducts/", aFileName, ".interpolated.csl") ;
        free(aFileName) ;
    }
    pInSAR->interpolatedSlave->infoDirectoryPath = initStringWith2Strings(pInSAR->interpolatedSlave->imageDirectoryPath, "/Info") ;
    pInSAR->interpolatedSlave->dataDirectoryPath = initStringWith2Strings(pInSAR->interpolatedSlave->imageDirectoryPath, "/Data") ;


    /* If a global master is associated to the processing, initialize master transform correspondingly */
    pInSAR->SM2MpInSAR = SM2MpInSAR ;
    if (SM2MpInSAR) {
        pInSAR->SM2MPath = initStringWithString(SM2MpInSAR->whereAmI) ;

        pInSAR->masterAffineTransform[0][1] = SM2MpInSAR->slaveAffineTransform[0][1] ;
        pInSAR->masterAffineTransform[0][0] = SM2MpInSAR->slaveAffineTransform[0][0] ;
        pInSAR->masterAffineTransform[0][2] = SM2MpInSAR->slaveAffineTransform[0][2] ;
        pInSAR->masterAffineTransform[1][1] = SM2MpInSAR->slaveAffineTransform[1][1] ;
        pInSAR->masterAffineTransform[1][0] = SM2MpInSAR->slaveAffineTransform[1][0] ;
        pInSAR->masterAffineTransform[1][2] = SM2MpInSAR->slaveAffineTransform[1][2] ;
        pInSAR->masterInterpolation = 1 ;

        /* Interpolated master image file path */
        pInSAR->interpolatedMaster = allocAndInitCSLImage() ;
        pInSAR->interpolatedMaster->imageDirectoryPath = initStringWithString(SM2MpInSAR->interpolatedSlave->imageDirectoryPath) ;
    }

	/* Init interferogram generation parameters */
	(pInSAR->interf).lenr = 0 ;
	(pInSAR->interf).lena = 0 ;
	extension = initStringWith4Strings(".", pInSAR->masterPolarizationChannel, "-", pInSAR->slavePolarizationChannel) ;
	(pInSAR->interf).filePath = initStringWith3Strings(InSARPath, "/InSARProducts/interfero", extension) ;
	/* Filtering parameters */
	(pInSAR->filter).filePath = initStringWith2Strings((pInSAR->interf).filePath, ".f") ;
	(pInSAR->filter).sigmar = 1. ;
    (pInSAR->filter).sigmaz = 1. ;
    (pInSAR->filter).adaptativeFilterSmoothingFactor = 1. ;

    /* First phase component */
    (pInSAR->firstPhaseComponent).lenr = 0 ;
    (pInSAR->firstPhaseComponent).lena = 0 ;
    (pInSAR->firstPhaseComponent).filePath = initStringWith2Strings(InSARPath, "/InSARProducts/topographicPhase") ;
    /* First phase component */
    (pInSAR->secondPhaseComponent).lenr = 0 ;
    (pInSAR->secondPhaseComponent).lena = 0 ;
    (pInSAR->secondPhaseComponent).filePath = initStringWith2Strings(InSARPath, "/InSARProducts/modelPhase") ;
    /* First phase component */
    (pInSAR->thirdPhaseComponent).lenr = 0 ;
    (pInSAR->thirdPhaseComponent).lena = 0 ;
    (pInSAR->thirdPhaseComponent).filePath = initStringWith2Strings(InSARPath, "/InSARProducts/correctionPhase") ;
    pInSAR->DEMExcludingValue = floatNaN ;

    /* Residual phase component */
    (pInSAR->residualPhase).lenr = 0 ;
    (pInSAR->residualPhase).lena = 0 ;
    (pInSAR->residualPhase).filePath = initStringWith3Strings(InSARPath, "/InSARProducts/residualInterferogram", extension) ;

    /* Coherence computation parameters */
	(pInSAR->coh).filePath = initStringWith3Strings(InSARPath, "/InSARProducts/coherence", extension) ;
	(pInSAR->coh).lenr = 0 ;
	(pInSAR->coh).lena = 0 ;
	(pInSAR->coh).spi = 5 ;
    switch (pInSAR->masterInfo->sensorID) {
        case __SENTINEL1__:
            (pInSAR->coh).cor = Fra ;
            (pInSAR->coh).coa = Faz ;
            break;

        case __TSX__:
            (pInSAR->coh).cor = 5 ;
            (pInSAR->coh).coa = 5 ;
            break;

        case __TDX__:
            (pInSAR->coh).cor = 5 ;
            (pInSAR->coh).coa = 5 ;
            break;
            
        case __PAZ1__:
            (pInSAR->coh).cor = 5 ;
            (pInSAR->coh).coa = 5 ;
            break;
            
        case __CSK__:
            (pInSAR->coh).cor = 4 ;
            (pInSAR->coh).coa = 4 ;
            break;

        case __CSG__:
            (pInSAR->coh).cor = 4 ;
            (pInSAR->coh).coa = 4 ;
            break;

        case __RSAT2__:
            (pInSAR->coh).cor = 5 ;
            (pInSAR->coh).coa = 5 ;
            break;

        case __ALOS2__:
            (pInSAR->coh).cor = Fra ;
            (pInSAR->coh).coa = Faz ;
            break;

        case __SAOCOM1A__:
            (pInSAR->coh).cor = Fra ;
            (pInSAR->coh).coa = Faz ;
            break;

        case __SAOCOM1B__:
            (pInSAR->coh).cor = Fra ;
            (pInSAR->coh).coa = Faz ;
            break;

        default:
            (pInSAR->coh).cor = Fra ;
            (pInSAR->coh).coa = Faz ;
            break;
    }

	/* Init Phase unwrapping parameters */
	/* Biased coherence */
	(pInSAR->cohder).filePath = initStringWith3Strings(InSARPath, "/InSARProducts/biasedCoherence", extension) ;
	(pInSAR->cohder).lenr = 0 ;
	(pInSAR->cohder).lena = 0 ;
	(pInSAR->cohder).cor = 5 ;
	(pInSAR->cohder).coa = 5 ;
	(pInSAR->cohder).spi = 5 ;
	/* Residus */
	(pInSAR->res).filePath = initStringWith3Strings(InSARPath, "/InSARProducts/residus", extension) ;
	(pInSAR->res).lenr = 0 ;
	(pInSAR->res).lena = 0 ;
	/* Connexions */
	(pInSAR->conex).filePath = initStringWith3Strings(InSARPath, "/InSARProducts/connexions", extension) ;
	(pInSAR->conex).lenr = 0 ;
	(pInSAR->conex).lena = 0 ;
	(pInSAR->conex).rrmin = 2 ;
	(pInSAR->conex).ramin = 2 ;
	(pInSAR->conex).drr = 1 ;
	(pInSAR->conex).dra = 1 ;
	(pInSAR->conex).ech = 1000 ;
	(pInSAR->conex).ts = 3 ;
	(pInSAR->conex).seuilnet = .25 ;
	(pInSAR->conex).seuilsuiv = .1 ;
    
	/* Unwrapped phase */
	(pInSAR->dephi).filePath = initStringWith3Strings(InSARPath, "/InSARProducts/unwrappedPhase", extension) ;
	(pInSAR->dephi).lenr = 0 ;
	(pInSAR->dephi).lena = 0 ;

    /* External slant range DEM */
    aFilePath = initStringWith2Strings(InSARPath, "/InSARProducts/externalSlantRangeDEM") ;
    pInSAR->externalSlantRangeDEMFile = allocFileDescriptorForPath(aFilePath) ;
    free(aFilePath) ;

	/* Slant Range DEM */
	(pInSAR->srDEM).filePath = initStringWith3Strings(InSARPath, "/InSARProducts/slantRangeDEM", extension) ;
	(pInSAR->srDEM).lenr = 0 ;
	(pInSAR->srDEM).lena = 0 ;

    pInSAR->xShift = pInSAR->yShift = 0 ;

    pInSAR->additionalParameters = NULL ;

    /* Initialize InSAR for topographic processing */
    pInSAR->flag |= _TOPO_ ;

	free(extension) ;
    free(InSARPath) ;

	return(pInSAR) ;
}

void initRawFileDescriptorsToNullInInSARParameterStructure(InSARParametersStruct *pInSAR)
{
    if (pInSAR != NULL) {
        pInSAR->masterImageFile = NULL ;
        pInSAR->slaveImageFile = NULL ;
        pInSAR->interpolatedSlaveImageFile = NULL ;
        pInSAR->interferogramFile = NULL ;
        pInSAR->filteredInterferogramFile = NULL ;
        pInSAR->firstPhaseComponentFile = NULL ;
        pInSAR->secondPhaseComponentFile = NULL ;
        pInSAR->thirdPhaseComponentFile = NULL ;
        pInSAR->residualPhaseFile = NULL ;
        pInSAR->coherenceFile = NULL ;
        pInSAR->biasedCoherenceFile = NULL ;
        pInSAR->residuesFile = NULL ;
        pInSAR->connexionsFile = NULL ;
        pInSAR->unwrappedPhaseFile = NULL ;
        pInSAR->measurementFile = NULL ;
        pInSAR->masterAmplitudeImageFile = NULL ;
        pInSAR->slaveAmplitudeImageFile = NULL ;
        pInSAR->phaseStandardDeviationImageFile = NULL ;
        pInSAR->heightStandardDeviationImageFile = NULL ;
        pInSAR->externalSlantRangeDEMFile = NULL ;
    }
}

InSARParametersStruct *readInSARParametersFileAtPath(char *aPath)
{
	/* local variables declaration */
    char *aFilePath, *textFilesDir ;
    char *masterImageDirectory, *slaveImageDirectory, *aString ;
	int i ;
	InSARParametersStruct *pInSAR ;
	keyValue *paramList, *aKeyVal ;
    CSVStruct *polMode ;

    genFloatNaN() ;
    genFloatInf() ;

 	paramList = readParameterFileAtPath(aPath) ;
    if (!paramList) {
      return (NULL) ;
    }
    if (!isCommentPresentIn(paramList, "InSAR parameters file")) {
        freeKeyValuePair(paramList) ;
        return (NULL) ;
    }
    
    pInSAR = allocInSARParametersStruct() ;

    /* Locate the InSAR working directory */
    aFilePath = getDirectoryPathFromPath(aPath) ;
    textFilesDir = expandEnvironmentVariablesInPath(aFilePath) ;
    pInSAR->whereAmI = getUpperDirectoryPath(textFilesDir) ;
    free(aFilePath) ;

	initRawFileDescriptorsToNullInInSARParameterStructure(pInSAR) ;

    /* Get or create master CSL image structure */
	aFilePath = getStringValForKeyIn(paramList, "Master image file path") ;
    if (!(pInSAR->masterImage = getCSLImageStructureAtPath(aFilePath))) {
        pInSAR->masterImage = allocAndInitCSLImage() ;
        pInSAR->masterImage->imageDirectoryPath = initStringWithString(aFilePath) ;
        pInSAR->masterImage->infoDirectoryPath = initStringWith2Strings(aFilePath, "/Info") ;
        pInSAR->masterImage->dataDirectoryPath = initStringWith2Strings(aFilePath, "/Data") ;
    }
    masterImageDirectory = initStringWithString(pInSAR->masterImage->dataDirectoryPath) ;

    /* Read infoImage text file within the InSAR directory structure or in master image structure */
    aFilePath = initStringWith2Strings(textFilesDir, "/masterSLCImageInfo.txt") ;
    if(!fileExistsAtPath(aFilePath)) {
        free(aFilePath) ;
        aFilePath = initStringWith2Strings(pInSAR->masterImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
        if(!fileExistsAtPath(aFilePath)) {
            ase("No master SLCImageInfo.txt file available\n") ;
        }
    }
    pInSAR->masterInfo = readInfoImageFromTextFile(aFilePath) ;
    if (pInSAR->masterInfo->CSLImagePath == NULL) {
        pInSAR->masterInfo->CSLImagePath = initStringWithString(pInSAR->masterImage->imageDirectoryPath) ;
    }
    free(aFilePath) ;

    orbitInterpolation(pInSAR->masterInfo) ;
  
    /* Now that we have image structures, we can check if requested polarizartion scheme is available */
	pInSAR->masterPolarizationChannel = initStringWithString(getStringValForKeyIn(paramList, "Master polarization channel")) ;
    polMode = readCSVInString(pInSAR->masterInfo->polMode) ;
    i = 0 ;
    while (i < polMode->numberOfEntries) {
        if (!strcmp(pInSAR->masterPolarizationChannel, polMode->stringVal[i])) {
            break ;
        }
        i++ ;
    }
    if(i == polMode->numberOfEntries) {
        perror("Requested polarisation channel not available within master image\n") ;
        exit(-1) ;
    }
    freeCSVStruct(polMode) ;

    /* Get or create slave CSL image structure */
	aFilePath = getStringValForKeyIn(paramList, "Slave image file path [CSL image format]") ;
    if (!(pInSAR->slaveImage = getCSLImageStructureAtPath(aFilePath))) {
        pInSAR->slaveImage = allocAndInitCSLImage() ;
        pInSAR->slaveImage->imageDirectoryPath = initStringWithString(aFilePath) ;
        pInSAR->slaveImage->infoDirectoryPath = initStringWith2Strings(aFilePath, "/Info") ;
        pInSAR->slaveImage->dataDirectoryPath = initStringWith2Strings(aFilePath, "/Data") ;
    }
    slaveImageDirectory = initStringWithString(pInSAR->slaveImage->dataDirectoryPath) ;

    /* Now, we will read the infoImage text file within the InSAR directory structure. */
    aFilePath = initStringWith2Strings(textFilesDir, "/slaveSLCImageInfo.txt") ;
    if(!fileExistsAtPath(aFilePath)) {
        free(aFilePath) ;
        aFilePath = initStringWith2Strings(pInSAR->slaveImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
        if(!fileExistsAtPath(aFilePath)) {
            ase("No slve SLCImageInfo.txt file available\n") ;
        }
    }
    pInSAR->slaveInfo = readInfoImageFromTextFile(aFilePath) ;
    if (pInSAR->slaveInfo->CSLImagePath == NULL) {
        pInSAR->slaveInfo->CSLImagePath = initStringWithString(pInSAR->slaveImage->imageDirectoryPath) ;
    }
    free(aFilePath) ;

    orbitInterpolation(pInSAR->slaveInfo) ;

    /* Now that we have slave image structure, we can check if requested polarizartion scheme  is available*/
	pInSAR->slavePolarizationChannel = initStringWithString(getStringValForKeyIn(paramList, "Slave polarization channel")) ;
    polMode = readCSVInString(pInSAR->slaveInfo->polMode) ;
    i = 0 ;
    while (i < polMode->numberOfEntries) {
        if (!strcmp(pInSAR->slavePolarizationChannel, polMode->stringVal[i])) {
            break ;
        }
        i++ ;
    }
    if(i == polMode->numberOfEntries) {
        perror("Requested polarisation channel not available within slave image\n") ;
        exit(-1) ;
    }
    freeCSVStruct(polMode) ;

	/* Interpolated slave image file path */
    aFilePath = getStringValForKeyIn(paramList, "Interpolated slave image file path") ;
    if (!(pInSAR->interpolatedSlave = getCSLImageStructureAtPath(aFilePath))) {
        pInSAR->interpolatedSlave = allocAndInitCSLImage() ;
        pInSAR->interpolatedSlave->imageDirectoryPath = initStringWithString(aFilePath) ;
        pInSAR->interpolatedSlave->infoDirectoryPath = initStringWith2Strings(aFilePath, "/Info") ;
        pInSAR->interpolatedSlave->dataDirectoryPath = initStringWith2Strings(aFilePath, "/Data") ;
    }

    /* Now we verify if there is a global master associated with the processing */
    if ((pInSAR->SM2MPath = initStringWithString(getStringValForKeyIn(paramList, "Global master to master InSAR directory path")))) {
        if (isInSARDirectoryStructureAtPath(pInSAR->SM2MPath)) {
            aPath = initStringWith2Strings(pInSAR->SM2MPath, "/TextFiles/InSARParameters.txt") ;
            printf("\t---> Master to global master processing requested.\n") ;
            printf("\t---> Reading Global master to master InSAR parameters file.\n\n") ;
            pInSAR->SM2MpInSAR = readInSARParametersFileAtPath(aPath) ;
            free(aPath) ;

            /* Global master to master transform initialization */
            pInSAR->masterAffineTransform[0][0] = pInSAR->SM2MpInSAR->slaveAffineTransform[0][0] ;
            pInSAR->masterAffineTransform[0][1] = pInSAR->SM2MpInSAR->slaveAffineTransform[0][1] ;
            pInSAR->masterAffineTransform[0][2] = pInSAR->SM2MpInSAR->slaveAffineTransform[0][2] ;
            pInSAR->masterAffineTransform[1][0] = pInSAR->SM2MpInSAR->slaveAffineTransform[1][0] ;
            pInSAR->masterAffineTransform[1][1] = pInSAR->SM2MpInSAR->slaveAffineTransform[1][1] ;
            pInSAR->masterAffineTransform[1][2] = pInSAR->SM2MpInSAR->slaveAffineTransform[1][2] ;
            pInSAR->masterInterpolation = 1 ;

            /* Interpolated master image file path */
            if (!(pInSAR->interpolatedMaster = getCSLImageStructureAtPath(pInSAR->SM2MpInSAR->interpolatedSlave->imageDirectoryPath))) {                 
                pInSAR->interpolatedMaster = allocAndInitCSLImage() ;
                pInSAR->interpolatedMaster->imageDirectoryPath = initStringWithString(pInSAR->SM2MpInSAR->interpolatedSlave->imageDirectoryPath) ;
                pInSAR->interpolatedMaster->infoDirectoryPath = initStringWithString(pInSAR->SM2MpInSAR->interpolatedSlave->infoDirectoryPath) ;
                pInSAR->interpolatedMaster->dataDirectoryPath = initStringWithString(pInSAR->SM2MpInSAR->interpolatedSlave->dataDirectoryPath) ;
            }
        }
    }

    /* Copy image specific parameters */
    pInSAR->chaz1.PRF = pInSAR->masterInfo->prf ;
	pInSAR->chaz1.ABW = pInSAR->masterInfo->azimuthBandwidth ;
	pInSAR->chaz1.a0FDC = pInSAR->masterInfo->fdc[0] ;
	pInSAR->chaz1.a1FDC = pInSAR->masterInfo->fdc[1] ;
	pInSAR->chaz1.a2FDC = pInSAR->masterInfo->fdc[2] ;
	pInSAR->chaz2.PRF = pInSAR->slaveInfo->prf ;
	pInSAR->chaz2.ABW = pInSAR->slaveInfo->azimuthBandwidth ;
	pInSAR->chaz2.a0FDC = pInSAR->slaveInfo->fdc[0] ;
	pInSAR->chaz2.a1FDC = pInSAR->slaveInfo->fdc[1] ;
	pInSAR->chaz2.a2FDC = pInSAR->slaveInfo->fdc[2] ;

	(pInSAR->ima1).filePath = initStringWith3Strings(masterImageDirectory, "/SLCData.", pInSAR->masterPolarizationChannel) ;
	(pInSAR->ima1).lenr = getIntValForKeyIn(paramList, "Master image range dimension") ;
	(pInSAR->ima1).lena = getIntValForKeyIn(paramList, "Master image azimuth dimension") ;
    (pInSAR->ima2).filePath = initStringWith3Strings(slaveImageDirectory, "/SLCData.", pInSAR->slavePolarizationChannel) ;
	(pInSAR->ima2).lenr = getIntValForKeyIn(paramList, "Slave image range dimension") ;
	(pInSAR->ima2).lena = getIntValForKeyIn(paramList, "Slave image azimuth dimension") ;

	(pInSAR->ima1).z0 = getDoubleValForKeyIn(paramList, "Master image minimum slant range") ;
	(pInSAR->ima2).z0 = getDoubleValForKeyIn(paramList, "Slave image minimum slant range") ;
    (pInSAR->rad).azimuthResolutionCell = getDoubleValForKeyIn(paramList, "Azimuth sampling") ;
    (pInSAR->rad).rangeResolutionCell = getDoubleValForKeyIn(paramList, "Slant range sampling") ;
	(pInSAR->rad).nu = getDoubleValForKeyIn(paramList, "Radar carrier frequency [Hz]") ;

    if(isKeyValPresent(paramList, "Bistatic interferometric pair")) {
        pInSAR->isBistaticPair = (!strncmp(getStringValForKeyIn(paramList, "Bistatic interferometric pair"), "YES", 3))? 1 : 0 ;
    }

    if (isKeyValPresent(paramList, "Orbit types")) {
        pInSAR->orbitTypes = initStringWithString(getStringValForKeyIn(paramList, "Orbit type")) ;
    }
    
    pInSAR->kz0 = 2. * PI * (pInSAR->rad).nu / c0 ;
    if (!pInSAR->isBistaticPair) {
        pInSAR->kz0 *= 2. ;
    }

	/* Read area of interest parameters */
    pInSAR->aoi = allocPolygon(4) ;
    (pInSAR->sup).Sbaz = pInSAR->aoi->P[0].y = pInSAR->aoi->P[1].y = getIntValForKeyIn(paramList, "Lower left azimuth coordinate") ;
	(pInSAR->sup).Sgra = pInSAR->aoi->P[0].x = pInSAR->aoi->P[3].x = getIntValForKeyIn(paramList, "Lower left range coordinate") ;
	(pInSAR->sup).Shaz = pInSAR->aoi->P[3].y = pInSAR->aoi->P[2].y = getIntValForKeyIn(paramList, "Upper right azimuth coordinate") ;
	(pInSAR->sup).Sdra = pInSAR->aoi->P[1].x = pInSAR->aoi->P[2].x = getIntValForKeyIn(paramList, "Upper right range coordinate") ;
    pInSAR->aoiKml = initStringWithString(getStringValForKeyIn(paramList, "Area of Interest .kml file")) ;
    pInSAR->externalReferenceDEM = initStringWithString(getStringValForKeyIn(paramList, "External reference DEM")) ;


	/* Read orbital parameters parameters */
	/* Earth centre to sensor distance */
	(pInSAR->S1).aS = getDoubleValForKeyIn(paramList, "Linear variation [m]/[azimuth row]") ;
	(pInSAR->S1).bS = getDoubleValForKeyIn(paramList, "Constant term [m]") ;
    (pInSAR->S1).RT = getDoubleValForKeyIn(paramList, "Earth radius at master image centre [m]") ;

	/* Baseline parameters */
	pInSAR->B.T = matrixDouble(0, 1, 0, 2) ;
	pInSAR->B.T[0][2] = getDoubleValForKeyIn(paramList, "Horizontal baseline component constant term [m]") ;
	pInSAR->B.T[0][0] = getDoubleValForKeyIn(paramList, "Horizontal baseline variation with range position [m]/[range pix]") ;
	pInSAR->B.T[0][1] = getDoubleValForKeyIn(paramList, "Horizontal baseline variation with azimuth position [m]/[azimuth pix]") ;
	pInSAR->B.T[1][2] = getDoubleValForKeyIn(paramList, "Vertical baseline component constant term [m]") ;
	pInSAR->B.T[1][0] = getDoubleValForKeyIn(paramList, "Vertical baseline variation with range position [m]/[range pix]") ;
	pInSAR->B.T[1][1] = getDoubleValForKeyIn(paramList, "Vertical baseline variation with azimuth position [m]/[azimuth pix]") ;
    pInSAR->B.Bperp = getDoubleValForKeyIn(paramList, "Perpendicular baseline component at image centre") ;
    pInSAR->B.Bpara = getDoubleValForKeyIn(paramList, "Parallel baseline component at image centre") ;
    pInSAR->ambiguityAltitude = getDoubleValForKeyIn(paramList, "Ambiguity altitude at scene centre") ;
    pInSAR->B.deltaDays = getIntValForKeyIn(paramList, "Temporal baseline [day]") ;

	/* Read box averaging parameters */
	(pInSAR->red).Fra = getIntValForKeyIn(paramList, "Range reduction factor") ;
	(pInSAR->red).Faz = getIntValForKeyIn(paramList, "Azimuth reduction factor") ;
	(pInSAR->mod1).filePath = initStringWithString(getStringValForKeyIn(paramList, "Reduced master amplitude image file path")) ;
	(pInSAR->mod1).lenr = getIntValForKeyIn(paramList, "Reduced master amplitude image range dimension [pix]") ;
	(pInSAR->mod1).lena = getIntValForKeyIn(paramList, "Reduced master amplitude image azimuth dimension [pix]") ;
	(pInSAR->mod2).filePath = initStringWithString(getStringValForKeyIn(paramList, "Reduced slave amplitude image file path")) ;
	(pInSAR->mod2).lenr = getIntValForKeyIn(paramList, "Reduced slave amplitude image range dimension [pix]") ;
	(pInSAR->mod2).lena = getIntValForKeyIn(paramList, "Reduced slave amplitude image azimuth dimension [pix]") ;

	/* Read coarse coregistration parameters */
	(pInSAR->corg).F_lenr = getIntValForKeyIn(paramList, "Coarse coregistration range window size [pix]") ;
	(pInSAR->corg).F_lena = getIntValForKeyIn(paramList, "Coarse coregistration azimuth window size [pix]") ;
	(pInSAR->corg).Depra = getIntValForKeyIn(paramList, "Coarse registration range distance between anchor points [pix]") ;
	(pInSAR->corg).Depaz = getIntValForKeyIn(paramList, "Coarse registration azimuth distance between anchor points [pix]") ;
	(pInSAR->corg).seuilcoh = getDoubleValForKeyIn(paramList, "Coarse coregistration correlation threshold") ;
	(pInSAR->corg).seuilra = getDoubleValForKeyIn(paramList, "Corelation peak range width threshold") ;
	(pInSAR->corg).seuilaz = getDoubleValForKeyIn(paramList, "Corelation peak azimut width threshold") ;

	/* Read fine coregistration parameters */
	(pInSAR->corf).F_lenr = getIntValForKeyIn(paramList, "Fine coregistration range window size [pix]") ;
	(pInSAR->corf).F_lena = getIntValForKeyIn(paramList, "Fine coregistration azimuth window size [pix]") ;
	(pInSAR->corf).errra = getIntValForKeyIn(paramList, "Estimated range error [pix]") ;
	(pInSAR->corf).erraz = getIntValForKeyIn(paramList, "Estimated azimuth error [pix]") ;
	(pInSAR->corf).Depra = getIntValForKeyIn(paramList, "Fine registration range distance between anchor points [pix]") ;
	(pInSAR->corf).Depaz = getIntValForKeyIn(paramList, "Fine registration azimuth distance between anchor points [pix]") ;
	(pInSAR->corf).seuilcoh = getDoubleValForKeyIn(paramList, "Fine coregistration correlation threshold") ;

	/* Read slave interpolation parameters */
	/* Affine transform */
	pInSAR->slaveAffineTransform = matrixDouble(0, 1, 0, 2) ;
	pInSAR->inverseSlaveAffineTransform = matrixDouble(0, 1, 0, 2) ;

	pInSAR->slaveAffineTransform[0][0] = getDoubleValForKeyIn(paramList, "Ax") ;
	pInSAR->slaveAffineTransform[0][1] = getDoubleValForKeyIn(paramList, "Bx") ;
	pInSAR->slaveAffineTransform[0][2] = getDoubleValForKeyIn(paramList, "Cx") ;
	pInSAR->slaveAffineTransform[1][0] = getDoubleValForKeyIn(paramList, "Ay") ;
	pInSAR->slaveAffineTransform[1][1] = getDoubleValForKeyIn(paramList, "By") ;
	pInSAR->slaveAffineTransform[1][2] = getDoubleValForKeyIn(paramList, "Cy") ;
	inversePlaneAffineTransform(pInSAR->slaveAffineTransform, pInSAR->inverseSlaveAffineTransform) ;

	/* Read interferogram generation parameters */
	(pInSAR->interf).lenr = getIntValForKeyIn(paramList, "Interferometric products range dimension [pix]") ;
	(pInSAR->interf).lena = getIntValForKeyIn(paramList, "Interferometric products azimuth dimension [pix]") ;
	(pInSAR->interf).filePath = initStringWithString(getStringValForKeyIn(paramList, "Interferogram file path")) ;
	/* Filtering parameters */
	(pInSAR->filter).filePath = initStringWithString(getStringValForKeyIn(paramList, "Filtered interferogram file path")) ;
	(pInSAR->filter).sigmar = getDoubleValForKeyIn(paramList, "Range filter Full Width at Half Maximum") ;
    (pInSAR->filter).sigmaz = getDoubleValForKeyIn(paramList, "Azimuth filter Full Width at Half Maximum") ;
    (pInSAR->filter).adaptativeFilterSmoothingFactor = getDoubleValForKeyIn(paramList, "Power spectrum filtering factor (for adaptative filtering)") ;
	/* Coherence computation parameters */
	(pInSAR->coh).filePath = initStringWithString(getStringValForKeyIn(paramList, "Coherence file path")) ;
	(pInSAR->coh).lenr = (pInSAR->interf).lenr ;
	(pInSAR->coh).lena = (pInSAR->interf).lena ;
	(pInSAR->coh).cor = getIntValForKeyIn(paramList, "Coherence estimator range window size [pix]") ;
	(pInSAR->coh).coa = getIntValForKeyIn(paramList, "Coherence estimator azimuth window size [pix]") ;
	(pInSAR->coh).spi = getIntValForKeyIn(paramList, "Square spiral size [pix]") ;
	(pInSAR->coh).medianFilterSize = getIntValForKeyIn(paramList, "Median filter size [pix]") ;

	/* Phase components */
    /* Check if we deal with an old InSARParameter file */
    aKeyVal = isKeyValPresent(paramList, "First phase component file path") ;
    if (aKeyVal) {
        (pInSAR->firstPhaseComponent).filePath = initStringWithString(aKeyVal->stringVal) ;
        (pInSAR->secondPhaseComponent).filePath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/modelPhase") ;
        (pInSAR->thirdPhaseComponent).filePath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/correctionPhase") ; 
        removeKeyValuePairIn(paramList, "First phase component file path") ;     
    }
    else {
        (pInSAR->firstPhaseComponent).filePath = initStringWithString(getStringValForKeyIn(paramList, "Topographic phase component file path")) ;
        (pInSAR->secondPhaseComponent).filePath = initStringWithString(getStringValForKeyIn(paramList, "Model-based phase component file path")) ;
        (pInSAR->thirdPhaseComponent).filePath = initStringWithString(getStringValForKeyIn(paramList, "Correction phase component file path")) ;
    }
	(pInSAR->firstPhaseComponent).lenr = (pInSAR->interf).lenr ;
	(pInSAR->firstPhaseComponent).lena = (pInSAR->interf).lena ;
	(pInSAR->secondPhaseComponent).lenr = (pInSAR->interf).lenr ;
	(pInSAR->secondPhaseComponent).lena = (pInSAR->interf).lena ;
	(pInSAR->thirdPhaseComponent).lenr = (pInSAR->interf).lenr ;
	(pInSAR->thirdPhaseComponent).lena = (pInSAR->interf).lena ;

    aString = getStringValForKeyIn(paramList, "Excluding value") ;
    if (plError != KEY_VALUE_NOT_FOUND) {
        if (!strncmp(aString, "NaN", 3)) {
            pInSAR->DEMExcludingValue = floatNaN ;
        }
        else {
            pInSAR->DEMExcludingValue = getFloatValForKeyIn(paramList, "Excluding value") ;
        }
    }
    else {
        pInSAR->DEMExcludingValue = floatNaN ;
    }

    /* Residual interferogram */
    (pInSAR->residualPhase).filePath = initStringWithString(getStringValForKeyIn(paramList, "Residual interferogram file path")) ;
	(pInSAR->residualPhase).lenr = (pInSAR->interf).lenr ;
	(pInSAR->residualPhase).lena = (pInSAR->interf).lena ;

	/* Biased coherence */
	(pInSAR->cohder).filePath = initStringWithString(getStringValForKeyIn(paramList, "Biased coherence file path")) ;
	(pInSAR->cohder).lenr = getIntValForKeyIn(paramList, "Biased coherence range dimension [pix]") ;
	(pInSAR->cohder).lena = getIntValForKeyIn(paramList, "Biased coherence azimuth dimension [pix]") ;
	(pInSAR->cohder).cor = getIntValForKeyIn(paramList, "Biased coherence estimator range window size [pix]") ;
	(pInSAR->cohder).coa = getIntValForKeyIn(paramList, "Biased coherence estimator azimuth window size [pix]") ;
	(pInSAR->cohder).spi = getIntValForKeyIn(paramList, "Biased coherence square spiral size [pix]") ;
	/* Residus */
	(pInSAR->res).filePath = initStringWithString(getStringValForKeyIn(paramList, "Residus image file path")) ;
	(pInSAR->res).lenr = getIntValForKeyIn(paramList, "Residus image range dimension [pix]") ;
	(pInSAR->res).lena = getIntValForKeyIn(paramList, "Residus image azimuth dimension [pix]") ;
	/* Connexions */
	(pInSAR->conex).filePath = initStringWithString(getStringValForKeyIn(paramList, "Connexions image file path")) ;
	(pInSAR->conex).lenr = getIntValForKeyIn(paramList, "Connexions image range dimension [pix]") ;
	(pInSAR->conex).lena = getIntValForKeyIn(paramList, "Connexions image azimuth dimension [pix]") ;
	(pInSAR->conex).rrmin = getIntValForKeyIn(paramList, "Range minimum search radius [pix]") ;
	(pInSAR->conex).ramin = getIntValForKeyIn(paramList, "Azimuth minimum search radius [pix]") ;
	(pInSAR->conex).drr = getIntValForKeyIn(paramList, "Range search radius step [pix]") ;
	(pInSAR->conex).dra = getIntValForKeyIn(paramList, "Azimuth search radius step [pix]") ;
	(pInSAR->conex).ech = getIntValForKeyIn(paramList, "Coherence scaling") ;
	(pInSAR->conex).ts = getIntValForKeyIn(paramList, "Connexion process mode") ;
	(pInSAR->conex).seuilnet = getFloatValForKeyIn(paramList, "Coherence cleaning threshold") ;
	(pInSAR->conex).seuilsuiv = getFloatValForKeyIn(paramList, "False residue coherence threshold") ;

	/* Unwrapped phase */
	(pInSAR->dephi).filePath = initStringWithString(getStringValForKeyIn(paramList, "Unwrapped phase file path")) ;
	(pInSAR->dephi).lenr = getIntValForKeyIn(paramList, "Unwrapped phase range dimension [pix]") ;
	(pInSAR->dephi).lena = getIntValForKeyIn(paramList, "Unwrapped phase azimuth dimension [pix]") ;

    /* External slant range DEM */
    if (isKeyValPresent(paramList, "External slant range DEM file path")) {
        pInSAR->externalSlantRangeDEMFile = allocFileDescriptorForPath(getStringValForKeyIn(paramList, "External slant range DEM file path")) ;
    }
    else {
        /* If using an old version of InSAR parameters file, we update it, adding an external DEM field */
        aString = getDirectoryPathFromPath(getStringValForKeyIn(paramList, "Slant range DEM file path")) ;
        aFilePath = initStringWith2Strings(aString, "externalSlantRangeDEM") ;
        pInSAR->externalSlantRangeDEMFile = allocFileDescriptorForPath(aFilePath) ;
        free(aFilePath) ;
        free(aString) ;
    }
    pInSAR->externalSlantRangeDEMFile->xDim = getIntValForKeyIn(paramList, "External slant range DEM range dimension [pix]") ;
    pInSAR->externalSlantRangeDEMFile->yDim = getIntValForKeyIn(paramList, "External slant range DEM azimuth dimension [pix]") ;

	/* Slant Range DEM or deformation measurement */
    pInSAR->flag |= (isKeyValPresent(paramList, "Slant range DEM"))? _TOPO_ : _DEFO_ ;
    if (pInSAR->flag & _TOPO_) {
        (pInSAR->srDEM).filePath = initStringWithString(getStringValForKeyIn(paramList, "Slant range DEM file path")) ;
        (pInSAR->srDEM).lenr = getIntValForKeyIn(paramList, "Slant range DEM range dimension [pix]") ;
        (pInSAR->srDEM).lena = getIntValForKeyIn(paramList, "Slant range DEM azimuth dimension [pix]") ;
    }
    if (pInSAR->flag & _DEFO_) {
        (pInSAR->srDEM).filePath = initStringWithString(getStringValForKeyIn(paramList, "Deformation measurement file path")) ;
        (pInSAR->srDEM).lenr = getIntValForKeyIn(paramList, "Deformation measurement range dimension [pix]") ;
        (pInSAR->srDEM).lena = getIntValForKeyIn(paramList, "Deformation measurement azimuth dimension [pix]") ;
    }

    modifyFileExtensionsWithRespectToSelectedPolarization(pInSAR) ;

    pInSAR->xShift = pInSAR->yShift = 0 ;
    pInSAR->additionalParameters = NULL ;
    pInSAR->averageBeta0CalibrationConstant = 1 ;

    /* Initialize georeferencing structure with respect to orbitography of the master image */
    pInSAR->geo = allocAndInitGeorefStructureForTargetEllipsoid(pInSAR->masterInfo, pInSAR->masterInfo->ellRef) ;

    free(textFilesDir) ;
	freeKeyValueList(paramList) ;
    free(masterImageDirectory) ;
    free(slaveImageDirectory) ;
    
	return(pInSAR) ;
}


void modifyFileExtensionsWithRespectToSelectedPolarization(InSARParametersStruct *pInSAR)
{
    char searchedExtension[5][4], replacementString[4], *aDir, *aPath ;
    int i ;
    keyValue *cohTrackParams, *thisKeyVal ;

    if((pInSAR->masterPolarizationChannel != NULL) && (pInSAR->slavePolarizationChannel != NULL)) {
        aDir = getDirectoryPathFromPath((pInSAR->ima1).filePath) ;
        free((pInSAR->ima1).filePath) ;
        (pInSAR->ima1).filePath = initStringWith3Strings(aDir, "SLCData.", pInSAR->masterPolarizationChannel) ;
        free(aDir) ;

        aDir = getDirectoryPathFromPath((pInSAR->ima2).filePath) ;
        free((pInSAR->ima2).filePath) ;
        (pInSAR->ima2).filePath = initStringWith3Strings(aDir, "SLCData.", pInSAR->slavePolarizationChannel) ;
        free(aDir) ;

        sprintf(searchedExtension[0], "HH") ;
        sprintf(searchedExtension[1], "VV") ;
        sprintf(searchedExtension[2], "HV") ;
        sprintf(searchedExtension[3], "VH") ;
        sprintf(searchedExtension[4], "XX") ;
        for(i = 0; i < 5; i++) {
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->mod1).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->mod1).filePath), searchedExtension[i], pInSAR->masterPolarizationChannel) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->mod2).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->mod2).filePath), searchedExtension[i], pInSAR->slavePolarizationChannel) ;
        }

        sprintf(searchedExtension[0], "HH-") ;
        sprintf(searchedExtension[1], "VV-") ;
        sprintf(searchedExtension[2], "HV-") ;
        sprintf(searchedExtension[3], "VH-") ;
        sprintf(searchedExtension[4], "XX-") ;
        sprintf(replacementString, "%s-", pInSAR->masterPolarizationChannel) ;
        for(i = 0; i < 5; i++) {
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->interf).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->interf).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->filter).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->filter).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->residualPhase).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->residualPhase).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->coh).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->coh).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->cohder).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->cohder).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->res).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->res).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->conex).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->conex).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->dephi).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->dephi).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->srDEM).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->srDEM).filePath), searchedExtension[i], replacementString) ;
        }

        sprintf(searchedExtension[0], "-HH") ;
        sprintf(searchedExtension[1], "-VV") ;
        sprintf(searchedExtension[2], "-HV") ;
        sprintf(searchedExtension[3], "-VH") ;
        sprintf(searchedExtension[4], "-XX") ;
        sprintf(replacementString, "-%s", pInSAR->slavePolarizationChannel) ;
        for(i = 0; i < 5; i++) {
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->interf).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->interf).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->filter).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->filter).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->residualPhase).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->residualPhase).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->coh).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->coh).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->cohder).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->cohder).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->res).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->res).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->conex).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->conex).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->dephi).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->dephi).filePath), searchedExtension[i], replacementString) ;
            if(isSubStringPresentInString(getPointerToFileNameInPath((pInSAR->srDEM).filePath), searchedExtension[i]))
                replaceSubStringInString(getPointerToFileNameInPath((pInSAR->srDEM).filePath), searchedExtension[i], replacementString) ;
        }
    }

    aPath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/cohTrackParameters.txt") ;
    if (fileExistsAtPath(aPath)) {
        cohTrackParams = readParameterFileAtPath(aPath) ;
        sprintf(searchedExtension[0], "HH-") ;
        sprintf(searchedExtension[1], "VV-") ;
        sprintf(searchedExtension[2], "HV-") ;
        sprintf(searchedExtension[3], "VH-") ;
        sprintf(searchedExtension[4], "XX-") ;
        sprintf(replacementString, "%s-", pInSAR->masterPolarizationChannel) ;
        for(i = 0; i < 5; i++) {
            thisKeyVal = isKeyValPresent(cohTrackParams, "Tracked coh") ;
            replaceSubStringInString(thisKeyVal->stringVal, searchedExtension[i], replacementString) ;
            thisKeyVal = isKeyValPresent(cohTrackParams, "Tracked int") ;
            replaceSubStringInString(thisKeyVal->stringVal, searchedExtension[i], replacementString) ;
            thisKeyVal = isKeyValPresent(cohTrackParams, "Tracked range") ;
            replaceSubStringInString(thisKeyVal->stringVal, searchedExtension[i], replacementString) ;
            thisKeyVal = isKeyValPresent(cohTrackParams, "Tracked azimuth") ;
            replaceSubStringInString(thisKeyVal->stringVal, searchedExtension[i], replacementString) ;
        }
        sprintf(searchedExtension[0], "-HH") ;
        sprintf(searchedExtension[1], "-VV") ;
        sprintf(searchedExtension[2], "-HV") ;
        sprintf(searchedExtension[3], "-VH") ;
        sprintf(searchedExtension[4], "-XX") ;
        sprintf(replacementString, "-%s", pInSAR->slavePolarizationChannel) ;
        for(i = 0; i < 5; i++) {
            thisKeyVal = isKeyValPresent(cohTrackParams, "Tracked coh") ;
            replaceSubStringInString(thisKeyVal->stringVal, searchedExtension[i], replacementString) ;
            thisKeyVal = isKeyValPresent(cohTrackParams, "Tracked int") ;
            replaceSubStringInString(thisKeyVal->stringVal, searchedExtension[i], replacementString) ;
            thisKeyVal = isKeyValPresent(cohTrackParams, "Tracked range") ;
            replaceSubStringInString(thisKeyVal->stringVal, searchedExtension[i], replacementString) ;
            thisKeyVal = isKeyValPresent(cohTrackParams, "Tracked azimuth") ;
            replaceSubStringInString(thisKeyVal->stringVal, searchedExtension[i], replacementString) ;
        }

        sprintf(searchedExtension[0], "HH") ;
        sprintf(searchedExtension[1], "VV") ;
        sprintf(searchedExtension[2], "HV") ;
        sprintf(searchedExtension[3], "VH") ;
        sprintf(searchedExtension[4], "XX") ;
        for(i = 0; i < 5; i++) {
            thisKeyVal = isKeyValPresent(cohTrackParams, "Tracked master") ;
            if (plError == NO_ERROR) {
                replaceSubStringInString(thisKeyVal->stringVal, searchedExtension[i], pInSAR->masterPolarizationChannel) ;
            }
            
            thisKeyVal = isKeyValPresent(cohTrackParams, "Tracked slave") ;
            if (plError == NO_ERROR) {
                replaceSubStringInString(thisKeyVal->stringVal, searchedExtension[i], pInSAR->slavePolarizationChannel) ;
            }
        }

        writeParameterFileAtPath(cohTrackParams, aPath) ;
        freeKeyValueList(cohTrackParams) ;
    }
    free(aPath) ;
    
}


/* ________________ Write InSAR parameter file ________________ */

void saveInSARParametersFileAtPath(InSARParametersStruct *pInSAR, char *aPath)
{
	keyValue *parameterList ;

	parameterList = allocAKeyValuePair() ;
	setStringValForKeyIn(parameterList, "InSAR parameters file", "") ;
	setStringValForKeyIn(parameterList, "*********************", "") ;
	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, "Input images", "") ;
	setStringValForKeyIn(parameterList, "************", "") ;
	if(pInSAR->masterImage) {
        setStringValForKeyIn(parameterList, (pInSAR->masterImage)->imageDirectoryPath, "Master image file path [CSL image format]") ;
	}
    else {
        setStringValForKeyIn(parameterList, "???", "Master image file path [CSL image format]") ;
    }

	if(pInSAR->masterPolarizationChannel != NULL) {
		setStringValForKeyIn(parameterList, pInSAR->masterPolarizationChannel, "Master polarization channel") ;
	}
	setIntValForKeyIn(parameterList, (pInSAR->ima1).lenr, "Master image range dimension [pixels]") ;
	setIntValForKeyIn(parameterList, (pInSAR->ima1).lena, "Master image azimuth dimension [rows]") ;

    if(pInSAR->slaveImage) {
        setStringValForKeyIn(parameterList, (pInSAR->slaveImage)->imageDirectoryPath, "Slave image file path [CSL image format]") ;
    }
    else {
        setStringValForKeyIn(parameterList, "???", "Slave image file path [CSL image format]") ;
    }

	if(pInSAR->slavePolarizationChannel != NULL) {
		setStringValForKeyIn(parameterList, pInSAR->slavePolarizationChannel, "Slave polarization channel") ;
	}
	setIntValForKeyIn(parameterList, (pInSAR->ima2).lenr, "Slave image range dimension [pixels]") ;
	setIntValForKeyIn(parameterList, (pInSAR->ima2).lena, "Slave image azimuth dimension [rows]") ;
	setDoubleValForKeyIn(parameterList, (pInSAR->ima1).z0, "Master image minimum slant range") ;
	setDoubleValForKeyIn(parameterList, (pInSAR->ima2).z0, "Slave image minimum slant range") ;
    setDoubleValForKeyIn(parameterList, (pInSAR->rad).azimuthResolutionCell, "Azimuth sampling [m]") ;
    setDoubleValForKeyIn(parameterList, (pInSAR->rad).rangeResolutionCell, "Slant range sampling [m]") ;
	setDoubleValForKeyIn(parameterList, (pInSAR->rad).nu, "Radar carrier frequency [Hz]") ;
	if(pInSAR->isBistaticPair) {
        setStringValForKeyIn(parameterList, "YES", "Bistatic interferometric pair") ;
    }
    else {
        setStringValForKeyIn(parameterList, "NO", "Bistatic interferometric pair") ;
    }
    if (pInSAR->orbitTypes) {
        setStringValForKeyIn(parameterList, pInSAR->orbitTypes, "Orbit types") ;
    }
    
	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, "Area of interest", "") ;
	setStringValForKeyIn(parameterList, "****************", "") ;
	setIntValForKeyIn(parameterList, (int)pInSAR->aoi->P[0].x, "Lower left range coordinate") ;
	setIntValForKeyIn(parameterList, (int)pInSAR->aoi->P[0].y, "Lower left azimuth coordinate") ;
	setIntValForKeyIn(parameterList, (int)pInSAR->aoi->P[2].x, "Upper right range coordinate") ;
	setIntValForKeyIn(parameterList, (int)pInSAR->aoi->P[2].y, "Upper right azimuth coordinate") ;
    if (pInSAR->aoiKml) {
        setStringValForKeyIn(parameterList, pInSAR->aoiKml, "Area of Interest .kml file") ;
    }
    else {
        setStringValForKeyIn(parameterList, "Full size", "Area of Interest .kml file") ;
    }
    if (pInSAR->externalReferenceDEM) {
        setStringValForKeyIn(parameterList, pInSAR->externalReferenceDEM, "External reference DEM (full path or DEM name provided $EXTERNAL_DEMS_DIR is defined)") ;
    }
    else {
        setStringValForKeyIn(parameterList, "DEMname", "External reference DEM (full path or DEM name provided $EXTERNAL_DEMS_DIR is defined)") ;
    }
    
	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, "Satellite - Earth centre distance", "") ;
	setStringValForKeyIn(parameterList, "*********************************", "") ;
	setDoubleValForKeyIn(parameterList, (pInSAR->S1).aS, "Linear variation [m]/[azimuth row]") ;
    setDoubleValForKeyIn(parameterList, (pInSAR->S1).bS, "Constant term [m]") ;
    setDoubleValForKeyIn(parameterList, (pInSAR->S1).RT, "Earth radius at master image centre [m]") ;
	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, "Baseline parameters", "") ;
	setStringValForKeyIn(parameterList, "*******************", "") ;
	setDoubleValForKeyIn(parameterList, pInSAR->B.T[0][2], "Horizontal baseline component constant term [m]") ;
	setDoubleValForKeyIn(parameterList, pInSAR->B.T[0][0], "Horizontal baseline variation with range position [m]/[range pix]") ;
	setDoubleValForKeyIn(parameterList, pInSAR->B.T[0][1], "Horizontal baseline variation with azimuth position [m]/[azimuth pix]") ;
	setDoubleValForKeyIn(parameterList, pInSAR->B.T[1][2], "Vertical baseline component constant term [m]") ;
	setDoubleValForKeyIn(parameterList, pInSAR->B.T[1][0], "Vertical baseline variation with range position [m]/[range pix]") ;
	setDoubleValForKeyIn(parameterList, pInSAR->B.T[1][1], "Vertical baseline variation with azimuth position [m]/[azimuth pix]") ;
    if (pInSAR->B.Bperp && pInSAR->B.Bpara) {
        setDoubleValForKeyIn(parameterList, pInSAR->B.Bperp, "Perpendicular baseline component at image centre") ;
        setDoubleValForKeyIn(parameterList, pInSAR->B.Bpara, "Parallel baseline component at image centre") ;
    }
	setDoubleValForKeyIn(parameterList, pInSAR->ambiguityAltitude, "Ambiguity altitude at scene centre") ;
    if (pInSAR->B.deltaDays || pInSAR->isBistaticPair) {
        setIntValForKeyIn(parameterList, pInSAR->B.deltaDays, "Temporal baseline [day]") ;
    }

	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, "********************", "") ;
	setStringValForKeyIn(parameterList, "* InSAR processing *", "") ;
	setStringValForKeyIn(parameterList, "********************", "") ;

    setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, "-1- Box averaging ", "") ;
	setStringValForKeyIn(parameterList, "*****************", "") ;
	setStringValForKeyIn(parameterList, (pInSAR->mod1).filePath, "Reduced master amplitude image file path") ;
	setIntValForKeyIn(parameterList, (pInSAR->mod1).lenr, "Reduced master amplitude image range dimension [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->mod1).lena, "Reduced master amplitude image azimuth dimension [pix]") ;
	setStringValForKeyIn(parameterList, (pInSAR->mod2).filePath, "Reduced slave amplitude image file path") ;
	setIntValForKeyIn(parameterList, (pInSAR->mod2).lenr, "Reduced slave amplitude image range dimension [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->mod2).lena, "Reduced slave amplitude image azimuth dimension [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->red).Fra, "Range reduction factor [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->red).Faz, "Azimuth reduction factor [pix]") ;

	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, "-2- Coarse coregistration", "") ;
	setStringValForKeyIn(parameterList, "*************************", "") ;
	setIntValForKeyIn(parameterList, (pInSAR->corg).F_lenr, "Coarse coregistration range window size [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->corg).F_lena, "Coarse coregistration azimuth window size [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->corg).Depra, "Coarse registration range distance between anchor points [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->corg).Depaz, "Coarse registration azimuth distance between anchor points [pix]") ;
	setDoubleValForKeyIn(parameterList, (pInSAR->corg).seuilcoh, "Coarse coregistration correlation threshold") ;
	setDoubleValForKeyIn(parameterList, (pInSAR->corg).seuilra, "Corelation peak range width threshold") ;
	setDoubleValForKeyIn(parameterList, (pInSAR->corg).seuilaz, "Corelation peak azimut width threshold") ;

	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, "-3- Fine coregistration", "") ;
	setStringValForKeyIn(parameterList, "***********************", "") ;
	setIntValForKeyIn(parameterList, (pInSAR->corf).F_lenr, "Fine coregistration range window size [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->corf).F_lena, "Fine coregistration azimuth window size [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->corf).errra, "Estimated range error [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->corf).erraz, "Estimated azimuth error [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->corf).Depra, "Fine registration range distance between anchor points [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->corf).Depaz, "Fine registration azimuth distance between anchor points [pix]") ;
	setDoubleValForKeyIn(parameterList, (pInSAR->corf).seuilcoh, "Fine coregistration correlation threshold") ;

	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, "-4- Interpolation", "") ;
	setStringValForKeyIn(parameterList, "*****************", "") ;
	setStringValForKeyIn(parameterList, "Master to slave affine coordinate transform:", "") ;
	setStringValForKeyIn(parameterList, "x2 = Ax x1 + Bx y1 + Cx", "") ;
	setStringValForKeyIn(parameterList, "y2 = Ay x1 + By y1 + Cy", "") ;
	setDoubleValForKeyIn(parameterList, pInSAR->slaveAffineTransform[0][0], "Ax") ;
	setDoubleValForKeyIn(parameterList, pInSAR->slaveAffineTransform[0][1], "Bx") ;
	setDoubleValForKeyIn(parameterList, pInSAR->slaveAffineTransform[0][2], "Cx") ;
	setDoubleValForKeyIn(parameterList, pInSAR->slaveAffineTransform[1][0], "Ay") ;
	setDoubleValForKeyIn(parameterList, pInSAR->slaveAffineTransform[1][1], "By") ;
	setDoubleValForKeyIn(parameterList, pInSAR->slaveAffineTransform[1][2], "Cy") ;
	setStringValForKeyIn(parameterList, pInSAR->interpolatedSlave->imageDirectoryPath, "Interpolated slave image file path") ;

	setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, "Global master to master InSAR processing", "") ;
    if (pInSAR->SM2MPath) {
        setStringValForKeyIn(parameterList, pInSAR->SM2MPath, "Global master to master InSAR directory path") ;
    }
    else {
        setStringValForKeyIn(parameterList, "NONE", "Global master to master InSAR directory path") ;
    }

	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, "-5- Interferometric products computation", "") ;
	setStringValForKeyIn(parameterList, "****************************************", "") ;
	setIntValForKeyIn(parameterList, (pInSAR->interf).lenr, "Interferometric products range dimension [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->interf).lena, "Interferometric products azimuth dimension [pix]") ;
	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, (pInSAR->interf).filePath, "Interferogram file path") ;
	setStringValForKeyIn(parameterList, (pInSAR->filter).filePath, "Filtered interferogram file path") ;
	setDoubleValForKeyIn(parameterList, (pInSAR->filter).sigmar, "Range filter Full Width at Half Maximum") ;
    setDoubleValForKeyIn(parameterList, (pInSAR->filter).sigmaz, "Azimuth filter Full Width at Half Maximum") ;
    setDoubleValForKeyIn(parameterList, (pInSAR->filter).adaptativeFilterSmoothingFactor, "Power spectrum filtering factor (for adaptative filtering)") ;
	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, (pInSAR->coh).filePath, "Coherence file path") ;
	setIntValForKeyIn(parameterList, (pInSAR->coh).cor, "Coherence estimator range window size [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->coh).coa, "Coherence estimator azimuth window size [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->coh).spi, "Square spiral size [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->coh).medianFilterSize, "Median filter size [pix]") ;
    setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, (pInSAR->firstPhaseComponent).filePath, "Topographic phase component file path") ;
	setStringValForKeyIn(parameterList, (pInSAR->secondPhaseComponent).filePath, "Model-based phase component file path") ;
	setStringValForKeyIn(parameterList, (pInSAR->thirdPhaseComponent).filePath, "Correction phase component file path") ;
	setStringValForKeyIn(parameterList, (pInSAR->residualPhase).filePath, "Residual interferogram file path") ;

    if (isnan(pInSAR->DEMExcludingValue)) {
        setStringValForKeyIn(parameterList, "NaN", "Excluding value") ;
    }
    else {
        setFloatValForKeyIn(parameterList, pInSAR->DEMExcludingValue, "Excluding value") ;
    }

	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, "-6- Phase unwrapping", "") ;
	setStringValForKeyIn(parameterList, "********************", "") ;
	setStringValForKeyIn(parameterList, (pInSAR->cohder).filePath, "Biased coherence file path") ;
	setIntValForKeyIn(parameterList, (pInSAR->cohder).lenr, "Biased coherence range dimension [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->cohder).lena, "Biased coherence azimuth dimension [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->cohder).cor, "Biased coherence estimator range window size [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->cohder).coa, "Biased coherence estimator azimuth window size [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->cohder).spi, "Biased coherence square spiral size [pix]") ;
	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, (pInSAR->res).filePath, "Residus image file path") ;
	setIntValForKeyIn(parameterList, (pInSAR->res).lenr, "Residus image range dimension [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->res).lena, "Residus image azimuth dimension [pix]") ;
	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, (pInSAR->conex).filePath, "Connexions image file path") ;
	setIntValForKeyIn(parameterList, (pInSAR->conex).lenr, "Connexions image range dimension [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->conex).lena, "Connexions image azimuth dimension [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->conex).rrmin, "Range minimum search radius [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->conex).ramin, "Azimuth minimum search radius [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->conex).drr, "Range search radius step [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->conex).dra, "Azimuth search radius step [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->conex).ech, "Coherence scaling") ;
	setIntValForKeyIn(parameterList, (pInSAR->conex).ts, "Connexion process mode") ;
	setFloatValForKeyIn(parameterList, (pInSAR->conex).seuilnet, "Coherence cleaning threshold") ;
	setFloatValForKeyIn(parameterList, (pInSAR->conex).seuilsuiv, "False residue coherence threshold") ;
	setStringValForKeyIn(parameterList, "", "") ;
	setStringValForKeyIn(parameterList, (pInSAR->dephi).filePath, "Unwrapped phase file path") ;
	setIntValForKeyIn(parameterList, (pInSAR->dephi).lenr, "Unwrapped phase range dimension [pix]") ;
	setIntValForKeyIn(parameterList, (pInSAR->dephi).lena, "Unwrapped phase azimuth dimension [pix]") ;
	setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, pInSAR->externalSlantRangeDEMFile->accessPath, "External slant range DEM file path") ;
    setIntValForKeyIn(parameterList, (pInSAR->externalSlantRangeDEMFile)->xDim, "External slant range DEM range dimension [pix]") ;
    setIntValForKeyIn(parameterList, (pInSAR->externalSlantRangeDEMFile)->yDim, "External slant range DEM azimuth dimension [pix]") ;
    setStringValForKeyIn(parameterList, "", "") ;
    if (pInSAR->flag & _TOPO_) {
        setStringValForKeyIn(parameterList, (pInSAR->srDEM).filePath, "Slant range DEM file path") ;
        setIntValForKeyIn(parameterList, (pInSAR->srDEM).lenr, "Slant range DEM range dimension [pix]") ;
        setIntValForKeyIn(parameterList, (pInSAR->srDEM).lena, "Slant range DEM azimuth dimension [pix]") ;
        removeKeyValuePairIn(parameterList, "Deformation measurement file path") ;
        removeKeyValuePairIn(parameterList, "Deformation measurement range dimension [pix]") ;
        removeKeyValuePairIn(parameterList, "Deformation measurement azimuth dimension [pix]") ;
    }
    if (pInSAR->flag & _DEFO_) {
        setStringValForKeyIn(parameterList, (pInSAR->srDEM).filePath, "Deformation measurement file path") ;
        setIntValForKeyIn(parameterList, (pInSAR->srDEM).lenr, "Deformation measurement range dimension [pix]") ;
        setIntValForKeyIn(parameterList, (pInSAR->srDEM).lena, "Deformation measurement azimuth dimension [pix]") ;
        removeKeyValuePairIn(parameterList, "Slant range DEM file path") ;
        removeKeyValuePairIn(parameterList, "Slant range DEM range dimension [pix]") ;
        removeKeyValuePairIn(parameterList, "Slant range DEM azimuth dimension [pix]") ;
    }

	writeParameterFileAtPath(parameterList, aPath) ;
    freeKeyValueList(parameterList) ;
}

void freeInSARParametersStruct(InSARParametersStruct *pInSAR)
{
    if (pInSAR->whereAmI) {
        free(pInSAR->whereAmI) ;
        pInSAR->whereAmI= NULL ;
    }
    
    if (pInSAR->masterImage != NULL) {
        freeCSLImageStructure(pInSAR->masterImage) ;
        pInSAR->masterImage = NULL ;
    }
    if (pInSAR->slaveImage != NULL) {
        freeCSLImageStructure(pInSAR->slaveImage) ;
        pInSAR->slaveImage = NULL ;
    }

    if (pInSAR->interpolatedSlave) {
        freeCSLImageStructure(pInSAR->interpolatedSlave) ;
        pInSAR->interpolatedSlave = NULL ;
    }
    if (pInSAR->interpolatedMaster) {
        freeCSLImageStructure(pInSAR->interpolatedMaster) ;
        pInSAR->interpolatedMaster = NULL ;
    }
	if(pInSAR->masterImageFile != NULL) {
		freeRawFileDescriptor(pInSAR->masterImageFile) ;
		pInSAR->masterImageFile = NULL ;
	}
	if(pInSAR->slaveImageFile != NULL) {
		freeRawFileDescriptor(pInSAR->slaveImageFile) ;
		pInSAR->slaveImageFile = NULL ;
	}
	if(pInSAR->interpolatedSlaveImageFile != NULL) {
		freeRawFileDescriptor(pInSAR->interpolatedSlaveImageFile) ;
		pInSAR->interpolatedSlaveImageFile = NULL ;
	}
	if(pInSAR->interferogramFile != NULL) {
		freeRawFileDescriptor(pInSAR->interferogramFile) ;
		pInSAR->interferogramFile = NULL ;
	}
	if(pInSAR->filteredInterferogramFile != NULL) {
		freeRawFileDescriptor(pInSAR->filteredInterferogramFile) ;
		pInSAR->filteredInterferogramFile = NULL ;
	}
	if(pInSAR->firstPhaseComponentFile != NULL) {
		freeRawFileDescriptor(pInSAR->firstPhaseComponentFile) ;
		pInSAR->firstPhaseComponentFile = NULL ;
	}
	if(pInSAR->secondPhaseComponentFile != NULL) {
		freeRawFileDescriptor(pInSAR->secondPhaseComponentFile) ;
		pInSAR->secondPhaseComponentFile = NULL ;
	}
	if(pInSAR->thirdPhaseComponentFile != NULL) {
		freeRawFileDescriptor(pInSAR->thirdPhaseComponentFile) ;
		pInSAR->thirdPhaseComponentFile = NULL ;
	}
	if(pInSAR->residualPhaseFile != NULL) {
		freeRawFileDescriptor(pInSAR->residualPhaseFile) ;
		pInSAR->residualPhaseFile = NULL ;
	}
	if(pInSAR->coherenceFile != NULL) {
		freeRawFileDescriptor(pInSAR->coherenceFile) ;
		pInSAR->coherenceFile = NULL ;
	}
	if(pInSAR->biasedCoherenceFile != NULL) {
		freeRawFileDescriptor(pInSAR->biasedCoherenceFile) ;
		pInSAR->biasedCoherenceFile = NULL ;
	}
	if(pInSAR->residuesFile != NULL) {
		freeRawFileDescriptor(pInSAR->residuesFile) ;
		pInSAR->residuesFile = NULL ;
	}
	if(pInSAR->connexionsFile != NULL) {
		freeRawFileDescriptor(pInSAR->connexionsFile) ;
		pInSAR->connexionsFile = NULL ;
	}
	if(pInSAR->unwrappedPhaseFile != NULL) {
		freeRawFileDescriptor(pInSAR->unwrappedPhaseFile) ;
		pInSAR->unwrappedPhaseFile = NULL ;
	}
	if(pInSAR->externalSlantRangeDEMFile != NULL) {
		freeRawFileDescriptor(pInSAR->externalSlantRangeDEMFile) ;
		pInSAR->externalSlantRangeDEMFile = NULL ;
	}
	if(pInSAR->measurementFile != NULL) {
		freeRawFileDescriptor(pInSAR->measurementFile) ;
		pInSAR->measurementFile = NULL ;
	}
	if(pInSAR->masterAmplitudeImageFile != NULL) {
		freeRawFileDescriptor(pInSAR->masterAmplitudeImageFile) ;
		pInSAR->masterAmplitudeImageFile = NULL ;
	}
	if(pInSAR->slaveAmplitudeImageFile != NULL) {
		freeRawFileDescriptor(pInSAR->slaveAmplitudeImageFile) ;
		pInSAR->slaveAmplitudeImageFile = NULL ;
	}
	if(pInSAR->phaseStandardDeviationImageFile != NULL) {
		freeRawFileDescriptor(pInSAR->phaseStandardDeviationImageFile) ;
		pInSAR->phaseStandardDeviationImageFile = NULL ;
	}
	if(pInSAR->heightStandardDeviationImageFile != NULL) {
		freeRawFileDescriptor(pInSAR->heightStandardDeviationImageFile) ;
		pInSAR->heightStandardDeviationImageFile = NULL ;
	}

    if (pInSAR->masterInfo) {
        if (pInSAR->SM2MpInSAR) {
            if (pInSAR->masterInfo == pInSAR->SM2MpInSAR->masterInfo) {
                pInSAR->SM2MpInSAR->masterInfo = NULL ;
            }
            if (pInSAR->masterInfo == pInSAR->SM2MpInSAR->slaveInfo) {
                pInSAR->SM2MpInSAR->slaveInfo = NULL ;
            }
            if (pInSAR->masterInfo == pInSAR->SM2MpInSAR->interpolatedSlaveInfo) {
                pInSAR->SM2MpInSAR->interpolatedSlaveInfo = NULL ;
            }
        }
        freeInfoImage(pInSAR->masterInfo) ;
        pInSAR->masterInfo = NULL ;
    }
    if (pInSAR->slaveInfo) {
        if (pInSAR->SM2MpInSAR) {
            if (pInSAR->slaveInfo == pInSAR->SM2MpInSAR->masterInfo) {
                pInSAR->SM2MpInSAR->masterInfo = NULL ;
            }
            if (pInSAR->slaveInfo == pInSAR->SM2MpInSAR->slaveInfo) {
                pInSAR->SM2MpInSAR->slaveInfo = NULL ;
            }
            if (pInSAR->slaveInfo == pInSAR->SM2MpInSAR->interpolatedSlaveInfo) {
                pInSAR->SM2MpInSAR->interpolatedSlaveInfo = NULL ;
            }        }
        freeInfoImage(pInSAR->slaveInfo) ;
        pInSAR->slaveInfo = NULL ;
    }
    if (pInSAR->interpolatedSlaveInfo) {
        freeInfoImage(pInSAR->interpolatedSlaveInfo) ;
        pInSAR->interpolatedSlaveInfo = NULL ;
    }
    if (pInSAR->SM2MPath) {
        free(pInSAR->SM2MPath) ;
    }
    if (pInSAR->SM2MpInSAR) {
        freeInSARParametersStruct(pInSAR->SM2MpInSAR) ;
        pInSAR->SM2MpInSAR = NULL ;
    }
    if (pInSAR->ima1.filePath) {
        free(pInSAR->ima1.filePath) ;
        pInSAR->ima1.filePath = NULL ;
    }
    if (pInSAR->ima2.filePath) {
        free(pInSAR->ima2.filePath) ;
        pInSAR->ima2.filePath = NULL ;
    }
    if (pInSAR->masterPolarizationChannel) {
        free(pInSAR->masterPolarizationChannel) ;
        pInSAR->masterPolarizationChannel = NULL ;
    }
    if (pInSAR->slavePolarizationChannel) {
        free(pInSAR->slavePolarizationChannel) ;
        pInSAR->slavePolarizationChannel = NULL ;
    }
    if (pInSAR->B.T) {
        freeMatrixDouble(pInSAR->B.T, 0, 0) ;
        pInSAR->B.T = NULL ;
    }
    if (pInSAR->masterAffineTransform) {
        freeMatrixDouble(pInSAR->masterAffineTransform, 0, 0) ;
        pInSAR->masterAffineTransform = NULL ;
    }
    if (pInSAR->slaveAffineTransform) {
        freeMatrixDouble(pInSAR->slaveAffineTransform, 0, 0) ;
        pInSAR->slaveAffineTransform = NULL ;
    }
    if (pInSAR->inverseSlaveAffineTransform) {
        freeMatrixDouble(pInSAR->inverseSlaveAffineTransform, 0, 0) ;
        pInSAR->inverseSlaveAffineTransform = NULL ;
    }
    if (pInSAR->mod1.filePath) {
        free(pInSAR->mod1.filePath) ;
        pInSAR->mod1.filePath = NULL ;
    }
    if (pInSAR->mod2.filePath) {
        free(pInSAR->mod2.filePath) ;
        pInSAR->mod2.filePath = NULL ;
    }
    if (pInSAR->firstPhaseComponent.filePath) {
        free(pInSAR->firstPhaseComponent.filePath) ;
        pInSAR->firstPhaseComponent.filePath = NULL ;
    }
    if (pInSAR->secondPhaseComponent.filePath) {
        free(pInSAR->secondPhaseComponent.filePath) ;
        pInSAR->secondPhaseComponent.filePath = NULL ;
    }
    if (pInSAR->thirdPhaseComponent.filePath) {
        free(pInSAR->thirdPhaseComponent.filePath) ;
        pInSAR->thirdPhaseComponent.filePath = NULL ;
    }
    if (pInSAR->residualPhase.filePath) {
        free(pInSAR->residualPhase.filePath) ;
        pInSAR->residualPhase.filePath = NULL ;
    }
    if (pInSAR->interf.filePath) {
        free(pInSAR->interf.filePath) ;
        pInSAR->interf.filePath = NULL ;
    }
    if (pInSAR->filter.filePath) {
        free(pInSAR->filter.filePath) ;
        pInSAR->filter.filePath = NULL ;
    }
    if (pInSAR->coh.filePath) {
        free(pInSAR->coh.filePath) ;
        pInSAR->coh.filePath = NULL ;
    }
    if (pInSAR->cohder.filePath) {
        free(pInSAR->cohder.filePath) ;
        pInSAR->cohder.filePath = NULL ;
    }
    if (pInSAR->res.filePath) {
        free(pInSAR->res.filePath) ;
        pInSAR->res.filePath = NULL ;
    }
    if (pInSAR->conex.filePath) {
        free(pInSAR->conex.filePath) ;
        pInSAR->conex.filePath = NULL ;
    }
    if (pInSAR->dephi.filePath) {
        free(pInSAR->dephi.filePath) ;
        pInSAR->dephi.filePath = NULL ;
    }
    if (pInSAR->srDEM.filePath) {
        free(pInSAR->srDEM.filePath) ;
        pInSAR->srDEM.filePath = NULL ;
    }
    if (pInSAR->geo) {
        freeGeoRef(pInSAR->geo) ;
        pInSAR->geo = NULL ;
    }
    if (pInSAR->aoi) {
        freePolygon(pInSAR->aoi) ;
        pInSAR->aoi = NULL ;
    }
    if (pInSAR->aoiKml) {
        free(pInSAR->aoiKml) ;
        pInSAR->aoiKml = NULL ;
    }
    if (pInSAR->orbitTypes) {
        free(pInSAR->orbitTypes) ;
        pInSAR->orbitTypes = NULL ;
    }

    if (pInSAR->xCoregistrationGrid != NULL) {
        freeGridMap(pInSAR->xCoregistrationGrid) ;
        pInSAR->xCoregistrationGrid = NULL ;
    }
    if (pInSAR->yCoregistrationGrid != NULL) {
        freeGridMap(pInSAR->yCoregistrationGrid) ;
        pInSAR->yCoregistrationGrid = NULL ;
    }
    if (pInSAR->additionalParameters != NULL) {
        freeKeyValueList(pInSAR->additionalParameters) ;
        pInSAR->additionalParameters = NULL ;
    }

    if (pInSAR->externalReferenceDEM){
        free(pInSAR->externalReferenceDEM) ;
        pInSAR->externalReferenceDEM = NULL ;
    }
    
    if (pInSAR->slantRangeMask){
        free(pInSAR->slantRangeMask) ;
        pInSAR->slantRangeMask = NULL ;
    }
    
    if (pInSAR->thresholdedSlantRangeMask){
        free(pInSAR->thresholdedSlantRangeMask) ;
        pInSAR->thresholdedSlantRangeMask = NULL ;
    }
    


	free(pInSAR) ;
}


rawFileDescriptor *openMasterImageForReading(InSARParametersStruct *pInSAR)
{
    char *aFilePath ;

    /* Open master image */
    if (pInSAR->masterInterpolation) {
        printf("Master interpolation is active\n") ;
        aFilePath = initStringWith3Strings(pInSAR->interpolatedMaster->dataDirectoryPath, "/SLCData.", pInSAR->masterPolarizationChannel) ;
    }
    else {
        aFilePath = initStringWith3Strings(pInSAR->masterImage->dataDirectoryPath, "/SLCData.", pInSAR->masterPolarizationChannel) ;
    }
    if((pInSAR->masterImageFile = openRawFileForReadingAtPath(aFilePath)) == NULL) {
        sprintf(ertex, "Failed to open master image file at path %s\n", aFilePath) ;
        ase(ertex) ;
    }
    pInSAR->masterImageFile->xDim = pInSAR->masterInfo->rangeDimension ;
    pInSAR->masterImageFile->yDim = pInSAR->masterInfo->azimuthDimension ;
    setRawFileAoI(pInSAR->masterImageFile, pInSAR->aoi) ;
   free(aFilePath) ;

    return(pInSAR->masterImageFile) ;
}

rawFileDescriptor *openSlaveImageForReading(InSARParametersStruct *pInSAR)
{
    char *aFilePath ;

    aFilePath = initStringWith3Strings(pInSAR->interpolatedSlave->dataDirectoryPath, "/SLCData.", pInSAR->slavePolarizationChannel) ;
    if((pInSAR->slaveImageFile = openRawFileForReadingAtPath(aFilePath)) == NULL) {
        sprintf(ertex, "Failed to open interpolated slave image file at path %s\n", aFilePath) ;
        ase(ertex) ;
    }
    pInSAR->slaveImageFile->xDim = pInSAR->slaveInfo->rangeDimension ;
    pInSAR->slaveImageFile->yDim = pInSAR->slaveInfo->azimuthDimension ;
    setRawFileAoI(pInSAR->slaveImageFile, pInSAR->aoi) ;
    free(aFilePath) ;

    return(pInSAR->slaveImageFile) ;
}

rawFileDescriptor *openInterferogramFile(InSARParametersStruct *pInSAR)
{
    if(pInSAR->interferogramFile) {
        rewind(pInSAR->interferogramFile->f) ;
        return pInSAR->interferogramFile ;
    }

    if((pInSAR->interferogramFile = openRawFileForReadingAndWritingAtPath(pInSAR->interf.filePath)) == NULL)
        return NULL ;

    pInSAR->interferogramFile->xDim = pInSAR->interf.lenr ;
    pInSAR->interferogramFile->yDim = pInSAR->interf.lena ;
    pInSAR->interferogramFile->typeSize = sizeof(float) ;

    return (pInSAR->interferogramFile) ;
}


rawFileDescriptor *openFilteredInterferogramFile(InSARParametersStruct *pInSAR)
{
    if(pInSAR->filteredInterferogramFile) {
        rewind(pInSAR->filteredInterferogramFile->f) ;
        return pInSAR->filteredInterferogramFile ;
    }

    if((pInSAR->filteredInterferogramFile = openRawFileForReadingAndWritingAtPath(pInSAR->filter.filePath)) == NULL) {
        return NULL ;
    }

    pInSAR->filteredInterferogramFile->xDim = pInSAR->interf.lenr ;
    pInSAR->filteredInterferogramFile->yDim = pInSAR->interf.lena ;
    pInSAR->filteredInterferogramFile->typeSize = sizeof(float) ;

    return (pInSAR->filteredInterferogramFile) ;
}


rawFileDescriptor *openFirstPhaseComponentFile(InSARParametersStruct *pInSAR)
{
    if(pInSAR->firstPhaseComponentFile) {
        rewind(pInSAR->firstPhaseComponentFile->f) ;
        return pInSAR->firstPhaseComponentFile ;
    }
    
    if((pInSAR->firstPhaseComponentFile = openRawFileForReadingAndWritingAtPath(pInSAR->firstPhaseComponent.filePath)) == NULL) {
        return NULL ;
    }

    pInSAR->firstPhaseComponentFile->xDim = pInSAR->interf.lenr ;
    pInSAR->firstPhaseComponentFile->yDim = pInSAR->interf.lena ;
    pInSAR->firstPhaseComponentFile->typeSize = sizeof(float) ;

    return (pInSAR->firstPhaseComponentFile) ;
}


rawFileDescriptor *openResidualInterferogramFile(InSARParametersStruct *pInSAR)
{
    if(pInSAR->residualPhaseFile) {
        rewind(pInSAR->residualPhaseFile->f) ;
        return pInSAR->residualPhaseFile ;
    }

    if((pInSAR->residualPhaseFile = openRawFileForReadingAndWritingAtPath(pInSAR->residualPhase.filePath)) == NULL) {
        return NULL ;
    }

    pInSAR->residualPhaseFile->xDim = pInSAR->interf.lenr ;
    pInSAR->residualPhaseFile->yDim = pInSAR->interf.lena ;
    pInSAR->residualPhaseFile->typeSize = sizeof(float) ;

    return (pInSAR->residualPhaseFile) ;
}


rawFileDescriptor *openUnwrappedPhaseFile(InSARParametersStruct *pInSAR)
{
    if(pInSAR->unwrappedPhaseFile) {
        rewind(pInSAR->unwrappedPhaseFile->f) ;
        return pInSAR->unwrappedPhaseFile ;
    }

    if((pInSAR->unwrappedPhaseFile = openRawFileForReadingAndWritingAtPath(pInSAR->dephi.filePath)) == NULL) {
        return NULL ;
    }

    pInSAR->unwrappedPhaseFile->xDim = pInSAR->dephi.lenr ;
    pInSAR->unwrappedPhaseFile->yDim = pInSAR->dephi.lena ;
    pInSAR->unwrappedPhaseFile->typeSize = sizeof(float) ;

    return (pInSAR->unwrappedPhaseFile) ;
}



rawFileDescriptor *openCoherenceFile(InSARParametersStruct *pInSAR)
{
    if(pInSAR->coherenceFile) {
        rewind(pInSAR->coherenceFile->f) ;
        return pInSAR->coherenceFile ;
    }

    if((pInSAR->coherenceFile = openRawFileForReadingAndWritingAtPath(pInSAR->coh.filePath)) == NULL) {
        return NULL ;
    }

    pInSAR->coherenceFile->xDim = pInSAR->coh.lenr ;
    pInSAR->coherenceFile->yDim = pInSAR->coh.lena ;
    pInSAR->coherenceFile->typeSize = sizeof(float) ;

    return (pInSAR->coherenceFile) ;
}



rawFileDescriptor *openMeasurementFile(InSARParametersStruct *pInSAR)
{
    if(pInSAR->measurementFile) {
        rewind(pInSAR->measurementFile->f) ;
        return pInSAR->measurementFile ;
    }

    if((pInSAR->measurementFile = openRawFileForReadingAndWritingAtPath(pInSAR->srDEM.filePath)) == NULL) {
        return (NULL) ;
    }

    pInSAR->measurementFile->xDim = pInSAR->srDEM.lenr ;
    pInSAR->measurementFile->yDim = pInSAR->srDEM.lena ;
    pInSAR->measurementFile->typeSize = sizeof(float) ;

    return (pInSAR->measurementFile) ;
}

rawFileDescriptor *openExternalSlantRangeDEMFile(InSARParametersStruct *pInSAR)
{
    if(pInSAR->externalSlantRangeDEMFile->f) {
        closeRawFile(pInSAR->externalSlantRangeDEMFile) ;
    }

    if(!openRawFileForReadingAndWriting(pInSAR->externalSlantRangeDEMFile)) {
        return NULL ;
    }
    pInSAR->externalSlantRangeDEMFile->typeSize = sizeof(float) ;

    return (pInSAR->externalSlantRangeDEMFile) ;
}




/* Create an example MCA parameter file at given path */
void createSBInSARParameterFileAtPath(InSARParametersStruct *pInSAR)
{
    char *aPath ;
    char isTDX ;
    int Nsb ;
    double bandwidth ;
    keyValue *paramList ;

    if ((pInSAR->flag & _NSB2_)) {
        bandwidth = divr(pInSAR->masterInfo->rangeBandwidth, 3000000).q * 1000000;
        Nsb = 2 ;
    }
    else {
        bandwidth = divr(pInSAR->masterInfo->rangeBandwidth, 5000000).q * 1000000;
        Nsb = 5 ;
    }

    paramList = allocAKeyValuePair() ;

    setStringValForKeyIn(paramList, "SBInSAR process parameter file", "") ;
    setStringValForKeyIn(paramList, "******************************", "") ;
    setStringValForKeyIn(paramList, "", "") ;
    aPath = initStringWith2Strings(pInSAR->whereAmI, "/SBInSARProducts") ;
    setStringValForKeyIn(paramList, aPath, "Root working directory") ;
    free(aPath) ;
    aPath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/InSARParameters.txt") ;
    setStringValForKeyIn(paramList, aPath, "InSAR parameters file") ;
    free(aPath) ;

    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Band splitting processing parameters", "") ;
    setStringValForKeyIn(paramList, "************************************", "") ;
    setDoubleValForKeyIn(paramList, pInSAR->masterInfo->radarCarrierFrequency, "RCF: Radar carrier frequency [Hz]") ;
    setDoubleValForKeyIn(paramList, pInSAR->masterInfo->rangeSamplingFrequency, "RSF: Range sampling frequency [Hz]") ;
    setDoubleValForKeyIn(paramList, bandwidth, "Bandwidth of sub-bands") ;
    setDoubleValForKeyIn(paramList, (pInSAR->masterInfo->rangeBandwidth - bandwidth) / (Nsb - 1), "Sub-bands frequency shift") ;
    setIntValForKeyIn(paramList, Nsb, "Sub-bands number") ;
    setStringValForKeyIn(paramList, "0.54", "Apodization coefficient") ;
    if (pInSAR->masterInfo->rangeApodizationCoefficient) {
        setDoubleValForKeyIn(paramList, pInSAR->masterInfo->rangeApodizationCoefficient, "Apodization coefficient") ;
    }


    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Multi-Chromatic Analysis", "") ;
    setStringValForKeyIn(paramList, "************************", "") ;
    setStringValForKeyIn(paramList, "mcaPhase", "MCA phase data filename") ;
//    setStringValForKeyIn(paramList, "absHeights", "Absolute heights data filename") ;
    setStringValForKeyIn(paramList, "regPhase", "Registration phase data filename") ;
    setStringValForKeyIn(paramList, "intercepts", "Intercepts data filename") ;
    setStringValForKeyIn(paramList, "R2", "R2 : Determination coefficient data file name") ;
    setStringValForKeyIn(paramList, "sigma", "Sigma data file name") ;
    setStringValForKeyIn(paramList, "spectralCoh", "Spectral coherence data file name") ;
    setStringValForKeyIn(paramList, "MCA.txt", "Text file gathering  bests points results") ;
    setStringValForKeyIn(paramList, "100", "Number of bests points extracted") ;
    setStringValForKeyIn(paramList, "sigmaIntercept", "Used criterion for bests points sorting (keywords are: spectralCoh, sigma, R2, sigmaIntercept)") ;
    setStringValForKeyIn(paramList, "YES", "Weighting linear regression with respect phase standard deviation (YES/NO)") ;

    /* Test if we deal with TDX PM or BS mode */
    /* We simply test if satellites are TSX and TDX with images acquired the same day */
    isTDX = ((pInSAR->masterInfo->sensorID == __TSX__ && pInSAR->slaveInfo->sensorID == __TDX__) 
          || (pInSAR->masterInfo->sensorID == __TDX__ && pInSAR->slaveInfo->sensorID == __TSX__)) ;
    isTDX *= !strcmp(pInSAR->masterInfo->acquisitionDate, pInSAR->slaveInfo->acquisitionDate) ;
    
    /* If we deal with TDX PM or BS mode, we localize the range registration file required for SBInSAR process */
    if (isTDX) {
        aPath = initStringWith2Strings(pInSAR->slaveImage->headersDirectoryPath, "/slave_shift_rg.flt") ;
    }
    else {
        aPath = initStringWithString("/aPath") ;
    }

    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Sensor-specific coregistration file", "") ;
    setStringValForKeyIn(paramList, "***********************************", "") ;
    setStringValForKeyIn(paramList, aPath, "Coregistration file") ;
    free(aPath) ;

    aPath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/SBInSARParameters.txt") ;
    writeParameterFileAtPath(paramList, aPath) ;
    freeKeyValueList(paramList) ;
    free(aPath) ;
}


/* Create an example cohTrack parameter file at given path */
void createCohTrackParameterFile(InSARParametersStruct *pInSAR)
{
    char *aPath, polScheme[10], aString[MAXSTRINGVALUELENGTH] ;
    keyValue *paramList ;

    sprintf(polScheme, "%s-%s", pInSAR->masterPolarizationChannel, pInSAR->slavePolarizationChannel) ;
    paramList = allocAKeyValuePair() ;

    setStringValForKeyIn(paramList, "CohTrack processing parameter file", "") ;
    setStringValForKeyIn(paramList, "**********************************", "") ;
    setStringValForKeyIn(paramList, "[-1 : .2 : 1]", "xSampling [dXMin : dXStep : dXMax]") ;
    setStringValForKeyIn(paramList, "[-1 : .2 : 1]", "ySampling [dYMin : dYStep : dYMax]") ;
    setStringValForKeyIn(paramList, ".2", "Coherence threshold") ;
    setStringValForKeyIn(paramList, ".2", "Visibility threshold") ;
    setStringValForKeyIn(paramList, ".2", "Sigma of range Gaussian filtering") ;
    setStringValForKeyIn(paramList, ".2", "Sigma of azimuth Gaussian filtering") ;
    setStringValForKeyIn(paramList, "NO", "NaN masking") ;


    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Output file names", "") ;
    setStringValForKeyIn(paramList, "*******************", "") ;
    sprintf(aString, "trackedCoherence.%s", polScheme) ;
    setStringValForKeyIn(paramList, aString, "Tracked coherence file name") ;
    sprintf(aString, "trackedInterf.%s", polScheme) ;
    setStringValForKeyIn(paramList, aString, "Tracked interferogram file name") ;
    sprintf(aString, "rangeShifts.%s", polScheme) ;
    setStringValForKeyIn(paramList, aString, "Tracked range shifts file name") ;
    sprintf(aString, "azimuthShifts.%s", polScheme) ;
    setStringValForKeyIn(paramList, aString, "Tracked azimuth shifts file name") ;
    sprintf(aString, "%s.tracked", getPointerToFileNameInPath(pInSAR->mod2.filePath)) ;
    setStringValForKeyIn(paramList, aString, "Tracked slave amplitude file name") ;


    aPath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/cohTrackParameters.txt") ;
    writeParameterFileAtPath(paramList, aPath) ;
    freeKeyValueList(paramList) ;
    free(aPath) ;


}
/* Get reference CSL image for InSAR processing, i.e. the master or the global master to which an external DEM should be associated. */
/* If no external DEM is associated with the considered image, NULL is returned */
CSLImage *getReferenceCSLImage(InSARParametersStruct *pInSAR)
{
    if (pInSAR->SM2MpInSAR) {
        return (getReferenceCSLImage(pInSAR->SM2MpInSAR)) ;
    }

    if (isFilePresentInCSLImage(pInSAR->masterImage, "externalSlantRangeDEM")) {
        return (pInSAR->masterImage) ;
    }

    return (NULL) ;
}


/* Compute effective range-azimuth coordinates of point in master image taking into account master transform if applicable */
/* If there is no global master to master transfrom, it returns the current position unchanged. */
/* If global master to master transfor exisits and if sent effective position pointer is NULL, currentPosition is updated with the computed effective position and NULL is returned. */
coord2D *computeEffectiveRangeAzimuthCoordinatesOfPoint(coord2D *currentPosition, coord2D *effectivePosition, InSARParametersStruct *pInSAR)
{
    if (effectivePosition) {
        effectivePosition[0] = currentPosition[0] ;
    }
    
    if (pInSAR->masterInterpolation) {
        planeAffineTransformOfCoord2D(currentPosition, effectivePosition, pInSAR->masterAffineTransform) ;
    }

    return effectivePosition ;
}


/* Find best range azimuth sampling ratio to generate ground range square pixels at mid swath */

/* Select filtered or not filtered interferogram */
rawFileDescriptor *selectInterferogram(InSARParametersStruct *pInSAR)
{
    rawFileDescriptor *interfPath ;

    /* Select requested interferogram */
    /* Open requested interferogram */
    if (pInSAR->flag & _CONSIDER_FILTERED_INTERF_) {
        interfPath = openFilteredInterferogramFile(pInSAR) ;
    }
    else {
        if (fileExistsAtPath(pInSAR->residualPhase.filePath)) {
            interfPath = openResidualInterferogramFile(pInSAR) ;
        }
        else {
            interfPath = openInterferogramFile(pInSAR) ;
        }
    }

    return(interfPath) ;
}

void freeSelectedInterferogram(InSARParametersStruct *pInSAR)
{
    if (pInSAR->flag & _CONSIDER_FILTERED_INTERF_) {
        freeRawFileDescriptor(pInSAR->filteredInterferogramFile) ;
        pInSAR->filteredInterferogramFile = NULL ;
    }
    else {
        if (fileExistsAtPath(pInSAR->residualPhase.filePath)) {
            freeRawFileDescriptor(pInSAR->residualPhaseFile) ;
            pInSAR->residualPhaseFile = NULL ;
         }
        else {
            freeRawFileDescriptor(pInSAR->interferogramFile) ;
            pInSAR->interferogramFile = NULL ;
         }
    }
}

/* Mask management: select event masks with respect to InSAR processing dates */
CSVStruct *selectEventMasks(InSARParametersStruct *pInSAR)
{
    char *image1Time, *image2Time, *imageTime ;
    int i ;
    CSLImage *referenceImage ;
    CSVStruct *eventMask, *selectedEventMask = NULL ;
    struct infoImage *info ;

    if ((referenceImage = getReferenceCSLImage(pInSAR))) {
        if((eventMask = recursiveSearchOfFileNamesInDir("eventMask", referenceImage->dataDirectoryPath))) {
            image1Time = allocStringOfLength(15) ;
            image2Time = allocStringOfLength(15) ;
            info = pInSAR->masterInfo ;
            sprintf(image1Time, "%.8sT%.2d%.2d%.2d", info->acquisitionDate, info->acquisitionTime_tm->tm_hour, info->acquisitionTime_tm->tm_min, info->acquisitionTime_tm->tm_sec) ;
            info = pInSAR->slaveInfo ;
            sprintf(image2Time, "%.8sT%.2d%.2d%.2d", info->acquisitionDate, info->acquisitionTime_tm->tm_hour, info->acquisitionTime_tm->tm_min, info->acquisitionTime_tm->tm_sec) ;
            if (strcmp(image1Time, image2Time) > 0) {
                imageTime = image1Time ;
                image1Time = image2Time ;
                image2Time = imageTime ;
            }
            
            for (i = 0 ; i < eventMask->numberOfEntries ; i++) {
                if (strncmp(eventMask->stringVal[i] + 9, image2Time, 15) < 0 && strncmp(eventMask->stringVal[i] + 25, image1Time, 15) > 0) {
                    selectedEventMask = addStringValInCSVStruct(eventMask->stringVal[i], selectedEventMask) ;
                }
            }
            
            free(image1Time) ;
            free(image2Time) ;
        } 
    }
    
    return (selectedEventMask) ;
}


void checkPolScheme(InSARParametersStruct *pInSAR, char *preferredPolarization)
{
    char isOk ;
    int i, j, masterPolIndex, slavePolIndex ;
    CSVStruct *masterPolarizations, *slavePolarizations ;

    /* We look in the info if several polarization channels are available and select the preferred one if available in both images */
	masterPolarizations = readCSVInString(pInSAR->masterInfo->polMode) ;
    slavePolarizations = readCSVInString(pInSAR->slaveInfo->polMode) ;
    masterPolIndex = slavePolIndex = 0 ;
    isOk = 0 ;
    if (preferredPolarization) {
        for (i = 0; i < masterPolarizations->numberOfEntries; i++) {
            if (!strncmp(masterPolarizations->stringVal[i], preferredPolarization, 2)) {
                masterPolIndex = i ;
            }
        }
        for (i = 0; i < slavePolarizations->numberOfEntries; i++) {
            if (!strncmp(slavePolarizations->stringVal[i], preferredPolarization, 2)) {
                slavePolIndex = i ;
            }
        }

        if (strncmp(masterPolarizations->stringVal[masterPolIndex], preferredPolarization, 2)) {
            printf("Expected polarization %s scheme not available.\n", preferredPolarization) ;
        }
        else
            isOk = 1 ;
    }

    /* If specific polarisation not requested or not found, we select the first corresponding polarization in both images */
    if (!isOk) {
        i = 0 ;
        while (i < masterPolarizations->numberOfEntries && !isOk) {
            j = 0 ;
            while (j < slavePolarizations->numberOfEntries && !isOk) {
                if (!strncmp(masterPolarizations->stringVal[i], slavePolarizations->stringVal[j], 2)) {
                    masterPolIndex = i ;
                    slavePolIndex = j ;
                    isOk = 1 ;
                }
                j++ ;
            }
            i++ ;
        }
    }
    if (!isOk) {
        printf("\t--> No common polarisation scheme found for slave and master images\n") ;
    }
    printf("\n\t--> Selected polarization scheme is %s-%s\n", masterPolarizations->stringVal[masterPolIndex], slavePolarizations->stringVal[slavePolIndex]) ;

    pInSAR->masterPolarizationChannel = initStringWithString(masterPolarizations->stringVal[masterPolIndex]) ;
	pInSAR->slavePolarizationChannel = initStringWithString(slavePolarizations->stringVal[slavePolIndex]) ;

    freeCSVStruct(masterPolarizations) ;
    freeCSVStruct(slavePolarizations) ;

}