
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  TSXDataReader.c
//  TSXDataReader
//
//  Created by Dominique Derauw on 22/08/12.
//  Copyright (c) 2012 Centre Spatial de Liège. All rights reserved.
//

#include <stdio.h>
#include "TSXDataReaderLib.h"


int main(int argc, const char * argv[])
{
    int i ;
    CSVStruct *csv = NULL, *savedCSLImages = NULL ;
    
    for (i = 0; i < argc; i++) {
        csv = addStringValInCSVStruct((char *)argv[i], csv) ;
    }
    
    savedCSLImages = TSXDataReader(csv) ;    
    freeCSVStruct(csv) ;
    freeCSVStruct(savedCSLImages) ;

    return(0) ;
}


