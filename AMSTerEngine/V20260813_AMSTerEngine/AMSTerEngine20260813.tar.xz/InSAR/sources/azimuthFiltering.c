
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  azimuthFiltering.c
//  azimuthFiltering
//
//  Created by Dominique Derauw on 6/01/2021.
//  Copyright © 2020 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "azimuthFilteringLib.h"


int main(int argc, const char * argv[])
{
    int i ;
    CSVStruct *csv = NULL ;
    
    for (i = 0; i < argc; i++) {
        csv = addStringValInCSVStruct((char *)argv[i], csv) ;
    }
    
    azimuthFiltering(csv) ;
    freeCSVStruct(csv) ;
    
    return(0) ;
}


