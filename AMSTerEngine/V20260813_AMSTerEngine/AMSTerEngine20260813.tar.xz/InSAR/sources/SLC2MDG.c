
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  SLC2MDG
//
//  Created by Dominique Derauw on 11/03/13.
//  Copyright (c) 2013 Centre Spatial de Liège. All rights reserved.
//

#include <stdio.h>
#include "SLC2MDG.h"

int main(int argc, const char * argv[])
{
    keyValue *paramList ;
    time_t startTime, endTime ;

    if (argc == 1 || isArgumentPresent(argc, argv, "-h")) {
        usage() ;
    }
    if (isArgumentPresent(argc, argv, "-create")) {
        createExampleParameterFileAtPath(argv[1]) ;
    }
    
	time(&startTime) ;
    paramList = readParameterFileAtPath((char *)argv[1]) ;
    
    SLC2MDG(paramList) ;
    
    freeKeyValueList(paramList) ;
    
	time(&endTime) ;
	duration(startTime, endTime) ;
    return 0;
}

void usage(void)
{
    printf("\nUsage:\nSLC2MDG path/parameterFile [-create]\n") ;
    printf("\nFirst parameter must be a valid path to a parameter file\n") ;
    printf("\nIf keyword \"-create\" is used, an example parameter file is created at given path\n") ;
}

void createExampleParameterFileAtPath(const char *aPath)
{
    keyValue *paramList ;
    
    paramList = allocAKeyValuePair() ;
    
    setStringValForKeyIn(paramList, "Calibration, multilooking and projection of SLC data - parameter file", "") ;
    setStringValForKeyIn(paramList, "*********************************************************************", "") ;
    setStringValForKeyIn(paramList, "/SLCImageFilePath", "Input file path to image in CSL format") ;
    setStringValForKeyIn(paramList, "Default", "Output file path (Default = within CSL format)") ;
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Multilooking", "") ;
    setStringValForKeyIn(paramList, "************", "") ;
    setStringValForKeyIn(paramList, "3", "Number of looks") ;
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Box averaging", "") ;
    setStringValForKeyIn(paramList, "*************", "") ;
    setStringValForKeyIn(paramList, "Taken into account only if multilooking is not requested (number of looks = 1)", "") ;
    setStringValForKeyIn(paramList, "1", "X box averaging size") ;
    setStringValForKeyIn(paramList, "1", "Y box averaging size") ;
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Detection", "") ;
    setStringValForKeyIn(paramList, "************", "") ;
    setStringValForKeyIn(paramList, "db", "Backscattering coefficient scale [db or linear]") ;
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Projection selection", "") ;
    setStringValForKeyIn(paramList, "********************", "") ;
    setStringValForKeyIn(paramList, "MDG", "Targeted projection [SLC, MDG, GEC or GTC] (No multilooking if SLC)") ;
    setStringValForKeyIn(paramList, "UTM", "Geographical coordinate system [UTM/GEC] (for GEC or GTC projection) */") ;
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Ground range projection parameters", "") ;
    setStringValForKeyIn(paramList, "**********************************", "") ;
	setStringValForKeyIn(paramList, "10", "Ground range sampling [m]") ;
	setStringValForKeyIn(paramList, "10", "Azimuth sampling [m]") ;
    setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "Geographical projection parameters (GEC)", "") ;
	setStringValForKeyIn(paramList, "**********************************", "") ;
	setStringValForKeyIn(paramList, "0.00027777", "Longitude sampling [dd]") ;
	setStringValForKeyIn(paramList, "0.00027777", "Latitude sampling [dd]") ;
	setStringValForKeyIn(paramList, "0.", "Longitude interpolation radius") ;
	setStringValForKeyIn(paramList, "0.", "Latitude interpolation radius") ;
	setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "UTM projection parameters", "") ;
	setStringValForKeyIn(paramList, "*************************", "") ;
	setStringValForKeyIn(paramList, "20", "Easting sampling [m]") ;
	setStringValForKeyIn(paramList, "20", "Northing sampling [m]") ;
	setStringValForKeyIn(paramList, "0.", "Easting interpolation radius [m]") ;
	setStringValForKeyIn(paramList, "0.", "Northing interpolation radius [m]") ;
	setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Resampling parameters", "") ;
    setStringValForKeyIn(paramList, "*********************", "") ;
    setStringValForKeyIn(paramList, "TRI", "Resampling method : TRI = Triangulation; AV = weighted average; NN = nearest neighbour") ;
    setStringValForKeyIn(paramList, "ID", "Weighting method : ID = inverse distance; LORENTZ = lorentzian") ;
    setStringValForKeyIn(paramList, "1.0", "ID smoothing factor") ;
    setStringValForKeyIn(paramList, "1.0", "ID weighting exponent") ;
    setStringValForKeyIn(paramList, "1.0", "FWHM : Lorentzian Full Width at Half Maximum") ;
    setStringValForKeyIn(paramList, "", "") ;
    
    writeParameterFileAtPath(paramList, (char *)aPath) ;
    
    exit(0) ;
}

void SLC2MDG(keyValue *paramList)
{
    char *requestedProjection, *requestedCoordinateSystem, outputSLCFileName[_MAX_PATH_LENGTH_] ;
    char *outputMLDataFilePath, *outputTextFilePath, *aPath ;
    char *outputGenericFileName ;
    char exportKML ;
    int layerIndex ;
    int xTileIndex, yTileIndex ;
    tileTool *inputDataTile ;
    MLStruct *ml ;
    rawFileDescriptor *outputCalFile ;
    CSLImage *inputImage ;
    calibrationParams *cal ;
    geoRef *gR ;
    geoProj *gP ;
    progressCounter *aCounter ;
    gridMap *slant2GroundGrid = NULL ;
    gridMap *DEMGrid = NULL ;
   
    /* Read requested projection and generate output file name */
    requestedProjection = getStringValForKeyIn(paramList, "Targeted") ;
    requestedCoordinateSystem = getStringValForKeyIn(paramList, "Geographical coordinate system") ;
    outputGenericFileName = initStringWith2Strings(requestedProjection, "Data.") ;
    
    /* Initialize calibration tool */
    inputImage = getCSLImageStructureAtPath(getStringValForKeyIn(paramList, "Input")) ;
    cal = initCalibrationParameters(inputImage, paramList) ;
    
    printf("Calibration and geoprojection of image: %s\n", inputImage->imageDirectoryPath) ;
    printf("Requested projection: %s\n", requestedProjection) ;
    exportKML = 0 ;
    if (isSubStringPresentInString(requestedProjection, "GEC") || isSubStringPresentInString(requestedProjection, "GTC")) {
        printf("Requested geographical coordinate system: %s\n", requestedCoordinateSystem) ;
        exportKML = isSubStringPresentInString(requestedCoordinateSystem, "GEC") ;
    }
    
    printf("\nCalibration initialization\n") ;
    /* Initialize incidence angle grid */
    cal->incidenceAngleGridMap = allocAndInitIncidenceAngleGridMap(cal->SLCInfo) ;
    
    printf("Multi-looking initialization\n") ;
    /* Allocate and init multilooking tool */
    ml  = allocMLStruct() ;
    transferProcessingValuesToMLStructure(cal, ml) ;
    initMLTileTools(ml, cal->dataLayer[0]) ;
    initMLTemporaryDataFileAtPath(ml, inputImage->dataDirectoryPath) ;
    initMultilooking(ml) ;
    
    printf("Georeferencing initialization\n") ;
    /* Allocate and init georeferencing structure */
    gR = allocAndInitGeoReferencingForInputImage(inputImage, cal->SLCInfo, ml) ;
    
    /* If MDG, compute slant to ground transformation grid */
    if (!strncmp(requestedProjection, "MDG", 3)) {
        slant2GroundGrid = computeGroundRangeReferencingGrid(gR) ;
    }
    
    /* If requested coordinate system is UTM, state it within the georeferencing structure */
    if (!strncmp(requestedProjection, "GEC", 3) || !strncmp(requestedProjection, "GTC", 3))
        gR->params->isUTM = isSubStringPresentInString(requestedCoordinateSystem, "UTM") ;
    
    /* If GTC, compute DEM grid */
    if (!strncmp(requestedProjection, "GTC", 3)) {
        DEMGrid = allocAndInitDEMGridForImage(inputImage) ;
        /* And transfer inverse additionnal transform to georeferencing structure in order to reference SLC image with external DEM */
        if (DEMGrid->T != NULL) {
            gR->params->affineTransform = inversePlaneAffineTransform(DEMGrid->T, NULL) ;
            freeMatrixDouble(DEMGrid->T, 0, 0) ;
            DEMGrid->T = NULL ;
        }
        aPath = initStringWith2Strings(inputImage->dataDirectoryPath, "/externalDEM") ;
        gR->files->DEM = openRawFileForReadingAndWritingAtPath(aPath) ;
        free(aPath) ;
   }
    
    printf("Geoprojection initialization\n") ;
    /* Allocate and initialize geoprojection */
    gP = allocAndInitGeoprojection(paramList, cal->SLCInfo, gR) ;
    
    /* Loop on layers */
    for (layerIndex = 0; layerIndex < cal->NLayers; layerIndex++) {
        outputMLDataFilePath = initStringWith3Strings(cal->dataLayer[layerIndex]->directoryPath, outputGenericFileName, cal->polMode->stringVal[layerIndex]) ;
        printf("\nData layer %d\n", layerIndex + 1) ;
        /* Initialize elevation antenna pattern grid if needed */
        cal->currentLayer = layerIndex ;
        cal->antennaPatternGridMap = allocAndInitAntennaPatternGridMapForLayer(layerIndex, cal) ;

        /* Associate input image with a tile tool */
        inputDataTile = allocTileToolForFilesOfType(cal->dataLayer[layerIndex], NULL, "complexFloat") ;
        initTileToolWithSizes(inputDataTile, cal->rangeTileSize, cal->azimuthTileSize, cal->rangeTileBorder, cal->azimuthTileBorder) ;
        
        /* If calibrating SLC data without specific projection, prepare output file */
        if (!cal->NLooks) {
            sprintf(outputSLCFileName, "%s.calibrated", cal->dataLayer[layerIndex]->accessPath) ;
            outputCalFile = openRawFileForWritingAtPath(outputSLCFileName) ;
        }
        
        
        if(!layerIndex)
            printf("\tCalibration, multilooking and referencing: ") ;
        else
            printf("\tCalibration and multilooking: ") ;
        
        /* Loop on input tiles */
        aCounter = initProgressCounterWithMinMaxValue(0, inputDataTile->xTileNumber * inputDataTile->yTileNumber) ;
        for (yTileIndex = 0; yTileIndex < inputDataTile->yTileNumber; yTileIndex++) {
            for (xTileIndex = 0; xTileIndex < inputDataTile->xTileNumber; xTileIndex++) {
                cleanAllTiles(inputDataTile, ml) ;
                readTileAtIndexes(inputDataTile, xTileIndex, yTileIndex) ;
                
                rangeSpreadingLossCompensation(inputDataTile, cal) ;
                incidenceAngleCompensation(inputDataTile, cal) ;
                antennaPatternCorrection(inputDataTile, cal) ;
                absoluteCalibration(inputDataTile, cal) ;
                
                if (cal->NLooks) {
                    multilooking(inputDataTile, ml) ;
                    
                    /* We consider that all layers are coregistered. So only one referencing is required */
                    if (!layerIndex) {
                        /* Select referencing */
                        if (!strncmp(requestedProjection, "MDG", 3)) {
                            groundRangeReferencingOfTile(ml->detectedMultilookedImage, gR, slant2GroundGrid) ;
                        }
                        if (!strncmp(requestedProjection, "GEC", 3)) {
                            georeferencingOfTile(ml->detectedMultilookedImage, gR, NULL ) ;
                        }
                        if (!strncmp(requestedProjection, "GTC", 3)) {
                            georeferencingOfTile(ml->detectedMultilookedImage, gR, DEMGrid ) ;
                        }
                        
                   }
                }
                else {
                    writeTileToOutputFile(inputDataTile, outputCalFile) ;
                }
                updatePointProgressCounterForIndex(aCounter, xTileIndex + yTileIndex * inputDataTile->xTileNumber) ;
            }
        }
        updatePointProgressCounterForIndex(aCounter, xTileIndex + yTileIndex * inputDataTile->xTileNumber) ;

        /* Projection take place here */
        if (cal->NLooks) {
            gR->params->xAverageSampling /= ml->detectedMultilookedImage->xTileNumber * ml->detectedMultilookedImage->yTileNumber ;
            gR->params->yAverageSampling /= ml->detectedMultilookedImage->xTileNumber * ml->detectedMultilookedImage->yTileNumber ;
            updateGeoProjParameters(gP, paramList, cal->SLCInfo, gR) ;
            outputTextFilePath = accessPathToTextFileAndUpdateOutputFilePath(gP, paramList, cal, layerIndex) ;

            projectionOfLayer(gP, layerIndex, cal->NLayers) ;
            
            writeParameterFileAtPath(paramList, outputTextFilePath) ;
            if (exportKML) {
                kmlBasicExport(outputTextFilePath, gP) ;
                exportKML = 0 ;
            }
            freeRawFileDescriptor(gP->files->output) ;
            gP->files->output = NULL ;
            free(outputTextFilePath) ;
        }
        
        if (!cal->NLooks) {
            freeRawFileDescriptor(outputCalFile) ;
        }
        freeTileTool(inputDataTile) ;
        freeGridMap(cal->antennaPatternGridMap) ;
    }
    
    /* If GTC, we will still reproject the external DEM */
    if (DEMGrid != NULL) {
        printf("DEM reprojection\n") ;
        freeRawFileDescriptor(gP->files->input) ;
        gP->files->input = openRawFileForReadingAndWritingAtPath(gP->files->DEM->accessPath) ;
        gP->files->input->xDim = gP->files->DEM->xDim ;
        gP->files->input->yDim = gP->files->DEM->yDim ;
        aPath = initStringWith2Strings(gP->files->DEM->directoryPath, "reprojectedDEM") ;
        gP->files->output = openRawFileForWritingAtPath(aPath) ;
        free(aPath) ;
        projectionOfLayer(gP, layerIndex, 1) ;
        unlink(gP->files->input->accessPath) ;
    }
    
    freeGridMap(cal->incidenceAngleGridMap) ;
    freeGridMap(slant2GroundGrid) ;
    freeGridMap(DEMGrid) ;
    freeCalibrationStructure(cal) ;
    freeCSLImageStructure(inputImage) ;
    unlinkS2GTemporaryFiles(gR) ;
    unlinkMapping(gP) ;
    freeGeoProj(gP) ;
    freeGeoRef(gR) ;
}



void rangeSpreadingLossCompensation(tileTool *inputData, calibrationParams *cal)
{
    int iX, iY, xImage, yImage ;
    double rangeFactor, slantRange ;
    complexFloat **data ;
    
    /* If normalization was performed or if no range spreading loss compensation was applied, correct data */
    if (cal->isRangeNormalizationDone || !cal->isRangeSpreadingLossCompensationDone) {
        data = (complexFloat **)inputData->tile ;

        /* Initialaze slant range to the tile start */
        slantRange = cal->minimumSlantRange + inputData->x0In * cal->rangeSampling ;
        
        /* Loop on range position */
        for (iX = 0; iX < inputData->xTileSize; iX++) {
            xImage = inputData->x0In + iX ;
            
            /* Loop on azimuth position */
            for (iY = 0; iY < inputData->yTileSize; iY++) {
                yImage = inputData->y0In + iY ;
                rangeFactor = 1.0 ;
                
                /* If range spreading loss compensation is not done, compute it */
                if (!cal->isRangeSpreadingLossCompensationDone) {
                    rangeFactor = pow(slantRange , 3) ;
                }
                
                /* Add reference range compensation if needed */
                if (cal->isRangeNormalizationDone) {
                    rangeFactor *= pow(cal->referenceRange, 2 * cal->rangeExponent) ;
                }
                
                /* Rem: Calibration is done on complex values of SLC data, so the square root of the corrections required for power values */
                rangeFactor = sqrt(rangeFactor) ;
                data[iY][iX] = mRC(data[iY][iX], rangeFactor) ;
            }
            slantRange += cal->rangeSampling ;
        }
    }
}

void incidenceAngleCompensation(tileTool *inputData, calibrationParams *cal)
{
    int iX, iY, xImage, yImage ;
    double incidenceAngleFactor ;
    complexFloat **data ;
    
    /* If normalization was performed or if no angular compensation was applied, correct data */
    if (cal->isIncidenceAngleNormalizationDone || !cal->isIncidenceAngleCompensationDone) {
        data = (complexFloat **)inputData->tile ;
        
        /* Loop on range position */
        for (iX = 0; iX < inputData->xTileSize; iX++) {
            xImage = inputData->x0In + iX ;
            
            /* Loop on azimuth position */
            for (iY = 0; iY < inputData->yTileSize; iY++) {
                yImage = inputData->y0In + iY ;
                incidenceAngleFactor = 1. ;
                
                /* If incidence angle compensation is not done, compute it */
                if (!cal->isIncidenceAngleCompensationDone) {
                    incidenceAngleFactor *= sin(PI/180 * interpolGridForImagePosition(cal->incidenceAngleGridMap, xImage, yImage)) ;
                }
                
                /* Add reference angle compensation if needed */
                if (cal->isIncidenceAngleNormalizationDone) {
                    incidenceAngleFactor *= sin(PI/180 * cal->referenceIncidenceAngle) ;
                }
                
                /* Rem: Calibration is done on complex values of SLC data, so the square root of the corrections required for power values */
                incidenceAngleFactor = sqrt(incidenceAngleFactor) ;
                data[iY][iX] = mRC(data[iY][iX], incidenceAngleFactor) ;
            }
        }
    }
}    

void antennaPatternCorrection(tileTool *inputData, calibrationParams *cal)
{
    int iX, iY, xImage, yImage ;
    double antennaPatternCorrectionFactor ;
    complexFloat **data ;
    
    /* If elevation antenna pattern must be corrected for, do it */
    if (cal->rangeAntennaPattern[cal->currentLayer] != NULL) {
        data = (complexFloat **)inputData->tile ;
        
        /* Loop on azimuth position */
        for (iY = 0; iY < inputData->yTileSize; iY++) {
            yImage = inputData->y0In + iY ;

            /* Loop on range position */
            for (iX = 0; iX < inputData->xTileSize; iX++) {
                xImage = inputData->x0In + iX ;
                
                /* Get antenna patter value in db */
                antennaPatternCorrectionFactor = interpolGridForImagePosition(cal->antennaPatternGridMap, xImage, yImage) ;
                
                /* Rem: Calibration is done on complex values of SLC data, so the square root of the corrections required for power values */
                antennaPatternCorrectionFactor = sqrt(1. / pow(10., antennaPatternCorrectionFactor / 10.)) ;
                data[iY][iX] = mRC(data[iY][iX], antennaPatternCorrectionFactor) ;
            }
        }
    }

}

void absoluteCalibration(tileTool *inputData, calibrationParams *cal)
{
    int iX, iY ;
    double globalCalibrationFactor ;
    complexFloat **data ;
    
    data = (complexFloat **)inputData->tile ;
    
    /* Rem: Calibration is done on complex values of SLC data, so the square root of the corrections required for power values */
    globalCalibrationFactor = 1. / (sqrt(cal->calibrationFactor[cal->currentLayer]) * cal->rescalingFactor) ;
    
    /* Loop on azimuth position */
    for (iY = 0; iY < inputData->yTileSize; iY++) {
        /* Loop on range position */
        for (iX = 0; iX < inputData->xTileSize; iX++) {
            data[iY][iX] = mRC(data[iY][iX], globalCalibrationFactor) ;
        }
    }
}

calibrationParams *initCalibrationParameters(CSLImage *inputImage, keyValue *paramList)
{
    char *aPath, *aKey, *polMode, *elevationAntennaPatternFilePath ;
    int layerIndex, iX ;
    calibrationParams *cal ;
    keyValue *calibrationPList ;
    rawFileDescriptor *eapFile ;

    if((cal = malloc(sizeof(calibrationParams))) == NULL)
        ase("Failed to allocate calibration parameters") ;
    
    /* Read image info associated to the SLC images within the CSL format image container */
    aPath = initStringWith2Strings(inputImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
    cal->SLCInfo = readInfoImageFromTextFile(aPath) ;
    free(aPath) ;
    
    /* Define tile size values */
    /* We need power of 2 sizes because of zooming in range and because of multilooking in azimuth */
    cal->rangeTileSize = ceil2ofIntVal(RANGE_TILE_SIZE) ;
    cal->rangeTileBorder = RANGE_TILE_BORDER ;
    cal->rangeTileSize = (cal->rangeTileSize > cal->SLCInfo->rangeDimension)? ceil2ofIntVal(cal->SLCInfo->rangeDimension  + 2 * cal->rangeTileBorder) : cal->rangeTileSize ;
    cal->azimuthTileSize = ceil2ofIntVal(AZIMUTH_TILE_SIZE) ;
    cal->azimuthTileBorder = AZIMUTH_TILE_BORDER ;
    cal->azimuthTileSize = (cal->azimuthTileSize > cal->SLCInfo->azimuthDimension)? ceil2ofIntVal(cal->SLCInfo->azimuthDimension + 2 * cal->azimuthTileBorder) : cal->azimuthTileSize ;
    
    /* Read calibration parameters associated to the SLC images within the CSL format image container */
    aPath = initStringWith2Strings(inputImage->infoDirectoryPath, "/SLCCalibrationInfo.txt") ;
    calibrationPList = readParameterFileAtPath(aPath) ;
    free(aPath) ;
    
    /* Read applied Hamming factor */
    cal->hammingFactor = getDoubleValForKeyIn(calibrationPList, "Azimuth Hamming window coefficient") ;
    
    /* Read requested number of looks */
    cal->NLooks = getIntValForKeyIn(paramList, "Number of looks") ;
    
    /* Read box averaging values */
    cal->xBoxAveragingSize = getIntValForKeyIn(paramList, "X box") ;
    cal->yBoxAveragingSize = getIntValForKeyIn(paramList, "Y box") ;
    
    /* In case of box averaging in place of multilooking, tile border sizes must be recalculated to fit with the box averaging size */
    if (cal->NLooks == 1) {
        cal->rangeTileBorder = (cal->rangeTileSize - cal->xBoxAveragingSize * 2 * ((cal->rangeTileSize - 2 * cal->rangeTileBorder) / (2 * cal->xBoxAveragingSize)))/ 2 ;
        cal->azimuthTileBorder = (cal->azimuthTileSize - cal->yBoxAveragingSize * 2 * ((cal->azimuthTileSize - 2 * cal->azimuthTileBorder) / (2 * cal->yBoxAveragingSize))) / 2 ;
    }

    /* Read backscattering coefficient scale */
    cal->isDetectionInDB = (strncmp(getStringValForKeyIn(paramList, "Backscattering coefficient scale"), "db", 2) == 0) ;

    /* Read the number of SLC layers to be handled (Number of polaization channels) */ 
    cal->NLayers = getIntValForKeyIn(calibrationPList, "Number of data layers") ;
    cal->polMode = readCSVInString(cal->SLCInfo->polMode) ;
    if (!cal->NLayers) {
        cal->NLayers = cal->polMode->numberOfEntries ;
    }
    
    /* Initialize range correction values */
    cal->isRangeSpreadingLossCompensationDone = !strncmp(getStringValForKeyIn(calibrationPList, "Is range spreading loss correction performed?"), "YES", 3) ;
    cal->isRangeNormalizationDone = !strncmp(getStringValForKeyIn(calibrationPList, "Is range spreading loss normalization performed?"), "YES", 3) ;
    cal->minimumSlantRange = cal->SLCInfo->slantRange[0] ;
    cal->rangeSampling = cal->SLCInfo->rangeResolutionCell ;
    cal->referenceRange = 1 ;
    if (cal->isRangeNormalizationDone) {
        cal->referenceRange = getDoubleValForKeyIn(calibrationPList, "Reference slant range") ;
    }
    cal->rangeExponent = getDoubleValForKeyIn(calibrationPList, "Reference slant range exponent") ;

    /* Initialize incidence angle correction values */
    cal->referenceIncidenceAngle = 0 ;
    if (!strncmp(getStringValForKeyIn(calibrationPList, "Is incidence angle normalization performed?"), "YES", 3)) {
        cal->referenceIncidenceAngle = getDoubleValForKeyIn(calibrationPList, "Reference incidence angle") ;
    }
    cal->isIncidenceAngleCompensationDone = !strncmp(getStringValForKeyIn(calibrationPList, "Is incidence angle correction performed?"), "YES", 3) ;
    cal->isIncidenceAngleNormalizationDone = !strncmp(getStringValForKeyIn(calibrationPList, "Is incidence angle normalization performed?"), "YES", 3) ;
    
    /* Initialize rescaling factor */
    cal->rescalingFactor = getDoubleValForKeyIn(calibrationPList, "Rescaling factor") ;
    
    /* Allocate vector of range antenna pattern vectors */
    if((cal->rangeAntennaPattern = malloc(sizeof(double *) * cal->NLayers)) == NULL)
        ase("Failed to allocate range antenna pattern") ;
    
    /* Allocate others vectors */
    cal->NSamples = vectorInt(0, cal->NLayers) ;
    cal->beamOffNadirAngle = vectorDouble(0, cal->NLayers) ;
    cal->angularOrigin = vectorDouble(0, cal->NLayers) ;
    cal->angularSampling = vectorDouble(0, cal->NLayers) ;
    cal->calibrationFactor = vectorDouble(0, cal->NLayers) ;
    
    /* Allocate vector of data layers */
    if((cal->dataLayer = malloc(cal->NLayers * sizeof(rawFileDescriptor *))) == NULL)
        ase("Failed to allocate input data file pointer") ;
    
    for (layerIndex = 0; layerIndex < cal->NLayers; layerIndex++) {
        /* Open data layer file */
        /* Open SLC channel input file */
        aPath = initStringWith3Strings(inputImage->dataDirectoryPath, "/SLCData.", cal->polMode->stringVal[layerIndex]) ;
        cal->dataLayer[layerIndex] = openRawFileForReadingAtPath(aPath) ;
        cal->dataLayer[layerIndex]->xDim = cal->SLCInfo->rangeDimension ;
        cal->dataLayer[layerIndex]->yDim = cal->SLCInfo->azimuthDimension ;
        
        /* Initialize antenna pattern vector to NULL */
        cal->rangeAntennaPattern[layerIndex] = NULL ;
        
        /* Read polarisation mode for current layer */
        polMode = cal->polMode->stringVal[layerIndex] ;
        
        /* Read flag to know if elevation antenna pattern compensation is performed for current layer */
        aKey = initStringWith3Strings("Is ", polMode, " elevation antenna pattern correction performed?") ;
        if (!strncmp("NO", getStringValForKeyIn(calibrationPList, aKey), 2)) {
            /* If elevation antenna pattern compensation must be performed... */
            /* Read number of availablesamples  */
            free(aKey) ;
            aKey = initStringWith2Strings(polMode, " elevation antenna pattern number of samples") ;
            cal->NSamples[layerIndex] = getIntValForKeyIn(calibrationPList, aKey) ;
            free(aKey) ;

            aKey = initStringWith2Strings(polMode, " elevation antenna pattern file name") ;
            elevationAntennaPatternFilePath = initStringWith3Strings(inputImage->infoDirectoryPath, "/", getStringValForKeyIn(calibrationPList, aKey)) ;
            free(aKey) ;
            eapFile = openRawFileForReadingAtPath(elevationAntennaPatternFilePath) ;
            cal->rangeAntennaPattern[layerIndex] = vectorDouble(0, cal->NSamples[layerIndex] - 1) ;
            for (iX = 0; iX < cal->NSamples[layerIndex]; iX++) {
                fscanf(eapFile->f, "%lf ", &cal->rangeAntennaPattern[layerIndex][iX]) ;
            }
            
            /* Read angular positionning of elevation antenna pattern */
            aKey = initStringWith2Strings(polMode, " beam centre off-nadir angle") ;
            cal->beamOffNadirAngle[layerIndex] = getDoubleValForKeyIn(calibrationPList, aKey) ;
            free(aKey) ;
            aKey = initStringWith2Strings(polMode, " elevation antenna pattern sampling") ;
            cal->angularSampling[layerIndex] = getDoubleValForKeyIn(calibrationPList, aKey) ;
            free(aKey) ;
            aKey = initStringWith2Strings(polMode, " elevation antenna pattern origin") ;
            cal->angularOrigin[layerIndex] = cal->beamOffNadirAngle[layerIndex] + getDoubleValForKeyIn(calibrationPList, aKey) ;
            free(aKey) ;
        }
        /* Read layer calibration factor */
        aKey = initStringWith2Strings(polMode, " calibration constant") ;
        cal->calibrationFactor[layerIndex] = getDoubleValForKeyIn(calibrationPList, aKey) ;
        free(aKey) ;
    }
    
    freeKeyValueList(calibrationPList) ;
    
    return (cal) ;
}

void freeCalibrationStructure(calibrationParams *cal)
{
    int layerIndex ;
    
    freeCSVStruct(cal->polMode) ;
    for (layerIndex = 0; layerIndex < cal->NLayers; layerIndex++) {
        if(cal->rangeAntennaPattern[layerIndex] != NULL)
            freeVectorDouble(cal->rangeAntennaPattern[layerIndex], 0) ;
        freeRawFileDescriptor(cal->dataLayer[layerIndex]) ;
    }
    free(cal->rangeAntennaPattern) ;
    freeVectorInt(cal->NSamples, 0) ;
    freeVectorDouble(cal->beamOffNadirAngle, 0) ;
    freeVectorDouble(cal->angularOrigin, 0) ;
    freeVectorDouble(cal->angularSampling, 0) ;
    freeVectorDouble(cal->calibrationFactor, 0) ;
}

gridMap *allocAndInitIncidenceAngleGridMap(struct infoImage *SLCInfo)
{
    int iX, iY ;
    coord2D imagePoint ;
    gridMap *incidenceAngleGridMap ;
    geoRef	*geo ;
    
    incidenceAngleGridMap = createGridWithXYSpacing(SLCInfo->rangeDimension, SLCInfo->azimuthDimension, SLCInfo->rangeDimension / 100, SLCInfo->azimuthDimension / 100) ;
    
    orbitInterpolation(SLCInfo) ;
    geo = allocAndInitGeorefStructureForTargetEllipsoid(SLCInfo, SLCInfo->ellRef) ;
    
    for (iY = 0; iY < incidenceAngleGridMap->Ny; iY++) {
        for (iX = 0; iX < incidenceAngleGridMap->Nx; iX++) {
            imagePoint = imageCoordinateForGridPoint(incidenceAngleGridMap, iX, iY) ;
            earthRadiusAtPoint(imagePoint.x, imagePoint.y, 0, geo) ;
            incidenceAngleGridMap->val[iX][iY] = 180. / PI * geo->solving->alpha ;
        }
    }
    
        
    return (incidenceAngleGridMap) ;
}


gridMap *allocAndInitAntennaPatternGridMapForLayer(int layerIndex, calibrationParams *cal)
{
    int iX, iY ;
    double *eapValue, elevationAngle ;
    struct divr angularIndex ;
    gridMap *antenaPatternGridMap ;
    SLCImageInfo *SLCInfo ;
    coord2D imagePoint ;
    geoRef	*geo ;
    
    /* Detemine if antenna patterncorrection must be performed */
    if (cal->rangeAntennaPattern[layerIndex] != NULL) {
        /* Initialize elevation antenna pattern grid for layer */
        SLCInfo = cal->SLCInfo ;
        antenaPatternGridMap = createGridWithYSpacing(SLCInfo->rangeDimension, SLCInfo->azimuthDimension, cal->NSamples[layerIndex], SLCInfo->azimuthDimension / 100) ;
                
        /* Initialize elevation antenna pattern grid */
        eapValue = cal->rangeAntennaPattern[layerIndex] ;
        orbitInterpolation(SLCInfo) ;
        geo = allocAndInitGeorefStructureForTargetEllipsoid(SLCInfo, SLCInfo->ellRef) ;
        for (iY = 0; iY < antenaPatternGridMap->Ny; iY++) {
            for (iX = 0; iX < antenaPatternGridMap->Nx; iX++) {
                imagePoint = imageCoordinateForGridPoint(antenaPatternGridMap, iX, iY) ;
                earthRadiusAtPoint(imagePoint.x, imagePoint.y, 0, geo) ;
                elevationAngle = 180 / PI * geo->solving->alpha_at - cal->angularOrigin[layerIndex] ;
                angularIndex = divr(elevationAngle, cal->angularSampling[layerIndex]) ;
                
                antenaPatternGridMap->val[iX][iY] = eapValue[angularIndex.q] + (eapValue[angularIndex.q + 1] - eapValue[angularIndex.q]) * angularIndex.r / cal->angularSampling[layerIndex] ;
            }
            
        }
                
        return (antenaPatternGridMap) ;
    }
    
    return (NULL) ;
}

void transferProcessingValuesToMLStructure(calibrationParams *cal, MLStruct  *ml)
{
    ml->expressInDB = cal->isDetectionInDB ;
    ml->NLooks = cal->NLooks ;
    ml->singleLookRangeTileSize = cal->rangeTileSize ;
    ml->singleLookAzimuthTileSize = cal->azimuthTileSize ;
    ml->singleLookRangeTileBorder = cal->rangeTileBorder ;
    ml->singleLookAzimuthTileBorder = cal->azimuthTileBorder ;
    ml->xBoxAveragingSize = cal->xBoxAveragingSize ;
    ml->yBoxAveragingSize = cal->yBoxAveragingSize ;
    ml->hammingFactor = cal->hammingFactor ;
    ml->SLCInfo = cal->SLCInfo ;
}



geoRef *allocAndInitGeoReferencingForInputImage(CSLImage *inputImage, SLCImageInfo *info, MLStruct *multiLooking) {
    char *aPath ;
    geoRef *gR ;
    
    /* Allocate and init georeferencing structure */
    orbitInterpolation(info) ;
    gR = allocAndInitGeorefStructureForTargetEllipsoid(info, info->ellRef) ;
    
    /* Create temporary referencing files for writing */
    aPath = initStringWith2Strings(inputImage->dataDirectoryPath, "/xRef") ;
    gR->files->xRef = openRawFileForReadingAndWritingAtPath(aPath) ;
    free(aPath) ;
    aPath = initStringWith2Strings(inputImage->dataDirectoryPath, "/yRef") ;
    gR->files->yRef = openRawFileForReadingAndWritingAtPath(aPath) ;
    free(aPath) ;
    
    /* Set scaling factor into geoRef Structure */
    gR->params->xReductionFactor = multiLooking->rangeScalingFactor ;
    gR->params->yReductionFactor = multiLooking->azimuthScalingFactor ;
    
    /* Set temporary output data file parameters */
    gR->files->input = multiLooking->mlData ;
    
    return (gR) ;
}



geoProj *allocAndInitGeoprojection(keyValue *paramList, SLCImageInfo *SLCInfo, geoRef *gR)
{
    char *aPath ;
    geoProj *gP ;
    
    gP = allocGeoProj() ;
    
	sprintf(gP->params->resamplingMethod, "%s", getStringValForKeyIn(paramList, "Resampling method")) ;
	sprintf(gP->params->weightingMethod, "%s",  getStringValForKeyIn(paramList, "Weighting method")) ;
	gP->params->smoothingFactor = getDoubleValForKeyIn(paramList, "ID smoothing factor") ;
	gP->params->exponent = getDoubleValForKeyIn(paramList, "ID weighting exponent") ;
	gP->params->FWHM = getDoubleValForKeyIn(paramList, "FWHM") ;
    gP->params->DEMExcludingValue = -9999 ;

    gP->files->input = openRawFileForReadingAtPath(gR->files->input->accessPath) ;
    gP->files->input->xDim = gR->files->input->xDim ;
    gP->files->input->yDim = gR->files->input->yDim ;
    gP->files->xRef = openRawFileForReadingAtPath(gR->files->xRef->accessPath) ;
    gP->files->xRef->xDim = gR->files->input->xDim ;
    gP->files->xRef->yDim = gR->files->input->yDim ;
    gP->files->yRef = openRawFileForReadingAtPath(gR->files->yRef->accessPath) ;
    gP->files->yRef->xDim = gR->files->input->xDim ;
    gP->files->yRef->yDim = gR->files->input->yDim ;
    
    if (gR->files->DEM != NULL) {
        gP->files->DEM = openRawFileForReadingAtPath(gR->files->DEM->accessPath) ;
        gP->files->DEM->xDim = gR->files->input->xDim ;
        gP->files->DEM->yDim = gR->files->input->yDim ;
    }
    
    gP->params->isUTM = gR->params->isUTM ;
        
    aPath = initStringWith2Strings(gP->files->input->directoryPath, "/projMat") ;
    if((gP->files->M = openRawFileForReadingAndWritingAtPath(aPath)) == NULL)
        ase("Failed to open/create Projection matrix file\n") ;
        
    return(gP) ;
}

void updateGeoProjParameters(geoProj *gP, keyValue *paramList, SLCImageInfo *SLCInfo, geoRef *gR)
{
    char *requestedProjection ;
    double medianLatitude ;
    
    gP->frame->xMax = gR->frame->xMax ;
    gP->frame->xMin = gR->frame->xMin ;
    gP->frame->yMax = gR->frame->yMax ;
    gP->frame->yMin = gR->frame->yMin ;
    medianLatitude = (gP->frame->yMax + gP->frame->yMin) / 2. ;
    
    requestedProjection = getStringValForKeyIn(paramList, "Targeted projection") ;
    if (!strncmp(requestedProjection, "GEC", 3) || !strncmp(requestedProjection, "GTC", 3)) {
        gP->params->isUTM = !strncmp(getStringValForKeyIn(paramList, "Geographical coordinate system"), "UTM", 3) ;
        if(gP->params->isUTM) {
            gP->params->xSampling = getDoubleValForKeyIn(paramList, "Easting sampling") ;
            gP->params->ySampling = getDoubleValForKeyIn(paramList, "Northing sampling") ;
            if(!(gP->params->xRadius = getDoubleValForKeyIn(paramList, "Easting interpolation radius"))) {
                if (!strncmp(requestedProjection, "GEC", 3)) {
                    gP->params->xRadius = 2. * SLCInfo->rangeResolutionCell * gR->params->xReductionFactor / sin(PI/180. * SLCInfo->incidenceAngle[1]) ;
                }
                else
                    gP->params->xRadius = 2. * gR->params->xAverageSampling ;
                setDoubleValForKeyIn(paramList, gP->params->xRadius, "Easting interpolation radius") ;
            }
            if(!(gP->params->yRadius = getDoubleValForKeyIn(paramList, "Northing interpolation radius"))) {
                if (!strncmp(requestedProjection, "GEC", 3)) {
                    gP->params->yRadius = 2. * SLCInfo->azimuthResolutionCell * gR->params->yReductionFactor ;
                }
                else
                    gP->params->yRadius = 2. * gR->params->yAverageSampling ;
                setDoubleValForKeyIn(paramList, gP->params->yRadius, "Northing interpolation radius") ;
            }
        }
        else {
            gP->params->xSampling = getDoubleValForKeyIn(paramList, "Longitude sampling") ;
            gP->params->ySampling = getDoubleValForKeyIn(paramList, "Latitude sampling") ;
            if(!(gP->params->xRadius = getDoubleValForKeyIn(paramList, "Longitude interpolation radius"))) {
                if (!strncmp(requestedProjection, "GEC", 3)) {
                    gP->params->xRadius = 2. * SLCInfo->rangeResolutionCell * gR->params->xReductionFactor / sin(PI/180. * SLCInfo->incidenceAngle[1]) * cos(medianLatitude) / SLCInfo->EarthRadiusAtSceneCenter * 180. / PI ;
                }
                else
                    gP->params->xRadius = 2. * gR->params->xAverageSampling ;
                setDoubleValForKeyIn(paramList, gP->params->xRadius, "Longitude interpolation radius") ;
            }
            if(!(gP->params->yRadius = getDoubleValForKeyIn(paramList, "Latitude interpolation radius"))) {
                if (!strncmp(requestedProjection, "GEC", 3)) {
                    gP->params->yRadius = 2. * SLCInfo->azimuthResolutionCell * gR->params->yReductionFactor / SLCInfo->EarthRadiusAtSceneCenter * 180. / PI  ;
                }
                else
                    gP->params->yRadius = 2. * gR->params->yAverageSampling ;
                setDoubleValForKeyIn(paramList, gP->params->yRadius, "Latitude interpolation radius") ;
            }
        }
        
    }
    else {
        if (!strncmp(requestedProjection, "MDG", 3)) {
            gP->params->xSampling = getDoubleValForKeyIn(paramList, "Ground range sampling") ;
            gP->params->ySampling = getDoubleValForKeyIn(paramList, "Azimuth sampling") ;
            gP->params->xRadius = 2. * SLCInfo->rangeResolutionCell * gR->params->xReductionFactor / sin(PI/180. * SLCInfo->incidenceAngle[1]) ;
            gP->params->yRadius = 2. * SLCInfo->azimuthResolutionCell * gR->params->yReductionFactor ;
        }
    }
	gP->params->xDimM = (gP->frame->xMax - gP->frame->xMin) / gP->params->xSampling + 1 ;
	gP->params->yDimM = (gP->frame->yMax - gP->frame->yMin) / gP->params->ySampling + 1 ;
	
    roundGeoProjFrame(gP) ;
    setStringValForKeyIn(paramList, "Geoprojection frame", "") ;
    setStringValForKeyIn(paramList, "*******************", "") ;
    setDoubleValForKeyIn(paramList, gP->frame->xMin, "xMin") ;
    setDoubleValForKeyIn(paramList, gP->frame->xMax, "xMax") ;
    setDoubleValForKeyIn(paramList, gP->frame->yMin, "yMin") ;
    setDoubleValForKeyIn(paramList, gP->frame->yMax, "yMax") ;	
    setStringValForKeyIn(paramList, "", "") ;
    setIntValForKeyIn(paramList, gP->params->xDimM, "X size of geoprojected products [pix]") ;
    setIntValForKeyIn(paramList, gP->params->yDimM, "Y size of geoprojected products [pix]") ;

	if(gR->params->isUTM) {
		printf("\n UTM zone: %d%s", gR->params->UTMZone->indiceZoneLonUTM, gR->params->UTMZone->zoneLatUTM) ;
		sprintf(aComment, "%2d %s", gR->params->UTMZone->indiceZoneLonUTM, gR->params->UTMZone->zoneLatUTM) ;
		setStringValForKeyIn(paramList, aComment, "UTM zone") ;
	}
}

char *accessPathToTextFileAndUpdateOutputFilePath(geoProj *gP, keyValue *paramList, calibrationParams *cal, int layerIndex)
{
    char *aPath, *textFileAccessPath ;
    char isDefaultPathRequested ;
    char *outputGenericFileName ;
    
    isDefaultPathRequested = (strncmp(getStringValForKeyIn(paramList, "Output"), "Default", 7) == 0) ;
    if (isDefaultPathRequested) {
        outputGenericFileName = initStringWith2Strings(getStringValForKeyIn(paramList, "Targeted"), "Data.") ;
        aPath = initStringWith3Strings(cal->dataLayer[layerIndex]->directoryPath, outputGenericFileName, cal->polMode->stringVal[layerIndex]) ;
        textFileAccessPath = initStringWith2Strings(aPath, ".txt") ;
        replaceSubStringInString(textFileAccessPath, "Data", "info") ;
    }
    else {
        aPath = initStringWithString(getStringValForKeyIn(paramList, "Output")) ;
        textFileAccessPath = initStringWith2Strings(aPath, ".txt") ;
    }
    gP->files->output = openRawFileForWritingAtPath(aPath) ;

    return textFileAccessPath ;
}

void projectionOfLayer(geoProj *gP, int layerIndex, int Nlayers)
{
	struct lmp *table ;

    if (layerIndex == 0) {
        printf("\n\nGeoprojection map computation:") ;
        findInterveningPoints(gP) ;
		table = allocProjectionTable(gP) ;
		weightCalculation(table, gP) ;
        if (Nlayers > 0) {
            saveProjectionTable(table, gP) ;
        }
		resampling(table, gP) ;
    }
    else {
        resamplingUsingSavedMapping(gP) ;
    }
}

void unlinkMapping(geoProj *gP)
{
    char *aPath ;
    
    aPath = initStringWithString(gP->files->input->accessPath) ;
    freeRawFileDescriptor(gP->files->input) ;
    gP->files->input = NULL ;
    unlink(aPath) ;
    free(aPath) ;
    
    aPath = initStringWithString(gP->files->M->accessPath) ;
    freeRawFileDescriptor(gP->files->M) ;
    gP->files->M = NULL ;
    unlink(aPath) ;
    free(aPath) ;
}


void kmlBasicExport(char *aPath, geoProj *gP)
{
    char *kmlFilePath ;
    rawFileDescriptor *kmlFile ;
    
    kmlFilePath = initStringWithString(aPath) ;
    stripExtensionAtEndOfPath(kmlFilePath) ;
    stripExtensionAtEndOfPath(kmlFilePath) ;
    kmlFilePath = addExtensionAtEndOfPath(kmlFilePath, ".kml") ;
    kmlFile = openRawFileForWritingAtPath(kmlFilePath) ;
    
    fprintf(kmlFile->f, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n") ;
    fprintf(kmlFile->f, "<kml>\n<name>GECData.kml</name>\n<Document>\n<Placemark>\n<name>Frame</name>\n") ;
    fprintf(kmlFile->f, "<Polygon>\n<outerBoundaryIs>\n<LinearRing>\n") ;
    fprintf(kmlFile->f, "<coordinates>") ;
    fprintf(kmlFile->f, "%lf,%lf,0.\n",gP->frame->xMin,gP->frame->yMin) ;
    fprintf(kmlFile->f, "%lf,%lf,0.\n",gP->frame->xMax,gP->frame->yMin) ;
    fprintf(kmlFile->f, "%lf,%lf,0.\n",gP->frame->xMax,gP->frame->yMax) ;
    fprintf(kmlFile->f, "%lf,%lf,0.\n",gP->frame->xMin,gP->frame->yMax) ;
    fprintf(kmlFile->f, "%lf,%lf,0.\n",gP->frame->xMin,gP->frame->yMin) ;
    fprintf(kmlFile->f, "</coordinates>") ;
    fprintf(kmlFile->f, "</LinearRing>\n</outerBoundaryIs>\n</Polygon>\n") ;
    fprintf(kmlFile->f, "</Placemark>\n</Document>\n</kml>\n") ;
    
    free(kmlFilePath) ;
    freeRawFileDescriptor(kmlFile) ;
}

gridMap *allocAndInitDEMGridForImage(CSLImage *anImage)
{
    char *aPath ;
    int dimGridX, dimGridY, Nx, Ny, dNx, dNy, iX, iY ;
    float *aDEMLine ;
    double **T ;
    keyValue *slantRangeDEMParams ;
    gridMap *DEMGrid ;
    rawFileDescriptor *DEMFile ;
    
    /* Verify that a slant range DEM file is available at predefined location */
    aPath = initStringWith2Strings(anImage->dataDirectoryPath, "/slantRangeDEM") ;
    if (!fileExistsAtPath(aPath)) {
        ase("No slant range DEM available. Please run slantRangeDEM first\n") ;
    }
    DEMFile = openRawFileForReadingAtPath(aPath) ;
    free(aPath) ;

    /* Verify that a slant range DEM description file is available at predefined location */
    aPath = initStringWith2Strings(anImage->infoDirectoryPath, "/slantRangeDEM.txt") ;
    if (!fileExistsAtPath(aPath)) {
        ase("No slant range DEM Description file available. Please run slantRangeDEM first\n") ;
    }
    
    /* Read description file */
    slantRangeDEMParams = readParameterFileAtPath(aPath) ;
    free(aPath) ;
    
    /* Read necessary file parameters */
    dimGridX = getIntValForKeyIn(slantRangeDEMParams, "xMax") - getIntValForKeyIn(slantRangeDEMParams, "xMin") + 1 ;
    dimGridY = getIntValForKeyIn(slantRangeDEMParams, "yMax") - getIntValForKeyIn(slantRangeDEMParams, "yMin") + 1 ;
    Nx = getIntValForKeyIn(slantRangeDEMParams, "X size of projected products") ;
    Ny = getIntValForKeyIn(slantRangeDEMParams, "Y size of projected products") ;
    dNx = getIntValForKeyIn(slantRangeDEMParams, "X sampling of projected product") ;
    dNy = getIntValForKeyIn(slantRangeDEMParams, "Y sampling of projected product") ;
    
    /* init Grid */
    DEMGrid = createFloatGridOfSize(Nx, Ny, dNx, dNy) ;
    DEMGrid->x0 = getDoubleValForKeyIn(slantRangeDEMParams, "xMin") ;
    DEMGrid->y0 = getDoubleValForKeyIn(slantRangeDEMParams, "yMin") ;
    
    /* Transfer DEM values to grid */
    /* Yes, I know it's stupid, but grid values are transposed with respect to saved slant range DEM... */
    aDEMLine = vectorFloat(0, Nx - 1) ;
    for (iY = 0; iY < Ny; iY++) {
        if ((fread(aDEMLine, sizeof(float), Nx, DEMFile->f)) != Nx)
            ase("Failed to read external DEM") ;
        for (iX = 0; iX < Nx; iX++) {
            DEMGrid->floatVal[iX][iY] = aDEMLine[iX] ;
        }
    }
    freeVectorFloat(aDEMLine, 0) ;
    
    /* If there is an additionnal affine transform, store it within the grid */
    T = matrixDouble(0, 2, 0, 2) ;
    T[0][0] = getDoubleValForKeyIn(slantRangeDEMParams, "Ax") ;
    T[0][1] = getDoubleValForKeyIn(slantRangeDEMParams, "Bx") ;
    T[0][2] = getDoubleValForKeyIn(slantRangeDEMParams, "Cx") ;
    T[1][0] = getDoubleValForKeyIn(slantRangeDEMParams, "Ay") ;
    T[1][1] = getDoubleValForKeyIn(slantRangeDEMParams, "By") ;
    T[1][2] = getDoubleValForKeyIn(slantRangeDEMParams, "Cy") ;
    if (isAffineTransformUnitary(T) || isAffineTransformNULL(T)) {
        freeMatrixDouble(T, 0, 0) ;
    }
    else {
        DEMGrid->T = T ;
    }
    
    freeRawFileDescriptor(DEMFile) ;
    
    return (DEMGrid) ;
}
