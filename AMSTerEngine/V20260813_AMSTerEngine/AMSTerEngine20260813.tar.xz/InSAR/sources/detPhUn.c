
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  detPhUn
//
//  Created by Dominique Derauw on 30/08/12.
//  Copyright (c) 2012 Centre Spatial de Liège. All rights reserved.
//

#include <stdio.h>

#include "detPhUnLib.h"

/* fonctions */
void usage(int hiddenParameters) ;
void createParameterFileAtPath(char *aPath) ;
void phaseToHeight(InSARParametersStruct *pInSAR) ;


/* main programm start */
int main(int argc, const char **argv)
{
    char *aPath = NULL, InSARParametersFileFound ;
	int	currentDirectoryFdesc, i ;
    int xTileSize, yTileSize, xTileBorderSize, yTileBorderSize, numberOfIterations ;
    float originalSmoothingFactor, originalCoherenceThreshold ;
	time_t startTime, endTime ;
    InSARParametersStruct *pInSAR;
	
    if (isArgumentPresent(argc, argv, "hidden")) {
        usage(1) ;
    }
    
    InSARParametersFileFound = 0 ;
	currentDirectoryFdesc = open(".", O_RDONLY) ;
	fchdir(currentDirectoryFdesc) ;
    
    if (isArgumentPresent(argc, argv, "-create")) {
        createParameterFileAtPath((char *)argv[1]) ;
    }
	
	i = 1 ;
	while (i < argc) {
		aPath = initStringWithString((char *)argv[i]) ;
		if(fileExistsAtPath(aPath)) {
			InSARParametersFileFound = 1 ;
			break ;
		}
		i++ ;
		free(aPath) ;
	}
	if(!InSARParametersFileFound) {
		aPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
		if(!fileExistsAtPath(aPath)){
			free(aPath) ;
			aPath = initStringWithString("./InSARParameters.txt") ;
			if(!fileExistsAtPath(aPath))
				usage(0) ;
		}
		InSARParametersFileFound = 1 ;
	}
	time(&startTime) ;
    
	pInSAR = readInSARParametersFileAtPath(aPath) ;
    pInSAR->flag |= (isFlagPresent(argc, argv, "F"))? _CONSIDER_FILTERED_INTERF_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresent(argc, argv, "-r"))? RESIDUAL_PHASE_ONLY : pInSAR->flag ;
    pInSAR->flag |= (!isFlagPresent(argc, argv, "-p"))? _PHASE_TO_MEASUREMENT_CONVERSION_ : pInSAR->flag ;
    pInSAR->flag |= (openFirstPhaseComponentFile(pInSAR))? FIRST_PHASE_COMPONENT_EXISTS : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresent(argc, argv, "f"))? _DETPHUN_WITH_FILTERING_ : pInSAR->flag ;
//    pInSAR->flag |= (isFlagPresent(argc, argv, "-d"))? _COMBINED_FILTERINGS_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresent(argc, argv, "-2"))? _DETPHUN2_ : pInSAR->flag ;

    originalSmoothingFactor = pInSAR->filter.adaptativeFilterSmoothingFactor ;
    if ((i = isArgumentPresent(argc, argv, "f="))) {
        pInSAR->flag |= _DETPHUN_WITH_FILTERING_ ;
        sscanf(argv[i] + 2, "%f", &(pInSAR->filter.adaptativeFilterSmoothingFactor)) ;
    }
    
    originalCoherenceThreshold = pInSAR->conex.seuilnet ;
    if ((i = isArgumentPresent(argc, argv, "t="))) {
        sscanf(argv[i] + 2, "%f", &(pInSAR->conex.seuilnet)) ;
    }
    
    xTileBorderSize = 0 ;
    if ((i = isArgumentPresent(argc, argv, "xTileSize"))) {
        sscanf(argv[i], "xTileSize=%d", &xTileSize) ;
        if ((i = isArgumentPresent(argc, argv, "xTileBorderSize"))) {
            sscanf(argv[i], "xTileBorderSize=%d", &xTileBorderSize) ;
        }
    }
    else {
        xTileSize = pInSAR->interf.lenr ;
    }
    
    yTileBorderSize = 0 ;
    if ((i = isArgumentPresent(argc, argv, "yTileSize"))) {
        sscanf(argv[i], "yTileSize=%d", &yTileSize) ;
        if ((i = isArgumentPresent(argc, argv, "yTileBorderSize"))) {
            sscanf(argv[i], "yTileBorderSize=%d", &yTileBorderSize) ;
        }
    }
    else {
        yTileSize = pInSAR->interf.lena ;
    }
    
    numberOfIterations = 1 ;
    if ((i = isArgumentPresent(argc, argv, "N"))) {
        sscanf(argv[i], "N=%d", &numberOfIterations) ;
    }

    deterministicPhaseUnwrapping(pInSAR, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize, numberOfIterations) ;
    pInSAR->filter.adaptativeFilterSmoothingFactor = originalSmoothingFactor ;
    pInSAR->conex.seuilnet = originalCoherenceThreshold ;
    saveInSARParametersFileAtPath(pInSAR, aPath) ;

    /* If there is a first phase component we add it to the unwrapped phase taking into account the excluding value */
    if (!(pInSAR->flag & RESIDUAL_PHASE_ONLY)) {
        addFirstPhaseComponentToUnWrappedPhase(pInSAR) ;
    }

    /* Convert phase to height if required */
    if(pInSAR->flag & _PHASE_TO_MEASUREMENT_CONVERSION_) {
        printf("\nPhase to height conversion\n");
        phaseToMeasurementConversion(pInSAR) ;
    }

    freeInSARParametersStruct(pInSAR) ;
    free(aPath) ;

	time(&endTime) ;
	duration(startTime, endTime) ;
	return(0) ;
}


void usage(int hiddenParameters)
{
	printf("Usage:\ndetPhUn [/pathTo/inSARParameters.txt] [-Ffdrp2] [N=n] \n") ;
    printf("Deterministic phase unwrapping of the interferogram found in the given InSARPArameters.txt file:\n") ;
    printf("By default, the phase is unwrapped and converted to local heigths.\n") ;
    printf("Options:\n") ;
    printf("-p :\tIssues only the unwrapped phase in radian.\n") ;
    printf("-r :\tThe unwrapped residual phase is issued without adding the first phase component.\n") ;
    printf("\t  Therefore, deformation measurement is considered. Unwrapped phase will be\n\tconverted in meter and saved with name deformationMap.\n") ;
    printf("-F :\tThe filtered interferogram will be unwrapped \n\t(use of -F option is thus also required for both residuesSearch and biasedCoherence processes)\n") ;
    printf("-f :\tFiltering of residual phase component is considered at each iteration of the process.\n") ;
//    printf("-d :\tBoth the classical and the Goldstein filtering are considered.\n") ;
    printf("-2 :\tdetPhUn2 method is considered.\n") ;
    printf("N=n :\tIterative process is considered with \"n\" being the number of iterations.\n") ;
	printf("\nThe routine will look for a parameter text file\nnamed \"inSARParameters.txt\" within the working directory\nor within the ./TextFiles subdirectory\n") ;
	printf("Any other path to a text file containing required parameters \ncan be given as first parameter\n") ;

    if (hiddenParameters) {
        printf("Hidden parameters are: xTileSize=n yTileSize=n xTileBorderSize=n yTileBorderSize=n  N=n\n") ;
    }
	exit(0) ;
}


void createParameterFileAtPath(char *aPath)
{
    keyValue *p ;
    
    p = allocAKeyValuePair() ;
    
    setStringValForKeyIn(p, "Deterministic phase unwrapping parameter file", "") ;
    setStringValForKeyIn(p, "*********************************************", "") ;
    setStringValForKeyIn(p, "pathToInSARParametersFile", "InSAR parameters file path") ;
    setStringValForKeyIn(p, "fullSize", "X window size") ;
    setStringValForKeyIn(p, "fullSize", "Y window size") ;
    setStringValForKeyIn(p, "0", "X border size") ;
    setStringValForKeyIn(p, "0", "Y border size") ;
    setStringValForKeyIn(p, "1", "Number of iterations") ;
    
    writeParameterFileAtPath(p, aPath) ;
    
    exit(0) ;
}


void phaseToHeight(InSARParametersStruct *pInSAR)
{
	int		i, j, dR, dA ;
	float *unwrappedPhase ;
    double rangePosition, azimuthPosition, *P1, *P2 ;
	double h, h0 ;
	double *z1, dz, RT, phiOrb, sign, gamma ;
	geoRefSolving *geoPar ;
	progressCounter *aCounter ;
    
    (pInSAR->srDEM).lenr = (pInSAR->firstPhaseComponent).lenr ;
    (pInSAR->srDEM).lena = (pInSAR->firstPhaseComponent).lena ;
	geoPar = pInSAR->geo->solving ;
    P1 = vectorDouble(0, 1) ;
    P2 = vectorDouble(0, 1) ;
    z1 = vectorDouble(0, (pInSAR->srDEM).lenr) ;
    unwrappedPhase = vectorFloat(0, pInSAR->firstPhaseComponent.lenr - 1) ;
    
    dR = (pInSAR->sup).Sgra ; // + (pInSAR->red).Fra / 2 ;
    dA = (pInSAR->sup).Sbaz ; // + (pInSAR->red).Faz / 2 ;
	/* ------------------ Phase to height conversion ------------------ */
    
    printf("\nPhase to height conversion\n") ;
    
    if(!openFirstPhaseComponentFile(pInSAR))
        ase("Failed to open first phase component file for reading") ;
    if(!openMeasurementFile(pInSAR))
        ase("Failed to open slant range DEM file for writing") ;

	for(j = 0; j < (pInSAR->srDEM).lenr; j++)
		z1[j] = ((pInSAR->ima1).z0 + (j * (pInSAR->red).Fra + dR) * (pInSAR->rad).rangeResolutionCell) ;
	
	aCounter = initProgressCounterWithMinMaxValue(0, (pInSAR->dephi).lena - 1) ;
	for(i = 0; i < (pInSAR->firstPhaseComponent).lena; i++) {
        fread(unwrappedPhase, sizeof(float), (pInSAR->firstPhaseComponent).lenr, pInSAR->firstPhaseComponentFile->f) ;
		azimuthPosition = (double)(i * (pInSAR->red).Faz + dA) ;
		for(j = 0 ; j < (pInSAR->firstPhaseComponent).lenr; j++) {
			rangePosition = (double)(j * (pInSAR->red).Fra  + dR) ;
            P2[0] = rangePosition ;
            P2[1] = azimuthPosition ;
            
            if (pInSAR->masterInterpolation) {
                P1[0] = P2[0] ;
                P1[1] = P2[1] ;
                planeAffineTransformOfPoint(P1, P2, pInSAR->masterAffineTransform) ;
                z1[j] = (pInSAR->ima1).z0 + P2[0] * (pInSAR->rad).rangeResolutionCell ;
            }
            /* Approximate computation: We compute the height considering the ambiguity altitude on flat ground */
            //			h = *ptr_dephi / TWOPI * ambiguityAltitudeAtPoint(P2[0], P2[1],0., pInSAR) ;
            
            /* "Exact" computation */
            RT = earthRadiusAtPoint(P2[0], P2[1], 0., pInSAR->geo) ;
            /* We re-add the removed orbital phase, whatever it is */
            phiOrb = orbitalPhaseAtPoint(P2[0], P2[1], pInSAR) ;
            unwrappedPhase[j] += phiOrb ;
            /* We compute the optical path difference */
            dz = unwrappedPhase[j] / pInSAR->kz0 ;
            
            /* We determine the sign of the angle gamma in triangle z1_B_z2 */
			sign = (fabs(pInSAR->B.theta - pInSAR->geo->solving->alpha_at) < HALFPI)? 1. : -1. ;
            /* And we compute the angle z1Bz2 */
            gamma = sign * (HALFPI + asin((1. + dz / (2 * z1[j])) * dz / pInSAR->B.B - pInSAR->B.B / (2 * z1[j]))) ;
            
            /* Then we compute the local height from triangle S_z1_(RT+h) */
            h = sqrt(pow(pInSAR->S1.S, 2.) + pow(z1[j], 2.) - 2. * z1[j] * pInSAR->S1.S * sin(gamma - pInSAR->B.theta)) - RT ;
            do {
                h0 = h ;
                RT = earthRadiusAtPoint(P2[0], P2[1], h0, pInSAR->geo) ;
                h = sqrt(pow(pInSAR->S1.S, 2.) + pow(z1[j], 2.) - 2. * z1[j] * pInSAR->S1.S * sin(gamma - pInSAR->B.theta)) - RT ;
            } while (fabs(h - h0) > .1)  ;
            
			unwrappedPhase[j] = h ;
		}
        fwrite(unwrappedPhase, sizeof(float), pInSAR->srDEM.lenr, pInSAR->measurementFile->f) ;
		updateProgressCounterForIndex(aCounter, i) ;
	}
	freeProgressCounter(aCounter) ;
	freeVectorDouble(z1, 0) ;
	freeVectorDouble(P1, 0) ;
	freeVectorDouble(P2, 0) ;
}

