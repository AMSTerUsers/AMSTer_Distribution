
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  EnviSATBulkDataReader.c
//  EnviSATDataReader
//
//  Created by Dominique Derauw on 30/06/16.
//
//

#include "EnviSATBulkDataReader.h"

int main (int argc, const char * argv[]) {
    char *inputDirectory, *outputDirectory, *DORISDir = NULL ;
    char **directoryContent, **ROI_PACDirContent ;
    char *aPath, *inputPath, *inputFilePath, *outputFilePath, *ROI_PACDirectoryPath, *rscFilePath, *fileExtension ;
    char isEnviSATFormat ;
    char isAP ;
    int numberOfEntries, ROI_PACNumberOfEntries, i, j  ;
    time_t startTime, endTime ;
    keyValue *parametersList ;
    SLCImageInfo *info ;
    CSLImage *thisImage ;
    ENVISAT_HEADER *header ;
    
    if(argc == 1 || isArgumentPresent(argc, argv, "help") || isFlagPresent(argc, argv, "h"))
        usageOfBulkDataReader() ;
    
    time(&startTime) ;
    
    parametersList = allocAKeyValuePair() ;
    
    inputDirectory = allocStringOfLength(strlen(argv[1])) ;
    inputDirectory = strcpy(inputDirectory, argv[1]) ;
    if (!isDir(inputDirectory)) {
        ase("Path given as input directory is not valid") ;
    }
    if (!isReadAccessGrantedAtPath(inputDirectory)) {
        ase("Read access denied at path given as input directory") ;
    }
    
    outputDirectory = allocStringOfLength(strlen(argv[2])) ;
    outputDirectory = strcpy(outputDirectory, argv[2]) ;
    if (!isDir(outputDirectory)) {
        if (mkdir(argv[2], S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            ase("Path given as output directory is not valid") ;
        }
    }
    if (!isWriteAccessGrantedAtPath(outputDirectory)) {
        ase("Write access denied at path given as output directory") ;
    }
    
    if (isFlagPresent(argc, argv, "-o")) {
        DORISDir = allocStringOfLength(strlen(argv[4])) ;
        DORISDir = strcpy(outputDirectory, argv[4]) ;
        setStringValForKeyIn(parametersList, DORISDir, "EnviSAT precises orbits directory") ;
    }
    
    printf("EnviSAT data bulk reading\n") ;
    printf("*************************\n") ;
    printf("Input directory: %s\n", inputDirectory) ;
    printf("Output directory: %s\n", outputDirectory) ;
    
    DORISDir = getDORISDirectory(parametersList, argc, argv) ;
    if (DORISDir != NULL) {
        printf("DORIS precise orbits....... \tYes\n") ;
    }
    else
        printf("DORIS precise orbits....... \tNo\n") ;

    directoryContent = getDirectoryContentAtPath(inputDirectory, &numberOfEntries) ;
    for (i = 0; i < numberOfEntries; i++) {
        /* We test if directory entry is a directory. In which case, we could deal with a ROI_PAC data */
        inputPath = initStringWith3Strings(inputDirectory, "/", directoryContent[i]) ;
        if (isDir(inputPath)) {
            ROI_PACDirectoryPath = inputPath ;
            /* Read directory content and look for .rsc file(s) */
            if ((ROI_PACDirContent = getDirectoryContentAtPath(ROI_PACDirectoryPath, &ROI_PACNumberOfEntries)) != NULL) {
                for (j = 0; j < ROI_PACNumberOfEntries; j++) {
                    if (!strcmp((aPath = getPointerToLastFileExtensionInPath(ROI_PACDirContent[j])), "slc")) {
                        break ;
                    }
                }
                if (j == ROI_PACNumberOfEntries) {
                    break ;
                }
                if (j != numberOfEntries) {
                    /* Verify now that the corresponding rsc file is present */
                    inputFilePath = initStringWith3Strings(ROI_PACDirectoryPath, "/", ROI_PACDirContent[j]) ;
                    rscFilePath = initStringWith2Strings(inputFilePath, ".rsc") ;
                    if (isReadAccessGrantedAtPath(rscFilePath)) {
                        aPath = initStringWithString(ROI_PACDirectoryPath) ;
                        setStringValForKeyIn(parametersList, aPath, "Path to EnviSAT data file") ;
                        free(aPath) ;
                        
                        /* Generate infoImage */
                        info = createInfoImageFromROI_PAC_RSCFile(parametersList) ;
                        
                        /* Generate output path */
                        aPath = initStringWith3Strings(outputDirectory, "/", info->acquisitionDate) ;
                        setStringValForKeyIn(parametersList, aPath, "Path to output image in CSL format") ;
                        free(aPath) ;
                        
                        /* Create CSL directory structure at indicated path */
                        printf("Reading/saving ROI_PAC image: %s\n", getStringValForKeyIn(parametersList, "Path to output image in CSL format")) ;
                        thisImage = createCSLDirectoryStructureAtPath(getStringValForKeyIn(parametersList, "Path to output image in CSL format"), NULL) ;
                        
                        /* Save infoImage */
                        aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
                        saveInfoImage(info, aPath) ;
                        
                        if ((DORISDir = getDORISDirectory(parametersList, argc, argv)) != NULL) {
                            managePrecisesOrbitsFor(thisImage, DORISDir) ;
                        }
                        
                        /* Simple copy */
                        outputFilePath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", info->polMode) ;
                        copyFileAtPathToPath(inputFilePath, outputFilePath) ;

                        freeInfoImage(info) ;
                        free(aPath) ;
                    }
                    free(inputFilePath) ;
                }
            }
        }
        else {
            /* Test if we deal with an N1, E1 or E2 images */
            fileExtension = getPointerToFileExtensionInPath(inputPath) ;
            isEnviSATFormat = ((!strncmp(fileExtension, "N1", 2) || !strncmp(fileExtension, "E1", 2) || !strncmp(fileExtension, "E2", 2)) && isSubStringPresentInString(inputPath, "_IMS_1P")) ;
            if (isEnviSATFormat) {
                /* Apparently yes. So proceed */
                aPath = initStringWithString(inputPath) ;
                setStringValForKeyIn(parametersList, aPath, "Path to EnviSAT data file") ;
                free(aPath) ;

                /* Read EnviSAT header */
                header = readEnvisatHeader(inputPath) ;
                isAP = ((strncmp(&header->Main_Product->Product_File_Name.Product_Id[4], "AP", 2)) == 0) ;
               
                /* Generate infoImage */
                info = readInfoImageFromEnvisatHeader(header) ;
                if (strncmp(fileExtension, "N1", 2)) {
                    if (!strncmp(fileExtension, "E1", 2)) {
                        sprintf(info->platformName, "%s", "ERS1") ;
                    }
                    else {
                        sprintf(info->platformName, "%s", "ERS2") ;
                    }
                }

                /* Generate output path */
                aPath = initStringWith3Strings(outputDirectory, "/", info->acquisitionDate) ;
                setStringValForKeyIn(parametersList, aPath, "Path to output image in CSL format") ;
                free(aPath) ;
                
                /* Create CSL directory structure at indicated path */
                thisImage = createCSLDirectoryStructureAtPath(getStringValForKeyIn(parametersList, "Path to output image in CSL format"), NULL) ;
                printf("Reading/saving image: %s\n", thisImage->imageDirectoryPath) ;
                
                /* Copy header to destination directory */
                copyEnviSATHeadersToHeadersDirectory(inputPath, thisImage, header) ;
                
                /* Save and free infoImage */
                aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
                saveInfoImage(info, aPath) ;
                freeInfoImage(info) ;
                free(aPath) ;
                
                /* Manage precise orbit if possible */
                if ((DORISDir = getDORISDirectory(parametersList, argc, argv)) != NULL) {
                    managePrecisesOrbitsFor(thisImage, DORISDir) ;
                }
                

                /* Read and save data */
                readAndConvertEnviSATSLCDataInto(thisImage, header, parametersList, 0) ;
                if(isAP) {
                    readAndConvertEnviSATSLCDataInto(thisImage, header, parametersList, 1) ;
                }
            }
        }
        free(inputPath) ;
    }

    freeKeyValueList(parametersList) ;
    free(inputDirectory) ;
    free(outputDirectory) ;
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    return (0) ;
}


void usageOfBulkDataReader()
{
    printf("Usage:\n") ;
    printf("EnviSATBulkDataReader /inputDir /outputDir [-o /DorisDir]\n") ;
    
    exit(0) ;
}
