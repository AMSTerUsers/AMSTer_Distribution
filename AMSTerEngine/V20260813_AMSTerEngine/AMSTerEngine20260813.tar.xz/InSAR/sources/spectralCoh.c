
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include "spectralCoh.h"

void usage(int argc) ;

int main (int argc, const char * argv[]) {
	char processingStep, *aPath ;
    CSLImage *image ;
	bandSplitStruct *bspMaster ;
	keyValue *p ;
	struct rlimit limit ;
    time_t startTime, endTime, lap ;
	
	usage(argc) ;
    if(isArgumentPresent(argc, argv, "-create")) {
		createSpectralCohParameterFileAtPath((char *)argv[1]) ;
		exit(0) ;
	}
	time(&startTime) ;
	
	p = readParameterFileAtPath((char *)argv[1]) ;
	processingStep = 0 ;
    if (argc == 2) {
        processingStep |= _PERFORM_BAND_SPLIT_ ;
        processingStep |= _INTERBAND_COH_ ;
    }
    if(isArgumentPresent(argc, argv, "-split")) {
        processingStep |= _SPLIT_ONLY_ ;
        processingStep |= _PERFORM_BAND_SPLIT_ ;
    }
    if(isArgumentPresent(argc, argv, "-coh")) {
        processingStep |= _INTERBAND_COH_ ;
//        processingStep &= _PERFORM_BAND_SPLIT_ ^ 0xFFFFFFFF ;
    }
	
	/* Increase the system limit number of openfiles */
	if(!getrlimit(RLIMIT_NOFILE, &limit)) {
		//		printf("rlim_cur = %d\t rlim_max = %d\n", limit.rlim_cur, limit.rlim_max) ;
		limit.rlim_cur = RLIM_INFINITY ;
		setrlimit(RLIMIT_NOFILE, &limit) ;
	}
    
    /* Processing initialization */
    verifySpectralCohDirectoryStructure(p) ;
	
    /* Open CSL image */
    image = getCSLImageStructureAtPath(getStringValForKeyIn(p, "Image file path")) ;
    
    /* Create bandSplit structure for CSL image under concern */
    bspMaster = getBandSplitStructForCSLImage(image, p) ;
    bspMaster->subBands->flag |= _ADDITIONAL_DEMODULATION_ ;

	/* Image sub-views splitting */
    if(processingStep & _PERFORM_BAND_SPLIT_) {
        createSubImagesFiles(bspMaster) ;
        fprintf(stdout, "\nSplitting image %s into sub-bands: ", bspMaster->image->path);
        fflush(stdout) ;
        subViewsSplitting(bspMaster) ;
        
        fprintf(stdout, "\n") ;
        time(&lap) ;
        duration(startTime, lap) ;
    }
    else {
        openSubImages(bspMaster) ;
    }
    
    freeBandSplitStructWorkingMemory(bspMaster) ;

	/* Generate interferometric products */
	if(processingStep & _INTERBAND_COH_) {
		spectralCoherenceProcessingOfSubViews(bspMaster, p) ;
		time(&lap) ;
        duration(startTime, lap) ;
	}
	
    aPath = initStringWith2Strings(getStringValForKeyIn(p, "Output"), "/spectralCoh.txt") ;
	writeParameterFileAtPath(p, aPath) ;
    free(aPath) ;
	
	printf("\nTotal processing time:\n") ;
	time(&endTime) ;
    duration(startTime, endTime) ;
    return 0;
}


bandSplitStruct *getBandSplitStructForCSLImage(CSLImage *anImage, keyValue *p)
{
    char *aPath, *requestedPol, *genericFileName ;
    int i ;
    bandSplitStruct *bsp ;
    SLCImageInfo *info ;
    CSVStruct *csv ;

    /* Read image info text file */
    aPath = initStringWith2Strings(anImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
    info = readInfoImageFromTextFile(aPath) ;
    free(aPath) ;

    /* Verify requested polarization is present */
    csv = readCSVInString(info->polMode) ;
    requestedPol = getStringValForKeyIn(p, "Polarization") ;
    for (i = 0; i < csv->numberOfEntries; i++) {
        if (!(strncmp(csv->stringVal[i], requestedPol, 2))) {
            break ;
        }
    }
    if (i == csv->numberOfEntries) {
        ase("Requested polarization not found in CSL image") ;
    }
    freeCSVStruct(csv) ;

    /* Initialize band split structure for image */
    genericFileName = initStringWith2Strings("/SLCData.", requestedPol) ;
    aPath = initStringWith2Strings(anImage->dataDirectoryPath, genericFileName) ;
    bsp = allocAndInitSplitBandStruct(p, anImage, requestedPol) ;

    return (bsp) ;
}



void usage(int argc)
{
	if((argc < 2) || (argc > 3)) {
		fprintf(stdout, "Usage:\n-1- spectralCoh /path/parameterFile ==> Full processing\n") ;
		fprintf(stdout, "-2- spectralCoh /path/parameterFile -split ==> Sub-band splitting processing\n") ;
		fprintf(stdout, "-3- spectralCoh /path/parameterFile -coh ==> Sub-band spectral coherence processing\n") ;
		fprintf(stdout, "-4- spectralCoh /path/parameterFile -create ==> Create example parameter file at given path\n") ;
		fprintf(stdout, "Options 3 requires preceding step(s) to be completed\n") ;
		exit(0) ;
	}
}


/* Create an example MCA parameter file at given path */
void createSpectralCohParameterFileAtPath(char *aPath)
{
    keyValue *paramList ;
    
    paramList = allocAKeyValuePair() ;
    
    setStringValForKeyIn(paramList, "Spectral coherence process parameter file", "") ;
    setStringValForKeyIn(paramList, "*****************************************", "") ;
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Input file", "") ;
    setStringValForKeyIn(paramList, "***********", "") ;
    setStringValForKeyIn(paramList, "/path/fileName", "Image file path (in .csl format)") ;
    setStringValForKeyIn(paramList, "VV", "Polarization to select") ;
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Area of interest", "") ;
    setStringValForKeyIn(paramList, "****************", "") ;
    setIntValForKeyIn(paramList, 0, "Lower left range coordinate") ;
    setIntValForKeyIn(paramList, 0, "Lower left azimuth coordinate") ;
    setIntValForKeyIn(paramList, 0, "Upper right range coordinate") ;
    setIntValForKeyIn(paramList, 0, "Upper right azimuth coordinate") ;
        
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Band splitting processing parameters", "") ;
    setStringValForKeyIn(paramList, "************************************", "") ;
    setStringValForKeyIn(paramList, "0.54", "Apodization coefficient") ;
    setStringValForKeyIn(paramList, "40e6", "Bandwidth of sub-bands") ;
    setStringValForKeyIn(paramList, "20e6", "Sub-bands frequency shift") ;
    setStringValForKeyIn(paramList, "5", "Sub-bands number") ;
    
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Output products", "") ;
    setStringValForKeyIn(paramList, "***************", "") ;
    setStringValForKeyIn(paramList, "/path", "Output path") ;
    setStringValForKeyIn(paramList, "bsp", "Subviews file extension") ;
    setStringValForKeyIn(paramList, "mod", "Intensity images generic extension") ;
    setStringValForKeyIn(paramList, "Coherence", "Coherence images generic file name") ;
    setStringValForKeyIn(paramList, "0", "SpectralCoh products range dimension") ;
    setStringValForKeyIn(paramList, "0", "SpectralCoh products azimuth dimension") ;
    
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Interferometric processing parameters", "") ;
    setStringValForKeyIn(paramList, "*************************************", "") ;
    setStringValForKeyIn(paramList, "3x3", "Box averaging size (range x azimuth)") ;
    setStringValForKeyIn(paramList, "5x5", "Coherence estimator size (range x azimuth)") ;
    
    writeParameterFileAtPath(paramList, aPath) ;
}

void verifySpectralCohDirectoryStructure(keyValue *p)
{
    char *rootDirectory, *aPath ;
    
    rootDirectory = getStringValForKeyIn(p, "Output path") ;
    if (!isDir(rootDirectory)) {
        if(mkdir((const char *)rootDirectory, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create directory at path %s\n", rootDirectory) ;
            ase(ertex) ;
        }
    }
    
    if (!isWriteAccessGrantedAtPath(rootDirectory)) {
        ase("Write access not granted at indicated output directory path") ;
    }
    
    aPath = initStringWith2Strings(rootDirectory, "/SubBands") ;
    if (!isDir(aPath)) {
        if(mkdir((const char *)aPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create directory at path %s\n", aPath) ;
            ase(ertex) ;
        }
    }
    if (!isRWAccessGrantedAtPath(aPath)) {
        sprintf(ertex, "Read/Write access not granted at path %s", aPath) ;
        ase(ertex) ;
    }
    free(aPath) ;
    
    aPath = initStringWith2Strings(rootDirectory, "/Results") ;
    if (!isDir(aPath)) {
        if(mkdir((const char *)aPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create directory at path %s\n", aPath) ;
            ase(ertex) ;
        }
    }
    if (!isRWAccessGrantedAtPath(aPath)) {
        sprintf(ertex, "Read/Write access not granted at path %s", aPath) ;
        ase(ertex) ;
    }
    free(aPath) ;
    
    setStringValForKeyIn(p, rootDirectory, "Root directory") ;
}


void spectralCoherenceProcessingOfSubViews(bandSplitStruct *bsp, keyValue *p)
{
    char *outputDir ;
    int i, j, k, l, Nsb, Ncoh ;
    int xDim, yDim, saveIntensityImage ;
    float	*cohLine, *avgCohLine, *geometricMeanCohLine, **globalArithmeticMean, **globalGeometricMean ;
    float	*intensityLine, *avgIntensityLine ;
    InSARParametersStruct	*pInSAR ;
    rawFileDescriptor **coh, *avgCoh, *geoMeanCoh, *globalAMean, *globalGMean ;
    rawFileDescriptor **intensityImage, *avgIntensityImage ;
    
    /* We deal with interband coherence computation. So an InSAR parameter structure is required */
    if((pInSAR = malloc(sizeof(InSARParametersStruct))) == NULL)
        ase("spectralCoh.c: Failed to allocate pointer to InSAR parameter structure") ;
    
    /* Now, we initialize this structure with the minimum of required processing parameters */
    pInSAR->masterInterpolation = 0 ;
    pInSAR->flag = 0 ;
    pInSAR->SM2MpInSAR = NULL ;

    /* If a specific area of interest is defined, use it */
    if(isKeyValPresent(p, "Lower left azimuth coordinate")) {
        pInSAR->sup.Sgra = getIntValForKeyIn(p, "Lower left range coordinate") ;
        pInSAR->sup.Sbaz = getIntValForKeyIn(p, "Lower left azimuth coordinate") ;
        pInSAR->sup.Sdra = getIntValForKeyIn(p, "Upper right range coordinate") ;
        pInSAR->sup.Shaz = getIntValForKeyIn(p, "Upper right azimuth coordinate") ;
    }
    /* But if set to zero, consider the whole image */
    if (!pInSAR->sup.Sgra && !pInSAR->sup.Sbaz && !pInSAR->sup.Sdra && !pInSAR->sup.Shaz) {
        pInSAR->sup.Sgra = pInSAR->sup.Sbaz = 0 ;
        pInSAR->sup.Sdra = bsp->image->rangeDim -1 ;
        pInSAR->sup.Shaz = bsp->image->azimuthDim -1 ;
    }
    pInSAR->aoi = allocQuadrilateral() ;
    pInSAR->aoi->P[0].x = pInSAR->aoi->P[3].x = pInSAR->sup.Sgra ;
    pInSAR->aoi->P[1].x = pInSAR->aoi->P[2].x = pInSAR->sup.Sdra ;
    pInSAR->aoi->P[0].y = pInSAR->aoi->P[1].y = pInSAR->sup.Sbaz ;
    pInSAR->aoi->P[3].y = pInSAR->aoi->P[2].y = pInSAR->sup.Shaz ;


    /* Definition of coherence estimator window */
    sprintf(aComment, "%s", getStringValForKeyIn(p, "Coherence estimator size")) ;
    sscanf(aComment, "%d%*1s%d ", &((pInSAR->coh).cor), &((pInSAR->coh).coa)) ;
    
    /* Definition of box averaging window */
    sprintf(aComment, "%s", getStringValForKeyIn(p, "Box averaging size")) ;
    sscanf(aComment, "%d%*1s%d ", &((pInSAR->red).Fra), &((pInSAR->red).Faz)) ;

    Nsb = bsp->subBands->Nsb ;
    printf("\n\nGenerating SpectralCoh products for each sub-band\n");
    
    pInSAR->rad.rangeResolutionCell = c0 / bsp->sensor->fs / 2. ;
    outputDir = initStringWith2Strings(getStringValForKeyIn(p, "Output"), "/Results") ;
    for(i = 0; i < Nsb - 1; i++) {
        printf("\nMaster Sub-band N° %d: ", i + 1) ;
        pInSAR->masterImageFile = bsp->subImage[i]->file ;
        pInSAR->rad.nu = bsp->subBands->fci[i] ;
        saveIntensityImage = 1 ;
        for(j = i + 1; j < Nsb; j++) {
            if(!i && (j == Nsb - 1)) saveIntensityImage = 2 ;
            printf("\n\tSlave Sub-band N° %d: ", j + 1) ;
            pInSAR->slaveImageFile = bsp->subImage[j]->file ;
            
            pInSAR->rad.nu2 = bsp->subBands->fci[j] ;
            sprintf(accessPath, "%s/%s.%d.%d", outputDir, getStringValForKeyIn(p, "Coherence"), i, j) ;
            pInSAR->coherenceFile = openRawFileForWritingAtPath(accessPath) ;
            if(saveIntensityImage) {
                sprintf(accessPath, "%s/%s.%d", outputDir, getStringValForKeyIn(p, "Intensity"), i) ;
                pInSAR->masterAmplitudeImageFile = openRawFileForWritingAtPath(accessPath) ;
            }
            if(saveIntensityImage == 2) {
                sprintf(accessPath, "%s/%s.%d", outputDir, getStringValForKeyIn(p, "Intensity"), j) ;
                pInSAR->slaveAmplitudeImageFile = openRawFileForWritingAtPath(accessPath) ;
            }
            
            coherenceEstimator(pInSAR, saveIntensityImage) ;
            
            if(!i && j == 1) {
                setIntValForKeyIn(p, pInSAR->coherenceFile->xDim, "SpectralCoh products range dimension") ;
                setIntValForKeyIn(p, pInSAR->coherenceFile->yDim, "SpectralCoh products azimuth dimension") ;
            }
            freeRawFileDescriptor(pInSAR->coherenceFile) ;
            saveIntensityImage = 0 ;
            
        }
        freeRawFileDescriptor(pInSAR->masterImageFile) ;
    }
    freeRawFileDescriptor(pInSAR->slaveImageFile) ;
    
    
    printf("\n\nAverage coherence measurements\n") ;
    /* Compute average coherences */
    xDim = getIntValForKeyIn(p, "SpectralCoh products range") ;
    yDim = getIntValForKeyIn(p, "SpectralCoh products azimuth") ;
    printf("\n xDim = %d\tyDim = %d\n", xDim, yDim) ;
    cohLine = vectorFloat(0, xDim - 1) ;
    avgCohLine = vectorFloat(0, xDim - 1) ;
    geometricMeanCohLine = vectorFloat(0, xDim - 1) ;
    globalArithmeticMean = matrixFloat(0, yDim - 1, 0, xDim - 1) ;
    globalGeometricMean = matrixFloat(0, yDim - 1, 0, xDim - 1) ;
    coh = (rawFileDescriptor **)malloc((Nsb - 1) * sizeof(rawFileDescriptor *)) ;
    
    /* We create the output file corresponding to the global arithmetic mean coherence */
    sprintf(accessPath, "%s/%s.arm", outputDir, getStringValForKeyIn(p, "Coherence")) ;
    globalAMean = openRawFileForWritingAtPath(accessPath) ;
    /* We create the output file corresponding to the global geometric mean coherence */
    sprintf(accessPath, "%s/%s.gem", outputDir, getStringValForKeyIn(p, "Coherence")) ;
    globalGMean = openRawFileForWritingAtPath(accessPath) ;
    Ncoh = 0 ;
    
    for(k = 1; k < Nsb - 2; k++) {
        /* We create the output file corresponding to arithmetic mean coherence k sub-bands appart */
        sprintf(accessPath, "%s/%s.arm.%d", outputDir, getStringValForKeyIn(p, "Coherence"), k) ;
        avgCoh = openRawFileForWritingAtPath(accessPath) ;
        
        /* We create the output file corresponding to geometric mean coherence k sub-bands appart */
        sprintf(accessPath, "%s/%s.gem.%d", outputDir, getStringValForKeyIn(p, "Coherence"), k) ;
        geoMeanCoh = openRawFileForWritingAtPath(accessPath) ;
        
        /* We open all coherence files required */
        for(l = 0; l < Nsb - k; l++) {
            sprintf(accessPath, "%s/%s.%d.%d", outputDir, getStringValForKeyIn(p, "Coherence"), l, l + k) ;
            coh[l] = openRawFileForReadingAtPath(accessPath) ;
        }
        
        /* For each lines ... */
        for(j = 0; j < yDim; j++) {
            /* in each required coherence files ... */
            for(l = 0; l < Nsb - k; l++) {
                /* we read the line and add it to the average line */
                fread(cohLine, sizeof(float), xDim, coh[l]->f) ;
                if(!l) {
                    memcpy(avgCohLine, cohLine, sizeof(float) * xDim) ;
                    for(i = 0; i < xDim; i++) {
                        geometricMeanCohLine[i] = logf(avgCohLine[i]) ;
                    }
                }
                else {
                    for(i = 0; i < xDim; i++) {
                        avgCohLine[i] += cohLine[i] ;
                        geometricMeanCohLine[i] += logf(cohLine[i]) ;
                    }
                }
                if (!j) {
                    Ncoh++ ;
                }
            }
            
            /* Now we compute the global means of all coherences */
            if (k == 1) {
                memcpy(globalArithmeticMean[j], avgCohLine, sizeof(float) * xDim) ;
                memcpy(globalGeometricMean[j], geometricMeanCohLine, sizeof(float) * xDim) ;
            }
            else {
                for(i = 0; i < xDim; i++) {
                    globalArithmeticMean[j][i] += avgCohLine[i] ;
                    globalGeometricMean[j][i] += geometricMeanCohLine[i] ;
                }
            }
            
            /* Then we compute the average and ... */
            for(i = 0; i < xDim; i++) {
                avgCohLine[i] /= Nsb - k ;
                geometricMeanCohLine[i] = expf(geometricMeanCohLine[i] / (Nsb - k)) ;
            }
            /* we save it. */
            fwrite(avgCohLine, sizeof(float), xDim, avgCoh->f) ;
            fwrite(geometricMeanCohLine, sizeof(float), xDim, geoMeanCoh->f) ;
        }
        
        /* Now, we close coherence files that must be closed */
        for(l = 0; l < Nsb - k; l++) {
            freeRawFileDescriptor(coh[l]) ;
        }
        freeRawFileDescriptor(avgCoh) ;
        freeRawFileDescriptor(geoMeanCoh) ;
    }
    /* Now, we finalize and save the global means */
    for (j = 0; j< yDim; j++) {
        for(i = 0; i < xDim; i++) {
            globalArithmeticMean[j][i] /= Ncoh ;
            globalGeometricMean[j][i] = expf(globalGeometricMean[j][i] / (Ncoh)) ;
        }
    }
    fwrite(globalArithmeticMean[0], sizeof(float), xDim * yDim, globalAMean->f) ;
    fwrite(globalGeometricMean[0], sizeof(float), xDim * yDim, globalGMean->f) ;
    
    printf("Average Coherence computed\n") ;
    
    freeRawFileDescriptor(globalAMean) ;
    freeRawFileDescriptor(globalGMean) ;
    freeVectorFloat(cohLine, 0) ;
    freeVectorFloat(avgCohLine, 0) ;
    freeVectorFloat(geometricMeanCohLine, 0) ;
    freeMatrixFloat(globalArithmeticMean, 0, 0) ;
    freeMatrixFloat(globalGeometricMean, 0, 0) ;
    
    
    printf("\n\nAverage intensity measurements\n") ;
    /* Compute average intensity image */
    intensityLine = vectorFloat(0, xDim - 1) ;
    avgIntensityLine = vectorFloat(0, xDim - 1) ;
    if((intensityImage = (rawFileDescriptor **)malloc(Nsb * sizeof(rawFileDescriptor *))) == NULL)
        ase("Failed to allocate vector of raw file descriptors for intensity images") ;
    
    /* We create the output file corresponding to averaged intensity of k sub-bands */
    sprintf(accessPath, "%s/%s.avg", outputDir, getStringValForKeyIn(p, "Intensity")) ;
    if((avgIntensityImage = openRawFileForWritingAtPath(accessPath)) == NULL)
        ase("Failed to create average intensity file");
    
    /* We open all intensity image files that must be opened */
    for(k = 0; k < Nsb; k++) {
        sprintf(accessPath, "%s/%s.%d", outputDir, getStringValForKeyIn(p, "Intensity"), k) ;
        if((intensityImage[k] = openRawFileForReadingAtPath(accessPath)) == NULL)
            ase("Failed to open intensity image for averaging\n") ;
    }
    /* For each lines ... */
    for(j = 0; j < yDim; j++) {
        /* in each required intensity image files ... */
        for(k = 0; k < Nsb ; k++) {
            /* we read the line and add it to the average line */
            fread(intensityLine, sizeof(float), xDim, intensityImage[k]->f) ;
            if(!k)
                memcpy(avgIntensityLine, intensityLine, sizeof(float) * xDim) ;
            else {
                for(i = 0; i < xDim; i++)
                    avgIntensityLine[i] += intensityLine[i] ;
            }
        }
        /* Then we compute the average and ... */
        for(i = 0; i < xDim; i++)
            avgIntensityLine[i] /= Nsb ;
        /* we save it. */
        if(fwrite(avgIntensityLine, sizeof(float), xDim, avgIntensityImage->f) != xDim)
            ase("Failed to write average intensity image") ;
    }
    printf("Average Intensity computed\n") ;
    
    /* Now, we close all intensity files that must be closed */
    for(k = 0; k < Nsb; k++) {
        freeRawFileDescriptor(intensityImage[k]) ;
    }
    printf("All files closed\n") ;
    
    freeRawFileDescriptor(avgIntensityImage) ;
    freeVectorFloat(intensityLine, 0) ;
    freeVectorFloat(avgIntensityLine, 0) ;
    printf("All pointers released\n") ;
}


void phaseStability(bandSplitStruct *bsp, keyValue *p)
{

}

