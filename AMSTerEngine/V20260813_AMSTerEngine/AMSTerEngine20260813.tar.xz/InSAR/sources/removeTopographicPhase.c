
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  removeTopographicPhase.c
//  removeTopographicPhase
//
//  Created by Dominique Derauw on 16/01/13.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "removeTopographicPhase.h"

int main(int argc, const char * argv[])
{
	char *aPath, InSARParametersFileFound ;
	int	currentDirectoryFdesc, i ;
    float deltaH ;
	InSARParametersStruct	*pInSAR ;
	time_t startTime, endTime ;
	
	InSARParametersFileFound = 0 ;
	currentDirectoryFdesc = open(".", O_RDONLY) ;
	fchdir(currentDirectoryFdesc) ;
	
	if(isArgumentPresent(argc, argv, "help"))
		usage() ;
	
	i = 1 ;
	while (i < argc) {
		aPath = initStringWithString((char *)argv[i]) ;
		if(fileExistsAtPath(aPath)) {
			InSARParametersFileFound = 1 ;
			break ;
		}
		i++ ;
		free(aPath) ;
	}
	if(!InSARParametersFileFound) {
		aPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
		if(!fileExistsAtPath(aPath)){
			free(aPath) ;
			aPath = initStringWithString("./InSARParameters.txt") ;
			if(!fileExistsAtPath(aPath))
				usage() ;
		}
		InSARParametersFileFound = 1 ;
	}
    
	time(&startTime) ;
	pInSAR = readInSARParametersFileAtPath(aPath) ;

    pInSAR->flag |= (isArgumentPresent(argc, argv, "-ha"))? FIRST_ORDER_TPOGRAPHIC_PHASE_APPROXIMATION : pInSAR->flag ;
    pInSAR->flag |= (!isArgumentPresent(argc, argv, "-noCrop"))? WITH_CROPPING : pInSAR->flag ;
    deltaH = 0. ;
    if ((i = isArgumentPresent(argc, argv, "deltaH"))) {
        sscanf(argv[i], "deltaH=%f", &deltaH) ;
    }


    removeTopographicPhase(pInSAR, deltaH);
	
	saveInSARParametersFileAtPath(pInSAR, aPath) ;
	free(pInSAR) ;
	
	time(&endTime) ;
	duration(startTime, endTime) ;
	return(0) ;
}

void removeTopographicPhase(InSARParametersStruct *pInSAR, float deltaH)
{
    char *aFilePath ;
    int iX, iY, dR, dA ;
    double rangePosition, azimuthPosition, *P1, *P2 ;
	float *h, *phiTopo, *phiDiff, *interf ;
    complexFloat cPhiDiff, cPhiTopo, cInterf ;
	geoRefSolving *geoPar ;
	progressCounter *aCounter ;
    rawFileDescriptor *externalSlantRangeDEMFile ;
    rawFileDescriptor *interferometricPhaseFile ;
    rawFileDescriptor *topographicPhaseFile ;
    rawFileDescriptor *differentialPhaseFile ;
    
	geoPar = pInSAR->geo->solving ;
    P1 = vectorDouble(0, 1) ;
    P2 = vectorDouble(0, 1) ;
    h = vectorFloat(0, (pInSAR->srDEM).lenr) ;
    phiTopo = vectorFloat(0, (pInSAR->srDEM).lenr) ;
    phiDiff = vectorFloat(0, (pInSAR->srDEM).lenr) ;
    interf = vectorFloat(0, (pInSAR->interf).lenr) ;
        
    if (fileExistsAtPath(pInSAR->srDEM.filePath)) {
        externalSlantRangeDEMFile = openRawFileForReadingAtPath(pInSAR->srDEM.filePath) ;
    }
    else
        ase("No external slant range DEM available") ;
    
    aFilePath = initStringWith2Strings(pInSAR->interf.filePath, ".differential") ;
    differentialPhaseFile = openRawFileForWritingAtPath(aFilePath) ;
    free(aFilePath) ;
    topographicPhaseFile = openRawFileForWritingAtPath(pInSAR->dephi.filePath) ;
    interferometricPhaseFile = openRawFileForReadingAtPath(pInSAR->interf.filePath) ;
    
    dR = (pInSAR->interf.lenr - pInSAR->srDEM.lenr) / 2 ;
    dA = (pInSAR->interf.lena - pInSAR->srDEM.lena) / 2 ;
    fseek(interferometricPhaseFile->f, dA * pInSAR->interf.lenr * sizeof(float), SEEK_SET) ;
	aCounter = initProgressCounterWithMinMaxValue(0, (pInSAR->srDEM).lena - 1) ;
    for (iY = 0; iY < pInSAR->srDEM.lena; iY++) {
		azimuthPosition = (double)(iY * (pInSAR->red).Faz + (pInSAR->sup).Sbaz + (pInSAR->coh).spi / 2 + (pInSAR->coh).coa / 2) ;
        if((fread(h, sizeof(float), (pInSAR->srDEM).lenr, externalSlantRangeDEMFile->f)) != (pInSAR->srDEM).lenr)
            ase("Failed to read external slant range DEM data") ;
        if((fread(interf, sizeof(float), (pInSAR->interf).lenr, interferometricPhaseFile->f)) != (pInSAR->interf).lenr)
            ase("Failed to read interferometric phase") ;
        
        for (iX = 0; iX < pInSAR->srDEM.lenr; iX++) {
			rangePosition = (double)(iX * (pInSAR->red).Fra  + (pInSAR->sup).Sgra + (pInSAR->coh).spi / 2 + (pInSAR->coh).cor / 2) ;
            P2[0] = rangePosition ;
            P2[1] = azimuthPosition ;
            
            if (pInSAR->masterInterpolation) {
                P1[0] = P2[0] ;
                P1[1] = P2[1] ;
                planeAffineTransformOfPoint(P1, P2, pInSAR->masterAffineTransform) ;
            }

            phiTopo[iX] = topographicalPhaseAtPoint(P2[0], P2[1], h[iX] + deltaH, pInSAR) ;
            cPhiTopo.r = cosf(phiTopo[iX]) ;
            cPhiTopo.i = sinf(phiTopo[iX]) ;
            cInterf.r = cosf(interf[iX + dR]) ;
            cInterf.i = sinf(interf[iX + dR]) ;
            cPhiDiff = mC(cInterf , cC(cPhiTopo)) ;
            phiDiff[iX] = phiC(cPhiDiff) ;
        }
        if((fwrite(phiDiff, sizeof(float), pInSAR->srDEM.lenr, differentialPhaseFile->f)) != pInSAR->srDEM.lenr)
            ase("Failed to write differential phase") ;
        if((fwrite(phiTopo, sizeof(float), pInSAR->srDEM.lenr, topographicPhaseFile->f)) != pInSAR->srDEM.lenr)
            ase("Failed to write differential phase") ;

        updateProgressCounterForIndex(aCounter, iY) ;
    }
    updateProgressCounterForIndex(aCounter, iY) ;

    if (pInSAR->flag & WITH_CROPPING) {
        cropInSARProducts(pInSAR) ;
    }
    
    pInSAR->interf.lenr = pInSAR->dephi.lenr = pInSAR->srDEM.lenr ;
    pInSAR->interf.lena = pInSAR->dephi.lena = pInSAR->srDEM.lena ;
    
    freeVectorDouble(P1, 0) ;
    freeVectorDouble(P2, 0) ;
    freeVectorFloat(h, 0) ;
    freeVectorFloat(phiTopo, 0) ;
    freeVectorFloat(phiDiff, 0) ;
    freeVectorFloat(interf, 0) ;

    freeRawFileDescriptor(externalSlantRangeDEMFile) ;
    freeRawFileDescriptor(interferometricPhaseFile) ;
    freeRawFileDescriptor(topographicPhaseFile) ;
    freeRawFileDescriptor(differentialPhaseFile) ;
}

void usage(void)
{
    
}