
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  ETADDataReader.c
//  ETADDataReader
//
//  Created by Dominique Derauw on 17/04/2025
//  Copyright (c) 2025 Dominique Derauw. All rights reserved.
//


#include "S1ETADManagement.h"

void ETADDataReaderUsage(void)  ;


int main(int argc, const char *argv[])
{
    char *inputDir = NULL, *ETADDir = NULL, *fromDate = NULL, *toDate = NULL ;
    int i ;
    size_t numberOfFrames, frameIndex ;
    CSVStruct *imageList ;
    CSLImage *thisImage, **imageFrame ;
    SLCImageInfo *imageInfo ;

    if (argc == 1 || isFlagPresent(argc, argv, "h")) {
        ETADDataReaderUsage() ;
    }
    if ((i = isArgumentPresent(argc, argv, "from="))) {
        fromDate = allocStringOfLength(8) ;
        sscanf(argv[i] + 5, "%8s", fromDate) ;
    }
    if ((i = isArgumentPresent(argc, argv, "to="))) {
        toDate = allocStringOfLength(8) ;
        sscanf(argv[i] + 3, "%8s", toDate) ;
    }
    
    for (i = 0; i < argc; i++) {
        if (isDir((char *)argv[i])) {
            if (!inputDir) {
                inputDir = initStringWithString((char *)argv[i]) ;
            }
            else {
                ETADDir = initStringWithString((char *)argv[i]) ;
            }
        }
    }
    
    if (!inputDir) {
        printf("\t-/-> First parameter must be a valid directory supposed to contain S1 images in .csl format\n") ;
        ETADDataReaderUsage() ;
    }
    if (!ETADDir) {
        ETADDir = initStringWithString(inputDir) ;
    }
    
    printf("ETADDataReader:\n\t---> ETAD data directory: %s\n\t--->.csl images directory: %s\n", ETADDir, inputDir) ;
    if(fromDate) {
        printf("\n\t---> Checking .csl images from %s\n", fromDate) ;
    }    
    if(toDate) {
        printf("\n\t---> Checking .csl images to %s\n", toDate) ;
    }

    imageList = getListingOfCSLImagesInDir(inputDir, fromDate, toDate) ;
    if (!imageList) {
        printf("\t---> No .csl image found in input directory. Stopping here. \n") ;
        exit(0) ;
    }
    
    for ( i = 0; i < imageList->numberOfEntries; i++) {
        thisImage = getCSLImageStructureAtPath(imageList->stringVal[i]) ;
        imageInfo = readInfoImageInCSLImage(thisImage) ;
        printf("\t\t---> Image %d of %d: %s\n", i + 1, imageList->numberOfEntries, thisImage->imageDirectoryPath) ;
        if (imageInfo->sensorID == __SENTINEL1__) {
            imageFrame = getFrameListInCSLImage(thisImage, &numberOfFrames) ;
            for (frameIndex = 0; frameIndex < numberOfFrames; frameIndex++){
                updateETADDataIntoS1Frame(imageFrame[frameIndex], ETADDir) ;
            }
            freeCSLImageListing(imageFrame, numberOfFrames) ;
        }
        else {
            printf("\t---> skipping %s. Not a Sentinel 1 frame\n\n", imageInfo->scene_id) ;
        }
        printf("\n") ;
        freeInfoImage(imageInfo) ;
        freeCSLImageStructure(thisImage) ;
    }
    
    if (fromDate) {
        free(fromDate) ;
    }    
    if (toDate) {
        free(toDate) ;
    }
    
    free(inputDir) ;
    free(ETADDir) ;

    return (0) ;
}

void ETADDataReaderUsage(void) 
{
    printf("\nETADDataReader usage:\n") ;
    printf("ETADDataReader S1ImagesDirectory [ETADDirectory] [from=YYYYMMDD] [to=YYYYMMDD]\n") ;
    printf("ETADDataReader reads already uncompressed ETAD data found in ETADDirectory to update corresponding Sentinel1 images in .csl format found in S1ImagesDirectory.\n") ;
    printf("If ETADDirectory is not given, ETAD data are searched within image directory.\n") ;
    printf("ETAD data are read and saved on a burst by burst basis within each .csl burst images.\n\n") ;
    printf("A starting and/or end date can be given to limit .csl images to be updated.\n") ;
    exit (0);
}