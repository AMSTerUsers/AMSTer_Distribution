
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  S1OrbitUpdater.c
//  S1OrbitUpdater
//
//  Created by Dominique Derauw on 20/06/2018.
//  Copyright © 2018 Dominique Derauw. All rights reserved.
//

#include "S1OrbitUpdater.h"

int main(int argc, const char * argv[]) {
    char isUpdated, justMerge ;
    char *POEORB_Dir = NULL ;
    char *inputDir ;
    char **directoryContent ;
    char *oldInfoImageFilePath ;
    char *logFilePath ;
    int i, frameIndex, numberOfEntries ;
    size_t numberOfFrames ;
    CSLImage *imageContainer, **frameList, *thisFrame ;
    SLCImageInfo *frameInfo, *imageInfo ;
    rawFileDescriptor *logFile ;


    if ((POEORB_Dir = getenv("S1_ORBITS_DIR")) == NULL) {
        ase("\t-/->\tS1_ORBITS_DIR environment variable not defined. Please define it with S1 orbits database location.") ;
    }
    
    if (isFlagPresent(argc, argv, "u")) {
        system("updateS1Orbits") ;
    }

    if (!isDir((char *)argv[1])) {
        S1OrbitUpdaterUsage() ;
    }
    
    /* Create log file */
    logFilePath = initStringWith2Strings((char *)argv[1], "/S1OrbitUpdaterLog.txt") ;
    if (fileExistsAtPath(logFilePath)) {
        unlink(logFilePath) ;
    }
    logFile = openRawFileForReadingAndWritingAtPath(logFilePath) ;

    
    /* List all available S1 scene within input directory */
    directoryContent = getDirectoryContentAtPath((char *)argv[1], &numberOfEntries) ;
    for (i = 0; i < numberOfEntries; i++) {
        inputDir = initStringWith3Strings((char *)argv[1], "/", directoryContent[i]) ;
        if (isCSLImageAtPath(inputDir)) {
            imageContainer = getCSLImageStructureAtPath(inputDir) ;
            if ((frameList = getFrameListInCSLImage(imageContainer, &numberOfFrames))) {
                isUpdated = justMerge = 0 ;
                for (frameIndex = 0; frameIndex < numberOfFrames; frameIndex++) {
                    thisFrame = frameList[frameIndex] ;
                    oldInfoImageFilePath = initStringWith2Strings(thisFrame->infoDirectoryPath, "/SLCImageInfo.txt.old") ;
                    frameInfo = readInfoImageInCSLImage(frameList[frameIndex]) ;
                    if (!fileExistsAtPath(oldInfoImageFilePath)) {
                        fseek(logFile->f, 0, SEEK_END) ;
                        printf("\t---> Checking frame %d in image %s.\n", frameIndex, getPointerToFileNameInPath(imageContainer->imageDirectoryPath)) ;
                        fprintf(logFile->f, "\t---> Checking frame %d in image %s.\n", frameIndex, getPointerToFileNameInPath(imageContainer->imageDirectoryPath)) ;

                        isUpdated = manageS1OrbitsFor(thisFrame, POEORB_Dir, frameInfo) ;
                    }
                    else {
                        printf("\t---> Precise orbit update already done previously.\n") ;
                        fprintf(logFile->f, "\t---> Precise orbit update already done previously.\n") ;
                        /* Checking if dealing with old version of SLCInfoImage.txt and setting Orbit type if needed */
                        if (!frameInfo->orbitTypeID || isSubStringPresentInString(frameInfo->orbitTypeID, "Unknown")) {
                            frameInfo->orbitTypeID = initStringWithString("Precise orbit") ;
                            saveInfoImageInCSLImage(frameInfo, frameList[frameIndex]) ;
                            justMerge = 1 ;
                        }
                    }

                    freeInfoImage(frameInfo) ;
                    outputOrbitUpdateMessage(logFile, isUpdated) ;
                    freeCSLImageStructure(thisFrame) ;
                    free(oldInfoImageFilePath) ;
                }
                /* If an update was performed, merge infomage with existing ones */
                if (isUpdated || justMerge) {
                    if (isUpdated) {
                        printf("\t---> Merging updated infoImage.txt\n") ;
                        fprintf(logFile->f, "\t---> Merging updated infoImage.txt\n") ;     
                    }
                    
                    imageInfo = mergeFrameInfo(imageContainer, NULL) ;
                    sprintf(accessPath, "%s/SLCImageInfo.txt", imageContainer->infoDirectoryPath) ;
                    saveInfoImage(imageInfo, accessPath) ;
                    closeAndReleasBurstFiles(imageInfo) ;
                    freeS1Specific(imageInfo->sensorSpecificInfo, _S1_TRASH_BURSTS_) ;
                    freeInfoImage(imageInfo) ;
                    
                    if (isUpdated) {
                        fprintf(logFile->f, "%s\n", getPointerToFileNameInPath(imageContainer->imageDirectoryPath)) ;
                        printf("\t---> Orbit update in image %s done.\n\n", getPointerToFileNameInPath(imageContainer->imageDirectoryPath)) ;
                    }
                }
                free(frameList) ;
            }
            freeCSLImageStructure(imageContainer) ;
        }
        free(inputDir) ;
    }
    freeDirectoryEntries(directoryContent, numberOfEntries) ;
    free(logFilePath) ;
    freeRawFileDescriptor(logFile) ;

    return (0) ;
}





void S1OrbitUpdaterUsage()
{
    printf("S1OrbitUpdater aPath [-u]\n") ;
    printf("Usage:\n") ;
    printf("aPath = path to dir containing S1 images in CSL format\n") ;
    printf("-u : Update precise orbit data base before starting images update.\n") ;
    exit(0) ;
}
