
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include "biasedCoh.h"

/* main programm start */
int main(int argc, const char **argv)
{
	char *aPath = NULL, InSARParametersFileFound ;
	int	currentDirectoryFdesc, i ;
	InSARParametersStruct	*pInSAR ;
	time_t startTime, endTime ;
	
	InSARParametersFileFound = 0 ;
	currentDirectoryFdesc = open(".", O_RDONLY) ;
	fchdir(currentDirectoryFdesc) ;
	
	if(isArgumentPresent(argc, argv, "help") || isArgumentPresent(argc, argv, "-h") || isArgumentPresent(argc, argv, "-help"))
		biasedCoherenceUsage() ;
		
	i = 1 ;
	while (i < argc) {
		aPath = initStringWithString((char *)argv[i]) ;
		if(fileExistsAtPath(aPath)) {
			InSARParametersFileFound = 1 ;
			break ;
		}
		i++ ;
		free(aPath) ;
	}
	if(!InSARParametersFileFound) {
		aPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
		if(!fileExistsAtPath(aPath)){
			free(aPath) ;
			aPath = initStringWithString("./InSARParameters.txt") ;
			if(!fileExistsAtPath(aPath))
				biasedCoherenceUsage() ;
		}
		InSARParametersFileFound = 1 ;
	}
	time(&startTime) ;
	pInSAR = readInSARParametersFileAtPath(aPath) ;
    
    pInSAR->flag |= (isFlagPresent(argc, argv, "A"))? _WITHOUT_AMPLITUDE_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresent(argc, argv, "M"))? _MEDIAN_FILTER_OF_COHERENCE_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresent(argc, argv, "m"))? _GEN_PHASE_UNWRAPPING_MASK_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresent(argc, argv, "F"))? _CONSIDER_FILTERED_INTERF_ : pInSAR->flag ;

	biasedCoherenceEstimation(pInSAR) ;
	
	saveInSARParametersFileAtPath(pInSAR, aPath) ;
	freeInSARParametersStruct(pInSAR) ;
	
	time(&endTime) ;
	duration(startTime, endTime) ;
	return(0) ;
}


void biasedCoherenceUsage()
{
	printf("\nbiasedCoherenceUsage:\nbiasedCoherenceEstimation [/pathTo/InSARParameters.txt] \n\n") ;
	printf("The biasedCoherenceEstimation routine will compute a biased coherence \nthat will be used for the residue connexion process\n") ;
	printf("\nIf used with no parameters, the routine will look for an \"InSARparameters.txt\".\n") ;
	printf("file within the working directory or within the ./TextFiles subdirectory.\n") ;
	printf("Any other path to a text file containing InSAR parameters can be given as\nfirst parameter.\n\n") ;
	exit(0) ;
}
