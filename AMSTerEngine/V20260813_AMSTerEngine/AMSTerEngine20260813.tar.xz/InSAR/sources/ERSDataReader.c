
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include <stdio.h>
#include "ERSDataReader.h"


int main (int argc, const char * argv[]) {
	char *inputDir, *outputDir, *imageName, *imagePath, *infoFilePath, satName[6], AD[12] ;
	int i, frameNumber ;
	keyValue *parametersList ;
	CSLImage *thisImage ;
	CEOSHeader *header ;
	CSVStruct *ERSFilePath ;
	SLCImageInfo *info ;

	    
	if(argc == 1 || isArgumentPresent(argc, argv, "help") || isArgumentPresent(argc, argv, "-h")) {
		usage() ;
	}
	
	if(isArgumentPresent(argc, argv, "-create")) {
		createParameterFileAtPath((char *)argv[1]) ;
	}

	if (isDir((char *)argv[1])) {
		if (argc == 3) {
			if (isDir((char *)argv[2])) {
				outputDir = initStringWithString((char *)argv[2]) ;
			}
		}
		else {
			outputDir = initStringWithString((char *)argv[1]) ;
		}
		ERSFilePath = recursiveSearchOfFileInDir("VDF_", (char *)argv[1]) ;
		if (ERSFilePath) {
			if (ERSFilePath->numberOfEntries == 1 && argc == 2) {
				free(outputDir) ;
				outputDir = getUpperDirectoryPath((char *)argv[1]) ;
			}
			
			parametersList = allocAKeyValuePair() ;
			for (i = 0; i < ERSFilePath->numberOfEntries; i++) {
				inputDir = getDirectoryPathFromPath(ERSFilePath->stringVal[i]) ;
				setStringValForKeyIn(parametersList, inputDir, "Path to directory containing ERS data") ;
				setStringValForKeyIn(parametersList, "VDF_DAT.001", "VDF") ;
				setStringValForKeyIn(parametersList, "LEA_01.001", "LF") ;
				setStringValForKeyIn(parametersList, "DAT_01.001", "DAT") ;
				verifyParametersList(parametersList) ;
				header = readCEOSHeaders(parametersList) ;
				info  = readInfoImageFromCEOSHeader(header->vdf, header->lf, header->imof) ;
				sscanf(info->scene_loc + 6, "%d", &frameNumber) ;
//saveInfoImage(info, "/home/dd/SAR/DATA/Images/RSAT/SLCInfo.txt") ;

				sprintf(satName, "%.4s_", info->productID) ;
				sprintf(AD, "_F%d_%.1s", frameNumber, info->heading) ;
				imageName = initStringWith3Strings(satName, info->acquisitionDate, AD) ;
				imagePath = initStringWith3Strings(outputDir, "/", imageName) ;

				printf("\nReading image %d/%d\n", i + 1, ERSFilePath->numberOfEntries) ;
				printf("---> %.4s image dated %s acquired in %s mode\n", satName, info->acquisitionDate, info->heading) ;
				thisImage = createCSLDirectoryStructureAtPath(imagePath, __ERS1__) ;

				copyHeadersToHeadersDirectory(parametersList, thisImage) ;
				readAndConvertERSSLCDataInto(thisImage, header, parametersList) ;
				infoFilePath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
				saveInfoImage(info, infoFilePath) ;
				saveInfoKmlInDir(info, thisImage->infoDirectoryPath) ;

				freeInfoImage(info) ;
				freeCEOSHeader(header) ;
				free(imageName) ;
				free(imagePath) ;
				free(infoFilePath) ;
				free(inputDir) ;
			}
			freeKeyValueList(parametersList) ;
		}
		else {
			printf("No ERS .vdf files found. Nothing to read.\n") ;
		}

		return (0) ;
	}
	else {
		if (fileExistsAtPath((char *)argv[1])) {
			parametersList = readParameterFileAtPath((char *)argv[1]) ;
			verifyParametersList(parametersList) ;
			
			thisImage = createCSLDirectoryStructureAtPath(getStringValForKeyIn(parametersList, "Path to output image in CSL format"), __ERS1__) ;
			copyHeadersToHeadersDirectory(parametersList, thisImage) ;
			header = readCEOSHeaders(parametersList) ;
			createInfoTextFileFromHeaderFor(thisImage, header) ;
			readAndConvertERSSLCDataInto(thisImage, header, parametersList) ;
			
			freeCEOSHeader(header) ;
			freeKeyValueList(parametersList) ;

			return 0 ;
		}
		else {
			printf("ERSDataReader:\n\t-/-> First parameter must be a directory or a readable parameter file.\n") ;
			usage() ;
		}
	}
}

void usage()
{
	printf("\nUsage:\n \n");
	printf("\t-1- ERSDataReader /pathTo/InputDir /pathTo/DestinationDir\n");
	printf("\t-2- ERSDataReader /pathTo/parameterFile [-create]\n");
	printf("\nThis routine will read ERS data and save it in CSL format.\n");
	printf("\nIf adding \"-create\" command line parameter, \nan example parameter file will be created at indicated path.\n") ;
	exit(0) ;
}

void createParameterFileAtPath(char *aPath)
{
	keyValue *parameterList ;
	
	parameterList = allocAKeyValuePair() ;
	setStringValForKeyIn(parameterList, "ERSDataReader parameter file", "") ;
	setStringValForKeyIn(parameterList, "****************************", "") ;
	setStringValForKeyIn(parameterList, "PathToDirectory", "Path to directory containing ERS data") ;
	setStringValForKeyIn(parameterList, "DAT_01.001", "DAT: Data file name") ;
	setStringValForKeyIn(parameterList, "VDF_DAT.001", "VDF: Volume Directory File filename") ;
	setStringValForKeyIn(parameterList, "LEA_01.001", "LF: Leader File filename") ;
	setStringValForKeyIn(parameterList, "NUL_DAT.001", "NUL: Null Volume File filename") ;
	setStringValForKeyIn(parameterList, "outputFilePath", "Path to output image in CSL format") ;
	
	writeParameterFileAtPath(parameterList, aPath) ;
	
	exit(0) ;
}

void copyHeadersToHeadersDirectory(keyValue *parameterList, CSLImage *thisImage) 
{
	char *inputDirectory, *buffer, *vdfName, *lfName, *nulName, *imofName ;
	char inputPath[_MAX_PATH_LENGTH_], destinationPath[_MAX_PATH_LENGTH_] ;
	char *aPath ;
	int i ;
	long aLong ;
	rawFileDescriptor *inputHeader, *outputHeader ;
	
	thisImage->numberOfHeaderFiles = 3 ;
	inputDirectory = getStringValForKeyIn(parameterList, "Path to directory containing ERS data") ;
	vdfName = getStringValForKeyIn(parameterList, "VDF") ;
	lfName = getStringValForKeyIn(parameterList, "LF") ;
	imofName = getStringValForKeyIn(parameterList, "DAT") ;
	nulName = getStringValForKeyIn(parameterList, "NUL") ;
	if((nulName != NULL)) {
		aPath = initStringWith3Strings(inputDirectory, "/",  nulName) ;
		if(fileExistsAtPath(aPath))
		   thisImage->numberOfHeaderFiles++ ;
		free(aPath) ;
	}
	thisImage->headerFileNames = (char **)malloc(sizeof(char *) * thisImage->numberOfHeaderFiles) ;
	
	thisImage->headerFileNames[0] = initStringWithString(vdfName) ;
	thisImage->headerFileNames[1] = initStringWithString(lfName) ;
	if(thisImage->numberOfHeaderFiles == 4) {
		thisImage->headerFileNames[2] = initStringWithString(nulName) ;
		thisImage->headerFileNames[3] = initStringWith2Strings(imofName, ".imof") ;
	}
	else
		thisImage->headerFileNames[2] = initStringWith2Strings(imofName, ".imof") ;
		
	/* Read and write Headers */
	for(i = 0; i < thisImage->numberOfHeaderFiles - 1; i++) {		
		sprintf(inputPath, "%s/%s", inputDirectory, thisImage->headerFileNames[i]) ;
		inputHeader = openRawFileForReadingAtPath(inputPath) ;
		sprintf(destinationPath, "%s/%s", thisImage->headersDirectoryPath, thisImage->headerFileNames[i]) ;
		outputHeader = openRawFileForWritingAtPath(destinationPath) ;
		buffer = malloc(inputHeader->fileLength) ;
		fread(buffer, inputHeader->fileLength, 1, inputHeader->f) ;
		fwrite(buffer, inputHeader->fileLength, 1, outputHeader->f) ;
		
		free(buffer) ;
		freeRawFileDescriptor(inputHeader) ;
		freeRawFileDescriptor(outputHeader) ;
	}
	
	sprintf(inputPath, "%s/%s", inputDirectory, getStringValForKeyIn(parameterList, "DAT")) ;
	inputHeader = openRawFileForReadingAtPath(inputPath) ;
	sprintf(destinationPath, "%s/%s", thisImage->headersDirectoryPath, thisImage->headerFileNames[i]) ;
	outputHeader = openRawFileForWritingAtPath(destinationPath) ;
	aLong = sizeof(struct CEOS_IMOF) ;
	buffer = malloc(aLong) ;
	fread(buffer, aLong, 1, inputHeader->f) ;
	fwrite(buffer, aLong, 1, outputHeader->f) ;
	
	free(buffer) ;
	freeRawFileDescriptor(inputHeader) ;
	freeRawFileDescriptor(outputHeader) ;
}

CEOSHeader *readCEOSHeaders(keyValue *parameterList)
{
	char *inputDirectory, *vdfName, *lfName, *imofName ;
	char *aPath ;
	union intChar4 recLength ;
	CEOSHeader *header ;
	rawFileDescriptor *dataFile ;

	inputDirectory = getStringValForKeyIn(parameterList, "Path to directory containing ERS data") ;
	vdfName = getStringValForKeyIn(parameterList, "VDF") ;
	lfName = getStringValForKeyIn(parameterList, "LF") ;
	imofName = getStringValForKeyIn(parameterList, "DAT") ;
	
	header = malloc(sizeof(CEOSHeader)) ;
	
	aPath = initStringWith3Strings(inputDirectory, "/", vdfName) ;
	header->vdf = readCEOS_VDF(aPath) ;
	free(aPath) ;

	aPath = initStringWith3Strings(inputDirectory, "/", lfName) ;
	header->lf = readCEOS_LF(aPath) ;
	free(aPath) ;
	
	aPath = initStringWith3Strings(inputDirectory, "/", imofName) ;
	header->imof = readCEOS_IMOF(aPath) ;


	return(header) ;
}


void createInfoTextFileFromHeaderFor(CSLImage *thisImage, CEOSHeader *header)
{
	char *aPath ;
	SLCImageInfo *info ;

	info  = readInfoImageFromCEOSHeader(header->vdf, header->lf, header->imof) ;
	aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
	saveInfoImage(info, aPath) ;
	free(aPath) ;
}


void readAndConvertERSSLCDataInto(CSLImage *thisImage, CEOSHeader *header, keyValue *parameterList)
{
	char aPath[_MAX_PATH_LENGTH_] ;
	char *inputDirectory, *inputFileName ;
	int i, j, numberOfDataRecords, numberOfSamplesPerLine ;
	long dataRecordLength, dataRecordHeaderLength, dataFirstRecordLength ;
	rawFileDescriptor *inputFile, *outputFile ;
	complexShort	*cs ;
    complexFloat	*cf ;
	progressCounter *aCounter ;
    keyValue *savedDataCharacteristics ;
	
	if(header->imof == NULL) {
		numberOfDataRecords = readIntInASCIIStringOfLength(header->vdf->fpr[1].ref_file_nrecs, 8) - 1 ;
		dataRecordLength = readIntInASCIIStringOfLength(header->vdf->fpr[1].ref_file_max_reclen, 8) ;
		dataRecordHeaderLength = 12 ;
		numberOfSamplesPerLine = (dataRecordLength - dataRecordHeaderLength) / 4 ;
	}
	else {
		numberOfDataRecords = readIntInASCIIStringOfLength(header->imof->imof_var.data_nrecs, 6) ;
		dataRecordLength = readIntInASCIIStringOfLength(header->imof->imof_var.data_rec_len, 6) ;
		dataRecordHeaderLength = dataRecordLength - readIntInASCIIStringOfLength(header->imof->imof_var.SAR_data_bytes_per_rec, 8) ;
		numberOfSamplesPerLine = (dataRecordLength - dataRecordHeaderLength) / readIntInASCIIStringOfLength(header->imof->imof_var.nbytes_group, 4) ;
	}
	
	inputDirectory = getStringValForKeyIn(parameterList, "Path to directory containing ERS data") ;
	inputFileName = getStringValForKeyIn(parameterList, "DAT") ;
	sprintf(aPath, "%s/%s", inputDirectory, inputFileName) ;
	inputFile = openRawFileForReadingAtPath(aPath) ;
    
    
    dataFirstRecordLength = readIntInASCIIStringOfLength(header->vdf->fpr[1].ref_file_1_st_reclen, 8) ;
	fseek(inputFile->f, dataFirstRecordLength, SEEK_SET) ;
	
	sprintf(aPath, "%s/%s", thisImage->dataDirectoryPath, "SLCData.VV") ;
	outputFile = openRawFileForWritingAtPath(aPath) ;
	
	cs = vectorComplexShort(0, numberOfSamplesPerLine - 1) ;
	cf = vectorComplexFloat(0, numberOfSamplesPerLine - 1) ;
	aCounter = initProgressCounterWithMinMaxValue(0, numberOfDataRecords - 1) ;
	for(i = 0 ; i < numberOfDataRecords ; i++) {	
		fseek(inputFile->f, dataRecordHeaderLength, SEEK_CUR) ;
        fread ((complexShort *)cs, sizeof(complexShort), numberOfSamplesPerLine, inputFile->f) ;
		
        for(j = 0; j < numberOfSamplesPerLine ; j++) {
			if(!isArchBigEndian()) {
				swapComplexShort(&cs[j]) ;
			}
            cf[j].r = (float)cs[j].r ;
            cf[j].i = (float)cs[j].i ;
        }
		
        fwrite((complexFloat *)cf, sizeof(complexFloat), numberOfSamplesPerLine, outputFile->f) ;
		updateProgressCounterForIndex(aCounter, i) ;
    }
	
	freeVectorComplexShort(cs, 0) ;
	freeVectorComplexFloat(cf, 0) ;
	freeRawFileDescriptor(inputFile) ;
	freeRawFileDescriptor(outputFile) ;
	freeProgressCounter(aCounter) ;
	
    savedDataCharacteristics = allocAKeyValuePair() ;
	sprintf(aPath, "%s/%s", thisImage->infoDirectoryPath, "SLCData.VV.txt") ;
    setStringValForKeyIn(savedDataCharacteristics, "SLC data structure", "") ;
    setStringValForKeyIn(savedDataCharacteristics, "******************", "") ;
    setStringValForKeyIn(savedDataCharacteristics, "complex", "Data type") ;
    setStringValForKeyIn(savedDataCharacteristics, "float - float", "Data structure") ;
    if (isArchBigEndian()) {
        setStringValForKeyIn(savedDataCharacteristics, "Big endian", "Data byte order") ;
    }
    else
        setStringValForKeyIn(savedDataCharacteristics, "Low endian", "Data byte order") ;
    setIntValForKeyIn(savedDataCharacteristics, numberOfSamplesPerLine, "Number of columns") ;
    setIntValForKeyIn(savedDataCharacteristics, numberOfDataRecords, "Number of raws") ;
    writeParameterFileAtPath(savedDataCharacteristics, aPath) ;
    freeKeyValueList(savedDataCharacteristics) ;
}

void freeCEOSHeader(CEOSHeader *header)
{
	freeStructCEOS_VDF(header->vdf) ;
	freeStructCEOS_LF(header->lf) ;
	free(header->imof) ;
	free(header) ;
}


void verifyParametersList(keyValue *parametersList)
{
	char *dirIn, *aPath ;
	
	dirIn = getStringValForKeyIn(parametersList, "Path to directory containing ERS data") ;
		
	if(!isDir(dirIn))
		ase("Given input path is not a valid directory\n") ;
	if(!isReadAccessGrantedAtPath(dirIn))
		ase("Read acces not granted for input path\n") ;
	
	aPath = initStringWith3Strings(dirIn, "/", getStringValForKeyIn(parametersList, "DAT")) ;
	if(!fileExistsAtPath(aPath))
		ase("Data file does not exists at given input path\n") ;
	free(aPath) ;
	
	aPath = initStringWith3Strings(dirIn, "/", getStringValForKeyIn(parametersList, "VDF")) ;
	if(!fileExistsAtPath(aPath))
		ase("Volume Directory file does not exists at given input path\n") ;
	free(aPath) ;

	aPath = initStringWith3Strings(dirIn, "/", getStringValForKeyIn(parametersList, "LF")) ;
	if(!fileExistsAtPath(aPath))
		ase("Leader file does not exists at given input path\n") ;
	free(aPath) ;
}

