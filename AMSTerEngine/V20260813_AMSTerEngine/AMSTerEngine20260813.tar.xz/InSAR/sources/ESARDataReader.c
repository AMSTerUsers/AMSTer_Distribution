
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  ESARDataReader
//
//  Created by Dominique Derauw on 25/02/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "infoImage.h"
#include "infoImageESAR.h"
#include "counters.h"
#include "complexCalculus.h"

void usage() ;
void createParameterFileAtPath(char *aPath) ;
void copyHeadersToHeaderDirectory(SLCImageInfo *info, CSLImage *anImage, keyValue *pList) ;
void readAndConvertData(SLCImageInfo *info, CSLImage *anImage, keyValue *pList) ;

int main(int argc, const char * argv[])
{
    char *aPath ;
	keyValue *parametersList ;
	CSLImage *thisImage ;
	SLCImageInfo *info ;
    time_t startTime, endTime ;
    
	time(&startTime) ;
    if(argc == 1 || argc > 3)
		usage() ;
	if(isArgumentPresent(argc, argv, "help")|| isArgumentPresent(argc, argv, "-h"))
		usage() ;
    
	if(isArgumentPresent(argc, argv, "-create"))
		createParameterFileAtPath((char *)argv[1]) ;
	
	parametersList = readParameterFileAtPath((char *)argv[1]) ;
    info = createSLCInfoImageForESARData(parametersList) ;

	thisImage = createCSLDirectoryStructureAtPath(getStringValForKeyIn(parametersList, "Out"), NULL) ;
    aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
	saveInfoImage(info, aPath) ;
    free(aPath) ;
    
    copyHeadersToHeaderDirectory(info, thisImage, parametersList) ;
    
    readAndConvertData(info, thisImage, parametersList) ;

    freeCSLImageStructure(thisImage) ;
    freeInfoImage(info) ;
	freeKeyValueList(parametersList) ;
    
    time(&endTime) ;
	duration(startTime, endTime) ;
    
    return 0;
}



void usage()
{
    printf("ESARDataReader:\n") ;
    printf("Usage: ESARDataReader /pathToParameterFile [-create]\n") ;
    printf("This routine reads ESAR data to save them in CSL format.\n") ;
    printf("It uses a parameter files giving the path to the ESAR data\ndirectory and to headers files.\n") ;
    printf("If the keyword \"-create\" is appended, an example parameter\nfile will be created at given path.\n") ;
    printf("Attention! This routine was developped making a lot of\nsupposition since we do not have a full format description.\n") ;
    printf("Consequently it may or it may not work... Good luck.\n") ;
    exit(0) ;
}


void createParameterFileAtPath(char *aPath)
{
    keyValue *parameters ;
	
	parameters = allocAKeyValuePair() ;
	setStringValForKeyIn(parameters, "ESARDataReader parameter file", "") ;
	setStringValForKeyIn(parameters, "****************************", "") ;
	setStringValForKeyIn(parameters, "pathToESARDataDirectory", "ESAR data directory path.") ;
	setStringValForKeyIn(parameters, "outputFilePath", "Output file path to image in CSL format") ;
    setStringValForKeyIn(parameters, "YES", "Read coregistered image layers") ;

    writeParameterFileAtPath(parameters, aPath) ;
	
	exit(0) ;
}


void copyHeadersToHeaderDirectory(SLCImageInfo *info, CSLImage *anImage, keyValue *pList)
{
    char *genericFileName, *ESARDirectory, aPath[_MAX_PATH_LENGTH_] ;
    char *areaCode ;
    char *outputFilePath ;
    int i ;

    ESARDirectory = getStringValForKeyIn(pList, "ESAR") ;
    if (!isReadAccessGrantedAtPath(ESARDirectory)) {
        ase("Cannot access ESAR data directory") ;
    }
    genericFileName = getFileNameFromPath(ESARDirectory) ;
    /* Seperate generic file name and area code */
    replaceNSubStringInString(genericFileName, "_", ".") ;
    areaCode = initStringWithString(getPointerToFileExtensionInPath(genericFileName)) ;
    stripExtensionAtEndOfPath(genericFileName) ;
    
    for (i = 0; i < info->numberOfLayers; i++) {
        sprintf(aPath, "%s/e%s_ch%.1d_%s.txt", ESARDirectory, genericFileName, i + 1, areaCode) ;
        outputFilePath = initStringWith3Strings(anImage->headersDirectoryPath, "/", getPointerToFileNameInPath(aPath)) ;
        copyFileAtPathToPath(aPath, outputFilePath) ;
    }
    
    sprintf(aPath, "%s/e%s_%s.txt", ESARDirectory, genericFileName, areaCode) ;
    outputFilePath = initStringWith3Strings(anImage->headersDirectoryPath, "/", getPointerToFileNameInPath(aPath)) ;
    copyFileAtPathToPath(aPath, outputFilePath) ;
}


void readAndConvertData(SLCImageInfo *info, CSLImage *anImage, keyValue *pList)
{
    char *genericFileName, *ESARDirectory, inputFilePath[_MAX_PATH_LENGTH_], *aPath ;
    char *areaCode ;
    char *outputFilePath ;
    int i, rangeDim, azimuthDim, iX, iY ;
    float amplitude, phase ;
    complexFloat *aLine, *aVHLine;
    CSVStruct *polMode ;
    rawFileDescriptor *inputFile, *inputFileVH, *outputFile ;
    progressCounter *aCounter ;
    
    
    ESARDirectory = getStringValForKeyIn(pList, "ESAR") ;
    if (!isReadAccessGrantedAtPath(ESARDirectory)) {
        ase("Cannot access ESAR data directory") ;
    }
    genericFileName = getFileNameFromPath(ESARDirectory) ;
    /* Seperate generic file name and area code */
    replaceNSubStringInString(genericFileName, "_", ".") ;
    areaCode = initStringWithString(getPointerToFileExtensionInPath(genericFileName)) ;
    stripExtensionAtEndOfPath(genericFileName) ;
    polMode = readCSVInString(info->polMode) ;
    
    aLine = vectorComplexFloat(0, info->rangeDimension) ;
    aVHLine = vectorComplexFloat(0, info->rangeDimension) ;
    aCounter = initProgressCounterWithMinMaxValue(0, info->azimuthDimension - 1) ;
    for (i = 0; i < info->numberOfLayers; i++) {
        if (!strncmp(getStringValForKeyIn(pList, "Read coregistered"), "NO", 2)) {
            sprintf(inputFilePath, "%s/i%s_ch%.1d_%s_slc.dat", ESARDirectory, genericFileName, i + 1, areaCode) ;
        }
        else
            sprintf(inputFilePath, "%s/i%s_ch%.1d_%s_slc.dat.final", ESARDirectory, genericFileName, i + 1, areaCode) ;
        
        outputFilePath = initStringWith3Strings(anImage->dataDirectoryPath, "/SLCData.", polMode->stringVal[i]) ;
        
        inputFile = openRawFileForReadingAtPath(inputFilePath) ;
        outputFile = openRawFileForWritingAtPath(outputFilePath) ;
        
        fread(&rangeDim, sizeof(int), 1, inputFile->f) ;
        fread(&azimuthDim, sizeof(int), 1, inputFile->f) ;
        if (!isArchBigEndian()) {
            swapInt(&rangeDim) ;
            swapInt(&azimuthDim) ;
        }
        printf("Reading %s layer:\n", polMode->stringVal[i]) ;
        for (iY = 0; iY < azimuthDim; iY++) {
            fread(aLine, sizeof(complexFloat), rangeDim, inputFile->f) ;
            if (!isArchBigEndian()) {
                for (iX = 0; iX < rangeDim; iX++) {
                    swapComplexFloat(aLine + iX) ;
                }
            }
            fwrite(aLine, sizeof(complexFloat), rangeDim, outputFile->f) ;
            updateProgressCounterForIndex(aCounter, iY) ;
        }
        updateProgressCounterForIndex(aCounter, iY) ;
        resetProgressCounter(aCounter) ;
        printf("\n\n") ;
        
        freeRawFileDescriptor(inputFile) ;
        freeRawFileDescriptor(outputFile) ;
        free(outputFilePath) ;
    }
    
    /* We will reread HV and VH layers and combine them in XX channel */
    if (info->numberOfLayers == 4) {
        aPath = initStringWith2Strings(anImage->dataDirectoryPath, "/SLCData.HV") ;
        inputFile = openRawFileForReadingAtPath(aPath) ;
        free(aPath) ;
        
        aPath = initStringWith2Strings(anImage->dataDirectoryPath, "/SLCData.VH") ;
        inputFileVH = openRawFileForReadingAtPath(aPath) ;
        free(aPath) ;
        
        aPath = initStringWith2Strings(anImage->dataDirectoryPath, "/SLCData.XX") ;
        outputFile = openRawFileForWritingAtPath(aPath) ;
        free(aPath) ;
        
        printf("Generating XX layer\n") ;
        for (iY = 0; iY < azimuthDim; iY++) {
            fread(aLine, sizeof(complexFloat), rangeDim, inputFile->f) ;
            fread(aVHLine, sizeof(complexFloat), rangeDim, inputFileVH->f) ;
            for (iX = 0; iX < rangeDim; iX++) {
                amplitude = (modC(aLine[iX]) + modC(aVHLine[iX])) / 2. ;
                phase = (phiC(aLine[iX]) + phiC(aVHLine[iX])) / 2. ;
                aLine[iX].r = amplitude * cosf(phase) ;
                aLine[iX].i = amplitude * sinf(phase) ;
            }
            fwrite(aLine, sizeof(complexFloat), rangeDim, outputFile->f) ;
            updateProgressCounterForIndex(aCounter, iY) ;
        }
        updateProgressCounterForIndex(aCounter, iY) ;
        resetProgressCounter(aCounter) ;
        printf("\n\n") ;
        
        freeRawFileDescriptor(inputFile) ;
        freeRawFileDescriptor(inputFileVH) ;
        freeRawFileDescriptor(outputFile) ;
    }

    freeVectorComplexFloat(aLine, 0) ;
    freeVectorComplexFloat(aVHLine, 0) ;
}

