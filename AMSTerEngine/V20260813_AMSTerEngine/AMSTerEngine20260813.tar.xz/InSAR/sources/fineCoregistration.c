
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  fineCoregistration.c
//  fineCoregistration
//
//  Created by Dominique Derauw on 15/01/2020.
//  Copyright © 2020 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "coregistrationLib.h"


int main(int argc, const char * argv[])
{
    int i ;
    CSVStruct *csv = NULL ;
    coregistrationResults *corResults ;
    
    for (i = 0; i < argc; i++) {
        csv = addStringValInCSVStruct((char *)argv[i], csv) ;
    }
    
    corResults = fineCoregistration(csv) ;
    /* Up to now, we do not keep track of the coregistration results */
    /* In the future, coregistration grids should be resampled on a regular grid and saved */
    freeCoregistrationResults(corResults) ;
    freeCSVStruct(csv) ;
    
    return(0) ;
}


