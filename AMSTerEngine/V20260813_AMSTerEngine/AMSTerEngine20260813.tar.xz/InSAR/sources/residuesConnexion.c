
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include "conex28.h"

/* fonctions */
void usage(void) ;

/* main programm start */
int main(int argc, const char **argv)
{
	char *aPath = NULL, InSARParametersFileFound ;
	int	currentDirectoryFdesc, i ;
	InSARParametersStruct	*pInSAR ;
	time_t startTime, endTime ;
	
	InSARParametersFileFound = 0 ;
	currentDirectoryFdesc = open(".", O_RDONLY) ;
	fchdir(currentDirectoryFdesc) ;
	
	if(isArgumentPresent(argc, argv, "help"))
		usage() ;
	
	i = 1 ;
	while (i < argc) {
		aPath = initStringWithString((char *)argv[i]) ;
		if(fileExistsAtPath(aPath)) {
			InSARParametersFileFound = 1 ;
			break ;
		}
		i++ ;
		free(aPath) ;
	}
	if(!InSARParametersFileFound) {
		aPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
		if(!fileExistsAtPath(aPath)){
			free(aPath) ;
			aPath = initStringWithString("./InSARParameters.txt") ;
			if(!fileExistsAtPath(aPath))
				usage() ;
		}
		InSARParametersFileFound = 1 ;
	}
    
	time(&startTime) ;
	pInSAR = readInSARParametersFileAtPath(aPath) ;
    
    if((i = isArgumentPresent(argc, argv, "mask="))) {
        pInSAR->additionalParameters = allocAKeyValuePair() ;
        setStringValForKeyIn(pInSAR->additionalParameters, (char *)&argv[i][5], "Mask path") ;
    }
	
	residuesConnexion(pInSAR) ;
	
	saveInSARParametersFileAtPath(pInSAR, aPath) ;
	free(pInSAR) ;
	
	time(&endTime) ;
	duration(startTime, endTime) ;
	return(0) ;
}


void usage(void)
{
	printf("\nUsage:\nresiduesConnexion [/pathTo/InSARParameters.txt]\n\n") ;
	printf("The residuesConnexion routine will perform the connexion of found residues.\n") ;
	printf("Connexion process is guided using the biased coherecne measurement.\n");
	printf("\nIf used with no parameters, the routine will look for an \"InSARparameters.txt\".\n") ;
	printf("file within the working directory or within the ./TextFiles subdirectory.\n") ;
	printf("Any other path to a text file containing InSAR parameters can be given as\nfirst parameter.\n\n") ;
	exit(0) ;
}
