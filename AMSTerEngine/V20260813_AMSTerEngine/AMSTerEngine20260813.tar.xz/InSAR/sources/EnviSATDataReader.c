
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  EnviSATBulkDataReader.c
//  EnviSATDataReader
//
//  Created by Dominique Derauw on 30/06/16.
//
//

#include "EnviSATDataReaderLib.h"


int main (int argc, const char * argv[]) {
    char *inputDirectory, *outputDirectory, *DORISDir = NULL ;
    char **directoryContent, **ROI_PACDirContent ;
    char *aPath, *inputPath, *inputFilePath, *outputFilePath = NULL, *ROI_PACDirectoryPath, *rscFilePath, *fileExtension ;
    char isEnviSATFormat ;
    char isAP ;
    int numberOfEntries, ROI_PACNumberOfEntries, i, j  ;
    time_t startTime, endTime ;
    SLCImageInfo *info ;
    CSLImage *thisImage ;
    ENVISAT_HEADER *header ;
    keyValue *parametersList = NULL ;
    
    if(argc == 1 || isArgumentPresent(argc, argv, "help") || isFlagPresent(argc, argv, "h")) {
        EnviSATDataReaderHelp() ;
    }
    if(isArgumentPresent(argc, argv, "-create")) {
        createEnviSATDataReaderParameterFileAtPath(argc, argv) ;
    }

    time(&startTime) ;

    if ((DORISDir = getNextArgument(argc, argv, "-o")) == NULL) {
        DORISDir = getenv("ENVISAT_PRECISES_ORBITS_DIR") ;
    }
    
    aPath = allocStringOfLength(strlen(argv[1])) ;
    aPath = strcpy(aPath, argv[1]) ;
    if (!isDir(aPath)) {
        /* First parameter is not a directory. So, let's suppose we deal with a parameter file */
        /* Read parameter file */
        parametersList = readParameterFileAtPath((char *)argv[1]) ;
        inputFilePath = initStringWithString(getStringValForKeyIn(parametersList, "Path to EnviSAT data file")) ;
        outputFilePath = initStringWithString(getStringValForKeyIn(parametersList, "Path to output image in CSL format")) ;
        inputDirectory = getDirectoryPathFromPath(inputFilePath) ;
        outputDirectory = getDirectoryPathFromPath(outputFilePath) ;
        numberOfEntries = 1 ;
        if((directoryContent = (char **)malloc(numberOfEntries * sizeof (char *))) == NULL) {
            ase("\t-/-> Failed to allocate EnviSAT image path...\n") ;
        }
        directoryContent[0] = initStringWithString(getFileNameFromPath(inputFilePath)) ;
        if (!DORISDir) {
            DORISDir = getStringValForKeyIn(parametersList, "EnviSAT precises orbits directory") ;
        }
        freeKeyValueList(parametersList) ;
    }
    else {
        inputDirectory = aPath ;
        if (!isReadAccessGrantedAtPath(inputDirectory)) {
            ase("Read access denied at path given as input directory") ;
        }
        outputDirectory = allocStringOfLength(strlen(argv[2])) ;
        outputDirectory = strcpy(outputDirectory, argv[2]) ;
        if (!isDir(outputDirectory)) {
            if (mkdir(argv[2], S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
                ase("Path given as output directory is not valid") ;
            }
        }
        if (!isWriteAccessGrantedAtPath(outputDirectory)) {
            ase("Write access denied at path given as output directory") ;
        }
        
        printf("EnviSAT data reading\n") ;
        printf("********************\n") ;
        printf("Input directory: %s\n", inputDirectory) ;
        printf("Output directory: %s\n", outputDirectory) ;
        directoryContent = getDirectoryContentAtPath(inputDirectory, &numberOfEntries) ;
    }
    

    for (i = 0; i < numberOfEntries; i++) {
        /* We test if directory entry is a directory. In which case, we could deal with a ROI_PAC data */
        inputPath = initStringWith3Strings(inputDirectory, "/", directoryContent[i]) ;
        if (isDir(inputPath)) {
            ROI_PACDirectoryPath = inputPath ;
            /* Read directory content and look for .rsc file(s) */
            if ((ROI_PACDirContent = getDirectoryContentAtPath(ROI_PACDirectoryPath, &ROI_PACNumberOfEntries)) != NULL) {
                for (j = 0; j < ROI_PACNumberOfEntries; j++) {
                    if (!strcmp((aPath = getPointerToLastFileExtensionInPath(ROI_PACDirContent[j])), "slc")) {
                        break ;
                    }
                }
                if (j == ROI_PACNumberOfEntries) {
                    break ;
                }
                if (j != numberOfEntries) {
                    /* Verify now that the corresponding rsc file is present */
                    inputFilePath = initStringWith3Strings(ROI_PACDirectoryPath, "/", ROI_PACDirContent[j]) ;
                    rscFilePath = initStringWith2Strings(inputFilePath, ".rsc") ;
                    if (isReadAccessGrantedAtPath(rscFilePath)) {
                       /* Generate infoImage */
                        info = createInfoImageFromROI_PAC_RSCFile(ROI_PACDirectoryPath) ;
                        
                        /* Generate output path */
                        outputFilePath = initStringWith3Strings(outputDirectory, "/", info->acquisitionDate) ;
                        
                        /* Create CSL directory structure at indicated path */
                        printf("Reading/saving ROI_PAC image: %s\n", outputFilePath) ;
                        thisImage = createCSLDirectoryStructureAtPath(outputFilePath, NULL) ;
                        
                        if (DORISDir) {
                            managePrecisesOrbitsFor(thisImage, DORISDir) ;
                        }

                        /* Save infoImage */
                        aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
                        saveInfoImage(info, aPath) ;
                        free(saveInfoKmlInDir(info, thisImage->infoDirectoryPath)) ;
                        free(aPath) ;
                        
                        /* Simple copy */
                        outputFilePath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", info->polMode) ;
                        copyFileAtPathToPath(inputFilePath, outputFilePath) ;
                        free(outputFilePath) ;

                        freeInfoImage(info) ;
                        free(aPath) ;
                    }
                    free(inputFilePath) ;
                }
            }
        }
        else {
            /* Test if we deal with an N1, E1 or E2 images */
            fileExtension = getPointerToFileExtensionInPath(inputPath) ;
            isEnviSATFormat = ((!strncmp(fileExtension, "N1", 2) || !strncmp(fileExtension, "E1", 2) || !strncmp(fileExtension, "E2", 2)) && isSubStringPresentInString(inputPath, "_IMS_1P")) ;
            if (isEnviSATFormat) {
                /* Read EnviSAT header */
                header = readEnvisatHeader(inputPath) ;
                isAP = (strncmp(&header->Main_Product->Product_File_Name.Product_Id[4], "AP", 2))? 0 : 1 ;
               
                /* Generate infoImage */
                info = readInfoImageFromEnvisatHeader(header) ;
                if (strncmp(fileExtension, "N1", 2)) {
                    if (!strncmp(fileExtension, "E1", 2)) {
                        sprintf(info->platformName, "%s", "ERS1") ;
                    }
                    else {
                        sprintf(info->platformName, "%s", "ERS2") ;
                    }
                }

                /* Generate output path */
                if (!outputFilePath) {
                    outputFilePath = initStringWith3Strings(outputDirectory, "/", info->acquisitionDate) ;
                }
                
                /* Create CSL directory structure at indicated path */
                thisImage = createCSLDirectoryStructureAtPath(outputFilePath, NULL) ;
                free(outputFilePath) ;
                outputFilePath = NULL ;

                printf("\nReading/saving image: %s\n", thisImage->imageDirectoryPath) ;
                
                /* Copy header to destination directory */
                copyEnviSATHeadersToHeadersDirectory(inputPath, thisImage, header) ;
                
                /* Manage precise orbit if possible and save corrected infoImage */
                if (info->sensorID == __ENVISAT__ && DORISDir) {
                    managePrecisesOrbitsFor(thisImage, DORISDir) ;
                }
                else {
                    /* Save infoImage as such */
                    aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
                    saveInfoImage(info, aPath) ;
                    free(saveInfoKmlInDir(info, thisImage->infoDirectoryPath)) ;
                    free(aPath) ;
                }
                freeInfoImage(info) ;

                /* Read and save data */
                readAndConvertEnviSATSLCDataInto(thisImage, header, inputPath, isAP) ;
           }
        }
        free(inputPath) ;
    }

    free(inputDirectory) ;
    free(outputDirectory) ;

    
    time(&endTime) ;
    duration(startTime, endTime) ;
    return (0) ;
}


void EnviSATDataReaderHelp()
{
    printf("EnviSatDataReader usage:\n") ;
	printf("\nThis routine will read EnviSAT SLC data format and save it in CSL format.\n\n") ;
    printf("1- EnviSatDataReader /inputDir /outputDir [-o /DORIS_DirectoryPath]\n") ;
	printf("2- EnviSATDataReader </pathTo/parameterFile> [-create] [-o <DORIS_DirectoryPath>] [-r]\n") ;
	printf("If adding \"-create\" command line parameter, an example parameter file\nwill be created at indicated path.\n") ;
    printf("\nIf available, the directory containing DORIS precise orbit state vectors may be given after -o option") ;
    printf("\nThis <DORIS_DirectoryPath> must contain the DOR_VOR_AX... files as provided by CNES") ;
    printf("\ni.e., with a ./vor_gdr_c/<yyyy><mm> or a ./vor_gdr_d/<yyyy><mm> sub directory structure") ;
    printf("\n<DORIS_DirectoryPath> can be set using the ENVISAT_PRECISES_ORBITS_DIR environment variable or given using the -o option") ;
    printf("\n\nIf using the -r option, ROI_PAC data format will be considered") ;
    printf("In which case, the path to the EnviSAT data is the path to the \nROI_PAC directory containing both the .slc and the .rsc data files */") ;
	exit(0) ;
}


void createEnviSATDataReaderParameterFileAtPath(int argc, const char * argv[])
{
	keyValue *parameterList ;
    char *EnviSATPrecisesOrbitsDir ;
	
	parameterList = allocAKeyValuePair() ;
	setStringValForKeyIn(parameterList, "EnviSATDataReader parameter file", "") ;
	setStringValForKeyIn(parameterList, "********************************", "") ;
	setStringValForKeyIn(parameterList, "PathToEnviSATDataFile", "Path to EnviSAT data file (or path to directory in case of ROI_PAC focused EnviSAT data") ;
	setStringValForKeyIn(parameterList, "outputFilePath", "Path to output image in CSL format") ;
    
    if ((EnviSATPrecisesOrbitsDir = getenv("ENVISAT_PRECISES_ORBITS_DIR")) == NULL) {
        if ((EnviSATPrecisesOrbitsDir = getNextArgument(argc, argv, "-o")) == NULL) {
            setStringValForKeyIn(parameterList, "DORIS_DirectoryPath", "EnviSAT precises orbits directory") ;
        }
        else {
            setStringValForKeyIn(parameterList, EnviSATPrecisesOrbitsDir, "EnviSAT precises orbits directory") ;
        }
    }
    else {
        setStringValForKeyIn(parameterList, EnviSATPrecisesOrbitsDir, "EnviSAT precises orbits directory") ;
    }

	writeParameterFileAtPath(parameterList, (char *)argv[1]) ;
    freeKeyValueList(parameterList) ;
    
	exit(0) ;
}
