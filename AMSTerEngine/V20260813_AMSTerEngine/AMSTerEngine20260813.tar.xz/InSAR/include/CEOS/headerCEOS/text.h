
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Volume Directory File: File Text record */struct text       {                          /*   byte       */struct rec_header	header ;       char           A_E_flag[2];               /*   13         */       char           cflag_2[2];                /*   15         */       char           prod_type_id[40];          /*   17         */       char           prod_creat_loc_date[60];   /*   57         */       char           phys_vol_id[40];           /*   117          */       char           scene_id[40];              /*   157           */       char           scene_loc[40];             /*   197           */       char           spare_20[20];              /*   237           */       char           spare_104[104];            /*   257           */    }   ;