
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*** NEW VERSION WRITTEN IN THE DATE 26-1-1994 ***/

struct dss {
struct rec_header 	header ;
char    dss_rec_seq_num[4] ;		/*dss record sequence number (1)*/
char   chan_ind[4];			/*sar channel indicator (1)*/
char   reserved1[16] ;			/* scene identifier*/
char 	scene_number[32] ;
char    input_scene_center_time[32];
char    spare1[16];
char    center_lat[16];
char    center_long[16];
char    center_heading[16];
char    ellipsoid_designator[16];
char    ellipsoid_semimajor_axis[16];
char    ellipsoid_semiminor_axis[16];
char    earth_constant[16];
char    spare2[16];
char    ellipsoid_j2[16];
char    ellipsoid_j3[16];
char    ellipsoid_j4[16];
char    spare[16];
char    reserved_new[16];
char	scene_centre_line_number[8];
char    scene_centre_pixel_number[8];
char    scene_length[16];
char    scene_width[16];
char    spare3[16];

/* General Mission - Sensor Parameters */
char     nchan[4];
char     spare4[4];
char    mission_identifier[16];
char    sensor_id_and_mode[32];
char    orbit_number[8];
char    lat_nadir_center[8];
char    long_nadir_center[8];
char    heading_nadir_center[8];
char    clock_angel[8];
char    incidence_angle_center[8];
char    radar_freq[8];
char    radar_wavelength[16];
char    motion_compensation[2];
char    range_pulse_code_specifier[16];
char    range_pulse_amplitude_const[16];
char    range_pulse_amplitude_lin[16];
char    range_pulse_amplitude_quad[16];
char    range_pulse_amplitude_cube[16];
char    range_pulse_amplitude_quart[16];
char    range_pulse_phase_const[16];
char    range_pulse_phase_lin[16];
char    range_pulse_phase_quad[16];
char    range_pulse_phase_cube[16];
char    range_pulse_phase_quart[16];
char     chirp_extraction_index[8];
char    spare5[8];
char    sampling[16];
char    range_gate_early_edge_start_image[16];
char    range_pulse_length[16];
char    reserved2[4];
char    range_compressed_flag[4];
char    reserved3[32];
char    quantisation_in_bits[8];
char    quantizer_descriptor[12];
char    dc_bias_i[16];
char    dc_bias_q[16];
char    gain_imbalance[16];
char    spare6[32];
char    reserved4[16];
char    antenna_mech_bor[16];
char    reserved5[4];
char    nominal_prf[16];
char    reserved6[32];

/* Sensor Specific Parameters */
char    satelite_encoded_binary_time[16];
char    satelite_clock_time[32];
char    satelite_clock_increment[8];
char    spare7[8];

/* General Processing Parameters */
char    processing_facility_identifier[16];
char    processing_system_id[8];
char    processing_version_id[8];
char    reserved7[32];
char    product_type_id[32];
char    alg_id[32];
char    nlooks_az[16];
char    neff_looks_range[16];
char    bandwidth_look_az[16];
char    bandwidth_look_range[16];
char    total_look_bandwidth_az[16];
char    total_look_bandwidth_range[16];
char    w_func_designator_az[32];
char    w_func_designator_range[32];
char    data_input_source[16];
char    nom_res_3db_range[16];
char    nom_res_az[16];
char    reserved8[32];
char    a_track_dop_freq_const_early_image[16];
char    a_track_dop_freq_lin_early_image[16];
char    a_track_dop_freq_quad_early_image[16];
char    spare8[16];
char    c_track_dop_freq_const_early_image[16];
char    c_track_dop_freq_lin_early_image[16];
char    c_track_dop_freq_quad_early_image[16];
char    time_direction_along_pixel[8];
char    time_direction_along_line[8];
char    a_track_dop_freq_rate_const_early_image[16];
char    a_track_dop_freq_rate_lin_early_image[16];
char    a_track_dop_freq_rate_quad_early_image[16];
char    spare9[16];
char    c_track_dop_freq_rate_const_early_image[16];
char    c_track_dop_freq_rate_lin_early_image[16];
char    c_track_dop_freq_rate_quad_early_image[16];
char    spare10[16];
char    line_content_indicator[8];
char    clut_lock_flag[4];
char    autofocussing_flag[4];
char    line_spacing[16];
char    pixel_spacing_range[16];
char    range_compression_designator[16];
char    spare11[32];
char    zero_dop_range_time_f_pixel[16];
char    zero_dop_range_time_c_pixel[16];
char    zero_dop_range_time_l_pixel[16];
char    zero_dop_az_time_f_pixel[24];
char    zero_dop_az_time_c_pixel[24];
char    zero_dop_az_time_l_pixel[24];
} ;
