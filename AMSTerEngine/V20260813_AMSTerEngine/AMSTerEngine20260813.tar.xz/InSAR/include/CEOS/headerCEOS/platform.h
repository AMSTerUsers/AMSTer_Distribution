
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#if !defined(STATE_VECTOR_STRUCT)
#define STATE_VECTOR_STRUCT

struct state_vec {
	char x[22] ;
	char y[22] ;
	char z[22] ;
	char vx[22] ;
	char vy[22] ;
	char vz[22] ;
} ;

#endif
struct platform {
struct rec_header 	header ;
char    reserved1[128];
char    num_data_points[4];
char    year_of_data_points[4];
char    month_of_data_points[4];
char    day_of_data_points[4];
char    day_of_data_points_in_year[4];
char 	sec_of_day_of_data[22];
char    data_points_time_gap[22];
char    ref_coord_sys[64];
char    greenwhich_mean_hour_angle[22];
char    a_track_pos_err[16];
char    c_track_pos_err[16];
char    radial_pos_err[16] ;
char    reserved2[48];
};
