
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* * structure for mph record */#if !defined(MPH)#define MPHstruct mph_des    {                              /*              */struct rec_header 	header ;	char           prod_id[17];               /*              */	char           prod_type ;                /*              */	char           spacecraft;                /*              */	char           sat_subpoint_UTC[24];      /*              */	char           station_id;                /*              */	char           pcd[2];                    /*              */	char           MPH_UTC[24];               /*              */	char           SPH_size[4];                  /*              */	char           pds_recs_num[4];              /*              */	char           pds_rec_len[4];               /*              */	char           gen_subsystem;             /*              */	char           OBRC_flag;                 /*              */	char           UTC_ref_time[24];          /*              */	char           ref_bin_time[4];              /*              */	char           sat_clock_step[4];            /*              */	char           proc_soft_ver[8];          /*              */	char           thres_tab_ver[2];             /*              */	char           spare[2];                     /*              */	char           UTC_a_node[24];            /*              */	char           state_vec_pos[12];          /*              */	char           state_vec_vel[12];          /*              */    } ;    #endif