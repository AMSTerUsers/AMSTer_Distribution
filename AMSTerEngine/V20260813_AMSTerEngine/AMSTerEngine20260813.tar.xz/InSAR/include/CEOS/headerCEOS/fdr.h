
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Volume Directory File: Volume descriptor record */

struct fdr  {                          /*   byte       */
struct rec_header 	header ;
       char           A_E_flag[2];               /*   13         */
       char           blank_2[2];                /*   15         */
       char           for_con_doc[12];           /*   17         */
       char           sup_for_doc[2];            /*   29         */
       char           sup_for_doc_rev[2];        /*   31           */
       char           softw_rel[12];             /*   33           */
       char           phys_tape_id[16];          /*   45           */
       char           log_set_id[16];            /*   61           */
       char           vol_set_id[16];            /*   77           */
       char           tot_num_vol[2];            /*   93           */
       char           phys_vol_seq_num_f[2];     /*   95           */
       char           phys_vol_seq_num_l[2];     /*   97           */
       char           phys_vol_seq_num_c[2];     /*   99           */
       char           fir_ref_fil[4];            /*   101           */
       char           log_vol_in_set[4];         /*   105           */
       char           log_vol_in_phys_set[4];    /*   109           */
       char           log_vol_gen_date[8];       /*   113           */
       char           log_vol_gen_time[8];       /*   121           */
       char           log_vol_gen_country[12];   /*   129           */
       char           log_vol_gen_agency[8];     /*   141           */
       char           log_vol_gen_facility[12];  /*   149           */
       char           num_fil_ptr[4];            /*   161           */
       char           num_rec_vdf[4];            /*   165           */
       char           tot_log_vol_in_set[4];     /*   169           */
       char           spare_88[88];              /*   173           */
       char           blank_100[100];            /*   261           */
    }  ;

