
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 * Global declarations for CEOS structure in FD products
 */

/*
 * structure definition for File Descriptor Record Variable segment
 * in Data File
 */

struct imageryOptionDescriptor {             /*   byte       */
   unsigned char           data_nrecs[6];             /*   181           */
   unsigned char           data_rec_len[6];           /*   187           */
   unsigned char           reserved24[24];            /*   193           */
   unsigned char           nbits_sample[4];           /*   217           */
   unsigned char           nsample_group[4];          /*   221           */
   unsigned char           nbytes_group[4];           /*   225           */
   unsigned char           just[4];                   /*   229           */
   unsigned char           nchannels[4];              /*   233           */
   unsigned char           nlines_data_set[8];        /*   241           */
   unsigned char           left_bord[4];              /*   245           */
   unsigned char           groups_per_line[8];        /*   253           */
   unsigned char           right_bord[4];             /*   257           */
   unsigned char           top_bord[4];               /*   261           */
   unsigned char           bottom_bord[4];            /*   265           */
   unsigned char           interleaving_ind[4];       /*   269           */
   unsigned char           nrecs_per_line[2];         /*   271           */
   unsigned char           nrecs_per_line_channels[2];/*   273           */
   unsigned char           prefix_len[4];             /*   277           */
   unsigned char           SAR_data_bytes_per_rec[8]; /*   285           */
   unsigned char           suffix_len[4];             /*   289           */
   unsigned char           pre_suff_flag[4];          /*   293           */
   unsigned char           sample_data_locator[8];    /*   297           */
   unsigned char           channel_number_locator[8]; /*   305           */
   unsigned char           time_data_locator[8];      /*   313  */
   unsigned char           left_fill_count_locator[8];/*   321  */
   unsigned char           right_fill_count_locator[8]; /* 329 */
   unsigned char           pad_pixels_indicator[4];     /* 337 */
   unsigned char           blanks_28[28];               /* 341 */
   unsigned char           data_quality_code_locator[8];/* 369 */
   unsigned char           cal_information_locator[8];  /* 377 */
   unsigned char           gain_values_locator[8];      /* 385 */
   unsigned char           bias_vaIues_locator[8];      /* 393 */
   unsigned char           data_format_type_id[28];   /*   401           */
   unsigned char           data_format_type_code[4];  /*   429           */
   unsigned char           left_fill_bits[4];         /*   433           */
   unsigned char           right_fill_bits[4];        /*   437           */
   unsigned char           max_pixel_data_range[8];   /*   441           */
   unsigned char           spare[11196];          /*   449           */
} ;
	
struct rawFileDescriptorRecord {
	struct fdr_fix_seg		fixedSegment ;
	struct imageryOptionDescriptor	imageryOption ;
} ;
