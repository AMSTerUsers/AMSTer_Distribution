
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  signalDataRecord.h
 *  ersRaw2SLC
 *
 *  Created by Dominique Derauw on 30/06/05.
 *  Copyright 2005 Dominique Derauw. All rights reserved.
 *
 */

struct rawSignalDataRecord {
	struct rec_header 	header ;
	
/* General information */	
	unsigned char	imageDataLineNumber[4] ;
	unsigned char	dataRecordIndex[4] ;
	unsigned char	countOfLeftFillPixels[4] ;
	unsigned char	countOfDataPixels[4] ;
	unsigned char	countOfRightFillPixels[4] ;
	
/* Sensor parameters */
	unsigned char	reserved1[52] ;
	unsigned char	spare1[4] ;
	unsigned char	spare2[4] ;
	unsigned char	reserved2[32] ;
	unsigned char	spare3[4] ;

/* Platform reference information */
	unsigned char	spare4[64] ;
	
/* Sensor/facility specific, auxiliary data */
	/* IDHT general header */
	unsigned char	packetCounter ;
	unsigned char	subcommutationCounter ;
	unsigned char	IDHTGeneralHeaderSourcePacket[8] ;
	
	unsigned char	fixedCode ;
	unsigned char	OGRC_OBRC_Flag ;
	unsigned char	ICUOnboardTime[4] ;
	unsigned char	activityTask[2] ;
	unsigned char	imageFormatCounter[4] ;
	unsigned char	samplingWindowStartTime[2] ;
	unsigned char	pulseRepetitionInterval[2] ;
	unsigned char	calibrationAttenuationSetting ;
	unsigned char	receiverGainAttenuationSetting ;
	unsigned char	spare5[120] ;
	unsigned char	calibrationPulse[36][2] ;
	unsigned char	sample[5616][2] ;
} ;

struct calPulse {
	unsigned	spare	: 4 ;
	unsigned	I		: 6 ;
	unsigned	Q		: 6 ;
	unsigned	spare2	: 4 ;
	unsigned	I2		: 6 ;
	unsigned	Q2		: 6 ;
} ;