
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Volume Directory File: Data File Pointer record */struct fpr       {                              /*   byte       */struct rec_header 	header ;	char           A_E_flag[2];                   /*   13         */	char           blank_2[2];                    /*   15         */	char           ref_file_num[4];               /*   17         */	char           ref_file_name[16];             /*   21         */	char           ref_file_class[28];            /*   37           */	char           ref_file_class_code[4];        /*   65           */	char           ref_file_data_type[28];        /*   69           */	char           ref_file_data_type_code[4];    /*   97           */	char           ref_file_nrecs[8];             /*   101           */	char           ref_file_1_st_reclen[8];       /*   109           */	char           ref_file_max_reclen[8];        /*   117           */	char           ref_file_reclen_type[12];      /*   125           */	char           ref_file_reclen_type_code[4];  /*   137           */	char           ref_file_vol_start_number[2];  /*   141           */	char           ref_file_vol_end_number[2];    /*   143           */	char           ref_file_frec_num_in_vol[8];   /*   145           */	char           ref_file_lrec_num_in_vol[8];   /*   153           */	char           spare_100[100];                /*   161           */	char           local_use_100[100];            /*   261           */    }  ;