
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 * Global declarations for CEOS structure in FD products
 */

/*
 * structure definition for File Descriptor Record Variable segment
 * in Data File
 */

struct data_var_seg       {                          /*   byte       */
       char           data_nrecs[6];             /*   181           */
       char           data_rec_len[6];           /*   187           */
       char           reserved24[24];            /*   193           */
       char           nbits_sample[4];           /*   217           */
       char           nsample_group[4];          /*   221           */
       char           nbytes_group[4];           /*   225           */
       char           just[4];                   /*   229           */
       char           nchannels[4];              /*   233           */
       char           nlines_data_set[8];        /*   241           */
       char           left_bord[4];              /*   245           */
       char           groups_per_line[8];        /*   253           */
       char           right_bord[4];             /*   257           */
       char           top_bord[4];               /*   261           */
       char           bottom_bord[4];            /*   265           */
       char           interleaving_ind[4];       /*   269           */
       char           nrecs_per_line[2];         /*   271           */
       char           nrecs_per_line_channels[2];/*   273           */
       char           prefix_len[4];             /*   277           */
       char           SAR_data_bytes_per_rec[8]; /*   285           */
       char           suffix_len[4];             /*   289           */
       char           pre_suff_flag[4];          /*   293           */
       char           sample_data_locator[8];    /*   297           */
       char           channel_number_locator[8]; /*   305           */
       char           time_data_locator[8];      /*   313  */
       char           left_fill_count_locator[8];/*   321  */
       char           right_fill_count_locator[8]; /* 329 */
       char           pad_pixels_indicator[4];     /* 337 */
       char           blanks_28[28];               /* 341 */
       char           data_quality_code_locator[8];/* 369 */
       char           cal_information_locator[8];  /* 377 */
       char           gain_values_locator[8];      /* 385 */
       char           bias_vaIues_locator[8];      /* 393 */
       char           data_format_type_id[28];   /*   401           */
       char           data_format_type_code[4];  /*   429           */
       char           left_fill_bits[4];         /*   433           */
       char           right_fill_bits[4];        /*   437           */
       char           max_pixel_data_range[8];   /*   441           */
	char           blanks_64[20116] ;        /*   449           */
    }  ;
