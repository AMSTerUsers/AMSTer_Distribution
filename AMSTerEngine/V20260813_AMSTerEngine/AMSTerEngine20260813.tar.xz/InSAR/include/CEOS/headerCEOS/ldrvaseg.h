
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* * Global declarations for CEOS structure in FD products *//* * structure definition for File Descriptor Record Variable segment * in Leader File ( SAR instrument ) */struct    leader_var_seg                               /* bytes   FMT*/{    char  n_data_set_summ_rec[6];                  /* 181-186  I6*/     char  data_set_summ_rec_len[6];                /* 187-192  I6*/     char  n_map_projec_rec[6];                     /* 193-198  I6*/     char  map_projec_rec_len[6];                   /* 199-204  I6*/     char  n_plat_pos_data_rec[6];                  /* 205-210  I6*/     char  plat_pos_data_rec_len[6];                /* 211-216  I6*/     char  n_att_data_rec[6];                       /* 217-222  I6*/     char  att_data_rec_len[6];                     /* 223-228  I6*/     char  n_rad_data_rec[6];						/* 229-234  I6*/     char  rad_data_rec_len[6];						/* 235-240  I6*/     char  n_rad_comp_rec[6];						/* 241-246  I6*/     char  rad_comp_rec_len[6];						/* 247-252  I6*/     char  n_data_qua_summ_rec[6];					/* 253-258  I6*/     char  data_qua_summ_rec_len[6];				/* 259-264  I6*/     char  n_data_hist_rec[6];						/* 265-270  I6*/     char  data_hist_rec_len[6];					/* 271-276  I6*/     char  n_range_spectra_rec[6];					/* 277-282  I6*/     char  range_spectra_rec_len[6];				/* 283-288  I6*/     char  n_DEM_des_rec[6];						/* 289-294  I6*/     char  DEM_des_rec_len[6];						/* 295-300  I6*/     char  n_radar_par_update_rec[6];				/* 301-306  I6*/     char  radar_par_update_rec_len[6];				/* 307-312  I6*/     char  n_annotation_data_rec[6];				/* 313-318  I6*/     char  annotation_data_rec_len[6];				/* 319-324  I6*/     char  n_detailed_proc_rec[6];					/* 325-330  I6*/     char  detailed_proc_rec_len[6];				/* 331-336  I6*/     char  n_cal_rec[6];							/* 337-342  I6*/     char  cal_rec_len[6];							/* 343-348  I6*/     char  n_GCP_rec[6];							/* 349-354  I6*/     char  GCP_rec_len[6];							/* 355-360  I6*/     char  spare_60[60];							/* 361-420  I6*/     char  n_facility_data_rec_1[6];					/* 421-426  I6*/     char  facility_data_rec_len_1[6];				/* 427-432  I6*/     char  blanks_288[288];							/* 433-720  A80*/} ;