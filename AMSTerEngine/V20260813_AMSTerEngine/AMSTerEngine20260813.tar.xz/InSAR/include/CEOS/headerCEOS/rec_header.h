
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Records header */
struct rec_header {
    char	      rec_seq_num[4];		 /*   1		 */
    unsigned char	      rec_sub_cod1;		 /*   5		 */
    unsigned char	      rec_sub_typ ;		 /*   6		 */
    unsigned char	      rec_sub_cod2;		 /*   7		 */
    unsigned char	      rec_sub_cod3;		 /*   8		 */
    char	      rec_len[4] ;			 /*   9	         */
} ;




