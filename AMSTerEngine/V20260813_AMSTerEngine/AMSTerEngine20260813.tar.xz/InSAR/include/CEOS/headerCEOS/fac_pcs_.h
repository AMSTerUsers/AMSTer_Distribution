
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include "mph.h"#include "sph.h"struct fac_pcs_type {long	      rec_seq_num;		 /*   1		 */char	      rec_sub_cod1;		 /*   5		 */char	      rec_sub_typ ;		 /*   6		 */char	      rec_sub_cod2;		 /*   7		 */char	      rec_sub_cod3;		 /*   8		 */long	      rec_len ;			 /*   9	         */char    name_of_facil_rec[64];struct mph_des	mpheader;struct sph_des	spheader;};