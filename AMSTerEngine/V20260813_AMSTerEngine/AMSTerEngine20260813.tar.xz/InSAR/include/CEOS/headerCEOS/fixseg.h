
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 * Global declarations for CEOS structure in FD products
 */

/*
 * structure definition for File Descriptor Record Fixed segment
 */

struct  fdr_fix_seg {                          /*   byte       */
struct rec_header 	header ;
	char           A_E_flag[2];               /*   13         */
	char           blank_2[2];                /*   15         */
	char           for_con_doc[12];           /*   17         */
	char           for_con_doc_rev_level[2];  /*   29         */
	char           file_des_rev_level[2];     /*   31           */
	char           softw_rel[12];             /*   33           */
	char           file_number[4];            /*   45           */
	char           file_name[16];             /*   49           */
	char           rec_seq_loc_type_flag[4];  /*   65           */
	char           seq_number_loc[8];         /*   69           */
	char           seq_number_field_length[4];/*   77           */
	char           rec_code_loc_type_flag[4]; /*   81           */
	char           rec_code_loc[8];           /*   85           */
	char           rec_code_field_length[4];  /*   93           */
	char           rec_len_loc_type_flag[4];  /*   97           */
	char           rec_len_loc[8];            /*   101           */
	char           rec_len_field_length[4];   /*   109           */
	char           reserved_4[4];             /*   113           */
	char           reserved_segment[64];      /*   117           */
    }   ;


/*
 * structure definition for data Record Fixed segment
 * Fields name are taken from RSAT1 format description
 * Ref: RADARSAT Data product specifications
 *      RSI-GS-026 - v2 - November 7, 1997
 */
struct  dataRecordFixSegment {                      /*   byte       */
	struct rec_header 	header ;
	char line_num[4] ;				/*  13 */
	char rec_num[4] ;				/*  17 */
	char n_left_pixel[4] ;			/*  21 */
	char n_data_pixel[4] ;			/*  25 */
	char n_right_pixel[4] ;			/*  29 */
	char sensor_updf[4] ;			/*  33 */
	char acq_year[4] ;				/*  37 */
	char acq_day[4] ;				/*  41 */
	char acq_msec[4] ;				/*  45 */
	char sar_chan_ind[2] ;			/*  49 */
	char sar_chan_code[2] ;			/*  51 */
	char tran_polar[2] ;			/*  53 */
	char recv_polar[2] ;			/*  55 */
	char prf[4] ;					/*  57 */
	char spare0[4] ;				/*  61 */
	char sr_first[4] ;				/*  65 */
	char sr_mid[4] ;				/*  69 */
	char sr_last[4] ;				/*  73 */
	char fdc_first[4] ;				/*  77 */
	char fdc_mid[4] ;				/*  81 */
	char fdc_last[4] ;				/*  85 */
	char ka_first[4] ;				/*  89 */
	char ka_mid[4] ;				/*  93 */
	char ka_last[4] ;				/*  97 */
	char nadir_ang[4] ;				/* 101 */
	char squint_ang[4] ;			/* 105 */
	char null_f[4] ;				/* 109 */
	char spare1[16] ;				/* 113 */
	char geo_updf[4] ;				/* 129 */
	char lat_first[4] ;				/* 133 */
	char lat_mid[4] ;				/* 137 */
	char lat_last[4] ;				/* 141 */
	char lon_first[4] ;				/* 145 */			
	char lon_mid[4] ;				/* 149 */
	char lon_last[4] ;				/* 153 */
	char north_first[4] ;			/* 157 */
	char spare2[4] ;				/* 161 */
	char north_last[4] ;			/* 165 */
	char east_first[4] ;			/* 169 */
	char spare3[4] ;				/* 173 */
	char east_last[4] ;				/* 177 */
	char heading[4] ;				/* 181 */
	char spare4[8] ;				/* 185 */
} ;