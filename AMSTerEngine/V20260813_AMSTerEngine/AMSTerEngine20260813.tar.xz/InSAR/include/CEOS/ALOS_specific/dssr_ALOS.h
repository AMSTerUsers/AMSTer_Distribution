
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/



/*** NEW VERSION WRITTEN IN THE DATE 26-1-1994 ***/
/* Completed with ALOS Specific fields */

struct additionalAnnotations {
	char	lineNumOfAnnotationStart[8] ;	/* 2023 - 2030 */
	char	pixelNumOfAnnotationStart[8] ;	/* 2031 - 2038 */
	char	annotationText[16] ;			/* 2039 - 2054 */	
} ;

struct dss {
	struct rec_header 	header ;			/*   1 - 12  */
	char    dss_rec_seq_num[4] ;			/*  13 - 16 dss record sequence number (1) */
	char	chan_ind[4];					/*  17 - 20 sar channel indicator (1) */
	char	sceneIdentifier[32] ;			/*  21 - 52 scene identifier */
	char 	sceneDesignator[16] ;			/*  53 - 68  */
	char    input_scene_center_time[32];	/*  69 - 100 */
	char    spare1[16];						/* 101 - 116 */
	char    center_lat[16];					/* 117 - 132 */
	char    center_long[16];				/* 133 - 148 */
	char    center_heading[16];				/* 149 _ 164 */
	char    ellipsoid_designator[16];		/* 165 _ 180 */
	char    ellipsoid_semimajor_axis[16];	/* 181 - 196 */
	char    ellipsoid_semiminor_axis[16];	/* 197 - 212 */
	char    earthMass[16];					/* 213 - 228 */
	char    gravitationalConstant[16];		/* 229 - 244 */
	char    ellipsoid_j2[16];				/* 245 - 260 */
	char    ellipsoid_j3[16];				/* 261 - 276 */
	char    ellipsoid_j4[16];				/* 277 - 292 */
	char    spare[16];						/* 293 - 308 */
	char    averageTerrainHeight[16];		/* 309 - 324 */
	char	scene_centre_line_number[8];	/* 325 - 332 */
	char    scene_centre_pixel_number[8];	/* 333 - 340 */
	char    scene_length[16];				/* 341 - 356 */
	char    scene_width[16];				/* 357 - 372 */
	char    spare3[16];						/* 373 - 388 */

	/* General Mission - Sensor Parameters */
	char	nchan[4];						/* 389 - 392 */
	char	spare4[4];						/* 393 - 396 */
	char    mission_identifier[16];			/* 397 - 412 */
	char    sensor_id_and_mode[32];			/* 413 - 444 */
	char    orbit_number[8];				/* 445 - 452 */
	char    lat_nadir_center[8];			/* 453 - 460 */
	char    long_nadir_center[8];			/* 461 - 468 */
	char    heading_nadir_center[8];		/* 469 - 476 */ 
	char    clock_angel[8];					/* 477 - 484 */
	char    incidence_angle_center[8];		/* 485 - 492 */
	char    radar_freq[8];					/* 493 - 500  blank filled for ALOS !*/
	char    radar_wavelength[16];			/* 501 - 516 */
	char    motion_compensation[2];			/* 517 - 518 */
	char    range_pulse_code_specifier[16];	/* 519 - 534 */
	char    range_pulse_amplitude_const[16];/* 535 - 550 */
	char    range_pulse_amplitude_lin[16];	/* 551 - 566 */
	char    range_pulse_amplitude_quad[16];	/* 567 - 582 */
	char    range_pulse_amplitude_cube[16];	/* 583 - 598 */
	char    range_pulse_amplitude_quart[16];/* 599 - 614 */
	char    range_pulse_phase_const[16];	/* 615 - 630 */
	char    range_pulse_phase_lin[16];		/* 631 - 646 */
	char    range_pulse_phase_quad[16];		/* 647 - 662 */
	char    range_pulse_phase_cube[16];		/* 663 - 678 */
	char    range_pulse_phase_quart[16];	/* 679 - 694 */
	char	chirp_extraction_index[8];		/* 695 - 702 */
	char    spare5[8];						/* 702 - 710 */
	char    sampling[16];					/* 711 - 726 */
	char    range_gate_early_edge_start_image[16];	/* 727 - 742 */
	char    range_pulse_length[16];			/* 743 - 758 */
	char    basebandConversionFlag[4];		/* 759 _ 762 */
	char    range_compressed_flag[4];		/* 763 - 766 */
	char	receiverGainForLikePol[16] ;	/* 767 - 782 */
	char	receiverGainForCrossPol[16] ;	/* 783 - 798 */
	char    quantisation_in_bits[8];		/* 799 - 806 */
	char    quantizer_descriptor[12];		/* 807 - 818 */
	char    dc_bias_i[16];					/* 819 - 834 */
	char    dc_bias_q[16];					/* 835 - 850 */
	char    gain_imbalance[16];				/* 851 - 866 */
	char    spare6[32];						/* 867 - 898 */
	char    antennaElectronicBoresight[16];	/* 899 - 914 */
	char    antenna_mech_bor[16];			/* 915 - 930 */
	char    echoTrackerFlag[4];				/* 931 - 934 */
	char    nominal_prf[16];				/* 935 - 950 */
	char	twoWayAntennaElevationWidth[16] ;	/* 950 - 966 */
	char	twoWayAntennaAzimuthWidth[16] ;	/* 967 - 982 */

	/* Sensor Specific Parameters */
	char    satelite_encoded_binary_time[16];	/* 983 - 998 */
	char    satelite_clock_time[32];		/*  999 - 1030 */
	char    satelite_clock_increment[16];	/* 1031 - 1046 */

	/* General Processing Parameters */
	char    processing_facility_identifier[16];	/* 1047 - 1062 */
	char    processing_system_id[8];		/* 1063 - 1070 */
	char    processing_version_id[8];		/* 1071 - 1078 */
	char	processingFacilityProcessCode[16] ;	/* 1079 - 1094 */
	char	ProductLevelCode[16] ;			/* 1095 - 1110 */
	char    product_type_id[32];			/* 1111 - 1142 */
	char    alg_id[32];						/* 1143 - 1174 */
	char    nlooks_az[16];					/* 1175 - 1190 */
	char    neff_looks_range[16];			/* 1191 - 1206 */
	char    bandwidth_look_az[16];			/* 1207 - 1222 */
	char    bandwidth_look_range[16];		/* 1223 - 1238 */
	char    total_look_bandwidth_az[16];	/* 1239 - 1254 */
	char    total_look_bandwidth_range[16];	/* 1255 - 1270 */
	char    w_func_designator_az[32];		/* 1271 - 1302 */
	char    w_func_designator_range[32];	/* 1303 - 1334 */
	char    data_input_source[16];			/* 1334 - 1350 */
	char    nom_res_3db_range[16];			/* 1351 - 1366 */
	char    nom_res_az[16];					/* 1367 - 1382 */
	char	constantRadiometricParameter[16] ;		/* 1382 - 1398 */
	char	linearRadiometricParameter[16] ;		/* 1399 - 1414 */
	char    a_track_dop_freq_const_early_image[16];	/* 1415 - 1430 */
	char    a_track_dop_freq_lin_early_image[16];	/* 1431 - 1446 */
	char    a_track_dop_freq_quad_early_image[16];	/* 1447 - 1462 */
	char    spare8[16];								/* 1462 - 1478 */
	char    c_track_dop_freq_const_early_image[16];	/* 1479 - 1494 */
	char    c_track_dop_freq_lin_early_image[16];	/* 1495 - 1510 */
	char    c_track_dop_freq_quad_early_image[16];	/* 1511 - 1526 */
	char    time_direction_along_pixel[8];			/* 1527 - 1534 */
	char    time_direction_along_line[8];			/* 1535 - 1542 */
	char    a_track_dop_freq_rate_const_early_image[16];	/* 1543 - 1558 */
	char    a_track_dop_freq_rate_lin_early_image[16];		/* 1559 - 1574 */
	char    a_track_dop_freq_rate_quad_early_image[16];		/* 1575 - 1590 */
	char    spare9[16];										/* 1591 - 1606 */
	char    c_track_dop_freq_rate_const_early_image[16];	/* 1607 - 1622 */
	char    c_track_dop_freq_rate_lin_early_image[16];		/* 1623 - 1638 */
	char    c_track_dop_freq_rate_quad_early_image[16];		/* 1639 - 1654 */
	char    spare10[16];						/* 1655 - 1670 */
	char    line_content_indicator[8];			/* 1671 - 1678 */
	char    clut_lock_flag[4];					/* 1679 - 1682 */
	char    autofocussing_flag[4];				/* 1683 - 1686 */
	char    line_spacing[16];					/* 1687 - 1702 */
	char    pixel_spacing_range[16];			/* 1703 - 1718 */
	char    range_compression_designator[16];	/* 1719 - 1734 */
	char	dopplerCentreFrequencyConstantTerm[16] ;	/* 1735 - 1750 */
	char	dopplerCentreFrequencyLinearTerm[16] ;		/* 1751 - 1766 */
	
	/* Sensor specific local use segment */
	char    calibrationDataIndicator[4] ;		/* 1767 - 1770 */
	char    startLineNumAtUpperImage[8] ;		/* 1771 - 1778 */
	char    stopLineNumAtUpperImage[8] ;		/* 1779 - 1786 */
	char    startLineNumAtBottomImage[8] ;		/* 1787 - 1794 */
	char    stopLineNumAtBottoImage[8] ;		/* 1795 - 1802 */
	char	prfSwitchinIndicator[4] ;			/* 1803 - 1806 */
	char	lineLocatorOfPRFSwitching[8] ;		/* 1807 - 1814 */
	char	directionOfBeamCentre[16] ;			/* 1815 - 1830 */
	char	yawSteeringModeFlag[4] ;			/* 1831 - 1834 */
	char	parameterTableNumber[4] ;			/* 1835 - 1838 */
	char	nominalOffNadirAngle[16] ;			/* 1838 - 1854 */
	char	antennaBeamNumber[4] ;				/* 1855 - 1858 */
	char	spare11[28] ;						/* 1859 - 1886 */
	char	incidenceAngleConstantTerm[20] ;	/* 1887 - 1906 */
	char	incidenceAngleLinearTerm[20] ;		/* 1907 - 1926 */
	char	incidenceAngleQuadraticTerm[20] ;	/* 1927 - 1946 */
	char	incidenceAngleCubicTerm[20] ;		/* 1947 - 1966 */
	char	incidenceAngleFourthTerm[20] ;		/* 1967 - 1986 */
	char	incidenceAngleFifthTerm[20] ;		/* 1987 - 2006 */
	char	numberOfAnnotationPoints[8] ;		/* 2007 - 2014 */
	char	spare12[8] ;						/* 2015 - 2022 */
	struct additionalAnnotations annotation[64] ;	/* 2023 - 4070 */
	char	spare13[2] ;						/* 4071 - 4072 */
	char	systemSpecific[24] ;				/* 4073 - 4096 */
} ;
