
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* CEOS platform position data record *//* Adapted to ALOS specificities */#if !defined(STATE_VECTOR_STRUCT)#define STATE_VECTOR_STRUCTstruct state_vec {	char x[22] ;	char y[22] ;	char z[22] ;	char vx[22] ;	char vy[22] ;	char vz[22] ;} ;#endifstruct platform {	struct rec_header 	header ;			/*    1 -   12 */	char	orbitalElementDesignator[32] ;	/*   13 -   44 */	char	x0[16] ;						/*   45 -   60 */	char	y0[16] ;						/*   61 -   76 */	char	z0[16] ;						/*   77 -   92 */	char	vX0[16] ;						/*   93 -  108 */	char	vY0[16] ;						/*  109 -  124 */	char	vZ0[16] ;						/*  125 -  140 */	char    num_data_points[4];				/*  141 -  144 */	char    year_of_data_points[4];			/*  145 -  148 */	char    month_of_data_points[4];		/*  149 -  152 */	char    day_of_data_points[4];			/*  153 -  156 */	char    day_of_data_points_in_year[4];	/*  157 -  160 */	char 	sec_of_day_of_data[22];			/*  161 -  182 */	char    data_points_time_gap[22];		/*  183 -  204 */	char    ref_coord_sys[64];				/*  205 -  268 */	char    greenwhich_mean_hour_angle[22];	/*  269 -  290 */	char    a_track_pos_err[16];			/*  291 -  306 */	char    c_track_pos_err[16];			/*  307 -  322 */	char    radial_pos_err[16];				/*  323 -  338 */	char    alongTrackVelocityError[16];	/*  339 -  354 */	char    acrossTrackVelocityError[16];	/*  355 -  370 */	char    radialVelocityError[16];		/*  371 -  386 */		struct state_vec stateVector[28] ;		/*  387 - 4082 */	char	spare1[18] ;					/* 4083 - 4100 */	char	leapSecondFlag[1] ;				/* 4101 - 4101 */	char	spare2[579] ;					/* 4102 - 4680 */} ;struct attitudeDataRecord {    struct rec_header 	header ;			/*    1 -   12 */    char    numberOfAttitudeDataPoints[4] ; /*   13 -   16 */    struct attitudeData *data ;} ;struct attitudeData {    char    dayOfTheYear[4] ;               /*   17 -   20 */    char    millisecondsOfDay[8] ;          /*   21 -   28 */    char    pitchDataQualityFlag[4] ;       /*   29 -   32 */    char    rollDataQualityFlag[4] ;        /*   33 -   36 */    char    yawDataQualityFlag[4] ;         /*   37 -   40 */    char    pitch[14] ;                     /*   41 -   54 */    char    roll[14] ;                      /*   55 -   68 */    char    yaw[14] ;                       /*   69 -   82 */    char    pitchRateDataQualityFlag[4] ;   /*   83 -   86 */    char    rollRateDataQualityFlag[4] ;    /*   87 -   90 */    char    yawRateDataQualityFlag[4] ;     /*   91 -   94 */    char    pitchRate[14] ;                 /*   95 -  108 */    char    rollRate[14] ;                  /*  109 -  122 */    char    yawRate[14] ;                   /*  123 -  136 */} ;