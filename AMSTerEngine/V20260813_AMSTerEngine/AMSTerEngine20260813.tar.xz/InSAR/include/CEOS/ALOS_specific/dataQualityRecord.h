
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  dataQualityRecord.h
 *  ALOSDataReader
 *
 *  Created by Dominique Derauw on 5/12/11.
 *  Copyright 2011 Dominique Derauw. All rights reserved.
 *
 */


#ifndef DATAQUALITYRECORD
#define DATAQUALITYRECORD

struct calib {
	char nominalAbsoluteCalibration1[16] ;	/*  191 -  206 */
	char nominalAbsoluteCalibration2[16] ;	/*  207 -  222 */
	char nominalRelativeMagnitudeCalibration[16] ;	/*  223 -  238 */
	char nominalRelativePhaseCalibration[16] ;	/*  239 -  254 */
} ;
typedef struct calib nominalCalibration ;

struct misreg {
	char alongTrackMisregistration[16] ;
	char acrossTrackMisregistration[16] ;
} ;
typedef struct misreg misRegistration ;

struct dqsr {
	struct rec_header 	header ;			/*    1 -   12 */
	char sequenceNumber[4] ;				/*   13 -   16 */
	char channelIndicator[4] ;				/*   16 -   20 */
	char dateOfLastCalibrationUpdate[6] ;	/*   21 -   26 */
	char numberOfChannels[4] ;				/*   27 -   30 */
	char nominalISLR[16] ;					/*   31 -   46 */
	char nominalPSLR[16] ;					/*   47 -   62 */
	char nominalAzimuthAmbiguity[16] ;		/*   63 -   78 */
	char nominalRangeAmbiguity[16] ;		/*   79 -   94 */
	char estimatedSNR[16] ;					/*   95 -  110 */
	char actualBitErrorRate[16] ;			/*  111 -  126 */
	char nominalSlantRangeResolution[16] ;	/*  127 -  142 */
	char nominalAzimuthResolution[16] ;		/*  143 -  158 */
	char nominalRadiometricResolution[16] ;	/*  159 -  174 */
	char instantaneousDynamicRange[16] ;	/*  175 -  190 */
	nominalCalibration channelCalibration[16] ; /* 191 - 734 */
	char nominalAlongTrackPositionError[16] ;	/* 735 - 750 */
	char nominalAcrossTrackPositionError[16] ;	/* 751 - 766 */
	char nominalLineDistortion[16] ;			/* 767 - 782 */
	char nominalPixelDistortion[16] ;			/* 783 - 798 */
	char nominalSkewDistortion[16] ;			/* 799 - 814 */
	char sceneOrientationError[16] ;			/* 815 - 830 */
	misRegistration channelMisregistration[16] ;/* 831 - 1102*/
	char spare[518] ;							/* 1103 - 1620 */
} ;

typedef struct dqsr dataQualityRecordStruct ;

#endif