
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  signalDataRecord.h
 *  ALOSDataReader
 *
 *  Created by Dominique Derauw on 5/12/11.
 *  Copyright 2011 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(SIGNALDATARECORD)
#define SIGNALDATARECORD

//#define ALOS

struct sigDatRec {
	struct rec_header 	header ;			/*    1 -   12 */
	unsigned char lineIndex[4] ;						/*   13 -   16 */
	unsigned char recordIndex[4] ;					/*   17 -   20 */
	unsigned char numberOfLeftFillPixels[4] ;		/*   21 -   24 */
	unsigned char numberOfDataPixels[4] ;			/*   25 -   28 */
	unsigned char numberOfRightFillPixels[4] ;		/*   29 -   32 */
	unsigned char sensorParametersUpdateFlag[4] ;	/*   33 -   36 */
	unsigned char sceneStartYear[4] ;				/*   37 -   40 */
	unsigned char sceneStartDayOfYear[4] ;			/*   41 -   44 */
	unsigned char sceneStartMillisecondsOfDay[4] ;	/*   45 -   48 */
	unsigned char channelIndicator[2] ;				/*   49 -   50 */
	unsigned char channelCode[2] ;					/*   51 -   52 */
	unsigned char transmittedPolarizationCode[2] ;	/*   53 -   54 */
	unsigned char receivedPolarizationCode[2] ;		/*   55 -   56 */
	unsigned char prf[4] ;							/*   57 -   60 */
	unsigned char scanID[4] ;						/*   61 -   64 */
	unsigned char onBoardRangeCompressedFlag[2] ;	/*   65 -   66 */
	unsigned char pulseTypeDesignator[2] ;			/*   67 -   68 */
	unsigned char chirpLength[4] ;					/*   69 -   72 */
	unsigned char chirpConstantCoefficient[4] ;		/*   73 -   76 */
	unsigned char chirpLinearCoefficient[4] ;		/*   77 -   80 */
	unsigned char chirpQuadraticCoefficient[4] ;		/*   81 -   84 */
	unsigned char spare1[8] ;						/*   85 -   92 */
	unsigned char receiverGain[4] ;					/*   93 -   96 */
	unsigned char noughtLineFlag[4] ;				/*   97 -  100 */
	unsigned char antennaElectronicElevationAngle[4] ;	/*  101 -  104 */
	unsigned char antennaMechanicalElevationAngle[4] ;	/*  105 -  108 */
	unsigned char antennaElectronicSquintAngle[4] ;	/*  107 -  112 */
	unsigned char antennaMechanicalSquintAngle[4] ;	/*  113 -  116 */
	unsigned char slantRangeToFirstPixel[4] ;		/*  117 -  120 */
	unsigned char dataSampleDelay[4] ;				/*  121 -  124 */
	unsigned char spare2[4] ;						/*  125 -  128 */
	unsigned char platformPositionUpdateFlag[4] ;	/*  129 -  132 */
	unsigned char platformLatitude[4] ;				/*  133 -  136 */
	unsigned char platformLongitude[4] ;				/*  137 -  140 */
	unsigned char platformAltitude[4] ;				/*  141 -  144 */
	unsigned char platformGroundSpeed[4] ;			/*  145 -  148 */
	unsigned char platformXVelocity[4] ;				/*  149 -  152 */
	unsigned char platformYVelocity[4] ;				/*  153 -  156 */
	unsigned char platformZVelocity[4] ;				/*  157 -  160 */
	unsigned char platformXAcceleration[4] ;			/*  161 -  164 */
	unsigned char platformYAcceleration[4] ;			/*  165 -  168 */
	unsigned char platformZAcceleration[4] ;			/*  169 -  172 */
	unsigned char platformTrackAngle1[4] ;			/*  173 -  176 */
	unsigned char platformTrackAngle2[4] ;			/*  177 -  180 */
	unsigned char platformPitchAngle[4] ;			/*  181 -  184 */
	unsigned char platformRollAngle[4] ;				/*  185 -  188 */
	unsigned char platformYawAngle[4] ;				/*  189 -  192 */
	unsigned char firstPixelLatitude[4] ;			/*  193 -  196 */
	unsigned char middlePixelLatitude[4] ;			/*  197 -  200 */
	unsigned char lastPixelLatitude[4] ;				/*  201 -  204 */
	unsigned char firstPixelLongitude[4] ;			/*  205 -  208 */
	unsigned char middlePixelLongitude[4] ;			/*  209 -  212 */
	unsigned char lastPixelLongitude[4] ;			/*  213 -  216 */
	unsigned char spare3[68] ;						/*  217 -  284 */
	unsigned char frameCounter[4] ;					/*  285 -  288 */
	unsigned char auxiliaryData[100] ;				/*  289 -  388 */
	unsigned char spare4[24] ;						/*  389 -  412 */
} ;

typedef struct sigDatRec signalDataRecordStruct ;

#endif