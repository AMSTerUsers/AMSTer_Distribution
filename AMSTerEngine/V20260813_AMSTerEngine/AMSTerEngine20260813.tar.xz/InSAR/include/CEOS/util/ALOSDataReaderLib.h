
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ALOSDataReader.h
 *  ALOSDataReader
 *
 *  Created by Dominique Derauw on 5/12/11.
 *  Copyright 2011 Dominique Derauw. All rights reserved.
 *
 */

#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "ALOSHeaderReader.h"
#include "infoImage.h"
#include "infoImageALOS.h"
#include "byteSwap.h"
#include "counters.h"
#include "vectors.h"
#include "ALOSAttitudeDataInterpolation.h"
#include "dopplerAnalysis.h"
#include "complexCalculus.h"

CSVStruct *ALOSDataReader(CSVStruct *csv) ;
void ALOSDataReaderHelp(void) ;
void createALOSDataReaderParameterFileAtPath(char *aPath) ;
void copyALOSHeadersToHeadersDirectory(keyValue *parameterList, CSLImage *thisImage)  ;
ALOSHeader *readALOSHeader(keyValue *parameterList) ;
void saveALOSInfoImageInCSLImage(SLCImageInfo *info, CSLImage *thisImage) ;
void readAndConvertALOS_SLCData(SLCImageInfo *info, CSLImage *thisImage, ALOSHeader *header, keyValue *parameterList) ;
void freeALOSHeader(ALOSHeader *header) ;
void verifyALOSParametersList(keyValue *parametersList) ;

