
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  CEOSUtils.h
//  Some small functions to clean a few old CEOS reader programs
//
//  Created by Dominique Derauw on 19/03/2021.
//  Copyrights SAREOS - Dominique Derauw
//
//

#if !defined _CEOS_UTILS_
#define _CEOS_UTILS_
#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "readASCII_Val.h"
#include "byteSwap.h"


/* Level 1 headers */
#include "rec_header.h"
#include "fdr.h"
#include "fpr.h"
#include "mph.h"
#include "sph.h"
#include "text.h"
#include "fac_gen_type.h"
#include "fixseg.h"
#include "map.h"

#include "datvaseg.h"
#include "dssr.h"
#include "ldrvaseg.h"
#include "platform.h"

/* Level 0 headers */
#if defined(INCLUDE_LEVEL0_HEADERS)
#include "rawDataFileDescriptorRecord.h"
#include "rawDataRecord.h"
#endif

/* #include "fac_pcs_.h" */
struct CEOS_VDF {
	int numberOfFilePointerRecords ;
    struct fdr			fdr ;
    struct fpr			*fpr ;
    struct text			text ;
} ;

struct CEOS_LF {
    struct fdr_fix_seg		fdr_fix ;
    struct leader_var_seg	fdr_var ;
    struct dss			*dss ;
    struct map			*map ;
    struct state_vec 	*state ;
    struct platform		*platform ;
    int nfacility ;
    struct fac_gen_type	**facility ;
} ;

struct CEOS_IMOF {
    struct fdr_fix_seg	imof_fix ;
    struct data_var_seg imof_var ;
    struct dataRecordFixSegment *dataRecordHeader ;       /* Added march 19, 2021 to cope with RSAT1 */
} ;

typedef struct {
	struct CEOS_VDF *vdf ;
	struct CEOS_LF *lf ;
	struct CEOS_IMOF *imof ;
} CEOSHeader ;


/* definition de fonctions */
struct CEOS_LF *allocCEOSLeaderFileStruct()  ;

struct CEOS_VDF	*readCEOS_VDF(char *) ;
struct CEOS_LF	*readCEOS_LF(char *) ;
struct CEOS_IMOF	*readCEOS_IMOF(char *IMOFFilePath) ;
void freeStructCEOS_VDF(struct CEOS_VDF *) ;
void freeStructCEOS_LF(struct CEOS_LF *) ;
void free_vect_state(struct state_vec *, int) ;
struct state_vec *vect_state(int ncl, int nch) ;

void locateRSAT1PlatformRecordInFile(rawFileDescriptor *leaderFile) ;


#endif