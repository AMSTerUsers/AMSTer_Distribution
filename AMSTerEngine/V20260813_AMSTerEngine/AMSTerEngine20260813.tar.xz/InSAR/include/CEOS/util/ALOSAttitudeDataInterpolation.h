
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  ALOSAttitudeDataInterpolation.h
//  ALOSDataReader
//
//  Created by Dominique Derauw on 22/10/12.
//
//

#ifndef ALOSDataReader_ALOSAttitudeDataInterpolation_h
#define ALOSDataReader_ALOSAttitudeDataInterpolation_h

#include "pourtous.h"
#include "infoImage.h"
#include "vectors.h"
#include "matrix.h"
#include "resmat.h"
#include "ALOSHeaderReader.h"
#include "readASCII_Val.h"

void ALOSAttitudeDataInterpolation(struct infoImage *info, struct attitudeDataRecord *attitudeRecord) ;


#endif
