
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ERSDataReader.h
 *  ERSDataReader
 *
 *  Created by Dominique Derauw on 10/10/11.
 *  Copyright 2011 CSL. All rights reserved.
 *
 */


#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "CEOSUtils.h"
#include "infoImage.h"
#include "infoImageERS.h"
#include "byteSwap.h"
#include "counters.h"
#include "vectors.h"
#include "rawFileLib.h"
#include "fileAccessLib.h"
#include "stringLib.h"

void usage(void) ;
void createParameterFileAtPath(char *aPath) ;
void copyHeadersToHeadersDirectory(keyValue *parameterList, CSLImage *thisImage)  ;
CEOSHeader *readCEOSHeaders(keyValue *parameterLis) ;
void createInfoTextFileFromHeaderFor(CSLImage *thisImage, CEOSHeader *header) ;
void readAndConvertERSSLCDataInto(CSLImage *thisImage, CEOSHeader *header, keyValue *parameterList) ;
void freeCEOSHeader(CEOSHeader *header) ;
void verifyParametersList(keyValue *parametersList) ;

