
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  lecheader.h
 *  lecheader
 *
 *  Created by Dominique Derauw on Mon Feb 18 2002.
 *  Copyright (c) 2001 Dominique Derauw All rights reserved.
 *
 */
#if !defined(ALOS_CEOS_HEADER_READER)
#define ALOS_CEOS_HEADER_READER

#include "pourtous.h"
#include "rawFileLib.h"
#include "readASCII_Val.h"
#include "byteSwap.h"

/* Level 1 headers */
#include "rec_header.h"
#include "fdr.h"
#include "fpr.h"
#include "mph.h"
#include "sph.h"
#include "text.h"
#include "fac_gen_type.h"
#include "fixseg.h"
#include "map.h"

#include "datvaseg_ALOS.h"
#include "dssr_ALOS.h"
#include "ldrvaseg_ALOS.h"
#include "platform_ALOS.h"
#include "signalDataRecord.h"
#include "dataQualityRecord.h"


/* #include "fac_pcs_.h" */
struct ALOS_VDF {
	int numberOfFilePointerRecords ;
    struct fdr			fdr ;
    struct fpr			*fpr ;
    struct text			text ;
} ;

struct ALOS_LF {
    struct fdr_fix_seg		fdr_fix ;
    struct leader_var_seg	fdr_var ;
    struct dss			*dss ;
    struct map			*map ;
    struct state_vec 	*state ;
    struct platform		*platform ;
    struct attitudeDataRecord     *attitude ;
	dataQualityRecordStruct *dataQualityRecord ;
} ;

struct ALOS_IMOF {
    struct fdr_fix_seg	imof_fix ;
    struct data_var_seg imof_var ;
	signalDataRecordStruct *signalDataRecord ;
} ;

typedef struct {
	struct ALOS_VDF *vdf ;
	struct ALOS_LF *lf ;
	struct ALOS_IMOF **imof ;
} ALOSHeader ;


/* definition de fonctions */
struct ALOS_VDF	*readALOS_VDF(char *) ;
struct ALOS_LF	*readALOS_LF(char *) ;
struct ALOS_IMOF	*readALOS_IMOF(char *IMOFFilePath) ;
void freeStructALOS_VDF(struct ALOS_VDF *) ;
void freeStructALOS_LF(struct ALOS_LF *) ;
void free_vect_state(struct state_vec *, int) ;
struct state_vec *vect_state(int ncl, int nch) ;

#endif
