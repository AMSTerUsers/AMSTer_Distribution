
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  H_A_Alpha.h
 *  cohOpt
 *
 *  Created by Dominique Derauw on 25/03/05.
 *  Copyright (c) 2005 Dominique Derauw. All rights reserved.
 *
 */

#include "pourtous.h"
#include "complexCalculus.h"

#if !defined(H_A_ALPHA)
#define H_A_ALPHA

float	entropyForEigenValues(float *eigenValue) ;
float	anisotropyForEigenValues(float *eigenValue) ;
float	alphaForEigenValuesAndEigenVectors(float *eigenValue, complexFloat **eigenVector) ;
void 	initT(complexFloat **) ;
void	swapFloatValues(float *val1, float *val2) ;

#endif

/* Remark : 
 * Entropy must be calculated before Alpha because the Entropy calculation includes 
 * normalisation of eigen values with respect to theire sum 
 *
 */
