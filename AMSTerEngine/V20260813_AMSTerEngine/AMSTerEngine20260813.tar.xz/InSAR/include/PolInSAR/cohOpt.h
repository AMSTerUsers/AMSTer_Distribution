
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  cohOpt.h
 *  cohOpt
 *
 *  Created by Dominique Derauw on Wed Mar 23 2005.
 *  Copyright (c) 2005 Dominique Derauw. All rights reserved.
 *
 */

#include "pourtous.h"
#include "jacobiComplexe.h"
#include "complexCalculus.h"
#include "targetVector.h"
#include "movingAverageTool.h"
#include "coherencyMatrix.h"
#include "H_A_Alpha.h"
#include "paramInSAR.h"
#include "orbitalPhase.h"

#if !defined(COHOPT)
#define COHOPT

#define EIGENVALMIN 0
#define eps 1.E-15

#define NCOLS 80

typedef struct {
	rawFileSet	*track1, *track2, *optimizedCoherences, *orbitalPhase ;
	char	calculateH_A_Alpha[4] ;
	char	calculateInterferograms[4] ;
	char	calculateModuleImages[4] ;
	char	computeOrbitalPhase ;
	int		boxAverageX ;
	int		boxAverageY ;
	int		movingAverageX ;
	int		movingAverageY ;
	InSARParametersStruct *pInSAR ;
} interfaceParameters ;

typedef struct {
	rawFileSet	*track1, *track2, *optimizedCoherences, *orbitalPhase, *HAA1, *HAA2, *interferograms, *moduleImages1, *moduleImages2 ;
	char	calculateH_A_Alpha ;
	char	calculateInterferograms ;
	char	calculateModuleImages ;
	char	isTopographicPhaseGiven ;
	char	computeOrbitalPhase ;
	int		boxAverageX ;
	int		boxAverageY ;
	int		movingAverageX ;
	int		movingAverageY ;
	int		currentLine ;
	float	*v1, *v2, **coh, **H_A_Alpha1, **H_A_Alpha2, norme ;
	float	**interferometricPhases, **modules1, **modules2, *mod, *oph ;
	complexFloat **optimumScatteringMechanism1, **optimumScatteringMechanism2 ;
	complexFloat **complexInterferograms, **complexReferencePhases, *diag ;
	complexFloat **piM, **piT, **M ;
	complexFloat **MT11, **MT22, **MO12, **MO12T, **iMT11, **iMT22 ;
	targVectObject	*k1, *k2 ;
	coherencyMatrixObject *T11, *T22, *O12 ;
	mAvObject ***movingAverageOnModules, *movingAverageOnOrbitalPhase ;
	InSARParametersStruct *pInSAR ;
} cohOpt ;

int PolInSARProductsGeneration(CSVStruct *csv) ;
void polInSARGenHelp(void) ;

void displayParameters(cohOpt *pp, FILE *fout) ;
interfaceParameters	*createInterfaceParameters(InSARParametersStruct *pInSAR) ;
void openInputFiles(cohOpt *p) ;
void openOutputFiles(cohOpt *p) ;
void freeCohOpt(cohOpt *pp) ;
rawFileSet *allocFilesParameters(int N) ;
void freeFilesParameters(rawFileSet *p) ;
cohOpt *initCohOpt(interfaceParameters *p) ;


void coherenceOptimization(cohOpt *pp) ;
void boxAveragingOnCoherencyMatricesT11T22AndO12(cohOpt *pp) ;
void initMovingAverageOnCoherencyMatrices(cohOpt *pp) ;
void piMatrixCalculation(cohOpt *pp) ;
void getOptimizedCoherencesForIndex(int index, cohOpt *pp) ;
void getOptimizedComplexInterferogramsForIndex(int index, cohOpt *pp) ;
void transpose3X3Matrix(complexFloat **M1, complexFloat **M2) ;
void transpose3X3MatrixInPlace(complexFloat **M) ;
void inverseOfSquareRootOfEigenValues(float *eigenValues, float *v) ;
void multiplyMatrixByDiag(complexFloat **M, float *v) ;
void multiplyMatrixByMatrixInPlace(complexFloat **M1, complexFloat **M2) ;
void multiplyMatrixByMatrix(complexFloat **M1, complexFloat **M2, complexFloat **M3) ;
void diagOfMatrixProduct(complexFloat **M1, complexFloat **M2, complexFloat *diag) ;
void invert3X3Matrix(complexFloat **M, complexFloat **iM) ;
void resetFloatVectorToZero(float *v, int iMin, int iMax) ;
void resetComplexFloatVectorToZero(complexFloat *v, int iMin, int iMax) ;
void boxAveragingOfH_A_AlphaForIndex(int index, cohOpt *pp) ;
void saveH_A_Alpha(cohOpt *pp) ;
void movingAverageOnModuleImages(cohOpt *pp) ;
void movingAverageOnOrbitalPhase(cohOpt *pp) ;
void computeOrbitalPhaseLine(cohOpt *pp) ;
void boxAveragingOfModulesForIndex(int index, cohOpt *pp) ;
void saveModules(cohOpt *pp) ;
void printfMatrice(complexFloat **M) ;
void invert3X3Matrix(complexFloat **M, complexFloat **iM) ;
void invert3X3HMatrix(complexFloat **M, complexFloat **iM) ;
void addRandEpsilonTo3X3MatrixElement(complexFloat **M) ;
void cplx_diag_mat3(complexFloat **T, complexFloat **V, float *L) ;


#endif
