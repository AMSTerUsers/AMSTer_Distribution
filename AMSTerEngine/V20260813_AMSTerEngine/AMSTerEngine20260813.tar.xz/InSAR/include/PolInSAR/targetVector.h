
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  targetVector.h
 *  decPol
 *
 *  Created by Dominique Derauw on 11/03/05.
 *  Copyright 2005 __MyCompanyName__. All rights reserved.
 *
 */

#include "pourtous.h"
#include "complexTypes.h"
#include "complexCalculus.h"
#include "matrix.h"
#include "vectors.h"
#include "rawFileLib.h"

#if !defined(TARGETVECTOR)
#define TARGETVECTOR

typedef struct {
	FILE *fHH, *fVV, *fXX, *fHV, *fVH ;         /* Input files */
	int currentLine, numberOfFiles ;
    int dimX, dimY ;                            /* Input files dimensions */
	complexFloat	*HH, *VV, *XX, *HV, *VH, **k ;
    frameType *aoi ;
} targVectObject ;

targVectObject *allocTargetVectorObject(void) ;
void registerFilesForTargetVector(rawFileSet *track, targVectObject *target) ;
complexFloat **kVectorsForLine(int line, targVectObject *target) ;
void freeTargetVectorObject(targVectObject *target) ;
void outerProduct(complexFloat *k1, complexFloat *k2, complexFloat **T) ;


#endif
