
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  coherencyMatrix.h
 *  cohOpt
 *
 *  Created by Dominique Derauw on 24/03/05.
 *  Copyright 2005 Dominique Derauw. All rights reserved.
 *
 */

#include "pourtous.h"
#include "vectors.h"
#include "matrix.h"
#include "matrixPile.h"
#include "targetVector.h"
#include "movingAverageTool.h"

#if !defined(COHERENCYMATRIX)
#define COHERENCYMATRIX

typedef struct {
	FILE	*anOutputFile ;
	char	name[10] ;
	int		boxAverageX ;
	int		boxAverageY ;
	int		movingAverageX ;
	int		movingAverageY ;
	int				currentIndex ;
	float			*eigenValues ;
	complexFloat	**eigenVectors ; 
	complexFloat	**MT, ***MC ;
	targVectObject	*k1, *k2 ;
	mAvObject		***mAv ;
} coherencyMatrixObject ;

coherencyMatrixObject *allocAndInitCoherencyMatrixObject(char *name, targVectObject *k1, targVectObject *k2, int mAvX, int mAvY, int bAvX, int bAvY) ;
void freeCoherencyMatrixObject(coherencyMatrixObject *cOb) ;
complexFloat **getAveragedCoherencyMatrixAtIndex(int index, coherencyMatrixObject *cOb) ;
void movingAverageOnCoherencyMatrix(coherencyMatrixObject *cOb) ;
void movingAverageOnCoherencyMatrixUpperTriangle(coherencyMatrixObject *cOb) ;


#endif
