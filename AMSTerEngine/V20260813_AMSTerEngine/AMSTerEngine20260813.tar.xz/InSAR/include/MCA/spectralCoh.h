
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  spectralCoh.h
//  spectralCoh
//
//  Created by Dominique Derauw on 26/05/16.
//  Copyright (c) 2016 Dominique Derauw. All rights reserved.
//

#ifndef spectralCoh_spectralCoh_h
#define spectralCoh_spectralCoh_h

#include "MCA.h"
#include "paramInSAR.h"

void usage(int argc) ;
void createSpectralCohParameterFileAtPath(char *aPath) ;
void verifySpectralCohDirectoryStructure(keyValue *p) ;
void spectralCoherenceProcessingOfSubViews(bandSplitStruct *bsp, keyValue *p) ;
void coherenceEstimator(InSARParametersStruct *p, int saveIntensityImage) ;

#endif
