
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  insarProductGeneration.h
 *  MCA
 *
 *  Created by Dominique Derauw on 27/04/09.
 *  Copyright 2009 Dominique Derauw. All rights reserved.
 *
 */


#if !defined(INSAR_PROCESSING)
#define INSAR_PROCESSING

#include "MCA.h"
#include "initMCA.h"
#include "subViewSplittingLib.h"
#include "incomod.h"

/* Function prototypes */ 
int SBInSAR (CSVStruct *csv) ;
bandSplitStruct *masterImageSubViewsSplitting(keyValue *SBInSARParams, InSARParametersStruct *pInSAR, char processingStep) ;
bandSplitStruct *slaveImageSubViewsSplitting(keyValue *p, InSARParametersStruct *pInSAR, char processingStep) ;
void SBInSARProcessingOfSubViews(bandSplitStruct *bspMaster, bandSplitStruct *bspSlave, InSARParametersStruct *pInSAR) ;
void SBInSARCoreProcess(InSARParametersStruct *pInSAR) ;
void verifySBInSARDirectoryStructureAtPath(char * rootWorkingDirectory) ;
void SBInSARHelp(void) ;

#endif
