
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  subViewSplittingLib.h
 *  rangeSubViewsSplitting
 *
 *  Created by Dominique Derauw on 14/11/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */
#if !defined(SUBVIEWSPLITTING)
#define SUBVIEWSPLITTING

#include "initMCA.h"
#include "SBInSARIOLib.h"
#include "complexCalculus.h"
#include "counters.h"

void subViewsSplitting(bandSplitStruct *bsp) ;
void transferBlocToFourierDataSpace(bandSplitStruct *bsp) ;
void transferFourierDataSpaceToBloc(FourierWorld *Fourier, dataStruct *anImage) ;
//void transferFourierFilteredDataSpaceToBloc(FourierWorld *Fourier, dataStruct *anImage) ;
void transferFourierFilteredDataSpaceToBloc(bandSplitStruct *bsp, int k, int dj) ;
void deHamming(FourierWorld *Fourier)  ;

#endif

