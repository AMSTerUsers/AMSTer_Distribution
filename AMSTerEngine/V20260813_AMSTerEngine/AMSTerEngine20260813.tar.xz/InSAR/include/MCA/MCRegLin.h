
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  MCRegLin.h
 *  MCA
 *
 *  Created by Dominique Derauw on 15/05/09.
 *  Copyright 2009 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(MCREGLIN)
#define MCREGLIN

#include "initMCA.h"
#include "subViewSplittingLib.h"
#include "matrix.h"
#include "vectors.h"
#include "rawFileLib.h"
#include "planeGeometry.h"
#include "gridMapping.h"
#include "orbitalPhase.h"
#include "sortingRoutines.h"


typedef struct {
    char isTDX ;
    char isMasterTransformActive ;
	char withWeighting ;
	char criterion ;
	int	Nsb, iX0, iY0 ;
	int	xDim, yDim ;
	int NBest, sortDim ;
	int *xSort, *ySort ;
	float *sortedCriterion ;
	int rangeReductionFactor ;
	int azimuthReductionFactor ;
	double Ax ;
	double Bx ;
	double Cx ;
    double **T13 ;                  /* Master to global master transform */
	rawFileDescriptor **interf ;
	rawFileDescriptor **masterAmplitude ;
	rawFileDescriptor **slaveAmplitude ;
	rawFileDescriptor **sigmaPhi ;
	rawFileDescriptor **coh ;
//	rawFileDescriptor *slopes ;
	rawFileDescriptor *intercepts ;
	rawFileDescriptor *R2 ;
	rawFileDescriptor *sigma ;
//	rawFileDescriptor *sigmaSlope ;
	rawFileDescriptor *sigmaIntercept ;
	rawFileDescriptor *spectralCoh ;
	rawFileDescriptor *mcaTxt ;
	rawFileDescriptor *registrationPhase ;
	rawFileDescriptor *mcaPhase ;
    gridMap *rangeCoregistrationGrid ;
} mcaLinReg ;

void multiChromaticPhaseLinearRegression(keyValue *p, InSARParametersStruct *pInSAR, bandSplitStruct *bsp) ;
mcaLinReg *allocAndInitMCALinReg(keyValue *p, InSARParametersStruct *pInSAR) ;


#endif
