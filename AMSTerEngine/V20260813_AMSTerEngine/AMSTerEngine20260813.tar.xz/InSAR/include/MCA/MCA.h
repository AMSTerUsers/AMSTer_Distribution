
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


 /*
 *  MCA.h
 *  MCA
 *
 *  Created by Dominique Derauw on 27/04/09.
 *  Copyright 2009 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(MCA)
#define MCA

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>

#include "pourtous.h"
#include "paramInSAR.h"
#include "subViewSplittingLib.h"
#include "TDXRegistration.h"

#ifndef SPECTRALCOH
#include "MCRegLin.h"
#endif

#define MAX_NUMBER_OF_OPENED_FILES 1024
#define _PERFORM_BAND_SPLIT_ 0x01
#define _PERFORM_SBINSAR_ 0x02
#define _PERFORM_MCA_ 0x04
#define _SPLIT_ONLY_ 0x08
#define _INTERBAND_COH_ 0x10 /* For spectralCoh, this will select inter band interferometric coherence calculation */
#define _SPECTRAL_COH_ 0x20


bandSplitStruct *masterImageSubViewsSplitting(keyValue *p, InSARParametersStruct *pInSAR, char processingStep) ;
bandSplitStruct *slaveImageSubViewsSplitting(keyValue *p, InSARParametersStruct *pInSAR, char processingStep) ;
void insarProcessingOfSubViews(bandSplitStruct *bspMaster, bandSplitStruct *bspSlave, keyValue *p) ;
bandSplitStruct *getBandSplitStructForCSLImage(CSLImage *anImage, keyValue *p) ;
void imageSubViewsSplitting(bandSplitStruct *bsp) ;

#endif

