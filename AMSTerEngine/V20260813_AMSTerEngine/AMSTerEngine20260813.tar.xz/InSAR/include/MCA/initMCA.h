
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  initMCA.h
 *  rangeSubViewsSplitting
 *
 *  Created by Dominique Derauw on 10/11/08.
 *  Copyright 2008 Dominique Derauw. All rights reserved.
 *
 */
 
#if !defined(INITMCA)
#define INITMCA


#include "pourtous.h"
#include "dataStruct.h"
#include "complexTypes.h"
#include "paramLib.h"
#include "rawFileLib.h"
#include "vectors.h"
#include "fft.h"
#include "paramInSAR.h"
#include "TDXRegistration.h"

//#define SPLITINGWITHAPODIZATION
#define _ADDITIONAL_DEMODULATION_ 0x02

typedef struct {
	double f0 ;		/* Radar central carrier frequency [Hz] */
	double B ;		/* Range bandwidth [Hz] */
	double fvo ;	/* Bandwith central frequency [Hz] */
	double fs ;		/* Range sampling frequency [Hz] */
	double T ;		/* Chirp length [sec] [Hz] */
	double azimuthResolution ;	/* Azimuth resolution [m] */
	double apodizationCoef ; /* Coefficient of the Hamming filter applied to the SLC data */
    double minimumSlantRange ;
    double rangeSampling ;
} sensorParams ;

typedef struct {
    char flag ;
	int Nsb ;		/* Number of sub-bands */
    int iDeltaf ;   /* Sub-bands frequency shift expressed in samples of df */
    int iBp ;       /* Sub-bands Bandwidth  expressed in samples of df */
	double Bp ;		/* Sub-bands Bandwidth */
	double deltaf ;	/* Sub-bands frequency shift */
	double *fci	;	/* Central frequencies set */
    double df ;     /* Frequency sampling */
} bandSplitParams ;

typedef struct {
    int fftDim ;
	float *filter ; /* Filter vector */
    float *deHammingFilter ; /* De-Hamming filter Vector */
    float *reHammingFilter ; /* Re-Hamming filter Vector */
	complexFloat *data ;
    complexFloat *aNullLine ;
	complexFloat **indexedData ;
	complexFloat *filteredData ;
	complexFloat **indexedFilteredData ;
	StructFFT *rangeFFT ;
} FourierWorld ;

typedef struct {
    char isGrid ;
    double **T ;
    gridMap *rangeCoregistrationGrid ;
} dataCoregistrationStruct ;

typedef struct {
	char processingStep ;
    char *workingDirectory ;
    char *subBandsDirectory ;
	dataStruct	*image ;
	dataStruct	**subImage ;
	sensorParams *sensor ;
	bandSplitParams *subBands ;
	FourierWorld *Fourier ;
    dataCoregistrationStruct *coreg ;
} bandSplitStruct ;


bandSplitStruct *allocAndInitSplitBandStruct(keyValue *p, CSLImage *inputImage, char *pol) ;
void freeBandSplitStruct(bandSplitStruct *bsp)  ;
void createSubImagesFiles(bandSplitStruct *bsp) ;
void openSubImages(bandSplitStruct *bsp) ;
void closeOpenedFilesForBandSplitStruct(bandSplitStruct *bsp) ;
void freeBandSplitStructWorkingMemory(bandSplitStruct *bsp)  ;
void verifySubBandsParameters(bandSplitStruct *bsp) ;
float *genFilter(bandSplitStruct *bsp) ;
void freeSubBandFilter(float *aFilter) ;
float *genDeHammingFilter(bandSplitStruct *bsp) ;
float *genReHammingFilter(bandSplitStruct *bsp) ;
void freeHammingFilter(float *aFilter) ;
void createSpectralCohParameterFileAtPath(char *aPath) ;
dataCoregistrationStruct *initBSCoregistrationStruct(InSARParametersStruct *pInSAR, keyValue *p) ;

#endif
