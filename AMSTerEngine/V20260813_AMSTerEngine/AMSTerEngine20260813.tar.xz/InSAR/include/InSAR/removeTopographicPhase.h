
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  removeTopographicPhase.h
//  removeTopographicPhase
//
//  Created by Dominique Derauw on 16/01/13.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#ifndef removeTopographicPhase_removeTopographicPhase_h
#define removeTopographicPhase_removeTopographicPhase_h

#define WITH_CROPPING 0x8

#include "pourtous.h"
#include "paramInSAR.h"
#include "fileAccessLib.h"
#include "counters.h"
#include "orbitalPhase.h"
#include "InSARGeoProjectionLib.h"

void    removeTopographicPhase(InSARParametersStruct *pInSAR, float deltaH) ;
void    usage(void) ;

#endif
