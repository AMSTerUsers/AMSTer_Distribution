
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  detPhUnLib.h
//  detPhUn
//
//  Created by Dominique Derauw on 30/08/12.
//  Copyright (c) 2012 Dominique Derauw. All rights reserved.
//

#ifndef detPhUn_detPhUnLib_h
#define detPhUn_detPhUnLib_h

#ifndef FIRST_PHASE_COMPONENT_EXISTS
#define FIRST_PHASE_COMPONENT_EXISTS 0x0004
#endif

#ifndef _COHERENCE_THRESHOLD_
#define _COHERENCE_THRESHOLD_          0x0010
#endif

#define _DETPHUN_                   0x1000
#define _DETPHUN_WITH_FILTERING_    0x2000
#define _DETPHUN1_                  0x4000
#define _DETPHUN2_                  0x8000

#include "pourtous.h"
#include "paramInSAR.h"
#include "fileAccessLib.h"
#include "vectors.h"
#include "matrix.h"
#include "complexTypes.h"
#include "complexCalculus.h"
#include "fft.h"
#include "counters.h"
#include "orbitalPhase.h"
#include "tileToolLib.h"
#include "phaseUnwrappingLib.h"
#include "interferogramFilteringLib.h"
#include "interpolCZT.h"
#include <fftw3.h>

typedef struct {
    char mode ;
    rawFileDescriptor *inputPhase, *outputPhase, *residualPhase ;
    int            xDim, yDim ;
    int            xDim2, yDim2 ;
    int			iterationNumber ;
    float 		**initialPhase, **currentPhase, **dephi, **coh ;
    float       **nablaX, **nablaY ;
    complexDouble *xPhaseShift, *yPhaseShift ;
    complexDouble **Z1, **Z2 ;
    double 		*qx, *qy, *qx2, *qy2 ;
    float coherenceThreshold ;
    double **input, **output ;
    double **pq2 ;
    double **sinPhi, **cosPhi, **temp1, **temp2 ;
    fftw_plan FFTPlan, IFFTPlan ;
    fftw_plan FFTPlanZ1, IFFTPlanZ1 ;
    fftw_plan FFTPlanZ2, IFFTPlanZ2 ;
} detphun ;


void detPhUnManagement(CSVStruct *csv, InSARParametersStruct *pInSAR) ;
void deterministicPhaseUnwrapping(InSARParametersStruct *pInSAR, int xTileSize, int yTileSize, int xTileBorderSize, int yTileBorderSize, int numberOfIterations) ;
void diffInterfDephi(detphun *gP) ;
void roundIt(detphun *gP) ;
void addZ1iToDephi(detphun *gP) ;
void diffTemp(detphun *gP) ;
void scalarMultiplyZ1(detphun *gP, float aFloat) ;
void divZ1Q2(detphun *gP) ;
void divZ1Qx(detphun *gP) ;
void addZ1Z2(detphun *gP)  ;
void halfPixelShiftZ0(detphun *gP) ;
void multZ1PIQx(detphun *gP) ;
void multZ2PIQy(detphun *gP) ;
void multZ1Qx(detphun *gP) ;
void multZ2Qy(detphun *gP) ;
void multZ1Qy(detphun *gP) ;
void multOutPQ2(detphun *gP) ;
void divOutPQ2(detphun *gP) ;
void multOutCosPhi(detphun *gP) ;
void multOutSinPhi(detphun *gP) ;
void multOutCst(detphun *gP, double factor) ;
void evaluateXGradient(detphun *gP) ;
void evaluateYGradient(detphun *gP) ;
void transferDataToZ(detphun *gP) ;
detphun *allocAndInitDetphunWithWindowSize(int xDim, int yDim, int unsigned flag) ;
void resetDetphun(detphun *gP) ;
void resetZ(detphun *gP) ;
void freeDetPhun(detphun *gP) ;
void removePhasePlane(detphun *gP) ;

#endif
