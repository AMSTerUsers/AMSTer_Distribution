
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* param.h
	INSAR processing parameter structure
*/
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
 */

#if !defined(PARAMINSAR)
#define PARAMINSAR

#define _TOPO_                      0x80000000
#define _DEFO_                      0x40000000
#define _CONSIDER_FILTERED_INTERF_  0x20000000
#define _CALIBRATE_IN_SIGMA0_       0x10000000
#if !defined(_VERBOSE_)
    #define _VERBOSE_               0x08000000
#endif
#define FIRST_ORDER_TPOGRAPHIC_PHASE_APPROXIMATION 0x4000000
#define _NORMALIZED_COH_            0x02000000
#define _NSB2_                      0x01000000
#define _NON_PARALLEL_ORBITS_       0x00800000
#define _SAVE_ETAD_LAYERS_			0x00400000
#define _RESAMPLE_FLOAT_FILES_		0x00200000

#include "pourtous.h"
#include "SARPlatformID.h"
#include "rawFileLib.h"
#include "fileAccessLib.h"
#include "paramLib.h"
#include "stringLib.h"
#include "CSLImageFormat.h"
#include "geoRef.h"
#include "infoImage.h"
#include "matrix.h"
#include "planeGeometry.h"
#include "approxRt.h"
#include "gridMapping.h"
#include "initInSARDirectoryStructure.h"

struct CarSARImage {
	char *filePath ;
	int	lena ;
	int	lenr ;
	double z0 ;
} ;

struct SupCom {
	int	Sbaz ;
	int	Sgra ;
	int	Shaz ;
	int	Sdra ;
} ;

struct DistSat {
	double aS ;
	double bS ;
	double S ;		/* Current Earth centre to sensor distance */
    double RT ;     /* Terrestrial radius at master scene centre */
} ;

struct baseLine {
    double **T ;    /* Affine baseline transform */
    double Bx, By ; /* Current horizontal and vertical baseline components */
	double B ;		/* Current baseline length */
	double theta ;	/* Current baseline elevation with respect to local horizontal */
    double Bperp, Bpara ; /* Perpendicular and paralleme baseline component at image centre */
    int deltaDays ;
} ;

struct ParamRadar {
	double nu ;
	double nu2 ;
    double	rangeResolutionCell ;
    double	azimuthResolutionCell ;
} ;

struct ParamRed {
	int	Faz ;
	int	Fra ;
} ;

struct ParamCor{
	int	F_lena ;
	int	F_lenr ;
	int	erraz ;
	int	errra ;
	int	Depaz ;
	int	Depra ;
	double seuilcoh ;
	double seuilaz ;
	double seuilra ;
} ;

struct CarImageRes {
	char *filePath ;
	int	lena ;
	int	lenr ;
} ;

struct ParamFiltre {
	char *filePath ;
	float sigmaz ;
	float sigmar ;
    float adaptativeFilterSmoothingFactor ;
} ;

struct ParamCoh {
	char *filePath ;
	int	coa ;
	int	cor ;
	int	spi ;
	int	lena ;
	int	lenr ;
	int medianFilterSize ;
} ;

struct	ParamConex {
	char *filePath ;
	int	lena ;
	int	lenr ;
	int	dra ;
	int	drr ;
	int	ramin ;
	int	rrmin ;
	unsigned int ech ;
	unsigned int ts ;
	float seuilnet ;
	float seuilsuiv ;
} ;

struct CarFreq {
	float PRF ;
	float ABW ;
	float a0FDC ;
	float a1FDC ;
	float a2FDC ;
} ;

typedef struct InSARParameters {
    char *whereAmI ;
	CSLImage	*masterImage ;
	CSLImage	*slaveImage ;
    CSLImage    *interpolatedSlave ;
    CSLImage    *interpolatedMaster ;

	rawFileDescriptor	*masterImageFile ;
	rawFileDescriptor	*slaveImageFile ;
	rawFileDescriptor	*interpolatedSlaveImageFile ;
	rawFileDescriptor	*interferogramFile ;
	rawFileDescriptor	*filteredInterferogramFile ;
	rawFileDescriptor	*firstPhaseComponentFile ;
	rawFileDescriptor	*secondPhaseComponentFile ;
	rawFileDescriptor	*thirdPhaseComponentFile ;
	rawFileDescriptor	*residualPhaseFile ;
	rawFileDescriptor	*coherenceFile ;
	rawFileDescriptor	*biasedCoherenceFile ;
	rawFileDescriptor	*residuesFile ;
	rawFileDescriptor	*connexionsFile ;
	rawFileDescriptor	*unwrappedPhaseFile ;
    rawFileDescriptor	*measurementFile ;
    rawFileDescriptor	*externalSlantRangeDEMFile ;
	rawFileDescriptor	*masterAmplitudeImageFile ;
	rawFileDescriptor	*slaveAmplitudeImageFile ;
	rawFileDescriptor	*phaseStandardDeviationImageFile ;
	rawFileDescriptor	*heightStandardDeviationImageFile ;
	struct infoImage	*masterInfo ;
	struct infoImage	*slaveInfo ;
	struct infoImage	*interpolatedSlaveInfo ;
    struct InSARParameters *SM2MpInSAR ;
	struct CarSARImage	ima1 ;
	struct CarSARImage	ima2 ;
	char *orbitTypes ;					/* Mainly for S1 */
	char *externalReferenceDEM ;
	char *slantRangeMask ;
	char *thresholdedSlantRangeMask ;
	char *masterPolarizationChannel ;
	char *slavePolarizationChannel ;
    char isBistaticPair ;
    char *SM2MPath ;                    /* Path to InSAR parameters for global master to master processing */
    char masterInterpolation ;
	struct SupCom		sup ;
    polygon             *aoi ;
    char *aoiKml ;
	struct DistSat		S1 ;
	struct baseLine	B ;
	struct ParamRadar	rad ;
	double **slaveAffineTransform ;
	double **masterAffineTransform ;
	double **inverseSlaveAffineTransform ;
	struct ParamRed		red ;
	struct CarImageRes	mod1 ;
	struct CarImageRes	mod2 ;
	struct ParamCor		corg ;
	struct ParamCor		corf ;
	struct CarImageRes	interf ;
	struct ParamFiltre	filter ;
	struct CarImageRes	firstPhaseComponent ;
	struct CarImageRes	secondPhaseComponent ;
	struct CarImageRes	thirdPhaseComponent ;
	struct CarImageRes	residualPhase ;
	struct ParamCoh		coh ;
	struct ParamCoh		cohder ;
	struct CarImageRes	res ;
	struct ParamConex	conex ;
	struct CarImageRes	dephi ;
	struct CarImageRes	srDEM ;
	struct CarFreq		chaz1 ;
	struct CarFreq		chaz2 ;
    float DEMExcludingValue ;
    double kz0 ;
	double ambiguityAltitude ;
    double averageBeta0CalibrationConstant ;            /* Defined as the average Ab (beta0) constant for calibrating S1 intensity data in terms of sigma (not sigma0!) since local slope will be taken into account */
	geoRef *geo ;
    int unsigned flag ;
    int unsigned flag2 ;
    char *SBInSARRootDirectory ;
    gridMap *xCoregistrationGrid, *yCoregistrationGrid ;
    void *corResults ;
    double xShift, yShift ;  /* Shifts introduced to allow computing interferograms with azimuth and range shifted coordinates - S1 case; per burst interferogram generation */
    keyValue *additionalParameters ;
	char *cohTrackString ;
} InSARParametersStruct ;

InSARParametersStruct *allocInSARParametersStruct(void) ;
InSARParametersStruct *allocAndinitInSARParametersStructAtPathFromInfoImage(char *inSARPath, char *masterInfoFilePath, char *slaveInfoFilePath, char isBistatic) ;
InSARParametersStruct *allocAndinitInSARParametersStructAtPathForImages(char* InSARPath, CSLImage *master, CSLImage *slave, InSARParametersStruct *SM2MpInSAR, char isBistatic, char *preferredPolarization) ;
void initRawFileDescriptorsToNullInInSARParameterStructure(InSARParametersStruct *pInSAR) ;
InSARParametersStruct *readInSARParametersFileAtPath(char *aPath) ;
void modifyFileExtensionsWithRespectToSelectedPolarization(InSARParametersStruct *pInSAR) ;
void saveInSARParametersFileAtPath(InSARParametersStruct *p, char *aPath) ;
void freeInSARParametersStruct(InSARParametersStruct *pInSAR) ;
rawFileDescriptor *openMasterImageForReading(InSARParametersStruct *pInSAR) ;
rawFileDescriptor *openSlaveImageForReading(InSARParametersStruct *pInSAR) ;
rawFileDescriptor *openInterferogramFile(InSARParametersStruct *pInSAR) ;
rawFileDescriptor *openFilteredInterferogramFile(InSARParametersStruct *pInSAR) ;
rawFileDescriptor *openFirstPhaseComponentFile(InSARParametersStruct *pInSAR) ;
rawFileDescriptor *openResidualInterferogramFile(InSARParametersStruct *pInSAR) ;
rawFileDescriptor *openUnwrappedPhaseFile(InSARParametersStruct *pInSAR) ;
rawFileDescriptor *openCoherenceFile(InSARParametersStruct *pInSAR) ;
rawFileDescriptor *openMeasurementFile(InSARParametersStruct *pInSAR) ;
rawFileDescriptor *openExternalSlantRangeDEMFile(InSARParametersStruct *pInSAR) ;
void createSBInSARParameterFileAtPath(InSARParametersStruct *pInSAR) ;
void createCohTrackParameterFile(InSARParametersStruct *pInSAR) ;
CSLImage *getReferenceCSLImage(InSARParametersStruct *pInSAR) ;
coord2D *computeEffectiveRangeAzimuthCoordinatesOfPoint(coord2D *currentPosition, coord2D *effectivePosition, InSARParametersStruct *pInSAR) ;
rawFileDescriptor *selectInterferogram(InSARParametersStruct *pInSAR) ;
void freeSelectedInterferogram(InSARParametersStruct *pInSAR) ;
CSVStruct *selectEventMasks(InSARParametersStruct *pInSAR) ;
void checkPolScheme(InSARParametersStruct *pInSAR, char *preferredPolarization) ;


#endif
