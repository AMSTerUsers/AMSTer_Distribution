
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  biasedCoh.h
//  biasedCoherenceEstimation
//
//  Created by Dominique Derauw on 23/08/16.
//
//

#ifndef biasedCoherenceEstimation_biasedCoh_h
#define biasedCoherenceEstimation_biasedCoh_h

#include "pourtous.h"
#include "paramInSAR.h"
#include "matrix.h"
#include "vectors.h"
#include "complexCalculus.h"
#include "aphi.h"
#include "counters.h"
#include "basicFilters.h"
#include "phaseUnwrappingLib.h"

#define _WITHOUT_AMPLITUDE_ 0x100000
#define _MEDIAN_FILTER_OF_COHERENCE_ 0x200000
#define _GEN_PHASE_UNWRAPPING_MASK_ 0x400000

/* functions */
void biasedCoherenceUsage(void) ;
void biasedCoherenceEstimation(InSARParametersStruct *pInSAR) ;


#endif
