
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  initInSARParams.h
//  initInSAR
//
//  Created by Dominique Derauw on 25/09/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#ifndef initInSAR_initInSARParams_h
#define initInSAR_initInSARParams_h

#define _KEEPAOI_ 0
#define _COMPUTEAOI_ 1

#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "paramInSAR.h"
#include "interpStateVect.h"
#include "geoRef.h"
#include "satRef.h"
#include "slantRangeDEMLib.h"
#include "planeGeometry.h"
#include "orbitalPhase.h"
#include "InSARGeoProjectionLib.h"
#include "SARPlatformID.h"
#include "aoiHandling.h"

InSARParametersStruct* initInSAR_GEO(InSARParametersStruct *pInSAR, int keepOrComputeAoI) ;
void computeEarthCentreToSensorDistance(InSARParametersStruct *pInSAR) ;
void computeBaseLine(InSARParametersStruct *pInSAR) ;
void computeBaseLineFromAffineTransform(InSARParametersStruct *pInSAR) ;
void computeCommonSuperpositionOfImages(InSARParametersStruct *pInSAR) ;
void projectAoIOnSuperMaster(InSARParametersStruct *pInSAR) ;
void updateBaseLineUsingRegistrationTransform(InSARParametersStruct *pInSAR) ;
void rangeAzimuthReferencingOfpointUsingDopplerPlane(double *lonLatH, double *xy, satRef *sR, double *eq1) ;
void computeTemporalBaseline(InSARParametersStruct *pInSAR) ;
double *getLocalHeightsOfAoISummits(char *kmlPath, char *DEMPath, double defaultValue) ;
double *getLocalHeightsOfPolygon(polygon *kmlAoI, char *DEMPath, double defaultValue) ;

#endif
