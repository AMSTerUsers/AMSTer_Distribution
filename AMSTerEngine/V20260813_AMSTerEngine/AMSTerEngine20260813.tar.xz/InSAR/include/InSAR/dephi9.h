
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* dephi9.h */

#if !defined(DEPHI9)
#define DEPHI9


#include "pourtous.h"
#include "bibdephi.h"
#include "phaseUnwrappingLib.h"
#include "paramInSAR.h"
#include "counters.h"
#include "orbitalPhase.h"
#include "rawFileLib.h"
#include "paramLib.h"
#include "stringLib.h"
#include "matrix.h"
#include "matrixObjects.h"


int branchCutPhaseUnwrapping(InSARParametersStruct *pInSAR) ;
void decphi(InSARParametersStruct *pInSAR) ;

#endif
