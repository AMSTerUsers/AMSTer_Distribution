
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  phaseUnwrappingLib.h
//  phaseUnwrapping
//
//  Created by Dominique Derauw on 25/04/2017.
//  Copyright © 2017 Dominique Derauw. All rights reserved.
//

#ifndef phaseUnwrappingLib_h
#define phaseUnwrappingLib_h

#include <stdio.h>
#include "pourtous.h"
#include "paramInSAR.h"
#include "counters.h"
#include "orbitalPhase.h"
#include "residuesSearch.h"
#include "biasedCoh.h"
#include "conex28.h"
#include "dephi9.h"
#include "snaphuManagement.h"
#include "detPhUnLib.h"

#define _RECOMPUTE_CONNEXIONS_              0x0001
#define _PHASE_TO_MEASUREMENT_CONVERSION_   0x0002

#ifndef FIRST_PHASE_COMPONENT_EXISTS
#define FIRST_PHASE_COMPONENT_EXISTS        0x0004
#endif

#define FLATTENING_CORRECTION               0x0008

#ifndef _COHERENCE_THRESHOLD_
#define _COHERENCE_THRESHOLD_               0x0010
#endif

#define RESIDUAL_PHASE_ONLY                 0x0020
#define _NO_PHASE_NORMALIZATION_            0x0040
#define _ZERO_FLATTENING_                   0x0080
#define _NO_NAN_FILL_                       0x0100

#ifndef _WITH_MASKING_
#define _WITH_MASKING_                      0x0200
#endif

#define _MASK_WITH_NAN_                     0x0400
#define _BRANCH_CUT_                        0x0800

#ifndef _DETPHUN_
#define _DETPHUN_                           0x1000
#define _DETPHUN_WITH_FILTERING_            0x2000
#define _DETPHUN1_                          0x4000
#define _DETPHUN2_                          0x8000
#endif

#ifndef _SNAPHU_
#define _SNAPHU_                            0x10000
#endif
#define _SAVE_SNAPHU_ZONEMAP_               0x20000
#define _THRESHOLD_EVERYWHERE_              0x40000

int phaseUnwrapping(CSVStruct *csv) ;
void phaseUnwrappingUsage(void) ;

void phaseToMeasurementConversion(InSARParametersStruct *pInSAR) ;
int unsigned defoOrTopo(InSARParametersStruct *pInSAR) ;
void addFirstPhaseComponentToUnWrappedPhase(InSARParametersStruct *pInSAR) ;


#endif /* phaseUnwrappingLib_h */
