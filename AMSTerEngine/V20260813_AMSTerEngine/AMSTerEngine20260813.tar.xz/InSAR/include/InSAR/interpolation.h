
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  interpolation.h
 *  interpolation
 *
 *  Created by Dominique Derauw on 14/11/11.
 *  Copyright 2011 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(SLAVEIMAGEINTERPOLATION)
#define SLAVEIMAGEINTERPOLATION

#include "pourtous.h"
#include "initInSARParams.h"
#include "paramInSAR.h"
#include "complexTypes.h"
#include "matrix.h"
#include "vectors.h"
#include "ceil2.h"
#include "interpolCZT.h"
#include "counters.h"
#include "rawFileLib.h"
#include "stringLib.h"
#include "planeGeometry.h"


#define MAXMEMALLOC 32              /* Default max memory allocation is 4GB (2**32) */
#define _INTERPOL_IN_PLACE_ 0x01

typedef struct {
    char verbose ;
    char flag ;
    int xDimIn, yDimIn, xDimOut, yDimOut ;
    int azimuthFilterDim, azimuthFilterBandwidth ;
    int x0In, y0In ;
    int dXFDC ;                     /* This shift is added for Sentinel 1 in order to compute correctly the FDC shift with respect to sub swath */
    int maxMemAlloc ;
    float *azimuthFilter ;
    double **affineTransform ;
    double *FDC, PRF ;              /* FDC is here the azimuth spectrum shift polynomial in powers of [Hz]/[pixel] */
    rawFileDescriptor *fIn, *fOut ;
    InSARParametersStruct *pInSAR ;
    polygon *aoi ;
} interpolationParameters ;

int interpolation(CSVStruct *csv) ;
void interpolationHelp(void) ;
interpolationParameters *allocInterpolationParameters (void) ;
void freeInterpolationParameters(interpolationParameters *params) ;
void interpolationCore(interpolationParameters *params);
void interpolCurrentChannels(interpolationParameters *params) ;
void interpolAllChannels(interpolationParameters *params) ;
void updateAoI(InSARParametersStruct *pInSAR) ;
double computeAzimuthFilterAtRange(int rangeIndex, interpolationParameters *params) ;

#endif
