
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  orbitalPhase.h
 *  fineCoregistration
 *
 *  Created by Dominique Derauw on 9/11/11.
 *  Copyright 2011 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(ORBITALPHASE)
#define ORBITALPHASE


#include "pourtous.h"
#include "geoRef.h"
#include "complexTypes.h"
#include "complexCalculus.h"
#include "paramInSAR.h"

double orbitalPhaseAtPoint(double rangePosition, double azimuthPosition, InSARParametersStruct *pInSAR) ;
complexFloat complexOrbitalPhaseAtPoint(double rangePosition, double azimuthPosition, InSARParametersStruct *pInSAR) ;
double geometricalPhaseAtPoint(double rangePosition, double azimuthPosition, double H, InSARParametersStruct *pInSAR) ;
complexFloat complexGeometricalPhaseAtPoint(double rangePosition, double azimuthPosition, double H, InSARParametersStruct *pInSAR) ;
double topographicalPhaseAtPoint(double rangePosition, double azimuthPosition, double H, InSARParametersStruct *pInSAR) ;
complexFloat complexTopographicalPhaseAtPoint(double rangePosition, double azimuthPosition, double H, InSARParametersStruct *pInSAR) ;
double ambiguityAltitudeAtPoint(double rangePosition, double azimuthPosition, double localAltitude, InSARParametersStruct *pInSAR) ;
void updateOrbitalParametersForPoint(double rangePosition, double azimuthPosition, InSARParametersStruct *pInSAR) ;
float phase2HeightConversionAtPoint(double rangePosition, double azimuthPosition, float phaseValue, InSARParametersStruct *pInSAR) ;

#endif
