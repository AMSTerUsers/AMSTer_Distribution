
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  amplitudeImagesReductionLib.h
//  amplitudeImagesReduction
//
//  Created by Dominique Derauw on 26/09/14.
//
//

#ifndef __azimuthFiltering__azimuthFilteringLib__
#define __azimuthFiltering__azimuthFilteringLib__

#include <stdio.h>

#include "pourtous.h"
#include "paramInSAR.h"
#include "complexCalculus.h"
#include "counters.h"
#include "slantRangeDEMLib.h"
#include "InSARSlantRangeProjectionLib.h"
#include "tileToolLib.h"
#include "fftw3.h"

#define _MASTER_AZIMUTH_FILTERING_ 0x0001
#define _SLAVE_AZIMUTH_FILTERING_ 0x0002

#define _XTILESIZE_ 1024
#define _YTILESIZE_ 1024
#define _XTILEBORDER_ 0
#define _YTILEBORDER_ 128

int azimuthFiltering(CSVStruct *csv) ;
void azimuthFilteringHelp() ;
void azimuthFilteringCore(InSARParametersStruct *pInSAR, int flag) ;
float *deHammingFilter_azimuthFilteringLib(struct infoImage *info, int length) ;
int updateReHammingFilter_azimuthFilteringLib(float *filter, int windowSize, int rangeIndex, InSARParametersStruct *pInSAR) ;

#endif /* defined(__azimuthFiltering__azimuthFilteringLib__) */
