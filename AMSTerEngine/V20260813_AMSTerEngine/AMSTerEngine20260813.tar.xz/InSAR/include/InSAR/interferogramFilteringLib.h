
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Filtre.h */
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
 */

#if !defined(FILTRE)
#define FILTRE
#include "pourtous.h"
#include "paramInSAR.h"
#include "fft.h"
#include "counters.h"
#include "tileToolLib.h"
#include "complexCalculus.h"

#define INTERF_FIlTERING 		0x1000
#define _COMBINED_FILTERING_ 	0x2000
#define _COMPLEX_FILTER_ 		0x4000
#define _CLASSIC_FILTER_ 		0x8000
#define _ADAPTATIVE_FILTER_ 	0x10000
#define _BLAH_BLAH_ 			0x20000

/* Adaptive filter tile size */
#define _XATILESIZE_ 32
#define _YATILESIZE_ 32
#define _XATILEBORDERSIZE_ 15
#define _YATILEBORDERSIZE_ 15

/* Classic filter tile size */
#define _XCTILESIZE_ 64
#define _YCTILESIZE_ 64
#define _XCTILEBORDERSIZE_ 16
#define _YCTILEBORDERSIZE_ 16


typedef	struct {
	int	iX ;
	int	iY ;
	int	DimX ;
	int	DimY ;
	int	SupX ;
	int	SupY ;
	int	DimXZE ;
	int	DimYZE ;
	int	NBlocX ;
	int	NBlocY ;
	int	LenX ;
	int	LenY ;
	float	*e, *s, *FFTGauss ;
    float **filteredData ;
    float **filter ;
	complexFloat	*BlocComplexe ;
    complexFloat **data ;
	StructFFT	*FFTLigne ;
	StructFFT	*FFTColonne ;
} CarBloc ;

int interferogramFiltering(CSVStruct *csv) ;
void interferogramFilteringHelp(void) ;
void createInteferogramFilteringParameterFileAtPath(char *aPath) ;

void convertFloatPhaseTileToComplex(tileTool *phaseTileTool, tileTool *complexTileTool) ;
void convertComplexPhaseTileToFloat(tileTool *phaseTileTool, tileTool *complexTileTool) ;
void initFilterTileTool(tileTool *filterTileTool, float sigmaX, float sigmaY) ;
void tileFiltering(tileTool *aTileTool, tileTool *filterTileTool) ;

void interferogramFilteringCore(keyValue *parameters) ;
void adaptativeFilteringOfTile(tileTool *aTileTool, tileTool *smoothedSpectrum, float alpha) ;
char testNaNTile(tileTool *complexPhaseTileTool, char *comment) ;


#endif
