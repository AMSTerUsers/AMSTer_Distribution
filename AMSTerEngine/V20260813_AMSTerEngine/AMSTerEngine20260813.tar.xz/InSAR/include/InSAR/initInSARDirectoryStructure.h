
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  initInSARDirectoryStructure.h
//  initInSAR
//
//  Created by Dominique Derauw on 25/09/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#ifndef __initInSAR__initInSARDirectoryStructure__
#define __initInSAR__initInSARDirectoryStructure__

#include <stdio.h>
#include "pourtous.h"
#include "fileAccessLib.h"
#include "paramLib.h"


void createInSARDirectoryStructureAtPath(char *aPath) ;
char isInSARDirectoryStructureAtPath(char *aPath) ;


#endif /* defined(__initInSAR__initInSARDirectoryStructure__) */
