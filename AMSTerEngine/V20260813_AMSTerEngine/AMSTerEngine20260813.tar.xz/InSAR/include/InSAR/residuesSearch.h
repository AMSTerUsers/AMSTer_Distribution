
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  residuesSearch.h
//  residuesSearch
//
//  Created by Dominique Derauw on 28/11/2017.
//

#ifndef residuesSearch_h
#define residuesSearch_h

#include "pourtous.h"
#include "paramInSAR.h"

/* fonctions */
void residuesSearch(InSARParametersStruct *pInSAR) ;



#endif /* residuesSearch_h */
