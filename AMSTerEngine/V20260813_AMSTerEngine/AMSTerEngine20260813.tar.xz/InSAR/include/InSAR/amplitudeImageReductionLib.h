
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  amplitudeImagesReductionLib.h
//  amplitudeImagesReduction
//
//  Created by Dominique Derauw on 26/09/14.
//
//

#ifndef __amplitudeImagesReduction__amplitudeImagesReductionLib__
#define __amplitudeImagesReduction__amplitudeImagesReductionLib__

#include <stdio.h>

#include "pourtous.h"
#include "paramInSAR.h"
#include "complexCalculus.h"
#include "counters.h"
#include "slantRangeDEMLib.h"
#include "InSARSlantRangeProjectionLib.h"


int amplitudeImageReduction(CSVStruct *csv) ;
void amplitudeImageReductionHelp(void) ;
void rawFileReduction(CSVStruct *csv) ;
int    complexImageReduction(rawFileDescriptor *inputFile, rawFileDescriptor *outputFile, int xReductionFactor, int yReductionFactor) ;
int    imageReduction(rawFileDescriptor *inputFile, rawFileDescriptor *outputFile, int xReductionFactor, int yReductionFactor, char whatToDo) ;


#endif /* defined(__amplitudeImagesReduction__amplitudeImagesReductionLib__) */
