
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  cohTrackLib.h
 *  Coherence Tracking Products Generation
 *
 *  Created by Dominique Derauw on 29/07/2025.
 *  Copyright 2029 Dominique Derauw SAREOS. All rights reserved.
 *
 */

#if !defined(COH_TRACK_LIB_H)
#define COH_TRACK_LIB_H


#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "paramInSAR.h"
#include "initInSARDirectoryStructure.h"
#include "initInSARLib.h"
#include "initInSARParams.h"
#include "InSARGenLib.h"
#include "aoiHandling.h"
#include "interpolation.h"
#include "S1InSARLib.h"
#include "tileToolLib.h"
#include "matrixPile.h"
#include "sortingRoutines.h"
#include "basicFilters.h"

#define __INTERPOL_ALL_DONE__   0x00000800
#define __INTERPOL_DONE__       0x00001000
#define __FORCE_INTERPOL__      0x00002000  /* --all */
#define __FORCE_INSAR__         0x00004000  /* --InSAR */
#define __CROSS_MAPPING__       0x00008000  /* -c */
#define __COHTRACK_ONLY__       0x00010000  /* --opt */
#define __NAN_EXCLUSION__       0x00020000  /* --nan */
#define __WEIGHTED_AVG__        0x00040000  /* -W */
#define __CENTROIDIZATION__     0x00080000  /* -C */
#define __MAX_LOC__             0x00100000  /* -M */
#define __SLOPE_CORRECTION__    0x00200000  /* -S */
#define __PIX_MEASUREMENT__     0x00400000  /* -P */

typedef struct cohTrackMax
{
    int iXMax, iYMax, iXMin, iYMin ;
    int isXNan, isYNan ;
    float xC, yC, cohCMAvg, sigmaCM ;
    float fineXMax, fineYMax ;
    float maxCoh, meanCoh, minCoh ;
    float maxCohX, maxCohY ;
    float optPhaseX, optPhaseY, optDiffPhaseX, optDiffPhaseY ;
    float optPhase, optDiffPhase ;
    float xTrend, yTrend ;
} cohMax ;

typedef struct cohTrackLib
{
    char *workingDirectory ;
    char *sequentialProcessDirectory ;
    char *resultsDirectory ;
    char *selectedPol ;
    int nStepsX, nStepsY ;      /* number of steps of dXStep and dYStep fraction of pixels for coherence exploration */
    int iXMin, iXMax, iYMin, iYMax ;  /* Shift indexes vary in the interval [iXMin ; iXMax = iXMin + nxSteps - 1] */
    int nTilesX, nTilesY ;
    int **xIndex, **yIndex ;    /* indexes of per line and per column ordered smoothed coherence values */
    size_t flag ;
    float **cohMat, **smoothedCohMat ;
    float **interfMat, **interfDiffMat ;
    float meanCoh ;             /* Global average on coherence mapping */
    float *meanCohX, *minCohX, *maxCohX, *rangeX, *slopeX ;           /* Along X average, min, max, range and slope for each iY */
    float *meanCohY, *minCohY, *maxCohY, *rangeY, *slopeY ;           /* Along Y average, min, max, range and slope Sfor each iX */
    float *p33X, *p33Y ;        /* Percentile 1/3 value for X line at index iY and Y column at index iX*/
    float *skX, *skY ;          /* Skewness */
    float *bsX, *bsY ;          /* beta stability */
    float sigmaX, sigmaY ;      /* sigma of Gaussian used for coherence mapping filtering */
    float dXMin, dXMax, dXStep, dYMin, dYMax, dYStep, *dX, *dY ;
    float coherenceThreshold, rangeThreshold, slopeThreshold ;     /* Selection parameters */
    InSARParametersStruct *pInSAR, ***ppInSAR ;
    rawFileDescriptor *trackedCoherenceFile ;
    rawFileDescriptor *trackedInterfFile ;
    rawFileDescriptor *trackedResidualPhaseFile ;
    rawFileDescriptor *trackedMod2File ;
    rawFileDescriptor *trackedRangeShiftFile ;
    rawFileDescriptor *trackedAzimuthShiftFile ;
    tileTool ***ppCohTiles ;
    tileTool ***ppInterfTiles ;
    tileTool ***ppInterfDiffTiles ;
    tileTool ***ppMod2Tiles ;
    tileTool *incidenceAngle ;
    tileTool *trackedCoh ;
    tileTool *trackedInt ;
    tileTool *trackedDiffInt ;
    tileTool *trackedMod2 ;
    tileTool *trackedRangeShifts ;
    tileTool *trackedAzimuthShifts ;
    CSVStruct *csv ;
    keyValue *cohTrackParams ;
    cohMax *locMax ;
} cohTrackStruct ;




int cohTrackMain (CSVStruct *csv) ;
void cohTrackHelp(void) ;
cohTrackStruct *getCohTrackParameters(CSVStruct *csv) ;
void freeCohTrackParams(cohTrackStruct *cohTrackParams) ;
void initCohTrackDirs(cohTrackStruct *cohTrackParams) ;
void initCohTrackTileTools(cohTrackStruct *pCohTrack) ;
void initOutputFiles(cohTrackStruct *pCohTrack) ;
void initShiftTransforms(cohTrackStruct *pCohTrack) ;
void cohTrackReferenceRegistration(cohTrackStruct *pCohTrack) ;
void copyRefCorToCohTrackDirs(cohTrackStruct *pCohTrack) ;
void cohTrackShiftInterpolation (cohTrackStruct *pCohTrack) ;
void cohTrackSequentialInSARProcessing(cohTrackStruct *pCohTrack) ;
void cohTrackStackProcessing( cohTrackStruct *pCohTrack) ;
void locateCohMax(cohTrackStruct *pCohTrack) ;
void saveCohTrackStacks(cohTrackStruct *pCohTrack) ;
void resetCohMat(cohTrackStruct *pCohTrack) ;
void cohTrackStats(cohTrackStruct *pCohTrack) ;
float optCohX(cohTrackStruct *pCohTrack) ;
float optCohY(cohTrackStruct *pCohTrack) ;
float optXPhaseCalc(cohTrackStruct *pCohtrack) ;
float optYPhaseCalc(cohTrackStruct *pCohtrack) ;


#endif