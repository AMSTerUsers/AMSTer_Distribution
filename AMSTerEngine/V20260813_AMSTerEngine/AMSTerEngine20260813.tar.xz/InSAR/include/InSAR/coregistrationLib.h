
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* corcoh.h */
/*
*  Created by Dominique Derauw a long time ago.
*  Copyright (c) Dominique Derauw. All rights reserved.
*
*/

#if !defined (CORCOH)
#define CORCOH

#include "pourtous.h"
#include "paramInSAR.h"
#include "complexTypes.h"
#include "fft.h"
#include "matrix.h"
#include "vectors.h"
#include "resmat.h"
#include "ceil2.h"
#include "polynomials.h"
#include "complexCalculus.h"
#include "initInSARLib.h"
#include "geoRef.h"
#include "orbitalPhase.h"
#include "counters.h"
#include "aphi.h"
#include "gridMapping.h"
#include "aoiHandling.h"

#define MAXBLOCSIZE 512 * 1024 * 1024

#define WITH_TRACKING 1
#define SQUARE_SPIRAL 2
#define _SAVE_ITERMEDIATE_RESULTS_ 4
#define _FULL_WINDOW_SEARCH_ 8

#if !defined _COREGISTRATION_RESULTS_
#define _COREGISTRATION_RESULTS_
struct coregistrationResultsStructure {
    int numberOfCandidatePoints ;
    int numberOfRegisteredPoints ;
    int coregistrationIndex ; 
    double sigmaX ;
    double sigmaY ;
    double sigmaXY ;
    double xTranslation, yTranslation ;
    double sigmaXTranslation ;
    double sigmaYTranslation ;
    double **T ;
    gridMap *xCoregistrationGrid ;
    gridMap *yCoregistrationGrid ;
    struct coregistrationResultsStructure *formerResults ;
} ;
typedef struct coregistrationResultsStructure coregistrationResults ;
#endif

/* definition de fonctions */
coregistrationResults *allocCoregistrationResults(void) ;
void freeCoregistrationResults (coregistrationResults *corResults) ;
coregistrationResults *coarseCoregistration(CSVStruct *csv) ;
void coarseCoregistrationHelp(void) ;
coregistrationResults *fineCoregistration(CSVStruct *csv) ;
void fineCoregistrationHelp(void) ;
coregistrationResults *coarseCoregistrationCore(InSARParametersStruct *pInSAR, int unsigned lowCutFilterVal) ;
coregistrationResults *fineCoregistrationCore(InSARParametersStruct *pInSAR) ;

#endif
