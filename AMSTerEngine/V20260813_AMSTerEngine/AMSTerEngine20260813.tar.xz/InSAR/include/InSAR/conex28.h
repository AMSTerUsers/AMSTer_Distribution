
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* conex.h */

#if !defined(CONEX)
#define CONEX

#include "pourtous.h"
#include "paramInSAR.h"
#include "complexCalculus.h"
#include "counters.h"

#ifndef _WITH_MASKING_
#define _WITH_MASKING_                      0x0200
#endif


/* definition de structure */
#if !defined(_INTEGRATION_STARTING_POINT_)
#define _INTEGRATION_STARTING_POINT_
 struct pile
	{
		unsigned char	hb ;
		int		az, ra ;
		struct	pile	*suiv ;
	} ;
typedef struct pile integrationPathStartingPoint ;

#endif

 struct chaine
	{
		unsigned char	s, p ;
		int		az, ra, ch ;
		struct	chaine	*suiv, *lien ;
	} ;

 struct cpdd
	{
		unsigned short		seuil ;
		int			az, ra ;
	} ;
typedef struct cpdd connexionStartingPoint ;

/* Functions prototyping */

void residuesConnexion(InSARParametersStruct *pInSAR) ;

int residuesDownSearch(unsigned short *ptr1, unsigned char *ptr2, unsigned char *ptr3, int *ptr_i, int *ptr_j, int *ptr_ra, int *ptr_rr, unsigned char *ptr_test1, unsigned short *ptr_test2, int *ptr_bord) ;
int residuesUpSearch(unsigned short *ptr1, unsigned char *ptr2, unsigned char *ptr3, int *ptr_i, int *ptr_j, int *ptr_ra, int *ptr_rr, unsigned char *ptr_test1, unsigned short *ptr_test2, int *ptr_bord) ;
void	addIntegrationPathStartingPoint(int i, int j, unsigned char sens) ;
void	achaine(int i, int j, unsigned char signe, unsigned char *ptr) ;
void	calcharge(int *ptr) ;
void	makeResidueConnection(int *ptr) ;
void	pchaine(void) ;
void	lien(int x0, int y0, int x1, int y1, unsigned char connexion) ;
void	ppv(struct chaine **ptr1, struct chaine **ptr2) ;
void	nettoyage(unsigned short *ptr) ;
void	lib(void) ;
void	netbas(unsigned char *ptr1, unsigned char *ptr2) ;
void	nethaut(unsigned char *ptr1, unsigned char *ptr2) ;
int		ppvcohmin(int *ptr_i0, int *ptr_j0) ;
void	rescohmax(void) ;
void	mincohres(void) ;
void	propag(unsigned char *ptr_res, unsigned short *ptr_coh, unsigned short *ptr_seuil, unsigned char *ptr_ok1, unsigned char *ptr_ok, unsigned char *ptr_dok, int *ptr_tb, int *ptr_th, int *ptr_stop, int *ptr_i0, int *ptr_j, unsigned char *ptr_p, unsigned char *ptr_test1, unsigned short *ptr_test2, int *ptr_bord) ;
void sauvegarde(rawFileDescriptor *outputFile) ;
void	comptage(long *ptr) ;
void	decompte(long *ptr) ;
void	tri(void) ;
void	seuilmoyen(unsigned short *ptr) ;
void	bordcoh(unsigned short *seuil) ;
void	bbas(unsigned short *seuil) ;
void	bhaut(unsigned short *seuil) ;


#endif
