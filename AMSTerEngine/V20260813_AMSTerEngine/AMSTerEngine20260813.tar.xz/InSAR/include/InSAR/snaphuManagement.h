
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  snaphuManagement.h
//  phaseUnwrapping
//
//  Created by Dominique Derauw on 21/02/17.
//
//

#ifndef snaphuManagement_h
#define snaphuManagement_h

#include <stdio.h>
#include "phaseUnwrappingLib.h"
#include "orbitalPhase.h"
#include "rawFileManipulation.h"

#define _SNAPHU_ 0x10000


int snaphuManagement(CSVStruct *csv, InSARParametersStruct *pInSAR) ;
void createSnaphuConfFile(InSARParametersStruct *pInSAR, char *interfPath) ;
void updateSnaphuConfFile(char *confFilePath, char *key, char *stringVal) ;


#endif /* snaphuManagement_h */
