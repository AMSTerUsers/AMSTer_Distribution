
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/**
 * @file genFakePol.h
 * @project genFakePol
 * @author Created by Dominique Derauw
 * @copyright ©2025 Dominique Derauw - SAREOS
 * @date 2025-10-22
 */

#ifndef genFakePol_genFakePol_H
#define genFakePol_genFakePol_H

#define _ALL_COMB_ 0x00000001

#include "pourtous.h"
#include "paramInSAR.h"
#include "InSARGenLib.h"
#include "cohOpt.h"
#include "sortingRoutines.h"

void genFakePolHelp() ;

#endif /* genFakePol_genFakePol_H */