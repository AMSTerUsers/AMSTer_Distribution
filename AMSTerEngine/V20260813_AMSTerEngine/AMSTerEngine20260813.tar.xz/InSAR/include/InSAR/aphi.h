
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* aphi.h *//* Local phase plane estimation using square spiral phase unwrapping */#if !defined(APHI)#define APHI#include "pourtous.h"float	aphi(float **Mphi, int *N, int *y, int *x) ;float squareSpiralPhaseUnwrapping(float **M, int N, int x0, int y0) ;#endif