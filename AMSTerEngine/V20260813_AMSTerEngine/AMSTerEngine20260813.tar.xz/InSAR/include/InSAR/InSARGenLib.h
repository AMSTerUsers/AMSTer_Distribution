
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  InSARGenLib.h
//  InSARProductsGeneration
//
//  Created by Dominique Derauw on 1/09/15.
//  Copyright (c) 2015 Dominique Derauw. All rights reserved.
//

#ifndef __InSARProductsGeneration__InSARGenLib__
#define __InSARProductsGeneration__InSARGenLib__

#include <stdio.h>
#include "pourtous.h"
#include "paramInSAR.h"
#include "incomod.h"
#include "initInSARLib.h"
#include "fft.h"
#include "ceil2.h"
#include "interferogramFilteringLib.h"
#include "matrix.h"
#include "vectors.h"
#include "aphi.h"
#include "rawFileLib.h"
#include "counters.h"
#include "orbitalPhase.h"
#include "planeGeometry.h"
#include "tileToolLib.h"
#include "movingAverageTool.h"
#include "S1InSARLib.h"


int InSARProductsGeneration(CSVStruct *csv) ;
void InSARGenHelp(void) ; ;

void computeInSARProducts(InSARParametersStruct *pInSAR) ;
void computeInterferogramTile(tileTool *interf, tileTool *master, tileTool *slave, InSARParametersStruct *pInSAR) ;
void boxAveragingOfInterferogramTile(tileTool *complexInterferogramTileTool, tileTool *reducedInterferogramTileTool, int xReductionFactor, int yReductionFactor) ;


#endif /* defined(__InSARProductsGeneration__InSARGenLib__) */
