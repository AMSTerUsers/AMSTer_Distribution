
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* dephi.h */

#if !defined(DEPHI)
#define DEPHI

/* definition de structure */
#if !defined(_INTEGRATION_STARTING_POINT_)
#define _INTEGRATION_STARTING_POINT_
struct pile
{
    unsigned char    hb ;
    int        az, ra ;
    struct    pile    *suiv ;
} ;
typedef struct pile integrationPathStartingPoint ;
#endif


struct pdd {
	int		az, ra, minaz, minra, maxaz, maxra ;
    int unsigned zoneSize, zoneIndex, validZoneSize ;
	double min, max, xM, yM ;
    double phaseAvg, cohAvg ;
    double **M, *V ;
} ;

typedef struct {
    unsigned char	**connexionsMap ;
    int unsigned **zoneMap, zoneIndex ;
    int		xDim, yDim ;
    float	DephiOk ;
    float   **interferometricPhase, **unwrappedPhase, **coherence ;
    struct pile	*integrationPath ;
    struct pdd	startingPoint ;
    
} phaseUnwrappingStructure ;

/*   functions declaration */
int ps(char init) ;
void bas(void) ;
void haut(void) ;
void apile(int i, int j, unsigned char sens) ;
void dd(float **aptr_phi, unsigned char **aptr_res, float **aptr_dephi, int *ptr_i0, int *ptr_j, int *ptr_tb, int *ptr_th) ;
void dg(float **aptr_phi, unsigned char **aptr_res, float **aptr_dephi, int *ptr_i0, int *ptr_j, int *ptr_tb, int *ptr_th) ;
double dphi(float *, float *, float *, int, int) ;

void apileNorme(int i, int j, unsigned char sens) ;
void normbas(void) ;
void normhaut(void) ;
void ndg(float **aptr_phi, unsigned char **aptr_res, float **aptr_dephi, int *ptr_i0, int *ptr_j, int *ptr_tb, int *ptr_th) ;
void ndd(float **aptr_phi, unsigned char **aptr_res, float **aptr_dephi, int *ptr_i0, int *ptr_j, int *ptr_tb, int *ptr_th) ;

/* global variables declaration */
extern unsigned char	**connexions ;
extern int unsigned **zoneMap, zoneIndex ;
extern float		DephiOk ;
extern float		*ptr_first_phi, *ptr_first_dephi, *ptr_first_coh ;
extern float   **interferometricPhase, **unwrappedPhase, **coherence ;
extern struct pdd	pdd ;

#if !defined(_CONNEXIONS_DEPHI_COMMON_EXT_DEFS_)
#define _CONNEXIONS_DEPHI_COMMON_EXT_DEFS_
    extern int lena, lenr ;
    extern unsigned char    *ptr_first_res ;
    extern integrationPathStartingPoint    *ptr_dpile ;
#endif


#endif
