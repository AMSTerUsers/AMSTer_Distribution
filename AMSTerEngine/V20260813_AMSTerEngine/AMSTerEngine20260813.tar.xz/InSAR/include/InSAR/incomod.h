
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* incomod.h */
/* Librairie relative aux fonctions d'incomod */
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
 */


#if !defined(INCOHMOD)
#define INCOHMOD

#include "pourtous.h"
#include "paramInSAR.h"
#include "fft.h"
#include "ceil2.h"
#include "interferogramFilteringLib.h"
#include "matrix.h"
#include "vectors.h"
#include "aphi.h"
#include "rawFileLib.h"
#include "counters.h"
#include "orbitalPhase.h"
#include "planeGeometry.h"
#include "gridMapping.h"
#include "slantRangeDEMLib.h"
#include "tileToolLib.h"
#include "rawFileManipulation.h"
#include "infoImageS1.h"
#include "basicFilters.h"

#define COMPUTE_STADARD_DEVIATION 		0x00000001
#define FLAT_EARTH_PHASE_REMOVAL 		0x00000002
#define COMPUTE_LOCAL_INCIDENCE_ANGLE 	0x00000004
#define WITH_FILTERING 					0x00000008
#define _WITH_WEIGHTING_ 				0x00000400

#if !defined(_WITH_MASKING_)
	#define _WITH_MASKING_ 				0x00000200
#endif


/* Définition d'une structure correspondant à un Bloc interferométrique i.e., un bloc de données et de résultats InSAR complet */
struct BlocInSAR {
	FILE	*f1, *f2 ;
    char withFiltering ;
	int	Dima, lenr, IndiceLigne, DecLignes ;
	double	**intensity1 ; /* Intensity of master image */
	double	**intensity2 ; /* Intensity of slave image */
    complexFloat    **masterImage, **slaveImage ;
	complexFloat	**Interf ;
	complexFloat	**InterfF ;
	complexFloat	**PhiOrb  ;
	complexFloat	**PhiTopo  ;
	complexFloat	**PhiGeom  ;
    gridMap *slantRangeDEMGrid ;
    tileTool *complexPhaseTileTool, *filterTileTool, *secondFilterTileTool ;
    StructFFT *xFFT, *yFFT ;
	} ;

void insicohmod(InSARParametersStruct *pInSAR) ;
void GenPhiOrb(struct BlocInSAR *BI, InSARParametersStruct *pInSAR) ;
void GenPhiGeom(struct BlocInSAR *BI, InSARParametersStruct *pInSAR) ;
void GenPhiTopo(struct BlocInSAR *BI, InSARParametersStruct *pInSAR) ;
void LectureBlocInSAR(FILE *f, complexFloat *BlocImage, int NLignes, int NPointsParLigne, off_t Debut) ;
void AllocBlocInSAR(struct BlocInSAR *BI, InSARParametersStruct *p) ;
void GenPhi(struct BlocInSAR *BI, InSARParametersStruct *p) ;
void GenPhiWithDoubleFiltering(struct BlocInSAR *BI, InSARParametersStruct *p) ;
void TransfertInterfFiltre(float *Ligne, struct BlocInSAR *BI, int IndiceLigne, int Dec) ;
void TransfertPhiFiltre(complexFloat *Phi, struct BlocInSAR *BI, int IndiceLigne, int Dec) ;
void TransfertPhi(complexFloat *Phi, struct BlocInSAR *BI, int IndiceLigne, int Dec) ;
void TransfertMod(float *Mod1, float *Mod2, struct BlocInSAR *BI, int IndiceLigne, int Dec) ;
void initFiltering(struct BlocInSAR *BI, InSARParametersStruct *pInSAR) ;
void initSecondFilter(struct BlocInSAR *BI, InSARParametersStruct *pInSAR) ;
void tileByTileFiltering(struct BlocInSAR *BI) ;
void secondFilter(struct BlocInSAR *BI) ;
void dataToFilterTransfer(complexFloat **inputData, CarBloc *filter) ;
void filterToDataTransfer(complexFloat **outputData, CarBloc *filter) ;
void LibBlocInSAR(struct BlocInSAR *BI) ;
void SigmaPhiToSigmaH(float *EcartType, InSARParametersStruct *pInSAR, int azimuthPosition) ;
void resampleFloatFiles(InSARParametersStruct *pInSAR) ;

#endif
