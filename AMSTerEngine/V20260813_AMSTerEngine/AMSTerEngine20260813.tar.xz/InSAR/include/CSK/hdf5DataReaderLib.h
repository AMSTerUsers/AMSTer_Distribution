
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
// hdf5DataReaderLib.h
//
// Created by Dominique Derauw on Fri Dec 20 2024
// Copyright (c) 2024 Dominique Derauw - SAREOS. All right reserved.
//

#ifndef _HDF5_ATA_READER_LIB_
#define _HDF5_ATA_READER_LIB_

#include <stdio.h>
#include <stdlib.h>
#include "hdf5.h"
#include "H5version.h"

#include "pourtous.h"
#include "paramLib.h"
#include "byteSwap.h"
#include "counters.h"
#include "tileToolLib.h"

/* Structure to store all dataset characteristics in line with info required for reading and saving it */
typedef struct {
	hid_t dataset ;             /* HDF5 dataset identifiers */
	hid_t dataspace ;           /* HDF5 dataspace identifier */
    hid_t typeID ;              /* HDF5 type ID */
    hid_t dcpl ;                /* HDF5 dataset creation property list */
    hid_t memspace ;            /* HDF5 memory space */
	hsize_t	*datasetDims ;      /* HDF dataset dimensions */
    hsize_t *offset ;           /* Current offset for line by line matrix reading */
    hsize_t numberOfElements ;  /* Total nimber of elements in matrix or vector */
    hsize_t *chunkDims ;        /* Chunks dimension for matrix reading */
    H5D_layout_t layoutType ;   /* HDF5 dataset layout */
    char isBigEndian ;
    char bytesMustBeSwapped ;
    int isChunked ;
    int currentRow;             /* Current row index */
    int numberOfRows;           /* Dataset  total number of rows */
    int rank ;                  /* dataset rank */
    size_t  dataTypeSize ;      /* Datatype size in bytes */
    char *dataTypeName ;            /* Data type string */
    void *dataTile ;
    progressCounter *aCounter ;
} hdf5DatasetDescriptor ;

/* Attribute info structure */
typedef struct {
    char* name ;
    hid_t typeID ;
    hid_t spaceID ;
    int rank ;          /* Attribute rank */
    hsize_t *dims ;     /* Attribute dimensions */
    size_t typeSize ;   /* Attribute tipe size */
    size_t numberOfElements ;
    void* value;        /* Attribute value(s) */
} attributeInfo ;

/* Readable dataset */
typedef struct {
    char *typeID ;
    int rank ;
    int *dims ;
    int typesize ;
    void *v, **m ;
} datasetVals ;


/* Scan and dump hdf5 file */
keyValue *hdf5Dump(char *inputPath, char *outputPath, char blahblah, CSVStruct *excludedDatasetNames) ;

/* Scalar object call-back function */
herr_t scalarObjectScan(hid_t objectID, const char *datasetName, const H5O_info_t *objectInfo, void *pList) ;

/* Matrix and vector object call-back function */
herr_t matrixAndVectorObjectsScan(hid_t objectID, const char *datasetName, const H5O_info_t *objectInfo, void *pList) ; 

// Get string representation of HDF5 data type
char* getHDF5TypeName(hid_t HDF5TypeID) ;

/* Get string contained in dataset */
char* getHDF5StringDataset(hid_t dataset, hid_t HDF5TypeID) ;

/* Alloc and init h5 dataset descriptor */
hdf5DatasetDescriptor *allocAndInitH5DatasetDescriptor(hid_t objectID, const char *datasetName) ;

/* Free h5 dataset descriptor */
void freeH5DatasetDescriptor(hdf5DatasetDescriptor *h5) ;

/* Read attribute content */
attributeInfo* readAttribute(hid_t attr_id) ;

/* Free attribute info */
void freeAttributeInfo(attributeInfo* attInfo) ;

/* Display attribute value */
void printAttributeValue(attributeInfo* attInfo) ;

/* Scan all dataset's attributes*/
void printDatasetAttributes(hid_t datasetID, const char* datasetName) ;

/* Read dumped data set at given path */
datasetVals *readDumpedDatasetAtPath (char* datasetPath) ;

/* Free read dataset */
void freeDatasetVals(datasetVals *thisDataset) ;


#endif