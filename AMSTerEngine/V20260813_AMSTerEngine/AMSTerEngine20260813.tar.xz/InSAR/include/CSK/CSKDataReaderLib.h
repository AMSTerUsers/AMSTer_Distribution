
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  CSKDataReader.h
//  CSKDataReader
//
//  Created by Dominique Derauw on 2/07/12.
//  Copyright (c) 2012 Dominique Derauw. All rights reserved.
//

#ifndef CSKDataReader_CSKDataReader_h
#define CSKDataReader_CSKDataReader_h

#include <stdio.h>
#include <stdlib.h>
#include "hdf5.h"
#include "H5version.h"
#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "infoImageCSK.h"
#include "byteSwap.h"
#include "counters.h"
#include "vectors.h"

/* Functions prototypes */
CSVStruct *CSKDataReader(CSVStruct *csv) ;
void CSKDataReaderHelp(void) ;
void createCSKDataReaderParameterFileAtPath(char *aPath) ;
keyValue *readCSKImageHeader(char *inputPath) ;
void readCSKImageData(char *inputPath, keyValue *pListAll, CSLImage *thisImage) ;

void createSLCCalibrationTextFileAtPath(keyValue *header, char *aPath)  ;


/* Operator function */
static herr_t transferAttributeInfoToPList(hid_t parentObject, const char *childObjectName, const H5A_info_t *childObjectInfo, void *sentPointer) ;

/* Operator function to be called by H5Ovisit */
static herr_t visitObjectsIteratively(hid_t parentObject, const char *childObjectName, const H5O_info_t *childObjectInfo, void *sentPointer) ;

static herr_t getAllRank0Data(hid_t parentObject, const char *childObjectName, const H5O_info_t *childObjectInfo, void *rank0pList)  ; 

/* Get HD5 sspace type identifier */
char *getH5SpaceTypeIdentifier(H5T_class_t dataTypeIdentifier) ;

/* Get HD5 string for data type identifier */
char *getHD5DataTypeIdentifier(H5T_class_t dataTypeIdentifier) ;

/* Get HD5 string for data type byte order */
char *getHD5DataTypeByteOrder(H5T_order_t dataTypeOrder) ;


#endif
