
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
// NISARDataReaderLib.h
//
// Created by Dominique Derauw on Fri Dec 20 2024
// Copyright (c) 2024 Dominique Derauw - SAREOS. All right reserved.
//

#ifndef _NISAR_DATA_READER_LIB_
#define _NISAR_DATA_READER_LIB_

#include "hdf5DataReaderLib.h"
#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "byteSwap.h"
#include "counters.h"
#include "vectors.h"
#include "stateVect.h"
#include "stateVector.h"

CSVStruct *NISARDataReader(CSVStruct *csv) ;
void NISARDataReaderHelp() ;
SLCImageInfo *createSLCInfoImageForNISARData(char *dumpDir, char *requestedPol) ; 
void initInfoImageForNISARFrequency(SLCImageInfo *info, char* frequencyAB, char *dumpDir) ;
double *approxNISARFDC(char *dopplerDir, SLCImageInfo *info) ;
struct stateVect    *readNISARStateVects(char *orbitDir, SLCImageInfo *info) ;
double computeAverageTerrainHeightForNISAR(char *paramsDir) ;
CSLImage *saveNISARDataInCSLImageStruct (char *outputDir, SLCImageInfo *info) ;
void checkExistingNISARData(char *outputDir, CSVStruct *H5Filepath, int reread) ;


#endif