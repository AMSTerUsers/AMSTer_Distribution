
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  ICEYEDataReader.h
//  ICEYEDataReader
//
//  Created by Dominique Derauw on 2/07/12.
//  Copyright (c) 2012 Dominique Derauw. All rights reserved.
//

#ifndef ICEYEDataReader_ICEYEDataReader_h
#define ICEYEDataReader_ICEYEDataReader_h

#include <stdio.h>
#include <stdlib.h>
#include "hdf5.h"
#include "H5version.h"
#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "infoImageICEYE.h"
#include "byteSwap.h"
#include "counters.h"
#include "vectors.h"

struct hdf5DatasetDescriptor
{
    char bytesMustBeSwapped ;
    unsigned long bufferDim ;
    int rank ;
	hsize_t	*datasetDim, *maxDims ;
    hsize_t *blockOffset, *blockDim, *blockCount ;
	hid_t   iDataset, qDataset;                     /* File and dataset identifiers */
	hid_t	dataSpace, outputDataSpace, perLineOutput ;			/* dataSpace identifier */
	hid_t	rootGroup ;
	hid_t   dataType ;
    H5T_class_t dataTypeIdentifier ;
    size_t  dataTypeSize ;
    H5S_sel_type selectionType;
    H5T_order_t dataTypeOrder ;
} ;


/* Functions prototypes */
CSVStruct *ICEYEDataReader(CSVStruct *csv) ;
void ICEYEDataReaderHelp(void) ;
void createICEYEDataReaderParameterFileAtPath(char *aPath) ;
keyValue *readICEYEHeader(char *inputPath)  ;
CSLImage *createCSLContainerForIceyeImage(keyValue *header, char flag) ;
void readIQComponents(keyValue *pListAll) ;
void readHDF5FloatMatrixDataset(char *datasetName, keyValue *header) ;
void readHDF5FloatVectorDataset(char *datasetName, keyValue *header) ;
CSVStruct  *readHDF5StringVectorDataset(char *datasetName, keyValue *header) ;
struct hdf5DatasetDescriptor * getHDF5DatasetParams(hid_t dataset) ;
void freeHdf5DatasetDescriptor (struct hdf5DatasetDescriptor *hdf5DatasetParams) ;

void createSLCCalibrationTextFileAtPath(keyValue *header, char *aPath)  ;


/* Operator function */
static herr_t transferAttributeInfoToPList(hid_t parentObject, const char *childObjectName, const H5A_info_t *childObjectInfo, void *sentPointer) ;

/* Operator function to be called by H5Ovisit */
static herr_t visitObjectsIteratively(hid_t parentObject, const char *childObjectName, const H5O_info_t *childObjectInfo, void *sentPointer) ;

static herr_t getAllRank0Data(hid_t parentObject, const char *childObjectName, const H5O_info_t *childObjectInfo, void *rank0pList)  ; 

/* Get HD5 sspace type identifier */
char *getH5SpaceTypeIdentifier(H5T_class_t dataTypeIdentifier) ;

/* Get HD5 string for data type identifier */
char *getHD5DataTypeIdentifier(H5T_class_t dataTypeIdentifier) ;

/* Get HD5 string for data type byte order */
char *getHD5DataTypeByteOrder(H5T_order_t dataTypeOrder) ;


#endif
