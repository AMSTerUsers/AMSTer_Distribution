
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* resmat.h */
/* Librairie d'inversion matricielle et de résolution par substitution */
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
 */

#if !defined(RESMAT)
#define RESMAT

#define TINY 		1.0e-20 ;

#include "vectors.h"
#include "matrix.h"

void ludcmp(double **, int, int *, double *) ;
complexFloat **ludcmpComplexFloat(complexFloat **a, int n, int *indx, float *s) ;
void lubksb(double **, int, int *, double *)  ;
void lubksbComplexFloat(complexFloat **a, int n, int *indx, complexFloat *b) ;
void lubksbComplexDouble(complexDouble **a, int n, int *indx, complexDouble *b) ;
void invertMatrixDouble(double **M, double ** iM, int rank) ;
complexFloat **invertMatrixComplexFloat(complexFloat **M, complexFloat ** iM, int rank) ;
void invertMatrixComplexFloatInDoublePrecision(complexFloat **M, complexFloat ** iM, int rank) ;
void linearSystemResolution(double **theMatrix, double *theVector, int systemOrder) ;

#endif
