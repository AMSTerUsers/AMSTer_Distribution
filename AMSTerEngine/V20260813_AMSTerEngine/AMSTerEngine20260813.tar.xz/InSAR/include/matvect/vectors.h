
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  vectors.h
 *  
 *
 *  Created by dd on Mon Dec 03 2001.
 *  Copyright (c) 2001 Dominique Derauw All rights reserved.
 *
 */

#if !defined(VECTORS)
#define VECTORS

#include <stdio.h>
#include <stdlib.h>
#include "complexTypes.h"


unsigned char	*vectorUChar(int lowerIndex, int higherIndex) ;
short			*vectorShort(int lowerIndex, int higherIndex) ;
int				*vectorInt(int lowerIndex, int higherIndex) ;
int	unsigned    *vectorIntUnsigned(int lowerIndex, int higherIndex) ;
long			*vectorLong(int lowerIndex, int higherIndex) ;
long unsigned	*vectorLongUnsigned(int lowerIndex, int higherIndex) ;
float			*vectorFloat(int lowerIndex, int higherIndex) ;
double			*vectorDouble(int lowerIndex, int higherIndex) ;
complexChar	*vectorComplexChar(int lowerIndex, int higherIndex) ;
complexShort	*vectorComplexShort(int lowerIndex, int higherIndex) ;
complexFloat	*vectorComplexFloat(int lowerIndex, int higherIndex) ;
complexDouble	*vectorComplexDouble(int lowerIndex, int higherIndex) ;
void	*vectorOfType(int lowerIndex, int higherIndex, size_t type) ;

void freeVectorUChar(unsigned char *, int lowerIndex) ;
void freeVectorShort(short *, int lowerIndex) ;
void freeVectorInt(int *, int lowerIndex) ;
void freeVectorIntUnsigned(int unsigned *, int lowerIndex) ;
void freeVectorLong(long *, int lowerIndex) ;
void freeVectorLongUnsigned(long unsigned *v, int lowerIndex) ;
void freeVectorFloat(float *, int lowerIndex) ;
void freeVectorDouble(double *, int lowerIndex) ;
void freeVectorComplexChar(complexChar *, int lowerIndex) ;
void freeVectorComplexShort(complexShort *v, int lowerIndex) ;
void freeVectorComplexFloat(complexFloat *, int lowerIndex) ;
void freeVectorComplexDouble(complexDouble *, int lowerIndex) ;
void freeVectorOfType(void *v, int lowerIndex, size_t type) ;

#endif
