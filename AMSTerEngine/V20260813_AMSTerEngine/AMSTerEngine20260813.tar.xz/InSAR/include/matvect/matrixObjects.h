
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  matrixObjects.h
 *  fluxOptimization
 *
 *  Created by Dominique Derauw on 24/01/12.
 *  Copyright 2012 Dominique Derauw. All rights reserved.
 *
 */

#include "pourtous.h"
#include "matrix.h"
#include "vectors.h"
#include "sortingRoutines.h"

#ifndef MATRIXOBJECTS
#define MATRIXOBJECTS

#ifndef GAUSSIANDEF
#define GAUSSIANDEF
typedef struct {
	double sigma, x0, A ;
	double sigmaX, sigmaY, y0 ;
} Gaussian ;
#endif

typedef struct {
    char *matrixID ;
    int unsigned matrixType ;                          /* float (4) or double (8) */
    int rowLowerIndex, rowUpperIndex, columnLowerIndex, columnUpperIndex ;	/* Matrix indexes */
    int xDim, yDim ;							/* Matrix dimensions */
    int maxValXIndex, minValXIndex ;			/* Min and Max location within matrix */
    int maxValYIndex, minValYIndex ;
    int *histo, histBins, mostPopulatedBin ;	/* Number of bins within histogram */
    double xC, yC ;								/* "Mass" centrer */
    double histMin, histMax ;					/* Interval on which the histogram is computed */
    double noVal ;								/* A masking value */
    int size ;									/* Number of points within the given interval */
    double maxVal, minVal, average, integral ;	/* Min, max, average and integral values of the given matrix */
    double standardDeviation ;
    rectangleType *frame ;
    Gaussian *gaussianDistribution ;
    float **mf ;								/* the Float matrix */
    double **md ;                               /* the double matrix */
    void **m ;                                  /* The matrix */
} matrixObject ;

typedef matrixObject floatMatrix ;
typedef matrixObject doubleMatrix ;

typedef struct {
    char *ID ;
    int lowerIndex, upperIndex ;	            /* Vector indexes */
    int xDim ;							        /* Vector dimension */
    int maxValXIndex, minValXIndex ;			/* Min and Max location within Vector */
    int *histo, histBins, mostPopulatedBin ;	/* Number of bins within histogram */
    float xC ;								    /* "Mass" centrer */
    float histMin, histMax ;					/* Interval on which the histogram is computed */
    float noVal ;								/* A masking value */
    int size ;									/* Number of points within the given interval */
    float maxVal, minVal, average, integral ;	/* Min, max, average and integral values of the given matrix */
    float standardDeviation, median ;
    Gaussian *gaussianDistribution ;
    float *v ;									/* the float vector */
} floatVector ;


matrixObject *allocMatrixObjectofTypeWithIndexes(int unsigned type, int rowLowerIndex, int rowUpperIndex, int columnLowerIndex, int columnUpperIndex) ;
floatMatrix *allocFloatMatrixWithIndexes(int rowLowerIndex, int rowHigherIndex, int columnLowerIndex, int columnHigherIndex) ;
void freeMatrixObject(matrixObject *aMatrix) ;
void freeFloatMatrix(floatMatrix *aFloatMatrix) ;
void statMatWithHistoInterval(floatMatrix *aMatrix, float histMin, float histMax, int histBins) ;
void statMat(floatMatrix *aMatrix) ;
void setFrameOfFloatMatrix(float xMinVal, float yMinVal, float xMaxVal, float yMaxVal, floatMatrix *M) ;
coord2D getPointFromPixelCoordInFloatMatrix(int iX, int iY, floatMatrix *M) ;
double **getMatrixDoubleOfMatrixObject(matrixObject *aMatrix) ;
float **getMatrixFloatOfMatrixObject(matrixObject *aMatrix) ;


/* floatvector routines */
floatVector *allocFloatVectorWithIndexes(int lowerIndex, int upperIndex) ;
floatVector *allocFloatVector(void)  ;
void freeFloatVector(floatVector *aFloatVector) ;
void statOnVectorFloatWithHistoInterval(floatVector *aFloatVector, float histMin, float histMax, int histBins) ;
void statOnVectorFloat(floatVector *aFloatVector) ;






#endif
