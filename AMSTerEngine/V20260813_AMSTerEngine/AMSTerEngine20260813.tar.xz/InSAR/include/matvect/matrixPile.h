
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  matrixPile.h
 *  MCA
 *
 *  Created by Dominique Derauw on 06/01/10.
 *  Copyright 2010 Dominique Derauw All rights reserved.
 *
 */

/* MatrixPile piles definition and allocation on continuous memory space */

#if !defined(MATRIXPILE)
#define MATRIXPILE

#include <stdio.h>
#include <stdlib.h>
#include "complexTypes.h"

unsigned char	***matrixPileUChar(int npl, int nph, int nrl, int nrh, int ncl, int nch) ;
void	freeMatrixPileUChar(unsigned char ***aMatrixPile, int npl, int nrl, int ncl) ;

short	***matrixPileShort(int npl, int nph, int nrl, int nrh, int ncl, int nch) ;
void	freeMatrixPileShort(short ***aMatrixPile, int npl, int nrl, int ncl) ;

short unsigned	***matrixPileShortUnsigned(int npl, int nph, int nrl, int nrh, int ncl, int nch) ;
void	freeMatrixPileShortUnsigned(short unsigned ***aMatrixPile, int npl, int nrl, int ncl) ;

int		***matrixPileInt(int npl, int nph, int nrl, int nrh, int ncl, int nch) ;
void	freeMatrixPileInt(int ***aMatrixPile, int npl, int nrl, int ncl) ;

float	***matrixPileFloat(int npl, int nph, int nrl, int nrh, int ncl, int nch) ;
void	freeMatrixPileFloat(float ***aMatrixPile, int npl, int nrl, int ncl) ;

double	***matrixPileDouble(int npl, int nph, int nrl, int nrh, int ncl, int nch) ;
void	freeMatrixPileDouble(double ***aMatrixPile, int npl, int nrl, int ncl) ;

complexFloat	***matrixPileComplexFloat(int npl, int nph, int nrl, int nrh, int ncl, int nch) ;
void	freeMatrixPileComplexFloat(complexFloat ***aMatrixPile, int npl, int nrl, int ncl) ;

complexDouble	***matrixPileComplexDouble(int npl, int nph, int nrl, int nrh, int ncl, int nch) ;
void	freeMatrixPileComplexDouble(complexDouble ***aMatrixPile, int npl, int nrl, int ncl) ;

#endif
