
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  geoRefUTM.h
//  geoProjection
//
//  Created by Dominique Derauw on 12/07/16.
//
//

#ifndef __geoProjection__geoRefUTM__
#define __geoProjection__geoRefUTM__

#include <stdio.h>

#include "pourtous.h"
#include "ellipsoid.h"

#if !defined(UTM_ZONE)
#define UTM_ZONE
struct zoneUTM {
    char	zoneLatUTM[2] ;
    int		indiceZoneLonUTM ;
    int		indiceZoneLatUTM ;
    double	lambdaC ;
    double	a, b, c, d, e, zkphi, x0, y0 ;
    ellipsoid *ellProj ;
} ;
typedef struct zoneUTM UTMZoneStruct ;

#endif

void UTMZoneForLonLatPoint(point2D *aPoint, UTMZoneStruct *UTMZone) ;
UTMZoneStruct *allocUTMZone(void) ;
void freeUTMZone(UTMZoneStruct *UTMZone) ;
UTMZoneStruct *initUTMReferencingOnEllipsoid(ellipsoid *ellRef) ;
void lonLat2UTMOnEllipsoid(double *lon, double *lat, UTMZoneStruct *UTMZone) ;


#endif /* defined(__geoProjection__geoRefUTM__) */
