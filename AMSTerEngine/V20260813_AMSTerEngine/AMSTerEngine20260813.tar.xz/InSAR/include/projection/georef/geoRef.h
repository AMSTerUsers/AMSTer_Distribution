
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  geoRef.h
 *  geoRef
 *
 *  Created by Dominique Derauw on Thu Feb 21 2002.
 *  Copyright (c) 2002 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(GEOREF)
#define GEOREF


#include "pourtous.h"
#include "infoImage.h"
#include "vectors.h"
#include "matrix.h"
#include "stateVect.h"
#include "ellipsoid.h"
#include "rawFileLib.h"
#include "fileAccessLib.h"
#include "vectorialCalculus.h"
#include "interpStateVect.h"
#include "geoRefUTM.h"
#include "gridMapping.h"

#define FOCALISATION_AU_DOPPLER_ZERO
#define REFERENTIEL_TOURNANT
#define _DEFAULT_HOLE_FILLING_FACTOR_ 2.


typedef rectangleType geoRefFrame ;


typedef struct {
    char    solSelector ;           /* spherical Earth solution selector : 1 for sol1, 0 for sol2 */
    double  lookDirection ;         /* look direction is 1 for right looking and -1 for left looking */
    double	*eq1 ;					/* Doppler centroid equation coefficients */
    double	*eq2 ;					/* Range equation coefficients */
    double	**M, *V, *Vl, *Vc ;		/* 2X2 Matrix and required vectors for system resolution */
    double	*C2, *C4 ;				/* Coefficients ofsecond and fourth order polynomials  */
    double	*sol1, *sol2, *V3 ;		/* Solutions 1 et 2 on spherical Earth, vector3X1 */
	double	*Pg ;					/* Solution on ellipsoid */
    double	a2b2Ratio, a4b4Ratio ;	/* Constantes de calcul. a = demi grand axe, b = demi petit axe de l'ellipsoïde de référence */
    double	a2, b2, e4, b2a2Ratio, b4a4Ratio, R2, R ;
    double	w ;						/* Angular speed of a point on the geoid */
    double rangePosition ;           /* Current range position */
	double	Rt ;					/* Local Earth radius */
	double	at ;					/* Local terrestrial angle */
	double	alpha ;					/* Local incidence angle */
	double	alpha_at ;				/* Boresight elevation angle */
    double  heading ;               /* Local heading angle */
    double  geodeticAngleCosine ;         /* Cosine of the local angle between the Earth radius and the normal to the ellipsoid */
    struct stateVect	*S ;		/* stateVector */
    ellipsoid	*ellProj ;			/* Reference Ellipsoid definition */
} geoRefSolving ;

typedef struct {
    rawFileDescriptor	*input ;	/* Data to be referenced */
    rawFileDescriptor	*DEM ;      /* Data to be referenced */
    rawFileDescriptor	*mask ;		/* A file having the same size than the input file locating points to be projected or not (0) */
    rawFileDescriptor	*xRef ;		/* X referencing file */
    rawFileDescriptor	*yRef ;		/* Y referencing file */
    rawFileDescriptor	*xRadius ;		/* x interpolation radius file */
    rawFileDescriptor	*yRadius ;		/* x interpolation radius file */
} geoRefFiles ;

typedef struct {
    char isUTM ;
    char atDopplerZero ;
	struct infoImage	*info ;		/* Orbital information relative to considered acquisition */ 
    ellipsoid	*ellRef ;			/* Reference ellipsoid */
    ellipsoid	*ellProj ;			/* Projection ellipsoid */
    int xDimInputData ;             /* X and Y dimensions of the data to be georeferenced */
    int yDimInputData ;             /* Should be the same than in *info and in given geoRefFiles */
	float	xReductionFactor ;			/* X reduction factor used to generate input image with respect to full resolution data */
	float	yReductionFactor ;			/* Y reduction factor used to generate input image with respect to full resolution data */
	float	x0 ;					/* Lower left X coordinate of input data with respect to full resolution frame */
	float	y0 ;					/* Lower left Y coordinate of input data with respect to full resolution frame */
	float	xSampling ;				/* xSampling of input image */
	float	ySampling ;				/* ySampling of input image */
	float	xAverageSampling ;			/* xAverageSampling may be used to save average X sampling detected during referencing */
	float	yAverageSampling ;			/* yAverageSampling may be used to save average Y sampling detected during referencing */
	float	xMaxSampling ;				/* xMaxSampling may be used to save maximum X sampling detected during referencing */
	float	yMaxSampling ;				/* yMaxSampling may be used to save maximum Y sampling detected during referencing */
    float   holeFillingFactor ;         /* A factor determining radii of influence of each point. 1 mean, nearest neighbor. 0 mean max radius to reach next intervening point. */
    float	excludingValue ;			/* A value characterizing points than do not have to be georeferenced (not yet implemented) */
    float	DEMExcludingValue ;			/* A value characterizing DEM points than do not have to be georeferenced */
	float	minVal, maxVal ;			/* An height interval outside which values are not georeferenced */
    float   refXShift, refYShift ;      /* A systematic shift to be applied to referenced values (half-pixel shift in case of ENVI format) */
	char	withMasking	;				/* A boolean value stating if a mask have to be used or not */
	UTMZoneStruct *UTMZone ;
    gridMap *DEMGrid ;              /* Reference DEM may be provided as a grid */
    double **affineTransform ;      /* An affine bilinear transform of azimuth - range coordinates may be added */
                                    /* This transform allows to take into account a first referencing with respect to a global master image */
} geoRefPar ;



typedef struct {
	geoRefPar	*params ;
	geoRefFiles *files ;
	geoRefSolving *solving ;
	geoRefFrame	*frame ;				/* Frame defining geoprojected area into the destination geometry */
} geoRef ;



geoRef *allocGeoRef(void) ;
geoRef *allocAndInitGeorefStructureForTargetEllipsoid(struct infoImage *info, ellipsoid *ellProj) ;
void freeGeoRef(geoRef *p) ;
geoRefSolving *allocGeoRefSolvingStructure(void) ;
void	freeGeoRefSolvingStructure(geoRefSolving *p) ;
void	initGeoRefSolvingOnEllipsoid(geoRefSolving *p, ellipsoid *anEllipsoid) ;
geoRefSolving *allocAndInitGeorefSolvingOnEllipsoid(ellipsoid *ellProj) ;
void	initOnSphereSolving(geoRefSolving *p) ;
double	*onSphereSolvingForPoint(double rangePosition, double azimuthPosition,  double h, geoRef *gR) ;
void	onEllipsoidProjection(double *onEllipsoidPoint, double *onSpherePoint, geoRefSolving *geoRefSolvingPointer) ;
void	eqDopplerCentroid(double *eq1, geoRefSolving *p) ;
double	DCEquationConstantTerm(struct infoImage *ima, double rangePosition) ;
void	XYZ2LonLat(double *lon, double *lat, double *Pg, geoRefSolving *p) ;
void	lonLatH2XYZ(double *lonLatH, double *xyz, ellipsoid *aGeoid) ;
void	XYZ2LonLatH(double *xyz, double *lonLatH, geoRefSolving *p) ;
double	earthRadiusAtPoint(double rangePosition, double azimuthPosition, double H, geoRef *gR) ;
float	localRange(double *PSat, double *Pg) ;
double	localIncidenceAngleAtPoint(double rangePosition, double azimuthPosition, double H, geoRef *gR) ;
double	localIncidenceAngle(double *PSat, double *Pg) ;
double	localElevationAngle(double *PSat, double *Pg) ;
void	inversionMatrice2X2(double **M) ;
void	multMatVect2X2(double *V2, double **M, double *V1) ;
void	secondOrderEquationSolving(double *sol, double *coef) ;
double	Newton(double *a, double x0, int N, double precision) ;
void geolocateSceneOnEllipsoid(struct infoImage *info, ellipsoid *ellProj) ;


#endif
