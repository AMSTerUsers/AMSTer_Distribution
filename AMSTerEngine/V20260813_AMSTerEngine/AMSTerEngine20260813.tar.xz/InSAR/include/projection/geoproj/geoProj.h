
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  paramProj.h
 *  dephiProj
 *
 *  Created by Dominique Derauw on Wed Apr 03 2002.
 *  Copyright (c) 2002 Dominique Derauw All rights reserved.
 *
 */

#if !defined(GEO_PROJ_PAR)
#define GEO_PROJ_PAR

#include "pourtous.h"
#include "rawFileLib.h"
#include "matrix.h"
#include "vectors.h"
#include "planeGeometry.h"

#ifndef _UTM_PROJ_
#define _UTM_PROJ_ 0x00000010
#endif

#ifndef _PROJ_WITH_MASKING_
#define _PROJ_WITH_MASKING_ 0x00000020
#endif

#ifndef _SAVE_MAPPING_
#define _SAVE_MAPPING_ 0x00008000
#endif




/* Projection parameters */
typedef struct {
    char	*resamplingMethod ;	/* TRI = triangulation, AVG = average */
    char	*weightingMethod ;		/* ID = inverse distance, LORENTZ = lorentzian, GAUSS = Gaussian-like Point Spread Function */
    char    verticalFlip ;              /* Flag to flip  geoprojected data verticaly to fit with GIS tools */
	double	smoothingFactor ;			/* ID smoothing factor */
	double	exponent ;					/* ID exponent */
	double	FWHM ;						/* Lorentzian Full Width at Half Maximum */
	double	HWHM ;						/* Lorentzian Half Width at Half Maximum */
	double	rx3db ;						/* 3db resolution of a gaussian-like point spread function */
	double	ry3db ;						/* 3db resolution of a gaussian-like point spread function */
    double	xSampling ;					/* X sampling interval in unit of destination projection */
    float   dX, dY ;                    /* pixel shift to cope with (Q)GIS */
    double	ySampling ;					/* Y sampling interval in unit of destination projection */
    float	xRadius ;					/* X radius defining the area on which intervening points are considered */
    float	yRadius ;					/* Y radius defining the area on which intervening points are considered */
    int     maxNumberOfInterveningPoints ;
	char	isDEMPresent ;
    float	noVal ;                     /* A value characterizing points that contain no information */
    float	DEMExcludingValue ;			/* A value characterizing DEM points that do not have to be projected */
	float	minVal, maxVal ;			/* An height interval outside which values are not geoprojected */
	char	withMasking	;				/* A boolean value stating if a mask have to be used or not */
    size_t xDimM ;						/* Projection Matrix X dimension */
    size_t yDimM ;						/* Projection Matrix Y dimension */
	long unsigned volume ;					/* Projection Matrix volume */
	char isUTM ;
    char UTMZone[5] ;
    int unsigned flag ;
} geoProjPar ;


/* References to required files */
typedef struct {
    char *geoProjDir ;
    char *genericExtension ;
    rawFileDescriptor	*input ;
    rawFileDescriptor	*output ;
    rawFileDescriptor	*DEM ;
    rawFileDescriptor	*mask ;		/* A file having the same size than the input file locating points to be projected */
    rawFileDescriptor	*xRef ;		/* X referencing file */
    rawFileDescriptor	*yRef ;		/* Y referencing file */
    rawFileDescriptor   *xRadius ;  /* X interpolation radius file */
    rawFileDescriptor   *yRadius ;  /* Y interpolation radius file */
    rawFileDescriptor	*M ;	/* Projection Matrix file */
    rawFileDescriptor	*IM ;	/* Inverse projection Matrix file */
} geoProjFiles ;



/* Mapping structure */
#if !defined(LMP)
#define LMP

struct lmp {
    unsigned short	l ;
    unsigned short	m ;
    float		p ;
} ;
#endif

typedef rectangleType geoProjFrame ;

typedef struct {
    char unsigned *countingMap ;
    float **xRef ;
    float **yRef ;
    float **DEM ;
    float **source ;
    float **output ;
    struct lmp *projectionMap ;
} geoProjData ;


typedef struct {
	geoProjPar		*params ;
	geoProjFiles	*files ;
	geoProjFrame	*frame ;			/* Frame defining geoprojected area into the destination geometry */
} geoProj ;


typedef geoProj	satProj ;

void geoProjection(geoProj *pGeoProj) ;
void	findInterveningPoints(geoProj *pGeoProj) ;
struct lmp	*allocProjectionTable(geoProj *pGeoProj) ;
void	freeProjectionTable(struct lmp *m) ;
void    weightCalculation(struct lmp *table, geoProj *pGeoProj)  ;
void    resampling(struct lmp *table, geoProj *pGeoProj) ;
void    resamplingUsingSavedMapping(geoProj *pGeoProj) ;
void    additiveResampling(struct lmp *table, geoProj *pGeoProj) ;
float	triangulation(struct lmp *table, long unsigned anIndex, unsigned char M, int iX, int iY, geoProj *pGeoProj, float **source, float **X, float **Y)  ;
float	addititveTriangulation(struct lmp *table, long unsigned anIndex, unsigned char M, int iX, int iY, geoProj *pGeoProj, float **source, float **X, float **Y)  ;
char	isIncludedInTriangle(double C1, double C2, double C3) ;
float	**readSource(geoProj *pGeoProj) ;
void roundGeoProjFrame(geoProj *pGeoProj) ;

geoProj *allocGeoProj(void) ;
void freeGeoProj(geoProj *) ;

void inverseProjectionMatrixComputation(geoProj *pGeoProj)  ;
long projectionTableSize(geoProj *pGeoProj) ;
void saveProjectionTable(struct lmp *table, geoProj *pGeoProj) ;
struct lmp *readProjectionTable(geoProj *pGeoProj) ;
void sortLMP(int n, struct lmp *serie, int unsigned *kVect, int unsigned *lVect) ;


#endif
