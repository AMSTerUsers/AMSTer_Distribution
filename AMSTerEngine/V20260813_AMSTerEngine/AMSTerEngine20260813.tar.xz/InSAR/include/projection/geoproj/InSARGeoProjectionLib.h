
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  InSARGeoProjectionLib.h
 *  geoProjection
 *
 *  Created by Dominique Derauw on 22/11/11.
 *  Copyright 2011 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(INSARGEOPROJLIB)
#define INSARGEOPROJLIB

#include "pourtous.h"
#include "paramInSAR.h"
#include "matrix.h"
#include "vectors.h"
#include "geoProj.h"
#include "geoRef.h"
#include "projUTM.h"
#include "counters.h"
#include "paramLib.h"
#include "planeGeometry.h"
#include "rawFileManipulation.h"
#include "gridMapping.h"
#include "slantRangeDEMLib.h"
#include "InSARSlantRangeProjectionLib.h"
#include "infoImageS1.h"
#include "S1DataReaderLib.h"



#define _EXTERNAL_DEM_REPROJECTION_ 0x00000010
#define _USE_EXTERNAL_DEM_ 0x00000020
#define _NEAREST_NEIGHBOR_ 0x00000040
#define _FILL_HOLES_ 0x00000080
#define _FLIP_ 0x00000100
#define _ESRI_HEADER_ 0x00000200
#define _CLEAN_PROJECTION_ 0x00000400
#define _POLINSAR_PRODUCTS_PROJECTION_ 0x00000800
#define _ON_GEOID_ 0x00001000
#define _COPY_SM2M_PROCESSING_PARAMETERS_ 0x00002000
#define _USE_INSAR_KML_ 0x00004000
#define _SAVE_MAPPING_ 0x00008000

int geoProjectionMain(CSVStruct *csv_CL) ;
void geoProjectionHelp(void) ;

void geoProjectPolInSARProducts(InSARParametersStruct *pInSAR, geoProj *pGeoProj, keyValue *geoProjParams) ;
void projectPolarimetricFileSeries(CSVStruct *filePath, InSARParametersStruct *pInSAR, geoProj *pGeoProj) ;
void geoProjectInSARProducts(InSARParametersStruct *pInSAR, geoProj *pGeoProj, keyValue *geoProjParams)  ;
void updateGeoProjectionParametersFile(geoProj *pGeoProj, keyValue *geoProjParams) ;
geoRef *initGeoRefStructure(keyValue *params, InSARParametersStruct *pInSAR) ;
void computeFrameFromGeoRef(geoRef *pGeoRef)  ;
void geoReferenceDEM(geoRef *pGeoRef, int unsigned  flag) ;
void cropInSARProducts(InSARParametersStruct *pInSAR) ;
void createGeoProjectionParametersFileAtPath(char *InSARPath) ;
geoProj *initGeoProjStructure(keyValue *paramList, InSARParametersStruct *pInSAR)  ;
void generateESRIHeaderForGeoProjectedProductAtPath(char *aPath, geoProj *pGeoProj) ;
void generateENVIHeaderForGeoProjectedProductAtPath(char *aPath, geoRef *pGeoRef, geoProj *pGeoProj, InSARParametersStruct *pInSAR) ;
void geoProjectInputProduct(InSARParametersStruct *pInSAR, char *geoProjDir, geoProj *pGeoProj, char *genericExtension) ;
void geoProjectProduct(InSARParametersStruct *pInSAR, char *geoProjDir, geoProj *pGeoProj, char *genericExtension) ;
void flipGeoprojectedProduct(InSARParametersStruct *PInSAR, geoProj *pGeoProj) ;
void nonMaskedMappingComputation(geoProj *pGeoProj) ;


#endif
