/* 
*  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version. 
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 * 
 *  You should have received a copy of the GNU Affero General Public License 
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**************************************************
 * File name : EGMLib.h
 * Author : Dominique Derauw
 * Date : 2026-02-03
 * Copyright 2026 Dominique Derauw
 * Description : Library to manage Earth Goidal Models
 *      These ones can be downloaded from :
 *      https://geographiclib.sourceforge.io/C++/doc/geoid.html
 **************************************************/



#if !defined(__EGMLib__)
#define __EGMLib__

#include <stdio.h>
#include "pourtous.h"
#include "vectors.h"
#include "matrix.h"
#include "rawFileLib.h"
#include "stringLib.h"
#include "paramLib.h"
#include "planeGeometry.h"
#include "gridMapping.h"
#include "byteSwap.h"
#include "slantRangeDEM.h"


gridMap *getEGMGrid(polygon *aoi, int XDim, int YDim, char *EGMID) ;
char* addEGMToExistingDEM(keyValue *DEMHeader, char *EGMID) ;

#endif