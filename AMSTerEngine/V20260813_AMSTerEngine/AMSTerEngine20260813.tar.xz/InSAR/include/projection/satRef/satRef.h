
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  satRef.h
 *  ground2SlantProj
 *
 *  Created by Dominique Derauw on 8/09/08.
 *  Copyright 2008 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(SATREF)
#define SATREF

#include "geoRef.h"
#include "vectorialCalculus.h"
#include "aoiHandling.h"

typedef geoRefFiles satRefFiles ;
typedef geoRefPar satRefPar ;
typedef geoRefFrame satRefFrame ;

/* Definition of a satRef structure equivalent to a geoRef structure */
/* It is simply intended to use a structure name in agrement with the target action */
/* The structure contains a georef structure made of it self. This will allow satRaf Structure to evolve itself if required, keeping the geoRef structure skeleton */
typedef struct {
	satRefPar	*params ;
	satRefFiles *files ;
	geoRefSolving *solving ;
	satRefFrame	*frame ;				/* Frame defining geoprojected area into the destination geometry */
	geoRef *gR ;
	char isGeo2SRApproxTransformComputed ;
	double **geo2SRApproxTransform ;
} satRef ;

satRef *allocSatRef(void) ;
void freeSatRef(satRef *sR) ;
satRef *allocAndInitSatRefWithGeoRefStructure(geoRef *gR) ;
double **geo2SlantRangeAzimuthApproximateTransform(satRef *sR) ;
double	approxAz(double lon, double lat, double *C)  ;
double	approxRa(double lon, double lat, double *C)  ;
void	approximateRangeAzimuthForLonLat(double *lonLatH, double *approxAzRa, satRef *sR) ;
void	rangeAzimuthReferencingOfpoint(double *lonLatH, double *xy, satRef *sR ) ;
polygon *convertAoIFromDeg2SRA(polygon *aoi, SLCImageInfo *info, double *H) ;
polygon *convertAoIFromDeg2SRAForHeight(polygon *aoi, SLCImageInfo *info, double height) ;

#endif

