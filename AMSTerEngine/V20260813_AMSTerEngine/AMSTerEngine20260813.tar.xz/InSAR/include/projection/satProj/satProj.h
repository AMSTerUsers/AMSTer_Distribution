
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  slantRangeProj.h
 *  ground2SlantProj
 *
 *  Created by Dominique Derauw on 26/11/08.
 *  Copyright 2008 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(SLANT_PROJ_PAR)
#define SLANT_PROJ_PAR

#include "pourtous.h"
#include "rawFileLib.h"
#include "fileAccesLib.h"

/* slantRangeProj is similar to geoproj */ 
/* It only differs in the fact that only one resampling method is consider */ 
/* This latter one is a weighted average in wich the weight is the integral of the point spread function around the considered position */ 

/* Projection parameters */
typedef struct {
	double	Rx ;						/* 3db Range resolution */
	double	Ry ;						/* 3db Azimuth resolution */
    float	xSampling ;					/* X sampling interval in unit of destination projection */
    float	ySampling ;					/* Y sampling interval in unit of destination projection */
    float	xRadius ;					/* X radius defining the area on which intervening points are considered */
    float	yRadius ;					/* Y radius defining the area on which intervening points are considered */
	char	isDEMPresent ;
	float	noVal ;						/* A value characterizing points than do not have to be projected */
	char	withMasking	;				/* A boolean value stating if a mask have to be used or not */
    int		xDimM ;						/* Projection Matrix X dimension */
    int		yDimM ;						/* Projection Matrix Y dimension */
	int		volume ;					/* Projection Matrix volume */
} slantRangeProjPar ;


/* References to files required */
typedef struct {
    rawFileDescriptor	*input ;
    rawFileDescriptor	*output ;
    rawFileDescriptor	*DEM ;
    rawFileDescriptor	*mask ;		/* A file having the same size than the input file locating points to be projected or not (0) */
    rawFileDescriptor	*xRef ;		/* X referencing file */
    rawFileDescriptor	*yRef ;		/* Y referencing file */
    rawFileDescriptor	*M ;	/* projection Matrix file */
} slantRangeProjFiles ;

typedef struct {
	float xMin, yMin ;
	float xMax, yMax ;
} slantRangeRefFrame ;

/* Mapping structure */
#if !defined(LMP)
#define LMP

struct lmp {
    unsigned short	l ;
    unsigned short	m ;
    float		p ;
} ;
#endif


typedef struct {
	slantRangeProjPar		*params ;
	slantRangeProjFiles		*files ;
	slantRangeRefFrame		*frame ;			/* Frame defining geoprojected area into the destination geometry */
} slantRangeProj ;

void slantRangeProjection(slantRangeProj *gP) ;
void	findInterveningPoints(slantRangeProj *gP) ;
struct lmp	*allocProjectionTable(slantRangeProj *gP) ;
void	freeProjectionTable(struct lmp *m) ;
void    weightCalculation(struct lmp *table, slantRangeProj *gP)  ;
void    resampling(struct lmp *table, slantRangeProj *gP) ;
float	triangulation(struct lmp *table, int index, unsigned char M, int iX, int iY, slantRangeProj *gP, float **source, float **X, float **Y)  ;
char	isIncludedInTriangle(double C1, double C2, double C3) ;
float	**readSource(slantRangeProj *gP) ;

slantRangeProj *allocSlantRangeProj(void) ;
void freeSlantRangeProj(slantRangeProj *) ;

#endif
