
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  Header.h
//  slantRangeDEM
//
//  Created by Dominique Derauw on 21/05/13.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#ifndef slantRangeDEMLib_Header_h
#define slantRangeDEMLib_Header_h

#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "infoImage.h"
#include "paramInSAR.h"
#include "interpStateVect.h"
#include "approxRt.h"
#include "satRef.h"
#include "geoProj.h"
#include "counters.h"
#include "gridMapping.h"
#include "ENVIHeaderManagement.h"
#include "byteSwap.h"

#ifndef _PROJECT_DEM_
#define _PROJECT_DEM_           0x00000010
#endif

#ifndef _PROJECT_MASK_
#define _PROJECT_MASK_          0x00000020
#endif

#ifndef _NEAREST_NEIGHBOR_
#define _NEAREST_NEIGHBOR_      0x00000040
#endif

#ifndef _FILL_HOLES_
#define _FILL_HOLES_            0x00000080
#endif

#define _FLIP_MASK_             0x00000100
#define _FLIP_DEM_              0x00000200
#define _FLIP_DATA_             0x00000400
#define _KEEP_EXTRACTED_DEM_    0x00000800
#define _GRADIENTS_PROJECTION_  0x00001000
#define _AMPLITUDE_SIMULATION_  0x00002000
#define _IS_GEOGRAPHICAL_MASK_  0x00004000
#define _IS_THRESHOLD_MASK_     0x00008000
#define _IS_DETREND_MASK_       0x00010000
#define _IS_EVENT_MASK_         0x00020000
#define _IS_LAST_MASK_          0x00040000


struct externalDEM {
    char *DEMPath, *DEMName ;
    int unsigned flag ;
    double holeFillingFactor ;
    double layoverThreshold ;
    rawFileDescriptor *dataFile ;
} ;
typedef struct externalDEM externalDEMStruct ;

/* The 3 first masks are in this order: */
/* - 1 - a purely geographical mask (water bodies, border limits, ...) */
/* - 2 - a threshold mask to re-consider pixels above a give coherence threshold */ 
/* - 3 - a constant detrend mask mask zone to not be considered in the detrend calculation */
/* The other masks are dated masks all named eventMaskYYYYMMDD to exclude event zone for detrending calculation */
struct maskStruct {
    char *maskName ;
    char maskVal ;
    int unsigned flag ;
    rawFileDescriptor *dataFile ;
} ;
typedef struct maskStruct maskStruct ;

int slantRangeDEM(CSVStruct *clCSV) ;
void slantRangeDEMUsage(void) ;
keyValue *createSRDParameterList(void) ;
void createSRDParameterFileAtPath(char *aPath) ;
externalDEMStruct *openExternalDEMFile(char *DEMPath, CSVStruct *clCSV) ;
maskStruct **openExternalMaskFiles(keyValue *parametersList) ;
void freeExternalDEMStruct(externalDEMStruct *externalDEM) ;
satRef *slantRangeReferencingOfDEM(externalDEMStruct *externalDEM, CSLImage *masterImage, keyValue *parameterList) ;
geoProj *initSlantRangeProjection(satRef *satRefMaster, CSLImage *masterImage, keyValue *parametersList, char saveMapping) ;
void slantRangeDEMProjection(geoProj *gP, externalDEMStruct *externalDEM) ;
void slantRangeMaskProjection(geoProj *gP, externalDEMStruct *externalDEM, maskStruct **mask) ;
void externalFloatFilesProjection(geoProj *gP, externalDEMStruct *externalDEM, char *floatFilesDir) ;
void slantRangeGradientsProjection(geoProj *gP, externalDEMStruct *externalDEM) ;
void simulMod(geoProj *gP, satRef *sR) ;
void unlinkTemporaryFiles(geoProj *gP) ;
double updateSceneAverageHeight(CSLImage *masterImage, externalDEMStruct *externalDEM) ;
char *getGeoreferencedDataFilePath(char *filePath) ;
rawFileDescriptor *getGeoreferencedDataFile(char *aPath) ;


#endif
