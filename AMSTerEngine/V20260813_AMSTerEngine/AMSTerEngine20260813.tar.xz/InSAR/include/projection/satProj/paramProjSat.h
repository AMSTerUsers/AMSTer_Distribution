
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  paramProjSat.h
 *  projSat
 *
 *  Created by Dominique Derauw on Fri Mar 21 2003.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
 */

#include <Carbon/Carbon.h>
#if !defined(PARAMPROJSAT)
#define PARAMPROJSAT

#include "pourtous.h"
#include "param.h"
#include "geoRef.h"
#include "ellipsoid.h"
#include "infoImage.h"
#include "interpStateVect.h"


#if !defined(BORD)
#define BORD
struct bord {
    float	xMin ;
    float	xMax ;
    float	yMin ;
    float	yMax ;
    double	*lat ;
    double	*lon ;
} ;
#endif

typedef struct {
    FILE	*fX, *fY, *fM, *fSource ;
    char	*accesParamProjSat ;
    char	*accesMNTRef ;
    char	*nomMNTRef ;
    char	*cLon00 ;
    char	*cLat00 ;
    float	lon00 ;
    float	lat00 ;
    int		dimLonRef ;
    int		dimLatRef ;
    char	*cPasLonRef ;
    char	*cPasLatRef ;
    float	pasLonRef ;
    float	pasLatRef ;
    struct ellipsoid	*ellRef ;
    char	*accesParamInSAR ;
    struct param	*paramInSAR ;
    struct ellipsoid	*ellProj ;
    char	*accesRes ;
    char	*nomMNTProj ;
    char	*nomModProj ;
    char	*nomPhiProj ;
    int		Sbaz ;
    int		Sgra ;
    int		Shaz ;
    int		Sdra ;
    char	*methode ;			/* Méthode d'interpolation: "TRI" = triangulation, "ID" = inverse distance */
    int		dimXM, dimYM, volume ;		/* dimensions et volume de la carte de projection */
    float	rayonY ;			/* rayon d'influence en azimut d'un point du MNT de référence */
    float	rayonX ;			/* rayon d'influence en range d'un point du MNT de référence */
    float	pasY ;				/* Pas d'échantillonnage en azimut */
    float	pasX ;    			/* Pas d'échantillonnage en range */
    struct infoImage	*infoImage1, *infoImage2 ;
    double	*CX1, *CZ1, *CX2, *CZ2 ;
    struct bord	b1, b2 ;
    geoRefSolving	*sr1, *sr2 ;
    double	*lonLatH ;
    double	*xyz ;
    double	*azRa ;
} paramProjSat ;

paramProjSat	*allocProjSat(const char **) ;
void	libParProjSat(paramProjSat *) ;
void 	initProjSat(paramProjSat *) ;
void	lectureParamProjSat(FILE *, paramProjSat *) ;
void	ecritureParamProjSat(paramProjSat *) ;
char 	*readFirstStringIn(char *) ;
float	readDDIn(char *texte) ;
char 	*absoluteAccessPathFromPath(char *) ;
void	initInfoImages(paramProjSat *) ;

#endif
