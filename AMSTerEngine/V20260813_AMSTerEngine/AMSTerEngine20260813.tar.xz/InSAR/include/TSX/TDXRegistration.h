
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  TDXRegistration.h
//  SBInSAR
//
//  Created by Dominique Derauw on 20/12/16.
//  Copyright © 2016 Dominique Derauw. All rights reserved.
//

#ifndef TDXRegistration_h
#define TDXRegistration_h

#include "gridMapping.h"
#include "byteSwap.h"
#include "rawFileLib.h"
#include "paramLib.h"
#include "infoImage.h"
#include "paramInSAR.h"

struct fltHeader {
    int unsigned id ;
    int unsigned xDim ;
    int unsigned yDim ;
    int unsigned headerSize ;
    int unsigned dataSize ;
    int unsigned IDontKnowWhatItIS_0 ;
    int unsigned IDontKnowWhatItIS_1 ;
    int unsigned IDontKnowWhatItIS_2 ;
};
typedef struct fltHeader fltHeader ;

gridMap *TDXSpecificCase(InSARParametersStruct *pInSAR, keyValue *p) ;
char isTDXInSARPair(InSARParametersStruct *pInSAR) ;
gridMap *TDXCoregistrationManagement(keyValue *p) ;


#endif /* TDXRegistration_h */
