
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  TSXDataReaderLib.h
//  TSXDataReader
//
//  Created by Dominique Derauw on 10/01/2020.
//  Copyright © 2020 Dominique Derauw. All rights reserved.
//

#ifndef TSXDataReaderLib_h
#define TSXDataReaderLib_h

#include <stdio.h>

#include <stdlib.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "infoImageTSX.h"
#include "byteSwap.h"
#include "counters.h"
#include "vectors.h"
#include "ieeehalfprecision.h"

/* Functions prototypes */
void TSXDataReaderHelp(void) ;
void createTSXDataReaderParameterFileAtPath(char *aPath) ;
void readTSXDataLayersInto(CSLImage *thisImage, struct infoImage *info, char *XMLPath, char isTandem) ;
CSVStruct *TSXDataReader(CSVStruct *csv) ;

#endif /* TSXDataReaderLib_h */
