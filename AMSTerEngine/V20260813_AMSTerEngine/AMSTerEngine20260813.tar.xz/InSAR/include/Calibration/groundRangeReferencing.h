
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  groundRangeReferencing.h
//  SLC2MDG
//
//  Created by Dominique Derauw on 26/03/13.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#ifndef SLC2MDG_groundRangeReferencing_h
#define SLC2MDG_groundRangeReferencing_h

#include "pourtous.h"
#include "tileToolLib.h"
#include "infoImage.h"
#include "geoRef.h"
#include "vectors.h"
#include "matrix.h"
#include "resmat.h"
#include "gridMapping.h"
#include "rawFileLib.h"


struct grRef {
    int x0InputImage, y0InputImage, xDimInputImage, yDimInputImage ;
    float **xReferencing, **yReferencing ;
    float minGroundRange, minAzimuth ;
    float maxGroundRange, maxAzimuth ;
    double rangeScalingFactor, azimuthScalingFactor ;
    double rangeSampling, azimuthSampling ;
    double *s2gTransform ;
    tileTool *inputTile ;
    gridMap *s2gGrid ;
    rawFileDescriptor *xRefFile ;
    rawFileDescriptor *yRefFile ;
    rawFileDescriptor *mlData ;
} ;

typedef struct grRef grRef;


void unlinkS2GTemporaryFiles(geoRef *gR) ;
void groundRangeReferencingOfTile(tileTool *inputTile, geoRef *gR, gridMap *s2gGrid) ;
gridMap *computeGroundRangeReferencingGrid(geoRef *gR) ;
void computeGroundRangeReferencingTransform(grRef *grRefTool, SLCImageInfo *SLCInfo) ;


#endif
