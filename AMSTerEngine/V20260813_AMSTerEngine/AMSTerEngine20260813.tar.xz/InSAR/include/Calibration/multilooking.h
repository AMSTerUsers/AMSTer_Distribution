
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  multilooking.h
//  SLC2MDG
//
//  Created by Dominique Derauw on 25/03/13.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#ifndef SLC2MDG_multilooking_h
#define SLC2MDG_multilooking_h

#include "pourtous.h"
#include "tileToolLib.h"
#include "infoImage.h"
#include "complexCalculus.h"
#include "fft.h"
#include "interpolCZT.h"
#include "polynomials.h"

#define RANGE_ZOOM_FACTOR 2


struct MLStruct {
    char expressInDB ;
    int NLooks ;
    int xTileIndex, yTileIndex ;
    int singleLookAzimuthTileSize ;
    int singleLookRangeTileSize ;
    int singleLookAzimuthTileBorder ;
    int singleLookRangeTileBorder ;
    int sublookRangeTileSize ;
    int sublookAzimuthTileSize ;
    int sublookRangeTileBorder ;
    int sublookAzimuthTileBorder ;
    int detectedRangeTileSize ;
    int detectedAzimuthTileSize ;
    int detectedRangeTileBorder ;
    int detectedAzimuthTileBorder ;
    int xBoxAveragingSize, yBoxAveragingSize ;
    double rangeScalingFactor, azimuthScalingFactor ;
    double rangeZoomFactor, azimuthZoomFactor ;
    double rangeSampling ;
    double prf, azimuthBandwidth ;
    double hammingFactor, *hammingFilter, *deHammingFilter ;
    double *passBandFilter ;
    xPolynomial *fdc ;
    tileTool **sublook, *detectedMultilookedImage ;
    StructFFT *azimuthFFTOfinputTile, *azimuthFFTOfSublookTile ;
    rawFileDescriptor *mlData ;
    SLCImageInfo *SLCInfo ;
};

typedef struct MLStruct MLStruct;


void multilooking(tileTool *inputData, MLStruct *ml) ;

/* Allocation and initalization of multilooking must be performed using the following functions in sequence */
MLStruct *allocMLStruct() ;
void initMLTileTools(MLStruct *ml, rawFileDescriptor *inputFile) ;
void initMLTemporaryDataFileAtPath(MLStruct *ml, char *directoryPath) ;
void initMultilooking(MLStruct *ml) ;

void freeMultilook(MLStruct *ml) ;
void DCCentringOfTile(tileTool *inputData, MLStruct *ml) ;
void applyDeHammingFilter(tileTool *inputDataTile, MLStruct *ml) ;
void transferDataToSubLooks(tileTool *inputDataTile, MLStruct *ml) ;
void sublookZoom(MLStruct *ml) ;
void multilookDetection(MLStruct *ml) ;
void cleanAllTiles(tileTool *inputDataTile, MLStruct *ml) ;


#endif
