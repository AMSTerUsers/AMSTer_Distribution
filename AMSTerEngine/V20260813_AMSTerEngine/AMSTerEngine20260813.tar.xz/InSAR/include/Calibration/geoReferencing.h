
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  geoReferencing.h
//  SLC2MDG
//
//  Created by Dominique Derauw on 10/05/13.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#ifndef SLC2MDG_geoReferencing_h
#define SLC2MDG_geoReferencing_h

#include "pourtous.h"
#include "geoRef.h"
#include "projUTM.h"
#include "counters.h"
#include "tileToolLib.h"
#include "gridMapping.h"

void georeferencingOfTile(tileTool *inputTile, geoRef *gR, gridMap *DEMGrid) ;
void flatEarthGeoreferencing(geoRef *pGeoRef) ;


#endif
