
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  SLC2MDG.h
//  SLC2MDG
//
//  Created by Dominique Derauw on 12/03/13.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#ifndef SLC2MDG_SLC2MDG_h
#define SLC2MDG_SLC2MDG_h

#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "tileToolLib.h"
#include "rawFileLib.h"
#include "infoImage.h"
#include "ceil2.h"
#include "gridMapping.h"
#include "geoRef.h"
#include "complexCalculus.h"
#include "fft.h"
#include "interpolCZT.h"
#include "multilooking.h"
#include "groundRangeReferencing.h"
#include "geoReferencing.h"
#include "geoProj.h"
#include "counters.h"
#include "planeGeometry.h"

#define RANGE_TILE_SIZE 1024        /* Must be a power of 2 */
#define AZIMUTH_TILE_SIZE 2048      /* Must be a power of 2 */
#define RANGE_TILE_BORDER 64
#define AZIMUTH_TILE_BORDER 128


struct calibrationParameters {
    char isRangeSpreadingLossCompensationDone ;
    char isRangeNormalizationDone ;
    char isIncidenceAngleCompensationDone ;
    char isIncidenceAngleNormalizationDone ;
    char isDetectionInDB ;
    int NLayers, currentLayer ;
    int NLooks ;
    int *NSamples ;
    int rangeTileSize ;
    int azimuthTileSize ;
    int rangeTileBorder ;
    int azimuthTileBorder ;
    int xBoxAveragingSize ;
    int yBoxAveragingSize ;
    double *calibrationFactor ;
    double rescalingFactor ;
    double minimumSlantRange, rangeSampling, referenceRange, rangeExponent ;
    double referenceIncidenceAngle, incidenceAngleFactor ;
    double *beamOffNadirAngle, *angularSampling, *angularOrigin ;
    double **rangeAntennaPattern ;
    double hammingFactor ;
    SLCImageInfo *SLCInfo ;
    CSVStruct *polMode ;
    gridMap *incidenceAngleGridMap ;
    gridMap *antennaPatternGridMap ;
    rawFileDescriptor **dataLayer ;
} ;

typedef struct calibrationParameters calibrationParams ;


void usage(void) ;
void createExampleParameterFileAtPath(const char *aPath) ;
void SLC2MDG(keyValue *paramList) ;
void rangeSpreadingLossCompensation(tileTool *inputData, calibrationParams *cal) ;
void incidenceAngleCompensation(tileTool *inputData, calibrationParams *cal) ;
void antennaPatternCorrection(tileTool *inputData, calibrationParams *cal) ;
void absoluteCalibration(tileTool *inputData, calibrationParams *cal) ;
calibrationParams *initCalibrationParameters(CSLImage *inputImage, keyValue *paramList) ;
void freeCalibrationStructure(calibrationParams *cal) ;
gridMap *allocAndInitIncidenceAngleGridMap(struct infoImage *SLCInfo) ;
gridMap *allocAndInitAntennaPatternGridMapForLayer(int layerIndex, calibrationParams *cal) ;
MLStruct *allocAndInitMultilooking(int NLooks, double hammingFactor, SLCImageInfo *SLCInfo) ;
geoRef *allocAndInitGeoReferencingForInputImage(CSLImage *inputImage, SLCImageInfo *info, MLStruct *multiLooking) ;
geoProj *allocAndInitGeoprojection(keyValue *paramList, SLCImageInfo *SLCInfo, geoRef *gR) ;
void transferProcessingValuesToMLStructure(calibrationParams *cal, MLStruct  *ml) ;
void updateGeoProjParameters(geoProj *gP, keyValue *paramList, SLCImageInfo *SLCInfo, geoRef *gR) ;
char *accessPathToTextFileAndUpdateOutputFilePath(geoProj *gP, keyValue *paramList, calibrationParams *cal, int layerIndex) ;
void projectionOfLayer(geoProj *gP, int layerIndex, int Nlayers) ;
void unlinkMapping(geoProj *gP) ;
void kmlBasicExport(char *aPath, geoProj *gP) ;
gridMap *allocAndInitDEMGridForImage(CSLImage *anImage) ;

#endif
