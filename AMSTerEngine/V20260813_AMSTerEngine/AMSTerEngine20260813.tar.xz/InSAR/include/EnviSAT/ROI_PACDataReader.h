
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  ROI_PACDataReader.h
//  ROI_PACDataReader
//
//  Created by Dominique Derauw on 20/07/15.
//  Copyright (c) 2015 Dominique Derauw. All rights reserved.
//

#ifndef ROI_PACDataReader_ROI_PACDataReader_h
#define ROI_PACDataReader_ROI_PACDataReader_h

#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "infoImage.h"
#include "byteSwap.h"
#include "counters.h"
#include "vectors.h"

void usage() ;
void createParameterFileAtPath(int argc, const char * argv[]) ;
SLCImageInfo *createInfoImageFromROI_PAC_RSCFile(keyValue *parametersList) ;
keyValue *convertRSCFileToKeyValueList(char *aPath) ;


#endif
