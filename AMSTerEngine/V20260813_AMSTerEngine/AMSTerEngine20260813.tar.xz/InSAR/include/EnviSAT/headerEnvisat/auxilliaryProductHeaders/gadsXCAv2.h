
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  gadsXCA.h
 *  externalCalibrationDataHandler
 *
 *  Created by Dominique Derauw on Tue Jul 01 2003.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
 */
#if !defined(GADS_XCA)
#define GADS_XCA

#include "MJD.h"

typedef struct {
    MJD		timeOfCreation ;
    unsigned long	DSRLength ;
    float	XCalScalingFactor_IM_SLC_HH[7] ;
    float	XCalScalingFactor_IM_SLC_VV[7] ;
    float	XCalScalingFactor_IM_PRI_HH[7] ;
    float	XCalScalingFactor_IM_PRI_VV[7] ;
    float	XCalScalingFactor_IM_GEC_HH[7] ;
    float	XCalScalingFactor_IM_GEC_VV[7] ;
    float	XCalScalingFactor_IM_MED_HH[7] ;
    float	XCalScalingFactor_IM_MED_VV[7] ;
    float	XCalScalingFactor_AP_SLC_HH[7] ;
    float	XCalScalingFactor_AP_SLC_VV[7] ;
    float	XCalScalingFactor_AP_SLC_HV[7] ;
    float	XCalScalingFactor_AP_SLC_VH[7] ;
    float	XCalScalingFactor_AP_PRI_HH[7] ;
    float	XCalScalingFactor_AP_PRI_VV[7] ;
    float	XCalScalingFactor_AP_PRI_HV[7] ;
    float	XCalScalingFactor_AP_PRI_VH[7] ;
    float	XCalScalingFactor_AP_GEC_HH[7] ;
    float	XCalScalingFactor_AP_GEC_VV[7] ;
    float	XCalScalingFactor_AP_GEC_HV[7] ;
    float	XCalScalingFactor_AP_GEC_VH[7] ;
    float	XCalScalingFactor_AP_MED_HH[7] ;
    float	XCalScalingFactor_AP_MED_VV[7] ;
    float	XCalScalingFactor_AP_MED_HV[7] ;
    float	XCalScalingFactor_AP_MED_VH[7] ;
    float	XCalScalingFactor_WM_HH[7] ;
    float	XCalScalingFactor_WM_VV[7] ;
    float	XCalScalingFactor_WS_HH ;
    float	XCalScalingFactor_WS_VV ;
    float	XCalScalingFactor_GM_HH ;
    float	XCalScalingFactor_GM_VV ;
    float	refElevationAngleIS[7] ;
    float	refElevationAngleSS1 ;
    float	twoWayAntElPatGainIS[7][4][201] ;
    float	twoWayAntElPatGainSS1HH[201] ;
    float	twoWayAntElPatGainSS1VV[201] ;
    float	twoWayAntElPatGainSS1HV[201] ;
    float	twoWayAntElPatGainSS1VH[201] ;
    unsigned char	spare1[32] ;
} gadsXCA ;


typedef struct {
    char	timeOfCreation[12] ;
    char	DSRLength[4] ;
    char	XCalScalingFactor_IM_SLC_HH[7][4] ;
    char	XCalScalingFactor_IM_SLC_VV[7][4] ;
    char	XCalScalingFactor_IM_PRI_HH[7][4] ;
    char	XCalScalingFactor_IM_PRI_VV[7][4] ;
    char	XCalScalingFactor_IM_GEC_HH[7][4] ;
    char	XCalScalingFactor_IM_GEC_VV[7][4] ;
    char	XCalScalingFactor_IM_MED_HH[7][4] ;
    char	XCalScalingFactor_IM_MED_VV[7][4] ;
    char	XCalScalingFactor_AP_SLC_HH[7][4] ;
    char	XCalScalingFactor_AP_SLC_VV[7][4] ;
    char	XCalScalingFactor_AP_SLC_HV[7][4] ;
    char	XCalScalingFactor_AP_SLC_VH[7][4] ;
    char	XCalScalingFactor_AP_PRI_HH[7][4] ;
    char	XCalScalingFactor_AP_PRI_VV[7][4] ;
    char	XCalScalingFactor_AP_PRI_HV[7][4] ;
    char	XCalScalingFactor_AP_PRI_VH[7][4] ;
    char	XCalScalingFactor_AP_GEC_HH[7][4] ;
    char	XCalScalingFactor_AP_GEC_VV[7][4] ;
    char	XCalScalingFactor_AP_GEC_HV[7][4] ;
    char	XCalScalingFactor_AP_GEC_VH[7][4] ;
    char	XCalScalingFactor_AP_MED_HH[7][4] ;
    char	XCalScalingFactor_AP_MED_VV[7][4] ;
    char	XCalScalingFactor_AP_MED_HV[7][4] ;
    char	XCalScalingFactor_AP_MED_VH[7][4] ;
    char	XCalScalingFactor_WM_HH[7][4] ;
    char	XCalScalingFactor_WM_VV[7][4] ;
    char	XCalScalingFactor_WS_HH[4] ;
    char	XCalScalingFactor_WS_VV[4] ;
    char	XCalScalingFactor_GM_HH[4] ;
    char	XCalScalingFactor_GM_VV[4] ;
    char	refElevationAngleIS[7][4] ;
    char	refElevationAngleSS1[4] ;
    char	twoWayAntElPatGainIS[7][4][201][4] ;
    char	twoWayAntElPatGainSS1HH[201][4] ;
    char	twoWayAntElPatGainSS1VV[201][4] ;
    char	twoWayAntElPatGainSS1HV[201][4] ;
    char	twoWayAntElPatGainSS1VH[201][4] ;
    char	spare1[32] ;
} gadsXCA_Char ;

#endif