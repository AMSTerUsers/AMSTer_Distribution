
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ASA_ALL_AX_sph.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on Mon Sep 13 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */
/* Specific product header applicable to all ENVISAT ASAR auxiliary files */

#if !defined(SPH_AX)
#define SPH_AX

#include "DSD.h"

typedef struct {
    unsigned char	SPH_Descriptor_KEY[15] ;		/* field 1 */
    unsigned char	quotation_mark1 ;
    unsigned char	SPH_Descriptor[28] ;
    unsigned char	quotation_mark2 ;
    unsigned char	terminator1 ;
    unsigned char	spare[52] ;
    DSD_TYPE		DSD ;
} sphAX ;

#endif
