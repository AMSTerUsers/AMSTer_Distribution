
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ASA_INS_AX_gads.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on Mon Sep 13 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(GADS_INS)
#define GADS_INS

#include "MJD.h"
#include "complexTypes.h"

typedef struct {
	float   amp[32] ;
	float   phase[32] ;
} calPulse ;

typedef struct {
	float   ampCoef[4] ;
	float   phaseCoef[4] ;
	float   duration ;
} nomPulse ;

typedef struct {
	unsigned short swath_num[7] ;
	unsigned short beam_set_num[7] ;
} defaultSwathID ;

typedef struct {
	char	echo_comp_method[4] ;
	char	echo_comp_ratio[3] ;
	char	echo_resamp_flag ;
	char	init_cal_comp_method[4] ;
	char	init_cal_comp_ratio[3] ;
	char	init_cal_resamp_flag ;
	char	per_cal_comp_method[4] ;
	char	per_cal_comp_ratio[3] ;
	char	per_cal_resamp_flag ;
	char	noise_comp_method[4] ;
	char	noise_comp_ratio[3] ;
	char	noise_resamp_flag ;
} dataProcConfig ;

typedef struct {
	unsigned short  num_samp_windows_echo[7] ;
	unsigned short  num_samp_windows_init_cal[7] ;
	unsigned short  num_samp_windows_per_cal[7] ;
	unsigned short  num_samp_windows_noise[7] ;
	float			resample_factor[7] ;
} swathConfig ;

typedef struct {
	unsigned short  swath_nums[7] ;
	unsigned short  m_values[7] ;
	unsigned short  r_values[7] ;
	unsigned short  g_values[7] ;
} modeTimeline ;

typedef struct {
    MJD				timeOfCreation ;
    unsigned long	DSRLength ;
	float			radarFrequency ;
	float			radarSamplingRate ;
	float			offsetFrequencyWM ;
	calPulse		cal_pulse_im0_tx_h_1 ;
	calPulse		cal_pulse_im0_tx_v_1 ;
	calPulse		cal_pulse_im0_tx_h_1a ;
	calPulse		cal_pulse_im0_tx_v_1a ;
	calPulse		cal_pulse_im0_rx_h_2 ;
	calPulse		cal_pulse_im0_rx_v_2 ;
	calPulse		cal_pulse_im0_h_3 ;
	calPulse		cal_pulse_im0_v_3 ;
	calPulse		cal_pulse_im_tx_h_1[7] ;
	calPulse		cal_pulse_im_tx_v_1[7] ;
	calPulse		cal_pulse_im_tx_h_1a[7] ;
	calPulse		cal_pulse_im_tx_v_1a[7] ;
	calPulse		cal_pulse_im_rx_h_2[7] ;
	calPulse		cal_pulse_im_rx_v_2[7] ;
	calPulse		cal_pulse_im_h_3[7] ;
	calPulse		cal_pulse_im_v_3[7] ;
	calPulse		cal_pulse_ap_tx_h_1[7] ;
	calPulse		cal_pulse_ap_tx_v_1[7] ;
	calPulse		cal_pulse_ap_tx_h_1a[7] ;
	calPulse		cal_pulse_ap_tx_v_1a[7] ;
	calPulse		cal_pulse_ap_rx_h_2[7] ;
	calPulse		cal_pulse_ap_rx_v_2[7] ;
	calPulse		cal_pulse_ap_h_3[7] ;
	calPulse		cal_pulse_ap_v_3[7] ;
	calPulse		cal_pulse_wv_tx_h_1[7] ;
	calPulse		cal_pulse_wv_tx_v_1[7] ;
	calPulse		cal_pulse_wv_tx_h_1a[7] ;
	calPulse		cal_pulse_wv_tx_v_1a[7] ;
	calPulse		cal_pulse_wv_rx_h_2[7] ;
	calPulse		cal_pulse_wv_rx_v_2[7] ;
	calPulse		cal_pulse_wv_h_3[7] ;
	calPulse		cal_pulse_wv_v_3[7] ;
	calPulse		cal_pulse_ws_tx_h_1[5] ;
	calPulse		cal_pulse_ws_tx_v_1[5] ;
	calPulse		cal_pulse_ws_tx_h_1a[5] ;
	calPulse		cal_pulse_ws_tx_v_1a[5] ;
	calPulse		cal_pulse_ws_rx_h_2[5] ;
	calPulse		cal_pulse_ws_rx_v_2[5] ;
	calPulse		cal_pulse_ws_h_3[5] ;
	calPulse		cal_pulse_ws_v_3[5] ;
	calPulse		cal_pulse_gm_tx_h_1[5] ;
	calPulse		cal_pulse_gm_tx_v_1[5] ;
	calPulse		cal_pulse_gm_tx_h_1a[5] ;
	calPulse		cal_pulse_gm_tx_v_1a[5] ;
	calPulse		cal_pulse_gm_rx_h_2[5] ;
	calPulse		cal_pulse_gm_rx_v_2[5] ;
	calPulse		cal_pulse_gm_h_3[5] ;
	calPulse		cal_pulse_gm_v_3[5] ;
	nomPulse		nom_pulse_im[7] ;
	nomPulse		nom_pulse_ap[7] ;
	nomPulse		nom_pulse_wv[7] ;
	nomPulse		nom_pulse_ws[5] ;
	nomPulse		nom_pulse_gm[5] ;
	float			az_pattern_is1[101] ;
	float			az_pattern_is2[101] ;
	float			az_pattern_is3_ss2[101] ;
	float			az_pattern_is4_ss3[101] ;
	float			az_pattern_is5_ss4[101] ;
	float			az_pattern_is6_ss5[101] ;
	float			az_pattern_is7[101] ;
	float			az_pattern_ss1[101] ;
	float			range_gate_bias ;
	float			range_gate_bias_gm ;
	float			adc_lut_i[255] ;
	float			adc_lut_q[255] ;
	char			spare_1[648] ;
	float			full8_lut_i[256] ;
	float			full8_lut_q[256] ;
	float			fbaq4_lut_i[16][256] ;
	float			fbaq3_lut_i[8][256] ;
	float			fbaq2_lut_i[4][256] ;
	float			fbaq4_lut_q[16][256] ;
	float			fbaq3_lut_q[8][256] ;
	float			fbaq2_lut_q[4][256] ;
	float			fbaq4_no_adc[4096] ;
	float			fbaq3_no_adc[2048] ;
	float			fbaq2_no_adc[1024] ;
	float			sm_lut_i[16] ;
	float			sm_lut_q[16] ;
	dataProcConfig  data_config_im ;
	dataProcConfig  data_config_ap ;
	dataProcConfig  data_config_ws ;
	dataProcConfig  data_config_gm ;
	dataProcConfig  data_config_wv ;
	swathConfig		swath_config_im ;
	swathConfig		swath_config_ap ;
	swathConfig		swath_config_ws ;
	swathConfig		swath_config_gm ;
	swathConfig		swath_config_wv ;
	unsigned short  per_cal_widows_ec ;
	unsigned short  per_cal_windows_ms ;
	defaultSwathID  swath_id_im ;
	defaultSwathID  swath_id_ap ;
	defaultSwathID  swath_id_ws ;
	defaultSwathID  swath_id_gm ;
	defaultSwathID  swath_id_wv ;
	unsigned short  init_cal_beam_set_wv ;
	unsigned short  beam_set_ec ;
	unsigned short  beam_set_ms ;
	unsigned short  cal_seq[32] ;
	modeTimeline	timeline_im ;
	modeTimeline	timeline_ap ;
	modeTimeline	timeline_wm ;
	modeTimeline	timeline_gm ;
	modeTimeline	timeline_wv ;
	unsigned short  m_ec ;
	char			spare_2[44] ;
	float			ref_elev_angle_is1 ;
	float			ref_elev_angle_is2 ;
	float			ref_elev_angle_is3_ss2 ;
	float			ref_elev_angle_is4_ss3 ;
	float			ref_elev_angle_is5_ss4 ;
	float			ref_elev_angle_is6_ss4 ;
	float			ref_elev_angle_is7 ;
	float			ref_elev_angle_ss1 ;
	char			spare_3[64] ;
	complexFloat	cal_loop_ref[8][2][32] ;
/*
	float			cal_loop_ref_is1[128] ;
	float			cal_loop_ref_is2[128] ;
	float			cal_loop_ref_is3_ss2[128] ;
	float			cal_loop_ref_is4_ss3[128] ;
	float			cal_loop_ref_is5_ss4[128] ;
	float			cal_loop_ref_is6_ss5[128] ;
	float			cal_loop_ref_is7[128] ;
	float			cal_loop_ref_ss1[128] ;
*/
	char			spare_4[5120] ;
	float			im_operating_temp ;
	double			im_rx_gain_droop_coeff[8] ;
	float			ap_operating_temp ;
	double			ap_rx_gain_droop_coeff[8] ;
	float			ws_operating_temp ;
	double			ws_rx_gain_droop_coeff[8] ;
	float			gm_operating_temp ;
	double			gm_rx_gain_droop_coeff[8] ;
	float			wv_operating_temp ;
	double			wv_rx_gain_droop_coeff[8] ;
	float			swst_cal_p2 ;
	char			spare_5[72] ;
} gadsINS ;

#endif