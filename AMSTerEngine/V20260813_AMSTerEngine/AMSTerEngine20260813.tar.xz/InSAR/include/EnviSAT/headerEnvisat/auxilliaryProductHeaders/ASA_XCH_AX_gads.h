
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ASA_XCH_AX_gads.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on Wed Sep 22 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(GADS_XCH)
#define GADS_XCH

#include "MJD.h"
#include "complexTypes.h"

typedef struct {
	MJD				dsr_time ;
	unsigned long   dsr_length ;
	complexFloat	complex_loop_factors[2][32] ;
	float			pointing_error ;
	char			spare_1[64] ;
} gadsXCH ;

#endif
