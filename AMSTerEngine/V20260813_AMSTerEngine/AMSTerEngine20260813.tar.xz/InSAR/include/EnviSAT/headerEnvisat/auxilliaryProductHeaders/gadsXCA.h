
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  gadsXCA.h
 *  externalCalibrationDataHandler
 *
 *  Created by Dominique Derauw on Tue Jul 01 2003.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
 */
#if !defined(GADS_XCA)
#define GADS_XCA

#include "MJD.h"

typedef struct {
    MJD		timeOfCreation ;
    unsigned long	DSRLength ;
    float	XCalScalingFactor_IM_SLC_HH[7] ;
    float	XCalScalingFactor_IM_SLC_VV[7] ;
    float	XCalScalingFactor_IM_PRI_HH[7] ;
    float	XCalScalingFactor_IM_PRI_VV[7] ;
    float	XCalScalingFactor_IM_GEC_HH[7] ;
    float	XCalScalingFactor_IM_GEC_VV[7] ;
    float	XCalScalingFactor_IM_MED_HH[7] ;
    float	XCalScalingFactor_IM_MED_VV[7] ;
    float	XCalScalingFactor_AP_SLC_HH[7] ;
    float	XCalScalingFactor_AP_SLC_VV[7] ;
    float	XCalScalingFactor_AP_SLC_HV[7] ;
    float	XCalScalingFactor_AP_SLC_VH[7] ;
    float	XCalScalingFactor_AP_PRI_HH[7] ;
    float	XCalScalingFactor_AP_PRI_VV[7] ;
    float	XCalScalingFactor_AP_PRI_HV[7] ;
    float	XCalScalingFactor_AP_PRI_VH[7] ;
    float	XCalScalingFactor_AP_GEC_HH[7] ;
    float	XCalScalingFactor_AP_GEC_VV[7] ;
    float	XCalScalingFactor_AP_GEC_HV[7] ;
    float	XCalScalingFactor_AP_GEC_VH[7] ;
    float	XCalScalingFactor_AP_MED_HH[7] ;
    float	XCalScalingFactor_AP_MED_VV[7] ;
    float	XCalScalingFactor_AP_MED_HV[7] ;
    float	XCalScalingFactor_AP_MED_VH[7] ;
    float	XCalScalingFactor_WM_HH[7] ;
    float	XCalScalingFactor_WM_VV[7] ;
    float	XCalScalingFactor_WS_HH ;
    float	XCalScalingFactor_WS_VV ;
    float	XCalScalingFactor_GM_HH ;
    float	XCalScalingFactor_GM_VV ;
    float	refElevationAngleIS1 ;
    float	refElevationAngleIS2 ;
    float	refElevationAngleIS3 ;
    float	refElevationAngleIS4 ;
    float	refElevationAngleIS5 ;
    float	refElevationAngleIS6 ;
    float	refElevationAngleIS7 ;
    float	refElevationAngleSS1 ;
    float	twoWayAntElPatGainIS1HH[201] ;
    float	twoWayAntElPatGainIS1VV[201] ;
    float	twoWayAntElPatGainIS1HV[201] ;
    float	twoWayAntElPatGainIS1VH[201] ;
    float	twoWayAntElPatGainIS2HH[201] ;
    float	twoWayAntElPatGainIS2VV[201] ;
    float	twoWayAntElPatGainIS2HV[201] ;
    float	twoWayAntElPatGainIS2VH[201] ;
    float	twoWayAntElPatGainIS3HH[201] ;
    float	twoWayAntElPatGainIS3VV[201] ;
    float	twoWayAntElPatGainIS3HV[201] ;
    float	twoWayAntElPatGainIS3VH[201] ;
    float	twoWayAntElPatGainIS4HH[201] ;
    float	twoWayAntElPatGainIS4VV[201] ;
    float	twoWayAntElPatGainIS4HV[201] ;
    float	twoWayAntElPatGainIS4VH[201] ;
    float	twoWayAntElPatGainIS5HH[201] ;
    float	twoWayAntElPatGainIS5VV[201] ;
    float	twoWayAntElPatGainIS5HV[201] ;
    float	twoWayAntElPatGainIS5VH[201] ;
    float	twoWayAntElPatGainIS6HH[201] ;
    float	twoWayAntElPatGainIS6VV[201] ;
    float	twoWayAntElPatGainIS6HV[201] ;
    float	twoWayAntElPatGainIS6VH[201] ;
    float	twoWayAntElPatGainIS7HH[201] ;
    float	twoWayAntElPatGainIS7VV[201] ;
    float	twoWayAntElPatGainIS7HV[201] ;
    float	twoWayAntElPatGainIS7VH[201] ;
    float	twoWayAntElPatGainSS1HH[201] ;
    float	twoWayAntElPatGainSS1VV[201] ;
    float	twoWayAntElPatGainSS1HV[201] ;
    float	twoWayAntElPatGainSS1VH[201] ;
    unsigned char	spare1[32] ;
} gadsXCA ;


typedef struct {
    char	timeOfCreation[12] ;
    char	DSRLength[4] ;
    char	XCalScalingFactor_IM_SLC_HH[7][4] ;
    char	XCalScalingFactor_IM_SLC_VV[7][4] ;
    char	XCalScalingFactor_IM_PRI_HH[7][4] ;
    char	XCalScalingFactor_IM_PRI_VV[7][4] ;
    char	XCalScalingFactor_IM_GEC_HH[7][4] ;
    char	XCalScalingFactor_IM_GEC_VV[7][4] ;
    char	XCalScalingFactor_IM_MED_HH[7][4] ;
    char	XCalScalingFactor_IM_MED_VV[7][4] ;
    char	XCalScalingFactor_AP_SLC_HH[7][4] ;
    char	XCalScalingFactor_AP_SLC_VV[7][4] ;
    char	XCalScalingFactor_AP_SLC_HV[7][4] ;
    char	XCalScalingFactor_AP_SLC_VH[7][4] ;
    char	XCalScalingFactor_AP_PRI_HH[7][4] ;
    char	XCalScalingFactor_AP_PRI_VV[7][4] ;
    char	XCalScalingFactor_AP_PRI_HV[7][4] ;
    char	XCalScalingFactor_AP_PRI_VH[7][4] ;
    char	XCalScalingFactor_AP_GEC_HH[7][4] ;
    char	XCalScalingFactor_AP_GEC_VV[7][4] ;
    char	XCalScalingFactor_AP_GEC_HV[7][4] ;
    char	XCalScalingFactor_AP_GEC_VH[7][4] ;
    char	XCalScalingFactor_AP_MED_HH[7][4] ;
    char	XCalScalingFactor_AP_MED_VV[7][4] ;
    char	XCalScalingFactor_AP_MED_HV[7][4] ;
    char	XCalScalingFactor_AP_MED_VH[7][4] ;
    char	XCalScalingFactor_WM_HH[7][4] ;
    char	XCalScalingFactor_WM_VV[7][4] ;
    char	XCalScalingFactor_WS_HH[4] ;
    char	XCalScalingFactor_WS_VV[4] ;
    char	XCalScalingFactor_GM_HH[4] ;
    char	XCalScalingFactor_GM_VV[4] ;
    char	refElevationAngleIS1[4] ;
    char	refElevationAngleIS2[4] ;
    char	refElevationAngleIS3[4] ;
    char	refElevationAngleIS4[4] ;
    char	refElevationAngleIS5[4] ;
    char	refElevationAngleIS6[4] ;
    char	refElevationAngleIS7[4] ;
    char	refElevationAngleSS1[4] ;
    char	twoWayAntElPatGainIS1HH[201][4] ;
    char	twoWayAntElPatGainIS1VV[201][4] ;
    char	twoWayAntElPatGainIS1HV[201][4] ;
    char	twoWayAntElPatGainIS1VH[201][4] ;
    char	twoWayAntElPatGainIS2HH[201][4] ;
    char	twoWayAntElPatGainIS2VV[201][4] ;
    char	twoWayAntElPatGainIS2HV[201][4] ;
    char	twoWayAntElPatGainIS2VH[201][4] ;
    char	twoWayAntElPatGainIS3HH[201][4] ;
    char	twoWayAntElPatGainIS3VV[201][4] ;
    char	twoWayAntElPatGainIS3HV[201][4] ;
    char	twoWayAntElPatGainIS3VH[201][4] ;
    char	twoWayAntElPatGainIS4HH[201][4] ;
    char	twoWayAntElPatGainIS4VV[201][4] ;
    char	twoWayAntElPatGainIS4HV[201][4] ;
    char	twoWayAntElPatGainIS4VH[201][4] ;
    char	twoWayAntElPatGainIS5HH[201][4] ;
    char	twoWayAntElPatGainIS5VV[201][4] ;
    char	twoWayAntElPatGainIS5HV[201][4] ;
    char	twoWayAntElPatGainIS5VH[201][4] ;
    char	twoWayAntElPatGainIS6HH[201][4] ;
    char	twoWayAntElPatGainIS6VV[201][4] ;
    char	twoWayAntElPatGainIS6HV[201][4] ;
    char	twoWayAntElPatGainIS6VH[201][4] ;
    char	twoWayAntElPatGainIS7HH[201][4] ;
    char	twoWayAntElPatGainIS7VV[201][4] ;
    char	twoWayAntElPatGainIS7HV[201][4] ;
    char	twoWayAntElPatGainIS7VH[201][4] ;
    char	twoWayAntElPatGainSS1HH[201][4] ;
    char	twoWayAntElPatGainSS1VV[201][4] ;
    char	twoWayAntElPatGainSS1HV[201][4] ;
    char	twoWayAntElPatGainSS1VH[201][4] ;
    char	spare1[32] ;
} gadsXCA_Char ;

#endif