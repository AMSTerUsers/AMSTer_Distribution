
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  MDSRAnnotations.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on Tue Aug 24 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */

#include "MJD.h"
#include "FEPAnnotationPacket.h"

#if !defined(MDSRANNOTATION)
#define MDSRANNOTATION

/* Levele 0 Measurement Data Set Annotations structure */
typedef struct {
    MJD					*ISPSensingTime ;
    FEPAnnotationPacket	*FEPAnnotations ;
} MDSRAnnotations ;

/* Equivalent char structure */
typedef struct {
    MJD_CHAR					ISPSensingTime ;
    FEPAnnotationPacket_CHAR	FEPAnnotations ;
} MDSRAnnotations_CHAR ;


#endif