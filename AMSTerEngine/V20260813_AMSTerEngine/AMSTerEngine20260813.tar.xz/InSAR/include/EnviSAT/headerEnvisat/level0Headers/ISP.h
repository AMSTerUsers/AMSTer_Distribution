
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ISP.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on Thu Aug 26 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */

#include "ISPHeader.h"
#include "ISPData.h"

#if !defined(ISP1)
#define ISP1

/* Instrument Source Packet structure */
typedef struct {
    ISPHeader		*packetHeader ;
    ISPDataField	packetDataField ;
} ISP ;

/* Equivalent char structure */
typedef struct {
    ISPHeader_CHAR		packetHeader ;
    ISPDataField_CHAR	packetDataField ;
} ISP_CHAR ;

#endif

