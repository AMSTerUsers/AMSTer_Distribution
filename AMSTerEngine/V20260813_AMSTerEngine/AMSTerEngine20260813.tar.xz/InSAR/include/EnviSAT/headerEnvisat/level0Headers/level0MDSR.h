
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  level0MDSR.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on Wed Aug 25 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */

#include "MDSRAnnotations.h"
#include "ISP.h"

#if !defined(LEVEL0MDSR)
#define LEVEL0MDSR

/* Level 0 measurement Data Set record structure */
typedef struct {
    MDSRAnnotations	annotations ;
    ISP				instrumentSourcePacket ;
} level0MDSRStruct ;

/* Equivalent char structure */
typedef struct {
    MDSRAnnotations_CHAR	annotations ;
    ISP_CHAR				instrumentSourcePacket ;
} level0MDSRStruct_CHAR ;

#endif