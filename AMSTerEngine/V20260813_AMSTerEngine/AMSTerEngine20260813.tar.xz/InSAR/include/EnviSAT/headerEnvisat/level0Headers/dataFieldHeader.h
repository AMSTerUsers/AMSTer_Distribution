
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  dataFieldHeader.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on Thu Aug 26 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(DATAFIELDHEADER)
#define DATAFIELDHEADER


typedef struct	{
    unsigned antennaBeamSetNumber	: 6 ;
    unsigned compressionRatio 		: 2 ;
    unsigned echoFlag			: 1 ;
    unsigned noiseFlag			: 1 ;
    unsigned calFlag			: 1 ;
    unsigned calType			: 1 ;
    unsigned cyclePacketCount		: 12 ;
    unsigned fillerForAlignment		: 8 ;
} bytes13To15 ;


typedef struct {
    unsigned upconvertedLevel		: 4 ;
    unsigned downconvertedlevel		: 5 ;
    unsigned TxRxPol				: 2 ;
    unsigned calibrationRowNumber	: 5 ;
    unsigned TxPulseLength		: 10 ;
    unsigned beamAdjustmentDelta	: 6 ;
} bytes22To25 ;


/* Instrument Source Packet data field header structure */
typedef struct {
    unsigned short	headerLength ;
    char		spare1 ;
    unsigned char	modeID ;
    unsigned short	onBoardTimeMSW ;
    unsigned short	onBoardTimeLSW ;
    unsigned char	onBoardTimeLSB ;
    char		spare2 ;
    unsigned short	modePacketCountMSW ;
    unsigned char	modePacketCountLSB ;
    unsigned char	s1[3] ;
    unsigned short	pulseRepetitionInterval ;
    unsigned short	windowStartTime ;
    unsigned short	windowLength ;
    unsigned char	s2[4] ;
    unsigned char	chirpPulseBandwidth ;
    unsigned char	auxiliaryTxMonitorLevel ;
    unsigned short	resamplingFactor ;
} dataFieldHeaderStruct ;


#endif

