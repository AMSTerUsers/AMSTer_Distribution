
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ISPData.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on Thu Aug 26 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */

#include "dataFieldHeader.h"

#if !defined(ISPDATA)
#define ISPDATA

/* Instrument Source Packet data field structure */
typedef struct {
    dataFieldHeaderStruct	*dataFieldHeader ;
    void					*data ;
} ISPDataField ;

/* Equivalent char structure */
typedef struct {
    char	dataFieldHeader[30] ;
} ISPDataField_CHAR ;

typedef struct {
	unsigned sI : 1 ;
	unsigned  I : 3 ;
	unsigned sQ : 1 ;
	unsigned  Q : 3 ;
	char	fillerForAlignment[3] ;
} FBAQ84 ;

typedef struct {
	unsigned char	blockID ;
	unsigned char	data[63] ;
} echoBlock ;


#endif
