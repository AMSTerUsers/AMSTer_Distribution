
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  Level 0 ENVISAT Specific Product Header
 *  SPH.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on Fri Aug 27 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */

#include "DSD.h"

#if !defined(SPH0)
#define SPH0

typedef struct {
/* field 1 */
    char	SPHDescriptorKEY[15] ;	
    char	quotationMark1 ;
    char	SPHDescriptor[28] ;
    char	quotationMark2 ;
    char	terminator1 ;
    
/* field 2: WGS84 latitude of first satellite nadir point at the Sensing Start time of
the MPH (positive north) */
    char	startLatKeyword[10] ;		
    char	startLat[11] ;			
    char	startLatUnits[10] ;		
    char	terminator2 ;			

/* field 3: WGS84 longitude of first satellite nadir point at the Sensing Start time of
the MPH (positive East, 0 = Greenwich) */
    char	startLonKeyword[11] ;		
    char	startLon[11] ;
    char	startLonUnits[10] ;		
    char	terminator3 ;			

/* field 4: WGS84 latitude of first satellite nadir point at the Sensing Stop time of
the MPH (positive north) */
    char	stopLatKeyword[9] ;		
    char	stopLat[11] ;			
    char	stopLatUnits[10] ;		
    char	terminator4 ;			

/* field 5: WGS84 longitude of first satellite nadir point at the Sensing Stop time of
the MPH (positive East, 0 = Greenwich) */
    char	stopLonKeyword[10] ;		
    char	stopLon[11] ;
    char	stopLonUnits[10] ;		
    char	terminator5 ;			

/* field 6: Sub-satellite track heading at the Sensing Start time in the MPH. */
    char	satTrackKeyword[10] ;		
    char	satTrack[15] ;
    char	satTrackUnits[5] ;		
    char	terminator6 ;			

/* field 7 */
    char	spare1[50] ;			
    char	terminator7 ;			


/* Product Confidence Data Information */
/* field 8 */
    char	ISPErrorsSignificantKeyword[23] ;
    char	ISPErrorsSignificant ;
    char	terminator8 ;			

/* field 9 */
    char	MissingISPSignificantKeyword[25] ;
    char	MissingISPSignificant ;
    char	terminator9 ;			

/* field 10 */
    char	ISPDiscardedSignificantKeyword[26] ;
    char	ISPDiscardedSignificant ;
    char	terminator10 ;			

/* field 11 */
    char	RSSignificantKeyword[15] ;
    char	RSSignificant ;
    char	terminator11 ;			

/* field 12 */
    char	spare2[50] ;			
    char	terminator12 ;			


/* Other Product Quality Information */
/* field 13 */
    char	numErrorISPSKeyword[15] ;
    char	numErrorISPS[11] ;
    char	terminator13 ;			

/* field 14 */
    char	errorISPSThreshKeyword[18] ;		
    char	errorISPSThresh[15] ;
    char	errorISPSThreshUnits[3] ;		
    char	terminator14 ;			

/* field 15 */
    char	numMissingISPSKeyword[17] ;
    char	numMissingISPS[11] ;
    char	terminator15 ;			

/* field 16 */
    char	missingISPSThreshKeyword[20] ;		
    char	missingISPSThresh[15] ;
    char	missingISPSThreshUnits[3] ;		
    char	terminator16 ;			

/* field 17 */
    char	numDiscardedISPSKeyword[19] ;
    char	numDiscardedISPS[11] ;
    char	terminator17 ;			

/* field 18 */
    char	discardedISPSThreshKeyword[22] ;		
    char	discardedISPSThresh[15] ;
    char	discardedISPSThreshUnits[3] ;		
    char	terminator18 ;			

/* field 19 */
    char	numRSISPSKeyword[12] ;
    char	numRSISPS[11] ;
    char	terminator19 ;			

/* field 20 */
    char	RSThreshKeyword[10] ;		
    char	RSThresh[15] ;
    char	RSThreshUnits[3] ;		
    char	terminator20 ;			

/* field 21 */
    char	spare3[100] ;			
    char	terminator21 ;			


/* ASAR Specific Information */
/* field 22 */
    char	TX_RX_PolarKeyword[12] ;
    char	quotationMark3 ;
    char	polarization[5] ;
    char	quotationMark4 ;
    char	terminator22 ;
    
/* field 23 */
    char	swathKeyword[6] ;
    char	quotationMark5 ;
    char	swathNumber[3] ;
    char	quotationMark6 ;
    char	terminator23 ;
    
/* field 24 */
    char	spare4[41] ;			
    char	terminator24 ;			


/* Data Set Descriptors */
/* field 25 to 28 */
    DSD_TYPE		DSD[4] ;
} level0SPH ;

#endif