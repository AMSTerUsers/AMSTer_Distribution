
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  annotationPacket.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on Tue Aug 24 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */

#include "MJD.h"

#if !defined(FEPANNOTATION)
#define FEPANNOTATION

/* Front End Processor Annotations structure */
typedef struct {
    MJD		timeStamp ;
    short	lengthOfISP ;
    short	countOfCRCErrors ;
    short	countOfRSErrors ;
    short	spare ;	
} FEPAnnotationPacket ;

/* Equivalent char structure */
typedef struct {
    MJD_CHAR	timeStamp ;
    char	lengthOfISP[2] ;
    char	countOfCRCErrors[2] ;
    char	countOfRSErrors[2] ;
    char	spare[2] ;	
} FEPAnnotationPacket_CHAR ;

#endif