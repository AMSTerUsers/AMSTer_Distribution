
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  DSD.h
 *  APS2PRI
 *
 *  Created by Dominique Derauw on Fri Aug 27 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(DSD1)
#define DSD1

typedef struct {
    char	DS_Name_KEY[8] ;			/* field 1 */
    char	quotation_mark1 ;
    char	Data_Set_Name[28] ;
    char	quotation_mark2 ;
    char	terminator1 ;

    char	DS_Type_KEY[8] ;			/* field 2 */
    char	DS_Type ;
    char	terminator2 ;

    char	File_Name_KEY[9] ;			/* field 3 */
    char	quotation_mark3 ;
    char	External_Reference[62] ;
    char	quotation_mark4 ;
    char	terminator3 ;

    char	DS_Offset_KEY[10] ;			/* field 4 */
    char	DS_Offset_Value[21] ;
    char	DS_Offset_Units[7] ;			/* <bytes> */
    char	terminator4 ;			

    char	DS_Size_KEY[8] ;			/* field 5 */
    char	DS_Size_Value[21] ;
    char	DS_Size_Units[7] ;			/* <bytes> */
    char	terminator5 ;			

    char	Num_DSR_KEY[8] ;			/* field 6 */
    char	Number_DSR[11] ;
    char	terminator6 ;

    char	DSR_Size_KEY[9] ;			/* field 7 */
    char	DSR_Size_Value[11] ;
    char	DSR_Size_Units[7] ;			/* <bytes> */
    char	terminator7 ;			

    char	Spare[32] ;				/* field 8 */
    char	terminator8 ;			
} DSD_TYPE ;


#endif

