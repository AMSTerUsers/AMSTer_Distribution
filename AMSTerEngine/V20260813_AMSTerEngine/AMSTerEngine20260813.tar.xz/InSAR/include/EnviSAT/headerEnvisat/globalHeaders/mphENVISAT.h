
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* ENVISAT Main Product Header */
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
 */

#if !defined(MPH_ENVISAT)
#define MPH_ENVISAT

typedef struct {
    char		quotation_mark1 ;
    char		Product_Id[10] ;
    char		Stage_Flag ;
    char		Originator_Id[3] ;
    char		Start_Day[8] ;
    char		underscore1 ;
    char		Start_Time[6] ;
    char		underscore2 ;
    char		Duration[8] ;			/* sec. */
    char		Phase_Id ;
    char		Cycle_Number[3] ;
    char		underscore3 ;
    char		Relative_Orbit[5] ;
    char		underscore4 ;
    char		Absolute_Orbit[5] ;
    char		underscore5 ;
    char		Counter[4] ;
    char		Period ;
    char		Satellite_Id[2] ;
    char		quotation_mark2 ;
    char		terminator ;
} PRODUCT_FILE_NAME ;

#define	PRODUCT_FILE_NAME_SIZE	sizeof(PRODUCT_FILE_NAME)


typedef struct {
    char		Product_KEY[8] ;		/* field 1 */
    PRODUCT_FILE_NAME		Product_File_Name ;

    char		Proc_Stage_KEY[11] ;		/* field 2 */
    char		Proc_Stage_Flag ;
    char		terminator2 ;

    char		Ref_Doc_KEY[8] ;		/* field 3 */
    char		quotation_mark1 ;
    char		Ref_Doc_Des[23] ;	
    char		quotation_mark2 ;
    char		terminator3 ;

    char		Spare1[40] ;			/* field 4 */
    char		terminator4 ;

    char		Acquisition_Station_KEY[20];	/* field 5 */
    char		quotation_mark3 ;
    char		Acquisition_Station_Id[20] ;
    char		quotation_mark4 ;
    char		terminator5 ;

    char		Proc_Center_KEY[12] ;		/* field 6 */
    char		quotation_mark5 ;
    char		Proc_Center_Id[6] ;
    char		quotation_mark6 ;
    char		terminator6 ;

    char		Proc_Time_KEY[10] ;		/* field 7 */
    char		quotation_mark7 ;
    char		UTC_Time[27] ;
    char		quotation_mark8 ;
    char		terminator7 ;

    char		Software_Ver_KEY[13] ;		/* field 8 */
    char		quotation_mark9 ;
    char		Software_Ver_Number[14] ;
    char		quotation_mark10 ;
    char		terminator8 ;

    char		Spare2[40] ;			/* field 9 */
    char		terminator9 ;

    char		Sensing_Start_KEY[14] ;		/* field 10 */
    char		quotation_mark11 ;
    char		UTC_Start_Time[27] ;
    char		quotation_mark12 ;
    char		terminator10 ;

    char		Sensing_Stop_KEY[13] ;		/* field 11 */
    char		quotation_mark13 ;
    char		UTC_Stop_Time[27] ;
    char		quotation_mark14 ;
    char		terminator11 ;

    char		Spare3[40] ;			/* field 12 */
    char		terminator12 ;
    
    char		Phase_KEY[6] ;			/* field 13 */
    char		Phase ;
    char		terminator13 ;

    char		Cycle_KEY[6] ;			/* field 14 */
    char		Cycle[4] ;			
    char		terminator14 ;

    char		Rel_Orbit_KEY[10] ;		/* field 15 */
    char		Rel_Orbit[6] ;			
    char		terminator15 ;

    char		Abs_Orbit_KEY[10] ;		/* field 16 */
    char		Abs_Orbit[6] ;			
    char		terminator16 ;

    char		State_Vector_Time_KEY[18] ;	/* field 17 */
    char		quotation_mark15 ;
    char		UTC_State_Vector[27] ;
    char		quotation_mark16 ;
    char		terminator17 ;

    char		Delta_Ut1_KEY[10] ;		/* field 18 */
    char		DUT1[8] ;			/* UT1-UTC */
    char		Delta_Units[3] ;		 /* <s> */
    char		terminator18 ;

    char		X_Position_KEY[11] ;		/* field 19 */
    char		X_Position[12] ;
    char		X_Position_Units[3] ;		 /* <m> */
    char		terminator19 ;

    char		Y_Position_KEY[11] ;		/* field 20 */
    char		Y_Position[12] ;
    char		Y_Position_Units[3] ; 		/* <m> */
    char		terminator20 ;

    char		Z_Position_KEY[11] ;		/* field 21 */
    char		Z_Position[12] ;
    char		Z_Position_Units[3] ; 		/* <m> */
    char		terminator21 ;

    char		X_Velocity_KEY[11] ;		/* field 22 */
    char		X_Velocity[12] ;
    char		X_Velocity_Units[5] ; 		/* <m/s> */
    char		terminator22 ;

    char		Y_Velocity_KEY[11] ;		/* field 23 */
    char		Y_Velocity[12] ;
    char		Y_Velocity_Units[5] ; 		/* <m/s> */
    char		terminator23 ;

    char		Z_Velocity_KEY[11] ;		/* field 24 */
    char		Z_Velocity[12] ;
    char		Z_Velocity_Units[5] ; 		/* <m/s> */
    char		terminator24 ;

    char		Vector_Source_KEY[14] ;		/* field 25 */
    char		quotation_mark17 ;
    char		Orbit_Vector[2] ;
    char		quotation_mark18 ;
    char		terminator25 ;

    char		Spare4[40] ;			/* field 26 */
    char		terminator26 ;
    
    char		UTC_SBT_Time_KEY[13] ;		/* field 27 */
    char		quotation_mark19 ;
    char		UTC_SBT_Time[27] ;
    char		quotation_mark20 ;
    char		terminator27 ;

    char		Sat_Binary_Time_KEY[16] ;	/* field 28 */
    char		Sat_Binary_Time[11] ;
    char		terminator28 ;

    char		Clock_Step_KEY[11] ;		/* field 29 */
    char		Clock_Step_Size[11] ;
    char		Clock_Step_Units[4] ;		 /* <ps> */
    char		terminator29 ;

    char		Spare5[32] ;			/* field 30 */
    char		terminator30 ;
    
    char		Leap_UTC_KEY[9] ;		/* field 31 */
    char		quotation_mark21 ;
    char		UTC_Leap_Time[27] ;
    char		quotation_mark22 ;
    char		terminator31 ;

    char		Leap_Sign_KEY[10] ;		/* field 32 */
    char		Leap_Sign[4] ;
    char		terminator32 ;

    char		Leap_Err_KEY[9] ;		/* field 33 */
    char		Leap_Err ;
    char		terminator33 ;

    char		Spare6[40] ;			/* field 34 */
    char		terminator34 ;

    char		Product_Err_KEY[12] ;		/* field 35 */
    char		Product_Err ;
    char		terminator35 ;

    char		Tot_Size_KEY[9] ;		/* field 36 */
    char		Tot_Size[21] ;
    char		Tot_Size_Units[7] ;		 /* <bytes> */
    char		terminator36 ;

    char		SPH_Size_KEY[9] ;		/* field 37 */
    char		SPH_Size[11] ;
    char		SPH_Size_Units[7] ; 		/* <bytes> */
    char		terminator37 ;

    char		Num_DSD_KEY[8] ;		/* field 38 */
    char		Num_DSD[11] ;
    char		terminator38 ;

    char		DSD_Size_KEY[9] ;		/* field 39 */
    char		Length_DSD[11] ;
    char		Length_DSD_Units[7] ;		 /* <bytes> */
    char		terminator39 ;

    char		Num_Data_Sets_KEY[14] ;		/* field 40 */
    char		Num_DSs[11] ;
    char		terminator40 ;

    char		Spare7[40] ;			/* field 41 */
    char		terminator41 ;

} MAIN_PRODUCT_HEADER ;
#define MAIN_PRODUCT_HEADER_SIZE	sizeof(MAIN_PRODUCT_HEADER) 

#endif