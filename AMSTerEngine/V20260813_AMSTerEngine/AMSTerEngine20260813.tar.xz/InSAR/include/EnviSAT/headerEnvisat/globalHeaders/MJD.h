
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  MJD.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on Tue Aug 24 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(MJD1)
#define MJD1

/* Modified Julian Date structure */
typedef struct {
    signed long		days ;			/* days since 1st january 2000 : may be negative */
    unsigned long	seconds ;		/* seconds since beginning of the day */
    unsigned long	microseconds ;		/* microseconds since last second */
} MJD ;	

/* Equivalent char structure*/
typedef struct {
    char	days[4] ;			/* days since 1st january 2000 : may be negative */
    char	seconds[4] ;			/* seconds since beginning of the day */
    char	microseconds[4] ;		/* microseconds since last second */
} MJD_CHAR ;	/* Modified Julian Date */


#endif