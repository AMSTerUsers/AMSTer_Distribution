
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Level 1 product ENVISAT Header structure */


#if !defined(_ENVISAT_DATA_READER_)
#define _ENVISAT_DATA_READER_

#include "mphENVISAT.h"
#include "sphENVISAT.h"
#include "sq_adsr.h"
#include "mpp_adsr.h"
#include "dcc_adsr.h"
#include "sr_gr_conversion.h"
#include "chirp.h"
#include "antenna.h"
#include "grid.h"
#include "gads.h"
#include "mds.h"


#define RANGE_DE_REFERENCE_ENVISAT	800000.

typedef struct {
    MAIN_PRODUCT_HEADER		*Main_Product ;
    SPECIFIC_PRODUCT_HEADER	Specific_Product ;
    SQ_ADSR_HEADER		SQ_MDS1 ;
    SQ_ADSR_HEADER		SQ_MDS2 ;
    MPP_ADSR_HEADER		Main_Process_Param ;
    DCC_ADSR_HEADER		Doppler_Centroid_Param ;
    SR_GR_CONVERSION_HEADER	*SR_GR_Conversion ;
    CHIRP_HEADER		Chirp_Parameters ;
    ANTENNA_ELEVATION_HEADER	*Antenna_ElevationMDS1 ;
    ANTENNA_ELEVATION_HEADER	*Antenna_ElevationMDS2 ;
    GEOLOCATION_GRID_HEADER	Geolocation_Grid[11] ;
    GADS_HEADER			Map_Projection_Param ;
    MDS_HEADER			MDS_Header ;
    char *precisesOrbitsDir ;
} ENVISAT_HEADER ;


#endif