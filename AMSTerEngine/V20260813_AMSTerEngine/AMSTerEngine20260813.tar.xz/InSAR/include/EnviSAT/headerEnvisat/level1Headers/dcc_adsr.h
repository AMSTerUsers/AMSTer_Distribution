
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Doppler Centroid Coefficients Annotation Data Set Record */

#include "MJD.h"

typedef struct {
    MJD			Doppler_Azimuth_Time ;			/* field 1 */
    unsigned char	Attachment ;				/* field 2 */
    float		Slant_Range_Time ;			/* field 3 */
    float		Doppler_Centroid_Coef[5] ;		/* field 4 */
    float		Doppler_Centroid_Confidence ;		/* field 5 */
	char	Spare[14] ;				/* field 6 */
} DCC_ADSR_HEADER ;

#define DCC_ADSR_HEADER_SIZE	sizeof(DCC_ADSR_HEADER)


typedef struct {
    char	Doppler_Azimuth_Time[12] ;			/* field 1 */
    char	Attachment ;					/* field 2 */
    char	Slant_Range_Time[4] ;				/* field 3 */
    char	Doppler_Centroid_Coef[20] ;			/* field 4 */
    char	Doppler_Centroid_Confidence[4] ;		/* field 5 */
    char	Spare[14] ;					/* field 6 */
} DCC_ADSR_HEADER_CHAR ;
