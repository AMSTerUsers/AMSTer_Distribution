
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Level 1 ENVISAT Specific Product Header */
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
 */

#include "DSD.h"

#if !defined(SPH_ENVISAT)
#define SPH_ENVISAT

typedef struct {
    char	SPH_Descriptor_KEY[15] ;		/* field 1 */
    char	quotation_mark1 ;
    char	SPH_Descriptor[28] ;
    char	quotation_mark2 ;
    char	terminator1 ;

    char	Stripline_Indicator_KEY[31] ;		/* field 2 */
    char	Stripline_Value[4] ;
    char	terminator2 ;

    char	Slice_Position_KEY[15] ;		/* field 3 */
    char	Slice_Value[4] ;
    char	terminator3 ;

    char	Num_Slice_KEY[11] ;			/* field 4 */
    char	Num_Slice[4] ;
    char	terminator4 ;

    char	First_Line_Time_KEY[16] ;		/* field 5 */
    char	quotation_mark3 ;
    char	First_Azimuth_Time[27] ;
    char	quotation_mark4 ;
    char	terminator5 ;

    char	Last_Line_Time_KEY[15] ;		/* field 6 */
    char	quotation_mark5 ;
    char	Last_Azimuth_Time[27] ;
    char	quotation_mark6 ;
    char	terminator6 ;

    char	First_Near_Lat_KEY[15] ;		/* field 7 */
    char	First_Near_Lat_Value[11] ;
    char	First_Near_Lat_Units[10] ;		/* <10-6degN> */
    char	terminator7 ;			

    char	First_Near_Long_KEY[16] ;		/* field 8 */
    char	First_Near_Long_Value[11] ;
    char	First_Near_Long_Units[10] ;		/* <10-6degE> */
    char	terminator8 ;

    char	First_Mid_Lat_KEY[14] ;			/* field 9 */
    char	First_Mid_Lat_Value[11] ;
    char	First_Mid_Lat_Units[10] ;		/* <10-6degN> */
    char	terminator9 ;

    char	First_Mid_Long_KEY[15] ;		/* field 10 */
    char	First_Mid_Long_Value[11] ;
    char	First_Mid_Long_Units[10] ;		/* <10-6degE> */
    char	terminator10 ;

    char	First_Far_Lat_KEY[14] ;			/* field 11 */
    char	First_Far_Lat_Value[11] ;
    char	First_Far_Lat_Units[10] ;		/* <10-6degN> */
    char	terminator11 ;

    char	First_Far_Long_KEY[15] ;		/* field 12 */
    char	First_Far_Long_Value[11] ;
    char	First_Far_Long_Units[10] ;		/* <10-6degE> */
    char	terminator12 ;

    char	Last_Near_Lat_KEY[14] ;			/* field 13 */
    char	Last_Near_Lat_Value[11] ;
    char	Last_Near_Lat_Units[10] ;		/* <10-6degN> */
    char	terminator13 ;			

    char	Last_Near_Long_KEY[15] ;		/* field 14 */
    char	Last_Near_Long_Value[11] ;
    char	Last_Near_Long_Units[10] ;		/* <10-6degE> */
    char	terminator14 ;

    char	Last_Mid_Lat_KEY[13] ;			/* field 15 */
    char	Last_Mid_Lat_Value[11] ;
    char	Last_Mid_Lat_Units[10] ;		/* <10-6degN> */
    char	terminator15 ;

    char	Last_Mid_Long_KEY[14] ;			/* field 16 */
    char	Last_Mid_Long_Value[11] ;
    char	Last_Mid_Long_Units[10] ;		/* <10-6degE> */
    char	terminator16 ;

    char	Last_Far_Lat_KEY[13] ;			/* field 17 */
    char	Last_Far_Lat_Value[11] ;
    char	Last_Far_Lat_Units[10] ;		/* <10-6degN> */
    char	terminator17 ;

    char	Last_Far_Long_KEY[14] ;			/* field 18 */
    char	Last_Far_Long_Value[11] ;
    char	Last_Far_Long_Units[10] ;		/* <10-6degE> */
    char	terminator18 ;

    char	Spare1[35] ;				/* field 19 */
    char	terminator19 ;

    char	Swath_KEY[6] ;				/* field 20 */
    char	quotation_mark7 ;
    char	Swath_Number[3] ;
    char	quotation_mark8 ;
    char	terminator20 ;

    char	Pass_KEY[5] ;				/* field 21 */
    char	quotation_mark9 ;
    char	Orbit_Designator[10] ;
    char	quotation_mark10 ;
    char	terminator21 ;

    char	Sample_Type_KEY[12] ;			/* field 22 */
    char	quotation_mark11 ;
    char	Type_Designator[8] ;
    char	quotation_mark12 ;
    char	terminator22 ;

    char	Algorithm_KEY[10] ;			/* field 23 */
    char	quotation_mark13 ;
    char	Algorithm[7] ;
    char	quotation_mark14 ;
    char	terminator23 ;

    char	MDS1_TX_RX_Polar_KEY[17] ;		/* field 24 */
    char	quotation_mark15 ;
    char	Polarization_MD1[3] ;
    char	quotation_mark16 ;
    char	terminator24 ;

    char	MDS2_TX_RX_Polar_KEY[17] ;		/* field 25 */
    char	quotation_mark17 ;
    char	Polarization_MD2[3] ;
    char	quotation_mark18 ;
    char	terminator25 ;

    char	Compression_KEY[12] ;			/* field 26 */
    char	quotation_mark19 ;
    char	Compression[5] ;
    char	quotation_mark20 ;
    char	terminator26 ;

    char	Azimuth_Looks_KEY[14] ;			/* field 27 */
    char	Azimuth_Looks[4] ;
    char	terminator27 ;

    char	Range_Looks_KEY[12] ;			/* field 28 */
    char	Range_Looks[4] ;
    char	terminator28 ;

    char	Range_Spacing_KEY[14] ;			/* field 29 */
    char	Range_Spacing_Value[15] ;
    char	Range_Spacing_Units[3] ;		/* <m> */
    char	terminator29 ;

    char	Azimuth_Spacing_KEY[16] ;		/* field 30 */
    char	Azimuth_Spacing_Value[15] ;
    char	Azimuth_Spacing_Units[3] ;		/* <m> */
    char	terminator30 ;

    char	Line_Time_Interval_KEY[19] ;		/* field 31 */
    char	Line_Time_Interval_Value[15] ;
    char	Line_Time_Interval_Units[3] ;		/* <s> */
    char	terminator31 ;

    char	Line_Length_KEY[12] ;			/* field 32 */
    char	Line_Length_Value[6] ;
    char	Line_Length_Units[9] ;			/* <samples> */
    char	terminator32 ;

    char	Data_Type_KEY[10] ;			/* field 33 */
    char	quotation_mark21 ;
    char	Data_Type[5] ;
    char	quotation_mark22 ;
    char	terminator33 ;

    char	Spare2[50] ;				/* field 34 */
    char	terminator34 ;

    DSD_TYPE		DSD[18] ;				/* field 35 à 52 */

} SPECIFIC_PRODUCT_HEADER ;

#define SPECIFIC_PRODUCT_HEARDER_SIZE	sizeof(SPECIFIC_PRODUCT_HEARDER)

#endif