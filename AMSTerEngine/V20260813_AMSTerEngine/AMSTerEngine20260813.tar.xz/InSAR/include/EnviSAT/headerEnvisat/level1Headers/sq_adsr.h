
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Summary Quality Annotation Data Set Record */
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
*/
#include "MJD.h"
#include "complexTypes.h"

typedef struct {
    MJD			Zero_Doppler_Time ;				/* field 1 */
    char	Attachment_Flag ;				/* field 2 */
    char	Input_Mean_Flag ;				/* field 3 */
    char	Input_Standard_Deviation_Flag ;			/* field 4 */
    char	Significant_Gaps_Flag ;				/* field 5 */
    char	Missing_Lines_Flag ;				/* field 6 */
    char	Doppler_Centroid_Flag ;				/* field 7 */
    char	Doppler_Ambiguity_Flag ;			/* field 8 */
    char	Output_Mean_Flag ;				/* field 9 */
    char	Output_Standard_Flag ;				/* field 10 */
    char	Chirp_Flag ;					/* field 11 */
    char	Data_Missing_Flag ;				/* field 12 */
    char	Invalid_Downlink_Flag ;				/* field 13 */
    char	Spare1[7] ;					/* field 14 */
    float		Max_Percent_Chirp ;				/* field 15 */
    float		First_Sidelobe_Chirp ;				/* field 16 */
    float		ISLR_Chirp ;					/* field 17 */
    float		Mean_Input_Quality ;				/* field 18 */
    float		Mean_Input_Value ;				/* field 19 */
    float		Standard_Deviation_Quality ;			/* field 20 */
    float		Input_Standard_Deviation ;			/* field 21 */
    float		Doppler_Confidence ;				/* field 22 */
    float		Doppler_Quality ;				/* field 23 */
    float		Mean_Output_Quality ;				/* field 24 */
    float		Mean_Output_Value ;				/* field 25 */
    float		Standard_Deviation_Output ;			/* field 26 */
    float		Output_Standard_Deviation ;			/* field 27 */
    float		Max_Missing_Lines ;				/* field 28 */
    float		Max_Missing_Gaps ;				/* field 29 */
    unsigned long	Number_Missing_Lines ;				/* field 30 */
    char	Spare2[15] ;					/* field 31 */
    complexFloat		Input_Data_Mean ;				/* field 32 */
    complexFloat		Input_Data_Standard_Deviation ;			/* field 33 */
    float		Number_Gaps ;					/* field 34 */
    float		Number_Lines_Excluding_Gaps ;			/* field 35 */
    complexFloat		Output_Data_Mean ;				/* field 36 */
    complexFloat		Output_Data_Standard_Deviation ;		/* field 37 */
    unsigned long	Number_Errors ;					/* field 38 */
    char	Spare3[16] ;					/* field 39 */
} SQ_ADSR_HEADER ;
#define SQ_ADSR_HEADER_SIZE		sizeof(SQ_ADSR_HEADER)

typedef struct {
        char	r[4] ;
        char	i[4] ;
} complex_char ;

typedef struct {
    char	Zero_Doppler_Time[12] ;			/* field 1 */
    char	Attachment_Flag ;			/* field 2 */
    char	Input_Mean_Flag ;			/* field 3 */
    char	Input_Standard_Deviation_Flag ;		/* field 4 */
    char	Significant_Gaps_Flag ;			/* field 5 */
    char	Missing_Lines_Flag ;			/* field 6 */
    char	Doppler_Centroid_Flag ;			/* field 7 */
    char	Doppler_Ambiguity_Flag ;		/* field 8 */
    char	Output_Mean_Flag ;			/* field 9 */
    char	Output_Standard_Flag ;			/* field 10 */
    char	Chirp_Flag ;				/* field 11 */
    char	Data_Missing_Flag ;			/* field 12 */
    char	Invalid_Downlink_Flag ;			/* field 13 */
    char	Spare1[7] ;				/* field 14 */
    char	Max_Percent_Chirp[4] ;			/* field 15 */
    char	First_Sidelobe_Chirp[4] ;		/* field 16 */
    char	ISLR_Chirp[4] ;				/* field 17 */
    char	Mean_Input_Quality[4] ;			/* field 18 */
    char	Mean_Input_Value[4] ;			/* field 19 */
    char	Standard_Deviation_Quality[4] ;		/* field 20 */
    char	Input_Standard_Deviation[4] ;		/* field 21 */
    char	Doppler_Confidence[4] ;			/* field 22 */
    char	Doppler_Quality[4] ;			/* field 23 */
    char	Mean_Output_Quality[4] ;		/* field 24 */
    char	Mean_Output_Value[4] ;			/* field 25 */
    char	Standard_Deviation_Output[4] ;		/* field 26 */
    char	Output_Standard_Deviation[4] ;		/* field 27 */
    char	Max_Missing_Lines[4] ;			/* field 28 */
    char	Max_Missing_Gaps[4] ;			/* field 29 */
    char	Number_Missing_Lines[4] ;		/* field 30 */
    char	Spare2[15] ;				/* field 31 */
    complex_char	Input_Data_Mean ;		/* field 32 */
    complex_char	Input_Data_Standard_Deviation ;	/* field 33 */
    char	Number_Gaps[4] ;			/* field 34 */
    char	Number_Lines_Excluding_Gaps[4] ;	/* field 35 */
    complex_char	Output_Data_Mean ;		/* field 36 */
    complex_char	Output_Data_Standard_Deviation ;/* field 37 */
    char	Number_Errors[4] ;			/* field 38 */
    char	Spare3[16] ;				/* field 39 */
} SQ_ADSR_HEADER_CHAR ;
