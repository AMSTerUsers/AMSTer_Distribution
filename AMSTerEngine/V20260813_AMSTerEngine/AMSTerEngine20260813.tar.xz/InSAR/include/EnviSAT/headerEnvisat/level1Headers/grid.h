
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Geolocation Grid Annotation Data Set */
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
*/

#include "MJD.h"

#if !defined(GEOLOCATION_GRID)
#define GEOLOCATION_GRID



typedef struct {
    MJD			Doppler_Azimuth_Time_First ;			/* field 1 */
    unsigned char	Attachment ;					/* field 2 */
    unsigned long	Range_Line_Number ;				/* field 3 */
    unsigned long	Number_Output_Lines ;				/* field 4 */
    float		Track_Heading ;					/* field 5 */
    unsigned long	Range_Sample_Number_First[11] ;			/* field 6 */
    float		Slant_Range_Time_First[11] ;
    float		Incidence_Angle_First[11] ;
    long		Latitude_First[11] ;
    long		Longitude_First[11] ;
	char		Spare1[22] ;					/* field 7 */
    MJD			Doppler_Azimuth_Time_Last ;			/* field 8 */
    unsigned long	Range_Sample_Number_Last[11] ;			/* field 9 */
    float		Slant_Range_Time_Last[11] ;
    float		Incidence_Angle_Last[11] ;
    long		Latitude_Last[11] ;
    long		Longitude_Last[11] ;
    char		Spare2[22] ;					/* field 10 */
} GEOLOCATION_GRID_HEADER ;

#define GEOLOCATION_GRID_HEADER_SIZE	sizeof(GEOLOCATION_GRID_HEADER)

typedef struct {
    char	Doppler_Azimuth_Time_First[12] ;		/* field 1 */
    char	Attachment ;					/* field 2 */
    char	Range_Line_Number[4] ;				/* field 3 */
    char	Number_Output_Lines[4] ;			/* field 4 */
    char	Track_Heading[4] ;				/* field 5 */
    char	Range_Sample_Number_First[44] ;			/* field 6 */
    char	Slant_Range_Time_First[44] ;
    char	Incidence_Angle_First[44] ;
    char	Latitude_First[44] ;
    char	Longitude_First[44] ;
    char	Spare1[22] ;					/* field 7 */
    char	Doppler_Azimuth_Time_Last[12] ;			/* field 8 */
    char	Range_Sample_Number_Last[44] ;			/* field 9 */
    char	Slant_Range_Time_Last[44] ;
    char	Incidence_Angle_Last[44] ;
    char	Latitude_Last[44] ;
    char	Longitude_Last[44] ;
    char	Spare2[22] ;					/* field 10 */
} GEOLOCATION_GRID_HEADER_CHAR ;

#endif
