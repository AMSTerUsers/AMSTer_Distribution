
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Antenna Elevation Pattern Data Set */
#include "MJD.h"

typedef struct {
    MJD			Doppler_Azimuth_Time ;			/* field 1 */
    unsigned char	Attachment ;				/* field 2 */
    unsigned char	Beam_Id[3] ;				/* field 3 */
    float		Slant_Range_Time[11] ;			/* field 4 */
    float		Elevation_Angles[11] ;
    float		Antenna_Elevation[11] ;
    char	Spare[14] ;				/* field 5 */
} ANTENNA_ELEVATION_HEADER ;

#define  ANTENNA_ELEVATION_HEADER_SIZE	sizeof(ANTENNA_ELEVATION_HEADER)



typedef struct {
    char	Doppler_Azimuth_Time[12] ;			/* field 1 */
    char	Attachment ;					/* field 2 */
    char	Beam_Id[3] ;					/* field 3 */
    char	Slant_Range_Time[44] ;				/* field 4 */
    char	Elevation_Angles[44] ;
    char	Antenna_Elevation[44] ;
    char	Spare[14] ;					/* field 5 */
} ANTENNA_ELEVATION_HEADER_CHAR ;
