
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include "MJD.h"

#if !defined(MDS)
#define MDS

/* Measurement Data Set header */

typedef struct {
    MJD			Azimuth_Doppler_Time ;		/* field 1 */
    char		Quality_Indicator ;		/* field 2 */
    unsigned long	Range_Line_Number ;		/* field 3 */
} MDS_HEADER ;




typedef struct {
    char		Azimuth_Doppler_Time[12] ;	/* field 1 */
    char		Quality_Indicator ;		/* field 2 */
    char		Range_Line_Number[4] ;		/* field 3 */
} MDS_HEADER_CHAR ;

#endif