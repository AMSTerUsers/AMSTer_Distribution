
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Main Processing Parameters Annotation Data Set Record */
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
*/

#include "MJD.h"


typedef struct {
    unsigned long	Number_Input_Gaps ;
    unsigned long	Number_Missing_Lines ;
    unsigned long	Range_Sample ;
    unsigned long	Range_Lines ;
    float		I_Channel_Bias ;
    float		Q_Channel_Bias ;
    float		I_Channel_Std_Deviation ;
    float		Q_Channel_Std_Deviation ;
    float		I_Q_Gain ;
    float		I_Q_Quadrature ;
    float		I_Bias_Upper ;
    float		I_Bias_Lower ;
    float		Q_Bias_Upper ;
    float		Q_Bias_Lower ;
    float		I_Q_Gain_Lower ;
    float		I_Q_Gain_Upper ;
    float		I_Q_Quadrature_Lower ;
    float		I_Q_Quadrature_Upper ;
    unsigned char	I_Bias_Significance ;
    unsigned char	Q_Bias_Significance ;
    unsigned char	I_Q_Gain_Significance ;
    unsigned char	I_Q_Quadrature_Significance ;
    float		I_Channel_Correction ;
    float		Q_Channel_Correction ;
    float		I_Q_Gain_Correction ;
    float		I_Q_Quadrature_Correction ;
} RAW_DATA_ANALYSIS ;


typedef struct {
    unsigned long	On_Board_Time[2] ;
    MJD			Sensing_Time ;
} DOWNLINK ;

typedef struct {
    float		Chirp_Amplitude_Coef[4] ;		
    float		Chirp_Phase_Coef[4] ;	
} CHIRP ;

typedef struct {
    float		Processor_Scaling_Factor ;
    float		External_Scaling_Factor ;
} CALIBRATION ;


typedef struct {
    float		Real_Data_Mean ;
    float		Imaginary_Data_Mean ;
    float		Real_Std_Deviation ;
    float		Imaginary_Std_Deviation ;
} PROCESS_INFORMATION ;

typedef struct {
    MJD			Time_State_Vector ;				
    signed int		X_Position_Earth ;
    signed int		Y_Position_Earth ;				
    signed int		Z_Position_Earth ;				
    signed int		X_Velocity_Earth ;				
    signed int		Y_Velocity_Earth ;				
    signed int		Z_Velocity_Earth ;
} ORBIT_VECTOR ;			


typedef struct {
    MJD			First_Azimuth_Time ;			/* field 1 */
    unsigned char	Attachment_Flag ;			/* field 2 */
    MJD			Last_Azimuth_Time ;			/* field 3 */
	char		Work_Order_Id[12] ;			/* field 4 */
    float		Time_Difference ;			/* field 5 */
    char		Swath_Number[3] ;			/* field 6 */
    float		Range_Sample_Spacing ;			/* field 7 */
    float		Azimuth_Sample_Spacing ;		/* field 8 */
    float		Azimuth_Spacing_InTime ;		/* field 9 */
    unsigned long	Number_Output_Range ;			/* field 10 */
    unsigned long	Number_Samples ;			/* field 11 */
    char		Output_Data_Type[5] ;			/* field 12 */
    char		Spare1[51] ;				/* field 13 */

    unsigned char	Raw_Analysis ;				/* field 14 */
    unsigned char	Antenna_Elevation ;			/* field 15 */
    unsigned char	Reconstructed_Chirp ;			/* field 16 */
    unsigned char	Slant_Range_Conversion ;		/* field 17 */
    unsigned char	Doppler_Centroid_Estimation ;		/* field 18 */
    unsigned char	Doppler_Ambiguity_Estimation;		/* field 19 */
    unsigned char	Range_Spreading_Loss ;			/* field 20 */
    unsigned char	Detection ;				/* field 21 */
    unsigned char	Look_Sommation ;			/* field 22 */
    unsigned char	RMS_Equalization ;			/* field 23 */
    unsigned char	Antenna_Gain ;				/* field 24 */
    char		Spare2[10] ;				/* field 25 */

    RAW_DATA_ANALYSIS MDS1_Raw ;				/* field 26 */
    RAW_DATA_ANALYSIS MDS2_Raw ;
    char		Spare3[32] ;				/* field 27 */

    DOWNLINK		MDS1_Downlink ;				/* field 28 */
    DOWNLINK		MDS2_Downlink ;

    unsigned short	usStart_Time_First_Line[5] ;		/* field 29 */
    unsigned short	usStart_Time_Last_Line[5] ;	
    unsigned short	usPulse_Interval[5] ;	
    unsigned short	usTX_Pulse_Length[5] ;	
    unsigned short	usTX_Pulse_Bandwidth[5] ;	
    unsigned short	usEcho_Window[5] ;	
    unsigned short	usUpconverter[5] ;	
    unsigned short	usDownconverter[5] ;	
    unsigned short	usResampling[5] ;	
    unsigned short	usBeam_Adjustment[5] ;	
    unsigned short	usAntenna_Beam[5] ;	
    unsigned short	usAuxiliary_Tx[5] ;	

    char	Spare4[60] ;				/* field 30 */

    unsigned long	Sampling_Windows_Err ;			/* field 31 */
    unsigned long	PRI_Code_Err ;
    unsigned long	TX_Pulse_Length_Err ;
    unsigned long	TX_Pulse_Bandwidth_Err ;
    unsigned long	Echo_Window_Err ;
    unsigned long	Upconverter_Err ;
    unsigned long	Downconverter_Err ;
    unsigned long	Resampling_Err ;
    unsigned long	Beam_Adjustment_Err ;
    unsigned long	Antenna_Beam_Err ;

    char	Spare5[26] ;				/* field 32 */

    float		flStart_Time_First_Line[5] ;		/* field 33 */
    float		flStart_Time_Last_Line[5] ;
    unsigned long	ulNumber_Sample_Window[5] ;
    float		flPulse_Repetition_Frequency[5] ;	
    float		flTX_Pulse_Length[5] ;	
    float		flTX_Pulse_Bandwidth[5] ;	
    float		flEcho_Window[5] ;	
    float		flUpconverter[5] ;	
    float		flDownconverter[5] ;	
    float		flResampling[5] ;	
    float		flBeam_Adjustment[5] ;	
    unsigned short	Antenna_Beam_Set[5] ;	
    float		flAuxiliary_Tx[5] ;	

    char	Spare6[82] ;				/* field 34 */

    unsigned long	First_Sample ;				/* field 35 */
    float		Range_Reference ;			/* field 36 */
    float		Range_Sampling_Rate ;			/* field 37 */
    float		Radar_Frequency ;			/* field 38 */
    unsigned short	Number_Range_Looks ;			/* field 39 */
	char		Filter_Window_Type[7] ;			/* field 40 */
    float		Window_Coefficient ;			/* field 41 */

    float		Range_Look_Bandwidth[5] ;		/* field 42 */
    float		Total_Range_Bandwidth[5] ;

    CHIRP		SS1 ;					/* field 43 */
    CHIRP		SS2 ;
    CHIRP		SS3 ;
    CHIRP		SS4	;
    CHIRP		SS5 ;

    char	Spare7[60] ;				/* field 44 */

    unsigned long	Number_Input_Lines ;			/* field 45 */
    unsigned short	Number_Azimuth_Looks ;			/* field 46 */
    float		Azimuth_Look_Bandwidth ;		/* field 47 */
    float		Processed_Azimuth_Bandwidth ;		/* field 48 */
	char	Matched_Filter_Type[7] ;		/* field 49 */
    float		Window_Coef ;				/* field 50 */
    float		Azimuth_FMRate[3] ;			/* field 51 */
    float		Slant_Range_Time ;			/* field 52 */
    float		Doppler_Measure ;			/* field 53 */
    char	Spare8[68] ;				/* field 54 */

    CALIBRATION		MDS1_Calibration ;			/* field 55 */
    CALIBRATION		MDS2_Calibration ;	

    float		Noise_Power[5] ;			/* field 56 */
    unsigned long	Noise_Lines[5] ;
    char	Spare9[64] ;				/* field 57 */

	char	Spare10[12] ;				/* field 58 */
    PROCESS_INFORMATION	MDS1_Process ;				/* field 59 */
    PROCESS_INFORMATION	MDS2_Process ;
    char	Spare11[52] ;				/* field 60 */

	char	Compres_Method_Echo[4] ;		/* field 61 */
	char	Compres_Ratio_Echo[3] ;			/* field 62 */
	char	Compres_Method_Init_Calib[4] ;		/* field 63 */
	char	Compres_Ratio_Init_Calib[3] ;		/* field 64 */
	char	Compres_Method_Period_Calib[4] ;	/* field 65 */
	char	Compres_Ratio_Period_Calib[3] ;		/* field 66 */
	char	Compres_Method_Noise[4] ;		/* field 67 */
	char	Compres_Ratio_Noise[3] ;		/* field 68 */
    char	Spare12[64] ;				/* field 69 */

    unsigned long	Number_Slant_Range[4] ;			/* field 70 */
    unsigned long	Number_Lines_Burst[5] ;			/* field 71 */
    char	Spare13[44] ;				/* field 72 */

    ORBIT_VECTOR	Orbit_State[5] ;			/* field 73 */
    char	Spare14[64] ;				/* field 74 */

} MPP_ADSR_HEADER ;

#define MPP_ADSR_HEADER_SIZE	sizeof(MPP_ADSR_HEADER)





typedef struct {
    char	Number_Input_Gaps[4] ;
    char	Number_Missing_Lines[4] ;
    char	Range_Sample[4] ;
    char	Range_Lines[4] ;
    char	I_Channel_Bias[4] ;
    char	Q_Channel_Bias[4] ;
    char	I_Channel_Std_Deviation[4] ;
    char	Q_Channel_Std_Deviation[4] ;
    char	I_Q_Gain[4] ;
    char	I_Q_Quadrature[4] ;
    char	I_Bias_Upper[4] ;
    char	I_Bias_Lower[4] ;
    char	Q_Bias_Upper[4] ;
    char	Q_Bias_Lower[4] ;
    char	I_Q_Gain_Lower[4] ;
    char	I_Q_Gain_Upper[4] ;
    char	I_Q_Quadrature_Lower[4] ;
    char	I_Q_Quadrature_Upper[4] ;
    char	I_Bias_Significance ;
    char	Q_Bias_Significance ;
    char	I_Q_Gain_Significance ;
    char	I_Q_Quadrature_Significance ;
    char	I_Channel_Correction[4];
    char	Q_Channel_Correction[4] ;
    char	I_Q_Gain_Correction[4] ;
    char	I_Q_Quadrature_Correction[4] ;
} RAW_DATA_ANALYSIS_CHAR ;

typedef struct {
    char	On_Board_Time[8] ;
    char	Sensing_Time[12] ;
} DOWNLINK_CHAR ;

typedef struct {
    char	Chirp_Amplitude_Coef[16] ;		
    char	Chirp_Phase_Coef[16] ;	
} CHIRP_CHAR ;

typedef struct {
    char	Processor_Scaling_Factor[4] ;
    char	External_Scaling_Factor[4] ;
} CALIBRATION_CHAR ;

typedef struct {
    char	Real_Data_Mean[4] ;
    char	Imaginary_Data_Mean[4] ;
    char	Real_Std_Deviation[4] ;
    char	Imaginary_Std_Deviation[4] ;
} PROCESS_INFORMATION_CHAR ;

typedef struct {
    char	Time_State_Vector[12] ;	
    char	X_Position_Earth[4] ;
    char	Y_Position_Earth[4] ;
    char	Z_Position_Earth[4] ;
    char	X_Velocity_Earth[4] ;
    char	Y_Velocity_Earth[4] ;
    char	Z_Velocity_Earth[4] ;
} ORBIT_VECTOR_CHAR ;

typedef struct {
    char	First_Azimuth_Time[12] ;			/* field 1 */
    char	Attachment_Flag ;				/* field 2 */
    char	Last_Azimuth_Time[12] ;				/* field 3 */
    char	Work_Order_Id[12] ;				/* field 4 */
    char	Time_Difference[4] ;				/* field 5 */
    char	Swath_Number[3] ;				/* field 6 */
    char	Range_Sample_Spacing[4] ;			/* field 7 */
    char	Azimuth_Sample_Spacing[4] ;			/* field 8 */
    char	Azimuth_Spacing_InTime[4] ;			/* field 9 */
    char	Number_Output_Range[4] ;			/* field 10 */
    char	Number_Samples[4] ;				/* field 11 */
    char	Output_Data_Type[5] ;				/* field 12 */
    char	Spare1[51] ;					/* field 13 */

    char	Raw_Analysis ;					/* field 14 */
    char	Antenna_Elevation ;				/* field 15 */
    char	Reconstructed_Chirp ;				/* field 16 */
    char	Slant_Range_Conversion ;			/* field 17 */
    char	Doppler_Centroid_Estimation ;			/* field 18 */
    char	Doppler_Ambiguity_Estimation;			/* field 19 */
    char	Range_Spreading_Loss ;				/* field 20 */
    char	Detection ;					/* field 21 */
    char	Look_Sommation ;				/* field 22 */
    char	RMS_Equalization ;				/* field 23 */
    char	Antenna_Gain ;					/* field 24 */
    char	Spare2[10] ;					/* field 25 */

    RAW_DATA_ANALYSIS_CHAR MDS1_Raw ;				/* field 26 */
    RAW_DATA_ANALYSIS_CHAR MDS2_Raw ;
    char	Spare3[32] ;					/* field 27 */

    DOWNLINK_CHAR		MDS1_Downlink ;			/* field 28 */
    DOWNLINK_CHAR		MDS2_Downlink ;

    char	usStart_Time_First_Line[10] ;			/* field 29 */
    char	usStart_Time_Last_Line[10] ;	
    char	usPulse_Interval[10] ;	
    char	usTX_Pulse_Length[10] ;	
    char	usTX_Pulse_Bandwidth[10] ;	
    char	usEcho_Window[10] ;	
    char	usUpconverter[10] ;	
    char	usDownconverter[10] ;	
    char	usResampling[10] ;	
    char	usBeam_Adjustment[10] ;	
    char	usAntenna_Beam[10] ;	
    char	usAuxiliary_Tx[10] ;	

    char	Spare4[60] ;					/* field 30 */

    char	Sampling_Windows_Err[4] ;			/* field 31 */
    char	PRI_Code_Err[4] ;
    char	TX_Pulse_Length_Err[4] ;
    char	TX_Pulse_Bandwidth_Err[4] ;
    char	Echo_Window_Err[4] ;
    char	Upconverter_Err[4] ;
    char	Downconverter_Err[4] ;
    char	Resampling_Err[4] ;
    char	Beam_Adjustment_Err[4] ;
    char	Antenna_Beam_Err[4] ;
    
    char	Spare5[26] ;					/* field 32 */

    char	flStart_Time_First_Line[20] ;			/* field 33 */
    char	flStart_Time_Last_Line[20] ;
    char	ulNumber_Sample_Window[20] ;
    char	flPulse_Repetition_Frequency[20] ;	
    char	flTX_Pulse_Length[20] ;	
    char	flTX_Pulse_Bandwidth[20] ;	
    char	flEcho_Window[20] ;	
    char	flUpconverter[20] ;	
    char	flDownconverter[20] ;	
    char	flResampling[20] ;	
    char	flBeam_Adjustment[20] ;	
    char	Antenna_Beam_Set[10] ;	
    char	flAuxiliary_Tx[20] ;	

    char	Spare6[82] ;					/* field 34 */

    char	First_Sample[4] ;				/* field 35 */
    char	Range_Reference[4] ;				/* field 36 */
    char	Range_Sampling_Rate[4] ;			/* field 37 */
    char	Radar_Frequency[4] ;				/* field 38 */
    char	Number_Range_Looks[2] ;				/* field 39 */
    char	Filter_Window_Type[7] ;				/* field 40 */
    char	Window_Coefficient[4] ;				/* field 41 */

    char	Range_Look_Bandwidth[20] ;			/* field 42 */
    char	Total_Range_Bandwidth[20] ;

    CHIRP_CHAR	SS1 ;						/* field 43 */
    CHIRP_CHAR	SS2 ;
    CHIRP_CHAR	SS3 ;
    CHIRP_CHAR	SS4	;
    CHIRP_CHAR	SS5 ;

    char	Spare7[60] ;					/* field 44 */

    char	Number_Input_Lines[4] ;				/* field 45 */
    char	Number_Azimuth_Looks[2] ;			/* field 46 */
    char	Azimuth_Look_Bandwidth[4] ;			/* field 47 */
    char	Processed_Azimuth_Bandwidth[4] ;		/* field 48 */
    char	Matched_Filter_Type[7] ;			/* field 49 */
    char	Window_Coef[4] ;				/* field 50 */
    char	Azimuth_FMRate[12] ;				/* field 51 */
    char	Slant_Range_Time[4] ;				/* field 52 */
    char	Doppler_Measure[4] ;				/* field 53 */
    char	Spare8[68] ;					/* field 54 */

    CALIBRATION_CHAR		MDS1_Calibration ;		/* field 55 */
    CALIBRATION_CHAR		MDS2_Calibration ;	

    char	Noise_Power[20] ;				/* field 56 */
    char	Noise_Lines[20] ;
    char	Spare9[64] ;					/* field 57 */

    char	Spare10[12] ;					/* field 58 */
    PROCESS_INFORMATION_CHAR	MDS1_Process ;			/* field 59 */
    PROCESS_INFORMATION_CHAR	MDS2_Process ;
    char	Spare11[52] ;					/* field 60 */

    char	Compres_Method_Echo[4] ;			/* field 61 */
    char	Compres_Ratio_Echo[3] ;				/* field 62 */
    char	Compres_Method_Init_Calib[4] ;			/* field 63 */
    char	Compres_Ratio_Init_Calib[3] ;			/* field 64 */
    char	Compres_Method_Period_Calib[4] ;		/* field 65 */
    char	Compres_Ratio_Period_Calib[3] ;			/* field 66 */
    char	Compres_Method_Noise[4] ;			/* field 67 */
    char	Compres_Ratio_Noise[3] ;			/* field 68 */
    char	Spare12[64] ;					/* field 69 */

    char	Number_Slant_Range[16] ;			/* field 70 */
    char	Number_Lines_Burst[20] ;			/* field 71 */
    char	Spare13[44] ;					/* field 72 */

    ORBIT_VECTOR_CHAR	Orbit_State[5] ;			/* field 73 */
    char	Spare14[64] ;					/* field 74 */

} MPP_ADSR_HEADER_CHAR ;
