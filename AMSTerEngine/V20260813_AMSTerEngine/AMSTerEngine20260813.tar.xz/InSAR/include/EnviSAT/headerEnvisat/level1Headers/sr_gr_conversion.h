
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Slant Range to Ground Range Conversion Annotation Data Set */
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
*/

#include "MJD.h"

typedef struct {
    MJD			Doppler_Azimuth_Time ;			/* field 1 */
    unsigned char	Attachment ;				/* field 2 */
    float		Slant_Range_Time ;			/* field 3 */
    float		Ground_Range_Origin ;			/* field 4 */
    float		Coefficient[5] ;			/* field 5 */
	char	Spare[14] ;				/* field 6 */
} SR_GR_CONVERSION_HEADER ;

#define SR_GR_CONVERSION_HEADER_SIZE	sizeof(SR_GR_CONVERSION_HEADER)


typedef struct {
    char	Doppler_Azimuth_Time[12] ;			/* field 1 */
    char	Attachment ;					/* field 2 */
    char	Slant_Range_Time[4] ;				/* field 3 */
    char	Ground_Range_Origin[4] ;			/* field 4 */
    char	Coefficient[20] ;				/* field 5 */
    char	Spare[14] ;					/* field 6 */
} SR_GR_CONVERSION_HEADER_CHAR ;

