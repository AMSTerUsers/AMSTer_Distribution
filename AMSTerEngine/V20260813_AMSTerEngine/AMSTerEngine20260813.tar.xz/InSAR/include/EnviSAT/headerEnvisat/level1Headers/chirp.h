
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Chirp Parameters Annotation Data Set */

#include "MJD.h"

typedef struct {
    float	Max_Cal_Pulses[3] ;
    float	Average_Cal_Pulse[3] ;
    float	Average_Cal_Pulse_1A ;		
    float	Extracted_Phase[4] ;
} CALIBRATION_PULSE ;

typedef struct {
    MJD			Doppler_Azimuth_Time ;				/* field 1 */
    unsigned char	Attachment ;					/* field 2 */
    unsigned char	Beam_Id[3] ;					/* field 3 */
    unsigned char	Tx_Rx_Polarization[3] ;				/* field 4 */
    float		Pulse_Width ;					/* field 5 */
    float		Side_Lobe ;					/* field 6 */
    float		ISLR ;						/* field 7 */
    float		Peak_Location ;					/* filed 8 */
    float		Chirp_Power ;					/* field 9 */
    float		Elevation_Gain ;				/* field 10 */
	char	Spare1[16] ;					/* field 11 */
    CALIBRATION_PULSE	Calibration_Pulse[32] ;				/* field 12 */
	char	Spare2[16] ;					/* field 13 */
} CHIRP_HEADER ;

#define  CHIRP_HEADER_SIZE	sizeof(CHIRP_HEADER)


typedef struct {
    char	Max_Cal_Pulses[12] ;
    char	Average_Cal_Pulse[12] ;
    char	Average_Cal_Pulse_1A[4] ;		
    char	Extracted_Phase[16] ;
} CALIBRATION_PULSE_CHAR ;

typedef struct {
    char	Doppler_Azimuth_Time[12] ;			/* field 1 */
    char	Attachment ;					/* field 2 */
    char	Beam_Id[3] ;					/* field 3 */
    char	Tx_Rx_Polarization[3] ;				/* field 4 */
    char	Pulse_Width[4] ;				/* field 5 */
    char	Side_Lobe[4] ;					/* field 6 */
    char	ISLR[4] ;					/* field 7 */
    char	Peak_Location[4] ;				/* filed 8 */
    char	Chirp_Power[4] ;				/* field 9 */
    char	Elevation_Gain[4] ;				/* field 10 */
    char	Spare1[16] ;					/* field 11 */
    CALIBRATION_PULSE_CHAR	Calibration_Pulse[32] ;		/* field 12 */
    char	Spare2[16] ;					/* field 13 */
} CHIRP_HEADER_CHAR ;
