
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* Global Annotation Data Set */

typedef struct {
    unsigned char	Map_Projection_Des[32] ;	/* field 1 */
    unsigned long	Number_Samples_Line ;		/* field 2 */
    unsigned long	Number_Lines ;			/* field 3 */
    float		Inter_Sample_Distance ;		/* field 4 */
    float		Inter_Line_Distance ;		/* field 5 */
    float		Output_Scene_Orientation ;	/* field 6 */
	char	Spare1[40] ;			/* field 7 */
    float		Platform_Heading ;		/* field 8 */
    unsigned char	Ellipsoid_Name[32] ;		/* field 9 */
    float		Semi_Major_Axis ;		/* field 10 */
    float		Semi_Minor_Axis ;		/* field 11 */
    float		Datum_Shift_dx ;		/* field 12 */
    float		Datum_Shift_dy ;		/* field 13 */
    float		Datum_Shift_dz ;		/* field 14 */
    float		Average_Scene_Height ;		/* field 15 */
	char		Spare2[12] ;			/* field 16 */
    unsigned char	Map_Projection[32] ;		/* field 17 */
    unsigned char	UTM_Descriptor[32] ;		/* field 18 */
    unsigned char	UTM_Signature[4] ;		/* field 19 */
    float		UTM_Map_Easting ;		/* field 20 */
    float		UTM_Map_Northing ;		/* field 21 */
    signed long		UTM_Projection_Longitude ;	/* field 22 */
    signed long		UTM_Projection_Latitude ;	/* field 23 */
    float		UTM_Parallel_1 ;		/* field 24 */
    float		UTM_Parallel_2 ;		/* field 25 */
    float		UTM_Scale_Factor ;		/* field 26 */
    unsigned char	UPS_Descriptor[32] ;		/* field 27 */
    signed long		UPS_Projection_Longitude ;	/* field 28 */
    signed long		UPS_Projection_Latitude ;	/* field 29 */
    float		UPS_Scale_Factor ;		/* field 30 */

    unsigned char	NSP_Descriptor[32] ;		/* field 31 */
    float		NSP_Map_Easting ;		/* field 32 */
    float		NSP_Map_Northing ;		/* field 33 */
    signed long		NSP_Projection_Longitude ;	/* field 34 */
    signed long		NSP_Projection_Latitude ;	/* field 35 */

    float		NSP_Parallel_1 ;		/* field 36 */
    float		NSP_Parallel_2 ;				
    float		NSP_Parallel_3 ;				
    float		NSP_Parallel_4 ;				

    float		NSP_Meridian_1 ;		/* field 37 */
    float		NSP_Meridian_2 ;				
    float		NSP_Meridian_3 ;				

    float		NSP_Dependant_1 ;		/* field 38 */
    float		NSP_Dependant_2 ;
    float		NSP_Dependant_3 ;
    float		NSP_Dependant_4 ;

    float		Top_Left_Northing ;		/* field 39 */
    float		Top_Left_Easting ;
    float		Top_Right_Northing ;
    float		Top_Right_Easting ;
    float		Bottom_Right_Northing ;
    float		Bottom_Right_Easting ;
    float		Bottom_Left_Northing ;
    float		Bottom_Left_Easting ;

    float		Top_Left_Latitude ;		/* field 40 */
    float		Top_Left_Longitude ;
    float		Top_Right_Latitude ;
    float		Top_Right_Longitude ;
    float		Bottom_Right_Latitude ;
    float		Bottom_Right_Longitude ;
    float		Bottom_Left_Latitude ;
    float		Bottom_Left_Longitude ;

	char	Spare3[32] ;			/* field 41 */

    float		Coefficient_Position[8] ;	/* filed 42 */
    float		Coefficient_Projection[8] ;	/* field 43 */

	char	Spare4[35] ;			/* field 44 */

} GADS_HEADER ;

#define GADS_HEADER_SIZE	sizeof(GADS_HEADER)

typedef struct {
    char	Map_Projection_Des[32] ;		/* field 1 */
    char	Number_Samples_Line[4] ;		/* field 2 */
    char	Number_Lines[4] ;			/* field 3 */
    char	Inter_Sample_Distance[4] ;		/* field 4 */
    char	Inter_Line_Distance[4] ;		/* field 5 */
    char	Output_Scene_Orientation[4] ;		/* field 6 */
    char	Spare1[40] ;				/* field 7 */
    char	Platform_Heading[4] ;			/* field 8 */
    char	Ellipsoid_Name[32] ;			/* field 9 */
    char	Semi_Major_Axis[4] ;			/* field 10 */
    char	Semi_Minor_Axis[4] ;			/* field 11 */
    char	Datum_Shift_dx[4] ;			/* field 12 */
    char	Datum_Shift_dy[4] ;			/* field 13 */
    char	Datum_Shift_dz[4] ;			/* field 14 */
    char	Average_Scene_Height[4] ;		/* field 15 */
    char	Spare2[12] ;				/* field 16 */
    char	Map_Projection[32] ;			/* field 17 */

    char	UTM_Descriptor[32] ;			/* field 18 */
    char	UTM_Signature[4] ;			/* field 19 */
    char	UTM_Map_Easting[4] ;			/* field 20 */
    char	UTM_Map_Northing[4] ;			/* field 21 */
    char	UTM_Projection_Longitude[4] ;		/* field 22 */
    char	UTM_Projection_Latitude[4] ;		/* field 23 */
    char	UTM_Parallel_1[4] ;			/* field 24 */
    char	UTM_Parallel_2[4] ;			/* field 25 */
    char	UTM_Scale_Factor[4] ;			/* field 26 */

    char	UPS_Descriptor[32] ;			/* field 27 */
    char	UPS_Projection_Longitude[4] ;		/* field 28 */
    char	UPS_Projection_Latitude[4] ;		/* field 29 */
    char	UPS_Scale_Factor[4] ;			/* field 30 */

    char	NSP_Descriptor[32] ;			/* field 31 */
    char	NSP_Map_Easting[4] ;			/* field 32 */
    char	NSP_Map_Northing[4] ;			/* field 33 */
    char	NSP_Projection_Longitude[4] ;		/* field 34 */
    char	NSP_Projection_Latitude[4] ;		/* field 35 */

    char	NSP_Parallel_1[4] ;			/* field 36 */
    char	NSP_Parallel_2[4] ;				
    char	NSP_Parallel_3[4] ;				
    char	NSP_Parallel_4[4] ;				

    char	NSP_Meridian_1[4] ;			/* field 37 */
    char	NSP_Meridian_2[4] ;				
    char	NSP_Meridian_3[4] ;				

    char	NSP_Dependant_1[4] ;			/* field 38 */
    char	NSP_Dependant_2[4];
    char	NSP_Dependant_3[4] ;
    char	NSP_Dependant_4[4] ;

    char	Top_Left_Northing[4] ;			/* field 39 */
    char	Top_Left_Easting[4] ;
    char	Top_Right_Northing[4] ;
    char	Top_Right_Easting[4] ;
    char	Bottom_Right_Northing[4] ;
    char	Bottom_Right_Easting[4] ;
    char	Bottom_Left_Northing[4] ;
    char	Bottom_Left_Easting[4] ;

    char	Top_Left_Latitude[4] ;			/* field 40 */
    char	Top_Left_Longitude[4] ;
    char	Top_Right_Latitude[4] ;
    char	Top_Right_Longitude[4] ;
    char	Bottom_Right_Latitude[4] ;
    char	Bottom_Right_Longitude[4] ;
    char	Bottom_Left_Latitude[4] ;
    char	Bottom_Left_Longitude[4] ;

    char	Spare3[32] ;				/* field 41 */

    char	Coefficient_Position[32] ;		/* filed 42 */
    char	Coefficient_Projection[32] ;		/* field 43 */

    char	Spare4[35] ;				/* field 44 */

} GADS_HEADER_CHAR ;
