
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  EnviSATDataReaderLib.h
 *  EnviSATDataReader
 *
 *  Created by Dominique Derauw on 10/10/11.
 *  Copyright 2011 CSL. All rights reserved.
 *
 */

#ifndef EnviSATDataReaderLib_EnviSATDataReaderLib_h
#define EnviSATDataReaderLib_EnviSATDataReaderLib_h

#include "EnvisatPrecisesOrbits.h"
#include "SARPlatformID.h"

#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "rawFileLib.h"
#include "infoImage.h"
#include "infoImageEnvisat.h"
#include "envisat.h"
#include "byteSwap.h"
#include "counters.h"
#include "vectors.h"

void copyEnviSATHeadersToHeadersDirectory(char *inputPath, CSLImage *thisImage, ENVISAT_HEADER *header)  ;
void createInfoTextFileFromHeaderFor(CSLImage *thisImage, ENVISAT_HEADER *header) ;
void readAndConvertEnviSATSLCDataInto(CSLImage *thisImage, ENVISAT_HEADER *header, char *EnviSATFilePAth, int imageIndex) ;
void readROI_PACData(keyValue *parametersList, int argc, const char * argv[]) ;
void EnviSATDataReaderHelp() ;
void createEnviSATDataReaderParameterFileAtPath(int argc, const char * argv[]) ;

#endif
