
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  exCal.h
 *  externalCalibrationDataHandler
 *
 *  Created by Dominique Derauw on Wed Jul 02 2003.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(EXCAL)
#define EXCAL

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include "mphENVISAT.h"
#include "sphENVISAT.h"
#include "sphXCA.h"
#include "gadsXCAv2.h"

struct exCal{
    char	fileAcces[256] ;
    MAIN_PRODUCT_HEADER		*mph ;
    sphXCA			*sph ;
    gadsXCA			*gads ;
} ;


float approxAntennaGainForElevationAngle(float , float *, float ) ;
struct exCal *allocExternalCalibrationObject() ;
void readExternalCalibrationFile(struct exCal *, char *) ;
void readFromCharStructure(struct exCal *, FILE *) ;


#endif