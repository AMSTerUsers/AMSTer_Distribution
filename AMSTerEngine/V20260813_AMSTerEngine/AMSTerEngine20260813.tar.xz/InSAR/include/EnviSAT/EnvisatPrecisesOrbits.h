
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  EnvisatPrecisesOrbits.h
//  EnvisatPrecisesOrbits
//
//  Created by Dominique Derauw on 21/05/15.
//  Copyright (c) 2015 Dominique Derauw. All rights reserved.
//

#ifndef EnvisatPrecisesOrbits_EnvisatPreciseOrbits_h
#define EnvisatPrecisesOrbits_EnvisatPreciseOrbits_h

#include "pourtous.h"
#include "paramLib.h"
#include "infoImage.h"
#include "CSLImageFormat.h"
#include "readASCII_Val.h"
#include "resmat.h"
#include "mphENVISAT.h"
#include "auxSPH.h"
#include "DSD.h"
#include "infoImage.h"
#include "geoRef.h"


typedef struct {
    
    char UTC_Orbit_State_Vector[27] ;   /* Field 1 */
    char blank_space1 ;                 /* Field 2 */
    
    char Delta_UT1[8] ;                 /* Field 3 [s] */
    char blank_space2 ;                 /* Field 4 */
    
    char Absolute_Orbit_Number[6] ;     /* Field 5 */
    char blank_space3 ;                 /* Field 6 */
    
    char X_Position[12] ;               /* Field 7 [m] */
    char blank_space4 ;                 /* Field 8 */
    
    char Y_Position[12] ;               /* Field 9 [m] */
    char blank_space5 ;                 /* Field 10 */
    
    char Z_Position[12] ;               /* Field 11 [m] */
    char blank_space6 ;                 /* Field 12 */
    
    char X_Velocity[12] ;               /* Field 13 [m/s] */
    char blank_space7 ;                 /* Field 14 */
    
    char Y_Velocity[12] ;               /* Field 15 [m/s] */
    char blank_space8 ;                 /* Field 16 */
    
    char Z_Velocity[12] ;               /* Field 17 [m/s] */
    char blank_space9 ;                 /* Field 18 */
    
    char Quality_Flags[6] ;             /* Field 19 */
    char terminator ;                   /* Field 20 */
    
} MDSR_DORIS_PRECISE_ORBIT_STATE_VECTOR ;

#define MDSR_DORIS_PRECISE_ORBIT_STATE_VECTOR_SIZE sizeof(MDSR_DORIS_PRECISE_ORBIT_STATE_VECTOR)

char *getDORISDirectory(keyValue *parametersList, int argc, const char *argv[]) ;
void managePrecisesOrbitsFor(CSLImage *thisImage, char *DORISDir) ;
void readPreciseOrbitStateVectors( FILE *f1, struct infoImage *info );
void computeInterpolatedStateVectors(SLCImageInfo *info) ;
int dayIndex(int YYYY, int MM, int DD) ;
char *findOrbitFilePath(SLCImageInfo *info, char *orbitDir) ;

#endif
