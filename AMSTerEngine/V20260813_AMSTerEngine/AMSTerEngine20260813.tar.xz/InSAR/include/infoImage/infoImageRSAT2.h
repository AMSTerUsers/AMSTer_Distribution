
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageRSAT2.h
//  RSAT2DAtaReader
//
//  Created by Dominique Derauw on 12/02/15.
//  Copyright SAREOS (c) 2015 Dominique Derauw. All rights reserved.
//

#ifndef RSAT2DAtaReader_infoImageRSAT_h
#define RSAT2DAtaReader_infoImageRSAT_h

#include <stdio.h>
#include "infoImage.h"
#include "geoRef.h"
#include "basicXMLHandlingLib.h"
#include "gridMapping.h"
#include "polynomials.h"
#include "fileAccessLib.h"

typedef struct {
    char isAzimuthFlipped ;
    char isRangeFlipped ;
} RSAT2AdditionalInfo ;

/* Create infoImage for S1 data */
struct infoImage *createSLCImageInfoForRSAT2Data(char *productInfoFilePAth) ;
double getTimeValInSecFromDateFormat(char* aDateChar) ;



#endif
