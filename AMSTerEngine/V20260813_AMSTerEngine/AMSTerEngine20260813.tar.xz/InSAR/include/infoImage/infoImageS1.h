
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageS1.h
//  S1DataReader
//
//  Created by Dominique Derauw on 7/01/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#ifndef S1DataReader_infoImageS1_h
#define S1DataReader_infoImageS1_h

#include <stdio.h>
#include "CSLImageFormat.h"
#include "infoImage.h"
#include "geoRef.h"
#include "basicXMLHandlingLib.h"
#include "gridMapping.h"
#include "polynomials.h"
#include "fileAccessLib.h"
#include "ncReaderLib.h"

/* ETAD structure definition */
/* ************************* */
#define _ETAD_BISTATIC_CORRECTION_AZ_        0x00000001
#define _ETAD_DOPPLER_RANGE_SHIFT_RG_        0x00000002
#define _ETAD_FM_MISMATCH_CORRECTION_AZ_     0x00000004
#define _ETAD_GEODETIC_CORRECTION_AZ_        0x00000008
#define _ETAD_GEODETIC_CORRECTION_RG_        0x00000010
#define _ETAD_IONOSPHERIC_CORRECTION_RG_     0x00000020
#define _ETAD_SUM_OF_CORRECTIONS_AZ_         0x00000040
#define _ETAD_SUM_OF_CORRECTIONS_RG_         0x00000080
#define _ETAD_TROPOSPHERIC_CORRECTION_RG_    0x00000100
#define _ETAD_HEIGHT_                        0x00000200

#define _ETAD_MASTER_BURST_                  0x00000400
#define _ETAD_SLAVE_BURST_                   0x00000800

#define _ETAD_CORRECTION_                    0x00010000

#if !defined(ETAD_LAYER_NAMES_DEF)
#define ETAD_LAYER_NAMES_DEF
static const char *ETADLayerName[10] = {
    "bistaticCorrectionAz", 
    "dopplerRangeShiftRg", 
    "fmMismatchCorrectionAz", 
    "geodeticCorrectionAz", 
    "geodeticCorrectionRg", 
    "ionosphericCorrectionRg", 
    "sumOfCorrectionsAz", 
    "sumOfCorrectionsRg", 
    "troposphericCorrectionRg", 
    "height", 
} ;
#endif

struct S1ETAD
{
    int layerSelection ;
    double rangeTimeMin ;
    double azimuthTimeMin ;
    double gridStartAzimuthTime ;
    double gridStartRangeTime ;
    double gridSamplingAzimuth ;
    double gridSamplingRange ;
    double averageZeroDopplerVelocity ;
    double instrumentTimingCalibrationRange ;
    double instrumentTimingCalibrationAzimuth ;

    gridMap *bistaticCorrectionAz ;
    gridMap *dopplerRangeShiftRg ;
    gridMap *fmMismatchCorrectionAz ;
    gridMap *geodeticCorrectionAz ;
    gridMap *geodeticCorrectionRg ;
    gridMap *ionosphericCorrectionRg ;
    gridMap *sumOfCorrectionsAz ;
    gridMap *sumOfCorrectionsRg ;
    gridMap *troposphericCorrectionRg ;
    gridMap *height ;
    gridMap **layer ;
} ;
typedef struct S1ETAD S1ETADLayers ;

/* End of ETAD structure definition */

/* S1 data burst structures definitions */
/* ************************************ */
typedef struct {
    int unsigned numberOfEstimates ;
    double *azimuthTime ;
    double *t0 ;
    xPolynomial **dcPolynomial ;
} perBurstDCEstimates ;

typedef struct {
    int unsigned numberOfRecords ;
    double *azimuthTime ;
    double *t0 ;
    xPolynomial **azimuthFmratePolynomial ;
} azimuthFmRateType ;


typedef struct {
    int swathIndex ;
    int burstIndex ;
    int lineIndex ;
    int dcEstimateIndex ;
    int fmRateIndex ;
    double t0 ;     /* Mid burst zero doppler time */
    double *kt ;    /* Doppler centroid rate in the focused data */
    double *tc ;    /* Reference azimuth time */
    double *dc ;    /* Doppler centroid */
    SLCImageInfo *info ;
    xPolynomial *ktPol ;
    xPolynomial *tcPol ;
    xPolynomial *dcPol ;
} derampingStructType ;

struct burstDescriptor {
    char isSelected ;   
    int unsigned frameIndex ;
    int unsigned swathIndex ;
    int unsigned burstIndex ;
    int unsigned xDim ;
    int unsigned yDim ;
    int unsigned firstRangeIndex, lastRangeIndex ;
    int unsigned firstAzimuthIndex, lastAzimuthIndex ;
    int unsigned superpositionAzimuthIndex, midSuperpositionAzimuthIndex ;
    int unsigned firstAzimuthIndexInMDS ;
    int unsigned firstValidLine, lastValidLine ;
    int rangeShift ;                            /* This is the range shift that may occur in case of frame stitching */
    int firstValidSample, lastValidSample, numberOfValidSamples ;
    int *firstValidSampleOfLine, *lastValidSampleOfLine ;
    int unsigned numberOfLayers ;
    double rangeSamplingFrequency ;
    double azimuthSamplingFrequency ;
    double FPRT, LPRT, MPRT ;
    double FPAT, LPAT, MPAT ;
    double anxFPAT ;
    double **T ;
    double rangeTransformConstantTerm ;
    CSLImage *burstImage ;
    rawFileDescriptor **file ;
    quadrilateral *burstLocation ;
    derampingStructType *deramping ;
    xPolynomial *dcPolynomial ;
    S1ETADLayers *ETAD ;
    struct burstDescriptor *preceedingBurst ;
    struct burstDescriptor *nextBurst ;
    struct burstDescriptor *slaveBurst ;
    struct burstDescriptor *masterBurst ;
} ;
typedef struct burstDescriptor burstDescriptor ;

typedef struct {
    char **ADSFilePath ;
    char **MDSFilePath ;
    int unsigned numberOfLayers, selectedLayer ;
    int unsigned numberOfSubSwaths, firstSwathIndex, lastSwathIndex, *numberOfValidSamples ;
    int unsigned rangeIndexStart, azimuthIndexStart, azimuthIndexEnd ;
    int unsigned *swathXDim ;          /* This is the max burst width which is also the swathWidth ; */
    int unsigned *numberOfBursts ;
    int unsigned *firstRangePixelIndexForSubSwath, *lastRangePixelIndexForSubSwath ;
    int *firstValidSampleForSubSwath, *lastValidSampleForSubSwath ;
    int unsigned *superpositionStartIndex, *superpositionEndIndex, *superpositionWidth, *midSuperpositionIndex ;
    int unsigned *swathAzimuthSize, *firstAzimuthLineIndexForSubSwath, *lastAzimuthLineIndexForSubSwath ;
    int unsigned rangeDimension ;
    int unsigned *calibrationXGridDim ;
    int unsigned *calibrationYGridDim ;
    int flag ;
    double twoWayRangeTime ;
    double anxFPAT ;
    double FPAT ;
    double LPAT ;
    double *nearRangeTime ;
    double *rangeBandwidth ;
    double *rangeApodizationCoefficient ;
    double *azimuthBandwidth ;
    double lineTimeInterval ;
    double rangeSamplingFrequency ;
    double *azimuthSteeringRate ;
    double ***calibrationRangeIndex ;
    double **calibrationAzimuthIndex ;
    double ***sigmaNought ;
    double ***betaNought ;
    double ***gamma ;
    double ***dn ;
    perBurstDCEstimates *dcEstimates ;
    azimuthFmRateType *azimuthFmRate ;
    gridMap ***betaGrid ;
    burstDescriptor **burstList ;
} S1AdditionalInfo ;


typedef struct  {
    char ***burstPath ;
    int firstSwathIndex ;
    int lastSwathIndex ;
    int numberOfSwath ;
    int *firstBurstIndex ;
    int *lastBurstIndex ;
    int *numberOfBursts ;
    int totalNumberOfBursts ;
    CSVStruct *refPol ;
    point2D **refPoint ;
    polygon ***aoi ;
} S1BurstSelection ;

/* S1 data management function */
/* *************************** */
struct infoImage *createSLCImageInfoForS1Data(char *S1AccesPath, char *polarization) ;
CSVStruct *concatenateXMLInfoFromXMLDocsAtPath(xmlChar *anXMLPath, xmlDocPtr *xmlDoc, int numberOfEntries) ;
char *setS1HourFormatFromTimeVal(double timeVal) ;
burstDescriptor *allocBurstDescriptor(burstDescriptor *preceedingBurst) ;
void freeBurstDescriptor(burstDescriptor *currentBurst) ;
void freeBurstDescriptorList(burstDescriptor *firstBurst) ;
void freeAllBursts(S1AdditionalInfo *S1Specific) ;
S1AdditionalInfo *allocS1Specific(int numberOfLayers, int numberOfSubSwaths) ;
S1AdditionalInfo *allocAndInitS1Specifics(int unsigned numberOfLayers, int unsigned numberOfSubSwaths, xmlDocPtr *ADSXMLDoc, xmlDocPtr *CADSXMLDoc) ;
void freeS1Specific (S1AdditionalInfo *S1Specific, char trashBursts) ;
double *approxFDCForS1(struct infoImage *info) ;
struct stateVect *readAndSelectStateVectors(xmlDocPtr *ADSXMLDoc, struct infoImage *info) ;
double computeAverageTerrainHeightFromS1ADS(xmlDocPtr *ADSXMLDoc, SLCImageInfo *info) ;
CSVStruct *getCSVForPathInADS(char *xmlPath, xmlDocPtr xmlDoc) ;
void allocAndInitDerampingForBursts(SLCImageInfo *infoImage) ;
void freeDerampingStruct(derampingStructType *deramp) ;
char **getADSFileNames(char *aPath, char *polarization, int unsigned *nMDS) ;
char *getExtensionOfMDSFiles(char *MDSFilePath) ;
xmlDocPtr *openADSXMLFiles(char **ADSFilePath, int numberOfMDS) ;
char **getADSFilePath(char *ADSDirectory, char **ADSFileNames, int numberOfMDS) ;
char **getCADSFilePath(char *calibrationDirectory, char **ADSFileNames, int numberOfMDS) ;
char **getMDSFilePath(char *MDSDirectory, char **ADSFileNames, int numberOfMDS) ;
S1AdditionalInfo *initS1SpecificInfo(SLCImageInfo *info, char *CSLImagePath) ;
void geolocatBursts(SLCImageInfo *info) ;
void updateBurstSelectionAtPath(SLCImageInfo *info, char *infoDir) ;
void saveS1InfoImage(SLCImageInfo *info, char *aPath) ;
char selectS1Bursts(quadrilateral *aoi, SLCImageInfo *info, int unsigned coordinateSystem) ;
void updateSpecificFieldsForSelectedBursts(SLCImageInfo *info) ;
void updateAzimuthIndexesForBursts(S1AdditionalInfo *S1Specific) ;
void orderBurstList(burstDescriptor *burstList) ;
void orderBurstInImage(S1AdditionalInfo *S1Specific) ;
void updateFrameIndexOfBursts(S1AdditionalInfo *S1Specific, int unsigned frameIndex) ;
void updateBurstIndexes(S1AdditionalInfo *S1Specific) ;
burstDescriptor *getBurstAtFrameSwathIndex(S1AdditionalInfo *S1Specific, int unsigned frameIndex, int unsigned swathIndex, int unsigned burstIndex) ;
burstDescriptor *getBurstAtIndex(burstDescriptor *firstBurst, int unsigned anIndex) ;
burstDescriptor *getFirstBurstInList(burstDescriptor *burstList) ;
burstDescriptor *getFirstBurstOfFrameInList(burstDescriptor *burstList, int unsigned frameIndex) ;
burstDescriptor *getFirstSelectedBurstInList(burstDescriptor *burstList) ;
burstDescriptor *getLastBurstInList(burstDescriptor *burstList) ;
burstDescriptor *getLastSelectedBurstInList(burstDescriptor *burstList) ;
void switchBursts(burstDescriptor *firstBurst, burstDescriptor *secondBurst) ;
double getNearRangeTimeInBurstList(burstDescriptor *burstList) ;
double getFarRangeTimeInBurstList(burstDescriptor *burstList) ;
double getNearRangeTimeInSelectedBurstList(burstDescriptor *burstList) ;
double getFarRangeTimeInSelectedBurstList(burstDescriptor *burstList) ;
burstDescriptor *getBurstForAzimuthLineInBurstList(burstDescriptor *burstList, int unsigned azimuthIndex) ;
burstDescriptor *getBurstForPoint(S1AdditionalInfo *S1Specific, int unsigned rangeIndex, int unsigned azimuthIndex) ;
CSVStruct *listReadS1FramesInDir(char *aDir) ;

/* ETAD management function */
/* ************************ */
char *findETADFile(char *S1FileName, char *dir) ;
void updateETADDataIntoS1Frame(CSLImage *aFrame, char *ETADDataDir) ;
char isETADPresentInCSLImage(CSLImage *thisImage) ;
S1ETADLayers *allocETADLayersStruct() ;
void freeETADLayersStruct(S1ETADLayers *ETAD) ;
void loadETADLayersIntoBursts(SLCImageInfo *info, int layerSelection) ;
void loadETADLayerIntoBurst(size_t ETADLayerIndex, burstDescriptor *currentBurst) ;
double ETADPhaseDelayAtPoint(double rangePosition, double azimuthPosition, SLCImageInfo *masterInfo, SLCImageInfo *slaveInfo) ;
double ETADHeightAtPoint(double rangePosition, double azimuthPosition, SLCImageInfo *info) ;
coord2D ETADGeoreferencingShift(double rangePosition, double azimuthPosition, SLCImageInfo *info) ;

#endif
