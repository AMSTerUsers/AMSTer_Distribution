
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  CSLImageFormat.h
 *  ERSDataReader
 *
 *  Created by Dominique Derauw on 10/10/11.
 *  Copyright 2011 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(CSL_IMAGE_FORMAT)
#define CSL_IMAGE_FORMAT

#define _CSLIMAGE_DATA_                 0x00000001
#define _CSLIMAGE_HEADERS_              0x00000002
#define _CSLIMAGE_INFO_                 0x00000004
#define _CSLIMAGE_SELECTED_BURSTS_IN_   0x00000008
#define _CSLIMAGE_SELECTED_BURSTS_OUT_  0x00000010
#define _CSLIMAGE_OVERWRITE_            0x00000020
#define _CSLIMAGE_CANCEL_OVERWRITTING_  0x00000040
#define _CSLIMAGE_FORCE_OVERWRITTING_   0x00000080
#define _CSLIMAGE_ALL_                  _CSLIMAGE_DATA_ | _CSLIMAGE_HEADERS_ | _CSLIMAGE_INFO_

#include "pourtous.h"
//#include "paramLib.h"
#include "rawFileLib.h"
#include "fileAccessLib.h"
#include "SARPlatformID.h"
#include "gridMapping.h"
#include "paramLib.h"
#include "infoImage.h"
#include "approxRt.h"
#include "interpStateVect.h"

typedef struct CSLBaseImageStructure {
	char *imageDirectoryPath ;
	char *dataDirectoryPath ;
	char *headersDirectoryPath ;
	char *infoDirectoryPath ;
	char **dataFileNames ;
	char **headerFileNames ;
	char **infoFileNames ;
	int numberOfDataFiles ;
	int numberOfHeaderFiles ;
	int numberOfInfoFiles ;
    int dataTypeID ;
    int numberOfFrames ;
} CSLImage ;

CSLImage *createCSLDirectoryStructureAtPath(char *aPath, int satellite) ;
CSLImage *createCSLDirectoryStructureFor(CSLImage *aCSLImage, int satellite) ;
CSLImage *allocAndInitCSLImage(void) ;
CSVStruct *listCSLImagesInDir(char *aDir) ;
CSLImage *getCSLImageStructureAtPath(char *aPath) ;
void freeCSLImageStructure(CSLImage *aCSLImage) ;
char isFilePresentInCSLImage(CSLImage *anImage, char *aFileName) ;
char isSLCDataFilePresentInCSLImage(CSLImage *anImage, SLCImageInfo *info) ;
char *getCSLImagePathFromPath (char *imagePath) ;
char isSLCImageInfoPresentInCSLImageAtPath(char *imagePath) ;
char isCSLImageAtPath(char *aPath) ;
char *getPathToFileInCSLImage(CSLImage *anImage, char *aFileName) ;
void copyCSLImage(char *inputPath, char *destinationPath, int flag) ;
gridMap *allocAndInitExternalFileGridForImage(CSLImage *anImage, char *fileName) ;
SLCImageInfo *readInfoImageInCSLImage(CSLImage *aCSLImage) ;
SLCImageInfo *readInfoImageInCSLImageAtPath(char *imagePath) ;
void saveInfoImageInCSLImage(SLCImageInfo *infoImage, CSLImage *aCSLImage) ;
SLCImageInfo *readAndInitInfoImageInCSLImage(CSLImage *aCSLImage) ;
CSLImage **getFrameListInCSLImage(CSLImage *aCSLImage, size_t *numberOfFrames) ;
void freeCSLImageListing(CSLImage **imageList, int numberOfImages)  ;
int unsigned getNumberOfFramesInCSLImage(CSLImage *aCSLImage) ;
int getFrameIndexInCSLImage(CSLImage *aCSLImage, SLCImageInfo *existingFrameInfo) ;
int getNewFrameIndexInCSLImage(CSLImage *aCSLImage, double frameFPAT) ;
CSVStruct *getListingOfCSLImagesInDir(char *inputDir, char *fromDate, char *toDate) ;
void removeEmptyFramesInCSLImage(CSLImage *imageContainer) ;
void renameCSLImage(CSLImage *aCSLImage, char *newName) ;
quadrilateral *getMaxAoiOfCSLImage(CSLImage *thisImage) ;
SLCImageInfo *adaptInfoImageOfCSLImageToAoi(CSLImage *thisImage, quadrilateral *aoi, char saveIt) ;
void cropCSLImageToAoi(CSLImage *thisImage, quadrilateral *aoi)  ;


#endif
