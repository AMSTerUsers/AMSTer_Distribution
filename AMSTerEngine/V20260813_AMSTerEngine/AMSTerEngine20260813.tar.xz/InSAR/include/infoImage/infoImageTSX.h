
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageTSX.h
//  TSXDataReader
//
//  Created by Dominique Derauw on 22/08/12.
//  Copyright (c) 2012 Dominique Derauw. All rights reserved.
//

#ifndef TSXDataReader_infoImageTSX_h
#define TSXDataReader_infoImageTSX_h

#define _SHORT_FLOAT_ 0x80

#include <stdio.h>
#include "stringLib.h"
#include "basicXMLHandlingLib.h"
#include "infoImage.h"
#include "geoRef.h"


/* Create infoImage for TSX data */
struct infoImage *createSLCImageInfoFromTSXXMLFile(char *filePath) ;



#endif
