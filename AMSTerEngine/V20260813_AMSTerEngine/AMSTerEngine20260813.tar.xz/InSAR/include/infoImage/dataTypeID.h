
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  dataTypeID.h
//  S1InSARDataReader
//
//  Created by Dominique Derauw on 3/11/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#ifndef S1InSARDataReader_dataTypeID_h
#define S1InSARDataReader_dataTypeID_h

#define ERS1 1
#define ERS2 2
#define ENVISAT 3
#define SENTINEL1 4

#define ALOS 10
#define CSK 11
#define TSX 12
#define TDX 13
#define RSAT2 14
#define ALOS2 15
#define K5 16
#define PAZ1 17
#define SAOCOM_1A 18
#define SAOCOM_1B 19
#define TDM 20
#define CSG 21          /* CSK second generation */

#define ICEYE 100

#endif
