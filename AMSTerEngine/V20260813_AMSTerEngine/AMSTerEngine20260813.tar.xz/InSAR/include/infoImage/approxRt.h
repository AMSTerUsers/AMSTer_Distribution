
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  approxRt.h
 *  genInfoImage
 *
 *  Created by Dominique Derauw on Mon Sep 29 2003.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
 */


#include "pourtous.h"
#include "geoRef.h"
#include "infoImage.h"
#include "resmat.h"
#include "vectors.h"
#include "matrix.h"
#include "vectorialCalculus.h"


double	*approxRt(SLCImageInfo *ima) ;
double approximateEarthRadiusAtRangeAzimuthPosition(int rangePosition, int azimuthPosition, double *EarthRadiusPolynomial) ;
void sceneAverageHeightCrossCheck(SLCImageInfo *info) ;