
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  interpStateVect.h
 *  lecheader
 *
 *  Created by Dominique Derauw on Wed Feb 20 2002.
 *  Copyright (c) 2001 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(INTERP_STATE_VECT)
#define INTERP_STATE_VECT

#include "pourtous.h"
#include "infoImage.h"
#include "vectors.h"
#include "matrix.h"
#include "resmat.h"
#include "stateVect.h"



void calcStateVect(struct stateVect    *S, double azimuthPosition, SLCImageInfo *info) ;
void calcStateVectLin(struct stateVect    *S, double azimuthPosition, struct infoImage *info) ;
void	interpolStateVect(struct infoImage *) ;
void	stateVectorsReferentialTranslation(struct infoImage *ima, ellipsoid *ellProj) ;
void orbitInterpolation(struct infoImage *info) ;

#endif
