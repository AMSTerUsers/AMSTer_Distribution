
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageS1.h
//  S1DataReader
//
//  Created by Dominique Derauw on 22/06/2020.
//  Copyright (c) 2020 Dominique Derauw. All rights reserved.
//

#ifndef SAOCOMDataReader_infoImageSAOCOM_h
#define SAOCOMDataReader_infoImageSAOCOM_h

#include <stdio.h>
#include "infoImage.h"
#include "geoRef.h"
#include "basicXMLHandlingLib.h"
#include "gridMapping.h"
#include "polynomials.h"
#include "fileAccessLib.h"

/* Create infoImage for SAOCOM data */
struct infoImage *allocAndInitSLCImageInfoFromSAOCOMxemtFile(char *xmltAccesPath) ;
double getTimeValInSecFromSAOCOMDateFormat(char* aDateChar) ;
struct stateVect *readAndSelectSAOCOMStateVectors(xmlDocPtr XEMTDoc, struct infoImage *info) ;



#endif
