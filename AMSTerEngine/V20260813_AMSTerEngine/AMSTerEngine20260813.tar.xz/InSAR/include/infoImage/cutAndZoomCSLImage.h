
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  cutAndZoomCSLImage.h
//  cutAndZoomCSLImage
//
//  Created by Dominique Derauw on 26/11/15.
//  Copyright (c) 2015 Dominique Derauw. All rights reserved.
//

#ifndef cutAndZoomCSLImage_cutAndZoomCSLImage_h
#define cutAndZoomCSLImage_cutAndZoomCSLImage_h

#include <stdio.h>
#include <math.h>
#include "pourtous.h"
#include "complexTypes.h"
#include "complexCalculus.h"
#include "fft.h"
#include "interpolCZT.h"
#include "vectors.h"
#include "rawFileLib.h"
#include "paramLib.h"
#include "counters.h"
#include "CSLImageFormat.h"
#include "infoImage.h"
#include "geoRef.h"
#include "satRef.h"
#include "stringLib.h"
#include "file2fileInterpolation.h"
#include "aoiHandling.h"
#include "slantRangeDEMLib.h"
#include "initInSARParams.h"

int cutAndZoomMain(CSVStruct *csv_CL) ;
void cutAndZoomUsage(void)  ;
void createCutAndZoomParameterFileAtPath(char *) ;
void extractAoI(rawFileDescriptor *input, rawFileDescriptor *output) ;


#endif
