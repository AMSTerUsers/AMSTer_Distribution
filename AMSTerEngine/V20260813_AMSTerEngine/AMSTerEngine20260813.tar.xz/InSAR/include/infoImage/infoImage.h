
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  infoImage.h
 *  lecheader
 *
 *  Created by Dominique Derauw on Mon Feb 18 2002.
 *  Copyright (c) 2001 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(INFO_IMAGE)
#define INFO_IMAGE

#include "pourtous.h"
#include "vectors.h"
#include "ellipsoid.h"
#include "fileAccessLib.h"
#include "paramLib.h"
#include "planeGeometry.h"
#include "SARPlatformID.h"
#include "stateVect.h"
#include "aoiHandling.h"

#define RIGHT_LOOKING 1
#define LEFT_LOOKING -1
#define MAX_POL_ORDER_FOR_ORBIT_INTERPOL 4
#define NUMBER_OF_STATE_VECTORS 5

#define _AOI_SRA_COORDINATE_SYSTEM_ 0x00000001
#define _AOI_GEO_COORDINATE_SYSTEM_DEG_ 0x00000002
#define _AOI_GEO_COORDINATE_SYSTEM_RAD_ 0x00000004


/* State vector structure definition */
struct stateVect {
    double	*P ;
    double	*V ;
    double	t ;
	double azimuthPosition ;
    double satDistance ;
    double velocity ;
} ;


/* InfoImage structure definition */
struct infoImage {
    char	productID[_MAX_COMMENT_LENGTH_] ;
    char	scene_id[_MAX_COMMENT_LENGTH_] ;
    char	scene_loc[_MAX_COMMENT_LENGTH_] ;
    char	platformName[_MAX_COMMENT_LENGTH_] ;
    char	polMode[_MAX_COMMENT_LENGTH_] ;
    CSVStruct *polScheme ;
    char    sensorID ;
    char    *productionTime ;
    char    *acquisitionDate ;
    char    *orbitTypeID ;
    char    *suffix ;
    char    *CSLImagePath ;
    time_t  acquisitionTime ;
    struct tm *acquisitionTime_tm ;
    char    *heading ;
    double  headingVal ;
    int unsigned flag ;
    int unsigned numberOfLayers ;                /* number of layers is a priori the number of polarization modes */
    int		numberOfSubswaths ;
    int		swathIndex ;                    /* When dealing with TOPSAR subswath images */
    int		beamNumber ;                    /* Beam number as identified by some agencies */
    int     relativeOrbitNumber ;
    int     relativeFrameNumber ;
    int		rangeDimension ;
    int		azimuthDimension ;
    int		nVect ;
    double  lookDirection ;                 /* look direction is 1 for right looking and -1 for left looking */
    double	radarCarrierFrequency ;
    double  wavelength ;
	double	rangeSamplingFrequency ;
    double  rangeApodizationCoefficient ;
    double	rangeResolutionCell ;
    double	azimuthResolutionCell ;
    double	prf ;
    double  lineTimeInterval ;
    double  rangeBandwidth ; ;
    double	azimuthBandwidth ;
    double	*fdc ;			/* Terme constant, linéaire et quadratique du Doppler Centroïde en fonction du range en Hz, Hz/sec et Hz/sec^2 */
    double  *dcFrequencyRate ;
    double	*twoWayRangeTime ;  /* Two-way range times for first, mid and last range pixel */
    double	*slantRange ;       /* Corresponding monostatic slant range */
    double	*incidenceAngle ;
    double	FPAT ;			/* First Pixel Azimuth Time */
    double	LPAT ;			/* Last Pixel Azimuth Time */
    double	FVT ;			/* First Vector Time */
    double	Dt ;			/* State Vector Time Gap */
    struct stateVect	*S ;
	int		polynomialOrder ;
	char	isOrbitInterpolationDone ;
    double	*aX ;			/* Coefficients des polynomes		*/
    double	*aY ;			/* d'ordre polynomialOrder			*/
    double	*aZ ;			/* approximant la trajectoire		*/
    double	*aVx ;			/* et la vitesse			*/
    double	*aVy ;			/* du satellite				*/
    double	*aVz ;			/*					*/
    ellipsoid	*ellRef ;
    double	referenceRange ;
    double  sceneAverageHeight ;
	double	EarthRadiusAtSceneCenter ;
	double	*EarthRadiusPolynomial ;		/* A second order polynomial approximating the Earth radius with respect to azimuth - range position */
	quadrilateral *loc, *locUTM, *aoi ;
    char    UTMZone[4] ;
    void    *sensorSpecificInfo ;
    double  *pitch, *pitchRate ;
    double  *roll, *rollRate ;
    double  *yaw, *yawRate ;
    double *ETADPhaseDelays ;
    keyValue *parameterList ;
    struct infoImage *masterInfo ;
    struct infoImage *superMasterInfo ;
} ;

typedef struct infoImage SLCImageInfo ;

struct infoImage 	*readInfoImageFromTextFile(char *filePath) ;
void saveInfoImage(struct infoImage * , char *filePath) ;
char *saveInfoKmlInDir(SLCImageInfo *info, char *destDir) ;
struct infoImage *allocInfoImage(void) ;
void freeInfoImage(struct infoImage *) ;
void freeOrbitInterpolation(struct infoImage *info) ;
char *convertUTCStartTimeIntoAcquisitionDate(char *UTCStartTime) ;
void genAcquisitionTimeFromDate(SLCImageInfo *info) ;
void sortPolarizations(SLCImageInfo *info) ;

#endif
