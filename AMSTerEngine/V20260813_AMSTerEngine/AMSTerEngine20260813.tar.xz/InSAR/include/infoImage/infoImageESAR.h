
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageESAR.h
//  ESARDataReader
//
//  Created by Dominique Derauw on 26/02/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#ifndef ESARDataReader_infoImageESAR_h
#define ESARDataReader_infoImageESAR_h

#include "infoImage.h"
#include "byteSwap.h"
#include "interpStateVect.h"
#include "geoRef.h"

#define ESARMLGEOMETRY

/* ESAR rectified state vectro structure */
typedef struct {
    double xRectified, yRectified, zRectified ;
    double xReal, yReal, zReal ;
} ESARSLCStateVect ;

/* ESAR Multilook Geometry state vector structure */
typedef struct {
    double x, y, z ;
    double vX, vY, vZ ;
    double aX, aY, aZ ;
    double timeStamp ;
} ESARMLStateVect ;


SLCImageInfo *createSLCInfoImageForESARData(keyValue *readerParams) ;
keyValue *readESARHeaderAtPath(char *aPath) ;


#endif
