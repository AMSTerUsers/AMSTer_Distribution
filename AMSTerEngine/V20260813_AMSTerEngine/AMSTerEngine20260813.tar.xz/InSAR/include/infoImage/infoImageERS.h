
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  infoImageCEOS.h
 *  
 *
 *  Created by Dominique Derauw on Mon Sep 22 2003.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(INFO_IMAGE_CEOS)
#define INFO_IMAGE_CEOS

#include "pourtous.h"
#include "CEOSUtils.h"
#include "infoImage.h"
#include "readASCII_Val.h"
#include "geoRef.h"
#include "planeGeometry.h"

struct infoImage 	*readInfoImageFromCEOSHeader(struct CEOS_VDF *, struct CEOS_LF *, struct CEOS_IMOF *) ;

#endif
