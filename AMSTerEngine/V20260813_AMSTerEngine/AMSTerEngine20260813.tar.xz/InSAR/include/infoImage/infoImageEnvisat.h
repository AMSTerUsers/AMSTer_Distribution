
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  infoImage.h
 *  lecheader
 *
 *  Created by Dominique Derauw on Mon Feb 18 2002.
 *  Copyright (c) 2001 Dominique Derauw. All rights reserved.
 *
 */
 
#if !defined(INFO_IMAGE_ENVISAT)
#define INFO_IMAGE_ENVISAT

#include "pourtous.h"
#include "infoImage.h"
#include "envisat.h"
#include "byteSwap.h"
#include "geoRef.h"
#include "planeGeometry.h"
#include "stringLib.h"
#include "readASCII_Val.h"

struct infoImage 	*readInfoImageFromEnvisatHeader(ENVISAT_HEADER *) ;

ENVISAT_HEADER		*readEnvisatHeader(char *filePath) ;
void readMapProjectionRecord(ENVISAT_HEADER *header, FILE *f1) ;
void readGeolocationGrid(ENVISAT_HEADER *header, FILE *f1) ;
void readAntennaPatternRecord(ENVISAT_HEADER *header, FILE *f1) ;
ANTENNA_ELEVATION_HEADER *readAntennaElevationPatternForDSD(int indiceDSD, ENVISAT_HEADER *header, FILE *f1) ;
void readChirpParametersRecord(ENVISAT_HEADER *header, FILE *f1) ;
void readSlantToGroundRangeConversionGrid(ENVISAT_HEADER *header, FILE *f1) ;
void readDopplerCentroidParametersRecord(ENVISAT_HEADER *header, FILE *f1) ;
void readMainProcessParametersRecord(ENVISAT_HEADER *header, FILE *f1) ;
void readSummaryQualityRecord(ENVISAT_HEADER *header, FILE *f1) ;
void readSpecificProductHeader(ENVISAT_HEADER *header, FILE *f1) ;
void readMainProductHeader(ENVISAT_HEADER *header, FILE *f1) ;
ENVISAT_HEADER *allocEnvisatHeader(void) ;
int getIndexOfDSD(char *DSDName, ENVISAT_HEADER *header) ;
void seekFileForDSD(FILE *f1, ENVISAT_HEADER *header, int indiceDSD, int indexOfRecord) ;
int getNumberOfRecordsForDSD(char *DSDName, ENVISAT_HEADER *header) ;
char isAP(ENVISAT_HEADER *header) ;
char isSLC(ENVISAT_HEADER *header) ;
char isPRI(ENVISAT_HEADER *header) ;
char isGeocoded(ENVISAT_HEADER *header) ;

/* ROI_PAC EnviSAT data reader */
SLCImageInfo *createInfoImageFromROI_PAC_RSCFile(char *ROI_PACDirectoryPath) ;
keyValue *convertRSCFileToKeyValueList(char *aPath) ;

#endif