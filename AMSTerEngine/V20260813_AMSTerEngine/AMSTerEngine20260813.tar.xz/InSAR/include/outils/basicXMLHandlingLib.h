
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  basicXMLHandlingLib.h
//  TSXDataReader
//
//  Created by Dominique Derauw on 7/01/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#ifndef TSXDataReader_basicXMLHandlingLib_h
#define TSXDataReader_basicXMLHandlingLib_h

#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/tree.h>
#include <libxml/xmlreader.h>
#include "pourtous.h"
#include "stringLib.h"

CSVStruct *readCSVInXMLFileForXPath(xmlChar *xPath, xmlDocPtr XMLdoc) ;
CSVStruct *readCSVInXMLFileForXPathOccurenceN(xmlChar *xPath, xmlDocPtr XMLdoc, int occurence) ;
CSVStruct *addCSVFromXMLFileForXPath(xmlChar *xPath, xmlDocPtr XMLdoc, CSVStruct *aCSV) ;
CSVStruct *getAttributeInXMLDocForXPath(xmlChar *xPath, xmlDocPtr XMLdoc) ;
char *getXMLAttributeFromXMLPath(xmlChar *xPath) ;
int getNumberOfPropsForNode(xmlNodePtr aNode) ;
char **getPropsNameOfNode(xmlNodePtr aNode) ;
char **getPropsOfNode(xmlNodePtr aNode) ;
xmlDocPtr getdoc (char *docname) ;
xmlXPathObjectPtr getnodeset (xmlDocPtr doc, xmlChar *xpath) ;

void listChildNodes(xmlNodePtr cur, char *tabs) ;
CSVStruct *findContentInXMLFromNode(xmlNodePtr cur, char *searchedNodes, char *propertyName, char *property, CSVStruct *csvIn) ;


#endif
