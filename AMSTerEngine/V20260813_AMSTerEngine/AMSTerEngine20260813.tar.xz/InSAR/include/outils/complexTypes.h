
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  DefTypesComplex.h
 *  
 *
 *  Created by Dominique Derauw on Mon Dec 03 2001.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(DEF_TYPES_COMPLEX)
#define DEF_TYPES_COMPLEX

typedef struct {
        char r, i ;
    } complexChar ;		/* !!! In more than 2 bytes alignement computer environement this structure will probably have a size of 4 bytes */

typedef struct {
        short r, i ;
    } complexShort ;

typedef struct {
        int r, i ;
    } complexInt ;

typedef struct {
        long r, i ;
    } complexLong ;

typedef struct {
        float r, i ;
    } complexFloat ;
    
typedef struct {
        double r, i ;
    } complexDouble ;

#define COMPLEX_CHAR_SIZE sizeof(complexChar)
#define COMPLEX_SHORT_SIZE sizeof(complexShort)
#define COMPLEX_INT_SIZE sizeof(complexInt)
#define COMPLEX_LONG_SIZE sizeof(complexLong)
#define COMPLEX_FLOAT_SIZE sizeof(complexFloat)
#define COMPLEX_DOUBLE_SIZE sizeof(complexDouble)

#endif
