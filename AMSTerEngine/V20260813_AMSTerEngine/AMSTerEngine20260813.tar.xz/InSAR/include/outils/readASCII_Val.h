
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  readASCII_Val.h
 *  lecheader
 *
 *  Created by Dominique Derauw on Wed Feb 20 2002.
 *  Copyright (c) 2002 Dominique Derauw All rights reserved.
 *
 */

#if !defined(READ_ASCII_VAL)
#define READ_ASCII_VAL

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/errno.h>

#include "stringLib.h"

#define NO_VALUE_READ -1 ;

int	readIntInASCIIStringOfLength(char *stringToRead, int numberOfCharInString) ;
long readLongInASCIIStringOfLength(char *stringToRead, int numberOfCharInString) ;
float readFloatInASCIIStringOfLength(char *stringToRead, int numberOfCharInString) ;
double readDoubleInASCIIStringOfLength(char *stringToRead, int numberOfCharInString) ;

#endif


