
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  arithmetiqueComplexe.h
 *  decPol
 *
 *  Created by Dominique Derauw on Wed Sep 25 2002.
 *  Copyright (c) 2002 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(ARITCOMP)
#define ARITCOMP

#include <math.h>
#include "complexTypes.h"

#if !defined(HALFPI)
#define HALFPI		M_PI_2 
#endif
#if !defined(PI)
#define	PI			M_PI 
#endif

complexFloat 	mRC(complexFloat a, float b) ;		/* Complex by real multiplication */
complexDouble 	mRComplexDouble(complexDouble a, double b) ;
complexFloat 	mC(complexFloat a, complexFloat b) ;	/* Complex by complex multiplication */
complexDouble 	multComplexDouble(complexDouble a, complexDouble b) ;
complexFloat 	aC(complexFloat a, complexFloat b) ;	/* Complex addition */
complexDouble sumComplexDouble(complexDouble a, complexDouble b) ;
complexFloat 	sC(complexFloat a, complexFloat b) ;	/* Complex substraction */
complexDouble	subtComplexDouble(complexDouble a, complexDouble b) ;
complexFloat 	cC(complexFloat a) ;					/* Complex conjugate */
complexDouble	cCComplexDouble(complexDouble a) ;
float			modC(complexFloat a) ;				/* modulus */
double modComplexDouble(complexDouble a) ;
float			sqmC(complexFloat a) ;				/* square modulus */
double sqmComplexDouble(complexDouble a) ;
float			phiC(complexFloat a) ;				/* Complex phase */
complexFloat divC(complexFloat a, complexFloat b)  ;	/* Complex division */
complexDouble divComplexDouble(complexDouble a, complexDouble b) ;

#endif
