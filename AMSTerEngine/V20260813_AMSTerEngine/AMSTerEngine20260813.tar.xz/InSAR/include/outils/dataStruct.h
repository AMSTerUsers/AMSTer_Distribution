
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  dataStruct.h
//  spectralCoh
//
//  Created by Dominique Derauw on 15/07/16.
//  Copyright (c) 2016 Dominique Derauw. All rights reserved.
//

#ifndef __spectralCoh__dataStruct__
#define __spectralCoh__dataStruct__

#include <stdio.h>
#include "rawFileLib.h"
#include "complexTypes.h"

#define _DATA_STRUCT_MAX_BLOC_SIZE_ 1024 * 1024 * 128 /* Will read and work on max 128Mb of data at a time */

/* Data type set to sizeof type */
#define _FLOAT_TYPE_ sizeof(float)
#define _COMPLEXFLOAT_TYPE_ sizeof(complexFloat)


typedef struct {
    char *path ;
    int rangeDim ;
    int azimuthDim ;
    int	numberOfBlocs ;					/* Data will be read by blocs if exceeding 16MB */
    int numberOfLinesPerBloc ;
    int currentBlocIndex ;				/* Index runing from 0 up to numberOfBloc - 1 */
    int firstLineIndex ;				/* firstLineIndex is the azimuth index of the first line of the current bloc */
    int currentLineIndex ;				/* currentLineIndex is the azimuth index of current line */
    size_t dataType ;
    void *data ;
    void **indexedData ;
    rawFileDescriptor *file ;
} dataStruct ;

dataStruct *allocDataStruct(void) ;
void initDataStructOfTypeWithSizes(dataStruct *dataDescriptor, size_t type, int xDim, int yDim) ;
void allocAndInitDataStructForRawFile(rawFileDescriptor *aFile) ;

void allocAndInitMemoryForDataStruct(dataStruct *anImage) ;
void freeMermoryForDataStruct(dataStruct *anImage) ;


#endif /* defined(__spectralCoh__dataStruct__) */
