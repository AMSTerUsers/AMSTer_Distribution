
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  rawFileManipulation.h
//  geoProjection
//
//  Created by Dominique Derauw on 16/03/17.
//
//

#ifndef rawFileManipulation_h
#define rawFileManipulation_h

#define _IN_PLACE_ 1

#if !defined(_BUFFER_SIZE_)
#define _BUFFER_SIZE_ (int)(1024 * 1024)
#endif


#include <stdio.h>
#include "rawFileLib.h"
#include "vectors.h"
#include "tileToolLib.h"

void verticalFlipOfDataOfTypeAtPath(char *aPath, int xDim, int yDim, char inPlace) ;
void floatFilesArithmetics(char *filePath1, char *arithmeticOperator, float operand, char *filePath2, char* outputPath) ;
void rawFilesArithmetics(float A, char *filePath1, char *arithmeticOperator, float B, char *filePath2, char *outputPath, int typeID) ;
void wrapFloatFile(char *filePath1, char *outputPath) ;
void maskFloatFileIfLowerThanThreshold(char *filePath1, char *maskFilePath, char *outputPath, float threshold) ;
void maskFloatFileWithValue(char *filePath1, char *maskFilePath, char *outputPath, float floatVal, char unsigned maskSelector) ;
char *maskThresholdingByFile(char *maskFilePath, char *coherenceFilePath, float threshold, size_t thresholdAll) ;
void invertBinaryMask(char *filePath1, char *outputPath) ;
void cropRawFile(rawFileDescriptor *aFile) ;


#endif /* rawFileManipulation_h */
