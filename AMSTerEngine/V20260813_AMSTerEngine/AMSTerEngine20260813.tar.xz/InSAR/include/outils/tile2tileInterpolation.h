
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  tile2tileInterpolation.h
//  detPhUn
//
//  Created by Dominique Derauw on 14/11/2017.
//  Copyright © 2017 Dominique Derauw. All rights reserved.
//

#ifndef tile2tileInterpolation_h
#define tile2tileInterpolation_h

#include <stdio.h>
#include "tileToolLib.h"
#include "file2fileInterpolation.h"

void    tile2TileInterpolComplexAlongXAxis(tileTool *inputTile, double **T, tileTool *outputTile, char withMirroring) ;
void    tile2TileInterpolComplexAlongYAxis(tileTool *inputTile, double **T, tileTool *outputTile, char withMirroring) ;


#endif /* tile2tileInterpolation_h */
