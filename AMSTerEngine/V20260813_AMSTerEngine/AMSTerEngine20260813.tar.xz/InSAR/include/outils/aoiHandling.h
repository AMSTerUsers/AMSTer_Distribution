
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  kmlHandling.h
//  S1DataReader
//
//  Created by Dominique Derauw on 17/10/2017.
//  Copyright © 2017 Dominique Derauw. All rights reserved.
//

#ifndef aoiHandling_h
#define aoiHandling_h

#include <stdio.h>
#include "basicXMLHandlingLib.h"
#include "paramLib.h"
#include "planeGeometry.h"

polygon *getRectangularAoIFromKMLFile(char *kmlFilePath) ;
polygon *getPolygonalAoIFromKMLFile(char *kmlFilePath) ;
void convertAoIFromDeg2Rad(polygon *aoi) ;
void genKMLForPolygonAtPath(polygon *aPolygon, char *aPath) ;

#endif /* aoiHandling_h */
