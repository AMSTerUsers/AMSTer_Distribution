
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  grid.h
 *  SLC2PRI
 *
 *  Created by Dominique Derauw on Mon Oct 13 2003.
 *  Copyright (c) 2003 Dominique Derauw All rights reserved.
 *
 */

#if !defined(GRIDMAPPING)
#define GRIDMAPPING

#include "pourtous.h"
#include "matrix.h"
#include "vectors.h"
#include "planeGeometry.h"

typedef struct {
    int		Nx, Ny ;                        /* Mesh knots number */
    int		dimGridX, dimGridY ;            /* Underlying data size */
    int		dNx, dNy ;                      /* Mesh size with respect to underlaying data sampling */
    int		x0, y0 ;                        /* Mesh origin with respect to underlying data */
    size_t  typeSize ;
    char    **charVal, charOutput ;
    float   **floatVal, floatOutput ;
    double	**val, outVal, noVal ;
    double  **T ;                           /* Associated affine transform */
    void    **M ;                           /* Mesh data */
} gridMap ;

/* The transform allows to take into account for an additionnal transfrom of the data constituting the grid */
/* espacially usefull in the case of using an external DEM that is not perfectly registered toi a reference image */

gridMap *allocGridStructure(void) ;
void freeGridMap(gridMap *aGridMap) ;
gridMap *createGrid(int dimGridX, int dimGridY, int Nx, int Ny) ;
gridMap *createGridWithXSpacing(int dimGridX, int dimGridY, int dNx, int Ny) ;
gridMap *createGridWithYSpacing(int dimGridX, int dimGridY, int Nx, int dNy) ;
gridMap *createGridWithXYSpacing(int dimGridX, int dimGridY, int dNx, int dNy) ;
gridMap *createFloatGridOfSize(int Nx, int Ny, int dNx, int dNy) ;
gridMap *createGridOfSize(int Nx, int Ny, int dNx, int dNy, size_t typeSize) ;
coord2D	imageCoordinateForGridPoint(gridMap *grid, int xGrid, int yGrid) ;
coord2D gridCoordinateForImagePoint(gridMap *grid, int xImage, int yImage) ;
coord2D	imageCoordinateForGridCoordinate(gridMap *grid, coord2D gridCoordinate) ;
coord2D gridCoordinateForImageCoordinate(gridMap *grid, coord2D imageCoordinate) ;
double	interpolGridForImagePosition(gridMap *, int xImage, int yImage) ;
double	interpolGridForImageCoordinate(gridMap *grid, double xImage, double yImage) ;
double	interpolFloatGridForImageCoordinate(gridMap *grid, double xImage, double yImage) ;
double weightedExtrapolationOfGridForImageCoordinate(gridMap *grid, double xImage, double yImage) ;
float nearestNeighbourInterpolationOfGridForImageCoordinate(gridMap *grid, double xImage, double yImage) ;
float weightedExtrapolationOfPhaseGridForImageCoordinate(gridMap *grid, double xImage, double yImage) ;

#endif
