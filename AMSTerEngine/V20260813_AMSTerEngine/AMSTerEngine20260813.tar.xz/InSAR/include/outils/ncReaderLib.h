
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  ncReaderLib.h
//  S1DataReader
//
//  Created by Dominique Derauw on 09/04/2025.
//  Copyright © SAREOS - Dominique Derauw. All rights reserved.
//

#ifndef ncReaderLib_h
#define ncReaderLib_h

#include "pourtous.h"
#include "paramLib.h"
#include "rawFileLib.h"
#include "vectors.h"
#include "matrixObjects.h"

#include "netcdf.h"


struct ncAttribute {
    char *attributeName ;
    char *dataTypeName ;
    int groupID ;
    nc_type ncDataTypeID ;
    size_t dataLength ;
    size_t dataTypeID ;
    void *data ;
    struct ncAttribute *nextOne ;
} ;
typedef struct ncAttribute ncAtb ;

struct ncDim {
    char **dimName ;
    int groupID ;
    int nDims ;
    int *dimID ;
    size_t *dimVal ;
} ;
typedef struct ncDim grpDim ;

struct ncVarDescription
{
    int groupID ;
    int nVars, *nDims, *nAtt ;
    int **dimID ;
    int *varID ;
    CSVStruct *varName ;
    nc_type *varType ;
    ncAtb **varAtt ;

} ;
typedef struct ncVarDescription ncVar ;

struct ncGroup {
    int groupID ;
    int numberOfSubGroups ;
    int *subGroupId ;
    char *groupName ;
    struct ncGroup *parentGroup ;
    struct ncGroup **subGroup ;
    grpDim *dims ;
    ncAtb *gpAtt ;
    ncVar *ncVars ;
} ;
typedef struct ncGroup groupStruct ;


void ncStatusCheck(int status) ;
groupStruct *ncGetSubGroupsForGroup(groupStruct *thisGroup, int groupID) ;
CSVStruct *listGroupStruct(groupStruct *aGroup, CSVStruct *aCSV) ;
void freeGroupStruct(groupStruct *aGroup) ;
void freeSubGroupsOfGroup(groupStruct *aGroup) ;
groupStruct *getSubGroupForPath(groupStruct *rootGroup, char *aPath) ;
int getGroupIdForPath(groupStruct *rootGroup, char *aPath) ;
void **ncGetCubeSliceAtPath(int ncID, char *aPath, int sliceIndex, char *dimName) ;
ncAtb *alloc_ncAttribute(void) ;
ncAtb *allocAtbList(int unsigned N) ;
void free_ncAttribute(ncAtb *anAttribute) ;
ncAtb *ncGetGroupAtts(int groupID, int attributeID) ;
grpDim *allocGroupDims(void) ;
void freeGroupDims(grpDim *aGroupDim) ;
grpDim *ncGetGroupDims(int groupID) ;
ncVar *allocVarDesc(void) ;
void freeVarDesc(ncVar *aVarDesc) ;
ncVar *ncGetGroupVarsDescription(int groupID) ;
keyValue *getVarAttOfGroup(int groupID, char * variableName) ;
void ncReadAndSaveGroupVariableAtPath(int groupID, char *variableName, char *destinationDir) ;
void ncReadAndSaveGroupVars(char *ncFilePath, char *groupPath, char *destinationDir) ;
keyValue *getGroupAtts(ncAtb *thisAttribute) ;


#endif /* ncReaderLib_h */
