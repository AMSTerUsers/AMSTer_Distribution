
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  planeGeometry.h
 *  initInSAR
 *
 *  Created by Dominique Derauw on 1/11/11.
 *  Copyright 2011 Dominique Derauw All rights reserved.
 *
 */

#if !defined(PLANEGEOMETRY)
#define PLANEGEOMETRY

/* call to librairies */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "pourtous.h"
#include "matrix.h"


typedef struct {
    int	k ;
    int	l ;
} intPoint2D ;

#ifndef COORD2D
#define COORD2D
typedef struct {
    double	x ;
    double	y ;
} coord2D ;
#endif

#if !defined(RECTANGLE)
#define RECTANGLE
typedef struct {
	double xMin ;
	double yMin ;
	double xMax ;
	double yMax ;
	double dimX ;
	double dimY ;
} rectangleType ;
#endif


typedef struct {
	int N ;
	coord2D *P ;
	double **V ;
} polygon ;

typedef polygon segment ;
typedef polygon triangle ;
typedef polygon quadrilateral ;


polygon *allocPolygon(int numberOfAngles) ;
polygon *getCopyOfPolygon(polygon *aPolygon) ;
coord2D *allocPoint(void) ;
segment *allocSegment(void) ;
triangle *allocTriangle(void) ;
quadrilateral *allocQuadrilateral(void) ;
void freePolygon(polygon *aPolygone) ;
void planeAffineTransformOfPoint(double *initialPoint, double *transformedPoint, double **usedPlaneAffineTransform) ;
coord2D  *planeAffineTransformOfCoord2D(coord2D *initialPoint, coord2D *transformedPoint, double **usedAffineTransform) ;
double **inversePlaneAffineTransform(double **initialTransform, double **inverseTransform) ;
polygon *planeAffineTransformOfPolygon(polygon *initialPolygon, polygon *transformedPolygon, double **usedAffineTransform) ;
polygon *circumscribedRectangleOfPolygon(polygon *aPolygone) ;
double **allocUnitaryAffineTransform(void) ;
double **getCopyOfAffineTransform(double **T) ;
char isAffineTransformUnitary(double **T) ;
char isAffineTransformNULL(double **T) ;
char isPointIncludedInPolygon(coord2D *aPoint, polygon *aPolygon) ;
char polygonesIntersects(polygon *polygon1, polygon *polygon2) ;
coord2D *segmentIntersect(segment *seg1, segment *seg2) ;
double **combinedAffineTransform(double **T2, double **T1) ;
coord2D *getCentreOfPolygon(polygon *aoi) ;
double EuclidianDistanceBetween2DPoints(coord2D *p1, coord2D *p2) ;


#endif

