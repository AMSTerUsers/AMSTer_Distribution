
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  ENVIHeaderManagement.h
//  slantRangeDEM
//
//  Created by Dominique Derauw on 24/04/2017.
//  Copyright © 2017 Dominique Derauw. All rights reserved.
//

#ifndef ENVIHeaderManagement_h
#define ENVIHeaderManagement_h

#include <stdio.h>
#include "paramLib.h"
#include "rawFileLib.h"


keyValue *readENVIHeader(char *HDRPath) ;
void writeENVIHeaderAtPath(char *headerPath, keyValue *ENVIHeader) ;
char *getENVIHeaderPathOfFile(char *inputPath) ;
char *getENVIFileCorrespondingToHeader(char *aPath) ;
void generateENVIHeaderForRawFile(rawFileDescriptor *inputFile, char makeLink) ;
void generateENVIHeaderForFile(char *aPath, int xDim, int yDim, char makeLink) ;

#endif /* ENVIHeaderManagement_h */
