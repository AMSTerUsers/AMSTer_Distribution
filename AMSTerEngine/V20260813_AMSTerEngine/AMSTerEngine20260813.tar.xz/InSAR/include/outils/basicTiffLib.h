/* 
*  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version. 
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 * 
 *  You should have received a copy of the GNU Affero General Public License 
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**************************************************
 * File name : basicTiffLib.h
 * Author : Dominique Derauw
 * Date : 2026-08-14
 * Copyright 2026 Dominique Derauw
 * Description : 
 **************************************************/



#if !defined(__basicTiffLib__)
#define __basicTiffLib__

#include <stdio.h>
#include <stdlib.h>
#include <tiffio.h>

#include "pourtous.h"
#include "stringLib.h"
#include "fileAccessLib.h"
#include "rawFileLib.h"
#include "byteSwap.h"

typedef struct _tiffHeader {
    short tiffID ;
    short tiffVersion ;
    int ifdOffset ;
} tiffHeader ;

typedef union _tagData {
    char charData[4] ;
    int intData ;
    float floatData ;
} tagData ;

typedef struct _tiffTag {
    short unsigned tagID ;
    short unsigned dataType ;
    int unsigned dataCount ;
    int unsigned offset ;
} tiffTag ;

typedef struct _tiffIFD {
    short nTags ;
    tiffTag *tag ;
    short offset ;
    struct _tiffIFD *nextOne ;
} tiffIFD ;

typedef struct _tiffFileDescriptor {
    int nIFD ;
    tiffHeader *header ;
    tiffIFD *ifd ;
    tiffIFD **ifdVect ;
    rawFileDescriptor *tiffFile ;
} tiffFileDescriptor ;


short readShortInTiffFile(rawFileDescriptor *thisFile, long offset) ;
int readIntInTiffFile(rawFileDescriptor *thisFile, long offset) ;
tiffTag readTagInTiffFile(rawFileDescriptor *thisFile, long offset) ;
tiffIFD *readIFDInTiffFile(rawFileDescriptor *thisFile, long offset) ;
tiffFileDescriptor *parseTiffFileAtPath(char *aPath) ;
void freeTiffFileDescripto(tiffFileDescriptor *desc) ;

#endif