
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  byteSwap.h
 *  ersRAWReader
 *
 *  Created by Dominique Derauw on 6/09/06.
 *  Copyright 2006 Dominique Derauw All rights reserved.
 *
 */

/* byte swapping tools for low-endian based processors */

#if !defined(BYTE_SWAPING_HEADER)
#define BYTE_SWAPING_HEADER

#include <string.h>
#include "complexTypes.h"

typedef struct {
	unsigned char	b1 ;
	unsigned char	b0 ;
} LEShort ;

typedef struct {
	unsigned char	b0 ;
	unsigned char	b1 ;
} BEShort ;

typedef struct {
	unsigned char	b3 ;
	unsigned char	b2 ;
	unsigned char	b1 ;
	unsigned char	b0 ;
} LEInt ;

typedef struct {
	unsigned char	b0 ;
	unsigned char	b1 ;
	unsigned char	b2 ;
	unsigned char	b3 ;
} BEInt ;

typedef BEInt BELong ;
typedef LEInt LELong ;
typedef BEInt BEFloat ;
typedef LEInt LEFloat ;

typedef struct {
	unsigned char	b7 ;
	unsigned char	b6 ;
	unsigned char	b5 ;
	unsigned char	b4 ;
	unsigned char	b3 ;
	unsigned char	b2 ;
	unsigned char	b1 ;
	unsigned char	b0 ;
} LELongLong ;

typedef struct {
	unsigned char	b0 ;
	unsigned char	b1 ;
	unsigned char	b2 ;
	unsigned char	b3 ;
	unsigned char	b4 ;
	unsigned char	b5 ;
	unsigned char	b6 ;
	unsigned char	b7 ;
} BELongLong ;

typedef BEShort BE2BytesStruct ;
typedef LEShort LE2BytesStruct ;
typedef BEInt BE4BytesStruct ;
typedef LEInt LE4BytesStruct ;
typedef BELongLong BE8BytesStruct ;
typedef LELongLong LE8BytesStruct ;
typedef BELongLong BEDouble ;
typedef LELongLong LEDouble ;

void swapByteStructOfType(void *aByteStruct, size_t byteSize) ;
void swap2bytesStruct(void *a2bytesStruct) ;
void swap4bytesStruct(void *a4bytesStruct) ;
void swap8bytesStruct(void *a8bytesStruct) ;
void swapShort(short *aShort) ;
void swapInt(int *anInt) ;
void swapFloat(float *aFloat) ;
void swapDouble(double *aDouble) ;
void swapLongLong(long long *aLong) ;
void swapComplexShort(complexShort *aComplexShort) ;
void swapComplexFloat(complexFloat *aComplexFloat) ;

#endif
