
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  movingAverageTool.h
 *  decPol
 *
 *  Created by Dominique Derauw on 11/03/05.
 *  Copyright 2005 __MyCompanyName__. All rights reserved.
 *
 */

#include "pourtous.h"
#include "complexTypes.h"
#include "complexCalculus.h"
#include "matrix.h"
#include "vectors.h"

#if !defined(MOVINGAVERAGE)
#define MOVINGAVERAGE

typedef struct {
	char	stringType[15] ;
	int		type ;
	int		norme ;
	long	sizeOfType ;
	frameType	averagingWindow ;
	frameType	inputRect ;
	frameType	outputRect ;
	void	*average ;
	void	*movingWindow ;
}mAvObject ;

mAvObject *allocMovingAverageObject(void) ;
void initMovingAverageObject(char *stringType, int averagingWindowXSize, int averagingWindowYSize, int inputImageXSize, int inputImageYSize, mAvObject *target) ;
void addNextLineInMovingAverage(void *source, mAvObject *target) ;
void *getMovingAverage(mAvObject *target) ;
void freeMovingAverageObject(mAvObject *target) ;


#endif
