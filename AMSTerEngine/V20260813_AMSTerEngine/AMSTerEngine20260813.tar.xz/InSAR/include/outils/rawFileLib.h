
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  rawFileLib.h
//  EnviSATDataReader
//
//  Created by Dominique Derauw on 30/06/16.
//
//

#ifndef __rawFileLib__
#define __rawFileLib__

//#include <stdio.h>
#include "stringLib.h"
#include "fileAccessLib.h"
#include "planeGeometry.h"
#include "matrix.h"

typedef struct {
    FILE	*f ;
    char	*accessPath ;
    char	*directoryPath ;
    char	*fileName ;
    char	*mode ;
    char    byteOrder ;         /* System byte order */
    char    fileByteOrder ;     /* File byte order */
    char    swapBytes ;
    char    *typeID ;
    size_t	fileLength ;
    size_t	xDim ;      /* Data X dimension */
    size_t	yDim ;      /* Data Y dimension */
    int unsigned flag ;
    int xLowerIndex ;           /* Data matrix lower column index */
    int yLowerIndex ;           /* Data matrix lower row index */
    double xSampling ;          /* X sampling in data units */
    double ySampling ;          /* Y sampling in data units */
    double x0 ;                 /* Lower left X coordinate in data units */
    double y0 ;                 /* Lower left Y coordinate in data units */
    void *excludingValue ;      /* pointer to an excluding value to be defined by handler */
    size_t typeSize ;           /* Data type in number of bytes */
    quadrilateral *aoi ;        /* Area of interest within raw file */
    void *data ;
    void **indexedData ;
} rawFileDescriptor ;

typedef rawFileDescriptor fileDescriptor ;

typedef struct {
    int unsigned numberOfFiles ;
    char	*location ;
    char    *genericName ;
    char    **extension ;
    int		dimX ;
    int		dimY ;
    frameType *aoi ;
    FILE **f ;
    rawFileDescriptor **file ;
} rawFileSet ;

rawFileDescriptor *allocFileDescriptor(void) ;
rawFileDescriptor *allocFileDescriptorForPath(char *aPath) ;
rawFileDescriptor *openRawFileForReading(rawFileDescriptor *aFileDescriptor) ;
rawFileDescriptor * openRawFileForWriting(rawFileDescriptor *aFileDescriptor) ;
rawFileDescriptor * openRawFileForReadingAndWriting(rawFileDescriptor *aFileDescriptor) ;
rawFileDescriptor *openRawFileForReadingAtPath(char *aPath) ;
rawFileDescriptor *openRawFileForWritingAtPath(char *aPath) ;
rawFileDescriptor *openRawFileForReadingAndWritingAtPath(char *aPath) ;
rawFileDescriptor *createRawFileForReadingAndWritingAtPath(char *aPath) ;
void setRawFilePath(rawFileDescriptor *aFileDescriptor, char *newFullPath) ;
void setRawFileDimensions(rawFileDescriptor *aFileDescriptor, int xDim, int yDim) ;
void setRawFileLowerIndexes(rawFileDescriptor *aFileDescriptor, int xLowerIndex, int yLowerIndex) ;
void setRawFileType(rawFileDescriptor *aFileDescriptor, size_t type) ;
void setRawFileOrigin(rawFileDescriptor *aFileDescriptor, int x0, int y0) ;
void setRawFileSampling(rawFileDescriptor *aFileDescriptor, int xSampling, int ySampling) ;
void setRawFileAoI(rawFileDescriptor *aFileDescriptor, quadrilateral *aoi) ;
void setRawFileAoIWithValues(rawFileDescriptor *aFileDescriptor, int xMin, int yMin, int xMax, int yMax) ;
void freeRawFileDescriptor(rawFileDescriptor *) ;
void closeRawFile(rawFileDescriptor *aFileDescriptor) ;


#endif /* defined(__EnviSATDataReader__rawFileLib__) */
