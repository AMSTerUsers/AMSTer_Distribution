
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  stringLib.h
 *  trackDataReader
 *
 *  Created by Dominique Derauw on 3/02/05.
 *  Copyright 2005 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(STRING_LIB)
#define STRING_LIB

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXSTRINGLENGTH 1024
#define SUBSTRINGTOOBIG  -4 
#define SUBSTRINGNOTFOUND  -5 
#define STRINGTOOSMALL -6 

struct CSVStruct {
	int numberOfEntries ;
	char **stringVal ;
} ;
typedef struct CSVStruct CSVStruct ;


char *allocStringOfLength(size_t) ;
char *readFirstStringIn(char *texte) ;
char *getStringUpToDelimiter(char *aString, char *delimiter) ;
char *getStringAfterDelimiter(char *aString, char *delimiter) ;
char *concatenateStrings(char *firstString, char *secondString) ;
char isWhiteChar(char *aChar) ;
void stripWhiteCharsAtStartOfString(char *aString) ;
void stripWhiteCharsInString(char *aString) ;
void stripWhiteCharsAtEndOfString(char *aString) ;
void stripTrailingZerosAtEndOfStringNumber(char *aString) ;
void replaceWhiteCharsInStringByChar(char *aString, char replacementChar) ;
char replaceSubStringInString(char *aString, char *subStringToFind, char *replacementString) ;
char replaceNSubStringInString(char *aString, char *subStringToFind, char *replacementString) ;
char *replaceSubStringsInString(char *aString, char *subStringToFind, char *replacementString) ;
char *escapeCharInString(char *aString, char *charToEscape) ;
void removeStringInString(char *aString, char *stringToRemove) ;
void removeAnyOccurrenceOfSubStringInString(char *aString, char *stringToRemove) ;
int isSubStringPresentInString(char *aString, char *subStringToFind) ;
char *getStringAfterSubStringInString(char *aString, char *aSubString) ;
int locateSubStringInString(char *aString, char *subStringToFind) ;
void convertStringToLowercase(char *aString) ;
void convertStringToUppercase(char *aString) ;
char *initStringWithString(char *aString) ;
char *initStringWithStringOfLength(char *aString, size_t stringLength) ;
char *initStringWith2Strings(char *string1, char *string2) ;
char *initStringWith3Strings(char *string1, char *string2, char *string3) ;
char *initStringWith4Strings(char *string1, char *string2, char *string3, char *string4) ;
void removeEmptyValsInCSV(CSVStruct *csv) ;
CSVStruct *readCSVInString(char *aString) ;
CSVStruct *readWhiteCharSeperatedValuesInString(char *aString) ;
CSVStruct *addIntValInCSVStruct(int anInt, CSVStruct *csv) ;
CSVStruct *addFloatValInCSVStruct(float aFloat, CSVStruct *csv) ;
CSVStruct *addStringValInCSVStruct(char *aStringValue, CSVStruct *csv) ;
CSVStruct *concatenateCSVStructs(CSVStruct *csv1, CSVStruct *csv2) ;
int isIntValPresentInCSV( int anInt, CSVStruct *csv) ;
int isStringValPresentInCSV(char *aStringValue, CSVStruct *csv) ;
CSVStruct *removeStringValInCSVStruct(char *aStringValue, CSVStruct *csv) ;
CSVStruct *removeStringValAtIndexInCSVStruct(int i, CSVStruct *csv) ;
CSVStruct *allocCSVStruct(void) ;
void freeCSVStruct(CSVStruct *csv) ;
int isArgumentPresentInCSV(CSVStruct *csv, const char *searchedArgument) ;
char isFlagPresentInCSV(CSVStruct *csv, const char *searchedFlag) ;
CSVStruct *getCSVWithStringInCSV(char *stringToLookFor, CSVStruct *aCSV)  ;
char *getStringFromCSV(CSVStruct *csv) ;

#endif
