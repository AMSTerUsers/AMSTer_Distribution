
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  interpolCZT.h
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on 10/06/05.
 *  Copyright 2005 Dominique Derauw. All rights reserved.
 *
 */

/* BibInterpol.h */
/* Bibliothèque des fonctions et variables utilisées pour l'interpolation */

#if !defined(INTERPOL)
#define INTERPOL

#include "pourtous.h"
#include "complexTypes.h"
#include "complexCalculus.h"
#include "fft.h"
#include "matrix.h"

typedef	struct {
    int	len ;
    float *filter ;
    double	A ;			/* zoom factor */
    complexFloat	*g ;
    complexFloat	*h ;
    complexFloat	*i ;
    StructFFT	*doubleLengthFFT ;
    StructFFT	*simpleLengthFFT ;
} CZTInterpolator ;

/* definition de fonctions */

CZTInterpolator	*initInterpolator(int len, double A) ;
void updateInterpolator(CZTInterpolator *V, double A) ;
void CZTInterpolation(complexFloat *u, double A, double B, CZTInterpolator *V) ;
void freeCZTInterpolator(CZTInterpolator *V) ;

float *allocAndInitApodizationFilterOfLength(int xDim, float alpha) ;
void allocAndInitCosineSumFilterInCZTInterpolator(CZTInterpolator *V, float alpha) ;

#endif
