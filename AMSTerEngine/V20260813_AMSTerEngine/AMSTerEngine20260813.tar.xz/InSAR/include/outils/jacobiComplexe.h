
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  jacobiComplexe.h
 *  decPol
 *
 *  Created by Dominique Derauw on Wed Sep 25 2002.
 *  Copyright (c) 2002 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(JACOBIC)
#define JACOBIC

#include "pourtous.h"
#include "vectors.h"
#include "matrix.h"

#define SORT 1

int jacobiComplexe(complexFloat **a, int n, float d[], complexFloat **v, int order) ;
void	rotate1(complexFloat **, int, int, int, int, double c, complexDouble s) ;
void	rotate2(complexFloat **, int, int, int, int, double c, complexDouble s) ;
void	rotate3(complexFloat **, int, int, int, int, double c, complexDouble s) ;
void	eigsrt(float d[], complexFloat **v, int n) ;


#endif
