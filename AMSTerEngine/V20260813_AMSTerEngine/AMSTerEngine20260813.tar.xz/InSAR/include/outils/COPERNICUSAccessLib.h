
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  COPERNICUSAccessLib.h
 *  AMSTerEngine
 *
 *  Created by Dominique Derauw on 9/2/2024.
 *  Copyright 2024 SAREOS - Dominique Derauw. All rights reserved.
 *
 */

#if !defined(__COPERNICUS_ACCESS_LIB__)
#define __COPERNICUS_ACCESS_LIB__


#include <stdio.h>
#include <stdlib.h>
#include "pourtous.h"
#include "paramLib.h"
#include "jsonLib.h"

time_t connectToCopernicusServer(CSVStruct *credentials) ;
CSVStruct *getCopernicusCredentials() ;
CSVStruct *getCopernicusTokens()  ;
time_t refreshConnection(CSVStruct *tokens, CSVStruct *credentials) ;
char *getCOPERNICUSStringAttributeRequest(char *attributeName, char *attributeValue) ;
char *getCOPERNICUSIntegerAttributeRequest(char *attributeName, int attributeValue) ;
char *getCOPERNICUSPolygonRequestFromKml(polygon *kml) ;
void waitAWhile(int sleepTime) ;

#endif