
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ceil2.h
 *  vDephi
 *
 *  Created by Dominique Derauw on Mon Mar 01 2004.
 *  Copyright (c) 2004 Dominique Derauw. All rights reserved.
 *
 */
#include <math.h>
#include "pourtous.h"
#include "byteSwap.h"

#if !defined(CEIL2)
#define CEIL2

void	ceil2(int *ptr_nb, int *ptr_expnb) ;
int		ceil2ofIntVal(int anInt) ;
int		ceil2ofFloatVal(float aFloat) ; 

#endif
