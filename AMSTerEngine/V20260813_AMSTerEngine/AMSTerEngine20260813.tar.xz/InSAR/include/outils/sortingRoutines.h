
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  sortingRoutines.h
//  InSAR suite
//
//  Created by Dominique Derauw on 24/08/16.
//
//

#ifndef __sortingRoutines__
#define __sortingRoutines__

#include <stdio.h>
#include <string.h>
#include "vectors.h" 
#include "stringLib.h"

#define _ASCENDING_SORT_ 1
#define _DESCENDING_SORT_ 0

void	descendingSort(int n, float *vector) ;
void	ascendingSort(int n, float *vector) ;
void	descendingSort3(int n, float *vector1, int *vector2, int *vector3) ;
void	ascendingSort3(int n, float *vector1, int *vector2, int *vector3) ;

int isIntGreaterOrEqualToInt(int val1, int val2) ;
int isIntLowerOrEqualToInt(int val1, int val2) ;
void mergeAndSortInt(int *v, int *vv, int *index, int* iindex, int lowerIndex, int middleIndex, int upperIndex, int flag) ;
void cutAndSortInt(int *v, int *vv, int *index, int* iindex, int lowerIndex, int upperIndex, int flag) ;
int *sortIntVect(int *v, int *index, int N, int flag) ;

int isFloatGreaterOrEqualToFloat(float val1, float val2) ;
int isFloatLowerOrEqualToFloat(float val1, float val2) ;
void mergeAndSortFloat(float *v, float *vv, int *index, int* iindex, int lowerIndex, int middleIndex, int upperIndex, int flag) ;
void cutAndSortFloat(float *v, float *vv, int *index, int* iindex, int lowerIndex, int upperIndex, int flag) ;
int *sortFloatVector(float *v, int *index, int N, int flag) ;

int isDoubleGreaterOrEqualToDouble(double val1, double val2) ;
int isDoubleLowerOrEqualToDouble(double val1, double val2) ;
void mergeAndSortDouble(double *v, double *vv, int *index, int* iindex, int lowerIndex, int middleIndex, int upperIndex, int flag) ;
void cutAndSortDouble(double *v, double *vv, int *index, int* iindex, int lowerIndex, int upperIndex, int flag) ;
int *sortDoubleVector(double *v, int *index, int N, int flag) ;

int isStringGreaterOrEqualToString(char *string1, char *string2) ;
int isStringLowerOrEqualToString(char *string1, char *string2) ;
void mergeAndSortStringVect(char **v, char **vv, int *index, int* iindex, int lowerIndex, int middleIndex, int upperIndex, int flag) ;
void cutAndSortStringVect(char **v, char **vv, int *index, int* iindex, int lowerIndex, int upperIndex, int flag) ;
int *sortStringVect(char **v, int *index, int N, int flag) ;


#endif /* defined(__sortingRoutines__) */
