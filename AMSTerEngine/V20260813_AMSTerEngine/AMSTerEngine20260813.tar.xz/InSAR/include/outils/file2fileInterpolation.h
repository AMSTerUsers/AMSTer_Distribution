
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  file2fileInterpolation.h
//  cutAndZoomCSLImage
//
//  Created by Dominique Derauw on 17/03/16.
//  Copyright (c) 2016 Dominique Derauw. All rights reserved.
//

#ifndef __file2fileInterpolation__
#define __file2fileInterpolation__

#include <stdio.h>
#include "interpolCZT.h"
#include "rawFileLib.h"
#include "counters.h"

#ifndef _INTERPOL_MEM_MAX_SIZE_
#define _INTERPOL_MEM_MAX_SIZE_ 1024 * 1024 * 1024 /* Mb */
#endif

typedef struct file2fileInterpolation
{
    double **afineTransform ;   /* This is a 2 x 3 matrix containing the afine transform */
    double **spectrumShift ;    /* This is a 2 x 2 matrix containing the x an y azimuth shifts and sampling rates */
} afineInterpolationParameters ;

afineInterpolationParameters *allocAfineInterpolationParameters(void) ;
void	interpolComplexAlongXAxis(rawFileDescriptor *, double **, rawFileDescriptor *, char) ;
void	interpolComplexAlongYAxis(rawFileDescriptor *, double **, rawFileDescriptor *, char) ;
void interpolFloatMatrixInPlace(float **M, int xDim, int yDim, double **T) ;

#endif /* defined(__file2fileInterpolation__) */
