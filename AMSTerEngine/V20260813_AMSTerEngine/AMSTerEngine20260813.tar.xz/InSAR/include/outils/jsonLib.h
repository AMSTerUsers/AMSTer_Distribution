
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  jsonLib.h
 *  AMSTerEngine
 *
 *  Created by Dominique Derauw on 29/11/2023.
 *  Copyright 2023 SAREOS - Dominique Derauw. All rights reserved.
 *
 */

#if !defined(JSONLIB)
#define JSONLIB

#include "stringLib.h"
#include "rawFileLib.h"
#include "fileAccessLib.h"
#include "paramLib.h"

char *readJsonFileIntoBuffer(char *jsonFilePath) ;
CSVStruct *getCSVForKeyInJsonFile(char *jsonFilePath, char *theKey) ;
keyValue *readJsonFileAsKeyValueList(char *jsonFilePath) ;
keyValue *getNextKeyVal(char *buffer) ;

char isJsonStartChar(char *aChar) ;
char isJsonEndChar(char *aChar) ;

#endif