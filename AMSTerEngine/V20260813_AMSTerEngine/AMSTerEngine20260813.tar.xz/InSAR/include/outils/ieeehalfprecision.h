
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  ieeehalfprecision.h
//  readAndConvertComplexData
//
//  Created by Dominique Derauw on 5/06/12.
//  Copyright (c) 2012 Dominique Derauw. All rights reserved.
//

#ifndef ieeehalfprecision_h
#define ieeehalfprecision_h

// Includes -------------------------------------------------------------------

#include <string.h>

// Macros ---------------------------------------------------------------------

#define  INT16_TYPE          short
#define UINT16_TYPE unsigned short
#define  INT32_TYPE          int
#define UINT32_TYPE unsigned int

// Prototypes -----------------------------------------------------------------

int singles2halfp(void *target, void *source, int numel);
int doubles2halfp(void *target, void *source, int numel);
int halfp2singles(void *target, void *source, int numel);
float half2SinglePrecision(void *halfPrecisionFloat) ;
int halfp2doubles(void *target, void *source, int numel);


#endif
