
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  tileToolLib.h
//  detPhUn
//
//  Created by Dominique Derauw on 30/08/12.
//  Copyright (c) 2012 Dominique Derauw. All rights reserved.
//

#ifndef detPhUn_tileToolLib_h
#define detPhUn_tileToolLib_h

#include "pourtous.h"
#include "rawFileLib.h"
#include "complexCalculus.h"


struct tileToolStructure {
    rawFileDescriptor *input ;                              /* Input file linked with tile tool */
    rawFileDescriptor *output ;                             /* Output file linked with tile tool */
    char mirroring ;                                        /* Flag for mirroring data on borders */
                                                            /* 0 = no mirroring (zeros on borders). 1 = borders filled by circularization of data 2 = borders filled mirroring data */
    char leftBorder, rightBorder, bottomBorder, upBorder ;  /* Flag determining which border must be mirrored */
    char dataType[16] ;                                     /* Data type: char, int, long, float, double or complexFloat */
    size_t typeCode ;                                 /* Data code corresponding to type */
    size_t typeSize ;                                 /* Data size corresponding to type */
    size_t xTileSize ;                                /* Tile X dimension */
    size_t yTileSize ;                                /* Tile Y dimension */
    size_t xTileBorderSize ;                          /* Tile border X dimension */
    size_t yTileBorderSize ;                          /* Tile border Y dimension */
    size_t xTileNumber ;                              /* Number of tiles within input data file along X dimension */
    size_t yTileNumber ;                              /* Number of tiles within input data file along Y dimension */
    size_t xDimIn ;                                   /* Input data X dimension (copied from input raw file descriptor!) */
    size_t yDimIn ;                                   /* Input data Y dimension (copied from input raw file descriptor!) */
    size_t xDimOut ;                                  /* Output data X dimension (copied from output raw file descriptor!) */
    size_t yDimOut ;                                  /* Output data Y dimension (copied from output raw file descriptor!) */
    int  x0In ;                                             /* X0 coordinate of current tile within input data */
    int  y0In ;                                             /* Y0 coordinate of current tile within input data */
    size_t x0Tile ;                                   /* X0 coordinate within current tile */
    size_t y0Tile ;                                   /* Y0 coordinate within current tile */
    size_t x0Out ;                                    /* X0 coordinate of current tile within output data */
    size_t y0Out ;                                    /* Y0 coordinate of current tile within output data */
    size_t x0EA ;                                     /* X0 coordinate of Efficient Area within current tool */
    size_t y0EA ;                                     /* Y0 coordinate of Efficient Area within current tool */
    size_t xDimEA ;                                   /* Tile Efficient Area X size */
    size_t yDimEA ;                                   /* Tile Efficient Area Y size */
    size_t xDimReadData ;                             /* X size of effectively read data */
    size_t yDimReadData ;                             /* Y size of effectively read data */
    size_t xTileIndex ;                               /* Current tile X index */
    size_t yTileIndex ;                               /* Current tile Y index */
    quadrilateral *aoi ;
    void **tile ;                                           /* Tile matrix */
    void **inputDataMatrix ;                                /* Data matrix */
    void **outputDataMatrix ;                               /* Data matrix */
} ;

typedef struct tileToolStructure tileTool ;


tileTool *allocTileTool()  ;
tileTool *allocTileToolForDataOfType(void **inputDataMatrix, void **outputDataMatrix, int xDimData, int yDimData, char *dataType) ;
tileTool *allocTileToolForFilesOfType(rawFileDescriptor *inputFile, rawFileDescriptor *outputFile, char *dataType) ;
void freeTileTool(tileTool *aTileTool) ;
void **initTileToolWithSizes(tileTool *aTileTool, size_t xTileSize, size_t yTileSize, size_t xTileBorderSize, size_t yTileBorderSize) ;
void resetTileToZero(tileTool *aTileTool) ;
void updateTileToolForIndexes(tileTool *aTileTool, size_t xTileIndex, size_t yTileIndex) ;
void **copyTileAtIndexes(tileTool *aTileTool, size_t xTileIndex, size_t yTileIndex) ;
void **readTileAtIndexes(tileTool *aTileTool, size_t xTileIndex, size_t yTileIndex) ;
void setMirroringForTileTool(tileTool *aTileTool) ;
void setCircularizationForTileTool(tileTool *aTileTool) ;
void mirrorDataLeft(tileTool *aTileTool) ;
void mirrorDataRight(tileTool *aTileTool)  ;
void mirrorDataBottom(tileTool *aTileTool) ;
void mirrorDataUp(tileTool *aTileTool) ;
void writeTile(tileTool *aTileTool) ;
void writeTileInLayer(tileTool *aTileTool, int layerIndex) ;
void saveTile(tileTool *aTileTool) ;
void writeTileToOutputFile(tileTool *aTileTool, rawFileDescriptor *output) ;
void writeTileToOutputFileInLayer(tileTool *aTileTool, rawFileDescriptor *output, int layerIndex) ;
void registerDataTileInTileTool(void **data, tileTool *aTileTool) ;
void swapInAndOutInTileTool(tileTool *aTileTool) ;
float localAverageOfFloatTile(tileTool *aTileTool) ;
void multiplyTileTools(tileTool *M1, tileTool *M2, tileTool *M3) ;
void getAmplitudeOfComplexTileTools(tileTool *M1, tileTool *M2) ;


#endif
