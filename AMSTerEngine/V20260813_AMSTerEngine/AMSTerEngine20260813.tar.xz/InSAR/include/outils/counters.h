
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  counters.h
 *  ersRAWReader
 *
 *  Created by Dominique Derauw on 7/09/06.
 *  Copyright 2006 Dominique Derauw. All rights reserved.
 *
 */


/* Little functions to create and display progress counters */
#if !defined(PROGRESS_COUNTER)
#define PROGRESS_COUNTER


#include "pourtous.h"

typedef struct {
	FILE *output ;
	int currentIndex ;
	int minIndex ;
	int maxIndex ;
	int gap ;
	int formerValue ;
    int displayIndex ;
} progressCounter ;

progressCounter *allocProgressCounter(void)  ;
progressCounter *initProgressCounterWithMinMaxValue(int min, int max) ;
void resetProgressCounter(progressCounter *aProgressCounter) ;
int updateProgressCounterForIndex(progressCounter *p, int anIndex) ;
int updatePointProgressCounterForIndex(progressCounter *p, int anIndex) ;
void freeProgressCounter(progressCounter *p) ;

#endif

