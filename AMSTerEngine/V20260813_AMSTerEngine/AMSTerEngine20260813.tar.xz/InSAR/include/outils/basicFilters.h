
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  basicFilters.h
//  biasedCoherenceEstimation
//
//  Created by Dominique Derauw on 24/08/16.
//
//

#ifndef __biasedCoherenceEstimation__basicFilters__
#define __biasedCoherenceEstimation__basicFilters__

#include <stdio.h>
#include "pourtous.h"
#include "tileToolLib.h"
#include "vectors.h"
#include "matrix.h"
#include "sortingRoutines.h"

#define _X_FILTER_TILE_SIZE_ 256
#define _Y_FILTER_TILE_SIZE_ 256


void medianFilter(tileTool *aTileTool, int unsigned xFilterSize, int unsigned yFilterSize) ;
void medianFilterOfFloatFile(rawFileDescriptor *aFloatFile, int unsigned xFilterSize, int unsigned yFilterSize, float *excludedVal) ;
void meanFilterOfFloatFile(rawFileDescriptor *aFloatFile, int unsigned xFilterSize, int unsigned yFilterSize, float *excludedVal) ;


#endif /* defined(__biasedCoherenceEstimation__basicFilters__) */
