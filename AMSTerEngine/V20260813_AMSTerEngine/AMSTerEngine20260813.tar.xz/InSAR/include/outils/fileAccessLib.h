
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  fileAccesLib.h
 *  trackDataReader
 *
 *  Created by Dominique Derauw on 3/02/05.
 *  Copyright 2005 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(FILE_ACCES_LIB)
#define FILE_ACCES_LIB

#if !defined(_BUFFER_SIZE_)
#define _BUFFER_SIZE_ (int)(32 * 1024 * 1024)
#endif

#include "stringLib.h"
#include "pourtous.h"
#include "planeGeometry.h"
//#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/errno.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <sys/types.h>

char *getFileNameFromPath(char *aPath) ;
char *getPointerToFileNameInPath(char *path) ;
char *getDirectoryName(char *aPath) ;
char *getFileExtensionFromPath(char *aPath) ;
char *getPointerToFileExtensionInPath(char *path) ;
char *getPointerToLastFileExtensionInPath(char *path) ;
void stripExtensionAtEndOfPath(char *aPath) ;
void stripAllExtensions(char *aPath) ;
char *addExtensionAtEndOfPath(char *aPath, char *extension) ;
char *getDirectoryPathFromPath(char *aPath) ;
char *getUpperDirectoryPath(char *aDirectoryPath) ;
char isValidDirectoryForPath(char *aPath) ;
char isSymbolicLink(char *path) ;
char fileExistsAtPath(char *aPath) ;
char isDir(char *aPath) ;
char isReadAccessGrantedAtPath(char *aPath) ;
char isWriteAccessGrantedAtPath(char *aPath) ;
char isRWAccessGrantedAtPath(char *aPath) ;
off_t getFileLengthAtPath(char *path) ;
CSVStruct *recursiveSearchOfDirInDir(char *dirName, char *dir) ;
CSVStruct *listDirectoriesOfNameInDir(char *dirName, char *searchedDir) ;
CSVStruct *getCSVDirectoryListingAtPath(char *aDir) ;
CSVStruct *recursiveSearchOfFileInDir(char *fileName, char *dir) ;
CSVStruct *recursiveSearchOfFileNamesInDir(char *fileName, char *dir) ;
CSVStruct *listFilesWithExtensionInDir(char *extension, char *dir) ;
CSVStruct *listFilesWithNameInDir(char *fileName, char *dir) ;
CSVStruct *recursiveSearchOfFilesWithExtensionInDir(char *extension, char *dir) ;
char isDirPresentInSubDir(char *searchedDir, char *startingDir) ;
char isFilePresentInSubDir(char *fileName, char *dir) ;
char **getDirectoryContentAtPath(char *aPath, int *numberOfEntries) ;
char **getDirectoryEntriesAtPath(char *aPath) ;
void freeDirectoryEntriesAtPath(char **entries, char *aPath) ;
char **getAllDirectoryEntriesAtPath(char *aPath) ;
void freeDirectoryEntries(char **entries, int numberOfEntries) ;
int getNumberOfDirectoryEntriesAtPath(char *aPath) ;
int getNumberOfAllDirectoryEntriesAtPath(char *aPath) ;
void makeDirRecursively(char *aPath) ;
void removeDirectoryAtPath(char *aPath) ;
void copyFileAtPathToPath(char *inputPath, char *outputPath) ;
void copyDirAtPathToPath(char *inputDir, char *outputDir) ;
char *expandEnvironmentVariablesInPath(char *aPath) ;
char *getCorrespondingFilePathWithExtension(char *filePath, char *anExtension) ;
char correspondingFileWithExtensionExists(char *filePath, char *anExtension) ;

#endif
