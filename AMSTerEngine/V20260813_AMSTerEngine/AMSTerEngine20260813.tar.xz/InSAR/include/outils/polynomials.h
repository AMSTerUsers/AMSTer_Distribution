
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  fonctionPolynome.h
 *  georef
 *
 *  Created by Dominique Derauw on Thu Feb 21 2002.
 *  Copyright (c) 2001 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(FONCTION_POLYNOME)
#define FONCTION_POLYNOME

#include "pourtous.h"

typedef struct {
	int	order ;
	double	*coefs ;
} xPolynomial ;

xPolynomial *allocXPolynomialOfOrder(int N) ;
double yValForPolynomial(xPolynomial *fX, double x) ;
void freeXPolynomial(xPolynomial *fX) ;

#endif
