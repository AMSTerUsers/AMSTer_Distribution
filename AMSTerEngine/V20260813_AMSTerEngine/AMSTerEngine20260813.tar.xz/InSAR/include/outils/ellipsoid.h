
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ellipsoid.h
 *  dephiProj
 *
 *  Created by Dominique Derauw on Thu Jan 09 2003.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
 */

#if !defined(ELLIPSOID)
#define ELLIPSOID

typedef struct  {
    char	ellipsoidID[64] ;
    double	a ;
    double	b ;
    double	f_1 ;
    double	e2, ep2 ;
    double	X0, Y0, Z0 ;
} ellipsoid ;

#define WGS84_A 6378137.0
#define WGS84_B 6356752.3142

#endif


