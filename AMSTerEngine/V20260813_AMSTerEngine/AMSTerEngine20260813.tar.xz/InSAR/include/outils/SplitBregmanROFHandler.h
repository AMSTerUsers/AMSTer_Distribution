
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  SplitBregmanROFHandler.h
 *  SplitBregmanROFHandler
 *
 *  Created by Dominique Derauw on Wed Aug 24 2022.
 *  Copyright (c) 2022 SAREOS Dominique Derauw. All rights reserved.
 *
 */

#include "pourtous.h"
#include "rawFileLib.h"
#include "matrixObjects.h"

#define mxREAL _REAL64_ID_

typedef struct supposedMathlabStruct
{
    int rank ;
    int *dims ;
    int dataType ;
    void *m ;
} mxArray ;

void splitBregmanROF_Help(void) ;
mxArray *alloc_mxArrayOfRank(int rank) ;
void free_mxArray(mxArray *mx) ;

int mxGetN(const mxArray *mx) ;
int mxGetM(const mxArray *mx) ;
double mxGetScalar(const mxArray *mx) ;

void mexErrMsgTxt(char *message) ;
int mxIsDouble(const mxArray *mx) ;
mxArray *mxCreateDoubleMatrix(int yDim, int xDim, int dataType) ;
double *mxGetPr(const mxArray *mx) ;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) ;
