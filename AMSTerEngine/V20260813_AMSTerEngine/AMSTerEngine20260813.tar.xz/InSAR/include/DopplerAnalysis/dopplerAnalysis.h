
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  dopplerAnalysis.h
//  dopplerAnalysis
//
//  Created by Dominique Derauw on 17/10/12.
//  Copyright (c) 2012 Dominique Derauw. All rights reserved.
//

#ifndef dopplerAnalysis_dopplerAnalysis_h
#define dopplerAnalysis_dopplerAnalysis_h

#include "pourtous.h"
#include "infoImage.h"
#include "fileAccessLib.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "geoRef.h"
#include "approxRt.h"
#include "matrixPile.h"
#include "vectorialCalculus.h"

#define X_DC_GRID_DIM  5
#define Y_DC_GRID_DIM  5


void usage(void) ;
void estimateDopplerParameterFromOrbitography(struct infoImage *info) ;
double *normalToDopplerPlane(double *RS, double *VS, double yaw, double pitch) ;
double **DopplerPolynomialApproximation(double ***DCGrid) ;
double *multMatVectDouble(double **M, double *V, int order) ;
double **multMatDouble( double **A, double**B, int rank) ;
void transposeMatrixDouble(double **resultMatrix, double **A, int rank) ;


#endif
