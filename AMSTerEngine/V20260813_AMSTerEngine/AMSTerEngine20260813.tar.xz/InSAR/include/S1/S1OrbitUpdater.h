
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  S1OrbitUpdater.h
//  S1OrbitUpdater
//
//  Created by Dominique Derauw on 20/06/2018.
//  Copyright © 2018 Dominique Derauw. All rights reserved.
//

#ifndef S1OrbitUpdater_h
#define S1OrbitUpdater_h

#include <stdio.h>
#include <stdlib.h>
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "S1OrbitManagement.h"
#include "S1DataReaderLib.h"

void S1OrbitUpdaterUsage(void) ;


#endif /* S1OrbitUpdater_h */
