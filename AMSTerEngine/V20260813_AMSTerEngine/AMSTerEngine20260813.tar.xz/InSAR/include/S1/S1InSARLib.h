
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  S1InSARDataReaderLib.h
//  S1InSARDataReader
//
//  Created by Dominique Derauw on 25/09/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#ifndef __S1InSARDataReader__S1InSARDataReaderLib__
#define __S1InSARDataReader__S1InSARDataReaderLib__

#include <stdio.h>
#include <sys/resource.h>

#include "pourtous.h"
#include "initInSARParams.h"
#include "initInSARDirectoryStructure.h"

#include "infoImage.h"
#include "infoImageS1.h"
#include "amplitudeImageReductionLib.h"
#include "coregistrationLib.h"
#include "interpolation.h"
#include "incomod.h"
#include "S1DataReaderLib.h"

/* Flags Definition */
#define FULL_AUTOMATIC_BEHAVIOR 0x00000008
#define PER_SUBSWATH_PROCESSING 0x00000010
#define _ASK_USER_              0x00000020
#define _NO_RERAMPING_          0x00000040
#define _FINE_REGISTRATION_     0x00000080
#define _BASIC_CORRECTION_      0x00000100
#define _COARSE_REGISTRATION_   0x00000200
#define _ALL_POLARIZATIONS_     0x00000400
#define _SQUINT_PHASE_REMOVAL_  0x00000800
#define _ESD_ENABLED_           0x00001000

/* Default values definition */
#define RANGE_REDUCTION_FACTOR 4
#define AZIMUTH_REDUCTION_FACTOR 4
#define XDIM_COARSE_COR_WINDOW 32
#define YDIM_COARSE_COR_WINDOW 32
#define X_COARSE_COR_WINDOW_SHIFT 32
#define Y_COARSE_COR_WINDOW_SHIFT 32
#define CORRELATION_THRESHOLD .5
#define COARSE_COR_X_FWHM 5
#define COARSE_COR_Y_FWHM 5
#define XDIM_FINE_COR_WINDOW 12
#define YDIM_FINE_COR_WINDOW 5
#define X_FINE_COR_WINDOW_SHIFT 32
#define Y_FINE_COR_WINDOW_SHIFT 32
#define X_FINE_COR_ERROR 3              /* These value gives the range of coherence exploration around the suposed correct position */
#define Y_FINE_COR_ERROR 3              /* A coherence map of (2 * X_FINE_COR_ERROR + 1) x (2 * Y_FINE_COR_ERROR + 1) will be computed to find the location of the coherence maximum. */
#define FINE_COR_THRESHOLD .5 ;
#define XDIM_COH_WINDOW 12
#define YDIM_COH_WINDOW 5
#define SPI_COH_WINDOW 3


int S1Coregistration(CSVStruct *cl) ;           /* cl means command line */
void S1CoregistrationHelp(void) ;
void transferAdditionalParameters(InSARParametersStruct *pInSAR, keyValue *parametersList) ;
void burstsInterpolation(InSARParametersStruct *pInSAR) ;
void adaptInSARparametersToS1(InSARParametersStruct *pInSAR) ;
void translateAffineTransform(double **T, double dx, double dy) ;
void basicBurstSynchronization(InSARParametersStruct *pInSAR) ;
void burstsDeramping(SLCImageInfo *info, SLCImageInfo *masterInfo) ;
void burstsReramping(SLCImageInfo *info, SLCImageInfo *masterInfo) ;
void burstDeramping(burstDescriptor *currentBurst, SLCImageInfo *info, SLCImageInfo *masterInfo) ;
void perLineBurstDeramping(derampingStructType *deramping, complexFloat *burstLine) ;
char InSARBurstSelection(InSARParametersStruct *pInSAR) ;
void initSlaveSwathsTransforms(InSARParametersStruct *pInSAR) ;
void initPerBurstTransforms(InSARParametersStruct *pInSAR) ;
void initPerBurstShiftTransforms(InSARParametersStruct *pInSAR) ;
void alignSlaveImage(InSARParametersStruct *pInSAR) ;
void copyMasterImageToDestination(InSARParametersStruct *pInSAR) ;
void copySlaveImageToDestination(InSARParametersStruct *pInSAR) ;


#endif /* defined(__S1InSARDataReader__S1InSARDataReaderLib__) */
