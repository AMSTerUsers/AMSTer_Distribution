
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  S1ETADManagement.h
//  S1DataReader
//
//  Created by Dominique Derauw on 09/04/2025.
//  Copyright © SAREOS - Dominique Derauw. All rights reserved.
//

#ifndef _S1ETAD_S1ETADMANAGEMENT_H_
#define _S1ETAD_S1ETADMANAGEMENT_H_

#include "pourtous.h"
#include "ncReaderLib.h"
#include "infoImageS1.h"

char *findETADFile(char *S1FileName, char *dir) ;
void updateETADDataIntoS1Frame(CSLImage *aFrame, char *ETADDataDir) ;
char isETADPresentInCSLImage(CSLImage *thisImage) ;
S1ETADLayers *allocETADLayersStruct() ;
void loadETADLayersIntoBursts(SLCImageInfo *info, int layerSelection) ;
void loadETADLayerIntoBurst(size_t ETADLayerIndex, burstDescriptor *currentBurst) ;
double ETADPhaseDelayAtPoint(double rangePosition, double azimuthPosition, SLCImageInfo *masterInfo, SLCImageInfo *slaveInfo) ;
coord2D ETADGeoreferencingShift(double rangePosition, double azimuthPosition, SLCImageInfo *info) ;

#endif