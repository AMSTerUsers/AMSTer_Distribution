
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/**
 * @file S1ETAD.h
 * @author Created by Dominique Derauw
 * @copyright ©2025 Dominique Derauw - SAREOS
 * @date 20250506
 */

#include "gridMapping.h"

#ifndef _S1ETAD_S1ETAD_H
#define _S1ETAD_S1ETAD_H

#define _ETAD_BISTATIC_CORRECTION_AZ_        0x00000001
#define _ETAD_DOPPLER_RANGE_SHIFT_RG_        0x00000002
#define _ETAD_FM_MISMATCH_CORRECTION_AZ_     0x00000004
#define _ETAD_GEODETIC_CORRECTION_AZ_        0x00000008
#define _ETAD_GEODETIC_CORRECTION_RG_        0x00000010
#define _ETAD_IONOSPHERIC_CORRECTION_RG_     0x00000020
#define _ETAD_SUM_OF_CORRECTIONS_AZ_         0x00000040
#define _ETAD_SUM_OF_CORRECTIONS_RG_         0x00000080
#define _ETAD_TROPOSPHERIC_CORRECTION_RG_    0x00000100
#define _ETAD_HEIGHT_                        0x00000200

#define _ETAD_MASTER_BURST_                  0x00000400
#define _ETAD_SLAVE_BURST_                   0x00000800

#define _ETAD_CORRECTION_                    0x00010000

#if !defined(ETAD_LAYER_NAMES_DEF)
#define ETAD_LAYER_NAMES_DEF
static const char *ETADLayerName[10] = {
    "bistaticCorrectionAz", 
    "dopplerRangeShiftRg", 
    "fmMismatchCorrectionAz", 
    "geodeticCorrectionAz", 
    "geodeticCorrectionRg", 
    "ionosphericCorrectionRg", 
    "sumOfCorrectionsAz", 
    "sumOfCorrectionsRg", 
    "troposphericCorrectionRg", 
    "height", 
} ;
#endif

struct S1ETAD
{
    int layerSelection ;
    double rangeTimeMin ;
    double azimuthTimeMin ;
    double gridStartAzimuthTime ;
    double gridStartRangeTime ;
    double gridSamplingAzimuth ;
    double gridSamplingRange ;
    double averageZeroDopplerVelocity ;
    double instrumentTimingCalibrationRange ;
    double instrumentTimingCalibrationAzimuth ;

    gridMap *bistaticCorrectionAz ;
    gridMap *dopplerRangeShiftRg ;
    gridMap *fmMismatchCorrectionAz ;
    gridMap *geodeticCorrectionAz ;
    gridMap *geodeticCorrectionRg ;
    gridMap *ionosphericCorrectionRg ;
    gridMap *sumOfCorrectionsAz ;
    gridMap *sumOfCorrectionsRg ;
    gridMap *troposphericCorrectionRg ;
    gridMap *height ;
    gridMap **layer ;
} ;
typedef struct S1ETAD S1ETADLayers ;



#endif /* _S1ETAD_S1ETAD_H */