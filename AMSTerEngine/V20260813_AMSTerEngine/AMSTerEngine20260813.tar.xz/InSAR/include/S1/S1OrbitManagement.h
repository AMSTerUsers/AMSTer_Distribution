
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  S1OrbitManagement.h
//  S1DataReader
//
//  Created by Dominique Derauw on 20/10/16.
//  Copyright (c) 2016 Dominique Derauw. All rights reserved.
//

#ifndef __S1DataReader__S1OrbitManagement__
#define __S1DataReader__S1OrbitManagement__

#include <stdio.h>
#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "infoImage.h"
#include "rawFileLib.h"
#include "geoRef.h"
#include "basicXMLHandlingLib.h"


#define _S1_ORBIT_DIR_NOT_DEFINED_  -1
#define _S1_ORBIT_NO_UPDATE_PERFORMED_  0
#define _S1_PRECISE_ORBIT_NOT_FOUND_  -2
#define _S1_PRECISE_ORBIT_UPDATED_OK_  1
#define _S1_PRECISE_ORBIT_ALREADY_UPDATED_  2
#define _S1_RESTITUTED_ORBIT_NOT_FOUND_  -3
#define _S1_RESTITUTED_ORBIT_UPDATED_OK_  3
#define _S1_RESTITUTED_ORBIT_ALREADY_UPDATED_  4


char *getPOEORBDirectory(keyValue *parametersList, int argc, const char *argv[]) ;
int updateS1PreciseOrbitInCSLImageAtPath(char *imagePath) ;
int updateS1PreciseOrbitInCSLImage(CSLImage *thisImage) ;
int manageS1OrbitsFor(CSLImage *thisImage, char *auxiliaryDataDirectoryFilePath, SLCImageInfo *info) ;
char isS1PreciseOrbitAvailable(SLCImageInfo *info, char *POEORBDir) ;
char *findS1OrbitFilePath(SLCImageInfo *info, char *POEORBDir) ;
void readS1PreciseOrbitStateVectors(char *POEORBDir, SLCImageInfo *info) ;
void outputOrbitUpdateMessage(rawFileDescriptor *logFile, int flag) ;

#endif /* defined(__S1DataReader__S1OrbitManagement__) */
