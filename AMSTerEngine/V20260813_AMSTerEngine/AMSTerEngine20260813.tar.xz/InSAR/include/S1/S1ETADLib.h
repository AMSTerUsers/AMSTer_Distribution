
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  S1DataReaderLib.h
//  S1InSARDataReader
//
//  Created by Dominique Derauw on 25/09/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#ifndef __S1InSARDataReader__S1DataReaderLib__
#define __S1InSARDataReader__S1DataReaderLib__

#include <stdio.h>

#include <stdio.h>
#include <stdlib.h>
#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "infoImageS1.h"
#include "byteSwap.h"
#include "counters.h"
#include "vectors.h"
#include "matrix.h"
#include "resmat.h"
#include "complexTypes.h"
#include "complexCalculus.h"
#include "polynomials.h"
#include "aoiHandling.h"
#include "S1OrbitManagement.h"

#include <tiffio.h>
#include <xtiffio.h>
#include <zlib.h>

#define _READ_ALL_BURSTS_               0x00000010
#define _READ_SELECTED_BURSTS_          0x00000020

#define _S1_TIFF_BURST_STITCHING_       0x00000100
#define _S1_SWATH_STITCHING_            0x00000200
#define _S1_HEADER_STITCHING_           0x00000400
#define _S1_READ_HEADERS_ONLY_          0x00000800
#define _S1_READ_OVERWRITE_             0x00001000
#define _S1_BULK_READING_               0x00002000
#define _S1_IMAGE_STITCHING_            0x00004000
#define _S1_SM_READ_AND_SAVE_           0x00008000
#define _S1_ORBIT_UPDATE_               0x00010000
#define _S1_READ_IF_ORBIT_UPDATE_       0x00020000
#define _S1_KEEP_AOI_AS_GIVEN_          0x00040000
#define _S1_COMPRESSED_DATA_IN_INPUT_   0x00080000
#define _S1_DOWNLOAD_AND_READ_          0x00100000

#define _S1_KEEP_BURSTS_ 0
#define _S1_TRASH_BURSTS_ 1


typedef struct {
    char isBlackLine ;
    int *currentLineInMDS ;
    int *currentLineInBurst ;
    int *firstValidSampleIndex, *lastValidSampleIndex ; /* These are index within the burst, starting from zero */
    int *firstRangePixelIndex, *lastRangePixelIndex ; /* These are index locations within the image */
    int *burstRangeShift, rangeDim ;
    complexShort **MDSLine ;
    complexFloat *aFullLine, **subswathLine, **subswathLine2, *zeroLine ;
    SLCImageInfo *info ;
    S1AdditionalInfo *S1 ;
    TIFF **tiffMDS ;
//    GTIF **gtiffMDS; /* GeoKey-level descriptor */
    burstDescriptor **currentBurst ;
} lineLocInMDS ;


typedef struct  {
    int firstSwathIndex ;
    int lastSwathIndex ;
    int numberOfSwath ;
    int *firstBurstIndex ;
    int *lastBurstIndex ;
    int *numberOfBursts ;
    int totalNumberOfBursts ;
    CSVStruct *refPol ;
    point2D **refPoint ;
    polygon ***aoi ;
} S1BurstSelection ;



/* Functions prototypes */
CSVStruct *S1DataReader(CSVStruct *csv) ;
void S1DataReaderHelp(void) ;
void createS1DataReaderParameterFileAtPath(char *aPath) ;
char isManifestFilePresentAtPath(char *aPath) ;
char isSlaveValid(CSLImage *slaveImage) ;
int readS1DATALayersInto(CSLImage *thisImage, SLCImageInfo *info) ;
int readS1DATALayersBurstsInto(CSLImage *thisImage, SLCImageInfo *info);
void copyS1HeadersToCSLImage(S1AdditionalInfo *S1Specific, CSLImage *anImage) ;
lineLocInMDS *initlineLocInTIFFMDS(SLCImageInfo *info, int layerIndex) ;
lineLocInMDS *initlineLocInMDS(SLCImageInfo *info) ;
void freelineLocInMDS(lineLocInMDS *lineLoc) ;
complexFloat *swathLineAtAzimuthIndexFromTIFFMDS(int azimuthIndex, lineLocInMDS *lineloc, int swathIndex) ;
complexFloat *wideSwathLineAtAzimuthIndexFromTIFFMDS(int azimuthIndex, lineLocInMDS *lineloc) ;
complexFloat *swathLineAtAzimuthIndexFromReadBursts(int azimuthIndex, lineLocInMDS *lineloc, int layerIndex, int swathIndex) ;
complexFloat *wideSwathLineAtAzimuthIndexFromReadBursts(int azimuthIndex, lineLocInMDS *lineloc, int layerIndex) ;
CSVStruct *generateSubswathImages(CSLImage *thisImage, SLCImageInfo *info, char trashBursts) ;
char *concatenateBurstsIntoSubSwathImage(CSLImage *thisImage, char *outputPath, SLCImageInfo *info, int layerIndex, int swathIndex) ;
void concatenateBurstsIntoWideSwathImage(CSLImage *thisImage, SLCImageInfo *info, char trashBursts) ;
void trashSelectedBursts(SLCImageInfo *info) ;
void trashAllBursts(CSLImage *thisImage) ;
void openBurstFilesForReadingAndWriting(CSLImage *thisImage, SLCImageInfo *info) ;
void closeAndReleasBurstFiles(SLCImageInfo *info) ;
void detectSelectedBurstsInCSLImage(CSLImage *thisImage, SLCImageInfo *info) ;
void readBurstSelectionInCSLImage(CSLImage *thisImage, SLCImageInfo *info) ;
CSVStruct *readS1Data(char *S1AccesPath, char *outputPath, quadrilateral *aoi, char *polarization, unsigned int flag) ;
SLCImageInfo *mergeFrameInfo(CSLImage *imageContainer, char *selectedPolarizations) ;
void S1FilePathTimeOrdering(CSVStruct *S1FilePath) ;
S1BurstSelection *getS1BurstSelectionForImage(CSLImage *refImage) ;
void freeS1BurstSelection (S1BurstSelection *imageBurstSelection) ;



#endif /* defined(__S1InSARDataReader__S1DataReaderLib__) */
