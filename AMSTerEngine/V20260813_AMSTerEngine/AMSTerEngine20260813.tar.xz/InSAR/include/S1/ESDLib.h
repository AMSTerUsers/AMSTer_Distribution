/* 
*  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version. 
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 * 
 *  You should have received a copy of the GNU Affero General Public License 
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**************************************************
 * File name : ESDLib.h
 * Author : Quentin Glaude
 * Date : 2026-07-20 (integration date)
 * Copyright 2026 Quentin Glaude
 * Description : Extended Spectral Diversity implementation
 **************************************************/



#if !defined(__ESDLib__)
#define __ESDLib__

#include "pourtous.h"
#include "initInSARParams.h"
#include "infoImage.h"
#include "infoImageS1.h"
#include "ENVIHeaderManagement.h"


/* ESD debug switches (compile-time; not exposed on the CLI).
* NOTE: ESDlog.txt is ALWAYS written to <project>/TextFiles/ whenever ESD (-e)
* runs, independent of these switches.
*
 * ESD_DEBUG     : write intermediate float32 QC products (DDI phase, mincoh,
 *                 upper/lower coh, upper/lower interf) to
 *                 <project>/InSARProducts/debug/. Lightweight; useful for
 *                 visual QC of each burst overlap.
 * ESD_DEBUG_RAW : additionally dump the raw full-resolution complex overlap
 *                 buffers (master/slave, upper/lower) as .cpx into the same
 *                 debug/ dir. Heavy (~tens of MB per overlap); only needed to
 *                 re-run the offline coherence-vs-shift misregistration proof
 *                 (prove_misreg.py). Leave 0 for normal processing.
 * Set either to 1 and recompile to activate. */
#define ESD_DEBUG     0
#define ESD_DEBUG_RAW 0


#endif