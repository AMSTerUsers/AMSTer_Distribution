
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  RSAT2DataReaderLib.h
//  RSAT2DAtaReader
//
//  Created by Dominique Derauw on 12/02/15.
//  Copyright SAREOS (c) 2015 Dominique Derauw. All rights reserved.
//

#ifndef RSAT2DAtaReader_RSAT2DataReaderLib_h
#define RSAT2DAtaReader_RSAT2DataReaderLib_h

#include <stdio.h>
#include <stdlib.h>
#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "infoImageRSAT2.h"
#include "byteSwap.h"
#include "counters.h"
#include "vectors.h"
#include "matrix.h"
#include "resmat.h"
#include "complexTypes.h"
#include "complexCalculus.h"
#include "stringLib.h"

#include <tiffio.h>
#include <xtiffio.h>
#include <zlib.h>

CSVStruct *RSAT2DataReader(CSVStruct *csv) ;
void RSAT2DataReaderHelp(void) ;
void createRSAT2DataReaderParameterFileAtPath(char *aPath) ;
void copyRSAT2HeaderToCSLImage(CSLImage *aCSLImage, char *productInfoFilePath) ;
void readRSAT2DATALayersInto(CSLImage *image, SLCImageInfo *info, char *RSAT2AccesPath) ;

#endif
