
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  SAOCOMDataReaderLib.h
//  SAOCOMDataReader
//
//  Created by Dominique Derauw on 19/06/20.
//  Copyright (c) 2020 Dominique Derauw. All rights reserved.
//

#ifndef __SAOCOMDataReader__SAOCOMDataReaderLib__
#define __SAOCOMDataReader__SAOCOMDataReaderLib__

#include <stdio.h>

#include <stdio.h>
#include <stdlib.h>
#include "pourtous.h"
#include "paramLib.h"
#include "CSLImageFormat.h"
#include "infoImageSAOCOM.h"
#include "byteSwap.h"
#include "counters.h"
#include "vectors.h"
#include "matrix.h"
#include "resmat.h"
#include "complexTypes.h"
#include "complexCalculus.h"
#include "polynomials.h"
#include "aoiHandling.h"
// #include "S1PreciseOrbitManagement.h"

#include <tiffio.h>
//#include <xtiffio.h>
#include <zlib.h>

#define _SKIP_READING_          0x00000100
#define _AOI_FULLY_INCLUDED_    0x00000200
#define _READ_OVERWRITE_        0x00001000
#define _ORDER_DATA_            0x00002000
#define _BULK_READING_          0x00004000

struct SAOCOMDataFileStruct
{
    size_t numberOfRows ; 
    size_t lineLength ;
    size_t fileHeaderLength ;
    size_t rowHeaderLength ;
    size_t iXMin, iXMax, iYMin, iYMax ;
    char swapBytes ;
} ;

/* Functions prototypes */
CSVStruct *SAOCOMDataReader(CSVStruct *csv) ;
CSVStruct *SAOCOMBulkReaderLoop(CSVStruct *csv, int unsigned flag) ;
void createSAOCOMDataReaderParameterFileAtPath(char *aPath) ;
void SAOCOMDataReaderHelp() ;
int readSAOCOMData(char *inputDataDirectory, CSLImage *thisImage, polygon *aoi, char *pol, unsigned int flag) ;
struct SAOCOMDataFileStruct *getSAOCOMDataFileStruct (char *inputFilePath) ;
void readSAOCOMModeIntoCSLImage(char *inputFilePath, CSLImage *thisImage, struct SAOCOMDataFileStruct *fileStruct) ;
void addaptSAOCOMFileStructToAoI(struct SAOCOMDataFileStruct *fileStruct, polygon *aoi) ;



#endif /* defined(__SAOCOMDataReader__SAOCOMDataReaderLib__) */
