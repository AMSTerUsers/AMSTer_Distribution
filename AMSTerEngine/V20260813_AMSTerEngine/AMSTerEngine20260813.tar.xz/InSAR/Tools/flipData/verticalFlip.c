
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  flipData
//
//  Created by Dominique Derauw on 5/10/16.
//  Copyright (c) 2016 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "rawFileLib.h"
#include "vectors.h"
#include "counters.h"

void usage(void) ;

int main(int argc, const char * argv[]) {
    char *filePath ;
    int unsigned iY ;
    int unsigned xDim, yDim ;
    size_t type ;
    long unsigned seekVal, seekValUp, seekValDown ;
    rawFileDescriptor *inputFile, *outputFile ;
    void *aLign, *lignUp, *lignDown ;
    
    if (argc == 1 || isFlagPresent(argc, argv, "-h")) {
        usage() ;
    }
    
    
    inputFile = openRawFileForReadingAndWritingAtPath((char *)argv[1]) ;
    sscanf(argv[2], "%d", &xDim) ;
    sscanf(argv[3], "%d", &yDim) ;
    type = (size_t)(inputFile->fileLength / xDim / yDim) ;

    if (isFlagPresent(argc, argv, "-i")) {
        lignUp = vectorOfType(0, xDim - 1, type) ;
        lignDown = vectorOfType(0, xDim - 1, type) ;
        seekValDown = xDim * (yDim - 1) * type ;
        seekValUp = 0 ;
        
        for (iY = 0; iY < yDim / 2; iY++) {
            fseek(inputFile->f, seekValUp, SEEK_SET) ;
            fread(lignUp, type, xDim, inputFile->f) ;

            fseek(inputFile->f, seekValDown, SEEK_SET) ;
            fread(lignDown, type, xDim, inputFile->f) ;
            fseek(inputFile->f, seekValDown, SEEK_SET) ;
            fwrite(lignUp, type, xDim, inputFile->f) ;

            fseek(inputFile->f, seekValUp, SEEK_SET) ;
            fwrite(lignDown, type, xDim, inputFile->f) ;
            
            seekValDown -= xDim * type ;
            seekValUp += xDim * type ;
        }
        
        freeVectorOfType(lignDown, 0, type) ;
        freeVectorOfType(lignUp, 0, type) ;

    }
    else {
        filePath = initStringWith2Strings(inputFile->accesPath, ".flipped") ;
        outputFile = openRawFileForReadingAndWritingAtPath(filePath) ;

        seekVal = xDim * (yDim - 1) * type ;
        aLign = vectorOfType(0, xDim - 1, type) ;
        
        for (iY = yDim; iY != 0; iY--) {
            fseek(inputFile->f, seekVal, SEEK_SET) ;
            fread(aLign, type, xDim, inputFile->f) ;
            fwrite(aLign, type, xDim, outputFile->f) ;
            seekVal -= xDim * type ;
        }
        
        freeVectorOfType(aLign, 0, type) ;
    }
    return 0;
}

void usage(void)
{
    printf("Usage:\nverticalFlip filePath xDim yDim [-i]") ;
    printf("\tData file given in input will be flipped vertically\n") ;
    printf("\tBy default, rasult is saved at the same location than \n\tthe input image with a .flipped extension\n") ;
    printf("\t-i: If using the -i option, flipping is done in place\n") ;
}
