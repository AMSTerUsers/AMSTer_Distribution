
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  interpolFloat.h
 *  interpolFloat
 *
 *  Created by Dominique Derauw on 20/09/07.
 *  Copyright 2007 CSL. All rights reserved.
 *
 */

#include "pourtous.h"
#include "complexTypes.h"
#include "complexCalculus.h"
#include "fft.h"
#include "interpolCZT.h"
#include "vectors.h"
#include "fileAccessLib.h"
#include "rawFileLib.h"
#include "paramLib.h"
#include "counters.h"

#define BLOCSIZE 256 * 1024 * 1024 /* Mb */
#define _MIRRORING_ 0x0001
#define _FILTERING_ 0x0002

void	interpolFloatAlongXAxis(rawFileDescriptor *, double **, rawFileDescriptor *, int flag) ;
void	interpolFloatAlongYAxis(rawFileDescriptor *, double **, rawFileDescriptor *, int flag) ;
void	interpolInterfAlongXAxis(rawFileDescriptor *, double **, rawFileDescriptor *, int flag) ;
void	interpolInterfAlongYAxis(rawFileDescriptor *, double **, rawFileDescriptor *, int flag) ;
void	interpolComplexAlongXAxis(rawFileDescriptor *, double **, rawFileDescriptor *, int flag) ;
void	interpolComplexAlongYAxis(rawFileDescriptor *, double **, rawFileDescriptor *, int flag) ;
void	usage()  ;
void	createParameterFileAtPath(char *) ;
