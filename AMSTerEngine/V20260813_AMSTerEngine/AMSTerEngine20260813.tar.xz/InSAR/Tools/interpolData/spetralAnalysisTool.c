
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include <stdio.h>
#include "pourtous.h"
#include "rawFileLib.h"
#include "fft.h"
#include "complexCalculus.h"
#include "interpolCZT.h"

void usage(void)  ;


int main (int argc, const char * argv[]) {
	char *aString = NULL, *inputFilePath, *outputFilePath, *tempFilePath ;
	char *outputDir ;
	int i, iX, iY ;
	int xDim, yDim ;
	int xDimOut, yDimOut ;
	int rX, rY ;
	int filterLength ;
	float *floatData, *filter ;
	complexFloat **complexData, *aNullLine ;
	rawFileDescriptor *inputFile, *outputFile, *tempFile ;
	StructFFT *FFTStruct ;
    time_t startTime, endTime ;
	
	if(argc < 3 || isFlagPresent(argc, argv, "h")) {
		usage() ;
	}

	time(&startTime) ;

	/* Get input/output file location */
	if (fileExistsAtPath((char *)argv[1])) {
		inputFilePath = initStringWithString((char *)argv[1]) ;
	}
	if (!isWriteAccessGrantedAtPath(inputFilePath)) {
		free(inputFilePath) ;
		ase("Write access not granted in input file directory\n") ;
	}

	/* Get file X dimension */
	sscanf(argv[2], "%d", &xDim) ;
	if (!xDim) {
		ase("Read input file X dimension is zero....") ;
	}

	/* Get reduction factors */
	rX = rY = 0 ;
	for (i = 3; i < argc; i++)  {
		if (!strncmp(argv[i], "x", 1)) {
			sscanf(argv[i], "x%d", &rY) ;
		}
		if (!strncmp(argv[i], "y", 1)) {
			sscanf(argv[i], "y%d", &rX) ;
		}
	}
	if (!rX && !rY) {
		ase("Failed to read reduction factors\n") ;
	}
	
	/* Open input file */
	inputFile = openRawFileForReadingAtPath(inputFilePath) ;
	inputFile->xDim = xDimOut = xDim ;
	inputFile->yDim = yDimOut = yDim = inputFile->fileLength / xDim / 8 ;

	/* Compute output dimension */
	outputDir = getDirectoryPathFromPath(inputFilePath) ;
	tempFilePath = initStringWith2Strings(outputDir, "tempFile") ;
	tempFile = allocFileDescriptorForPath(tempFilePath) ;
	if(rX) {
		yDimOut = ceil2ofIntVal(yDim) ;
		tempFile->yDim = yDimOut ;
	}
	if(rY) {
		xDimOut = ceil2ofIntVal(xDim) ;
		tempFile->xDim = xDimOut ;
	}
	if(rX) {
		xDimOut /= rX ;
		aString = initStringWithString(".yps") ;
	}
	if(rY) {
		yDimOut /= rY ;
		if (aString) {
			free(aString) ;
			aString = initStringWithString(".xyps") ;
		}
		else {
			aString = initStringWithString(".xps") ;
		}
	}

	/* Create output file */
	sprintf(aComment, ".%dX%d", xDimOut, yDimOut) ;
	outputFilePath = initStringWith3Strings(inputFilePath, aComment, aString) ;
	outputFile = openRawFileForReadingAndWritingAtPath(outputFilePath) ;

	filterLength = 2 * 60 ;
	filter = allocAndInitCosineSumFilterOfLength(filterLength, 0.5) ;

	if (rY) {
		complexData = matrixComplexFloat(0, rY - 1, 0, xDimOut - 1) ;
		aNullLine = vectorComplexFloat(0, xDimOut - 1) ;
		floatData = vectorFloat(0, xDimOut) ;

		FFTStruct = initFFT(xDimOut, rY, ALONGX) ;

		for (iY = 0; iY < yDimOut; iY++) {					
			for (i = 0; i < rY; i++) {
				memcpy(complexData[i], aNullLine, sizeof(complexFloat) * xDimOut) ;
				fread(complexData[i], sizeof(complexFloat), xDim, inputFile->f) ;
			}

			fftX(FORWARD_FFT, complexData[0], FFTStruct) ;
/*			
			for (i = 0; i < rY; i++) {
				for (iX = 0; iX < filterLength / 2; iX++) {
					complexData[i][iX] = mRC(complexData[i][iX], filter[iX + filterLength / 2]) ;
				}
				for (; iX< xDimOut - filterLength/2; iX++) {
					complexData[i][iX] = mRC(complexData[i][iX], 0.) ;
				}
			}
			fftX(INVERSE_FFT, complexData[0], FFTStruct) ;
*/
			memcpy(floatData, aNullLine, sizeof(float) * xDimOut) ;
			for (iX = 0; iX < xDimOut; iX++) {
				for (i = 0; i < rY; i++) {
					floatData[iX] += sqmC(complexData[i][iX]) ;
				}
				floatData[iX] /= rY ;
			}
			fwrite(floatData, xDimOut, sizeof(float), outputFile->f) ;
		}
	}
	
	time(&endTime) ;
	duration(startTime, endTime) ;

	unlink(tempFilePath) ;
	freeRawFileDescriptor(inputFile) ;
	freeRawFileDescriptor(outputFile) ;
	freeRawFileDescriptor(tempFile) ;

	freeVectorFloat(filter, 0) ;
	freeVectorFloat(floatData, 0) ;
	freeVectorComplexFloat(aNullLine, 0) ;
	freeMatrixComplexFloat(complexData, 0, 0) ;

	free(outputDir) ;
	free(inputFilePath) ;
	free(outputFilePath) ;
	free(tempFilePath) ;

	return 0 ;
}


void usage(void) 
{
	printf("spectralAnalysisTool\n") ;
	printf("This is a very basic tool to generate average power spectrum in one or the other dimension of an imput complex (float - float) imag\n") ;
	printf("Usage: \nspectralAnalysisTool /path/To/inputData xDim xN yN") ;
	printf("xDim is the xDimension of the file in pixels\n") ; 
	printf("xN where N is an integer number of lines: power spectrum along x dimension will be calculated and averaged on N lines\n") ;
	printf("yN where N is an integer number of column: power spectrum along y dimension will be calculated and averaged on N columns\n") ;
//	printf("If both xN and yN are present, logically, it is the 2D average power spectrum that will be computed\n") ;
	printf("Power spectrum image is saved in the same directory than input image with the same name adding an extension stating the process and the dimension of the file.\n") ;
	exit(0) ;
}

