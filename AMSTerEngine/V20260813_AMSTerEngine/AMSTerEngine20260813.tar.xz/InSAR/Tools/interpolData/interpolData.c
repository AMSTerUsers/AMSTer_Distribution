
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include <stdio.h>
#include "interpol.h"

int main (int argc, const char * argv[]) {
	char *aString, *inputFilePath, *outputFilePath, *fileType ;
	int flag = 0 ;
	double	**transformCoefficients, **inverseTransform ;
	polygon *aoi, *aoi2 ;
	keyValue *paramList ;
	rawFileDescriptor *inputFile, *outputFile, *tempFile ;
    time_t startTime, endTime ;

	if(argc == 1) usage() ;
	flag |= (isFlagPresent(argc, argv, "m"))? _MIRRORING_ : flag ;
	flag |= (isFlagPresent(argc, argv, "f"))? _FILTERING_ : flag ;
	
	if(argc == 1 || isFlagPresent(argc, argv, "h")) {
		usage() ;
	}
	if(isArgumentPresent(argc, argv, "-create")) {
		createParameterFileAtPath((char *)argv[1]) ;
	}
	time(&startTime) ;
    
	/* Allocate transform */
	transformCoefficients = (double **)matrixDouble(0, 3, 0, 2) ;
	
	/* Read parameter File */ 
	paramList = readParameterFileAtPath((char *)argv[1]) ;
	
	/* Get input/output file location */
	if((aString = getStringValForKeyIn(paramList, "input file path")) == NULL)
		ase("Missing parameter: \"input file path\"") ;
	inputFilePath = readFirstStringIn(aString) ;
	if((inputFile = openRawFileForReadingAtPath(inputFilePath)) == NULL) {
		sprintf(aComment, "Unable to open file for reading at path: %s\n", inputFilePath) ;
		ase(aComment) ;
	}
	
	if((aString = getStringValForKeyIn(paramList, "output file path")) == NULL)
		ase("Missing parameter: \"output file path\"") ;
	outputFilePath = readFirstStringIn(aString) ;
	if((outputFile = openRawFileForWritingAtPath(outputFilePath)) == NULL) {
		sprintf(aComment, "Unable to open file for writting at path: %s\n", outputFilePath) ;
		ase(aComment) ;
	}

	
	/* Get X/Y dimensions */
	if((aString = getStringValForKeyIn(paramList, "input x dimension")) == NULL)
		ase("Missing parameter: \"input x dimension\"") ;
	sscanf(aString, "%d", &(inputFile->xDim)) ;
	outputFile->xDim = inputFile->xDim ;
	if((aString = getStringValForKeyIn(paramList, "input y dimension")) == NULL)
		ase("Missing parameter: \"input y dimension\"") ;
	sscanf(aString, "%d", &(inputFile->yDim)) ;
	outputFile->yDim = inputFile->yDim ;
	
	if((aString = getStringValForKeyIn(paramList, "output x dimension")) != NULL)
		sscanf(aString, "%d", &(outputFile->xDim)) ;
	if((aString = getStringValForKeyIn(paramList, "output y dimension")) != NULL)
		sscanf(aString, "%d", &(outputFile->yDim)) ;

	/* Get input file type */
	fileType = getStringValForKeyIn(paramList, "data file type") ;

	/* Get transform coefficients */
    transformCoefficients[0][0] = getDoubleValForKeyIn(paramList, "Ax") ;
    transformCoefficients[0][1] = getDoubleValForKeyIn(paramList, "Bx") ;
    transformCoefficients[0][2] = getDoubleValForKeyIn(paramList, "Cx") ;
    transformCoefficients[1][0] = getDoubleValForKeyIn(paramList, "Ay") ;
    transformCoefficients[1][1] = getDoubleValForKeyIn(paramList, "By") ;
    transformCoefficients[1][2] = getDoubleValForKeyIn(paramList, "Cy") ;

	if (outputFile->xDim == 0 || outputFile->yDim == 0) {
		aoi = allocQuadrilateral() ;
		aoi->P[0].x = aoi->P[3].x = 0 ;
		aoi->P[0].y = aoi->P[1].y = 0 ;
		aoi->P[1].x = aoi->P[2].x = inputFile->xDim - 1 ;
		aoi->P[2].y = aoi->P[3].y = inputFile->yDim - 1 ;
		inverseTransform = inversePlaneAffineTransform(transformCoefficients, NULL) ;
		aoi = planeAffineTransformOfPolygon(aoi, aoi, inverseTransform) ;
		aoi2 = circumscribedRectangleOfPolygon(aoi) ;
		freePolygon(aoi) ;
		aoi = aoi2 ;

		outputFile->xDim = aoi->P[2].x - aoi->P[0].x + 1 ;
		outputFile->yDim = aoi->P[2].y - aoi->P[0].y + 1 ;
		planeAffineTransformOfCoord2D(aoi->P, aoi->P, transformCoefficients) ;
		transformCoefficients[0][2] += aoi->P[0].x ;
		transformCoefficients[1][2] += aoi->P[0].y ;
		printf("output dimensions: %d X %d\n", outputFile->xDim, outputFile->yDim) ;

		setIntValForKeyIn(paramList, outputFile->xDim, "output x dimension") ;
		setIntValForKeyIn(paramList, outputFile->yDim, "output y dimension") ;
		setDoubleValForKeyIn(paramList, transformCoefficients[0][2], "Cx") ;
		setDoubleValForKeyIn(paramList, transformCoefficients[1][2], "Cy") ;
		writeParameterFileAtPath(paramList, (char *)argv[1]) ;
		freeMatrixDouble(inverseTransform, 0, 0) ;
	}
	
	
	sprintf(accessPath, "%s/tempFile", outputFile->directoryPath) ;
	tempFile = openRawFileForReadingAndWritingAtPath(accessPath) ;
	tempFile->xDim = outputFile->xDim ;
	tempFile->yDim = inputFile->yDim ;
	
	printf("Data interpolation:\n") ;
	printf("Input file: %s\n", inputFile->accessPath) ;
	printf("Output file: %s\n", outputFile->accessPath) ;
	printf("Applied transform: \n") ;
	printf("x2 = %-7.3f * x1 + %-7.3f * y1 + %-7.3f\n", transformCoefficients[0][0], transformCoefficients[0][1], transformCoefficients[0][2]) ;
	printf("y2 = %-7.3f * x1 + %-7.3f * y1 + %-7.3f\n", transformCoefficients[1][0], transformCoefficients[1][1], transformCoefficients[1][2]) ;
	printf("Input dimension: xDim = %d\tyDim = %d\n", inputFile->xDim, inputFile->yDim) ;
	printf("Output dimension: xDim = %d\tyDim = %d\n", outputFile->xDim, outputFile->yDim) ;
    
    /* Get frequency shifts if present */
    transformCoefficients[2][0] = getDoubleValForKeyIn(paramList, "X frequency shift") ;
    transformCoefficients[2][1] = getDoubleValForKeyIn(paramList, "X sampling frequency") ;
    transformCoefficients[3][0] = getDoubleValForKeyIn(paramList, "Y frequency shift") ;
    transformCoefficients[3][1] = getDoubleValForKeyIn(paramList, "Y sampling frequency") ;
	
	if(!strncmp(fileType, "float", 5)) {
		printf("Data type: Float\n") ;
		/* X dimension interpolation */ 
//		if (transformCoefficients[0][0] != 1. || transformCoefficients[0][1] != 0. || transformCoefficients[0][2] != 0.) {
			interpolFloatAlongXAxis(inputFile, transformCoefficients, tempFile, flag) ;
//		}
		/* Y dimension interpolation */ 
//		if (transformCoefficients[1][0] != 0. || transformCoefficients[1][1] != 1. || transformCoefficients[1][2] != 0.) {
			interpolFloatAlongYAxis(tempFile, transformCoefficients, outputFile, flag) ;
//		}
	}
	else if(!strncmp(fileType, "complex", 7)) {
		printf("Data type: Complex float\n") ;
		/* X dimension interpolation */ 
		if (transformCoefficients[0][0] != 1. || transformCoefficients[0][1] != 0. || transformCoefficients[0][2] != 0.) {
			if (transformCoefficients[1][0] != 0. || transformCoefficients[1][1] != 1. || transformCoefficients[1][2] != 0.) {
				interpolComplexAlongXAxis(inputFile, transformCoefficients, tempFile, flag) ;
			}
			else {
				interpolComplexAlongXAxis(inputFile, transformCoefficients, outputFile, flag) ;
			}
		}
		/* Y dimension interpolation */ 
		if (transformCoefficients[1][0] != 0. || transformCoefficients[1][1] != 1. || transformCoefficients[1][2] != 0.) {
			if (transformCoefficients[0][0] != 1. || transformCoefficients[0][1] != 0. || transformCoefficients[0][2] != 0.) {
				interpolComplexAlongYAxis(tempFile, transformCoefficients, outputFile, flag) ;
			}
			else {
				interpolComplexAlongYAxis(inputFile, transformCoefficients, outputFile, flag) ;
			}
		}
	}
	else if(!strncmp(fileType, "interf", 6)) {
		printf("Data type: interf (phase float)\n") ;
		/* X dimension interpolation */ 
//		if (transformCoefficients[0][0] != 1. || transformCoefficients[0][1] != 0. || transformCoefficients[0][2] != 0.) {
			interpolInterfAlongXAxis(inputFile, transformCoefficients, tempFile, flag) ;
//		}
		/* Y dimension interpolation */ 
//		if (transformCoefficients[1][0] != 0. || transformCoefficients[1][1] != 1. || transformCoefficients[1][2] != 0.) {
			interpolInterfAlongYAxis(tempFile, transformCoefficients, outputFile, flag) ;
//		}
	}
	else ase("data type not suported") ;
	
    time(&endTime) ;
    duration(startTime, endTime) ;
    
	unlink(accessPath) ;
	freeMatrixDouble(transformCoefficients, 0, 0) ;
	freeKeyValueList(paramList) ;
	
	return 0 ;
}

/* X dimension interpolation */ 
void	interpolFloatAlongXAxis(rawFileDescriptor *inputFile, double **T, rawFileDescriptor *outputFile, int flag)
{
	int	i, j, lenX, lenX0, expLenX, xBorder, p, index ;
	float	*aLign, *aNullLine ;
	double D ;
    double frequencyShift, sampling, phaseFactor ;
	complexFloat *u, phasor ;
	CZTInterpolator *V ;
	progressCounter *aCounter ;

	lenX0 = (outputFile->xDim < inputFile->xDim)? inputFile->xDim : outputFile->xDim ;
	lenX = lenX0 ;
	ceil2(&lenX, &expLenX) ;
	xBorder = (lenX - lenX0)/2 ;

	aLign = vectorFloat(0, lenX - 1) ;	
	u = vectorComplexFloat(0, lenX - 1) ;
	aNullLine = vectorFloat(0, lenX - 1) ;	
	for(i = 0; i < lenX; i++)
		aNullLine[i] = 0. ;
	aCounter = initProgressCounterWithMinMaxValue(0, inputFile->yDim) ;

	printf("Interpolation along X axis\n") ;
	
    /* Init interpolator */
	T[0][1] /= T[1][1] ;
	T[0][0] -= T[0][1] * T[1][0] ;
	T[0][2] -= T[0][1] * T[1][2] - (1. - T[0][0]) * xBorder ;
	V = initInterpolator(lenX, T[0][0]) ;
    
    /* Frequency shift */
    frequencyShift = T[2][0] ;
    sampling = T[2][1] ;
    phaseFactor = PI ;
    if(sampling) {
        phaseFactor = 2. * PI *(-frequencyShift / sampling + .5) ;
	}
	for(i = 0; i < inputFile->yDim ; i++)
	{
		memcpy(aLign, aNullLine, lenX * sizeof(float)) ;
		fread ((float *)&aLign[xBorder], inputFile->xDim, sizeof(float), inputFile->f) ;
		
		if(flag & _MIRRORING_) {
			p = xBorder + inputFile->xDim - 1 ;
			while(p < lenX) {
				for(index = p + 1, j = 1; j < inputFile->xDim; index++, j++)
					 if(index < lenX) aLign[index] = aLign[p - j] ;
				p += inputFile->xDim - 1 ;
			}
			p = xBorder ;
			while(p >= 0) {
				for(index = p - 1, j = 1; j < inputFile->xDim; index--, j++)
					 if(index >= 0) aLign[index] = aLign[p + j] ;
				p -= inputFile->xDim - 1 ;
			}
		}


		for(j=0; j<lenX; j++) {
            phasor.r = (float)cos((double)phaseFactor * j) ;
            phasor.i = (float)sin((double)phaseFactor * j) ;
            u[j].r = aLign[j] * phasor.r ;
            u[j].i = aLign[j] * phasor.i ;
		}
        

		D = T[0][1] * i + T[0][2] ;
		CZTInterpolation(u, T[0][0], D, V) ;
        
		for(j=0; j<lenX; j++)
		{
            phasor.r = (float)cos(-phaseFactor * (T[0][0]*j + D))/lenX ;
            phasor.i = (float)sin(-phaseFactor * (T[0][0]*j + D))/lenX ;
			u[j] = mC(phasor, u[j]) ;
		}
		fwrite((complexFloat *)&u[xBorder], outputFile->xDim, sizeof(complexFloat), outputFile->f) ;
		updateProgressCounterForIndex(aCounter, i) ;
	}
	updateProgressCounterForIndex(aCounter, i) ;
	
	freeCZTInterpolator(V) ;
	freeVectorFloat(aLign, 0) ;
	freeVectorFloat(aNullLine, 0) ;
	freeVectorComplexFloat(u, 0) ;
}

/* Y dimension interpolation */ 
void	interpolFloatAlongYAxis(rawFileDescriptor *inputFile, double **T, rawFileDescriptor *outputFile, int flag)
{
	int	i, j, k, lenY, lenY0, expLenY, yBorder, p, index ;
	int	xDimBloc, xDimLastBloc, NBlocs, xIndex ;
	long inputFileShift, outputFileShift ;
	float *outputLine ;
	double D ;
    double frequencyShift, sampling, phaseFactor ;
	complexFloat *u, phasor ;
	complexFloat	**aBloc, **aNullBloc ;
	CZTInterpolator *V ;
	progressCounter *aCounter ;

	printf("\nInterpolation along Y axis\n") ;
	
	lenY0 = (outputFile->yDim < inputFile->yDim)? inputFile->yDim : outputFile->yDim ;
	lenY = lenY0 ;
	ceil2(&lenY, &expLenY) ;
	yBorder= (lenY - lenY0)/2 ;
	
	xDimBloc = BLOCSIZE / lenY / sizeof(complexFloat) ;
	NBlocs = inputFile->xDim / xDimBloc ;
	xDimLastBloc = inputFile->xDim - NBlocs * xDimBloc ;
	if(!NBlocs) xDimBloc = xDimLastBloc ;
	inputFileShift = (long)(inputFile->xDim - xDimBloc) * sizeof(complexFloat) ;
	outputFileShift = (long)(outputFile->xDim - xDimBloc) * sizeof(float) ;

	aBloc = (complexFloat **)matrixComplexFloat(0, lenY - 1, 0, xDimBloc - 1) ;
	aNullBloc = (complexFloat **)matrixComplexFloat(0, lenY - 1, 0, xDimBloc - 1) ;
	for(i = 0; i < lenY; i++) {
		for(j = 0; j < xDimBloc; j++) {
			aNullBloc[i][j].r = aNullBloc[i][j].i = 0. ;
		}
	}
	outputLine = vectorFloat(0, xDimBloc - 1) ;
	
	V = initInterpolator(lenY, T[1][1]) ;
	u = vectorComplexFloat(0, lenY) ;
	aCounter = initProgressCounterWithMinMaxValue(0, outputFile->xDim) ;

    /* Frequency shift */
    frequencyShift = T[3][0] ;
    sampling = T[3][1] ;
    phaseFactor = PI ;
    if(sampling) {
        phaseFactor = 2. * PI *(-frequencyShift / sampling + .5) ;
	}
	for(k = 0; k <= NBlocs; k++) {
		xIndex = k * xDimBloc ;
		memcpy(aBloc[0], aNullBloc[0], xDimBloc * lenY * sizeof(complexFloat)) ;
		
		if(k == NBlocs) {
			xDimBloc = xDimLastBloc ;
			inputFileShift = (long)(inputFile->xDim - xDimBloc) * sizeof(complexFloat) ;
			outputFileShift = (long)(outputFile->xDim - xDimBloc) * sizeof(float) ;
		}
		
		fseek(inputFile->f, xIndex * sizeof(complexFloat), SEEK_SET) ;
		for(i = 0; i < inputFile->yDim; i++) {
			fread((complexFloat *)aBloc[i + yBorder], xDimBloc, sizeof(complexFloat), inputFile->f) ;
			fseek(inputFile->f, inputFileShift, SEEK_CUR) ;
		}
	
		for(i = 0; i < xDimBloc; i++) {
			if(flag & _MIRRORING_) {
				p = yBorder + inputFile->yDim - 1 ;
				while(p < lenY) {
					for(index = p + 1, j = 1; j < inputFile->yDim; index++, j++)
						 if(index < lenY) aBloc[index][i] = aBloc[p - j][i] ;
					p += inputFile->yDim - 1 ;
				}
				p = yBorder ;
				while(p >= 0) {
					for(index = p - 1, j = 1; j < inputFile->yDim; index--, j++)
						 if(index >= 0) aBloc[index][i] = aBloc[p + j][i] ;
					p -= inputFile->yDim - 1 ;
				}
			}

			for(j = 0; j < lenY; j++) {
				phasor.r = (float)cos((double)phaseFactor * j) ;
				phasor.i = (float)sin((double)phaseFactor * j) ;
                u[j] = mC(aBloc[j][i], phasor) ;
			}
		
			D = T[1][0] * (i + xIndex) + T[1][2] + (1. - T[1][1]) * yBorder ;
			CZTInterpolation(u, T[1][1], D, V) ;

			for(j = yBorder; j < lenY - yBorder; j++) {
				phasor.r = (float)cos(-phaseFactor * (T[1][1]*j + D))/lenY ;
				phasor.i = (float)sin(-phaseFactor * (T[1][1]*j + D))/lenY ;
				aBloc[j][i] = mC(phasor, u[j]) ;
			}
			updateProgressCounterForIndex(aCounter, i + xIndex) ;
		}
		
		fseek(outputFile->f, xIndex * sizeof(float), SEEK_SET) ;

		for(i = 0; i < outputFile->yDim; i++) {
			for(j = 0; j < xDimBloc; j++)
				outputLine[j] = (aBloc[i + yBorder][j]).r ;
			fwrite((float *)outputLine, (int unsigned)xDimBloc, sizeof(float), outputFile->f) ;
			fseek(outputFile->f, outputFileShift, SEEK_CUR) ;
		}

	}	
	updateProgressCounterForIndex(aCounter, outputFile->xDim) ;
	
	freeMatrixComplexFloat(aBloc, 0, 0) ;
	freeVectorComplexFloat(u, 0) ;
	freeCZTInterpolator(V) ;
}

/* X dimension interpolation */ 
void	interpolComplexAlongXAxis(rawFileDescriptor *inputFile, double **T, rawFileDescriptor *outputFile, int flag)
{
	int	i, j, lenX, lenX0, expLenX, xBorder, p, index ;
	complexFloat	*aLign, *aNullLine ;
	double D ;
    double frequencyShift, sampling, phaseFactor ;
	complexFloat *u, phasor ;
	CZTInterpolator *V ;
	progressCounter *aCounter ;
	
	lenX0 = (outputFile->xDim < inputFile->xDim)? inputFile->xDim : outputFile->xDim ;
	lenX = lenX0 ;
	ceil2(&lenX, &expLenX) ;
	xBorder = (lenX - lenX0)/2 ;
	
	aLign = vectorComplexFloat(0, lenX - 1) ;
	u = vectorComplexFloat(0, lenX - 1) ;
	aNullLine = vectorComplexFloat(0, lenX - 1) ;	
	for(i = 0; i < lenX; i++) {
		aNullLine[i].r = aNullLine[i].i = 0. ;
	}

	aCounter = initProgressCounterWithMinMaxValue(0, inputFile->yDim) ;

	printf("Interpolation along X axis\n") ;
	
    /* Init interpolator */
	T[0][1] /= T[1][1] ;
	T[0][0] -= T[0][1] * T[1][0] ;
	T[0][2] -= T[0][1] * T[1][2]  - (1. - T[0][0]) * xBorder ;
	V = initInterpolator(lenX, T[0][0]) ;
	if (flag & _FILTERING_) {
		allocAndInitCosineSumFilterInCZTInterpolator(V, .54) ;
	}
	
    /* Frequency shift */
    frequencyShift = T[2][0] ;
    sampling = T[2][1] ;
    phaseFactor = PI ;
    if(sampling) {
        phaseFactor = 2. * PI *(-frequencyShift / sampling + .5) ;
	}
    
    for(i = 0; i < inputFile->yDim ; i++)
	{
		memcpy(aLign, aNullLine, lenX * sizeof(complexFloat)) ;
		fread ((complexFloat *)&aLign[xBorder], inputFile->xDim, sizeof(complexFloat), inputFile->f) ;

		if(flag & _MIRRORING_) {
			p = xBorder + inputFile->xDim - 1 ;
			while(p < lenX) {
				for(index = p + 1, j = 1; j < inputFile->xDim; index++, j++)
					 if(index < lenX) {
						aLign[index].r = aLign[p - j].r ;
						aLign[index].i = aLign[p - j].i ;
					}
				p += inputFile->xDim - 1 ;
			}
			p = xBorder ;
			while(p >= 0) {
				for(index = p - 1, j = 1; j < inputFile->xDim; index--, j++)
					 if(index >= 0) {
						aLign[index].r = aLign[p + j].r ;
						aLign[index].i = aLign[p + j].i ;
					}
				p -= inputFile->xDim - 1 ;
			}
		}

		for(j=0; j<lenX; j++) {
            phasor.r = (float)cos((double)phaseFactor * j) ;
            phasor.i = (float)sin((double)phaseFactor * j) ;
			u[j] = mC(aLign[j], phasor) ; 
			if (flag & _FILTERING_) {
			}
		}

		D = T[0][1] * i + T[0][2] ;
		CZTInterpolation(u, T[0][0], D, V) ;

		for(j=0; j<lenX; j++)
		{
            phasor.r = (float)cos(-phaseFactor * (T[0][0]*j + D))/lenX ;
            phasor.i = (float)sin(-phaseFactor * (T[0][0]*j + D))/lenX ;
			aLign[j] = mC(phasor, u[j]) ;
		}
		fwrite((complexFloat *)&aLign[xBorder], outputFile->xDim, sizeof(complexFloat), outputFile->f) ;
		updateProgressCounterForIndex(aCounter, i) ;
	}
	updateProgressCounterForIndex(aCounter, i) ;
	
	freeCZTInterpolator(V) ;
	freeVectorComplexFloat(aLign, 0) ;
	freeVectorComplexFloat(u, 0) ;
}

/* Y dimension interpolation */ 
void	interpolComplexAlongYAxis(rawFileDescriptor *inputFile, double **T, rawFileDescriptor *outputFile, int flag)
{
	int	i, j, k, lenY, lenY0, expLenY, yBorder, p, index ;
	int	xDimBloc, xDimLastBloc, NBlocs, xIndex ;
//	fpos_t fileShift ;
	long fileShift ;
	complexFloat	**aBloc, **aNullBloc ;
	double D ;
    double frequencyShift, sampling, phaseFactor ;
	complexFloat *u, phasor ;
	CZTInterpolator *V ;
	progressCounter *aCounter ;
    
	printf("\nInterpolation along Y axis\n") ;
	
	lenY0 = (outputFile->yDim < inputFile->yDim)? inputFile->yDim : outputFile->yDim ;
	lenY = lenY0 ;
	ceil2(&lenY, &expLenY) ;
	yBorder= (lenY - lenY0)/2 ;
    
	
	xDimBloc = BLOCSIZE / lenY / sizeof(complexFloat) ;
	NBlocs = inputFile->xDim / xDimBloc ;
	xDimLastBloc = inputFile->xDim - NBlocs * xDimBloc ;
	
printf("lenY = %d\tyBorder = %d\n", lenY, yBorder) ;
printf("xDimBloc = %d\txDimLastBloc = %d\n", xDimBloc, xDimLastBloc) ;
printf("NBlocs = %d\txDimLastBloc = %d\n", NBlocs, xDimLastBloc) ;
/*
	printf("Creating output file\n") ;
	aNullVector = vectorComplexFloat(0, outputFile->xDim - 1) ;
	for(i = 0; i < outputFile->yDim; i++) {
		fwrite((complexFloat *)aNullVector, outputFile->xDim, sizeof(complexFloat), outputFile->f) ;
	}
	fflush(outputFile->f) ;
	freeVectorComplexFloat(aNullVector, 0) ;
*/		
	aBloc = (complexFloat **)matrixComplexFloat(0, lenY - 1, 0, xDimBloc - 1) ;
	aNullBloc = (complexFloat **)matrixComplexFloat(0, lenY - 1, 0, xDimBloc - 1) ;
	for(i = 0; i < lenY; i++) {
		for(j = 0; j < xDimBloc; j++) {
			aNullBloc[i][j].r = aNullBloc[i][j].i = 0. ;
		}
	}
	
	V = initInterpolator(lenY, T[1][1]) ;
	if (flag & _FILTERING_) {
		allocAndInitCosineSumFilterInCZTInterpolator(V, .54) ;
	}
	u = vectorComplexFloat(0, lenY) ;
	aCounter = initProgressCounterWithMinMaxValue(0, outputFile->xDim) ;
    
    /* Frequency shift */
    frequencyShift = T[3][0] ;
    sampling = T[3][1] ;
    phaseFactor = PI ;
    if(sampling) {
        phaseFactor = 2. * PI *(-frequencyShift / sampling + .5) ;
	}

	for(k = 0; k <= NBlocs; k++) {
		xIndex = k * xDimBloc ;
		memcpy(aBloc[0], aNullBloc[0], xDimBloc * lenY * sizeof(complexFloat)) ;

		if(k == NBlocs) {
			xDimBloc = xDimLastBloc ;
		}
		
		for(i = 0; i < inputFile->yDim; i++) {
			fileShift = (i * inputFile->xDim + xIndex) * sizeof(complexFloat) ;
			if(fseek(inputFile->f, fileShift, SEEK_SET))
//			fileShift = ((fpos_t)i * inputFile->xDim + xIndex) * sizeof(complexFloat) ;
//			if(fsetpos(inputFile->f, &fileShift))
				ase("Failed to seek in input file before reading");
			fread((complexFloat *)aBloc[i + yBorder], xDimBloc, sizeof(complexFloat), inputFile->f) ;
		}

        
		for(i = 0; i < xDimBloc; i++) {
			if(flag & _MIRRORING_) {
				p = yBorder + inputFile->yDim - 1 ;
				while(p < lenY) {
					for(index = p + 1, j = 1; j < inputFile->yDim; index++, j++)
						 if(index < lenY) {
							aBloc[index][i] = aBloc[p - j][i] ;
						}
					p += inputFile->yDim - 1 ;
				}
				p = yBorder ;
				while(p >= 0) {
					for(index = p - 1, j = 1; j < inputFile->yDim; index--, j++)
						 if(index >= 0) {
							aBloc[index][i] = aBloc[p + j][i] ;
						}
					p -= inputFile->yDim - 1 ;
				}
			}
			
			for(j = 0; j < lenY; j++) {
				phasor.r = (float)cos((double)phaseFactor * j) ;
				phasor.i = (float)sin((double)phaseFactor * j) ;
                u[j] = mC(aBloc[j][i], phasor) ;
			}
		
			D = T[1][0] * (i + xIndex) + T[1][2] + (1. - T[1][1]) * yBorder ;
			CZTInterpolation(u, T[1][1], D, V) ;
            
			for(j = yBorder; j < lenY - yBorder; j++) {
				phasor.r = (float)cos(-phaseFactor * (T[1][1]*j + D))/lenY ;
				phasor.i = (float)sin(-phaseFactor * (T[1][1]*j + D))/lenY ;
				aBloc[j][i] = mC(phasor, u[j]) ;
			}
			updateProgressCounterForIndex(aCounter, i + xIndex) ;
		}
		
		for(i = 0; i < outputFile->yDim; i++) {
			fileShift = (i * outputFile->xDim + xIndex) * sizeof(complexFloat) ;
			if(fseek(outputFile->f, fileShift, SEEK_SET))
//			fileShift = ((fpos_t)i * outputFile->xDim + xIndex) * sizeof(complexFloat) ;
//			if(fsetpos(outputFile->f, &fileShift))
				ase("Failed to seek in output file before writing") ;
			fwrite((complexFloat *)aBloc[i + yBorder], xDimBloc, sizeof(complexFloat), outputFile->f) ;
		}
	}	
	updateProgressCounterForIndex(aCounter, outputFile->xDim) ;
	
	freeMatrixComplexFloat(aBloc, 0, 0) ;
	freeVectorComplexFloat(u, 0) ;
	freeCZTInterpolator(V) ;
}

/* X dimension interpolation */ 
void	interpolInterfAlongXAxis(rawFileDescriptor *inputFile, double **T, rawFileDescriptor *outputFile, int flag)
{
	int	i, j, lenX, lenX0, expLenX, xBorder, p, index ;
	float	*aLign, *aNullLine, minVal, maxVal, norm ;
	double D, c ;
	complexFloat *u, cs ;
	CZTInterpolator *V ;
	progressCounter *aCounter ;
	
	lenX0 = (outputFile->xDim < inputFile->xDim)? inputFile->xDim : outputFile->xDim ;
	lenX = lenX0 ;
	ceil2(&lenX, &expLenX) ;
	xBorder = (lenX - lenX0)/2 ;

	aLign = vectorFloat(0, lenX - 1) ;	
	u = vectorComplexFloat(0, lenX - 1) ;
	aNullLine = vectorFloat(0, lenX - 1) ;	
	for(i = 0; i < lenX; i++)
		aNullLine[i] = 0. ;
	aCounter = initProgressCounterWithMinMaxValue(0, inputFile->yDim) ;

	printf("Interpolation along X axis\n") ;
	
	T[0][1] /= T[1][1] ;
	T[0][0] -= T[0][1] * T[1][0] ;
	T[0][2] -= T[0][1] * T[1][2]  - (1. - T[0][0]) * xBorder ;
	
	/* Find max and min value in interf */
	maxVal = minVal = 0.0 ;
	for(i = 0; i < inputFile->yDim ; i++)
	{
		fread ((float *)aLign, inputFile->xDim, sizeof(float), inputFile->f) ;
		for(j = 0; j < inputFile->xDim; j++) {
			maxVal = (maxVal < aLign[j])? aLign[j] : maxVal ;
			minVal = (minVal > aLign[j])? aLign[j] : minVal ;
		}
	}
	norm = (double)((maxVal - minVal) / TWOPI) ;
	printf("Normalization : min = %f\tmax = %f\tnorm = %f\n", minVal, maxVal, norm) ;
	fseek(inputFile->f, 0L, SEEK_SET) ;


	V = initInterpolator(lenX, T[0][0]) ;
	for(i = 0; i < inputFile->yDim ; i++)
	{
		memcpy(aLign, aNullLine, lenX * sizeof(float)) ;
		fread ((float *)&aLign[xBorder], inputFile->xDim, sizeof(float), inputFile->f) ;
		
		if(flag & _MIRRORING_) {
			p = xBorder + inputFile->xDim - 1 ;
			while(p < lenX) {
				for(index = p + 1, j = 1; j < inputFile->xDim; index++, j++)
					 if(index < lenX) aLign[index] = aLign[p - j] ;
				p += inputFile->xDim - 1 ;
			}
			p = xBorder ;
			while(p >= 0) {
				for(index = p - 1, j = 1; j < inputFile->xDim; index--, j++)
					 if(index >= 0) aLign[index] = aLign[p + j] ;
				p -= inputFile->xDim - 1 ;
			}
		}
		c = -1. ;
		for(j=0; j<lenX; j++) {
			c *= -1. ;
			u[j].r = c * cos((aLign[j] - minVal)/norm) ; 
			u[j].i = c * sin((aLign[j] - minVal)/norm)  ; 
		}

		D = T[0][1] * i + T[0][2] ;
		CZTInterpolation(u, T[0][0], D, V) ;
		for(j=0; j<lenX; j++)
		{
			cs.r = (float)cos(-(double)PI * (T[0][0]*j + D))/lenX ;
			cs.i = (float)sin(-(double)PI * (T[0][0]*j + D))/lenX ;
			aLign[j] = phiC(mC(cs, u[j])) ;
		}
		fwrite((float *)&aLign[xBorder], outputFile->xDim, sizeof(float), outputFile->f) ;
		updateProgressCounterForIndex(aCounter, i) ;
	}
	updateProgressCounterForIndex(aCounter, i) ;
	
	freeCZTInterpolator(V) ;
	freeVectorFloat(aLign, 0) ;
	freeVectorComplexFloat(u, 0) ;
}

/* Y dimension interpolation */ 
void	interpolInterfAlongYAxis(rawFileDescriptor *inputFile, double **T, rawFileDescriptor *outputFile, int flag)
{
	int	i, j, k, lenY, lenY0, expLenY, yBorder, p, index ;
	int	xDimBloc, xDimLastBloc, NBlocs, xIndex ;
	long inputFileShift, outputFileShift ;
	float	*aBloc, *aNullBloc, **anIndexedBloc ;
	double D, c ;
	complexFloat *u, cs ;
	CZTInterpolator *V ;
	progressCounter *aCounter ;

	printf("\nInterpolation along Y axis\n") ;
	
	lenY0 = (outputFile->yDim < inputFile->yDim)? inputFile->yDim : outputFile->yDim ;
	lenY = lenY0 ;
	ceil2(&lenY, &expLenY) ;
	yBorder= (lenY - lenY0)/2 ;

	xDimBloc = BLOCSIZE / lenY / sizeof(float) ;
	NBlocs = inputFile->xDim / xDimBloc ;
	xDimLastBloc = inputFile->xDim - NBlocs * xDimBloc ;
    xDimBloc = (NBlocs)? xDimBloc : xDimLastBloc ;

	inputFileShift = (long)(inputFile->xDim - xDimBloc) * sizeof(float) ;
	outputFileShift = (long)(outputFile->xDim - xDimBloc) * sizeof(float) ;

	aBloc = vectorFloat(0, xDimBloc * lenY) ;
	aNullBloc = vectorFloat(0, xDimBloc * lenY) ;
	if((anIndexedBloc = (float **)(malloc(lenY * sizeof(float *)))) == NULL)
		ase("Failed to index bloc") ;
	for(i = 0; i < lenY; i++)
		anIndexedBloc[i] = &(aBloc[i * xDimBloc]) ;
	
	V = initInterpolator(lenY, T[1][1]) ;
	u = vectorComplexFloat(0, lenY) ;
	aCounter = initProgressCounterWithMinMaxValue(0, outputFile->xDim) ;

	for(k = 0; k <= NBlocs; k++) {
		xIndex = k * xDimBloc ;
		memcpy(aBloc, aNullBloc, xDimBloc * lenY * sizeof(float)) ;

		if(k == NBlocs) {
			xDimBloc = xDimLastBloc ;
			inputFileShift = (long)(inputFile->xDim - xDimBloc) * sizeof(float) ;
			outputFileShift = (long)(outputFile->xDim - xDimBloc) * sizeof(float) ;
		}
		
		fseek(inputFile->f, xIndex * sizeof(float), SEEK_SET) ;
		for(i = 0; i < inputFile->yDim; i++) {
			fread((float *)anIndexedBloc[i + yBorder], xDimBloc, sizeof(float), inputFile->f) ;
			fseek(inputFile->f, inputFileShift, SEEK_CUR) ;
		}
	
		for(i = 0; i < xDimBloc; i++) {
			if(flag & _MIRRORING_) {
				p = yBorder + inputFile->yDim - 1 ;
				while(p < lenY) {
					for(index = p + 1, j = 1; j < inputFile->yDim; index++, j++)
						 if(index < lenY) anIndexedBloc[index][i] = anIndexedBloc[p - j][i] ;
					p += inputFile->yDim - 1 ;
				}
				p = yBorder ;
				while(p >= 0) {
					for(index = p - 1, j = 1; j < inputFile->yDim; index--, j++)
						 if(index >= 0) anIndexedBloc[index][i] = anIndexedBloc[p + j][i] ;
					p -= inputFile->yDim - 1 ;
				}
			}
			
			c = -1. ;
			for(j = 0; j < lenY; j++) {
				c *= -1. ;				
				u[j].r = c * cos(anIndexedBloc[j][i]) ; 
				u[j].i = c * sin(anIndexedBloc[j][i]) ; 
			}
		
			D = T[1][0] * (i + xIndex) + T[1][2] + (1. - T[1][1]) * yBorder ;
			CZTInterpolation(u, T[1][1], D, V) ;

			for(j = yBorder; j < lenY - yBorder; j++) {
				cs.r = (float)cos(-(double)PI * (T[1][1]*j + D))/lenY ;
				cs.i = (float)sin(-(double)PI * (T[1][1]*j + D))/lenY ;
				anIndexedBloc[j][i] = phiC(mC(cs, u[j])) ;
			}
			updateProgressCounterForIndex(aCounter, i + xIndex) ;
		}
		
		fseek(outputFile->f, xIndex * sizeof(float), SEEK_SET) ;

		for(i = 0; i < outputFile->yDim; i++) {
			fwrite((float *)anIndexedBloc[i + yBorder], xDimBloc, sizeof(float), outputFile->f) ;
			fseek(outputFile->f, outputFileShift, SEEK_CUR) ;
		}

	}	
	updateProgressCounterForIndex(aCounter, outputFile->xDim) ;
	
	freeVectorFloat(aBloc, 0) ;
	free(anIndexedBloc) ;
	freeVectorComplexFloat(u, 0) ;
	freeCZTInterpolator(V) ;
}

void usage() 
{
	printf("%s\n%s\n%s\n","Usage:", "-1- interpolData pathToParameterFile : read interpolation parameters in parameter file and interpolate data correspondingly", "-2- interpolData pathToParameterFile -create : create example parameter file at given path") ;
	exit(0) ;
}

void createParameterFileAtPath(char *aPath)
{
	keyValue *paramList ;
	
	paramList = allocAKeyValuePair() ;
	
	setStringValForKeyIn(paramList, "Interpolation parameter file", "") ;
	setStringValForKeyIn(paramList, "****************************", "") ;
	setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "Input/output file access path", "") ;
	setStringValForKeyIn(paramList, "/path/inputFileName\t\t", "input file path") ;
	setStringValForKeyIn(paramList, "/path/outputFileName\t\t", "output file path") ;
	setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "Data file type", "") ;
	setStringValForKeyIn(paramList, "float\t\t", "data file type (float, complex or interf)") ;
	setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "Input image size", "") ;
	setStringValForKeyIn(paramList, "100\t\t", "input x dimension") ;
	setStringValForKeyIn(paramList, "100\t\t", "input y dimension") ;
	setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "Output image size (if set to zero, output file size will be computed from the given transform)", "") ;
	setStringValForKeyIn(paramList, "100\t\t", "output x dimension") ;
	setStringValForKeyIn(paramList, "100\t\t", "output y dimension") ;
	setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "Affine transform", "") ;
	setStringValForKeyIn(paramList, "1.0\t\t", "Ax") ;
	setStringValForKeyIn(paramList, "0.0\t\t", "Bx") ;
	setStringValForKeyIn(paramList, "0.0\t\t", "Cx") ;
	setStringValForKeyIn(paramList, "1.0\t\t", "By") ;
	setStringValForKeyIn(paramList, "0.0\t\t", "Ay") ;
	setStringValForKeyIn(paramList, "0.0\t\t", "Cy") ;
    setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "Frequency shifts", "") ;
    setStringValForKeyIn(paramList, "0", "Y frequency shift") ;
	setStringValForKeyIn(paramList, "0", "Y sampling frequency") ;


	writeParameterFileAtPath(paramList, aPath) ;
	exit(0) ;
}

