
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  crop2Common.c
//  crop2Common
//
//  Created by Dominique Derauw on 25/04/2022.
//  Copyright © 2022 SAREOS Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "initInSARLib.h"

void DEMWeightedAverageHelp() ;
void updateBprParameterFile(keyValue *bprParams, InSARParametersStruct *pInSAR, float coherenceThreshold) ;

int main(int argc, const char * argv[])
{
    char *rootDir, *outputPath, *tempFilePath, *maskedCoh, *sumCohPath, *bprParamFilePath ;
    int i ;
    float coherenceThreshold = 0 ;
    CSVStruct *InSARParamsPath ;
    InSARParametersStruct *pInSAR ;
    keyValue *bprParams ;

    if (argc == 1 || isFlagPresent(argc, argv, "h")) {
        DEMWeightedAverageHelp() ;
    }
    if (!isDir((char *)argv[1])) {
        DEMWeightedAverageHelp() ;
    }
    if (argc == 3) {
        sscanf(argv[2], "%f", &coherenceThreshold) ;
    }
    
    rootDir = initStringWithString((char *)argv[1]) ;
    if (!isWriteAccessGrantedAtPath(rootDir)) {
        ase("Cannot access/write in input directory\n") ;
    }
    
    outputPath = initStringWith2Strings(rootDir, "/weightedAverageDEM") ;
    tempFilePath = initStringWith2Strings(rootDir, "/tempfile") ;
    maskedCoh = initStringWith2Strings(rootDir, "/maskedCoh") ;
    sumCohPath = initStringWith2Strings(rootDir, "/sumCoh") ;
    bprParamFilePath = initStringWith2Strings(rootDir, "/bpr.txt") ;

    sprintf(aCommand, "bestPlaneRemoval2 %s -create", bprParamFilePath) ;
    system(aCommand) ;
    sprintf(aCommand, "bestPlaneRemoval2 %s", bprParamFilePath) ;

    InSARParamsPath = recursiveSearchOfFileInDir("InSARParameters.txt", rootDir) ;
    if (InSARParamsPath->numberOfEntries) {
        for (i = 0; i < InSARParamsPath->numberOfEntries; i++) {
            if (strcmp(getPointerToFileNameInPath(InSARParamsPath->stringVal[i]), "InSARParameters.txt")) {
                removeStringValAtIndexInCSVStruct(i, InSARParamsPath) ;
                i-- ;
            }
        }

        printf("---> Number of InSAR processing found: %d\n", InSARParamsPath->numberOfEntries) ;

        pInSAR = readInSARParametersFileAtPath(InSARParamsPath->stringVal[0]) ;
        printf("\n---> Considered processing: %s", pInSAR->whereAmI) ;
        /* If an external reference DEM exists, corrects computed DEM removing best plane */
        if (pInSAR->externalSlantRangeDEMFile->xDim) {
            bprParams = readParameterFileAtPath(bprParamFilePath) ;
            updateBprParameterFile(bprParams, pInSAR, coherenceThreshold) ;
            writeParameterFileAtPath(bprParams, bprParamFilePath) ;
            system(aCommand) ;
        }
        maskFloatFileIfLowerThanThreshold(pInSAR->coh.filePath, NULL, maskedCoh, coherenceThreshold) ;
        floatFilesArithmetics(pInSAR->srDEM.filePath, "*", 0, maskedCoh, outputPath) ;
        floatFilesArithmetics(maskedCoh, "+", 0, NULL, sumCohPath) ;
        freeInSARParametersStruct(pInSAR) ;
        for (i = 1; i < InSARParamsPath->numberOfEntries; i++) {
            pInSAR = readInSARParametersFileAtPath(InSARParamsPath->stringVal[i]) ;
            printf("\n---> Considered processing: %s", pInSAR->whereAmI) ;
            /* If an external reference DEM exists, corrects computed DEM removing best plane */
            if (pInSAR->externalSlantRangeDEMFile->xDim) {
                bprParams = readParameterFileAtPath(bprParamFilePath) ;
                updateBprParameterFile(bprParams, pInSAR, coherenceThreshold) ;
                writeParameterFileAtPath(bprParams, bprParamFilePath) ;
                system(aCommand) ;
            }
            maskFloatFileIfLowerThanThreshold(pInSAR->coh.filePath, NULL, maskedCoh, coherenceThreshold) ;
            floatFilesArithmetics(pInSAR->srDEM.filePath, "*", 0, maskedCoh, tempFilePath) ;
            floatFilesArithmetics(outputPath, "+", 0, tempFilePath, NULL) ;
            floatFilesArithmetics(sumCohPath, "+", 0, maskedCoh, NULL) ;
            freeInSARParametersStruct(pInSAR) ;
        }
        floatFilesArithmetics(outputPath, "/", 0, sumCohPath, NULL) ;
    }
    else {
        printf("No InSARParameters.txt file found in sub directories\n") ;
        DEMWeightedAverageHelp() ;
    }
    unlink(tempFilePath) ;
    unlink(sumCohPath) ;
    free(rootDir) ;
    free(tempFilePath) ;
    free(sumCohPath) ;
    free(outputPath) ;
    free(bprParamFilePath) ;
}

void DEMWeightedAverageHelp()
{
    printf("SRDEMWeightedAverage directory [coherenceThreshold]\n") ;
    printf("SRDEMWeightedAverage will compute the weighted slant range DEM average\nin a stack of InSAR process, considering coherence as weight\n") ;
    printf("SRDEMWeightedAverage is only applicable on stack of InSAR processes performed with respect to the same super master image\n") ;
    printf("coherenceThreshold: a float value used as coherence threshold to consider a point in weighted average\n") ;
    printf("\ndirectory: Upper directory containing InSAR processing directories\n") ;
    printf("Result will be saved within the given directory") ;
    printf("\nBe sure to use crop2Common on the InSAR processing directory stack\nbefore performing the InSAR processes up to DEM generation to get\nthe required stack\n") ;
    exit(0) ;
}

void updateBprParameterFile(keyValue *bprParams, InSARParametersStruct *pInSAR, float coherenceThreshold)
{
    setStringValForKeyIn(bprParams, pInSAR->srDEM.filePath, "File to be corrected") ;
    setIntValForKeyIn(bprParams, pInSAR->srDEM.lenr, "X dimension of the file to be corrected") ;
    setIntValForKeyIn(bprParams, pInSAR->srDEM.lena, "Y dimension of the file to be corrected") ;
    setStringValForKeyIn(bprParams, pInSAR->externalSlantRangeDEMFile->accessPath, "Reference file path") ;
    setIntValForKeyIn(bprParams, pInSAR->externalSlantRangeDEMFile->xDim, "X dimension of reference file") ;
    setIntValForKeyIn(bprParams, pInSAR->externalSlantRangeDEMFile->yDim, "Y dimension of reference file") ;
    setStringValForKeyIn(bprParams, pInSAR->coh.filePath, "Threshold file") ;
    setIntValForKeyIn(bprParams, pInSAR->coh.lenr, "X dimension of the threshold file") ;
    setIntValForKeyIn(bprParams, pInSAR->coh.lena, "Y dimension of the threshold file") ;
    setFloatValForKeyIn(bprParams, coherenceThreshold, "Threshold value") ;
    free(pInSAR->srDEM.filePath) ;
    pInSAR->srDEM.filePath = initStringWith2Strings(getStringValForKeyIn(bprParams, "File to be corrected"), ".flattened") ;
}
