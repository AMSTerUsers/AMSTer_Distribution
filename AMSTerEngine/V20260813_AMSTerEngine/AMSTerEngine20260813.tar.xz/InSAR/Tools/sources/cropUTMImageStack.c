
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  cropImageStack
//
//  Created by Dominique Derauw on 10/07/2019.
//  Copyright © 2019 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "rawFileLib.h"
#include "paramLib.h"
#include "ENVIHeaderManagement.h"
#include "aoiHandling.h"
#include "projUTM.h"
#include "ellipsoid.h"
#include "matrixObjects.h"
#include "counters.h"

void usage(void) ;

int main(int argc, const char * argv[]) {
    char skip ;
    char *inputDir, *outputDir ;
    char *headerFileName, *headerPath ;
    char *inputFileName, *inputFilePath ;
    char *outputFileName, *outputFilePath ;
    char *kmlPath ;
    int i, imageIndex ;
    int xDim, yDim ;
    int dx, dy, xDimZone, yDimZone ;
    long seekVal ;
    double xSampling, ySampling, refEasting, refNorthing ;
    point2D aPoint ;
    CSVStruct *fileList ;
    polygon *aoi ;
    keyValue *ENVIHeader = NULL ;
    UTMZoneStruct *UTMZone ;
    ellipsoid *WGS84Ellipsoid ;
    floatMatrix *theZone ;
    rawFileDescriptor *inputFile, *outputFile ;
    progressCounter *aCounter ;

    if (argc !=  4) {
        usage() ;
    }
    if (!isDir((char *)argv[1])) {
        usage() ;
    }
    if (!fileExistsAtPath((char *)argv[2])) {
        usage() ;
    }
    outputDir = initStringWithString((char *)argv[3]) ;
    if (!isDir((char *)argv[1])) {
        if(mkdir((const char *)outputDir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create image directory at path %s\n", outputDir) ;
            ase(ertex) ;
        }
    }
    if (!isWriteAccessGrantedAtPath(outputDir)) {
        ase("Write access dinied in given output directory") ;
    }

    
    /* read input parameters */
    kmlPath = initStringWithString((char *)argv[2]) ;

    /* Init WGS84 ellipsoid */
    if((WGS84Ellipsoid = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL) {
        perror("Failed to allocate WGS84 reference ellipsoid\n") ;
        exit(-1) ;
    }
    WGS84Ellipsoid->a = 6.378137000000000e+06 ;
    WGS84Ellipsoid->b = 6.356752314245000e+06 ; // Predefined as WGS84
    WGS84Ellipsoid->f_1 = WGS84Ellipsoid->a / (WGS84Ellipsoid->a  - WGS84Ellipsoid->b) ;
    WGS84Ellipsoid->e2 = (pow(WGS84Ellipsoid->a, 2.) - pow(WGS84Ellipsoid->b, 2.)) / pow(WGS84Ellipsoid->a, 2.) ;
    WGS84Ellipsoid->X0 = WGS84Ellipsoid->Y0 = WGS84Ellipsoid->Z0 = 0. ;
    
    /* List files in directory */
    inputDir = initStringWithString((char *)argv[1]) ;
    fileList = recursiveSearchOfFilesWithExtensionInDir("hdr", inputDir) ;
    
    /* First, we look for the first valid file to read its ENVI header */
    xDim = yDim = 0 ;
    for (i = 0; i < fileList->numberOfEntries; i++) {
        headerPath = fileList->stringVal[i] ;
        if((ENVIHeader = readENVIHeader(headerPath)) != NULL) {
            break ;
        }
    }
    if(!ENVIHeader) {
        perror("Failed to read ENVI header") ;
        return (0) ;
    }
    xDim = getIntValForKeyIn(ENVIHeader, "samples") ;
    yDim = getIntValForKeyIn(ENVIHeader, "lines") ;
    xSampling = getDoubleValForKeyIn(ENVIHeader, "X sampling") ;
    ySampling = getDoubleValForKeyIn(ENVIHeader, "Y sampling") ;
    refEasting = getDoubleValForKeyIn(ENVIHeader, "Easting") ;
    refNorthing = getDoubleValForKeyIn(ENVIHeader, "Northing") ;
    if (!xDim || !yDim || !xSampling || !ySampling || !refEasting || !refNorthing) {
        perror("Failed to read values in ENVI header \n") ;
        return (0) ;
    }
    
    /* Make basic verifications */
    if (!xDim) {
        ase("Failed to read header file") ;
    }
    
    /* Compute AoI from kml */
    if((aoi = getRectangularAoIFromKMLFile(kmlPath)) == NULL) {
        perror("Failed to derive rectangular area of interest from kml file") ;
        return (0) ;
    }
    convertAoIFromDeg2Rad(aoi) ;

    UTMZone = initUTMReferencingOnEllipsoid(WGS84Ellipsoid) ;
    aPoint.p.x = aoi->P[0].x ;
    aPoint.p.y = aoi->P[0].y ;
    UTMZoneForLonLatPoint(&aPoint, UTMZone) ;
    for (i = 0; i < aoi->N; i++) {
        lonLat2UTMOnEllipsoid(aoi->V[i], aoi->V[i] + 1, UTMZone) ;
    }
    setIntValForKeyIn(ENVIHeader, UTMZone->indiceZoneLatUTM, "indiceZoneLatUTM") ;
    
    /* Localize AoI within raster */
    dx = (int)round((aoi->P[0].x - refEasting) / xSampling) ;
    dy = (int)round((refNorthing - aoi->P[2].y) / ySampling) ;
    dx = (dx < 0)? 0 : ((dx > xDim)? 0 : dx) ;
    dy = (dy < 0)? 0 : ((dy > yDim)? 0 : dy) ;
    xDimZone = (int)round((aoi->P[2].x - refEasting) / xSampling) - dx + 1 ;
    yDimZone = (int)round((refNorthing - aoi->P[0].y) / ySampling) - dy + 1 ;
    xDimZone = (xDimZone > xDim)? xDim : xDimZone ;
    yDimZone = (yDimZone > yDim)? yDim : yDimZone ;
    
    /* Modify ENVIHeader */
    setDoubleValForKeyIn(ENVIHeader, xDimZone, "samples") ;
    setDoubleValForKeyIn(ENVIHeader, yDimZone, "lines") ;
    refEasting += dx * xSampling ;
    refNorthing -= dy * ySampling ;
    setDoubleValForKeyIn(ENVIHeader, refEasting, "Easting") ;
    setDoubleValForKeyIn(ENVIHeader, refNorthing, "Northing") ;

    /* initialize measurement matrix */
    theZone = allocFloatMatrixWithIndexes(0, yDimZone - 1, 0, xDimZone - 1) ;

    /* Let's go */
    aCounter = initProgressCounterWithMinMaxValue(0, fileList->numberOfEntries - 1) ;
    for (imageIndex = 0; imageIndex < fileList->numberOfEntries; imageIndex++) {
        skip = 0 ;
        headerFileName = getPointerToFileNameInPath(fileList->stringVal[imageIndex]) ;
        inputFileName = initStringWithString(headerFileName) ;
        stripExtensionAtEndOfPath(inputFileName) ;
        inputFilePath = initStringWith3Strings(inputDir, "/", inputFileName) ;
        if (!fileExistsAtPath(inputFilePath)) {
            free(inputFilePath) ;
            inputFilePath = initStringWith4Strings(outputDir, "/", inputFileName, ".bil") ;
            if (!fileExistsAtPath(inputFilePath)) {
                printf("File not found for file header %s\nSkipping image cropping\n", headerFileName) ;
            }
            skip = 1 ;
        }
        if (!skip) {
            inputFile = openRawFileForReadingAtPath(inputFilePath) ;
            outputFilePath = initStringWith3Strings(outputDir, "/", inputFileName) ;
            outputFile = openRawFileForWritingAtPath(outputFilePath) ;
            for (i = 0; i < yDimZone; i++) {
                seekVal = ((dy + i) * xDim + dx) * sizeof(float) ;
                fseek(inputFile->f, seekVal, SEEK_SET) ;
                fread(theZone->m[i], sizeof(float), xDimZone, inputFile->f) ;
            }
            fwrite(theZone->m[0],sizeof(float), xDimZone * yDimZone, outputFile->f) ;
            outputFilePath = initStringWith3Strings(outputDir, "/", headerFileName) ;
            writeENVIHeaderAtPath(outputFilePath, ENVIHeader) ;
            free(outputFilePath) ;
            freeRawFileDescriptor(inputFile) ;
            freeRawFileDescriptor(outputFile) ;
        }
        free(inputFileName) ;
        free(inputFilePath) ;
        updatePointProgressCounterForIndex(aCounter, imageIndex) ;
   }
    updatePointProgressCounterForIndex(aCounter, imageIndex) ;

    free(outputDir) ;
    
    return 0;
}


void usage()
{
    printf("Usage: \ncropFileStack inputDir kml outputDir\n");
    exit(0) ;
}
