
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  getSRTMDEM
//
//  Created by Dominique Derauw on 25/09/24.
//  Copyright (c) 2024 SAREOS Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "EGMLib.h"

void usage(void) ;

int main(int argc, const char * argv[]) {
    char *outputFilePath, *outputFileDir ;
    char *aString, *aPath ;
    char *EGMID = NULL, *requestedEGM = NULL ;
    keyValue *existingDEMHeader ;
    
    if (argc == 1 || isArgumentPresent(argc, argv, "h")) {
        usage() ;
    }

    outputFileDir = getenv("EXTERNAL_DEMS_DIR") ;
    if (!fileExistsAtPath((char *)argv[1])) {
        outputFilePath = initStringWith3Strings(outputFileDir, "/", (char *)argv[1]) ;
        if (!fileExistsAtPath(outputFilePath)) {
            ase("\n-/-> No DEM found at given path.\n\n") ;
        }
    }
    else {
        outputFilePath = initStringWithString((char *)argv[1]) ;
    }

    if (argc == 3){
        requestedEGM = initStringWithString(argv[2]) ;
    }
    
    /* Check if it is requested to transform an existing DEM into ellipsoidal heights */
    if ((aPath = getCorrespondingFilePathWithExtension(outputFilePath, ".txt"))) {
        existingDEMHeader = readParameterFileAtPath(aPath) ;
        aString = getStringValForKeyIn(existingDEMHeader, "Height type") ;

        EGMID = addEGMToExistingDEM(existingDEMHeader, requestedEGM) ;
        if (!strcmp(EGMID, "EGM96")) {
            setStringValForKeyIn(existingDEMHeader, "Ellipsoidal - EGM96 geoidal height added", "Height type") ;
        }
        else {
            setStringValForKeyIn(existingDEMHeader, "Ellipsoidal - EGM2008 geoidal height added", "Height type") ;
        }
        writeParameterFileAtPath(existingDEMHeader, aPath) ;

        freeKeyValueList(existingDEMHeader) ;
        free(aPath) ;
        free(EGMID) ;
        return (0) ;
    }
    else {
        ase("\n-/-> No .txt descriptor file corresponding to input DEM found.\n\n") ;
    }

    if (requestedEGM) {
        free(requestedEGM) ;
    }
    
}

void usage(void)
{
    printf("Usage:\n") ;
    printf("geoidal2EllipsoidalDEM DEMName/DEMPath [EGMID]]\n\n") ;
    printf("Conversion of geoidal DEM into ellipsoidal DEM required by AMSTerEngine\n") ;
    printf("Given DEM will be \"Corrected for\" EGM geoidal ondulations.\n") ;
    printf("Selection of EGM is based on DEM definition within DEM associated text file\n") ;
    printf("If SRTM DEM, EGM96 is selected. If COPERNICUS DEM, EGM2008 is selected\n") ;
    printf("EGM can be forced using either EGM96 or EGM2008 as EGMID parameter\n") ;

    printf("EGM files can be donloaded at:\n\thttps://geographiclib.sourceforge.io/C++/doc/geoid.html\n") ;
    printf("Or\n\thttps://github.com/jleppert/egm96/blob/master/WW15MGH.DAC\n") ;
    printf("(link checked on April 30, 2025)\n") ;
    printf("Or ask it to me politely and I will send you the EGM archive I have (dderauw@sareos.be).\n") ;
    
    exit(0) ;
}
