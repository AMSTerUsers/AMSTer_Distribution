
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  updateParameterFile
//
//  Created by Dominique Derauw on 7/07/16.
//  Copyright (c) 2016 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "paramLib.h"
#include "fileAccessLib.h"

int main(int argc, const char * argv[]) {
    char *inputFilePath, *key, *oldValue, *newValue ;
    keyValue *params ;
    
    if (argc < 3) {
        exit(0) ;
    }
    inputFilePath = (char *)argv[1] ;
    key = (char *)argv[2] ;
    
    replaceNSubStringInString(key, "_", " ") ;
    params = readParameterFileAtPath(inputFilePath) ;
    oldValue = getStringValForKeyIn(params, key) ;
    fprintf(stdout, "%s\n", oldValue) ;
 
    if (argc == 4) {
        newValue = (char *)argv[3] ;
        setStringValForKeyIn(params, newValue, key) ;
        writeParameterFileAtPath(params, inputFilePath) ;
    }

    return (0) ;
}
