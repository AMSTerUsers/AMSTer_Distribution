
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include <stdio.h>
#include "pourtous.h"
#include "vectors.h"
#include "matrix.h"
#include "resmat.h"
#include "rawFileLib.h"
#include "fileAccessLib.h"

void usage(void) ;

int main (int argc, const char * argv[])
{
	char *aPath ;
	int	xDim, yDim, iX0, iY0 ;
	int xDimBloc, yDimBloc, deltaX, deltaY, nBlocX, nBlocY ;
	int i, j, k, l, iX, iY ;
	int	*index ;
	float **data, zVal, meanVal ;
    float excludingValue, norm ;
	double **M, *V, signe ;
	rawFileDescriptor *imageFile, *resultFile ;
	
	if(argc == 1) usage() ;
	aPath = (char *)argv[1] ;
	if((imageFile =  openRawFileForReadingAndWritingAtPath(aPath)) == NULL)
		ase ("Failed to open input file for reading and writing\n") ;
	sscanf(argv[2], "%d", &xDim) ;
    sscanf(argv[3], "%d", &yDim) ;
	if(imageFile->fileLength != xDim * yDim * sizeof(float))
		ase("Input file has wrong dimensions") ;
	
	meanVal = 0. ;
    if ((i = isArgumentPresent(argc, argv, "shift"))) {
        sscanf(argv[i], "shift=%f", &meanVal) ;
    }
    
	excludingValue = -9999 ;
    if ((i = isArgumentPresent(argc, argv, "excludingValue"))) {
        sscanf(argv[i], "excludingValue=%f", &excludingValue) ;
    }
    
	data = matrixFloat(0, yDim - 1, 0, xDim - 1) ;
	if(fread(data[0], sizeof(float), xDim * yDim, imageFile->f) != xDim * yDim)
		ase("Failed to read input file\n") ;
	
	index = vectorInt(1, 3) ;
    M = matrixDouble(1, 3, 1, 3) ;
    V = vectorDouble(1, 3) ;

	for(i = 1; i <= 3; i++) {
		for(j = 1; j <= 3; j++) {
			M[i][j] = 0.0 ;
		}
		V[i] = 0.0 ;
	}
	
	xDimBloc = yDimBloc = 41 ;
	do {
		xDimBloc = xDimBloc / 2 + 1 ;
		nBlocX = xDim / xDimBloc ;
	} while(nBlocX <= 1) ;
	
	do {
		yDimBloc = yDimBloc / 2 + 1 ;
		nBlocY = yDim / yDimBloc ;
	} while(nBlocY <= 1) ;
	
	deltaX = (xDim - nBlocX * xDimBloc)/(nBlocX - 1) ;
	deltaY = (yDim - nBlocY * yDimBloc)/(nBlocY - 1) ;
	iX0 = (deltaX)? 0 : (xDim - nBlocX * xDimBloc) / 2 ;
	iY0 = (deltaY)? 0 : (yDim - nBlocY * yDimBloc) / 2 ;
	
	for(i = 0; i < nBlocY; i++) {
		iY = i * (yDimBloc + deltaY) + yDimBloc/2 + iY0 ;
		for(j = 0; j < nBlocX; j++) {
			iX = j * (xDimBloc + deltaX) + xDimBloc/2 + iX0 ;
			zVal = norm = 0. ;
			for(k = -yDimBloc/2; k <= yDimBloc/2; k++) {
				for(l = -xDimBloc/2; l <= xDimBloc/2; l++) {
                    if (data[iY + k][iX + l] != excludingValue) {
                        zVal += data[iY + k][iX + l] ;
                        norm++ ;
                    }
				}
			}
            if (norm) {
                zVal /= norm ;
                
                M[1][1] += pow((double)iX, 2.) ;
                M[1][2] += iX * iY ;
                M[1][3] += iX ;
                M[2][2] += pow((double)iY, 2.) ;
                M[2][3] += iY ;
                M[3][3]++ ;
                
                V[1] += iX * zVal ;
                V[2] += iY * zVal ;
                V[3] += zVal ;
            }
		}
	}
	for(i = 1; i <= 3; i++) {
		for(j = i + 1; j <= 3; j++) {
			M[j][i] = M[i][j] ;
		}
	}
	ludcmp(M, 3, index, &signe) ;
	lubksb(M, 3, index, V) ;
	printf("Removed plane: %7.3f X + %7.3f Y + %7.3f\n", V[1], V[2], V[3]);
	for(iY = 0; iY < yDim; iY++) {
		for(iX = 0; iX < xDim; iX++) {
			data[iY][iX] -= (float)(V[1] * iX + V[2] * iY + V[3]) - meanVal ;
		}
	}
	
	sprintf(accessPath, "%s.flattened", aPath) ;
	if((resultFile =  openRawFileForWritingAtPath(accessPath)) == NULL)
		ase ("Failed to open result file for writing\n") ;
	if(fwrite(data[0], sizeof(float), xDim * yDim, resultFile->f) != xDim * yDim)
		ase("Failed to write result file\n") ;

	
	freeMatrixFloat(data, 0, 0) ;
	freeMatrixDouble(M, 1, 1) ;
	freeVectorDouble(V, 1) ;
}

void usage()
{
	printf("bestPlaneRemoval removes the best plane component from an image coded in float\n") ;
	printf("Usage : removePlane /path/To/imageFile xDim yDim [shift]\n") ;
	printf("An optional parameter can be added after the dimensions of the considered image\nThis \"shift\" parameter is a global shift value that will be added after best plane removal\n");
	
	exit(-1) ;
}
