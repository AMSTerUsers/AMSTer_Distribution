
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include <stdio.h>
#include "pourtous.h"
#include "rawFileLib.h"
#include "fileAccessLib.h"
#include "byteSwap.h"
#include "vectors.h"

void usage(void) ;

int main (int argc, const char * argv[]) {
    char isShort ;
	short *aShort ;
	int		i, j, N, vectorLength, lastVectorLength, headerLength = 0, dataLength ;
	float	*a ;
	rawFileDescriptor *inputFile, *outputFile ;
	
	if(argc == 1) usage() ;
	vectorLength = 1024 ;
	inputFile = openRawFileForReadingAtPath((char *)argv[1]) ;
	sprintf(accessPath, "%s.bSwapped", (char *)argv[1]) ;
	outputFile = openRawFileForWritingAtPath(accessPath) ;
	
    if((i = isArgumentPresent(argc, argv, "headerLength"))) {
        sscanf(argv[i], "headerLength=%d ", &headerLength) ;
    }
	dataLength = (int)inputFile->fileLength - headerLength ;
	
	if((isShort = isArgumentPresent(argc, argv, "short"))) {
	   	N = dataLength / sizeof(short) / vectorLength ;
		lastVectorLength = dataLength / sizeof(short) - N * vectorLength ;
		aShort = (short *)vectorShort(0, vectorLength - 1) ;
		
		fseek(inputFile->f, (long)headerLength, SEEK_SET) ;
		for(i = 0; i < N; i++) {
			if(fread(aShort, sizeof(short), vectorLength, inputFile->f) != vectorLength)
				ase("Read error") ;
			for(j = 0; j < vectorLength; j++) {
				swapShort(&aShort[j]) ;
			}
			fwrite(aShort, sizeof(short), vectorLength, outputFile->f) ;
		}
		if(ftell(inputFile->f) < inputFile->fileLength) {
			fread(aShort, sizeof(short), lastVectorLength, inputFile->f) ;
			for(j = 0; j < lastVectorLength; j++) {
				swapShort(&aShort[j]) ;
			}
			fwrite(aShort, sizeof(short), lastVectorLength, outputFile->f) ;
		}	
		freeVectorShort(aShort, 0) ;
	}
	else {
		N = dataLength / sizeof(int) / vectorLength ;
		lastVectorLength = dataLength / sizeof(int) - N * vectorLength ;
		a = (float *)vectorFloat(0, vectorLength - 1) ; 
		
		fseek(inputFile->f, (long)headerLength, SEEK_SET) ;
		for(i = 0; i < N; i++) {
			if(fread(a, sizeof(float), vectorLength, inputFile->f) != vectorLength)
				ase("Read error") ;
			for(j = 0; j < vectorLength; j++) {
				swapFloat(&a[j]) ;
			}
			fwrite(a, sizeof(float), vectorLength, outputFile->f) ;
		}
		if(ftell(inputFile->f) < inputFile->fileLength) {
			fread(a, sizeof(float), lastVectorLength, inputFile->f) ;
			for(j = 0; j < lastVectorLength; j++) {
				swapFloat(&a[j]) ;
			}
			fwrite(a, sizeof(float), lastVectorLength, outputFile->f) ;
		}	
		freeVectorFloat(a, 0) ;
	}
	
	
	freeRawFileDescriptor(inputFile) ;
	freeRawFileDescriptor(outputFile) ;
	
    return 0;
}

void usage()
{
	printf("Usage: swapBytes /PathTo/file [headerLength=N] [short]");
	printf("This routine simply swaps bytes of the files given as input\n");
	printf("By default, the file is supposed to be in float or complex float.\n");
	printf("If willing to swap short values, add the keyword \"short\"\n");
	printf("If willing to skip a header length, add the keyword \"headerLength=N\",\nwhere N is the header length in bytes.\n");
	printf("Result file is saved next to the input file, adding the extension \".swapped\"\n");
	
	exit(0) ;
}
