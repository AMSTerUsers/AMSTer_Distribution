/* 
*  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version. 
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 * 
 *  You should have received a copy of the GNU Affero General Public License 
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**************************************************
 * File name : fff.c
 * Author : Dominique Derauw
 * Date : 2026-04-28
 * Copyright 2026 Dominique Derauw
 * Description : float file filtering
 **************************************************/


#include <stdio.h>
#include "basicFilters.h"

void help(void) ;

int main(int argc, const char * argv[]) {
    char *inputFilePath ;
    int xDim, yDim, xFilterSize, yFilterSize ;
    int filterType ;
    float *excludedVal = NULL;
    rawFileDescriptor *inputFile ;
    
    if ((argc == 1) || isFlagPresent(argc, argv, "h")) {
    	help() ;
    }
    
    filterType = -1 ;
    if(!strcmp(argv[4], "mean")) {
    	filterType = 0 ;
    }
    if(!strcmp(argv[4], "median")) {
    	filterType = 1 ;
    }

    inputFilePath = initStringWithString((char *)argv[1]) ;
    sscanf(argv[2], "%d", &xDim) ;
    sscanf(argv[3], "%d", &yDim) ;
    sscanf(argv[5], "%d", &xFilterSize) ;
    sscanf(argv[6], "%d", &yFilterSize) ;
    if (argc == 8) {
        excludedVal = calloc(1, sizeof(float)) ;
        sscanf(argv[7], "%f", excludedVal) ;
    }
    


    inputFile = openRawFileForReadingAtPath(inputFilePath) ;
    if (!inputFile) {
        ase("\t-/-> Failed to open input file\n") ;
    }
    if (inputFile->fileLength != xDim * yDim * __SIZEOF_FLOAT__) {
        ase("\t-/-> input file has wrong dimensions\n") ;
    }
    
    inputFile->xDim = xDim ;
    inputFile->yDim = yDim ;
    
    switch (filterType) {
	case 0:
    		meanFilterOfFloatFile(inputFile, xFilterSize, yFilterSize, excludedVal) ;
    	break ;
    	
	case 1:
    		medianFilterOfFloatFile(inputFile, xFilterSize, yFilterSize, excludedVal) ;
    	break ;

	default:
		help() ;
    	break;
     }


    
    
    freeRawFileDescriptor(inputFile) ;
    free(inputFilePath) ;
    return 0;
}

void help(void)
{
    	printf("Usage:\nfff floatFilePath xDim yDim filterType xFilterDim yFilterDim [excludingValue]\n") ;
    	printf("filterType = mean or median\n") ;
    	exit(0) ;
}
