
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  crop2Common.c
//  crop2Common
//
//  Created by Dominique Derauw on 25/04/2022.
//  Copyright © 2022 SAREOS Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "initInSARLib.h"

void crop2CommonHelp() ;

int main(int argc, const char * argv[])
{
    char *rootDir, *aPath, *aDir ;
    int i ;
    int coha, cohr, spi, rangeReductionFactor, azimuthReductionFactor ;
    double minX, minY, maxX, maxY ;
    CSVStruct *InSARParamsPath ;
    InSARParametersStruct **pInSAR ;

    if (argc == 1 || isFlagPresent(argc, argv, "h")) {
        crop2CommonHelp() ;
    }
    if (!isDir((char *)argv[1])) {
        crop2CommonHelp() ;
    }
    rootDir = initStringWithString((char *)argv[1]) ;

    if ((i = isArgumentPresent(argc, argv, "rX="))) {
        sscanf(argv[i], "rX=%d", &rangeReductionFactor) ;
    }
    if ((i = isArgumentPresent(argc, argv, "rY="))) {
        sscanf(argv[i], "rY=%d", &azimuthReductionFactor) ;
    }
    if ((i = isArgumentPresent(argc, argv, "cX="))) {
        sscanf(argv[i], "cX=%d", &cohr) ;
    }
    if ((i = isArgumentPresent(argc, argv, "cY="))) {
        sscanf(argv[i], "cY=%d", &coha) ;
    }
    if ((i = isArgumentPresent(argc, argv, "spi="))) {
        sscanf(argv[i], "spi=%d", &spi) ;
    }
    

    InSARParamsPath = recursiveSearchOfFileInDir("InSARParameters.txt", rootDir) ;
    if (InSARParamsPath->numberOfEntries) {
        for (i = 0; i < InSARParamsPath->numberOfEntries; i++) {
            if (strcmp(getPointerToFileNameInPath(InSARParamsPath->stringVal[i]), "InSARParameters.txt")) {
                removeStringValAtIndexInCSVStruct(i, InSARParamsPath) ;
            }
        }

        pInSAR = malloc(InSARParamsPath->numberOfEntries * sizeof(pInSAR[0])) ;
        for (i = 0; i < InSARParamsPath->numberOfEntries; i++) {
            pInSAR[i] = readInSARParametersFileAtPath(InSARParamsPath->stringVal[i]) ;

            minX = (i)? ((minX < pInSAR[i]->aoi->P[0].x)? pInSAR[i]->aoi->P[0].x : minX ): pInSAR[i]->aoi->P[0].x ;
            minY = (i)? ((minY < pInSAR[i]->aoi->P[0].y)? pInSAR[i]->aoi->P[0].y : minY ): pInSAR[i]->aoi->P[0].y ;
            maxX = (i)? ((maxX > pInSAR[i]->aoi->P[2].x)? pInSAR[i]->aoi->P[2].x : maxX ): pInSAR[i]->aoi->P[2].x ;
            maxY = (i)? ((maxY > pInSAR[i]->aoi->P[2].y)? pInSAR[i]->aoi->P[2].y : maxY ): pInSAR[i]->aoi->P[2].y ;

            rangeReductionFactor = (i)? ((rangeReductionFactor > pInSAR[i]->red.Fra)? pInSAR[i]->red.Fra : rangeReductionFactor) : pInSAR[i]->red.Fra ;
            azimuthReductionFactor = (i)? ((azimuthReductionFactor > pInSAR[i]->red.Faz)? pInSAR[i]->red.Faz : azimuthReductionFactor) : pInSAR[i]->red.Faz ;
            cohr = (i)? ((cohr > pInSAR[i]->coh.cor)? pInSAR[i]->coh.cor : cohr) : pInSAR[i]->coh.cor ;
            coha = (i)? ((coha > pInSAR[i]->coh.coa)? pInSAR[i]->coh.coa : coha) : pInSAR[i]->coh.coa ;
            spi = (i)? ((spi > pInSAR[i]->coh.spi)? pInSAR[i]->coh.spi : spi) : pInSAR[i]->coh.spi ;
        }
    }
    else {
        printf("No InSARParameters.txt file found in sub directories\n") ;
        crop2CommonHelp() ;
    }
    printf("\nCommon area of interest in range azimuth coordinate of super master image:\n") ;
    printf("xMin = %lf\n", minX) ;
    printf("yMin = %lf\n", minY) ;
    printf("xMax = %lf\n", maxX) ;
    printf("yMax = %lf\n", maxY) ;

    if ((i = isArgumentPresent(argc, argv, "rX="))) {
        sscanf(argv[i], "rX=%d", &rangeReductionFactor) ;
        printf("\nRange reduction factor chosen as common one by user: %d\n", rangeReductionFactor) ;
    }
    else {
        printf("\nMinimum range reduction factor chosen as common one: %d\n", rangeReductionFactor) ;
    }
    if ((i = isArgumentPresent(argc, argv, "rY="))) {
        sscanf(argv[i], "rY=%d", &azimuthReductionFactor) ;
        printf("\nRange azimuth factor chosen as common one by user: %d\n", azimuthReductionFactor) ;
    }
    else {
        printf("Minimum azimuth reduction factor chosen as common one: %d\n", azimuthReductionFactor) ;
    }
    if ((i = isArgumentPresent(argc, argv, "cX="))) {
        sscanf(argv[i], "cX=%d", &cohr) ;
        printf("Range dimention of coherence estimator window chosen as common by user: %d\n", cohr) ;
    }
    else {
        printf("Minimum range dimention of coherence estimator window chosen as common one: %d\n", cohr) ;
    }
    if ((i = isArgumentPresent(argc, argv, "cY="))) {
        sscanf(argv[i], "cY=%d", &coha) ;
        printf("Azimuth dimention of coherence estimator window chosen as common one by user: %d\n", coha) ;
    }
    else {
        printf("Minimum azimuth dimention of coherence estimator window chosen as common one: %d\n", coha) ;
    }
    if ((i = isArgumentPresent(argc, argv, "spi="))) {
        sscanf(argv[i], "spi=%d", &spi) ;
        printf("Spiral size for coherence estimator window chosen as common one by user: %d\n", spi) ;
    }
    else {
        printf("Minimum spiral size for coherence estimator window chosen as common one: %d\n", spi) ;
    }
    
    for (i = 0; i < InSARParamsPath->numberOfEntries; i++) {
        aDir = getDirectoryPathFromPath(InSARParamsPath->stringVal[i]) ;
        aPath = initStringWith2Strings(aDir, "/InSARParameters.ori") ;
        saveInSARParametersFileAtPath(pInSAR[i], aPath) ;
        pInSAR[i]->aoi->P[0].x = minX ;
        pInSAR[i]->aoi->P[0].y = minY ;
        pInSAR[i]->aoi->P[2].x = maxX ;
        pInSAR[i]->aoi->P[2].y = maxY ;

        pInSAR[i]->red.Fra = rangeReductionFactor ;
        pInSAR[i]->red.Faz = azimuthReductionFactor ;
        pInSAR[i]->coh.cor = cohr ;
        pInSAR[i]->coh.coa = coha ;
        pInSAR[i]->coh.spi = spi ;

        saveInSARParametersFileAtPath(pInSAR[i], InSARParamsPath->stringVal[i]) ;
        freeInSARParametersStruct(pInSAR[i]) ;
        free(aDir) ;
        free(aPath) ;
    }
    free(rootDir) ;
}

void crop2CommonHelp()
{
    printf("crop2Common directory [rX=rx] [rY=rY] [cX=cX] [cY=cY] [spi=spi]\n") ;
    printf("crop2Common will simply compute common area of interest found in a series of InSAR processing subdirerctories\nand change them to the common intersection\n") ;
    printf("rX and rY are the range and azimuth reduction factors for common InSAR processing\n") ;
    printf("cX, cY and spi are the coherence estimator window size and square spiral size used for common InSAR processing\n") ;
    printf("If not given, the smallest one(s) will be chosen as common value for all InSAR processings\n") ;
    printf("It is the user's responsibility to ensure that all input InSAR processing are \nfrom the same acquisition mode, all coregistered to a common super master\n") ;
    printf("directory: Upper directory containing InSAR processing directories\n") ;
    exit(0) ;
}