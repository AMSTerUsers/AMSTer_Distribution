
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  raw2ENVIFormat
//
//  Created by Dominique Derauw on 06/07/2018.
//  Copyright © 2018 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "rawFileLib.h"
#include "fileAccessLib.h"
#include "ENVIHeaderManagement.h"
#include "CSLImageFormat.h"

void usage(void) ;

int main(int argc, const char * argv[]) {
    char *inputPath, makeLink ;
    int xDim, yDim, layerIndex ;
    rawFileDescriptor *inputFile ;
    CSLImage *thisImage = NULL ;
    SLCImageInfo *info ;
    CSVStruct *polMode ;
    
    if (argc == 1 || isFlagPresent(argc, argv, "h")) {
        usage() ;
    }
    
    inputPath = initStringWithString((char *)argv[1]) ; 
    if ((thisImage = getCSLImageStructureAtPath(inputPath))) {
        makeLink = 1 ;
        info = readInfoImageInCSLImage(thisImage) ;
        xDim = info->rangeDimension ;
        yDim = info->azimuthDimension ;
        polMode = readCSVInString(info->polMode) ;
        for (layerIndex = 0; layerIndex < polMode->numberOfEntries; layerIndex++)
        {
            free(inputPath) ;
            inputPath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", polMode->stringVal[layerIndex]) ;
            generateENVIHeaderForFile(inputPath, xDim, yDim, makeLink) ;
        }
        freeCSLImageStructure(thisImage) ;
        freeInfoImage(info) ;
        freeCSVStruct(polMode) ;
    }
    else {
        if (!fileExistsAtPath(inputPath)) {
            ase("input file not found\n") ;
        }
        if (argc < 4) {
            usage() ;
        }
        
        makeLink = isFlagPresent(argc, argv, "l")? 1 : 0 ;
        sscanf(argv[2], "%d", &xDim) ;
        sscanf(argv[3], "%d", &yDim) ;
        generateENVIHeaderForFile(inputPath, xDim, yDim, makeLink) ;
    }

    

    free(inputPath) ;
    return 0;
}


void usage()
{
    printf("Usage: \n") ;
    printf("-1- raw2ENVIFormat CSLImageFilepath\n") ;
    printf("-2- raw2ENVIFormat filePath xDim yDim [-l]\n") ;
    exit (0) ;
}
