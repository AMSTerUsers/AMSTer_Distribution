
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  ffa
//
//  Created by Dominique Derauw on 25/04/2017.
//  Copyright © 2017 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "vectors.h"
#include "matrix.h"
#include "rawFileLib.h"

//#define _BUFFER_SIZE_ (int)(1024 * 1024)
void usage(void) ;

int main(int argc, const char * argv[]) {
    char inPlace ;
    char operator, *outputPath, *outputFileName = NULL, *opString = NULL ;
    int iX, iB ;
    float *data1, *data2, *result ;
    size_t nBlocs, lastBlocSize, blocSize ;
    rawFileDescriptor *file1, *file2, *outputFile = NULL ;
    
    if (argc < 4) {
        usage() ;
    }
    
    if((file1 = openRawFileForReadingAndWritingAtPath((char *)argv[1])) == NULL)
        ase("Failed to open first file") ;
    if((file2 = openRawFileForReadingAtPath((char *)argv[3])) == NULL)
        ase("Failed to open second file") ;
    
    if (file1->fileLength != file2->fileLength) {
        ase("Float files do no have same dimensions") ;
    }
    if (4 * (file1->fileLength / 4) != file1->fileLength) {
        ase("Files are not float files") ;
    }
    
    operator = argv[2][0] ;
    switch (operator) {
        case '+':
            opString = initStringWithString("_+_") ;
            printf("Adding file %s with file %s\n", file1->fileName, file2->fileName) ;
            break;
            
        case '-':
            opString = initStringWithString("_-_") ;
            printf("Subtracting file %s from file %s\n", file2->fileName, file1->fileName) ;
            break;
            
        case 'x':
            opString = initStringWithString("_X_") ;
            printf("Multiplicating file %s with file %s\n", file1->fileName, file2->fileName) ;
            break;
            
        case '/':
            opString = initStringWithString("_div_") ;
            printf("Dividing file %s by file %s\n", file1->fileName, file2->fileName) ;
            break;
            
        case 'N':
            opString = initStringWithString("_NaN_") ;
            genFloatNaN() ;
            printf("NaN masking file %s by file %s\n", file1->fileName, file2->fileName) ;
            break;
            
        default:
            ase("Opertor not recognized") ;
            break;
    }
    
    inPlace = 0 ;
    if (argc > 4) {
        if (isWriteAccessGrantedAtPath((char *)argv[4])) {
            outputFileName = getFileNameFromPath((char *)argv[4]) ;
        }
    }
    if (isArgumentPresent(argc, argv, "-i")) {
        inPlace = 1 ;
    }
    else {
        outputFileName = initStringWith3Strings(file1->fileName, opString, file2->fileName) ;
        outputPath = concatenateStrings(file1->directoryPath, outputFileName) ;
        outputFile = openRawFileForWritingAtPath(outputPath) ;
        free(outputPath) ;
        free(outputFileName) ;
    }
    
    file1->type = file2->type = 4 ;
    data1 = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->type) ;
    data2 = vectorOfType(0, _BUFFER_SIZE_ - 1, file2->type) ;
    result = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->type) ;
    nBlocs = file1->fileLength / file1->type / _BUFFER_SIZE_ ;
    lastBlocSize = file1->fileLength / file1->type - nBlocs * _BUFFER_SIZE_  ;
    
    for (iB = 0; iB <= nBlocs; iB++) {
        blocSize = (iB == nBlocs)? lastBlocSize : _BUFFER_SIZE_ ;
        fread(data1, file1->type, blocSize, file1->f) ;
        fread(data2, file2->type, blocSize, file2->f) ;
        for (iX = 0; iX < blocSize; iX++) {
            switch (operator) {
                case '+':
                    result[iX] = data1[iX] + data2[iX] ;
                    break;
                    
                case '-':
                    result[iX] = data1[iX] - data2[iX] ;
                    break;
                    
                case 'x':
                    result[iX] = data1[iX] * data2[iX] ;
                    break;
                    
                case '/':
                    result[iX] = data1[iX] / data2[iX] ;
                    break;
                    
                case 'N':
                    result[iX] = (data2[iX])? data1[iX] : floatNaN ;
                    break;
                    
                default:
                    break;
            }
        }
        if (inPlace) {
            fseek(file1->f, -1 * blocSize * file1->type, SEEK_CUR) ;
            fwrite(result, file1->type, blocSize, file1->f) ;
        }
        else {
            fwrite(result, file1->type, blocSize, outputFile->f) ;
        }
    }
    
    freeVectorOfType(data1, 0, file1->type) ;
    freeVectorOfType(data2, 0, file2->type) ;
    freeVectorOfType(result, 0, file1->type) ;
    freeRawFileDescriptor(file1) ;
    freeRawFileDescriptor(file2) ;
    if (!inPlace) {
        freeRawFileDescriptor(outputFile) ;
    }

    return 0;
}


void usage()
{
    printf("Usage: ffa = floatFilesArithmetics\nffa pathToFile1 A pathToFile2 [-i]\n") ;
    printf("where A is the classical arithmetic sign, i.e. +, -, x or /\n") ;
    printf("Options:\n") ;
    printf("\t-i: In place --> First file is replaced by the result\n") ;
    exit(0) ;
}
