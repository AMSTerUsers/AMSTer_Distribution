
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  SentinelDataDownloader
//
//  Created by Dominique Derauw on 10/05/19.
//  Copyright © 2019 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "fileAccessLib.h"
#include "planeGeometry.h"
#include "aoiHandling.h"
#include "basicXMLHandlingLib.h"
#include "stringLib.h"
#include "COPERNICUSAccessLib.h"
#include "infoImageS1.h"
#include "S1DataReaderLib.h"
#include "gridMapping.h"
#include "EGMLib.h"

#define _SHORTSIGNBIT_ 0b1000000000000000


typedef struct S1DataDownloader
{
    char *productType ;
    char *queryURL ;
    char *orbit ;
    char *destDir ;
    char *DEMDir, *DEMName, *maskDir, *downloadDEMDir ;
    char *collection ;
    char *locationName ;
    int relativeOrbitNumber ;
    int startYear, startMonth, startDay, endYear, endMonth, endDay ;
    polygon *aoi, *rectAoi ;
    CSVStruct *idListing, *nameListing ;
    CSVStruct *status, *fileSize ;
} S1DataSearch ;

void usage (void) ;
char isDataPresentInDestDir(char *destDir, char *dataName, char *dataLength) ;
S1DataSearch *allocRequest(void) ;
void freeRequest(S1DataSearch *aRequest) ;
void buildQuery(S1DataSearch *aRequest) ;
void buildDEMQuery(S1DataSearch *aRequest) ;
void getListings(S1DataSearch *aRequest) ;
void getCOPERNICUSDEM(S1DataSearch *aRequest) ;

int main(int argc, const char * argv[]) {
    char *from, *to, *today, *kml, *orbit, *currentDir ;
    char readAndTrash, *pol ;
    char *productType = NULL ;
    char *command ;
    char isExternalMaskDirDefined ;
    char *maskDir, *DEMDir ;
    char *sizeString = NULL ;
    char *outputPath, *fileName ;
    char *frameListFilePath ;
    int isEW, isSM, isETAD, isS2, isDEM, checkSize = 0 ;
    int index, i, j ;
    int yearFrom, monthFrom, dayFrom, yearTo, monthTo, dayTo, dateFrom, dateTo ;
    int endYear ;
    size_t thisFileSize ;
    CSVStruct *idListing, *nameListing ;
    CSVStruct *status, *fileSize ;
    CSVStruct *tokens ;
    CSVStruct *csv ;
    CSVStruct *S1DataReaderCLParams = NULL ;
    CSVStruct *existingFrames ;
    CSVStruct *credentials = NULL ;
    rawFileDescriptor *thisFile ;
    rawFileDescriptor *frameListFile ;
    static time_t lastTokenRenewal = 0, now ;
    S1DataSearch *request, *ETADRequest = NULL ;
    polygon *aoi ;

    setvbuf(stdout, NULL, _IONBF, 0) ; 
    printf("S1DataDownloader - Requesting data download from COPERNICUS servers\n") ;
    /* Establish the date */
    now = time(NULL);

    /* Initialize strings */
    from = to = kml = orbit = NULL ;

    /* Do I have to check size of already present data? */
    checkSize= isFlagPresent(argc, argv, "v") ;

    /* Alloc request structure */
    request = allocRequest() ;

    /* Manage kml */
    if ((index = isArgumentPresent(argc, argv, "kml="))) {
        kml = initStringWithString((char *)argv[index] + 4) ;
    }
    else {
        printf("\t\t-/-> No kml file path given in input. \n\n") ;
        usage() ;
    }
    if ((request->aoi = getPolygonalAoIFromKMLFile(kml)) == NULL) {
        usage() ;
    }
    printf("\t---> kml considered to limit data search: %s\n", getPointerToFileNameInPath(kml)) ;
        
    /* Verify input parameters */
    if ((index = isArgumentPresent(argc, argv, "from="))) {
        from = initStringWithString((char *)argv[index] + 5) ;
    }
    else {
        from = initStringWithString("20140420") ;
    }

    if ((index = isArgumentPresent(argc, argv, "to="))) {
        to = initStringWithString((char *)argv[index] + 3) ;
    }
    else {
        to = allocStringOfLength(10) ;
        strftime(to, 10, "%Y%m%d", gmtime(&now)) ;
    }

    if ((readAndTrash = isFlagPresent(argc, argv, "r"))) {
        /* Preparing S1DataDownloader command line parameters */
        S1DataReaderCLParams = addStringValInCSVStruct("S1DataReader", NULL) ;
        S1DataReaderCLParams = addStringValInCSVStruct("filePath", S1DataReaderCLParams) ;
        S1DataReaderCLParams = addStringValInCSVStruct(kml, S1DataReaderCLParams) ;
        if ((index = isArgumentPresent(argc, argv, "P="))) {
            pol = initStringWith2Strings((char *)argv[index], " ") ;
            S1DataReaderCLParams = addStringValInCSVStruct(pol, S1DataReaderCLParams) ;
            free(pol) ;
        }
        if (isFlagPresent(argc, argv, "s")){
            S1DataReaderCLParams = addStringValInCSVStruct("-s ", S1DataReaderCLParams) ;
        }
        if (isFlagPresent(argc, argv, "o")){
            S1DataReaderCLParams = addStringValInCSVStruct("-o ", S1DataReaderCLParams) ;
        }
        if (isFlagPresent(argc, argv, "k")){
            S1DataReaderCLParams = addStringValInCSVStruct("-k ", S1DataReaderCLParams) ;
        }
        S1DataReaderCLParams = addStringValInCSVStruct("-r ", S1DataReaderCLParams) ;
    }
    

    if ((index = isArgumentPresent(argc, argv, "orbit="))) {
        request->orbit = initStringWithString((char *)argv[index] + 6) ;
    }

    /* Check requested orbit number */
    if (request->orbit) {
        sscanf(request->orbit, "%d", &request->relativeOrbitNumber) ;
        if (request->relativeOrbitNumber <= 0 || request->relativeOrbitNumber > 180) {
            printf("Wrong relativeOrbitNumber. Outside of authorized interval [0 ; 180]\n") ;
            usage() ;
        }
        printf("\t---> Limiting search to relative orbit %s\n", request->orbit) ;
    }

    /* Check requested image type */
    isEW = isArgumentPresent(argc, argv, "-EW") ;
    isDEM = isArgumentPresent(argc, argv, "-DEM") ;
    isETAD = (isArgumentPresent(argc, argv, "-ETAD") )? -1 : (isArgumentPresent(argc, argv, "+ETAD"))? 1 : 0 ;
    isS2 = (isArgumentPresent(argc, argv, "-S2MSI2A") )? 2 : (isArgumentPresent(argc, argv, "-S2MSI1C"))? 1 : 0 ;
    isSM = (isS2)? 0 : isArgumentPresent(argc, argv, "-S") ;
    checkSize = (isETAD < 0)? 1 : checkSize ;
    
    /* Determine product type */
    if (isS2) {
        productType = (isS2 == 1)? initStringWithString("S2MSI1C") : initStringWithString("S2MSI2A") ;
        request->collection = initStringWithString("SENTINEL-2") ;
        readAndTrash = 0 ;
    }
    if(isEW || isSM) {
        productType = (isEW)? initStringWithString("EW_SLC__1S") : (isSM)? initStringWith2Strings((char *)argv[isSM] + 1, "_SLC__1S") : (isETAD < 0)? initStringWithString("IW_ETA__AX") : ("IW_SLC__1S") ;
        request->collection = initStringWithString("SENTINEL-1") ;
    }
    if (isDEM) {
        request->collection = initStringWithString("CCM") ;
        productType = initStringWithString("COP-DEM_GLO-30-DTED") ;
        request->locationName = getFileNameFromPath(kml) ;
        stripExtensionAtEndOfPath(request->locationName) ;
        aoi = getRectangularAoIFromKMLFile(kml) ;
        request->rectAoi = allocPolygon(5) ;
        for(i = 0; i < aoi->N; i++) {
            memcpy(request->rectAoi->V[i], aoi->V[i], 2 * sizeof(request->rectAoi->V[0][0])) ;
        }
        memcpy(request->rectAoi->V[i], aoi->V[0], 2 * sizeof(request->rectAoi->V[0][0])) ;
        freePolygon(aoi) ;

        /* Date range */
        request->startYear = 1998 ;
        request->startMonth = 04 ;
        request->startDay = 01 ;
        today = allocStringOfLength(10) ;
        strftime(today, 10, "%Y%m%d", gmtime(&now)) ;
        sscanf(today, "%4d%2d%2d", &request->endYear, &request->endMonth, &request->endDay) ;
        free(today) ;
    }

    /* Check if product type was set. Else we deal with IW Sentine1 products*/
    request->productType = (productType == NULL)? initStringWithString("IW_SLC__1S") : initStringWithString(productType);
    if (isETAD < 0) {
        request->productType = initStringWithString(request->productType) ;
        request->collection = initStringWithString("SENTINEL-1") ;
        replaceSubStringInString(request->productType, "SLC__1S", "ETA__AX") ;
    }
    printf("\t---> Requested image type is %s\n", request->productType) ;
    
    currentDir = allocStringOfLength(MAXPATHLEN) ;
    currentDir = getcwd(currentDir, MAXPATHLEN) ;
    index = 0 ;
    if ((index = isArgumentPresent(argc, argv, "destDir="))) {
        request->destDir = initStringWithString((char *)argv[index] + 8) ;
        if (!isDir(request->destDir)) {
            printf("\t-/-> Destination directory not existing\n\n") ;
            usage() ;
        }
        
        if (!isWriteAccessGrantedAtPath(request->destDir)) {
            printf("\t-/-> Write access denied in destination dir\n\n") ;
            usage() ;
        }
    }
    else {
        request->destDir = initStringWithString(currentDir) ;
    }

    if (isETAD > 0) {
        ETADRequest = allocRequest() ;
        ETADRequest->productType = initStringWithString(request->productType) ;
        ETADRequest->startYear = -1 ;
        ETADRequest->collection = initStringWithString("SENTINEL-1") ;
        replaceSubStringInString(ETADRequest->productType, "SLC__1S", "ETA__AX") ;
        ETADRequest->destDir = initStringWithString(request->destDir) ;
        ETADRequest->aoi = getCopyOfPolygon(request->aoi) ;
        if (request->orbit) {
            ETADRequest->orbit = initStringWithString(request->orbit) ;
            ETADRequest->relativeOrbitNumber = request->relativeOrbitNumber ;
        }
        readAndTrash = 0 ;
    }

    if (isDEM) {
        /* Get DEM default destination directories */
        isExternalMaskDirDefined = 1 ;
        if ((maskDir = getenv("EXTERNAL_MASKS_DIR")) == NULL) {
            printf("\t-/-> EXTERNAL_MASKS_DIR environment variable not defined\n") ;
            printf("\t-/-> Water body mask will not be saved\n\n") ;
            isExternalMaskDirDefined = 0 ;
        }
        request->maskDir = initStringWithString(maskDir) ;

        if ((DEMDir = getenv("EXTERNAL_DEMS_DIR")) == NULL) {
            printf("\t-/-> EXTERNAL_DEMS_DIR environment variable not defined\n") ;
        }
        if (isDir(DEMDir)) {
            request->DEMDir = initStringWithString(DEMDir) ;
            free(request->destDir) ;
            request->destDir = initStringWithString(request->DEMDir) ;
        }
        else {
            request->DEMDir = initStringWithString(request->destDir) ;
        }
        
        if ((i = isArgumentPresent(argc, argv, "-DEM="))) {
            request->DEMName = initStringWithString((char *)(argv[i] + 5)) ;
        }

        getCOPERNICUSDEM(request) ;
    }
    
    /* Check if collection was set. Else we deal with IW Sentinel1 products */
    if (request->collection == NULL) {
        request->collection = initStringWithString("SENTINEL-1") ;
    } 
    printf("\t---> Considered collection : %s\n", request->collection) ;
    
    chdir(request->destDir) ;
    printf("\t---> Destination directory: %s\n", request->destDir) ;


    /* Check dates */
    sscanf(from, "%d", &dateFrom) ;
    sscanf(from, "%4d%2d%2d", &yearFrom, &monthFrom, &dayFrom) ;
    sscanf(to, "%d", &dateTo) ;
    sscanf(to, "%4d%2d%2d", &yearTo, &monthTo, &dayTo) ;
    if (dateFrom > dateTo) {
        printf("Better to request an end date after the start date...\n") ;
        usage() ;
    }
    if (yearFrom < 2014 || yearTo < 2014) {
        printf("Sentinel1 was not launched at that date....\n") ;
        usage() ;
    }
    if (monthFrom < 1 || monthFrom > 12 || monthTo < 1 || monthTo > 12 ) {
        printf("Month are supposed to be between 1 and 12....\n") ;
        usage() ;
    }
    if (dayFrom < 1 || dayFrom > 31 || dayTo < 1 || dayTo > 31 ) {
        printf("Days are supposed to be between 1 and 31....\n") ;
        usage() ;
    }
    printf("\t---> Search start date: %s\n", from) ;
    printf("\t---> Search end date: %s\n", to) ;


    /* Let's go! */     
    endYear =  yearTo + 1 ;
    do {
        endYear-- ;
        request->endYear = endYear ;
        /* If request cover several years, start from first of january of last year */
        if (yearFrom != endYear) {
            printf("\n\nRequesting data acquired in %d\n", endYear) ;
            printf("--------------------------------\n") ;
            request->startYear = endYear ;
            request->startMonth = 1 ;
            request->startDay = 1 ;
        }
        else {
            request->startYear = yearFrom ;
            request->startMonth = monthFrom ;
            request->startDay = dayFrom ;
        }

        if (endYear == yearTo) {
            request->endYear = yearTo ;
            request->endMonth = monthTo ;
            request->endDay = dayTo ;
        }
        else {
            request->endMonth = 12 ;
            request->endDay = 31 ;
        }

        buildQuery(request) ;    
        getListings(request) ;

        if (isETAD > 0) {
            ETADRequest->startYear = request->startYear ;
            ETADRequest->startMonth = request->startMonth ;
            ETADRequest->startDay = request->startDay ;
            ETADRequest->endYear = request->endYear ;
            ETADRequest->endMonth = request->endMonth ;
            ETADRequest->endDay = request->endDay ;
            buildQuery(ETADRequest) ;
            getListings(ETADRequest) ;
        }
        

        if (request->idListing) {
            idListing = request->idListing ;
            nameListing = request->nameListing ;
            status = request->status ;
            fileSize = request->fileSize ;
        
            printf("\t---> Number of images found: %d.\n", nameListing->numberOfEntries) ;

            /* First, clean listing from already downloaded data */
            printf("\t---> Cleaning listing.\n") ;   
            for (index = 0; index < idListing->numberOfEntries; index++) {
                fileName = replaceSubStringsInString(nameListing->stringVal[index], ".SAFE", ".zip") ;

                if (checkSize) {
                    sizeString = fileSize->stringVal[index] ;
                }
                if (isDataPresentInDestDir(request->destDir, fileName, sizeString) || !isSubStringPresentInString(status->stringVal[index], "true")) {
                    removeStringValAtIndexInCSVStruct(index, idListing) ;
                    removeStringValAtIndexInCSVStruct(index, nameListing) ;
                    removeStringValAtIndexInCSVStruct(index, status) ;
                    removeStringValAtIndexInCSVStruct(index, fileSize) ;
                    index-- ;
                }
                free(fileName) ;
            }

            if (readAndTrash) {
                if ((existingFrames = listReadS1FramesInDir(request->destDir))) {
                    /* Clean listing of images to read */
                    printf("\t---> %d existing frames(s) found/registered\n", existingFrames->numberOfEntries) ;
                    printf("\t---> Cleaning listing of S1 frame to be downloaded and read\n") ;
                    for (i = 0; i < idListing->numberOfEntries; i++) {
                        for (j = 0; j < existingFrames->numberOfEntries; j++) {
                            if (isSubStringPresentInString(nameListing->stringVal[i], existingFrames->stringVal[j])) {
                                printf("\t\t---> Skipping frame %s\n", existingFrames->stringVal[j]) ;
                                printf("\t\t---> Frame already present in destination directory\n\n") ;
                                removeStringValAtIndexInCSVStruct(i, idListing) ;
                                removeStringValAtIndexInCSVStruct(i, nameListing) ;
                                removeStringValAtIndexInCSVStruct(i, status) ;
                                removeStringValAtIndexInCSVStruct(i, fileSize) ;
                                removeStringValAtIndexInCSVStruct(j, existingFrames) ;
                                i-- ;
                                j = existingFrames->numberOfEntries ;
                            }
                        }
                    }
                    freeCSVStruct(existingFrames) ;
                }
                frameListFilePath = initStringWith2Strings(request->destDir, "/readFramesListing.txt") ;
                frameListFile = openRawFileForReadingAndWritingAtPath(frameListFilePath) ;
                fseek(frameListFile->f, 0, SEEK_END) ;
                free(frameListFilePath) ;
            }
            
            printf("\t---> Number of images to download: %d\n", nameListing->numberOfEntries) ;
            if (index){
                if (!credentials) {
                    if((credentials = getCopernicusCredentials()) == NULL) {
                        ase("\t-/-> Failed to read COPERNICUS credentials. Please update your .netrc file\n") ;
                    }
                }
                
                printf("\n\t---> Starting on-line data download\n") ;
                printf("\t---> ------------------------------\n") ;

                if (!lastTokenRenewal) {
                    lastTokenRenewal = connectToCopernicusServer(credentials) ;
                }
                else {
                    now = time(NULL) ;
                    /* Normally COPERNICUS connection closes after 600 seconds. Let's take a one minute margin */
                    if (now - lastTokenRenewal > 540) {
                        lastTokenRenewal = refreshConnection(tokens, credentials) ;
                        freeCSVStruct(tokens) ;
                    }
                }
                
                if((tokens = getCopernicusTokens()) == NULL) {
                    /* May be we even pass the one hour delay for repetitive reconection. So let's try a new session */
                    lastTokenRenewal = connectToCopernicusServer(credentials) ;
                    if((tokens = getCopernicusTokens()) == NULL) {
                        printf("Failed to refresh Copernicus server connection.\n") ;
                        printf("Will wait a few before trying to reconnect\n") ;
                        waitAWhile(600) ;
                        lastTokenRenewal = connectToCopernicusServer(credentials) ;
                        if((tokens = getCopernicusTokens()) == NULL) {
                            ase("Failed to connect to Copernicus server\n") ;
                        }
                    }
                }

                for ( index = 0; index < idListing->numberOfEntries; index++) {
                    fileName = initStringWithString(nameListing->stringVal[index]) ;
                    sscanf(fileSize->stringVal[index],"%ld", &thisFileSize) ;
                    stripExtensionAtEndOfPath(fileName) ;
                    outputPath = initStringWith4Strings(request->destDir, "/", fileName, ".zip") ;
                    csv = addStringValInCSVStruct("curl -H \"Authorization: Bearer ", NULL) ;
                    csv = addStringValInCSVStruct(tokens->stringVal[0], csv) ;
                    csv = addStringValInCSVStruct("\" 'https://catalogue.dataspace.copernicus.eu/odata/v1/Products(", csv) ;
                    csv = addStringValInCSVStruct(idListing->stringVal[index], csv) ;
                    csv = addStringValInCSVStruct(")/$value' --location-trusted --output ", csv) ;
                    csv = addStringValInCSVStruct(outputPath, csv) ;

                    command = getStringFromCSV(csv) ;
                    freeCSVStruct(csv) ;

                    printf("\nDownload %d/%d\n", index + 1, idListing->numberOfEntries) ;
                    printf("\t---> Starting download of %s\n", nameListing->stringVal[index]) ;
                    printf("\t---> Saved as %s\n", getPointerToFileNameInPath(outputPath)) ;
                    system(command) ;

                    /* Check size of downloaded file */
                    thisFile = openRawFileForReadingAtPath(outputPath) ;
                    if (thisFile->fileLength < thisFileSize) {
                        closeRawFile(thisFile) ;
                        printf("\t-/-> Downloaded file has not expected size. Removing it and relaunching download.\n") ;
                        unlink(outputPath) ;
                        system(command) ;
                        openRawFileForReading(thisFile) ;
                        if (thisFile->fileLength <= thisFileSize) {
                            printf("\t-/-> Downloaded file has still not expected size. Removing it and skipping download.\n") ;
                            unlink(outputPath) ;
                        }
                    }
                    freeRawFileDescriptor(thisFile) ;
                    free(command) ;

                    if (checkSize && ETADRequest) {
                        i = 0 ;
                        while (strncmp(nameListing->stringVal[index] + 17, ETADRequest->nameListing->stringVal[i] + 17, 45) && i < ETADRequest->nameListing->numberOfEntries) {
                            i++ ;
                        }
                        
                        if (i < ETADRequest->nameListing->numberOfEntries) {
                            free(fileName) ;
                            fileName = initStringWithString(ETADRequest->nameListing->stringVal[i]) ;
                            sscanf(ETADRequest->fileSize->stringVal[0],"%ld", &thisFileSize) ;
                            stripExtensionAtEndOfPath(fileName) ;
                            outputPath = initStringWith4Strings(request->destDir, "/", fileName, ".zip") ;
                            csv = addStringValInCSVStruct("curl -H \"Authorization: Bearer ", NULL) ;
                            csv = addStringValInCSVStruct(tokens->stringVal[0], csv) ;
                            csv = addStringValInCSVStruct("\" 'https://catalogue.dataspace.copernicus.eu/odata/v1/Products(", csv) ;
                            csv = addStringValInCSVStruct(ETADRequest->idListing->stringVal[i], csv) ;
                            csv = addStringValInCSVStruct(")/$value' --location-trusted --output ", csv) ;
                            csv = addStringValInCSVStruct(outputPath, csv) ;
        
                            command = getStringFromCSV(csv) ;
                            freeCSVStruct(csv) ;

                            system(command) ;
                            free(command) ;

                            removeStringValAtIndexInCSVStruct(i, ETADRequest->nameListing) ;
                        }
                    }                    

                    /* If reading is requested, proceed and trash downloaded data afterwards */
                    if (checkSize && readAndTrash) {
                        free(S1DataReaderCLParams->stringVal[1]) ;
                        S1DataReaderCLParams->stringVal[1] = initStringWithString(outputPath) ;
                        if ((csv = S1DataReader(S1DataReaderCLParams))) {
                            fprintf(frameListFile->f, "%s\n", nameListing->stringVal[index]) ;
                            freeCSVStruct(csv) ;
                            fflush(frameListFile->f) ;
                        }                        

                        unlink(outputPath) ;
                    }
                    
                    free(fileName) ;
                    free(outputPath) ;

                    now = time(NULL) ;
                    if (now - lastTokenRenewal > 540) {
                        lastTokenRenewal = refreshConnection(tokens, credentials) ;
                        freeCSVStruct(tokens) ;
                        if((tokens = getCopernicusTokens()) == NULL) {
                            printf("Failed to refresh Copernicus server connection.\n") ;
                            printf("Will wait a few before trying to reconnect\n") ;
                            waitAWhile(600) ;
                            lastTokenRenewal = connectToCopernicusServer(credentials) ;
                            if((tokens = getCopernicusTokens()) == NULL) {
                                ase("Failed to connect to Copernicus server\n") ;
                            }
                        }
                    }
                }
            }
            if (readAndTrash) {
                freeRawFileDescriptor(frameListFile) ;
            }
        }
        else {
            printf("\t---> No images found\n\n") ;
        }
        
    } while (yearFrom != endYear);
    chdir(currentDir) ;
    free(currentDir) ;
    freeRequest(request) ;
    if (isETAD > 0) {
        freeRequest(ETADRequest) ;
    }
    if (credentials) {
        freeCSVStruct(credentials) ;
    }
    

    return 0;
}


void usage()
{
    printf("Usage:\nSentinelDataDownloader -v from=startDate to=endData kml=kmlFilePath destDir=/downloadPath [orbit=relativeOrbitNumber] [-EW] [-Sn] [+/-ETAD] | [-S2MSI1C] | [-S2MSI2A] [-DEM[=DEMName]]\n") ;
    printf("Dates are in format YYYYMMDD\n") ;
    printf("\n-v: In case data already exists at destination path, it is removed provided its size differs to the one to be downloaded.\n") ;
    printf("       If older data were previously downloaded from other servers (SciHub, ONDA, ASF, ...), size may differs from the one of zipped data from COPERNICUS serveurs.\n") ;
    printf("       In such case, activating -v will systematically supress old data, re-downloading it from COPERNICUS server.\n\n") ;
    printf(" By default, SentinelDataDownloader is meant at downloading S1 IW products. \n") ;
    printf(" EW or Stripmap data may be requested using the corresponding keyword.\n") ;
    printf("-Sn: In case requesting strip map image, the beam index n must be specified.\n") ;
    printf("-ETAD: Allows downloading ETAD data for the given date range, kml and orbit. \n") ;
    printf("+ETAD: ETAD data corresponding to requested SAR products are downloaded provided they are available. \n") ;
    printf("-S2MSI1C | -S2MSI2A: Allows downloading Sentinel2 products. \n") ;
    printf("-DEM: COPERNICUS DEM will be downloaded and saved at destination path with the same file name that the given kml.\n") ;
    printf("-DEM=DEMName: COPERNICUS DEM will be downloaded and saved at destination path with given name.\n") ;
    printf("\tIf EXTERNAL_DEMS_DIR system variable is defined, DEM will be saved at corresponding location\n") ;
    printf("\tDownloaded DEMs are \"corrected\" from available Earth Gravitational Models (EGM) to get ellipsoidal heights\n") ;
    printf("\tEach Gravitational Model must be saved in a directory named following EGM year within directory defined by EARTH_GRAVITATIONAL_MODELS_DIR environment variable.\n") ; 
    printf("\tEGM's can be downloaded from https://geographiclib.sourceforge.io/C++/doc/geoid.html\n\n") ;
    exit(0) ;
}



/* Verify if image is already existing in destination directory */
char isDataPresentInDestDir(char *destDir, char *dataName, char *dataLength)
{
    char *archiveFilePath, isPresent = 0 ;
    size_t fileLength = 0 ;
    rawFileDescriptor *zippedFile ;

    archiveFilePath = initStringWith3Strings(destDir, "/", dataName) ;
    if (fileExistsAtPath(archiveFilePath)) {
        isPresent = 1 ;
        if (dataLength) {
            zippedFile = openRawFileForReadingAtPath(archiveFilePath) ;
            sscanf(dataLength, "%ld", &fileLength) ;
            if (zippedFile->fileLength < fileLength) {
                printf("\n\t\t---> Archive name: %s\n", dataName) ;
                printf("\t\t---> Archive already existing in destination directory but has wrong size\n") ;
                printf("\t\t---> Removing file to allow relaunching download \n") ;
                unlink(archiveFilePath) ;
                isPresent = 0 ;
            }
            freeRawFileDescriptor(zippedFile) ;
        }
        if (isPresent) {
            printf("\n\t\t---> Archive name: %s\n", dataName) ;
            printf("\t\t---> Archive already existing in destination directory\n\t\t---> Skipping download\n") ;
        }
    }
    free(archiveFilePath) ;

    return (isPresent) ;
}


S1DataSearch *allocRequest(void) 
{
    S1DataSearch *aRequest ;

    aRequest = malloc(sizeof(aRequest[0])) ;
    aRequest->collection = NULL ;
    aRequest->productType = NULL ;
    aRequest->idListing = NULL ;
    aRequest->nameListing = NULL ;
    aRequest->fileSize = NULL ;
    aRequest->status = NULL ;
    aRequest->queryURL = NULL ;
    aRequest->aoi = NULL ;
    aRequest->orbit = NULL ;
    aRequest->DEMDir = NULL ;
    aRequest->DEMName = NULL ;
    aRequest->maskDir = NULL ;
    aRequest->relativeOrbitNumber = 0 ;
    aRequest->startYear = 0 ;
    aRequest->locationName = NULL ;

    return (aRequest) ;
}

void freeRequest(S1DataSearch *aRequest) 
{
    free(aRequest->productType) ;
    free(aRequest->collection) ;
    free(aRequest->queryURL) ;
    free(aRequest->destDir) ;
    if (aRequest->DEMDir) {
        free(aRequest->DEMDir) ;
    }
    if (aRequest->DEMName) {
        free(aRequest->DEMName) ;
    }
    if (aRequest->locationName) {
        free(aRequest->locationName) ;
    }
    freeCSVStruct(aRequest->idListing) ;
    freeCSVStruct(aRequest->nameListing) ;
    freeCSVStruct(aRequest->fileSize) ;
    freeCSVStruct(aRequest->status) ;
    freePolygon(aRequest->aoi) ;

    if (aRequest->orbit) {
        free(aRequest->orbit) ;
    }
    
    free(aRequest) ;
}



void buildQuery(S1DataSearch *aRequest)
{
    char *baseURL ;
    char *attributeRequest ;
    char fromDateRequest[32], toDateRequest[32] ;
    CSVStruct *csv ;

    baseURL = initStringWithString("\"https://catalogue.dataspace.copernicus.eu/odata/v1/Products?\\$filter=") ;

    /* Preparing Query */
    csv = addStringValInCSVStruct(baseURL, NULL) ;

    /* Requesting  collection */
    csv = addStringValInCSVStruct("Collection/Name%20eq%20%27", csv) ;
    csv = addStringValInCSVStruct(aRequest->collection, csv) ;
    csv = addStringValInCSVStruct("%27", csv) ;

    /* Requesting polygone */
    if (aRequest->DEMDir == NULL) {
        attributeRequest = getCOPERNICUSPolygonRequestFromKml(aRequest->aoi) ;
    }
    else {
        attributeRequest = getCOPERNICUSPolygonRequestFromKml(aRequest->rectAoi) ;
    }
    csv = addStringValInCSVStruct("%20and%20", csv) ;
    csv = addStringValInCSVStruct(attributeRequest, csv) ;
    free(attributeRequest) ;

    /* requesting time interval */
    sprintf(fromDateRequest, "%04d-%02d-%02dT00:00:00.000Z", aRequest->startYear, aRequest->startMonth, aRequest->startDay) ;
    sprintf(toDateRequest, "%04d-%02d-%02dT23:59:59.000Z", aRequest->endYear, aRequest->endMonth, aRequest->endDay) ;
    csv = addStringValInCSVStruct("%20and%20ContentDate/Start%20ge%20", csv) ;
    csv = addStringValInCSVStruct(fromDateRequest, csv) ;
    csv = addStringValInCSVStruct("%20and%20ContentDate/Start%20lt%20", csv) ;
    csv = addStringValInCSVStruct(toDateRequest, csv) ;
    
    /* Requesting product type */
    attributeRequest = getCOPERNICUSStringAttributeRequest("productType", aRequest->productType) ;
    csv = addStringValInCSVStruct("%20and%20", csv) ;
    csv = addStringValInCSVStruct(attributeRequest, csv) ;
    free(attributeRequest) ;

    /* Requesting specific orbit */
    if (aRequest->orbit) {
        attributeRequest = getCOPERNICUSIntegerAttributeRequest("relativeOrbitNumber", aRequest->relativeOrbitNumber) ;
        csv = addStringValInCSVStruct("%20and%20", csv) ;
        csv = addStringValInCSVStruct(attributeRequest, csv) ;
        free(attributeRequest) ;
    }
    csv = addStringValInCSVStruct("&\\$top=500\"", csv) ;

    free(baseURL) ;
    aRequest->queryURL = getStringFromCSV(csv) ;
    freeCSVStruct(csv) ;
}

void buildDEMQuery(S1DataSearch *aRequest)
{
    char *baseURL ;
    char *attributeRequest ;
    char fromDateRequest[32], toDateRequest[32] ;
    CSVStruct *csv ;
    polygon *aoi ;

    /* Check requested aoi to avoid downloading useless DEM tiles */
    aoi = getCopyOfPolygon(aRequest->rectAoi) ;
    if (aoi->P[2].x == ceil(aoi->P[2].x)) {
        aoi->P[2].x -= .01 ;
        aoi->P[1].x -= .01 ;
    }
    if (aoi->P[2].y == ceil(aoi->P[2].y)) {
        aoi->P[2].y -= .01 ;
        aoi->P[3].y -= .01 ;
    }
    
    aoi->P[2].x -= (aoi->P[2].x == ceil(aoi->P[2].x)? .01 : 0) ;

    baseURL = initStringWithString("\"https://catalogue.dataspace.copernicus.eu/odata/v1/Products?&\\$filter=") ;

    /* Preparing Query */
    csv = addStringValInCSVStruct(baseURL, NULL) ;

    /* Requesting  collection */
    csv = addStringValInCSVStruct("((Collection/Name%20eq%20%27", csv) ;
    csv = addStringValInCSVStruct(aRequest->collection, csv) ;
    csv = addStringValInCSVStruct("%27", csv) ;
    csv = addStringValInCSVStruct("%20and%20(", csv) ;

    /* Requesting full dataset */
    attributeRequest = getCOPERNICUSStringAttributeRequest("datasetFull", aRequest->productType) ;
    csv = addStringValInCSVStruct(attributeRequest, csv) ;
    free(attributeRequest) ;

    /* Requesting polygone */
    csv = addStringValInCSVStruct("%20and%20", csv) ;
    attributeRequest = getCOPERNICUSPolygonRequestFromKml(aoi) ;
    csv = addStringValInCSVStruct(attributeRequest, csv) ;
    free(attributeRequest) ;

    /* Requesting all DEM data sets */
    csv = addStringValInCSVStruct(")%20and%20(", csv) ;
    attributeRequest = getCOPERNICUSStringAttributeRequest("dataset", "COP-DEM_GLO-30-DGED/2024_1") ;
    csv = addStringValInCSVStruct(attributeRequest, csv) ;
    free(attributeRequest) ;

    csv = addStringValInCSVStruct("%20or%20", csv) ;
    attributeRequest = getCOPERNICUSStringAttributeRequest("dataset", "COP-DEM_GLO-30-DTED/2024_1") ;
    csv = addStringValInCSVStruct(attributeRequest, csv) ;
    free(attributeRequest) ;

    csv = addStringValInCSVStruct("%20or%20", csv) ;
    attributeRequest = getCOPERNICUSStringAttributeRequest("dataset", "COP-DEM_GLO-90-DGED/2024_1") ;
    csv = addStringValInCSVStruct(attributeRequest, csv) ;
    free(attributeRequest) ;

    csv = addStringValInCSVStruct("%20or%20", csv) ;
    attributeRequest = getCOPERNICUSStringAttributeRequest("dataset", "COP-DEM_GLO-90-DTED/2024_1") ;
    csv = addStringValInCSVStruct(attributeRequest, csv) ;
    free(attributeRequest) ;

    csv = addStringValInCSVStruct("%20or%20", csv) ;
    attributeRequest = getCOPERNICUSStringAttributeRequest("dataset", "COP-DEM_EEA-10-DGED/2024_1") ;
    csv = addStringValInCSVStruct(attributeRequest, csv) ;
    free(attributeRequest) ;

    csv = addStringValInCSVStruct("%20or%20", csv) ;
    attributeRequest = getCOPERNICUSStringAttributeRequest("dataset", "COP-DEM_EEA-10-INSP/2024_1") ;
    csv = addStringValInCSVStruct(attributeRequest, csv) ;
    free(attributeRequest) ;
    csv = addStringValInCSVStruct(")%20and%20Online%20eq%20true)", csv) ;


    /* requesting time interval */
    sprintf(fromDateRequest, "%04d-%02d-%02dT00:00:00.000Z", aRequest->startYear, aRequest->startMonth, aRequest->startDay) ;
    sprintf(toDateRequest, "%04d-%02d-%02dT23:59:59.999Z", aRequest->endYear, aRequest->endMonth, aRequest->endDay) ;
    csv = addStringValInCSVStruct("%20and%20ContentDate/Start%20ge%20", csv) ;
    csv = addStringValInCSVStruct(fromDateRequest, csv) ;
    csv = addStringValInCSVStruct("%20and%20ContentDate/Start%20lt%20", csv) ;
    csv = addStringValInCSVStruct(toDateRequest, csv) ;
    
    csv = addStringValInCSVStruct(")&\\$top=500\"", csv) ;

    free(baseURL) ;
    aRequest->queryURL = getStringFromCSV(csv) ;
    freeCSVStruct(csv) ;
    freePolygon(aoi) ;
}


void getListings(S1DataSearch *aRequest)
{
    char *listing ;
    char *command ;
    char *aString ;
    char *queryURL ;
    CSVStruct *csv ;
    CSVStruct *csv2 ;

    freeCSVStruct(aRequest->idListing) ;
    freeCSVStruct(aRequest->nameListing) ;
    freeCSVStruct(aRequest->status) ;
    freeCSVStruct(aRequest->fileSize) ;

    queryURL = aRequest->queryURL ;
    
    /* Getting data listing */
    listing = initStringWith2Strings(aRequest->destDir, "/imageList.json") ;
    command = initStringWith4Strings("curl --silent -H \"Accept:application/json\" ", queryURL, " --output ", listing) ;  
//    printf("%s\n", command) ;

    system(command) ;
    free(command) ;

    switch (aRequest->startYear) {
    case -1 :
        printf("\t---> Getting ETAD product\n") ;
        break;

    case 1998 :
        printf("\t---> Getting COPERNICUS GEO 30  DTED DEM\n") ;
        break;
    
    default:
        printf("\n\t---> Getting listing of available data between %.4d%.2d%.2d and  %.4d%.2d%.2d\n", aRequest->startYear, aRequest->startMonth, aRequest->startDay, aRequest->endYear, aRequest->endMonth, aRequest->endDay) ;
        break;
    }
 
    
    aRequest->idListing = getCSVForKeyInJsonFile(listing, "Id") ;
    if (aRequest->idListing) {
        aRequest->nameListing = getCSVForKeyInJsonFile(listing, "Name") ;
        aRequest->status = getCSVForKeyInJsonFile(listing, "Online") ;
        aRequest->fileSize = getCSVForKeyInJsonFile(listing, "ContentLength") ;
        
        while ((csv = getCSVForKeyInJsonFile(listing, "@odata.nextLink"))) {
            aString = getStringFromCSV(csv) ;
            free(queryURL) ;
            queryURL = initStringWith3Strings("\"", aString, "\"") ;
            freeCSVStruct(csv) ;
            command = initStringWith4Strings("curl -H \"Accept:application/json\" ", queryURL, " --output ", listing) ;  
            system(command) ;
            free(command) ;
            free(queryURL) ;
            free(aString) ;
    
            if ((csv = getCSVForKeyInJsonFile(listing, "Id"))) {
                csv2 = concatenateCSVStructs(aRequest->idListing, csv) ;
                freeCSVStruct(csv) ;
                freeCSVStruct(aRequest->idListing) ;
                aRequest->idListing = csv2 ;

                csv = getCSVForKeyInJsonFile(listing, "Name") ;
                csv2 = concatenateCSVStructs(aRequest->nameListing, csv) ;
                freeCSVStruct(csv) ;
                freeCSVStruct(aRequest->nameListing) ;
                aRequest->nameListing = csv2 ;

                csv = getCSVForKeyInJsonFile(listing, "Online") ;
                csv2 = concatenateCSVStructs(aRequest->status, csv) ;
                freeCSVStruct(csv) ;
                freeCSVStruct(aRequest->status) ;
                aRequest->status = csv2 ;

                csv = getCSVForKeyInJsonFile(listing, "ContentLength") ;
                csv2 = concatenateCSVStructs(aRequest->fileSize, csv) ;
                freeCSVStruct(csv) ;
                freeCSVStruct(aRequest->fileSize) ;
                aRequest->fileSize = csv2 ;
            }
        }
    }              
}


void 
getCOPERNICUSDEM(S1DataSearch *aRequest)
{
    char * fileName, *downloadDir, *outputFilePath ;
    char *command ;
    char DTED2Header[3428] ;
    short *inputColumn ;
    int index ;
    int i, iX, iY ;
    int xDimTileIn, yDimTileIn, xDimTileOut, yDimTileOut ;
    int xDimOutput, yDimOutput ;
    int minLat0, minLon0, maxLat0, maxLon0 ;
    int EGMID ;
    long xShift, yShift, lowerLeftX, lowerLeftY ;
    size_t seekVal ;
    float **destinationTile, floatVal ;
    float latSampling, lonSampling ;
    double longitudeSampling, latitudeSampling ;
    CSVStruct *csv ;
    CSVStruct *idListing, *nameListing ;
    CSVStruct *status, *fileSize ;
    CSVStruct *tokens ;
    CSVStruct *credentials = NULL ;
    CSVStruct *DEMTileFileName ;
    static time_t lastTokenRenewal = 0, now ;
    rawFileDescriptor *outputFile, *inputTileFile ;
    gridMap *EGMHeight = NULL ;
    polygon *aoi ;
    keyValue *header ;
    gridMap *inputFloatTile ;
    
    genFloatNaN() ;

    buildDEMQuery(aRequest) ;        
    getListings(aRequest) ;

    if (aRequest->idListing->numberOfEntries == 0) {
        printf("\t-/-> No DEM tiles found\n") ;
        freeRequest(aRequest) ;
        exit(0) ;
    }
    
    idListing = aRequest->idListing ;
    nameListing = aRequest->nameListing ;
    status = aRequest->status ;
    fileSize = aRequest->fileSize ;

    printf("\t---> Number of DEM tiles found: %d.\n", nameListing->numberOfEntries) ;

    /* Get COPERNICUS credentials */
    if (!credentials) {
        if((credentials = getCopernicusCredentials()) == NULL) {
            ase("\t-/-> Failed to read COPERNICUS credentials. Please update your .netrc file\n") ;
        }
    }

    if (!lastTokenRenewal) {
        lastTokenRenewal = connectToCopernicusServer(credentials) ;
    }
    else {
        now = time(NULL) ;
        /* Normally COPERNICUS connection closes after 600 seconds. Let's take a one minute margin */
        if (now - lastTokenRenewal > 540) {
            lastTokenRenewal = refreshConnection(tokens, credentials) ;
            freeCSVStruct(tokens) ;
        }
    }
    
    tokens = getCopernicusTokens() ;

    /* There is something to download, then proceed */
    downloadDir = initStringWith3Strings(aRequest->destDir, "/_Download/", aRequest->locationName) ;
    if (!isDir(downloadDir)) {
        makeDirRecursively(downloadDir) ;
    }

    for (index = 0; index < idListing->numberOfEntries; index++) {
        fileName = initStringWithString(nameListing->stringVal[index]) ;
        stripExtensionAtEndOfPath(fileName) ;
        outputFilePath = initStringWith4Strings(downloadDir, "/", fileName, ".zip") ;
        csv = addStringValInCSVStruct("curl -H \"Authorization: Bearer ", NULL) ;
        csv = addStringValInCSVStruct(tokens->stringVal[0], csv) ;
        csv = addStringValInCSVStruct("\" 'https://catalogue.dataspace.copernicus.eu/odata/v1/Products(", csv) ;
        csv = addStringValInCSVStruct(idListing->stringVal[index], csv) ;
        csv = addStringValInCSVStruct(")/$value' --location-trusted --output ", csv) ;
        csv = addStringValInCSVStruct(outputFilePath, csv) ;

        command = getStringFromCSV(csv) ;
        freeCSVStruct(csv) ;

//        printf("%s", command) ;

        printf("\nDownload %d/%d\n", index + 1, idListing->numberOfEntries) ;
        printf("\n\t---> Starting download of %s\n", nameListing->stringVal[index]) ;
        printf("\t---> Saved as %s\n", getPointerToFileNameInPath(outputFilePath)) ;
        system(command) ;
        free(command) ;

        sprintf(aCommand, "unzip -quo %s -d %s", outputFilePath, downloadDir) ;
        system(aCommand) ;
        unlink(outputFilePath) ;
        free(outputFilePath) ;
    }
    
    /* Get tile listing */
    if ((DEMTileFileName = recursiveSearchOfFilesWithExtensionInDir("dt2", downloadDir)) == NULL) {
        ase("\t-/-> No DEM tiles downloaded and unzipped in _Download directory.\n") ;
    }
    
    /* Ok we deal with DEM tiles to aggregate. So create output file */
    if (aRequest->DEMName) {
        outputFilePath = initStringWith3Strings(aRequest->destDir, "/", aRequest->DEMName) ; 
    }
    else {
        outputFilePath = initStringWith3Strings(aRequest->destDir, "/", aRequest->locationName) ; 
    }
    

    printf("---> Creating/opening destination file at path: \t\t%s\n", outputFilePath) ;
    outputFile = openRawFileForWritingAtPath(outputFilePath) ;
    if (!outputFile) {
        ase("\t-/-> Failed to create external DEM file at requested path\n") ;
    }

    /* Initialize bounding box */
    minLon0 = (int)floor(aRequest->rectAoi->P[0].x) ;
    minLat0 = (int)floor(aRequest->rectAoi->P[0].y) ;
    maxLon0 = (int)ceil(aRequest->rectAoi->P[2].x) ;
    maxLat0 = (int)ceil(aRequest->rectAoi->P[2].y) ;

    /* Allocate output tile of 1x1 degree with 1"x1" sampling */
    longitudeSampling = latitudeSampling = 1/3600. ;
    xDimTileOut = yDimTileOut = 3601 ;
    destinationTile = matrixFloat(0, yDimTileOut - 1, 0, xDimTileOut - 1) ;
    
    /* Determine area of interest */
    aoi = allocPolygon(4) ;
    aoi->P[0].x = minLon0 ;
    aoi->P[0].y = minLat0 ;
    aoi->P[2].x = maxLon0 ;
    aoi->P[2].y = maxLat0 ;
    
    /* Compute output dimensions */
    xDimOutput = (aoi->P[2].x - aoi->P[0].x) * (xDimTileOut - 1) + 1 ;
    yDimOutput = (aoi->P[2].y - aoi->P[0].y) * (yDimTileOut - 1) + 1 ;
    
    printf("---> Reading EGM2008 area corresponding to COPERNICUS DEM tiles\n") ;
    EGMHeight = getEGMGrid(aoi, xDimOutput,  yDimOutput, "EGM2008") ;
    if (!EGMHeight) {
        printf("\t-/-> Earth Gravitational Model 2008 not available.\n") ;
        printf("\t-/-> COPERNICUS DEM will be downloaded but not corrected for gravitational ondulations\n") ;
    }
    
    for (i = 0; i < DEMTileFileName->numberOfEntries; i++) {
        /* Open DEM tile files for reading */
        inputTileFile = openRawFileForReadingAtPath(DEMTileFileName->stringVal[i]) ;
        if (!inputTileFile) {
            ase("-/-> Failed to open DEM tile.\n\n") ;
        }
        
        /* Read DTED header */
        if (fread(DTED2Header, 1, 3428, inputTileFile->f) != 3428) {
            ase("-/-> Failed to read header of DEM tile. \n\n") ;
        }
                
        /* Read sampling values given in seconds */
        sscanf(DTED2Header + 20, "%3f", &lonSampling) ;
        sscanf(DTED2Header + 24, "%3f", &latSampling) ;
        
        /* Alloc input tile matrix  taking into account DTED DEM is stored by rows at constant longitude */
        xDimTileIn = (xDimTileOut - 1) / lonSampling + 1;
        yDimTileIn = (yDimTileOut - 1) / latSampling +1 ;
        inputColumn = vectorShort(0, yDimTileIn - 1) ;
        inputFloatTile = createFloatGridOfSize(xDimTileIn, yDimTileIn, lonSampling, latSampling) ;

        /* Determine upper left tile coordinate from tile name */      
        sscanf(DTED2Header + 265, "%2ld", &lowerLeftY) ;
        sscanf(DTED2Header + 274, "%3ld", &lowerLeftX) ;

        if (!strncmp(DTED2Header + 273, "S", 1)) {
            lowerLeftY *= -1. ;
        }
        if (!strncmp(DTED2Header + 283, "W", 1)) {
            lowerLeftX *= -1. ;
        }
        
        /* Read tiles */
        seekVal = 80 + 648 + 2700 + 8 ;
        fseek(inputTileFile->f, seekVal, SEEK_SET) ;
        seekVal = 12 ;
        for (iX = 0; iX < xDimTileIn; iX++) {
            if (fread(inputColumn, sizeof(short), yDimTileIn, inputTileFile->f) != (size_t)yDimTileIn) {
                ase("Failed to read DEM tile\n") ;
            }
            for (iY = 0; iY < yDimTileIn; iY++) {
                if (!isArchBigEndian()) {
                    swapShort(inputColumn + iY) ;
                }
                if (inputColumn[iY] < 0) {
                    inputColumn[iY] = -(inputColumn[iY] ^ _SHORTSIGNBIT_) ;
                }
                inputFloatTile->floatVal[iX][iY] = (inputColumn[iY] == 32767)? floatNaN: (float)inputColumn[iY] ;
            }
            fseek(inputTileFile->f, seekVal, SEEK_CUR) ;
        }        
        freeRawFileDescriptor(inputTileFile) ;
        
        /* Convert input tile to destination tile */
        /* Save it, adding EGM height */
        xShift = lowerLeftX - aoi->P[0].x ;
        yShift = lowerLeftY - aoi->P[0].y ;
        seekVal = (yShift * (yDimTileOut - 1) * xDimOutput + xShift * (xDimTileOut - 1)) ;
        for (iY = 0; iY < yDimTileOut; iY++) {
            for (iX = 0; iX < xDimTileOut; iX++) {
                destinationTile[iY][iX] = weightedExtrapolationOfGridForImageCoordinate(inputFloatTile, iX, iY) ;                
                if (EGMHeight) {
                    floatVal = weightedExtrapolationOfGridForImageCoordinate(EGMHeight, xShift * (xDimTileOut - 1) + iX, yShift * (yDimTileOut - 1) + iY) ;
                    destinationTile[iY][iX] += floatVal ;
                }
            }
            
            if(fseek(outputFile->f, seekVal  * sizeof(float), SEEK_SET)) {
                ase("Failed to seek into output file") ;
            }
            if(xDimTileOut != (int)fwrite(destinationTile[iY], sizeof(float), xDimTileOut, outputFile->f)) {
                ase("Failed to write into output file") ;
            }

            seekVal += xDimOutput ;
        }
        fflush(outputFile->f) ;
        freeVectorShort(inputColumn, 0) ;
    }

    removeDirectoryAtPath(downloadDir) ;
    free(downloadDir) ;
    freeMatrixFloat(destinationTile, 0, 0) ;
    freeCSVStruct(DEMTileFileName) ;
    
    /* Create DEM parameter file */
    header = allocAKeyValuePair() ;
    setStringValForKeyIn(header, "COPERNICUS DEM characteristics", "") ;
    setStringValForKeyIn(header, "******************************", "") ;
    
    if (getenv("EXTERNAL_DEMS_DIR")) {
        free(outputFilePath) ;
        outputFilePath = initStringWith2Strings("${EXTERNAL_DEMS_DIR}/", outputFile->fileName) ;
    }
    setStringValForKeyIn(header, outputFilePath, "Georeferenced DEM file path") ;
    free(outputFilePath) ;
    setIntValForKeyIn(header, xDimOutput, "X (longitude) dimension [pixels]") ;
    setIntValForKeyIn(header, yDimOutput, "Y (latitude) dimension [pixels]") ;
    setDoubleValForKeyIn(header, aoi->P[0].x, "Lower left corner longitude [dd]") ;
    setDoubleValForKeyIn(header, aoi->P[0].y, "Lower left corner latitude [dd]") ;
    setDoubleValForKeyIn(header, longitudeSampling, "Longitude sampling [dd]") ;
    setDoubleValForKeyIn(header, latitudeSampling, "Latitude sampling [dd]") ;
    setStringValForKeyIn(header, "NaN", "Excluding value") ;
    if (EGMHeight) {
        setStringValForKeyIn(header, "Ellipsoidal - EGM2008 geoidal height added", "Height type") ;
        freeGridMap(EGMHeight) ;
    }

    outputFilePath = initStringWith2Strings(outputFile->accessPath, ".txt") ;
    writeParameterFileAtPath(header, outputFilePath) ;
    free(outputFilePath) ;
    freeKeyValueList(header) ;
    freeRawFileDescriptor(outputFile) ;
    freePolygon(aoi) ;
    
    freeRequest(aRequest) ;
    
    exit(0) ;
}
