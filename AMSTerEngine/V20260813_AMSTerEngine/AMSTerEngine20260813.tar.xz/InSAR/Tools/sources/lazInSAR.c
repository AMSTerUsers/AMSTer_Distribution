
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  _bb_initInSAR
//
//  Created by Dominique Derauw on 07/01/2020.
//  Copyright © 2020 SAREOS - Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "SARPlatformID.h"
#include "rawFileLib.h"
#include "S1DataReaderLib.h"
#include "TSXDataReaderLib.h"
#include "CSKDataReaderLib.h"
#include "RSAT2DataReaderLib.h"
#include "ALOSDataReaderLib.h"
#include "SAOCOMDataReaderLib.h"
#include "initInSARLib.h"
#include "amplitudeImageReductionLib.h"
#include "coregistrationLib.h"
#include "S1InSARLib.h"
#include "SBInSARProcess.h"
#include "interpolation.h"
#include "InSARGenLib.h"
#include "interferogramFilteringLib.h"
#include "cutAndZoomCSLImage.h"
#include "phaseUnwrappingLib.h"

#define _SKIP_COREGISTRATION_   0x00000001
#define _SKIP_INTERPOL_         0x00000002
#define _SKIP_INSAR_            0x00000004
#define _IONO_                  0x00000008
#define _SKIP_SPLITTING_        0x00000010
#define _SKIP_SBINSAR_          0x00000020
#define _SKIP_MCA_              0x00000040
#define _InSAR_PARAMS_          0x00000080
#define _SBInSAR_PARAMS_        0x00000100
#define _INSAR_ONLY_            0x00000200
#define _S1_FULL_               0x00000400
#define _INIT_INSAR_            0x00000800
#define _SKIP_GEOPROJ_          0x00001000
#define _SKIP_FILTER_           0x00002000
#define _SKIP_UNWRAP_           0x00004000
#define _COMPUTE_DEFO_          0x00008000
#define _SKIP_CROPPING_         0x00010000

int lazInSAR(CSVStruct *csv) ;
void lazInSARHelp(void) ;
keyValue *getLazInSARStartingParameters(CSVStruct *csv) ;
keyValue *lazInSARDataReader(keyValue *params) ;
keyValue *lazInSARInitialization(keyValue *params) ;
keyValue *slantRangeDEMCalc(keyValue *params) ;
keyValue *coregistrationPhase(keyValue *params) ;
keyValue *InSARProcessingPhase(keyValue *params) ;
keyValue *geoProjectionPhase(keyValue *params) ;


int main(int argc, const char * argv[])
{
    int i ;
    CSVStruct *csv = NULL ;
    time_t startTime, endTime ;

    
	time(&startTime) ;
    for (i = 0; i < argc; i++) {
        csv = addStringValInCSVStruct((char *)argv[i], csv) ;
    }
    
    lazInSAR(csv) ;
    freeCSVStruct(csv) ;
    
    time(&endTime) ;
    printf("\nlazInSAR process duration\n") ;
    printf("Start time = %s\n", ctime(&startTime)) ;
	duration(startTime, endTime) ;

    return(0) ;
}


int lazInSAR(CSVStruct *csv)
{
    int flag = 0 ;
    char *aPath ;
    CSVStruct *InSAR_CL = NULL ;
    keyValue *params ;
    time_t now ;
    struct tm *ptm ;
    
    if(csv->numberOfEntries == 1 || isArgumentPresentInCSV(csv, "-h")) {
        lazInSARHelp() ;
    }


    /* Get starting parameters */
    params = getLazInSARStartingParameters(csv) ;
    flag = getIntValForKeyIn(params, "Processing flag") ;

    /* Define parameter file name */
    aPath = initStringWith2Strings(getStringValForKeyIn(params, "Working directory"), "/params.txt") ;
    if (fileExistsAtPath(aPath)) {
        free(aPath) ;
        now = time(NULL) ;
        ptm = localtime(&now) ;
        strftime(aComment, _MAX_COMMENT_LENGTH_, "_%Y%m%d_%H%M%S.txt", ptm);
        aPath = initStringWith3Strings(getStringValForKeyIn(params, "Working directory"), "/params", aComment) ;
    } 
    writeParameterFileAtPath(params, aPath) ;
    
    /* Read data */
    lazInSARDataReader(params) ;
    writeParameterFileAtPath(params, aPath) ;

    /* InSAR initialization */
    lazInSARInitialization(params) ;
    writeParameterFileAtPath(params, aPath) ;

    /* Slant range DEM calculation */
    slantRangeDEMCalc(params) ;
    writeParameterFileAtPath(params, aPath) ;

    /* Coregistration phase */
    coregistrationPhase(params) ;
    writeParameterFileAtPath(params, aPath) ;

    /* Classical InSAR processing */
    InSARProcessingPhase(params) ;
    writeParameterFileAtPath(params, aPath) ;

    /* GeoProjection processing */
    geoProjectionPhase(params) ;
    writeParameterFileAtPath(params, aPath) ;

    /* Band split and MCA step */
    if (!(flag & _INSAR_ONLY_)) {
        InSAR_CL = addStringValInCSVStruct("SBInSAR", NULL) ;
        InSAR_CL = addStringValInCSVStruct(getStringValForKeyIn(params, "SBInSAR parameter file path"), InSAR_CL) ;
        InSAR_CL = addStringValInCSVStruct("chut!", InSAR_CL) ;
        if ((flag & _IONO_)) {
            InSAR_CL = addStringValInCSVStruct("-d", InSAR_CL) ;
            InSAR_CL = addStringValInCSVStruct("-split", InSAR_CL) ;
        }
        if ((flag & _SKIP_SPLITTING_)) {
            if (!(flag & _SKIP_SBINSAR_)) {
                InSAR_CL = addStringValInCSVStruct("-interf", InSAR_CL) ;
            }
            InSAR_CL = addStringValInCSVStruct("-mca", InSAR_CL) ;
        }
        
        SBInSAR(InSAR_CL) ;
    }

    freeKeyValueList(params) ;
    free(aPath) ;

    return 0;
}


void lazInSARHelp(void)
{
    printf("Usage: \n") ;
    printf("-1- lazInSAR masterImage slaveImage workingDir [DEMFilePath] [kmlPathFile] [options]\n") ;
    printf("-2- lazInSAR master&SlaveImagesDir workingDir  [DEMFilePath] [kmlPathFile] [options]\n") ;
    printf("-3- lazInSAR pathTo/InSARParameters.txt [options]\n") ;
    printf("-4- lazInSAR pathTo/SBInSARParameters.txt [options]\n\n") ;
    printf("\tFor CSK and K5, masterImage and slaveImage are full path to corresponding .h5 files\n") ;
    printf("\tFor TSX, TDX, RS2 and SAOCOM, masterImage and slaveImage are full path to directories \ncontaining the master and slave data.\n") ;
    printf("\tFor TDM, master&SlaveImagesDir is the full path to the TDM directory structure\n") ;
    printf("\tmaster and slave images can also be given directly in previously read .csl image format\n") ;
    printf("\n\tFor S1, either give path to uncompressed master and slave images, or give the path to\n\ta directory containing any number of uncompresses S1 images.\n") ;
    printf("\tIn the latter case, all images will be read and converted in .csl format.\n") ;
    printf("\tS1 read images can then be used in a second run, selecting directly master and slave\n\t images in .csl format.\n") ;
    printf("\n\nSome options are:  \n") ;
    printf("-topo : By default, lazInSAR is working in defo mode. So...\n") ;
    printf("-coh : Skip filtering and unwraping. Aims at getting geoProjected coherence for proofing.\n") ;
    printf("-skipUnwrapping: As its names states it\n") ;
    printf("-skipFilter: As its names states it\n") ;
    printf("-skipGeoProj: As its names states it\n") ;
    printf("-SBInSAR: Split Band InSAR processing is performed\n") ;
    printf("-initInSAR: Only InSAR initialization is performed. This allows modifying \n\tdefault parameters at will\n") ;
    printf("-iono: Performs a split band processing of both master and slave in low and high sub-abnds\n\tof one third of available bandwidth for further ionospheric decomposition\n") ;
    printf("\n") ;
    exit(-1) ;
}



keyValue *getLazInSARStartingParameters(CSVStruct *csv)
{
    char *masterPath, *slavePath, *workingDir, *pGeoProjPath, *aString ;
    char *paramsFileDirectory, *InSARWorkingDirectoryirectory, *workingDirectory, *filePath, *fileExtension ;
    char *externalDEMFilePath ;
    int sensorID = 0, flag = 0 ;
    int i ;
    polygon *aoi ;
    CSVStruct *fileList ;
    CSVStruct *flagsList = NULL ;
    keyValue *aKeyValueList ;
    keyValue *params ;
    InSARParametersStruct *pInSAR ;

    params = allocAKeyValuePair() ;
    if ((i = isArgumentPresentInCSV(csv, "P="))) {
        setStringValForKeyIn(params, csv->stringVal[i] + 2, "Preferred polarization scheme") ;
    }
    
    if (isDir(csv->stringVal[1])) {
        filePath = expandEnvironmentVariablesInPath(csv->stringVal[1]) ;
        masterPath = (setStringValForKeyIn(params, filePath, "Master file path"))->stringVal ;
        free(filePath) ;
        
        /* Verify if it is a TDM directory */
        if (isSubStringPresentInString(masterPath, "TDM1_SAR")) {
            sensorID = __TDM__ ;
            workingDir = expandEnvironmentVariablesInPath(csv->stringVal[2]) ;
            setStringValForKeyIn(params, workingDir, "Working directory") ;
            free(workingDir) ;
        }
        else {
            /* Else get slave and working directories */
            if (csv->numberOfEntries < 4) {
                printf("Working directory is missing\n") ;
                lazInSARHelp() ;
            }
            if (!isDir(csv->stringVal[3])) {
                printf("Third parameter must be a valid working directory\n") ;
                lazInSARHelp() ;
            }
            filePath = expandEnvironmentVariablesInPath(csv->stringVal[2]) ;
            slavePath = (setStringValForKeyIn(params, filePath, "Slave file path"))->stringVal ;
            free(filePath) ;
            workingDir = expandEnvironmentVariablesInPath(csv->stringVal[3]) ;
            setStringValForKeyIn(params, workingDir, "Working directory") ;
            free(workingDir) ;
            
            /* Verify if we deal with S1 images */
            if (isDirPresentInSubDir("_SLC__", masterPath) || isSubStringPresentInString(masterPath, "_SLC__")) {
                if (!isDirPresentInSubDir("_SLC__", slavePath) && !isSubStringPresentInString(slavePath, "_SLC__")) {
                    ase("Master and slave images must both be Sentinel1 images\n") ;
                }
                sensorID = __SENTINEL1__ ;
            }
            
            /* Verify if we deal with TDX images */
            if (isSubStringPresentInString(masterPath, "1_SAR__SSC")) {
                if (!isSubStringPresentInString(slavePath, "1_SAR__SSC")) {
                    ase("Master and slave images must both be TSX or PAZ images\n") ;
                }
                sensorID = __TSX__ ;
            }
            
            /* Verify if we deal with RSAT2 images */
            if (isSubStringPresentInString(masterPath, "RS2_") && isSubStringPresentInString(masterPath, "_SLC")) {
                if (!isSubStringPresentInString(slavePath, "RS2_") || !isSubStringPresentInString(slavePath, "_SLC")) {
                    ase("Master and slave images must both be RS2 images\n") ;
                }
                sensorID = __RSAT2__ ;
            }
            
            /* Verify if we deal with ALOS2 images */
            if ((fileList = recursiveSearchOfFileInDir("VOL-AL", masterPath))) {
                freeCSVStruct(fileList) ;
                if (!(fileList = recursiveSearchOfFileInDir("VOL-AL", slavePath))) {
                    ase("Master and slave images must both be ALOS images\n") ;
                }
                freeCSVStruct(fileList) ;
                sensorID = __ALOS2__ ;
            }
            
            /* Verify if we deal with SAOCOM images */
            if ((fileList = recursiveSearchOfFileInDir(".xemt", masterPath))) {
                freeCSVStruct(fileList) ;
                if (!(fileList = recursiveSearchOfFileInDir("xemt", slavePath))) {
                    ase("Master and slave images must both be SAOCOM images\n") ;
                }
                freeCSVStruct(fileList) ;
                sensorID = __SAOCOM1A__ ;
            }

            if ((fileList = recursiveSearchOfFilesWithExtensionInDir("h5", masterPath))) {
                if (fileList->numberOfEntries == 1) {
                    masterPath = (setStringValForKeyIn(params, fileList->stringVal[0], "Master file path"))->stringVal ;
                }
                freeCSVStruct(fileList) ;
                if ((fileList = recursiveSearchOfFilesWithExtensionInDir("h5", slavePath))) {
                    if (fileList->numberOfEntries == 1) {
                        slavePath = (setStringValForKeyIn(params, fileList->stringVal[0], "Slave file path"))->stringVal ;
                    }
                    freeCSVStruct(fileList) ;
                }
                sensorID = __CSK__ ;
            }

            /* Verify if we deal with already read CSL images */
            if (isCSLImageAtPath(masterPath) && isCSLImageAtPath(slavePath)) {
                masterPath = (setStringValForKeyIn(params, csv->stringVal[1], "Master .csl file path"))->stringVal ;
                slavePath = (setStringValForKeyIn(params, csv->stringVal[2], "Slave .csl file path"))->stringVal ;
                
                sensorID = -1 ;
            }
        }
    }
    else {
        /* Verify if we deal with S1 zipped files or CSK images */
        /* Get slave and working directories */
        if (fileExistsAtPath(csv->stringVal[1])) {
            fileExtension = getPointerToLastFileExtensionInPath(csv->stringVal[1]) ;   
            /* Verify if we deal with S1 images */
            if (isSubStringPresentInString(csv->stringVal[1], "_SLC__")) {
                if (!isSubStringPresentInString(csv->stringVal[2], "_SLC__")) {
                    ase("Master and slave images must both be Sentinel1 images\n") ;
                }
                if (fileExtension && !strncmp(fileExtension, "zip", 2)) {
                    masterPath = (setStringValForKeyIn(params, csv->stringVal[1], "Master file path"))->stringVal ;
                    slavePath = (setStringValForKeyIn(params, csv->stringVal[2], "Slave file path"))->stringVal ;
                    workingDir = (setStringValForKeyIn(params, csv->stringVal[3], "Working directory"))->stringVal ;
                    sensorID = __SENTINEL1__ ;
                }
                else {
                    sensorID = -1 ;
                }
            }
            else if (fileExtension && !strncmp(fileExtension, "h5", 2)) {
                if (csv->numberOfEntries < 3) {
                    printf("CSK slave image is missing\n") ;
                    lazInSARHelp() ;
                }
                if (csv->numberOfEntries < 4) {
                    printf("Working directory is missing\n") ;
                    lazInSARHelp() ;
                }
                
                masterPath = (setStringValForKeyIn(params, csv->stringVal[1], "Master file path"))->stringVal ;
                slavePath = (setStringValForKeyIn(params, csv->stringVal[2], "Slave file path"))->stringVal ;
                if (strncmp(getPointerToLastFileExtensionInPath(slavePath), "h5", 2)) {
                    ase("Both master and slave images must be CSK (or K5) .h5 files\n") ;
                }
                
                workingDir = (setStringValForKeyIn(params, csv->stringVal[3], "Working directory"))->stringVal ;
                sensorID = __CSK__ ;
            }
            else {
                /* Test if a parameter file was given as first parameter */
                if ((aKeyValueList = readParameterFileAtPath(csv->stringVal[1]))) {
                    if (isCommentPresentIn(aKeyValueList, "InSAR parameters file")) {
                        flag |= _InSAR_PARAMS_ ;
                        flag |= _SBInSAR_PARAMS_ ;
                        setStringValForKeyIn(params, csv->stringVal[1], "InSAR parameter file path") ;
                    }
                    else {
                        if (isCommentPresentIn(aKeyValueList, "SBInSAR process parameter file")) {
                            flag |= _SBInSAR_PARAMS_ ;
                            setStringValForKeyIn(params, csv->stringVal[1], "SBInSAR parameter file path") ;
                        }
                        else {
                            printf("Text file given as first parameter is not a valid InSAR nor SBINSAR parameter file\n") ;
                            lazInSARHelp() ;
                        }
                    }
                    if (flag & _SBInSAR_PARAMS_) {
                        paramsFileDirectory = getDirectoryPathFromPath(csv->stringVal[1]) ;
                        InSARWorkingDirectoryirectory = getDirectoryPathFromPath(paramsFileDirectory) ;
                        workingDirectory = getDirectoryPathFromPath(InSARWorkingDirectoryirectory) ;
                        setStringValForKeyIn(params, InSARWorkingDirectoryirectory, "InSAR working directory") ;
                        setStringValForKeyIn(params, workingDirectory, "Working directory") ;

                        if (flag & _InSAR_PARAMS_) {
                            filePath = initStringWith2Strings(paramsFileDirectory, "SBInSARParameters.txt") ;
                            setStringValForKeyIn(params, filePath, "SBInSAR parameter file path") ;
                        }
                        else {
                            filePath = initStringWith2Strings(paramsFileDirectory, "InSARParameters.txt") ;
                            setStringValForKeyIn(params, filePath, "InSAR parameter file path") ;
                        }

                        pInSAR = readInSARParametersFileAtPath(getStringValForKeyIn(params, "InSAR parameter file path")) ;
                        if (pInSAR->aoiKml) {
                            setStringValForKeyIn(params, pInSAR->aoiKml, "kml file path") ;
                        }
                        if (pInSAR->externalReferenceDEM) {
                            if (fileExistsAtPath(pInSAR->externalReferenceDEM)) {
                                setStringValForKeyIn(params, pInSAR->externalReferenceDEM, "External DEM file path") ;
                            }
                            
                        }
                        pGeoProjPath = initStringWith2Strings(InSARWorkingDirectoryirectory, "/TextFiles/geoProjectionParameters.txt") ;
                        setStringValForKeyIn(params, pGeoProjPath, "Geoprojection parameter file path") ;
                        setStringValForKeyIn(params, pInSAR->masterImage->imageDirectoryPath, "Master .csl file path") ;
                        setStringValForKeyIn(params, pInSAR->slaveImage->imageDirectoryPath, "Slave .csl file path") ;
                        free(pGeoProjPath) ;
                        sensorID = pInSAR->masterInfo->sensorID ;

                        free(paramsFileDirectory) ;
                        free(InSARWorkingDirectoryirectory) ;
                        free(workingDirectory) ;
                        free(filePath) ;
                        freeInSARParametersStruct(pInSAR) ;
                    }
                    freeKeyValueList(aKeyValueList) ;
                }        
            }
        }
    }
    if (!sensorID) {
        printf("SAR images(s) not recognized\n") ;
        lazInSARHelp() ;
    }
    
    setIntValForKeyIn(params, sensorID, "Sensor ID");
    
    /* Read area of interest file path if present in command line parameters */
    for (i = 2; i < csv->numberOfEntries; i++) {
        if ((aoi = getRectangularAoIFromKMLFile(csv->stringVal[i])) != NULL) {
            setStringValForKeyIn(params, csv->stringVal[i], "kml file path") ;
            freePolygon(aoi) ;
        }

    /* Read DEM file path if present in command line parameters */
        if ((externalDEMFilePath = getGeoreferencedDataFilePath(csv->stringVal[i]))) {
            setStringValForKeyIn(params, externalDEMFilePath, "External DEM file path") ;
            free(externalDEMFilePath) ;
        }
    }

    /* Flags management */
    flag |= _INSAR_ONLY_ ;
    flag |= _S1_FULL_ ;
    flag |= _COMPUTE_DEFO_ ;

    if (isArgumentPresentInCSV(csv, "-initInSAR")) {
        flag |= _INIT_INSAR_ ;
        flagsList = addStringValInCSVStruct("-initInSAR", flagsList) ;
    }

    if (isArgumentPresentInCSV(csv, "-coh")) {
        flag |= _SKIP_FILTER_ ;
        flag |= _SKIP_UNWRAP_ ;
        flagsList = addStringValInCSVStruct("-coh", flagsList) ;
    }

    if (isArgumentPresentInCSV(csv, "-skipUnwrapping")) {
        flag |= _SKIP_UNWRAP_ ;
        flagsList = addStringValInCSVStruct("-skipUnwrapping", flagsList) ;
    }

    if (isArgumentPresentInCSV(csv, "-skipFilter")) {
        flag |= _SKIP_FILTER_ ;
        flagsList = addStringValInCSVStruct("-skipFilter", flagsList) ;
    }

    if (isArgumentPresentInCSV(csv, "-skipGeoProj")) {
        flag |= _SKIP_GEOPROJ_ ;
        flagsList = addStringValInCSVStruct("-skipGeoProj", flagsList) ;
    }

    if (isArgumentPresentInCSV(csv, "-iono")) {
        flag |= _IONO_ ;
        flag &= ~_INSAR_ONLY_ ;
        flag |= _SKIP_COREGISTRATION_ ;
        flag |= _SKIP_INTERPOL_ ;
        flag |= _SKIP_INSAR_ ;
        flag |= _SKIP_GEOPROJ_ ;
        flagsList = addStringValInCSVStruct("-iono", flagsList) ;
    }
    if (isArgumentPresentInCSV(csv, "-SBInSAR")) {
        flag &= ~_INSAR_ONLY_ ;
        flag &= ~_S1_FULL_ ;
    }
    
    if (isArgumentPresentInCSV(csv, "-topo")) {
        flag &= ~_COMPUTE_DEFO_ ;
        flagsList = addStringValInCSVStruct("-topo", flagsList) ;
    }
    
    if (flag & _INIT_INSAR_) {
        flag |= _INSAR_ONLY_ ;
        flag |= _SKIP_INSAR_ ;
        flag |= _SKIP_GEOPROJ_ ;
    }
    if (flag & _SKIP_INSAR_) {
        flag |= _SKIP_COREGISTRATION_ ;
        flag |= _SKIP_INTERPOL_ ;
    }
    if (flag & _SKIP_COREGISTRATION_) {
        flag |= _SKIP_INTERPOL_ ;
    }

    setIntValForKeyIn(params, flag, "Processing flag") ;
    if (flagsList) {
        aString = getStringFromCSV(flagsList) ;
        setStringValForKeyIn(params, aString, "User flags") ;
        freeCSVStruct(flagsList) ;
        free(aString) ;
    }
    
    return (params) ;
}


keyValue *lazInSARDataReader(keyValue *params)
{
    char *kmlFilePath, *externalDEMFilePath ;
    char *pol, *anOption ;
    char *masterPath = NULL, *slavePath = NULL, *workingDir = NULL, *cutAndZoomParameterFilePath, *imageDir, *imagePath ;
    int sensorID, flag ;
    CSVStruct *masterDataReader, *slaveDataReader = NULL ;
    CSVStruct *masterCSLImagePath = NULL, *slaveCSLImagePath = NULL ;
    CSVStruct *csv_CL ;
    keyValue *cutAndZoomParameters ; 
    struct infoImage *info ;

    sensorID = getIntValForKeyIn(params, "Sensor ID") ;
    flag = getIntValForKeyIn(params, "Processing flag") ;
    externalDEMFilePath = getStringValForKeyIn(params, "External DEM file path") ;
    kmlFilePath = expandEnvironmentVariablesInPath(getStringValForKeyIn(params, "kml file path")) ;
    
    masterDataReader = addStringValInCSVStruct("reader", NULL) ;
    if (sensorID) {
        masterPath = expandEnvironmentVariablesInPath(getStringValForKeyIn(params, "Master file path")) ;
        workingDir = expandEnvironmentVariablesInPath(getStringValForKeyIn(params, "Working")) ;
        masterDataReader = addStringValInCSVStruct(masterPath, masterDataReader) ;
        masterDataReader = addStringValInCSVStruct(workingDir, masterDataReader) ;
        if (sensorID != __TDM__) {
            slavePath = expandEnvironmentVariablesInPath(getStringValForKeyIn(params, "Slave file path")) ;
            slaveDataReader = addStringValInCSVStruct("reader", NULL) ;
            slaveDataReader = addStringValInCSVStruct(slavePath, slaveDataReader) ;
            slaveDataReader = addStringValInCSVStruct(workingDir, slaveDataReader) ;
        }
        masterDataReader = addStringValInCSVStruct("keepExisting", masterDataReader) ;
        slaveDataReader = addStringValInCSVStruct("keepExisting", slaveDataReader) ;
    }
    else {
        if (!(flag & _SBInSAR_PARAMS_)) {
            printf("Sensor not recognized\n") ;
            lazInSARHelp() ;
        }
    }
    
    /* Prepare for InSAR initialization */
    if (!(flag & _SBInSAR_PARAMS_)) {
        switch (sensorID) {
            case __SENTINEL1__ :
                if (kmlFilePath) {
                    addStringValInCSVStruct(kmlFilePath, masterDataReader) ;
                    addStringValInCSVStruct(kmlFilePath, slaveDataReader) ;
                }
                if ((pol = getStringValForKeyIn(params, "Preferred polarization scheme"))) {
                    anOption = initStringWith2Strings("P=", pol) ;
                    masterDataReader = addStringValInCSVStruct(anOption, masterDataReader) ;
                    slaveDataReader = addStringValInCSVStruct(anOption, slaveDataReader) ;
                    free(anOption) ;
                }
                addStringValInCSVStruct("-ok", masterDataReader) ;
                addStringValInCSVStruct("-ok", slaveDataReader) ;
                masterCSLImagePath = S1DataReader(masterDataReader) ;
                slaveCSLImagePath = S1DataReader(slaveDataReader) ;
                if (!masterCSLImagePath || !slaveCSLImagePath) {
                    ase("\n") ;
                }
                if (masterCSLImagePath->numberOfEntries > 1 || slaveCSLImagePath->numberOfEntries > 1) {
                    printf("You chosed to read more than two Sentinel images.\n") ;
                    printf("Please, re-run lazInSAR giving directly master and slave Sentinel1 images in .csl format.\n") ;
                    lazInSARHelp() ;
                }
                break;
                
            case __TDM__ :
                masterCSLImagePath = TSXDataReader(masterDataReader) ;
                if (isSubStringPresentInString(masterCSLImagePath->stringVal[0], ".slave.csl")) {
                    slaveCSLImagePath = addStringValInCSVStruct(masterCSLImagePath->stringVal[0], NULL) ;
                    removeStringValAtIndexInCSVStruct(0, masterCSLImagePath) ;
                }
                else {
                    slaveCSLImagePath = addStringValInCSVStruct(masterCSLImagePath->stringVal[1], NULL) ;
                    removeStringValAtIndexInCSVStruct(1, masterCSLImagePath) ;
                }
                break;
                
            case __TSX__ :
                masterCSLImagePath = TSXDataReader(masterDataReader) ;
                slaveCSLImagePath = TSXDataReader(slaveDataReader) ;
                break;
                
            case __CSK__ :
                masterCSLImagePath = CSKDataReader(masterDataReader) ;
                slaveCSLImagePath = CSKDataReader(slaveDataReader) ;
                break;
                
            case __RSAT2__ :
                masterCSLImagePath = RSAT2DataReader(masterDataReader) ;
                slaveCSLImagePath = RSAT2DataReader(slaveDataReader) ;
                break;
                
            case __ALOS2__ :
                masterCSLImagePath = ALOSDataReader(masterDataReader) ;
                slaveCSLImagePath = ALOSDataReader(slaveDataReader) ;
                break;
                
            case __SAOCOM1A__ :
                masterCSLImagePath = SAOCOMDataReader(masterDataReader) ;
                slaveCSLImagePath = SAOCOMDataReader(slaveDataReader) ;
                break;
                
            case -1 :
                masterCSLImagePath = addStringValInCSVStruct(masterPath, NULL) ;
                slaveCSLImagePath = addStringValInCSVStruct(slavePath, NULL) ;
                if ((info = readInfoImageInCSLImageAtPath(masterPath)) == NULL) {
                    ase("Failed to read info image in master .csl image") ;
                }
                setIntValForKeyIn(params, info->sensorID, "Sensor ID") ;   
                if (info->sensorID == __SENTINEL1__) {
                    flag |= _SKIP_CROPPING_ ;
                }
                
                freeInfoImage(info) ; 
            break ;
                
            default:
                if (!(flag & _SBInSAR_PARAMS_)) {
                    printf("Sensor not recognized\n") ;
                    lazInSARHelp() ;
                }
            break;

        }
        free(masterPath) ;
        free(slavePath) ;
                
        /* Crop read data to area of interest */
        if ((kmlFilePath) && (sensorID != __SENTINEL1__) && !(flag & _SKIP_CROPPING_)) {
            cutAndZoomParameterFilePath = initStringWith2Strings(workingDir, "/cutAndZoom.txt") ;
            csv_CL = addStringValInCSVStruct("cutAndZoom" , NULL) ;
            csv_CL = addStringValInCSVStruct(cutAndZoomParameterFilePath , csv_CL) ;
            csv_CL = addStringValInCSVStruct("-create" , csv_CL) ;
            cutAndZoomMain(csv_CL) ;

            /* Crop master image */
            removeStringValInCSVStruct("-create", csv_CL) ;
            masterPath = initStringWith2Strings(workingDir, "/temp.csl") ;
            imageDir = getDirectoryPathFromPath(masterCSLImagePath->stringVal[0]) ;
            cutAndZoomParameters = readParameterFileAtPath(cutAndZoomParameterFilePath) ;
            setStringValForKeyIn(cutAndZoomParameters, masterCSLImagePath->stringVal[0], "Input file path in CSL format") ;
            setStringValForKeyIn(cutAndZoomParameters, masterPath, "Output") ;
            if (externalDEMFilePath) {
                setStringValForKeyIn(cutAndZoomParameters, externalDEMFilePath, "Georeferenced") ;
            }
            
            setStringValForKeyIn(cutAndZoomParameters, kmlFilePath, "kml") ;
            writeParameterFileAtPath(cutAndZoomParameters, cutAndZoomParameterFilePath) ;
            cutAndZoomMain(csv_CL) ;
            if (!strncmp(imageDir, workingDir, strlen(workingDir))) {                
                removeDirectoryAtPath(masterCSLImagePath->stringVal[0]) ;
            }
            imagePath = initStringWith3Strings(workingDir, "/", getPointerToFileNameInPath(masterCSLImagePath->stringVal[0])) ;
            freeCSVStruct(masterCSLImagePath) ;
            masterCSLImagePath = addStringValInCSVStruct(imagePath, NULL) ;
            if (rename(masterPath, imagePath)) {
                ase("Failed to rename cropped master image.\n") ;
            }
            
            free(masterPath) ;
            free(imageDir) ;
            free(imagePath) ;

            /* Crop slave Image */
            slavePath = initStringWith2Strings(workingDir, "/temp.csl") ;
            imageDir = getDirectoryPathFromPath(slaveCSLImagePath->stringVal[0]) ;
            setStringValForKeyIn(cutAndZoomParameters, slaveCSLImagePath->stringVal[0], "Input file path in CSL format") ;
            setStringValForKeyIn(cutAndZoomParameters, slavePath, "Output") ;
            writeParameterFileAtPath(cutAndZoomParameters, cutAndZoomParameterFilePath) ;
            cutAndZoomMain(csv_CL) ;
            if (!strncmp(imageDir, workingDir, strlen(workingDir))) {                
                removeDirectoryAtPath(slaveCSLImagePath->stringVal[0]) ;
            }
            imagePath = initStringWith3Strings(workingDir, "/", getPointerToFileNameInPath(slaveCSLImagePath->stringVal[0])) ;
            freeCSVStruct(slaveCSLImagePath) ;
            slaveCSLImagePath = addStringValInCSVStruct(imagePath, NULL) ;
            if (rename(slavePath, imagePath)) {
                ase("Failed to rename cropped slave image.\n") ;
            }

            free(slavePath) ;
            free(imageDir) ;
            free(imagePath) ;

        }
        if (!masterCSLImagePath || !slaveCSLImagePath) {
            printf("One or both images were not read. Most probably, their .csl version already exist in destination directory.\n") ;
            printf("If it is effectively the case, either trash them or bether, use them as master and slave image to relauch lazInSAR\n\n") ;
            lazInSARHelp() ;
        }
        
        setStringValForKeyIn(params, masterCSLImagePath->stringVal[0], "Master .csl file path") ;
        setStringValForKeyIn(params, slaveCSLImagePath->stringVal[0], "Slave .csl file path") ;
        
        freeCSVStruct(masterDataReader) ;
        freeCSVStruct(slaveDataReader) ;
        masterDataReader = slaveDataReader = NULL ;
    }

    freeCSVStruct(masterCSLImagePath) ;
    freeCSVStruct(slaveCSLImagePath) ;
    free(kmlFilePath) ;
    free(workingDir) ;

    return (params) ;
}



keyValue *lazInSARInitialization(keyValue *params)
{
    char *InSARPath, *pInSARPath,*pSBInSARPath, *pGeoProjPath ;
    char *kmlFilePath, *pol, *aPath ;
    int flag, sensorID ;
    CSVStruct *InSAR_CL ;
    InSARParametersStruct *pInSAR ;
    
    flag = getIntValForKeyIn(params, "Processing flag") ;
    sensorID = getIntValForKeyIn(params, "Sensor ID") ;
    if (!(flag & _SBInSAR_PARAMS_)) {
        /* Init InSAR Command Line */
        InSAR_CL = addStringValInCSVStruct("initInSAR", NULL) ;
        InSAR_CL = addStringValInCSVStruct(getStringValForKeyIn(params, "Master .csl"), InSAR_CL) ;
        InSAR_CL = addStringValInCSVStruct(getStringValForKeyIn(params, "Slave .csl"), InSAR_CL) ;
        InSAR_CL = addStringValInCSVStruct(getStringValForKeyIn(params, "Working directory"), InSAR_CL) ;
        
        if ((pol = getStringValForKeyIn(params, "preferred polarization scheme"))) {
            InSAR_CL = addStringValInCSVStruct(pol, InSAR_CL) ;
        }
        
        if ((kmlFilePath = getStringValForKeyIn(params, "kml file path"))) {
            InSAR_CL = addStringValInCSVStruct(kmlFilePath, InSAR_CL) ;
        }
        if ((aPath = getStringValForKeyIn(params, "External DEM file path"))) {
            InSAR_CL = addStringValInCSVStruct(aPath, InSAR_CL) ;
        }

        if (flag & _IONO_) {
            InSAR_CL = addStringValInCSVStruct("-iono", InSAR_CL) ;
        }

        if (sensorID == __TDM__) {
            InSAR_CL = addStringValInCSVStruct("-b", InSAR_CL) ;
            flag |= _SKIP_COREGISTRATION_ ;
            flag |= _SKIP_INTERPOL_ ;
        }
        
        setIntValForKeyIn(params, flag, "Processing flag") ;
        
        /* Initialize InSAR only if not previously done at destination location */
        InSAR_CL = addStringValInCSVStruct("keepExisting", InSAR_CL) ;
        pInSAR = initInSAR(InSAR_CL) ;
        InSARPath = pInSAR->whereAmI ;

        pInSARPath = initStringWith2Strings(InSARPath, "/TextFiles/InSARParameters.txt") ;
        pGeoProjPath = initStringWith2Strings(InSARPath, "/TextFiles/geoProjectionParameters.txt") ;
        pSBInSARPath = initStringWith2Strings(InSARPath, "/TextFiles/SBInSARParameters.txt") ;
        
        setStringValForKeyIn(params, InSARPath, "InSAR working directory") ;
        setStringValForKeyIn(params, pInSARPath, "InSAR parameter file path") ;
        setStringValForKeyIn(params, pGeoProjPath, "Geoprojection parameter file path") ;
        setStringValForKeyIn(params, pSBInSARPath, "SBInSAR parameter file path") ;

        if (!(flag & _COMPUTE_DEFO_)) {
            updateParameterFileAtPath(pGeoProjPath, "Geoproject interferogram", "YES") ;
            updateParameterFileAtPath(pGeoProjPath, "Geoproject filtered interferogram", "YES") ;
        }
           
        freeCSVStruct(InSAR_CL) ;
        free(pInSARPath) ;
        free(pGeoProjPath) ;
        free(pSBInSARPath) ;
    }
    else {
        pInSAR = readInSARParametersFileAtPath(getStringValForKeyIn(params, "InSAR parameter file path")) ;
        aPath = initStringWith3Strings(pInSAR->interpolatedSlave->dataDirectoryPath, "/SLCData.", pInSAR->slavePolarizationChannel) ;
        if (fileExistsAtPath(aPath)) {
            flag |= _SKIP_COREGISTRATION_ ;
            flag |= _SKIP_INTERPOL_ ;
            setIntValForKeyIn(params, flag, "Processing flag") ;
        }
        else {
            if (sensorID == __SENTINEL1__ && isDir(pInSAR->interpolatedSlave->dataDirectoryPath)) {
                removeDirectoryAtPath(pInSAR->interpolatedSlave->dataDirectoryPath) ;
            }
        }
        
        free(aPath) ;
    }
    freeInSARParametersStruct(pInSAR) ;
    
    return (params) ;
}


keyValue *slantRangeDEMCalc(keyValue *params)
{
    char *srdParamFile = NULL ;
    keyValue *srdParams ;
    InSARParametersStruct *pInSAR ;
    CSVStruct *InSAR_CL ;

    pInSAR = readInSARParametersFileAtPath(getStringValForKeyIn(params, "InSAR parameter file path")) ;
    if (isKeyValPresent(params, "External DEM file path") && !isFilePresentInCSLImage(pInSAR->masterImage, "externalSlantRangeDEM")) {
        srdParamFile = initStringWith2Strings(pInSAR->masterImage->infoDirectoryPath, "/srd.txt") ;
        
        printf("Creating slandRangeDem interface text file at path :\n%s\n\n", srdParamFile) ;
        createSRDParameterFileAtPath(srdParamFile) ;

        srdParams = readParameterFileAtPath(srdParamFile) ;
        setStringValForKeyIn(srdParams, pInSAR->masterImage->imageDirectoryPath, "Reference slant range image") ;
        setStringValForKeyIn(srdParams, getStringValForKeyIn(params, "External DEM file path"), "Georeferenced DEM file path") ;
        setIntValForKeyIn(srdParams, pInSAR->red.Fra, "Range reduction factor") ;
        setIntValForKeyIn(srdParams, pInSAR->red.Faz, "Azimuth reduction factor") ;
        writeParameterFileAtPath(srdParams, srdParamFile) ;
        InSAR_CL = addStringValInCSVStruct("slantRangeDEM", NULL) ;
        InSAR_CL = addStringValInCSVStruct(srdParamFile, InSAR_CL) ;
        InSAR_CL = addStringValInCSVStruct("chut!", InSAR_CL) ;
        slantRangeDEM(InSAR_CL) ;

        unlink(srdParamFile) ;
        free(srdParamFile) ;
        srdParamFile = initStringWith2Strings(pInSAR->masterImage->dataDirectoryPath, "/externalSlantRangeDEM") ;
        setStringValForKeyIn(params, srdParamFile, "Referenced slant range DEM") ;
        free(srdParamFile) ;

        freeKeyValueList(srdParams) ;
        freeCSVStruct(InSAR_CL) ;
    }
    else {
        if (isFilePresentInCSLImage(pInSAR->masterImage, "externalSlantRangeDEM")) {
            printf("\n\t---> External DEM already present in master image\n") ;
        }
        else {
            printf("\n\t---> No external DEM considered.\n\n") ;
        }
    }
    freeInSARParametersStruct(pInSAR) ;
    
    return (params) ;
}



keyValue *coregistrationPhase(keyValue *params)
{
    int sensorID, flag, NCorMax ;
    double criterion0, criterion ;
    CSVStruct *InSAR_CL ;
    coregistrationResults *corRes, *corRes0 ;
    InSARParametersStruct *pInSAR ;
    
    sensorID = getIntValForKeyIn(params, "Sensor ID") ;
    flag = getIntValForKeyIn(params, "Processing flag") ;
    InSAR_CL = addStringValInCSVStruct("coregistration", NULL) ;
    InSAR_CL = addStringValInCSVStruct(getStringValForKeyIn(params, "InSAR parameter file path"), InSAR_CL) ;
//    InSAR_CL = addStringValInCSVStruct("-f", InSAR_CL) ;
    InSAR_CL = addStringValInCSVStruct("chut!", InSAR_CL) ;

    if (!(flag & _SKIP_COREGISTRATION_)) {
        if (sensorID != __SENTINEL1__) {
            printf("\nAmplitude image reduction\n") ;
            amplitudeImageReduction(InSAR_CL) ;

            printf("\nCoarse coregistration\n") ;
            pInSAR = readInSARParametersFileAtPath(InSAR_CL->stringVal[1]) ;
            corRes0 = coarseCoregistration(InSAR_CL) ;
            criterion0 = corRes0->sigmaXY * corRes0->numberOfCandidatePoints / corRes0->numberOfRegisteredPoints ;
            if (corRes0->sigmaXY > 5 || corRes0->numberOfRegisteredPoints < 4) {
                printf("\t---> Coarse coregistration apparently quite bad.\nWill perform a second attempt authorizing larger search area for correlation local maximum\n") ;
                pInSAR->corg.errra += 2 ;
                pInSAR->corg.erraz += 2 ;
                saveInSARParametersFileAtPath(pInSAR, InSAR_CL->stringVal[1]) ;
                freeCoregistrationResults(corRes0) ;
                corRes0 = coarseCoregistration(InSAR_CL) ;
                if (corRes0->sigmaXY > 5 || corRes0->numberOfRegisteredPoints < 4) {
                    printf("\t---> Coarse coregistration apparently still quite bad.\nWill perform a second attempt enlarging correlation window\n") ;
                    pInSAR->corg.F_lena *= (corRes0->sigmaY > 5 || corRes0->numberOfRegisteredPoints < 4)? 2 : 1 ;
                    pInSAR->corg.F_lenr *= (corRes0->sigmaX > 5 || corRes0->numberOfRegisteredPoints < 4)? 2 : 1 ;
                    pInSAR->corg.Depaz /=2 ;
                    pInSAR->corg.Depra /=2 ;
                    saveInSARParametersFileAtPath(pInSAR, InSAR_CL->stringVal[1]) ;
                    freeInSARParametersStruct(pInSAR) ;
                    freeCoregistrationResults(corRes0) ;
                    corRes0 = coarseCoregistration(InSAR_CL) ;
                    if (corRes0->sigmaXY > 5) {
                        ase("\t-/->Failed to coregister images. They should perhaps be coregistered manually. I stop here, sorry.") ;
                    }
                }
            }
            NCorMax = 3 ;
            criterion0 = corRes0->sigmaXY * corRes0->numberOfCandidatePoints / corRes0->numberOfRegisteredPoints ;
            InSAR_CL = removeStringValInCSVStruct("-f", InSAR_CL) ;
            corRes = coarseCoregistration(InSAR_CL) ;
            criterion = corRes->sigmaXY * corRes0->numberOfCandidatePoints /corRes->numberOfRegisteredPoints ;
            while (NCorMax && criterion < .9 * criterion0) {
                NCorMax-- ;
                freeCoregistrationResults(corRes0) ;
                corRes0 = corRes ;
                criterion0 = criterion ;
                printf("\t---> Trying to improve coarse coregistration\n") ;
                corRes = coarseCoregistration(InSAR_CL) ;
                criterion = corRes->sigmaXY * corRes->numberOfCandidatePoints / corRes->numberOfRegisteredPoints ;
            }
            
            freeCoregistrationResults(corRes0) ;
            corRes0 = corRes ;
            criterion0 = criterion ;
            
            printf("\nFine coregistration\n") ;
            corRes = fineCoregistration(InSAR_CL) ;
            if (corRes->sigmaXY > 1) {
                printf("\t---> Fine coregistration apparently quite bad.\nWill perform a second attempt enlarging coherence window\n") ;
                pInSAR = readInSARParametersFileAtPath(InSAR_CL->stringVal[1]) ;
                pInSAR->corf.F_lenr += pInSAR->red.Fra ;
                pInSAR->corf.F_lena += pInSAR->red.Faz ;
                pInSAR->corf.Depaz /= 2 ;
                pInSAR->corf.Depra /= 2 ;
                pInSAR->corf.seuilcoh -= .05 ;
                memcpy(pInSAR->slaveAffineTransform[0], corRes0->T[0], 6 * sizeof(double)) ;
                saveInSARParametersFileAtPath(pInSAR, InSAR_CL->stringVal[1]) ;
                freeInSARParametersStruct(pInSAR) ;
                freeCoregistrationResults(corRes) ;
                corRes = fineCoregistration(InSAR_CL) ;
                if (corRes->sigmaXY > 2 || corRes->numberOfRegisteredPoints < 10) {
                    ase("\t-/->Failed to coregister images. Images apparently poorly coherent.\n Try perhaps to coregistered them manually. I stop here, sorry.") ;
                }
            }
            criterion = corRes->sigmaXY * corRes->numberOfCandidatePoints / corRes->numberOfRegisteredPoints ;
            NCorMax = 3 ;
            if (corRes->sigmaXY > 0.4) {
                do {
                    printf("\t---> Trying to improve fine coregistration\n") ;
                    NCorMax-- ;
                    freeCoregistrationResults(corRes0) ;
                    corRes0 = corRes ;
                    criterion0 = criterion ;
                    corRes = fineCoregistration(InSAR_CL) ;                
                    criterion = corRes->sigmaXY * corRes->numberOfCandidatePoints / corRes->numberOfRegisteredPoints ;
                } while (NCorMax && criterion < .9 * criterion0) ;
            }
            pInSAR = readInSARParametersFileAtPath(InSAR_CL->stringVal[1]) ;
            if (corRes->sigmaXY > corRes0->sigmaXY) {
                memcpy(pInSAR->slaveAffineTransform[0], corRes0->T[0], 6 * sizeof(double)) ;
                saveInSARParametersFileAtPath(pInSAR, InSAR_CL->stringVal[1]) ;
            }
            computeBaseLineFromAffineTransform(pInSAR) ;

            printf("\nCoregistration results:\n") ;
            printf("*************************\n") ;
            printf("Found affine transform:\n") ;
            printf("x2 = Ax x1 + Bx y1 + Cx\n Ax = %-21.15f\tBx = %-21.15f\tCx = %-21.15f\n", pInSAR->slaveAffineTransform[0][0], pInSAR->slaveAffineTransform[0][1], pInSAR->slaveAffineTransform[0][2]) ;
            printf("\ny2 = Ay x1 + By y1 + Cy\n Ay = %-21.15f\tBy = %-21.15f\tCy = %-21.15f\n", pInSAR->slaveAffineTransform[1][0], pInSAR->slaveAffineTransform[1][1], pInSAR->slaveAffineTransform[1][2]) ;
            printf("\nsigmaRange = %-f\tsigmaAzimuth = %-f\tsigmaRangeAzimuth = %-f\n", corRes->sigmaX,corRes->sigmaY, corRes->sigmaXY) ;

            freeInSARParametersStruct(pInSAR) ;            
            freeCoregistrationResults(corRes0) ;
            freeCoregistrationResults(corRes) ;

            printf("\n\n") ;
        }
    }
    if (!(flag & _SKIP_INTERPOL_)) {
        if (sensorID != __SENTINEL1__) {
            interpolation(InSAR_CL) ;
        }
        else {
            if (!isKeyValPresent(params, "Preferred")) {
                InSAR_CL = addStringValInCSVStruct("-A", InSAR_CL) ;
            }
            
            if (!(flag & _S1_FULL_)) {
                InSAR_CL = addStringValInCSVStruct("-w", InSAR_CL) ;
            }
            S1Coregistration(InSAR_CL) ;
        }
    }
    freeCSVStruct(InSAR_CL) ;

    return (params) ;
}


keyValue *InSARProcessingPhase(keyValue *params)
{
    char *pol, *anOption ;
    int sensorID, flag ;
    CSVStruct *InSAR_CL ;

    sensorID = getIntValForKeyIn(params, "Sensor ID") ;
    flag = getIntValForKeyIn(params, "Processing flag") ;
    if (!(flag & _SKIP_INSAR_)) {
        InSAR_CL = addStringValInCSVStruct("InSARProductGeneration", NULL) ;
        InSAR_CL = addStringValInCSVStruct(getStringValForKeyIn(params, "InSAR parameter file path"), InSAR_CL) ;
        if (sensorID & __SENTINEL1__) {
            InSAR_CL = addStringValInCSVStruct("-C", InSAR_CL) ;
        }
        if ((pol = getStringValForKeyIn(params, "Preferred polarization scheme"))) {
            anOption = initStringWith2Strings("P=", pol) ;
            InSAR_CL = addStringValInCSVStruct(anOption, InSAR_CL) ;
            free(anOption) ;
        }
        
        InSARProductsGeneration(InSAR_CL) ;
        freeCSVStruct(InSAR_CL) ;

        /* Filtering management */
        if (!(flag & _SKIP_FILTER_)) {
            printf("\n---> Interferogram filtering\n") ;
            InSAR_CL = addStringValInCSVStruct("interferogramFiltering", NULL) ;
            InSAR_CL = addStringValInCSVStruct(getStringValForKeyIn(params, "InSAR parameter file path"), InSAR_CL) ;
            interferogramFiltering(InSAR_CL) ;
            freeCSVStruct(InSAR_CL) ;
        }        

        /* Phase unwrapping management */
        if (!(flag & _SKIP_UNWRAP_)) {
            printf("\n--->Phase unwrapping\n") ;
            InSAR_CL = addStringValInCSVStruct("phaseUnwrapping", NULL) ;
            InSAR_CL = addStringValInCSVStruct(getStringValForKeyIn(params, "InSAR parameter file path"), InSAR_CL) ;
            if (!(flag & _SKIP_FILTER_)) {
                InSAR_CL = addStringValInCSVStruct("-F", InSAR_CL) ;
            }
            if (flag & _COMPUTE_DEFO_) {
                InSAR_CL = addStringValInCSVStruct("-r", InSAR_CL) ;
            }
            InSAR_CL = addStringValInCSVStruct("--snaphu", InSAR_CL) ;

            if (!phaseUnwrapping(InSAR_CL)) {
                printf("Snaphu crashed 2 times. Most probably missing memory\n") ;
                printf("Attempting home made branch cut algorithm\n") ; 
                InSAR_CL = removeStringValInCSVStruct("--snaphu", InSAR_CL) ;
                phaseUnwrapping(InSAR_CL) ;
            }            

            freeCSVStruct(InSAR_CL) ;
        }        
    }

    return (params) ;
}

keyValue *geoProjectionPhase(keyValue *params)
{
    char *masterFilePath, *pGeoProjPath ;
    int flag ;
    CSVStruct *InSAR_CL ;
    CSLImage *masterImage ;

    flag = getIntValForKeyIn(params, "Processing flag") ;
    if (!(flag & _SKIP_GEOPROJ_)) {
        pGeoProjPath = getStringValForKeyIn(params, "Geoprojection parameter file path") ;
        flag = getIntValForKeyIn(params, "Processing flag") ;
        masterFilePath = getStringValForKeyIn(params, "Master .csl file path") ;
        masterImage = getCSLImageStructureAtPath(masterFilePath) ;
        printf("\n---> Geoprojection\n") ;
        InSAR_CL = addStringValInCSVStruct("geoProjection", NULL) ;
        InSAR_CL = addStringValInCSVStruct(pGeoProjPath, InSAR_CL) ;
        InSAR_CL = addStringValInCSVStruct("-r", InSAR_CL) ;
        InSAR_CL = addStringValInCSVStruct("-i", InSAR_CL) ;
        if (!isFilePresentInCSLImage(masterImage, "externalSlantRangeDEM")) {
            InSAR_CL = addStringValInCSVStruct("-g", InSAR_CL) ;
        }

        geoProjectionMain(InSAR_CL) ;

        freeCSLImageStructure(masterImage) ;
        freeCSVStruct(InSAR_CL) ;
    }

    return(params) ;
}
