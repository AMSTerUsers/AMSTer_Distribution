
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 * @file : envi2cog
 * @project: tool
 * @author Created by Dominique Derauw
 * @copyright ©2025 Dominique Derauw - SAREOS
 * @date : 2025-11-06
 * Description : Conversion of ENVI format image to Cloud Optimized Geotiff format
 */

// #include "envi2cog.h"

#include <stdio.h>
#include <stdlib.h>

#include "pourtous.h"
#include "fileAccessLib.h"

void envi2cogUsage() ;

int main(int argc, char *argv[]) {
    char *inputFilePath, *outputFilePath, *filePath, *tempFilePath ;
    int i ;

    if (argc == 1 || isArgumentPresent(argc, argv, "h")) {
        envi2cogUsage() ;
    }
    
    inputFilePath = initStringWithString(argv[1]) ;
    if (!fileExistsAtPath(inputFilePath)) {
        free(inputFilePath) ;
        envi2cogUsage() ;
    }
    
    outputFilePath = NULL ;
    for ( i = 2; i < argc; i++) {
        outputFilePath = initStringWithString(argv[2]) ;
        if (!isWriteAccessGrantedAtPath(outputFilePath)) {
            free(outputFilePath) ;
            outputFilePath = NULL ;
        }
        i++ ;
    }

    if (!outputFilePath) {
        filePath = initStringWithString(inputFilePath) ;
        stripExtensionAtEndOfPath(filePath) ;
        outputFilePath = initStringWith2Strings(filePath, ".tif") ;
        free(filePath) ;
    }

    
    snprintf(aCommand, sizeof(aCommand),
    "gdal_translate %s %s -of GTiff -co TILED=YES -co COMPRESS=LZW -co BLOCKSIZE=512 -co COPY_SRC_OVERVIEWS=YES -co BIGTIFF=IF_SAFER",
    inputFilePath, outputFilePath) ;
    
    printf("Executing: %s\n", aCommand);
    int result = system(aCommand);
    
    if (isArgumentPresent(argc, argv, "-log")) {
        tempFilePath = initStringWith2Strings(outputFilePath, ".temp") ;
        snprintf(aCommand, sizeof(aCommand), "gdal_calc.py -A %s --outfile=%s --calc=\"log10(A + 1)\" --NoDataValue=-9999 --type=Float32 --format=\"GTiff\"", outputFilePath, tempFilePath) ;

        printf("Executing: %s\n", aCommand);
        int result = system(aCommand);

        unlink(outputFilePath) ;
        rename(tempFilePath, outputFilePath) ;
        free(tempFilePath) ;
    }

    if (result == 0) {
        printf("Conversion to COG successful!\n");
    } else {
        printf("Conversion failed.\n");
    }

    free(inputFilePath) ;
    free(outputFilePath) ;

    return result;
}


void envi2cogUsage() 
{
    printf ("envi2cog inputFilePath [outputFilePath] [-log]\n") ;
    exit(0) ;
}