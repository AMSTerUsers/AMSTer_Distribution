
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  ffa
//
//  Created by Dominique Derauw on 25/04/2017.
//  Copyright © 2017 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "vectors.h"
#include "matrix.h"
#include "rawFileLib.h"

//#define _BUFFER_SIZE_ (int)(1024 * 1024)
void usage(void) ;

int main(int argc, const char * argv[]) {
    char inPlace, byteMask ;
    char operator, *outputPath, *outputFileName = NULL, *opString = NULL ;
    int iX ;
    float *data1, operand, *result ;
    void *data2 ;
    size_t nBlocs, lastBlocSize, blocSize, iB ;
    rawFileDescriptor *file1, *file2, *outputFile = NULL ;
    
    if (argc < 4 || isFlagPresent(argc, argv, "h")) {
        usage() ;
    }
    
    if((file1 = openRawFileForReadingAndWritingAtPath((char *)argv[1])) == NULL) {
        ase("Failed to open first file") ;
    }
    if((file2 = openRawFileForReadingAtPath((char *)argv[3])) == NULL) {
        ase("Failed to open second file") ;
    }
    
    if (4 * (file1->fileLength / 4) != file1->fileLength) {
        ase("ffa: first file must be float.") ;
    }
    file1->typeSize = file2->typeSize = 4 ;

    byteMask = 0 ;
    if (file1->fileLength != file2->fileLength) {
        if (file1->fileLength == 4 * file2->fileLength) {
            byteMask = 1 ;
            file2->typeSize = 1 ;
        }
        else {
            ase("ffa: files do no have same dimensions") ;
        }
    }

    operator = argv[2][0] ;
    switch (operator) {
        case '+':
            opString = initStringWithString("_+_") ;
            printf("Adding file %s with file %s\n", file1->fileName, file2->fileName) ;
            break;
            
        case '-':
            opString = initStringWithString("_-_") ;
            printf("Subtracting file %s from file %s\n", file2->fileName, file1->fileName) ;
            break;
            
        case 'x':
            opString = initStringWithString("_X_") ;
            printf("Multiplicating file %s with file %s\n", file1->fileName, file2->fileName) ;
            break;
            
        case '/':
            opString = initStringWithString("_div_") ;
            printf("Dividing file %s by file %s\n", file1->fileName, file2->fileName) ;
            break;
            
        case 'N':
            opString = initStringWithString("_NaN_") ;
            genFloatNaN() ;
            printf("NaN masking of %s file by %s file\n", file1->fileName, file2->fileName) ;
            break;
            
        default:
            ase("Opertor not recognized") ;
            break;
    }
    
    inPlace = 0 ;
    if (argc > 4) {
        if (isWriteAccessGrantedAtPath((char *)argv[4])) {
            outputPath = initStringWithString((char *)argv[4]) ;
        }
    }
    if (isArgumentPresent(argc, argv, "-i")) {
        printf("\t---> Masking in-place\n") ;
        inPlace = 1 ;
    }
    else {
        if (!outputPath) {
            outputFileName = initStringWith3Strings(file1->fileName, opString, file2->fileName) ;
            outputPath = initStringWith2Strings(file1->directoryPath, outputFileName) ;
            free(outputFileName) ;
        }
        
        if ((outputFile = openRawFileForWritingAtPath(outputPath)) == NULL) {
            printf("Failed to create output file at path:\n%s\n", outputPath) ;
            printf("Destination directory: %s\n", file1->directoryPath) ;
            printf("File name: %s\n", outputFileName) ;
            ase("Failed to create output...") ;
        }
        
        free(outputPath) ;
        printf("Destination directory: %s\n", outputFile->directoryPath) ;
        printf("Destination fileName:  %s\n\n", outputFile->fileName) ;
    }

    data1 = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    data2 = vectorOfType(0, _BUFFER_SIZE_ - 1, file2->typeSize) ;
    result = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    nBlocs = file1->fileLength / file1->typeSize / _BUFFER_SIZE_ ;
    lastBlocSize = file1->fileLength / file1->typeSize - nBlocs * _BUFFER_SIZE_  ;
    
    for (iB = 0; iB <= nBlocs; iB++) {
        blocSize = (iB == nBlocs)? lastBlocSize : _BUFFER_SIZE_ ;
        fread(data1, file1->typeSize, blocSize, file1->f) ;
        fread(data2, file2->typeSize, blocSize, file2->f) ;
        for (iX = 0; iX < blocSize; iX++) {
            operand = (byteMask)? (float)(*(char *)(data2 + iX)) : *((float *)(data2 + iX * file2->typeSize)) ;
            switch (operator) {
                case '+':
                    result[iX] = data1[iX] + operand ;
                    break;
                    
                case '-':
                    result[iX] = data1[iX] - operand ;
                    break;
                    
                case 'x':
                    result[iX] = data1[iX] * operand ;
                    break;
                    
                case '/':
                    result[iX] = data1[iX] / operand ;
                    break;
                    
                case 'N':
                    result[iX] = (operand)? data1[iX] : floatNaN ;
                    break;
                    
                default:
                    break;
            }
        }
        if (inPlace) {
            if (fseek(file1->f, -1 * blocSize * file1->typeSize, SEEK_CUR) == -1) {
                perror("Failed to seek in output file\n") ;
            }
            
            fwrite(result, file1->typeSize, blocSize, file1->f) ;
        }
        else {
            fwrite(result, file1->typeSize, blocSize, outputFile->f) ;
        }
    }
    
    freeVectorOfType(data1, 0, file1->typeSize) ;
    freeVectorOfType(data2, 0, file2->typeSize) ;
    freeVectorOfType(result, 0, file1->typeSize) ;
    freeRawFileDescriptor(file1) ;
    freeRawFileDescriptor(file2) ;
    if (!inPlace) {
        freeRawFileDescriptor(outputFile) ;
    }

    return 0;
}


void usage()
{
    printf("Usage: ffa = floatFilesArithmetics\nffa pathToFile1 A pathToFile2 [-i]/[outputPath]\n") ;
    printf("where A is the classical arithmetic sign, i.e. +, -, x or /\n") ;
    printf("Both files must have the same X * Y dimension.\nSecond file can be coded in signed char\n") ;
    printf("Result file is saved at the given output path if present\n") ;
    printf(" If an output path is not given, the result will be saved in the file1 directory \nwith filename made of the concatenation of both file names and the requested operand\n") ;
    printf("\nOption:\n") ;
    printf("\t-i: In place --> First file is replaced by the result\n") ;
    exit(0) ;
}
