
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  S1BurstCounter
//
//  Created by Dominique Derauw on January 15, 2025.
//  Copyright © 2025 Dominique Derauw. All rights reserved.
//


#include <stdio.h>
#include "pourtous.h"
#include "fileAccessLib.h"
#include "aoiHandling.h"
#include "stringLib.h"
#include "infoImageS1.h"
#include "S1DataReaderLib.h"

void S1BurstCounterUsage(void) ;


int main(int argc, const char * argv[]) {
    char test, burstTest, shortName, *imageName, *preferredPol = NULL ;
    char *inputDir, *referenceImagePath, *destDir, *linkPath ;
    char *kmlDir, *aPath, aKey[32], *refImageName ;
    int j, firstSwathIndex, lastSwathIndex, numberOfSwaths, swathIndex, refSwathIndex ;
    int *firstBurstIndex, *lastBurstIndex, burstIndex, refBurstIndex ;
    point2D **refPoint ; 
    size_t i, N ;
    SLCImageInfo *refInfo, **info, *currentInfo ; ;
    CSLImage *refImage, **image, *currentImage ;
    CSVStruct *CSLImageList, *existingLinks, *csv ;
    CSVStruct *refPol, *pol, *burstList ;
    keyValue *burstSelection ;
    polygon *aoi ;
    S1BurstSelection *refBurstSelection, *currentBurstSelection ;

    if (argc == 1 || isFlagPresent(argc, argv, "h")) {
        S1BurstCounterUsage() ;
    }

    /* Determine if links must be saved with short name */
    shortName = isFlagPresent(argc, argv, "-d") ;

    /* Determine if a specific polarization scheme is requested */
    if ((i = isArgumentPresent(argc, argv, "P="))) {
        preferredPol = initStringWithString(argv[i] + 2) ;
    }
    

    
    /* If a Sentinel1 .csl image is given in entry, it will be the reference image. */
    /* All images in the same directory will be checked with respect to the reference one */
    /* to keep only those haveing the same burst structure. */
    if ((refImage = getCSLImageStructureAtPath(argv[1]))) {
        refInfo = readInfoImageInCSLImageAtPath(argv[1]) ;
        inputDir = getDirectoryPathFromPath(argv[1]) ;
        referenceImagePath = initStringWithString(argv[1]) ;
    }
    else {
        inputDir = initStringWithString(argv[1]) ;
    }

    /* Getting output directory */
    destDir = NULL ;
    if (argc > 2) {
        if (isDir(argv[2])) {
            destDir = initStringWithString(argv[2]) ;
        }   
    }
    if (!destDir) {
        destDir = initStringWith2Strings(inputDir, "/BurstChecked") ;
    }
    makeDirRecursively(destDir) ;
    
    /* Get all image in .csl format in input directory */
    CSLImageList = listDirectoriesOfNameInDir(".csl", inputDir) ;
    if (!CSLImageList) {
        printf("No .csl image foud at path %s.\n", inputDir) ;
        S1BurstCounterUsage() ;
    }

    /* Get all existing linked images in destination directory */
    /* Remove all found .csl images targeted by a link */
    existingLinks = listDirectoriesOfNameInDir(".csl", destDir) ;
    if (existingLinks) {
        for (i = 0; i < existingLinks->numberOfEntries; i++) {
            if (!isSymbolicLink(existingLinks->stringVal[i])) {
                removeStringValAtIndexInCSVStruct(i, existingLinks) ;
                i-- ;
            }
            else {
                linkPath = expandEnvironmentVariablesInPath(existingLinks->stringVal[i]) ;
                if (isCSLImageAtPath(linkPath)) {
                    if (!i) {
                        if (refImage) {
                            printf("\t---> Some links already presents within destination directory.\n") ;
                            printf("\t---> First found one will be used to redefine reference image.\n") ;
                            freeCSLImageStructure(refImage) ;
                            freeInfoImage(refInfo) ;
                        }
                        refImage = getCSLImageStructureAtPath(linkPath) ;                        
                        refInfo = readInfoImageInCSLImageAtPath(linkPath) ;
                    }
                    
                    j = 0 ;
                    while (j < CSLImageList->numberOfEntries) {
                        if (!strcmp(linkPath, CSLImageList->stringVal[j])) {
                            removeStringValAtIndexInCSVStruct(j, CSLImageList) ;
                            break ;
                        }
                        
                        j++ ;
                    } ;
                }
                free(linkPath) ;
            }
        }
    }

    
    /* Keep only the Sentinel1 images of the same relative orbit than the reference one */
    /* If no reference image was given, the first S1 image found will be the reference one */
    N = CSLImageList->numberOfEntries ;
    info = malloc(N * sizeof(info[0])) ;
    image = malloc(N * sizeof(image[0])) ;
    for (i = 0; i < CSLImageList->numberOfEntries; i++) {
        currentImage = getCSLImageStructureAtPath(CSLImageList->stringVal[i]) ;
        currentInfo = readInfoImageInCSLImage(currentImage) ;
        if (currentInfo->sensorID != __SENTINEL1__) {
            removeStringValAtIndexInCSVStruct(i, CSLImageList) ;
            i-- ;
            freeCSLImageStructure(currentImage) ;
            freeInfoImage(currentInfo) ;
        }
        else {
            if (!refImage) {
                refImage = currentImage ;
                refInfo = currentInfo ;
                removeStringValAtIndexInCSVStruct(i, CSLImageList) ;
                i-- ;
            }
            else {
                if (refInfo->relativeOrbitNumber != currentInfo->relativeOrbitNumber || !strcmp(currentInfo->scene_id, refInfo->scene_id)) {
                    removeStringValAtIndexInCSVStruct(i, CSLImageList) ;
                    i-- ;
                    freeCSLImageStructure(currentImage) ;
                    freeInfoImage(currentInfo) ;
                }
                else {
                    if (preferredPol && !isSubStringPresentInString(currentInfo->polMode, preferredPol)){
                        removeStringValAtIndexInCSVStruct(i, CSLImageList) ;
                        i-- ;
                        freeCSLImageStructure(currentImage) ;
                        freeInfoImage(currentInfo) ;
                    }
                    else {
                        image[i] = currentImage ;
                        info[i] = currentInfo ;
                    }
                }
            }
        }
    }
    for (; i < N; i++) {
        image[i] = info[i] = NULL ;
    }
    printf("\t---> Reference image is %s\n", refImage->imageDirectoryPath) ;
    printf("\t---> All S1 images within %s\n\t\t having all its bursts corresponding with those of reference image will be linked into\n\t\t%s\n\n", inputDir, destDir) ;
    

    /* Let's go */
    refBurstSelection = getS1BurstSelectionForImage(refImage) ;
    for (i = 0; i < CSLImageList->numberOfEntries; i++) {
        test = 1 ;
        if (isSubStringPresentInString(info[i]->acquisitionDate, "20180428")) {
            printf("ici\n") ;
        }
        
        /* Get current burst selection descriptor  */
        currentBurstSelection = getS1BurstSelectionForImage(image[i]) ;

        /* First verify tha current image have the same number of burst per swath than reference one */
        test *= (currentBurstSelection->firstSwathIndex == refBurstSelection->firstSwathIndex) ; 
        test *= (currentBurstSelection->lastSwathIndex == refBurstSelection->lastSwathIndex) ; 
        if (test) {
            for (swathIndex = currentBurstSelection->firstSwathIndex; swathIndex <= currentBurstSelection->lastSwathIndex; swathIndex++) {
                test *= (currentBurstSelection->numberOfBursts[swathIndex] == refBurstSelection->numberOfBursts[swathIndex]) ;
            }
        }
        
        if (test) {
            /* Loop on current image bursts */
            for (swathIndex = currentBurstSelection->firstSwathIndex; swathIndex <= currentBurstSelection->lastSwathIndex; swathIndex++) {
                for (burstIndex = currentBurstSelection->firstBurstIndex[swathIndex]; burstIndex <= currentBurstSelection->lastBurstIndex[swathIndex]; burstIndex++) {
                    aoi = currentBurstSelection->aoi[swathIndex][burstIndex] ;              

                    /* Loop on reference image bursts*/
                    burstTest = 0 ;
                    for (refBurstIndex = refBurstSelection->firstBurstIndex[swathIndex]; refBurstIndex <= refBurstSelection->lastBurstIndex[swathIndex]; refBurstIndex++) {
                        refPoint = refBurstSelection->refPoint[swathIndex] + refBurstIndex ;
                        burstTest += isPointIncludedInPolygon(refPoint, aoi) ;
                    }
                    test *= burstTest ;
                }
            }
        }

        if (!test) {
            freeCSLImageStructure(image[i]) ;
            freeInfoImage(info[i]) ;
            image[i] = info[i] = NULL ;
        }
        
        
        freeS1BurstSelection(currentBurstSelection) ;
    }
    

    /* Make symlink to reference image */
    if (shortName){
        imageName = initStringWith2Strings(refInfo->acquisitionDate, ".csl") ;
    }
    else {
        imageName = getFileNameFromPath(refImage->imageDirectoryPath) ;
    }
    
    linkPath = initStringWith3Strings(destDir, "/", imageName) ;
    if (!isDir(linkPath)) {
        if (symlink(refImage->imageDirectoryPath, linkPath)) {
            ase("\n\t\t-/-> Failed to create link to reference image within destination directory. \n\n") ;
        }
    }
    free(linkPath) ;
    free(imageName) ;

    /* Make links for selected images */
    for (i = 0; i < CSLImageList->numberOfEntries; i++) {
        if(info[i]) {
            if (shortName){
                imageName = initStringWith2Strings(info[i]->acquisitionDate, ".csl") ;
            }
            else {
                imageName = getFileNameFromPath(image[i]->imageDirectoryPath) ;
            }
            linkPath = initStringWith3Strings(destDir, "/", imageName) ;
            if (symlink(image[i]->imageDirectoryPath, linkPath)) {
                ase("\n\t\t-/-> Failed to create link to reference image within destination directory. \n\n") ;
            }
            free(linkPath) ;
            free(imageName) ;

            freeCSLImageStructure(image[i]) ;
            freeInfoImage(info[i]) ;
        }
    }

    free(info) ;
    free(image) ;
    freeCSVStruct(CSLImageList) ;
    free(inputDir) ;
    free(destDir) ;
    freeS1BurstSelection(refBurstSelection) ;
}

void S1BurstCounterUsage(void) {
    printf("Usage: \n") ;
    printf("-1- S1BurstCounter ./inputDir [outputDir] [-d] [P=XX]\n") ;
    printf("-2- S1BurstCounter /pathToRefImage [outputDir] [-d] [P=XX]\n") ;
    printf("\nAs its name states it S1BurstCounter counts bursts in all S1 images found in given directory.\n") ;
    printf("First S1 image found in input directory will be used as reference.\n") ;
    printf("It then save links to all S1 images having corresponding bursts with reference one in destination directory.\n") ;
    printf("If output directory is not given, it is created with name ./BurstChecked in input directory. \n") ;
    printf("It also accepts a reference .csl image as input in which case the directory containing this reference image will be considered as input directory. \n") ;
    printf("If destination directory already contains links to S1 images, the first linked image will be considered as reference.\n") ;
    printf("-d : This option allows saving short name links as used by AMSTer toolbox (YYYYMMDD.csl)\n") ;
    printf("P=XX : By default, S1BurstCounter selects only S1 images having exactly the same polarisation schème than the reference one.\n") ;
    printf("\tTo overcome this limitation, one can give a preferred polarization scheme to select both single and dual pol images\n") ;
    printf("\tprovided they both share this preferred polarisation scheme\n") ;
    printf("\n") ;
    exit(0) ;
}

