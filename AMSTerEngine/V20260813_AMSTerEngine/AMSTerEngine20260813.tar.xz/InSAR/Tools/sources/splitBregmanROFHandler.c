
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  SplitBregmanROFHandler.c
 *  SplitBregmanROF
 *
 *  Created by Dominique Derauw on Sun Aug 7 2022.
 *  Copyright (c) 2022 SAREOS Dominique Derauw. All rights reserved.
 *
 *  This simply a C wrapper to handle SplitBregmanROF.c original sources by Tom Goldstein
 *
 *  See DISCLAMER in SplitBregmanROF.c file
 * 
 */

#include "SplitBregmanROFHandler.h"



int main(int argc, const char * argv[])
{
    char isFloat, *outputPath ;
    int xDim, yDim, iY ;
    size_t typeSize, fileSize ; 
    double mu, tol ;
    rawFileDescriptor *inputFile, *outputFile ;
    matrixObject *mIn, *mOut ; 
    mxArray *mx[3], *mxOut[1] ;
    time_t startTime, endTime ;

    if (!(argc > 1 && argc < 7) || isFlagPresent(argc, argv, "h")) {
        splitBregmanROF_Help() ;
    }
    
    if (!(inputFile = openRawFileForReadingAndWritingAtPath((char *)argv[1]))) {
        printf("\t-/-> Failed to open input file\n") ;        
        splitBregmanROF_Help() ;
    }

    xDim = yDim = 0 ;
    sscanf(argv[2], "%d", &xDim) ;
    sscanf(argv[3], "%d", &yDim) ;
    sscanf(argv[4], "%lf", &mu) ;
    sscanf(argv[5], "%lf", &tol) ;

    fileSize = xDim * yDim ;
    if (inputFile->fileLength == fileSize *__SIZEOF_FLOAT__ ) {
        isFloat = 1 ;
        typeSize = __SIZEOF_FLOAT__ ;
    }
    else {
        if (inputFile->fileLength != fileSize * __SIZEOF_DOUBLE__) {
            printf("\t-/-> Wrong file size\n") ;
            splitBregmanROF_Help() ;
        }
        isFloat = 0 ;  
        typeSize = __SIZEOF_DOUBLE__ ;

    }

    time(&startTime) ;
    if (isFloat) {
        mIn = allocFloatMatrixWithIndexes(0, yDim - 1, 0, xDim - 1) ;
    }
    else {
        mIn = allocMatrixObjectofTypeWithIndexes(_REAL64_ID_, 0, yDim - 1, 0, xDim - 1) ;
    }
    if ((fread(mIn->m[0], typeSize, fileSize, inputFile->f) != fileSize)) {
        ase("Failed to read input data\n") ;
    }
    if (isFloat) {
        getMatrixDoubleOfMatrixObject(mIn) ;
        mIn->m = (void **)mIn->md ;
    }
    
    
    mx[0] = alloc_mxArrayOfRank(2) ;
    mx[0]->dataType = _REAL64_ID_ ;
    mx[0]->dims[0] = yDim ;
    mx[0]->dims[1] = xDim ;
    mx[0]->m = mIn->m ;

    mx[1] = alloc_mxArrayOfRank(0) ;
    mx[1]->dataType = _REAL64_ID_ ;
    mx[1]->m = &mu ;

    mx[2] = alloc_mxArrayOfRank(0) ;
    mx[2]->dataType = _REAL64_ID_ ;
    mx[2]->m = &tol ;

    printf("Applying ROF TV-Denoising model using Split Bregman algorithm to file:\n%s\n", inputFile->fileName) ;
    printf("Weighting term mu: %8.5f\n", mu) ;
    printf("Requested tolerance: %8.5f\n", tol) ;

    mexFunction(1, mxOut, 3, (const mxArray **)mx) ;
    
    mOut = allocMatrixObjectofTypeWithIndexes(_REAL64_ID_,0, yDim - 1, 0, xDim - 1) ;
    freeMatrixDouble(mOut->md, 0, 0) ;
    mOut->md = (double **)mxOut[0]->m ;
    mOut->m = mxOut[0]->m ;

    if (isFloat) {
        getMatrixFloatOfMatrixObject(mOut) ;
        mOut->m = (void **)mOut->mf ;
    }
    
    outputPath = initStringWith2Strings(inputFile->accessPath, ".sbr") ;
    outputFile = openRawFileForWritingAtPath(outputPath) ;

    for (iY = 0; iY < yDim - 1; iY++) {
        fwrite(mOut->m[iY], typeSize, xDim, outputFile->f) ;
    }

    printf("\nDone.\n\n") ;
    time(&endTime) ;
    duration(startTime, endTime) ;

    
    freeRawFileDescriptor(inputFile) ;
    freeRawFileDescriptor(outputFile) ;

    freeMatrixObject(mIn) ;
    freeMatrixObject(mOut) ;
    free_mxArray(mx[0]) ;
    free_mxArray(mx[1]) ;
    free_mxArray(mx[2]) ;
    free_mxArray(mxOut[0]) ;

    return (0) ;
}

void splitBregmanROF_Help(void)
{
    printf("\n\nsplitBregmanROF:\n") ;
    printf("This code performs isotropic ROF denoising using the Split Bregman algorithm.\n") ;
    printf("Core C code from Tom Goldstein\n") ;
    printf("\nUsage:\n") ;
    printf("splitBregmanROF /pathTo/image xDim yDim mu tol\n") ;
    printf("Where: image is a 2d array containing the noisy image.\n") ;
    printf("xDim and yDim are (int) dimensions of input image\n") ;
    printf("mu is the weighting parameter for the fidelity term (usually a value between 0.01 and 0.5 works well for images with pixels on the 0-255 scale)\n") ;
    printf("tol is the stopping tolerance for the iteration.  tol = 0.001 is reasonable for most applications.\n") ;
    printf("\n") ;
    printf("\n") ;
    exit (0) ;
}


mxArray *alloc_mxArrayOfRank(int rank)
{
    mxArray *mx ;

    mx = malloc(sizeof(mx[0])) ;
    switch (rank) {
    case 0:
        mx->dims = vectorInt(0, 0) ;
        mx->dims[0] = 1 ;
        break;
    
    case 1:
        mx->dims =  vectorInt(0, 0) ;
        break;
    
    case 2:
        mx->dims =  vectorInt(0, 1) ;
        break;
    
    default:
    free(mx) ;
        return (NULL) ;
        break;
    }

    mx->dataType = 0 ;
    mx->rank = rank ;

    return (mx) ;
}

void free_mxArray(mxArray *mx)
{
    freeVectorInt(mx->dims, 0) ;
    free(mx) ;
}

int mxGetN(const mxArray *mx) 
{
    return (mx->dims[0]) ;
}


int mxGetM(const mxArray *mx) 
{
    return (mx->dims[1]) ;
}


double mxGetScalar(const mxArray *mx) 
{
    double aValue = 0 ;

    switch (mx->dataType) {
    case _REAL32_ID_  :
        aValue = (double)(((float *)mx->m)[0]) ;
        break;
    
    case _REAL64_ID_  :
        aValue = ((double *)mx->m)[0] ;
        break;
    
    default:
        break;
    }
    return (aValue) ;
}


void mexErrMsgTxt(char *message)
{
    ase(message) ;
}

int mxIsDouble(const mxArray *mx)
{
    return ((mx->dataType == _REAL64_ID_)) ;
}

mxArray *mxCreateDoubleMatrix(int xDim, int yDim, int dataType)
{
    mxArray *mx ;
    double **aMatrix ;

    aMatrix = matrixDouble(0, yDim - 1, 0 , xDim- 1) ;
    mx = alloc_mxArrayOfRank(2) ;
    mx->dataType = _REAL64_ID_ ;
    mx->dims[0] = yDim ;
    mx->dims[1] = xDim ;
    mx->m = (void **)aMatrix ;

    return (mx) ;
}

double *mxGetPr(const mxArray *mx)
{
    double **m ;
    if (mx->dataType == _REAL64_ID_) {
        m = (double **)mx->m ;
        return (m[0]) ;
    }
    return (NULL) ;
}