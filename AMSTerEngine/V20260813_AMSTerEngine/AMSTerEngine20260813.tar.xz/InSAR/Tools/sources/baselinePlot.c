
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  baselinePlot.c
//  baselinePlot
//
//  Created by Dominique Derauw on 25/11/2020.
//  Copyright © 2020 SAREOS Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "initInSARLib.h"
#include "sortingRoutines.h"

void baselinePlotHelp(void) ;
void restrictBaselinePlotToSelection(const char * argv[]) ;
void genGnuplotScript(char *outputDir, char *filenameSuffix, double xShift, double yShift, double BpMax, int DTMax, double BpShift, int superMasterDate0, int superMasterDate) ;

struct baselinePlotStruct {
    int masterDate ;
    int slaveDate ;
    int dT ;
    int isSelected ;
    double Bx, By, Bp0, Bp, ha ;
    double xs, ys, xm, ym ;
} ;
typedef struct baselinePlotStruct baselinePlotElement ;

int main(int argc, const char * argv[])
{
    char *inputDir, *outputDir = NULL, *outputPath, *fileNameSuffix = NULL ;
    char *aPath ;
    char masterDateString[10], slaveDateString[10] ;
    char test ;
    int i, j, k, k0, ks ;
    int numberOfPairs, numberOfSelectedPairs ;
    int superMasterDate0, superMasterDate ;
    int masterDate, slaveDate ;
    int DTMax, anInt ;
    int *index = NULL ;
    double x0, y0, dMin, dist ;
    double xShift, yShift, BpShift, BxShift, ByShift ;
    double BpMax, haMax, haMin ;
    double alpha ; 
    int *dates ;
    CSVStruct *CSLImageList = NULL ;
    CSVStruct *sortedCSLImageList = NULL ;
    CSVStruct *selectedImageList = NULL ;
    CSVStruct *fileNameComponent = NULL;
    baselinePlotElement *pair ; 
    SLCImageInfo *masterInfo, *slaveInfo ;
    CSLImage *masterImage, *slaveImage ;
    InSARParametersStruct *pInSAR ;
    rawFileDescriptor *outputFile, *outputFile2 ;
    rawFileDescriptor *table = NULL ;
    polygon *acquisitionLocalisations ;

    if (argc == 1 || isFlagPresent(argc, argv, "h")) {
        baselinePlotHelp() ;
    }
    
    /* Test first if reevaluation of an existing baseline plot with respect to a selection is requested */
    /* Pair selection must be issued from one of the MasTerToolbox script and be a text file with four columns: */
    /* pathToDiffLayer Bp masterDate slaveDate */
    if ((isArgumentPresent(argc, argv, "-r") == 1) && argc == 4) {
        restrictBaselinePlotToSelection(argv) ;
    }

    if (!isDir((char *)argv[1])) {
        baselinePlotHelp() ;
    }
    inputDir = initStringWithString((char *)argv[1]) ;
    BpMax = 0 ;
    DTMax = 0 ;
    haMax = haMin = 0 ;
    if ((j = isArgumentPresent(argc, argv, "BpMax="))) {
        sscanf(argv[j], "BpMax=%lf", &BpMax) ;
    }
    if ((j = isArgumentPresent(argc, argv, "haMax="))) {
        sscanf(argv[j], "haMax=%lf", &haMax) ;
    }
    if ((j = isArgumentPresent(argc, argv, "haMin=")) && !isArgumentPresent(argc, argv, "BpMax=")) {
        sscanf(argv[j], "haMin=%lf", &haMin) ;
    }
    if ((j = isArgumentPresent(argc, argv, "dTMax="))) {
        sscanf(argv[j], "dTMax=%d", &DTMax) ;
    }        
    
    for (i = 2; i < argc; i++) {
        aPath = getDirectoryPathFromPath((char *)argv[i]) ;
        if (isDir((char *)argv[i]) || isDir(aPath)) {
            outputDir = initStringWithString((char *)argv[i]) ;
        }
        free(aPath) ;
    }
    
    if (!isDir(outputDir)) {
        if (!outputDir) {
            outputDir = initStringWith2Strings(inputDir, "/BaselinePlot") ;
        }
        if (!isDir(outputDir)) {
            aPath = getDirectoryPathFromPath(outputDir) ;
            if (isWriteAccessGrantedAtPath(aPath)) {
                if(mkdir((const char *)outputDir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
                    sprintf(ertex, "Failed to create output directory at path %s\n", outputDir) ;
                    ase(ertex) ;
                }
            }
            else {
                    sprintf(ertex, "Cannot create output directory at path %s\n", outputDir) ;
                    ase(ertex) ;
            }
            free(aPath) ;
        }
    }
    if (!isWriteAccessGrantedAtPath(outputDir)) {
        ase("OutputDir: write access denied\n") ;
    }
    if (!isReadAccessGrantedAtPath(inputDir)) {
        ase("InputDir: read access denied\n") ;
    }

    CSLImageList = listCSLImagesInDir(inputDir) ;
    numberOfPairs = CSLImageList->numberOfEntries * (CSLImageList->numberOfEntries - 1) / 2 ;
    if ((pair = malloc(numberOfPairs * sizeof(baselinePlotElement))) == NULL) {
        ase("Failed to allocate list of pairs\n") ;
    }

/* Compute listing of all potential pairs */
    outputPath = initStringWith2Strings(outputDir, "/allPairsListing.txt") ;
    outputFile = openRawFileForWritingAtPath(outputPath) ;
    free(outputPath) ;
    fprintf(outputFile->f, "# List of all potential InSAR pairs in directory:\n# \t%s\n# \n", inputDir) ;

    /* First, we read dates of available images */
    dates = vectorInt(0, CSLImageList->numberOfEntries - 1) ;
    masterImage = getCSLImageStructureAtPath(CSLImageList->stringVal[0]) ;
    masterInfo = readInfoImageInCSLImage(masterImage) ;
    sscanf(masterInfo->acquisitionDate, "%d", &masterDate) ;
    dates[0] = masterDate ;
    for (j = 1; j < CSLImageList->numberOfEntries; j++) {
        slaveImage = getCSLImageStructureAtPath(CSLImageList->stringVal[j]) ;
        slaveInfo = readInfoImageInCSLImage(slaveImage) ;
        sscanf(slaveInfo->acquisitionDate, "%d", &slaveDate) ;
        dates[j] = slaveDate ;
        freeInfoImage(slaveInfo) ;
        freeCSLImageStructure(slaveImage) ;
    }
    freeInfoImage(masterInfo) ;
    freeCSLImageStructure(masterImage) ;


    /* Sort dates in ascending order */
    index = sortIntVect(dates, index, CSLImageList->numberOfEntries, _ASCENDING_SORT_) ;

    /* Order CSL images with respect to sorting */
    for (i = 0; i < CSLImageList->numberOfEntries; i++) {
        sortedCSLImageList = addStringValInCSVStruct(CSLImageList->stringVal[index[i]], sortedCSLImageList) ;
    }
    freeCSVStruct(CSLImageList) ;
    CSLImageList = sortedCSLImageList ;

    /* Read info of the first image in chronological order */
    masterImage = getCSLImageStructureAtPath(CSLImageList->stringVal[0]) ;
    masterInfo = readInfoImageInCSLImage(masterImage) ;
    alpha = -masterInfo->wavelength / 2 * sin(PI/180 * masterInfo->incidenceAngle[1]) * masterInfo->slantRange[1] ; 
    if (!BpMax && haMin) {
        BpMax = fabs(round(alpha / haMin)) ;
    }
    
    
    /* Compute pairs parameters */
    k = 0 ;
    for (i = 0; i < CSLImageList->numberOfEntries - 1; i++) {
        masterDate = dates[i] ;
        sprintf(masterDateString, "%d", masterDate) ;
        for (j = i + 1; j < CSLImageList->numberOfEntries; j++, k++) {
            slaveDate = dates[j] ;
            sprintf(slaveDateString, "%d", slaveDate) ;
            if (!i) {
                slaveImage = getCSLImageStructureAtPath(CSLImageList->stringVal[j]) ;
                slaveInfo = readInfoImageInCSLImage(slaveImage) ;
                sscanf(slaveInfo->acquisitionDate, "%d", &slaveDate) ;
                printf("\nTesting pair %d - %d:", masterDate, slaveDate) ;

                pInSAR = allocAndinitInSARParametersStructAtPathForImages(NULL, masterImage, slaveImage, NULL, 0, NULL) ;                
                initInSAR_GEO(pInSAR, _COMPUTEAOI_) ;

                pair[k].Bx = pInSAR->B.T[0][2] ;
                pair[k].By = pInSAR->B.T[1][2] ;
                pair[k].Bp = pInSAR->B.Bperp ;
                pair[k].dT = pInSAR->B.deltaDays ;
                pair[k].xm = pair[k].ym = pair[k].Bp0 = 0 ;
                pair[k].xs = pair[k].Bx ;
                pair[k].ys = pair[k].By ;

                pInSAR->masterImage = NULL ;
                freeInSARParametersStruct(pInSAR) ;
                freeInfoImage(slaveInfo) ;
            }
            else {
                pair[k].Bx = pair[j - 1].Bx - pair[i - 1].Bx ;
                pair[k].By = pair[j - 1].By - pair[i - 1].By ;
                pair[k].Bp = pair[j - 1].Bp - pair[i - 1].Bp ;
                pair[k].dT = pair[j - 1].dT - pair[i - 1].dT ;
                pair[k].xm = pair[i - 1].Bx ;
                pair[k].ym = pair[i - 1].By ; ;
                pair[k].xs = pair[j - 1].Bx ;
                pair[k].ys = pair[j - 1].By ;
                pair[k].Bp0 = pair[i - 1].Bp ;
            }
            
            pair[k].ha = alpha / pair[k].Bp  ;
            pair[k].masterDate = masterDate ;
            pair[k].slaveDate = slaveDate ;
        }
    }
    freeCSLImageStructure(masterImage) ;

    printf("\n\t---> Number of candidate pairs: %d\n", k) ;
    
    /* Compute centre of mass */
    x0 = y0 = 0 ;
    for (k = 0; k < CSLImageList->numberOfEntries - 1; k++) {
        x0 += pair[k].xs ;
        y0 += pair[k].ys ;
    }
    x0 /= CSLImageList->numberOfEntries ;
    y0 /= CSLImageList->numberOfEntries ;

    /* Identify super master */ 
    superMasterDate0 = pair[0].masterDate ;
    dMin = sqrt(pow(pair[0].xm - x0, 2.) + pow(pair[0].ym - y0, 2.)) ;
    k0 = -1 ;
    for (k = 0; k < CSLImageList->numberOfEntries - 1; k++) {
        dist = sqrt(pow(pair[k].xs - x0, 2.) + pow(pair[k].ys - y0, 2.)) ;
        if (dist < dMin) {
            dMin = dist ;
            k0 = k ;
        }        
    }

    if (k0 == -1) {
        superMasterDate0 = pair[0].masterDate ;
        BpShift = BxShift = ByShift = 0 ;        
    }
    else {
        superMasterDate0 = pair[k0].slaveDate ;
        BpShift = pair[k0].Bp ;
        BxShift = pair[k0].Bx ;
        ByShift = pair[k0].By ;
    }
        
    printf("\t---> Identified Super Master: %d\n", superMasterDate0) ;
    fprintf(outputFile->f, "#\n# Identified Super Master: %d\n", superMasterDate0) ;
    fprintf(outputFile->f, "#\n#  Master date   .   Slave date  .       xm     .       ym     .       xs     .       ys     .       Bp0      .       Bp      .       Dt      .       Ha\n") ;
    for (k = 0; k < numberOfPairs; k++) {
        pair[k].xm -= BxShift ;
        pair[k].ym -= ByShift ;
        pair[k].xs -= BxShift ;
        pair[k].ys -= ByShift ;
        pair[k].Bp0 -= BpShift ;        
        fprintf(outputFile->f, "    %d        %d        %8.2lf        %8.2lf        %8.2lf        %8.2lf        %8.2lf        %8.2lf        %8d        %8.2lf\n", pair[k].masterDate, pair[k].slaveDate, pair[k].xm, pair[k].ym, pair[k].xs, pair[k].ys, pair[k].Bp0, pair[k].Bp, pair[k].dT, pair[k].ha) ;
    }
    freeRawFileDescriptor(outputFile) ;

    /* Create acquisition location files */
    outputPath = initStringWith2Strings(outputDir, "/acquisitionsRepartition.txt") ;
    outputFile = openRawFileForWritingAtPath(outputPath) ;
    free(outputPath) ;
    fprintf(outputFile->f, "# Acquisition spatial location within orbital tube of images in directory:\n# \t%s\n# \n", inputDir) ;
    fprintf(outputFile->f, "#\n# Acq. date      .       x      .       y      \n") ;
    fprintf(outputFile->f, "    %d        %8.2lf        %8.2lf\n", pair[0].masterDate, pair[0].xm, pair[0].ym) ;
    for (i = 0; i < CSLImageList->numberOfEntries - 1; i++) {
        fprintf(outputFile->f, "    %d        %8.2lf        %8.2lf\n", pair[i].slaveDate, pair[i].xs, pair[i].ys) ;
    }
    freeRawFileDescriptor(outputFile) ;

    numberOfSelectedPairs = 0 ;
    if (BpMax || DTMax || haMax || haMin) {
        if (BpMax) {
            anInt = (int)rint(BpMax) ;
            fileNameComponent = addStringValInCSVStruct("_BpMax=", fileNameComponent) ;
            fileNameComponent = addIntValInCSVStruct(anInt, fileNameComponent) ;
        }
        if (DTMax) {
            anInt = (int)rint(DTMax) ;
            fileNameComponent = addStringValInCSVStruct("_BTMax=", fileNameComponent) ;
            fileNameComponent = addIntValInCSVStruct(anInt, fileNameComponent) ;
        }
        if (haMax) {
            anInt = (int)rint(haMax) ;
            fileNameComponent = addStringValInCSVStruct("_haMax=", fileNameComponent) ;
            fileNameComponent = addIntValInCSVStruct(anInt, fileNameComponent) ;
        }
        if (haMin) {
            anInt = (int)rint(haMin) ;
            fileNameComponent = addStringValInCSVStruct("_haMin=", fileNameComponent) ;
            fileNameComponent = addIntValInCSVStruct(anInt, fileNameComponent) ;
        }
        fileNameComponent = addStringValInCSVStruct(".txt", fileNameComponent) ;
        fileNameSuffix = getStringFromCSV(fileNameComponent) ;
        
        
        outputPath = initStringWith3Strings(outputDir, "/selectedPairsListing", fileNameSuffix) ;
        if (isSymbolicLink(outputPath)){
            unlink(outputPath) ;
        }
        
        outputFile = openRawFileForWritingAtPath(outputPath) ;
        free(outputPath) ;
        fprintf(outputFile->f, "# List of potential InSAR pairs with criterion in directory:\n# \t%s\n", inputDir) ;
        if (BpMax) {
            fprintf(outputFile->f, "# Maximal perpendicular baseline: %8.2lf\n", BpMax) ;
        }
        if (DTMax) {
            fprintf(outputFile->f, "# Maximal time base: %d\n", DTMax) ;
        }
        if (haMax) {
            fprintf(outputFile->f, "# Maximal ambiguity of altitude: %8.2lf\n", haMax) ;
        }
        if (haMin) {
            fprintf(outputFile->f, "# Minimal ambiguity of altitude: %8.2lf\n", haMin) ;
        }
        for (k = 0; k < numberOfPairs; k++) {
            pair[k].isSelected = 0 ;
            test = 1 ;
            if (BpMax && fabs(pair[k].Bp) > BpMax) {
                test = 0 ;
            }
            if (haMax && fabs(pair[k].ha) > haMax) {
                test = 0 ;
            }
            if (haMin && fabs(pair[k].ha) < haMin) {
                test = 0 ;
            }
            if (DTMax && abs(pair[k].dT) > DTMax) {
                test = 0 ;
            }
            pair[k].isSelected = test ;
            numberOfSelectedPairs += (test)? 1 : 0 ;
        }

        /* If some pairs are selected with respect to criterion, create corresponding text files */
        if (numberOfSelectedPairs){
            printf("\n\t---> Number of selected pairs: %d\n", numberOfSelectedPairs) ;
            /* Sort out selected pairs */
            acquisitionLocalisations = allocPolygon(2 * numberOfSelectedPairs) ;
            for (k = 0; k < numberOfPairs; k++) {
                if (pair[k].isSelected) {
                    if (!selectedImageList) {
                        selectedImageList = addIntValInCSVStruct(pair[k].masterDate, selectedImageList) ;
                        selectedImageList = addIntValInCSVStruct(pair[k].slaveDate, selectedImageList) ;
                        acquisitionLocalisations->P[0].x = pair[k].xm ;
                        acquisitionLocalisations->P[0].y = pair[k].ym ;
                        acquisitionLocalisations->P[1].x = pair[k].xs ;
                        acquisitionLocalisations->P[1].y = pair[k].ys ;
                    }
                    else {
                        if (!isIntValPresentInCSV(pair[k].masterDate, selectedImageList)) {
                            selectedImageList = addIntValInCSVStruct(pair[k].masterDate, selectedImageList) ;
                            acquisitionLocalisations->P[selectedImageList->numberOfEntries - 1].x = pair[k].xm ;
                            acquisitionLocalisations->P[selectedImageList->numberOfEntries - 1].y = pair[k].ym ;
                        }
                        if (!isIntValPresentInCSV(pair[k].slaveDate, selectedImageList)) {
                            selectedImageList = addIntValInCSVStruct(pair[k].slaveDate, selectedImageList) ;
                            acquisitionLocalisations->P[selectedImageList->numberOfEntries - 1].x = pair[k].xs ;
                            acquisitionLocalisations->P[selectedImageList->numberOfEntries - 1].y = pair[k].ys ;
                        }                    
                    }
                }
            }

            /* Create acquisition location files */
            outputPath = initStringWith3Strings(outputDir, "/selectedAcquisitionsSpatialRepartition", fileNameSuffix) ;
            if (isSymbolicLink(outputPath)){
                unlink(outputPath) ;
            }
            outputFile2 = openRawFileForWritingAtPath(outputPath) ;
            free(outputPath) ;

            /* Create table file for MSBAS processing */
            if (BpMax && DTMax) {
                anInt = (int)round(BpMax) ;
                outputPath = allocStringOfLength(strlen(outputDir) + 80) ;
                sprintf(outputPath, "%s/table_0_%-d_0_%-d.txt", outputDir, anInt, DTMax) ;

                table = openRawFileForWritingAtPath(outputPath) ;
                free(outputPath) ;
                fprintf(table->f, "   Master\t   Slave\t Bperp\t Delay\n\n") ;
            }
            

            fprintf(outputFile2->f, "# Selected acquisitions spatial location within orbital tube:\n# Data directory: %s\n# \n", inputDir) ;
            fprintf(outputFile2->f, "#\n# Acq. date      .       x      .       y      \n") ;
            for (k = 0; k < selectedImageList->numberOfEntries; k++) {
                x0 = acquisitionLocalisations->P[k].x ;
                y0 = acquisitionLocalisations->P[k].y ;
                fprintf(outputFile2->f, "    %s        %8.2lf        %8.2lf\n", selectedImageList->stringVal[k], x0, y0) ;
            }
            
            /* Compute centre of mass of selected images */
            x0 = y0 = 0 ;
            for (k = 0; k < selectedImageList->numberOfEntries; k++) {
                x0 += acquisitionLocalisations->P[k].x ;
                y0 += acquisitionLocalisations->P[k].y ;
            }
            x0 /= selectedImageList->numberOfEntries ;
            y0 /= selectedImageList->numberOfEntries ;

            /* Identify super master */ 
            dMin = sqrt(pow(acquisitionLocalisations->P[0].x - x0, 2.) + pow(acquisitionLocalisations->P[0].y - y0, 2)) ;
            ks = 0 ;
            for (k = 0; k < selectedImageList->numberOfEntries - 1; k++) {
                dist = sqrt(pow(acquisitionLocalisations->P[k].x - x0, 2.) + pow(acquisitionLocalisations->P[k].y - y0, 2.)) ;
                if (dist < dMin) {
                    dMin = dist ;
                    ks = k ;
                }     
            }

            /* Find perpendicular baseline shift */
            sscanf(selectedImageList->stringVal[ks], "%d", &superMasterDate) ;
            printf("\t---> Identified super master within selection: : %d\n", superMasterDate) ;
            for (k = 0; k < CSLImageList->numberOfEntries - 1; k++) {
                if (pair[k].slaveDate == superMasterDate) {
                    BpShift = pair[k].Bp - BpShift ;
                }
            }

            /* Centre selected acquisition on new super master */
            xShift = acquisitionLocalisations->P[ks].x ;
            yShift = acquisitionLocalisations->P[ks].y ;
            fprintf(outputFile->f, "#\n# Identified Super Master: %d\n", superMasterDate) ;
            fprintf(outputFile->f, "#\n#  Master date   .   Slave date  .       xm     .       ym     .       xs     .       ys     .       Bp0      .       Bp      .       Dt      .       Ha\n") ;
            for (k = 0; k < numberOfPairs; k++) {                
                if (pair[k].isSelected) {
                    if (ks) {
                        pair[k].xm -= xShift ;
                        pair[k].ym -= yShift ;
                        pair[k].xs -= xShift ;
                        pair[k].ys -= yShift ;
                        pair[k].Bp0 -= BpShift ;
                    }
                    fprintf(outputFile->f, "    %d        %d        %8.2lf        %8.2lf        %8.2lf        %8.2lf        %8.2lf        %8.2lf        %8d        %8.2lf\n", pair[k].masterDate, pair[k].slaveDate, pair[k].xm, pair[k].ym, pair[k].xs, pair[k].ys, pair[k].Bp0, pair[k].Bp, pair[k].dT, pair[k].ha) ;
                    if (table) {
                        anInt = (int)round(pair[k].Bp) ;
                        fprintf(table->f, "%8d\t%8d\t%6d\t%6d\n", pair[k].masterDate, pair[k].slaveDate, anInt, pair[k].dT) ;
                    }
                    
                }
            }

            sprintf(aCommand, "ln -fs %s %s/selectedPairsListing.txt", outputFile->accessPath, outputDir) ;
            system(aCommand) ;
            sprintf(aCommand, "ln -fs %s %s/selectedAcquisitionsSpatialRepartition.txt", outputFile2->accessPath, outputDir) ;
            system(aCommand) ;

            freeRawFileDescriptor(outputFile) ;   
            freeRawFileDescriptor(outputFile2) ;
            if (table) {
                freeRawFileDescriptor(table) ;
            }
            
        }  
        freePolygon(acquisitionLocalisations) ;
    }
    else {
        sprintf(aCommand, "ln -fs %s/allPairsListing.txt %s/selectedPairsListing.txt", outputDir, outputDir) ;
        system(aCommand) ;
        sprintf(aCommand, "ln -fs %s/acquisitionsRepartition.txt %s/selectedAcquisitionsSpatialRepartition.txt", outputDir, outputDir) ;
        system(aCommand) ;
        fileNameSuffix = initStringWithString("_allPairs") ;
    }

    genGnuplotScript(outputDir, fileNameSuffix, xShift, yShift, BpMax, DTMax, BpShift, superMasterDate0, superMasterDate) ;

    free(fileNameSuffix) ;
    freeCSVStruct(selectedImageList) ;
    free(pair) ;
    
    return(0) ;
}

void baselinePlotHelp(void)
{
    printf("Usage: \n-1-\tbaselinePlot imagesDirectory [baselinePlotDirectory] [BpMax=BpMax] [haMax=haMax] [haMin=haMin] [dTMax=dTMax]\n") ;
    printf("-2-\tbaselinePlot -r /pathTo/allreadyPerformed/baselinePlotDir pathTo/pairSubSelection.txt\n") ;
    printf("imageDirectory: Directory where are stored read images in .csl format\n") ;
    printf("baselinePlotDir: Directory where results will be saved. If not provided, input directory will be considered.\n") ;
    printf("pairSubSelection.txt: text file containing pair sub-selection on the form of a \n\tfour-column text file as provided by MasTer Toolbox scripts like restrict_msbas_to_Coh.sh.\n") ;
    exit(0) ;
}


/* Restriction of an already performed baseline plot with respect to a sub selection of valid pairs */
/* First parameter must be the directory toward an already performed baseline plot */
/* Second parameter must be a pair selection issued from a MasTer Toolbox script */
/* This selection is a four column text file havineg the following structure: */
/* pathToDiffLayer Bp masterDate slaveDate */ 
void restrictBaselinePlotToSelection(const char * argv[]) 
{
    char *baselinePlotDir, *acquisitionRepartitionFilePath, *allPairsListingFilePath, *subSelectionFilePath, *aPath, *fileNameSuffix ;
    char test ;
    int NCandidates, i ;
    int masterDate, slaveDate, aDate, superMasterDate0 ; 
    baselinePlotElement *filteredPairListing ; 
    rawFileDescriptor *acquisitionRepartitionFile, *allPairsListingFile, *subSelectionFile, *filteredSelectionFile ;

    baselinePlotDir = initStringWithString((char *)argv[2]) ;
    if (!isDir(baselinePlotDir)) {
        printf("First parameter must be a baselinePlot directory\n") ;
        baselinePlotHelp() ;
    }
    allPairsListingFilePath = initStringWith2Strings(baselinePlotDir, "/allPairsListing.txt") ;
    if (!fileExistsAtPath(allPairsListingFilePath)) {
        ase("allPairsListing.txt file missing in baselinePlot directory\n") ;
    }
    subSelectionFilePath = initStringWithString((char *)argv[3]) ;
    if (!fileExistsAtPath(subSelectionFilePath)) {
        printf("Second parameter must be the path to a sub-selection text file.\n") ;
        baselinePlotHelp() ;
    }
    
    allPairsListingFile = openRawFileForReadingAtPath(allPairsListingFilePath) ;
    subSelectionFile = openRawFileForReadingAtPath(subSelectionFilePath) ;

    /* Count number of pairs in listing */
    i = 0 ;
    while (fgets(aComment, _MAX_COMMENT_LENGTH_, allPairsListingFile->f)) {
        if (strncmp(aComment, "#", 1)) {
            i++ ;
        }
        else {
            if (!strcmp(aComment, "# Identified")) {
                sscanf(aComment, "# Identified Super Master: %d", &superMasterDate0) ;
            }
        }
    }
    NCandidates = i ;
    if (!NCandidates) {
        ase("acquisitionsRepartition.txt file not correctly formatted\n") ;
    }
    if ((filteredPairListing = malloc(NCandidates * sizeof(filteredPairListing[0]))) == NULL) {
        ase("Failed to allocate filtered pair listing") ;
    }
    rewind(allPairsListingFile->f) ;
    i= 0 ;
    /* Read all pairs listing */
    while (fgets(aComment, _MAX_COMMENT_LENGTH_, allPairsListingFile->f)) {
        if (strncmp(aComment, "#", 1)) {
            filteredPairListing[i].isSelected = 0 ;
            sscanf(aComment,"%d %d %lf %lf %lf %lf %lf %lf %d %lf", &(filteredPairListing[i].masterDate), &(filteredPairListing[i].slaveDate), &(filteredPairListing[i].xm), &(filteredPairListing[i].ym), &(filteredPairListing[i].xs), &(filteredPairListing[i].ys), &(filteredPairListing[i].Bp0), &(filteredPairListing[i].Bp), &(filteredPairListing[i].dT), &(filteredPairListing[i].ha)) ;
            i++ ;
        }
        else {
            if (!strncmp(aComment, "# Identified", 12)) {
                sscanf(aComment, "# Identified Super Master: %d", &superMasterDate0) ;
            }
        }
    }

    /* Filter pair listing with respect to sub selection */
    printf("Restricting pair selection %s\nwith respect to file %s\n", allPairsListingFilePath, subSelectionFile->fileName) ;
    printf("Generating corresponding baseline plot\n") ;
    while (fgets(aComment, _MAX_COMMENT_LENGTH_, subSelectionFile->f)) {
        sscanf(aComment, "%*s %*f %d %d", &masterDate, &slaveDate) ;
        if (masterDate > slaveDate) {
            aDate = masterDate ;
            masterDate = slaveDate ;
            slaveDate = aDate ;
        }
        i = 0 ;
        while (filteredPairListing[i].masterDate < masterDate && i < NCandidates) {
            i++ ;
        }
        if (i < NCandidates) {
            while (filteredPairListing[i].masterDate == masterDate && filteredPairListing[i].slaveDate < slaveDate) {
                i++ ;
            }
            if (filteredPairListing[i].slaveDate == slaveDate) {
                filteredPairListing[i].isSelected = 1 ;
            }            
        }
    }
    
    fileNameSuffix = initStringWith2Strings("_", subSelectionFile->fileName) ;
    aPath = initStringWith3Strings(baselinePlotDir, "/restrictedPairSelection", fileNameSuffix) ;
    filteredSelectionFile = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;

    /* Saving restricted listing */
    acquisitionRepartitionFilePath = initStringWith3Strings(baselinePlotDir, "/restrictedAcquisitionsRepartition.txt", fileNameSuffix) ;
    acquisitionRepartitionFile = openRawFileForWritingAtPath(acquisitionRepartitionFilePath) ;

    fprintf(filteredSelectionFile->f, "# Restricted pair listing based on file: \n") ;
    fprintf(filteredSelectionFile->f, "# %s\n", subSelectionFilePath) ;
    fprintf(filteredSelectionFile->f, "# \n") ;
    fprintf(filteredSelectionFile->f, "# \n") ;
    fprintf(filteredSelectionFile->f, "#\n# Identified Super Master: %d\n", superMasterDate0) ;
    fprintf(filteredSelectionFile->f, "#\n#  Master date   .   Slave date  .       xm     .       ym     .       xs     .       ys     .       Bp0      .       Bp      .       Dt      .       Ha\n") ;

    fprintf(acquisitionRepartitionFile->f, "# Acquisition spatial location within orbital tube\n") ;
    fprintf(acquisitionRepartitionFile->f, "# Selection restricted based on file: \n") ;
    fprintf(filteredSelectionFile->f, "# %s\n", subSelectionFilePath) ;
    fprintf(acquisitionRepartitionFile->f, "#\n# Acq. date      .       x      .       y      \n") ;
    test = 0 ;
    for (i = 0; i < NCandidates; i++) {
        if (filteredPairListing[i].isSelected) {
            fprintf(filteredSelectionFile->f, "    %d        %d        %8.2lf        %8.2lf        %8.2lf        %8.2lf        %8.2lf        %8.2lf        %8d        %8.2lf\n", filteredPairListing[i].masterDate, filteredPairListing[i].slaveDate, filteredPairListing[i].xm, filteredPairListing[i].ym, filteredPairListing[i].xs, filteredPairListing[i].ys, filteredPairListing[i].Bp0, filteredPairListing[i].Bp, filteredPairListing[i].dT, filteredPairListing[i].ha) ;               
            if (!test) {
                test = 1 ;
                fprintf(acquisitionRepartitionFile->f, "    %d        %8.2lf        %8.2lf\n", filteredPairListing[i].masterDate, filteredPairListing[i].xm, filteredPairListing[i].ym) ;
            }
            fprintf(acquisitionRepartitionFile->f, "    %d        %8.2lf        %8.2lf\n", filteredPairListing[i].slaveDate, filteredPairListing[i].xs, filteredPairListing[i].ys) ;
        }
        
    }

    sprintf(aCommand, "ln -fs %s %s/selectedPairsListing.txt", filteredSelectionFile->accessPath, baselinePlotDir) ;
    system(aCommand) ;
    sprintf(aCommand, "ln -fs %s %s/selectedAcquisitionsSpatialRepartition.txt", acquisitionRepartitionFile->accessPath, baselinePlotDir) ;
    system(aCommand) ;

    freeRawFileDescriptor(acquisitionRepartitionFile) ;
    freeRawFileDescriptor(filteredSelectionFile) ;
    freeRawFileDescriptor(allPairsListingFile) ;
    freeRawFileDescriptor(subSelectionFile) ;

    genGnuplotScript(baselinePlotDir, fileNameSuffix, 0, 0, 0, 0, 0, superMasterDate0, superMasterDate0) ;
    
    free(filteredPairListing) ;
    free(baselinePlotDir) ;
    free(acquisitionRepartitionFilePath) ;
    free(allPairsListingFilePath) ;
    free(subSelectionFilePath) ;
    free(fileNameSuffix) ;



    exit(0) ;
}



/* gnuplot script creation */
/* Create gnuplot script for displaying spatial repartition of acquisitions */
void genGnuplotScript(char *outputDir, char *fileNameSuffix, double xShift, double yShift, double BpMax, int DTMax, double BpShift, int superMasterDate0, int superMasterDate)
{
    char *outputPath ;
    int anInt ;
    rawFileDescriptor *outputFile ; 
//    if (numberOfSelectedPairs) {
        outputPath = initStringWith2Strings(outputDir, "/baselinePlot.gnuplot") ;
        outputFile = openRawFileForWritingAtPath(outputPath) ;
        free(outputPath) ;    
        fprintf(outputFile->f, "# Spatial baseline plot\n#\n") ;
        fprintf(outputFile->f, "# WorkingDirectory:\n") ;
        fprintf(outputFile->f, "workingDir = sprintf(\"%s\")\n", outputDir) ;
        fprintf(outputFile->f, "filenameSuffix = sprintf(\"%s\")\n", fileNameSuffix) ;
        fprintf(outputFile->f, "\n# Input files:\n") ;
        fprintf(outputFile->f, "inputFile0 = sprintf(\"%%s/allPairsListing.txt\", workingDir)\n") ;
        fprintf(outputFile->f, "inputFile1 = sprintf(\"%%s/acquisitionsRepartition.txt\", workingDir)\n") ;
        fprintf(outputFile->f, "inputFile2 = sprintf(\"%%s/selectedAcquisitionsSpatialRepartition.txt\", workingDir)\n") ;
        fprintf(outputFile->f, "inputFile3 = sprintf(\"%%s/selectedPairsListing.txt\", workingDir)\n\n") ;
        fprintf(outputFile->f, "# Set output file:\n") ;
        fprintf(outputFile->f, "outputFile = sprintf(\"%%s/imageSpatialLocalization%%s.png\", workingDir, filenameSuffix)\n") ;
        fprintf(outputFile->f, "set output outputFile\n\n") ;
        fprintf(outputFile->f, "set terminal png size 1280, 720 #transparent truecolor\n\n") ;
        fprintf(outputFile->f, "# Constants:\n") ;
        fprintf(outputFile->f, "xShift = %8.2lf\n", xShift) ;
        fprintf(outputFile->f, "yShift = %8.2lf\n", yShift) ;
        if (BpMax && DTMax) {
            fprintf(outputFile->f, "BpShift = %8.2lf\n\n", BpShift) ;
        }
        else {
            fprintf(outputFile->f, "BpShift = %8.2lf\n\n", 0.) ;
        }
        fprintf(outputFile->f, "superMasterDate = %d\n", superMasterDate0) ;
        fprintf(outputFile->f, "newSuperMasterDate = %d\n", superMasterDate) ;

        fprintf(outputFile->f, "# Settings:\n") ;
        fprintf(outputFile->f, "set style line 1 pointsize 2 pointtype 7\n") ;
        fprintf(outputFile->f, "set xzeroaxis linetype 4 linewidth 2\n") ;
        fprintf(outputFile->f, "set yzeroaxis linetype 4 linewidth 2\n") ;
        fprintf(outputFile->f, "set style circle radius screen 0.004\n") ;
        fprintf(outputFile->f, "set style fill transparent solid 0.5 noborder\n") ;
        fprintf(outputFile->f, "set autoscale xfix\n") ;
        fprintf(outputFile->f, "set offsets graph 0.05, graph 0.05\n") ;
        fprintf(outputFile->f, "set key  left tmargin  box title \"Acquisitions spatial repartition\"\n") ;
        fprintf(outputFile->f, "set label at xShift, yShift \"\" point pointtype 69 pointsize 4 linecolor rgb \"red\" linewidth 2\n") ;
        fprintf(outputFile->f, "plot \\\n") ;
        fprintf(outputFile->f, "inputFile1 using 2:3 with points ls 1 notitle, \\\n") ;
        fprintf(outputFile->f, "inputFile1 using 2:3:1 with labels rotate by 15 offset screen 0.03,0.03 font \"Times,10\" notitle, \\\n") ;
        fprintf(outputFile->f, "inputFile2 using 2:3 with points pointsize 1 pointtype 4 notitle, \\\n") ;
        fprintf(outputFile->f, "inputFile3 using ($3 + xShift):($4 + yShift):($5 - $3):($6 - $4) with vectors notitle \n\n") ;
//       fprintf(outputFile->f, "inputFile3 using ($3):($4):($5 - $3):($6 - $4) with vectors notitle \n\n") ;

        fprintf(outputFile->f, "\n# Second plot settings:\n") ;
        fprintf(outputFile->f, "\noutputFile = sprintf(\"%%s/baselinePlot%%s.png\", workingDir, filenameSuffix)\n") ;
        fprintf(outputFile->f, "set output outputFile\n\n") ;
        fprintf(outputFile->f, "\n# Defining title\n") ;
        if (BpMax && DTMax) {
            anInt = (int)round(BpMax) ;
            fprintf(outputFile->f, "BpMax = %d\n", anInt) ;
            fprintf(outputFile->f, "BTMax = %d\n\n", DTMax) ;        
            fprintf(outputFile->f, "theTitle = sprintf(\"Baseline plot of selected data\\nBp Max = %%d        BT Max = %%d\\nSuper Master date: %%d\", BpMax, BTMax, newSuperMasterDate)\n") ;
        }
        else {
            fprintf(outputFile->f, "theTitle = sprintf(\"Baseline plot of selected data - All pairs considered\\nSuper Master date: %%d\", superMasterDate)\n") ;
        }
        fprintf(outputFile->f, "set key left tmargin  box title theTitle\n") ;
        fprintf(outputFile->f, "timeFormat = \"%%Y%%m%%d\"\n") ;
        fprintf(outputFile->f, "timeString(n) = sprintf(\"%%d\", n)\n") ;
        fprintf(outputFile->f, "set xdata time\n") ;
        fprintf(outputFile->f, "set timefmt timeFormat\n") ;
        fprintf(outputFile->f, "set format x \"%%d/%%m\\n%%Y\"\n") ;
        fprintf(outputFile->f, "set grid\n") ;
        fprintf(outputFile->f, "set style fill transparent solid 0.4 noborder\n") ;
        fprintf(outputFile->f, "set key left\n") ;
        fprintf(outputFile->f, "set arrow 1 from strptime(timeFormat, timeString(superMasterDate)), graph 0 to strptime(timeFormat, timeString(superMasterDate)), graph 1 lt 4 lw 2 nohead\n") ;
        fprintf(outputFile->f, "plot \\\n") ;
        fprintf(outputFile->f, "inputFile0 using 1:($7 - 2 * BpShift) with circles fillcolor \"red\" notitle, \\\n") ;
        fprintf(outputFile->f, "inputFile0 using 2:($7 + $8 - 2 * BpShift) with circles fillcolor \"red\" notitle, \\\n") ;
        fprintf(outputFile->f, "inputFile3 using 1:($7 - BpShift):(strptime(timeFormat, timeString($2)) - strptime(timeFormat, timeString($1))):8 with vectors linewidth 1 linecolor rgb \"#3050A0\"notitle \n\n") ;
        closeRawFile(outputFile) ;
        sprintf(aCommand, "gnuplot %s", outputFile->accessPath) ;
        printf("\t---> Generating plots.\n") ;
        system(aCommand) ;

        freeRawFileDescriptor(outputFile) ;       
//    }
}
