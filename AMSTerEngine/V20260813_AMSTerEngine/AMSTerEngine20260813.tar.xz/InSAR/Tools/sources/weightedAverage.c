
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  weigthedAverage.c
//  bestPlaneRemoval
//
//  Created by Dominique Derauw on 6/01/16.
//  Copyright (c) 2016 Dominique Derauw. All rights reserved.
//

#include <stdio.h>

#include <stdio.h>
#include "pourtous.h"
#include "vectors.h"
#include "matrix.h"
#include "resmat.h"
#include "fileAccessLib.h"
#include "rawFileLib.h"
#include "paramLib.h"

void usage() ;
void createParameterFileAtPath(char *aPath) ;

int main (int argc, const char * argv[])
{
    char *aPath, withWeightFile1, withWeightFile2 ;
    char gammaCorrection ;
    int	xDim, yDim ;
    int iX, iY ;
    float **image1, **image2, **weight1 = NULL, **weight2 = NULL ;
    float excludingValue, globalWeight1, globalWeight2, threshold1, threshold2 ;
    float w1, w2, avg ;
    float gamma1, gamma2 ;
    rawFileDescriptor *file1, *file2, *weightFile1 = NULL, *weightFile2 = NULL, *resultFile ;
    keyValue *pFile ;
    
    if(argc == 1) usage() ;
    aPath = (char *)argv[1] ;
    if(isArgumentPresent(argc, argv, "-create"))
        createParameterFileAtPath(aPath) ;
    
    /* Read parameter file */
    pFile = readParameterFileAtPath(aPath) ;
    
    gammaCorrection = isArgumentPresent(argc, argv, "-g") ;
    
    /* Read file 1 */
    if((file1 = openRawFileForReadingAtPath(getStringValForKeyIn(pFile, "File 1"))) == NULL)
        ase ("Failed to open input file 1 for reading\n") ;
    xDim = file1->xDim = getIntValForKeyIn(pFile, "X dimension of files") ;
    yDim = file1->yDim = getIntValForKeyIn(pFile, "Y dimension of files") ;
    if(file1->fileLength != file1->xDim * file1->yDim * sizeof(float))
        ase("Input file 1 has wrong dimensions") ;
    
    image1 = matrixFloat(0, file1->yDim - 1, 0, file1->xDim - 1) ;
    if(fread(image1[0], sizeof(float), file1->xDim * file1->yDim, file1->f) != file1->xDim * file1->yDim)
        ase("Failed to read weight file 1\n") ;
    
    /* Read weight or weight file 1 */
    withWeightFile1 = threshold1 = globalWeight1 = 0 ;
    aPath = getStringValForKeyIn(pFile, "Weight file 1") ;
    if (fileExistsAtPath(aPath)) {
        if((weightFile1 = openRawFileForReadingAtPath(getStringValForKeyIn(pFile, "Weight file 1"))) == NULL)
            ase ("Failed to open input weight file 1 for reading\n") ;
        weightFile1->xDim = xDim ;
        weightFile1->yDim = yDim ;
        if(weightFile1->fileLength != weightFile1->xDim * weightFile1->yDim * sizeof(float))
            ase("Input file has wrong dimensions") ;
        
        weight1 = matrixFloat(0, weightFile1->yDim - 1, 0, weightFile1->xDim - 1) ;
        if(fread(weight1[0], sizeof(float), weightFile1->xDim * weightFile1->yDim, weightFile1->f) != weightFile1->xDim * weightFile1->yDim)
            ase("Failed to read weight file 1\n") ;
        
        threshold1 = getFloatValForKeyIn(pFile, "Threshold 1") ;
        withWeightFile1 = 1 ;
    }
    else {
        globalWeight1 = getFloatValForKeyIn(pFile, "Weight 1") ;
    }
    
    /* Read file 2 */
    if((file2 = openRawFileForReadingAtPath(getStringValForKeyIn(pFile, "File 2"))) == NULL)
        ase ("Failed to open input file 1 for reading\n") ;
    file2->xDim = xDim ;
    file2->yDim = yDim ;
    if(file2->fileLength != file2->xDim * file2->yDim * sizeof(float))
        ase("Input file 1 has wrong dimensions") ;
    
    image2 = matrixFloat(0, file2->yDim - 1, 0, file2->xDim - 1) ;
    if(fread(image2[0], sizeof(float), file2->xDim * file2->yDim, file2->f) != file2->xDim * file2->yDim)
        ase("Failed to read weight file 2\n") ;
    
    /* Read weight or weight file 1 */
    withWeightFile2 = threshold2 = globalWeight2 = 0 ;
    aPath = getStringValForKeyIn(pFile, "Weight file 2") ;
    if (fileExistsAtPath(aPath)) {
        if((weightFile2 = openRawFileForReadingAtPath(getStringValForKeyIn(pFile, "Weight file 2"))) == NULL)
            ase ("Failed to open input weight file 2 for reading\n") ;
        weightFile2->xDim = xDim ;
        weightFile2->yDim = yDim ;
        if(weightFile2->fileLength != weightFile2->xDim * weightFile2->yDim * sizeof(float))
            ase("Input file has wrong dimensions") ;
        
        weight2 = matrixFloat(0, weightFile2->yDim - 1, 0, weightFile2->xDim - 1) ;
        if(fread(weight2[0], sizeof(float), weightFile2->xDim * weightFile2->yDim, weightFile2->f) != weightFile2->xDim * weightFile2->yDim)
            ase("Failed to read weight file 1\n") ;
        
        threshold2 = getFloatValForKeyIn(pFile, "Threshold 2") ;
        withWeightFile2 = 1 ;
    }
    else {
        globalWeight2 = getFloatValForKeyIn(pFile, "Weight 2") ;
    }
    
    if(!(excludingValue = getFloatValForKeyIn(pFile, "Excluding value")))
        excludingValue = -9999 ;
    
    gamma1 = (float)(logf((1 - threshold1)/2.) / logf((1 + threshold1)/2.)) ;
    gamma2 = (float)(logf((1 - threshold2)/2.) / logf((1 + threshold2)/2.)) ;
    for (iY = 0; iY < yDim; iY++) {
        for (iX = 0; iX < xDim; iX++) {
            w1 = (withWeightFile1)? weight1[iY][iX] : globalWeight1 ;
            w2 = (withWeightFile2)? weight2[iY][iX] : globalWeight2 ;
            if (gammaCorrection) {
                w1 = (withWeightFile1)? powf(weight1[iY][iX], gamma1) : powf(globalWeight1, gamma1) ;
                w2 = (withWeightFile2)? powf(weight2[iY][iX], gamma2) : powf(globalWeight2, gamma2) ;
            }
            else {
                w1 = (w1 > threshold1)? (w1 - threshold1) / (1. - threshold1) : 0 ;
                w2 = (w2 > threshold2)? (w2 - threshold2) / (1. - threshold2) : 0 ;
            }
            
            avg = (w1 * image1[iY][iX] + w2 * image2[iY][iX]) / (w1 + w2) ;
            
            if (isnan(image1[iY][iX])) {
                avg = image2[iY][iX] ;
            }
            if (isnan(image2[iY][iX])) {
                avg = image1[iY][iX] ;
            }
            
            image1[iY][iX] = avg ;
        }
    }
    
    
    sprintf(accessPath, "%s.wAvg", file1->accessPath) ;
    if((resultFile =  openRawFileForWritingAtPath(accessPath)) == NULL)
        ase ("Failed to open result file for writing\n") ;
    if(fwrite(image1[0], sizeof(float), xDim * yDim, resultFile->f) != xDim * yDim)
        ase("Failed to write result file\n") ;
    
    
    freeMatrixFloat(image1, 0, 0) ;
    if (withWeightFile1) {
        freeMatrixFloat(weight1, 0, 0) ;
    }
    
    freeMatrixFloat(image2, 0, 0) ;
    if (withWeightFile2) {
        freeMatrixFloat(weight2, 0, 0) ;
    }
    
    freeKeyValueList(pFile) ;
}

void usage()
{
    printf("weightedAverage computes the weighted average between two files\n") ;
    printf("A global weight or weight file for each files can be given.\n") ;
    printf("Usage : bestPlaneRemoval /pathToParameterFile [-create]\n") ;
    
    exit(0) ;
}

void createParameterFileAtPath(char *aPath)
{
    keyValue *pFile ;
    
    pFile = allocAKeyValuePair() ;
    
    setStringValForKeyIn(pFile, "weightedAverage parameter file", "") ;
    setStringValForKeyIn(pFile, "********************************", "") ;
    setStringValForKeyIn(pFile, "/pathToFile", "File 1") ;
    setStringValForKeyIn(pFile, "/pathToFile", "Weight file 1") ;
    setStringValForKeyIn(pFile, "0", "Threshold 1") ;
    setStringValForKeyIn(pFile, "1.", "Weight 1 (used if no weight file is given)") ;
    setStringValForKeyIn(pFile, "", "") ;
    setStringValForKeyIn(pFile, "/pathToFile", "File 2") ;
    setStringValForKeyIn(pFile, "/pathToFile", "Weight file 2") ;
    setStringValForKeyIn(pFile, "0", "Threshold 2") ;
    setStringValForKeyIn(pFile, "1.", "Weight 2 (used if no weight file is given)") ;
    setStringValForKeyIn(pFile, "", "") ;
    setStringValForKeyIn(pFile, "1234", "X dimension of files") ;
    setStringValForKeyIn(pFile, "1234", "Y dimension of files") ;
    setStringValForKeyIn(pFile, "Nan", "Excluding value") ;
    
    writeParameterFileAtPath(pFile, aPath) ;
    
    freeKeyValueList(pFile) ;
    
    exit(0) ;
    
}
