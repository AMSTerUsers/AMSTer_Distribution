
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include <stdio.h>
#include "pourtous.h"
#include "complexTypes.h"
#include "vectors.h"
#include "complexCalculus.h"
#include "rawFileLib.h"
#include "fileAccessLib.h"
#include "paramLib.h"

void	usage(void) ;
void createParameterFileAtPath(const char *aPath) ;


int main (int argc, const char * argv[]) {
	char *aString, *inputFilePath, *outputFilePath ;
	int	i, j, k, dX1, dX2, dY1, dY2 ;
	int weight1, weight2, sign1, sign2 ;
	float	*aLignInterf1,*aLignInterf2, *anOutputLine ;
	double	phase ;
	complexFloat	complexValue1, complexValue2 ;
	keyValue *paramList ;
	rawFileDescriptor *interf1, *interf2, *outputFile ;
	
	if(argc == 1 || argc > 3) usage() ;
	if(argc == 3) {
		if(isArgumentPresent(argc, argv, "-create"))
			createParameterFileAtPath(argv[1]) ;
		else usage() ;
	}
	   
	/* Read parameter File */ 
	paramList = readParameterFileAtPath((char *)argv[1]) ;
	
	/* Get input/output file location */
	aString = getStringValForKeyIn(paramList, "Interferogram 1 file path") ;
	inputFilePath = readFirstStringIn(aString) ;
	if((interf1 = openRawFileForReadingAtPath(inputFilePath)) == NULL)
		ase("Failed to open interferogram 1 file for reading") ;
	free(inputFilePath) ;
	
	aString = getStringValForKeyIn(paramList, "Interferogram 2 file path") ;
	inputFilePath = readFirstStringIn(aString) ;
	if((interf2 = openRawFileForReadingAtPath(inputFilePath)) == NULL)
		ase("Failed to open interferogram 2 file for reading") ;;
	free(inputFilePath) ;
	
	aString = getStringValForKeyIn(paramList, "Output file path") ;
	outputFilePath = readFirstStringIn(aString) ;
	if((outputFile = openRawFileForReadingAndWritingAtPath(outputFilePath)) == NULL)
		ase("Failed to open output file for writing") ;;

	/* Get X/Y dimensions */
	aString = getStringValForKeyIn(paramList, "xDim 1") ;
	sscanf(aString, "%d", &(interf1->xDim)) ;
	aString = getStringValForKeyIn(paramList, "yDim 1") ;
	sscanf(aString, "%d", &(interf1->yDim)) ;
	aString = getStringValForKeyIn(paramList, "xDim 2") ;
	sscanf(aString, "%d", &(interf2->xDim)) ;
	aString = getStringValForKeyIn(paramList, "yDim 2") ;
	sscanf(aString, "%d", &(interf2->yDim)) ;
	
    /* Compute shifts between images with respect to centering */
    dX1 = dX2 = dY1 = dY2 = 0 ;
    if (strncmp(getStringValForKeyIn(paramList, "Cen"), "YES", 2) == 0) {
        if (interf1->xDim < interf2->xDim) {
            dX1 = 0 ;
            dX2 = (interf2->xDim - interf1->xDim) / 2 ;
        }
        else {
            dX2 = 0 ;
            dX1 = (interf1->xDim - interf2->xDim) / 2 ;
        }

        if (interf1->yDim < interf2->yDim) {
            dY1 = 0 ;
            dY2 = (interf2->yDim - interf1->yDim) / 2 ;
        }
        else {
            dY2 = 0 ;
            dY1 = (interf1->yDim - interf2->yDim) / 2 ;
        }
    }
    
	outputFile->xDim = (interf1->xDim < interf2->xDim) ? interf1->xDim : interf2->xDim ;
	outputFile->yDim = (interf1->yDim < interf2->yDim) ? interf1->yDim : interf2->yDim ;
	setIntValForKeyIn(paramList, outputFile->xDim, "xDim output interferogram") ;
	setIntValForKeyIn(paramList, outputFile->yDim, "yDim output interferogram") ;

	aLignInterf1 = vectorFloat(0, interf1->xDim - 1 ) ;
	aLignInterf2 = vectorFloat(0, interf2->xDim - 1 ) ;
	anOutputLine = vectorFloat(0, outputFile->xDim - 1 ) ;

	/* Get weights */
	weight1 = getIntValForKeyIn(paramList, "Interferogram 1 weight") ;
	weight2 = getIntValForKeyIn(paramList, "Interferogram 2 weight") ;
	sign1 = (weight1 < 0)? -1 : +1 ;
	sign2 = (weight2 < 0)? -1 : +1 ;
	weight1 *= sign1 ;
	weight2 *= sign2 ;

	fseek(interf1->f, sizeof(float) * interf1->xDim * dY1, SEEK_SET) ;
	fseek(interf2->f, sizeof(float) * interf2->xDim * dY2, SEEK_SET) ;
	for(i = 0; i < outputFile->yDim; i++) {
		fread ((float *)aLignInterf1, interf1->xDim, sizeof(float), interf1->f) ;
		fread ((float *)aLignInterf2, interf2->xDim, sizeof(float), interf2->f) ;
		for(j = 0; j < outputFile->xDim; j++) {
			phase = aLignInterf1[dX1 + j] ;
			complexValue1.r = (float)cos(phase) ;
			complexValue1.i = (float)sin(phase) ;
			for(k = 1; k < weight1; k++) 
				complexValue1 = mC(complexValue1, complexValue1) ;
			complexValue1.i *= sign1 ;
			
			phase = aLignInterf2[dX2 + j] ;
			complexValue2.r = (float)cos(phase) ;
			complexValue2.i = (float)sin(phase) ;
			for(k = 1; k < weight2; k++) 
				complexValue2 = mC(complexValue2, complexValue2) ;
			complexValue1.i *= sign2 ;

			anOutputLine[j] = phiC(mC(complexValue1, complexValue2)) ;
		}
		fwrite ((float *)anOutputLine, outputFile->xDim, sizeof(float), outputFile->f) ;
	}
    return 0;
}

void	usage()
{
	printf("Usage: \ninterferogramsCombination /pathTo/parameterFile [-create]\n\n") ;
	printf("interferogramsCombination computes the combination two interferograms considered as coregistered.\n") ;
	printf("Resulting dimensions will be the intersection of both interferograms.\n");
	printf("An integer weight can be given to each interferogram.\n");
	printf("To substract two interferograms, simply chose +1 and -1 weights\n");
	exit(-1) ;
}

void createParameterFileAtPath(const char *aPath)
{
	keyValue *paramList ;
	
	paramList = allocAKeyValuePair() ;
	setStringValForKeyIn(paramList, "Interferograms combination parameters file", "") ;
	setStringValForKeyIn(paramList, "******************************************", "") ;
	setStringValForKeyIn(paramList, "/pathToFirstInterferogramm", "Interferogram 1 file path") ;
	setIntValForKeyIn(paramList, 1234, "xDim 1") ;
	setIntValForKeyIn(paramList, 1234, "yDim 1") ;
	setIntValForKeyIn(paramList, 1, "Interferogram 1 weight") ;
	setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "/pathToSecondInterferogramm", "Interferogram 2 file path") ;
	setIntValForKeyIn(paramList, 1235, "xDim 2") ;
	setIntValForKeyIn(paramList, 1235, "yDim 2") ;
	setIntValForKeyIn(paramList, 1, "Interferogram 2 weight") ;
	setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "NO", "Centered interferograms") ;
	setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "/outputFilePath", "Output file path") ;
	
	writeParameterFileAtPath(paramList, (char *)aPath) ;
	printf("Parameter file created at indicated path\n") ;
	exit(0) ;
}
