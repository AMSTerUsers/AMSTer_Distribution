
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* bestPlaneRemoval */
//
//  Created by Dominique Derauw 2013.
//  Copyright © 2024 Dominique Derauw - SAREOS. All rights reserved.
//
/* Values used in the linear regression to fit the best plane are derived through box averaging */
/* Both to speed up the process and get a more stable result */
/* */


#include <stdio.h>
#include "pourtous.h"
#include "vectors.h"
#include "matrix.h"
#include "resmat.h"
#include "rawFileLib.h"
#include "fileAccessLib.h"
#include "paramLib.h"

void usage(void) ;
void createParameterFileAtPath(char *aPath) ;

int main (int argc, const char * argv[])
{
	char *aPath, isThresholded, isMasked, noRef, *aString, maskValue ;
    char unsigned **mask ;
    char operator[2], opY, opC ;
	int	xDim, yDim, xDimRef, yDimRef, xDimCoh, yDimCoh, xDimMask, yDimMask, iX0, iY0 ;
	int xDimBloc, yDimBloc, deltaX, deltaY, nBlocX, nBlocY ;
	int i, j, k, l, iX, iY ;
	int	*index, count ;
	float **DEM, **Ref, **coh, zVal, zVal0 ;
    float minCoh, norm, shift ;
    float excludingValue ;
    float *aLine = NULL ;
	double **M, *V, signe ;
	double sigma, mean, aValue ;
	rawFileDescriptor *imageFile, *referenceFile = NULL, *coherenceFile = NULL, *resultFile ;
	rawFileDescriptor *diffRef, *maskFile = NULL ;
    keyValue *pFile ;

	if(argc == 1) usage() ;
	aPath = (char *)argv[1] ;
    if(isArgumentPresent(argc, argv, "-create")) {
        createParameterFileAtPath(aPath) ;
    }

    pFile = readParameterFileAtPath(aPath) ;
	if((imageFile = openRawFileForReadingAndWritingAtPath(getStringValForKeyIn(pFile, "File to be corrected"))) == NULL) {
		ase ("Failed to open input file for reading and writing\n") ;
    }
    xDim = getIntValForKeyIn(pFile, "X dimension of the file to be corrected") ;
    yDim = getIntValForKeyIn(pFile, "Y dimension of the file to be corrected") ;
	if(imageFile->fileLength != xDim * yDim * sizeof(float)) {
		printf("xDim = %d\tyDim =%d\nFilelength = %ld\n", xDim, yDim, imageFile->fileLength) ;
		ase("Input file has wrong dimensions") ;
	}

    noRef = 0 ;
    aPath = getStringValForKeyIn(pFile, "Reference file") ;
    if (!fileExistsAtPath(aPath)) {
        noRef = 1 ;
    }
    else {
        if((referenceFile = openRawFileForReadingAndWritingAtPath(aPath)) == NULL) {
            ase ("Failed to open input file for reading and writing\n") ;
        }
        xDimRef = getIntValForKeyIn(pFile, "X dimension of reference file") ;
        yDimRef = getIntValForKeyIn(pFile, "Y dimension of reference file") ;
        if(referenceFile->fileLength != xDimRef * yDimRef * sizeof(float)) {
            ase("Reference file has wrong dimensions") ;
        }
    }

    isThresholded = 0 ;
    if ((coherenceFile = openRawFileForReadingAndWritingAtPath(getStringValForKeyIn(pFile, "Threshold file"))) != NULL) {
        minCoh = getFloatValForKeyIn(pFile, "Threshold value") ;
        if (isThresholded = !!(minCoh)) {
            printf("Thresholding at %f\n", minCoh) ;
            xDimCoh = getIntValForKeyIn(pFile, "X dimension of the threshold file") ;
            yDimCoh = getIntValForKeyIn(pFile, "Y dimension of the threshold file") ;
            if(coherenceFile->fileLength != xDimCoh * yDimCoh * sizeof(float)) {
                ase("Threshold file has wrong dimensions") ;
            }
        }
    }

    isMasked = 0 ;
    if ((maskFile = openRawFileForReadingAndWritingAtPath(getStringValForKeyIn(pFile, "Mask file"))) != NULL) {
        isMasked = 1 ;
        maskValue = getCharValForKeyIn(pFile, "Masking value") ;
        xDimMask = getIntValForKeyIn(pFile, "X dimension of the mask file") ;
        yDimMask = getIntValForKeyIn(pFile, "Y dimension of the mask file") ;
        if(maskFile->fileLength != xDimMask * yDimMask) {
            ase("Threshold file has wrong dimensions") ;
        }
    }
    

    /* Read Excluding value */
    genFloatNaN() ;
    excludingValue = floatNaN ;
    aString = getStringValForKeyIn(pFile, "Excluding value") ;
    if (plError != KEY_VALUE_NOT_FOUND) {
        convertStringToLowercase(aString) ;
        if (strncmp(aString, "nan", 3)) {
            excludingValue = getFloatValForKeyIn(pFile, "Excluding value") ;
        }
    }
        


	DEM = matrixFloat(0, yDim - 1, 0, xDim - 1) ;
	if(fread(DEM[0], sizeof(float), xDim * yDim, imageFile->f) != xDim * yDim)
		ase("Failed to read input file\n") ;

    if (!noRef) {
        Ref = matrixFloat(0, yDim - 1, 0, xDim - 1) ;
        if (xDim == xDimRef && yDim == yDimRef) {
            if(fread(Ref[0], sizeof(float), xDim * yDim, referenceFile->f) != xDim * yDim)
                ase("Failed to read input file\n") ;
        }
        else {
            iX0 = (xDimRef - xDim) / 2 ;
            iY0 = (yDimRef - yDim) / 2 ;
            if (iX0 < 0 || iY0 < 0) {
                ase("Almost one of the dimension of the reference file is smaller than the ones of the file to be corrected\n") ;
            }
            printf("File to be corrected considered as centred with respect to reference file\n") ;
            for (j = 0; j < yDim; j++) {
                fseek(referenceFile->f, ((iY0 + j) * xDimRef + iX0) * sizeof(float), SEEK_SET) ;
                if(fread(Ref[j], sizeof(float), xDim, referenceFile->f) != xDim)
                    ase("Failed to read input file\n") ;
            }
        }
    }

    if (isThresholded) {
        coh = matrixFloat(0, yDim - 1, 0, xDim - 1) ;
        if (xDim == xDimCoh && yDim == yDimCoh) {
            if(fread(coh[0], sizeof(float), xDim * yDim, coherenceFile->f) != xDim * yDim)
                ase("Failed to read input file\n") ;
        }
        else {
            iX0 = (xDimCoh - xDim) / 2 ;
            iY0 = (yDimCoh - yDim) / 2 ;
            for (j = 0; j < yDim; j++) {
                fseek(coherenceFile->f, ((iY0 + j) * xDimCoh + iX0) * sizeof(float), SEEK_SET) ;
                if(fread(coh[j], sizeof(float), xDim, coherenceFile->f) != xDim)
                    ase("Failed to read input file\n") ;
            }
        }
    }

    if (isMasked) {
        mask = matrixUChar(0, yDim - 1, 0, xDim - 1) ;
        if (xDim == xDimMask && yDim == yDimMask) {
            if(fread(mask[0], 1, xDim * yDim, maskFile->f) != xDim * yDim)
                ase("Failed to read input file\n") ;
        }
        else {
            iX0 = (xDimMask - xDim) / 2 ;
            iY0 = (yDimMask - yDim) / 2 ;
            for (j = 0; j < yDim; j++) {
                fseek(maskFile->f, ((iY0 + j) * xDimMask + iX0) * sizeof(float), SEEK_SET) ;
                if(fread(mask[j], sizeof(float), xDim, maskFile->f) != xDim)
                    ase("Failed to read input file\n") ;
            }
        }
    }

	index = vectorInt(1, 3) ;
    M = matrixDouble(1, 3, 1, 3) ;
    V = vectorDouble(1, 3) ;

	for(i = 1; i <= 3; i++) {
		for(j = 1; j <= 3; j++) {
			M[i][j] = 0.0 ;
		}
		V[i] = 0.0 ;
	}

	xDimBloc = yDimBloc = 41 ;
	do {
		xDimBloc = xDimBloc / 2 + 1 ;
		nBlocX = xDim / xDimBloc ;
	} while(nBlocX <= 1) ;

	do {
		yDimBloc = yDimBloc / 2 + 1 ;
		nBlocY = yDim / yDimBloc ;
	} while(nBlocY <= 1) ;

	deltaX = (xDim - nBlocX * xDimBloc)/(nBlocX - 1) ;
	deltaY = (yDim - nBlocY * yDimBloc)/(nBlocY - 1) ;
	iX0 = (deltaX)? 0 : (xDim - nBlocX * xDimBloc) / 2 ;
	iY0 = (deltaY)? 0 : (yDim - nBlocY * yDimBloc) / 2 ;

	for(i = 0; i < nBlocY; i++) {
		iY = i * (yDimBloc + deltaY) + yDimBloc/2 + iY0 ;
		for(j = 0; j < nBlocX; j++) {
			iX = j * (xDimBloc + deltaX) + xDimBloc/2 + iX0 ;
			zVal = norm = 0. ;
			for(k = -yDimBloc/2; k <= yDimBloc/2; k++) {
				for(l = -xDimBloc/2; l <= xDimBloc/2; l++) {
                    if (!areFloatValsEquals(DEM[iY + k][iX + l], excludingValue) &&
                        !(isThresholded && (coh[iY + k][iX + l] < minCoh)) &&
                        !(isMasked && (mask[iY + k][iX + l] & 0b00000101))) {
                        if (noRef) {
                            zVal0 = DEM[iY + k][iX + l] ;
							norm++ ;
						}
                        else {
							if (!areFloatValsEquals(Ref[iY + k][iX + l], excludingValue)) {
								zVal0 = DEM[iY + k][iX + l] - Ref[iY + k][iX + l] ;
								norm++ ;
							}
						}
                       zVal += zVal0 ;
                    }
				}
			}
            if (norm) {
                zVal /= norm ;

                M[1][1] += pow((double)iX, 2.) ;
                M[1][2] += iX * iY ;
                M[1][3] += iX ;
                M[2][2] += pow((double)iY, 2.) ;
                M[2][3] += iY ;
                M[3][3]++ ;

                V[1] += iX * zVal ;
                V[2] += iY * zVal ;
                V[3] += zVal ;
            }
		}
	}
	for(i = 1; i <= 3; i++) {
		for(j = i + 1; j <= 3; j++) {
			M[j][i] = M[i][j] ;
		}
	}
	ludcmp(M, 3, index, &signe) ;
	lubksb(M, 3, index, V) ;

    if(!noRef && isFlagPresent(argc, argv, "-d")) {
		sprintf(accessPath, "%s.diffRef", imageFile->accessPath) ;
		if((diffRef =  openRawFileForWritingAtPath(accessPath)) == NULL) {
			ase ("Failed to open diffRef file for writing\n") ;
		}
		aLine = vectorFloat(0, xDim - 1) ;
	}
	
    shift = getFloatValForKeyIn(pFile, "Shift") ;
    V[3] -= shift ;

    operator[0] = '+' ;
    operator[1] = '\0' ;
    opY = (V[2] > 0)? 0 : 1 ;
    opC = (V[3] > 0)? 0 : 1 ;
	printf("Removed plane: %g X %c %g Y %c %g\n", V[1], operator[opY], V[2], operator[opC], V[3]);
	sigma = mean = 0.0 ;
	count = 0 ;
	for(iY = 0; iY < yDim; iY++) {
		for(iX = 0; iX < xDim; iX++) {
			DEM[iY][iX] -= (float)(V[1] * iX + V[2] * iY + V[3]) ;
			if(aLine) {
				aLine[iX] = excludingValue ;
			}
			if (!noRef && !areFloatValsEquals(DEM[iY][iX], excludingValue) && !areFloatValsEquals(Ref[iY][iX], excludingValue)) {
				count ++ ;
				aValue = DEM[iY][iX] - Ref[iY][iX] ;
				if(aLine) {
					aLine[iX] = aValue ;
				}
				mean += aValue ;
				sigma += pow(aValue, 2) ;
			}
		}
		if(aLine) {
			if(fwrite(aLine, sizeof(float), xDim, diffRef->f) != xDim) {
				ase("Failed to write diffRef file\n") ;
			}
		}
	}
	if (!noRef) {
		sigma /= count ; 
		mean /= count ; 
		sigma = sqrt(sigma - pow(mean, 2)) ;
		printf("sigma_ref = %lf\n", sigma) ; 
	}
	
	sprintf(accessPath, "%s.flattened", imageFile->accessPath) ;
	if((resultFile =  openRawFileForWritingAtPath(accessPath)) == NULL) {
		ase ("Failed to open result file for writing\n") ;
    }
	if(fwrite(DEM[0], sizeof(float), xDim * yDim, resultFile->f) != xDim * yDim) {
		ase("Failed to write result file\n") ;
    }


	freeMatrixFloat(DEM, 0, 0) ;
    if (!noRef) {
        freeMatrixFloat(Ref, 0, 0) ;

    }
    if (isThresholded) {
        freeMatrixFloat(coh, 0, 0) ;
    }
    
    if (aLine) {
		freeVectorFloat(aLine, 0) ;
		freeRawFileDescriptor(diffRef) ;
	}
	
	freeMatrixDouble(M, 1, 1) ;
	freeVectorDouble(V, 1) ;
    freeKeyValueList(pFile) ;
}

void usage()
{
	printf("Usage : bestPlaneRemoval /pathToParameterFile [-create]\n\n") ;
	printf("bestPlaneRemoval2 removes the best plane component from \nan image coded in float with respect to a reference one\n") ;
    printf("The plane is computed in the difference between the reference file and the file to be corrected for\n") ;
    printf("If no reference file is given or if does not exists,\nthe best plane is computed and removed from the input file to be corrected\n") ;
    printf("An additional float file may be added to be used as threshold mask \nbetween 0 and 1 to only take into account points above a given threshold\n") ;
    printf("A binary mask file can be given to restrict computation on non masked areas. \nMask value is given as a binary value to select the mask(s) to be used.\n\n") ;
    printf("Input files can have different size, in which case the file to be corrected is the smallest and is considered as centered with respect to the other files. \n") ;

	exit(0) ;
}

void createParameterFileAtPath(char *aPath)
{
    keyValue *pFile ;

    pFile = allocAKeyValuePair() ;

    setStringValForKeyIn(pFile, "bestPlaneRemoval2 parameter file", "") ;
    setStringValForKeyIn(pFile, "********************************", "") ;
    setStringValForKeyIn(pFile, "/pathToFile", "File to be corrected") ;
    setStringValForKeyIn(pFile, "1234", "X dimension of the file to be corrected") ;
    setStringValForKeyIn(pFile, "1234", "Y dimension of the file to be corrected") ;
    setStringValForKeyIn(pFile, "NaN", "Excluding value") ;
    setStringValForKeyIn(pFile, "", "") ;
    setStringValForKeyIn(pFile, "/pathToFile", "Reference file path") ;
    setStringValForKeyIn(pFile, "1234", "X dimension of reference file") ;
    setStringValForKeyIn(pFile, "1234", "Y dimension of reference file") ;
    setStringValForKeyIn(pFile, "", "") ;
    setStringValForKeyIn(pFile, "/pathToFile", "Threshold file") ;
    setStringValForKeyIn(pFile, "1234", "X dimension of the threshold file") ;
    setStringValForKeyIn(pFile, "1234", "Y dimension of the threshold file") ;
    setStringValForKeyIn(pFile, "0.6", "Threshold value") ;
    setStringValForKeyIn(pFile, "", "") ;
   setStringValForKeyIn(pFile, "/pathToFile", "Mask file") ;
    setStringValForKeyIn(pFile, "1234", "X dimension of the mask file") ;
    setStringValForKeyIn(pFile, "1234", "Y dimension of the mask file") ;
    setStringValForKeyIn(pFile, "0b00000101", "Masking value") ;
    setStringValForKeyIn(pFile, "", "") ;
    setStringValForKeyIn(pFile, "0.", "Shift value") ;

    writeParameterFileAtPath(pFile, aPath) ;

    freeKeyValueList(pFile) ;

    exit(0) ;

}

