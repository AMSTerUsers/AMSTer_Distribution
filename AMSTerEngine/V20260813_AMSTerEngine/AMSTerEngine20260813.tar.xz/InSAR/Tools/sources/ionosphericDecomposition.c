
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  ionosphericDecomposition
//
//  Created by Dominique Derauw on 26/03/2018.
//  Copyright © 2018 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "paramLib.h"
#include "paramInSAR.h"
#include "rawFileManipulation.h"

void usage(void) ;


int main(int argc, const char * argv[]) {
    char *LFInSARPath, *HFInSARPath ;
    char *dispersiveComponentPath, *nonDispersiveComponentPath, *tempFilePath ;
    double f0, fL, fH ;
    float fHf0Ratio, fLf0Ratio ;
    float dispersiveCoef, nonDispersiveCoef ;
    InSARParametersStruct *LFpInSAR, *HFpInSAR ;
    time_t startTime, endTime ;

    if(argc < 3)
        usage() ;
    
    /* Let's go */
    time(&startTime) ;

    /* Locate low and high frequency InSAR processings */
    LFInSARPath = initStringWith2Strings((char *)argv[1], "/TextFiles/InSARParameters.txt") ;
    HFInSARPath = initStringWith2Strings((char *)argv[2], "/TextFiles/InSARParameters.txt") ;
    LFpInSAR = readInSARParametersFileAtPath(LFInSARPath) ;
    HFpInSAR = readInSARParametersFileAtPath(HFInSARPath) ;
    openUnwrappedPhaseFile(LFpInSAR) ;
    openUnwrappedPhaseFile(HFpInSAR) ;
    
    dispersiveComponentPath = initStringWith2Strings((char *)argv[1], "/InSARProducts/dispersivePhaseComponent") ;
    nonDispersiveComponentPath = initStringWith2Strings((char *)argv[1], "/InSARProducts/nonDispersivePhaseComponent") ;
    tempFilePath = initStringWith2Strings((char *)argv[1], "/InSARProducts/tempFile") ;

    fL = LFpInSAR->masterInfo->radarCarrierFrequency ;
    fH = HFpInSAR->masterInfo->radarCarrierFrequency ;
    f0 = (fL + fH) / 2 ;
    fLf0Ratio = (float)(fL / f0) ;
    fHf0Ratio = (float)(fH / f0) ;

    dispersiveCoef = (float)(1. / (fH / fL - fL / fH)) ;
    nonDispersiveCoef = (float)(1. / (pow(fH / f0, 2.)  - pow(fL / f0, 2.))) ;
    
    floatFilesArithmetics(LFpInSAR->unwrappedPhaseFile->accessPath, "x", fHf0Ratio, NULL, dispersiveComponentPath) ;
    floatFilesArithmetics(HFpInSAR->unwrappedPhaseFile->accessPath, "x", fLf0Ratio, NULL, tempFilePath) ;
    floatFilesArithmetics(dispersiveComponentPath, "-", 0, tempFilePath, NULL) ;
    floatFilesArithmetics(dispersiveComponentPath, "x", dispersiveCoef, NULL, NULL) ;
    if (isFlagPresent(argc, argv, "w")) {
        wrapFloatFile(dispersiveComponentPath, NULL) ;
    }
    
    floatFilesArithmetics(HFpInSAR->unwrappedPhaseFile->accessPath, "x", fHf0Ratio, NULL, nonDispersiveComponentPath) ;
    floatFilesArithmetics(LFpInSAR->unwrappedPhaseFile->accessPath, "x", fLf0Ratio, NULL, tempFilePath) ;
    floatFilesArithmetics(nonDispersiveComponentPath, "-", 0, tempFilePath, NULL) ;
    floatFilesArithmetics(nonDispersiveComponentPath, "x", nonDispersiveCoef, NULL, NULL) ;
    if (isFlagPresent(argc, argv, "w")) {
        wrapFloatFile(nonDispersiveComponentPath, NULL) ;
    }

    unlink(tempFilePath) ;
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    return 0;
}


void usage()
{
    printf("\nionosphericDecomposition \n") ;
    printf("Starting from a Low Frequency and a High Frequency InSAR processing, \nthe routine will compute a dispersive and a non dispersive component of the phase. \n\n") ;
    printf("usage: \n") ;
    printf("ionosphericDecomposition LFInSARPath HFInSARPath [-w] \n") ;
    printf("LFInSARPath and HFInSARpath are the path to Low Frequency and High Frequency InSAR processings. \n") ;
    printf("-w : If using this option, dispersive and non dispersive phase components are re-wrapped. \n\n") ;
    exit(0) ;
}
