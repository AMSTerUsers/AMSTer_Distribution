
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  updateS1Orbits
//
//  Created by Dominique Derauw on 24/11/16.
//  Rebuild from scrach in 2020 due to ESA server changes.
//  Copyright © 2020 Dominique Derauw -SAREOS. All rights reserved.
//
//

#include <stdio.h>
#include <stdlib.h>
#include "pourtous.h"
#include "paramLib.h"
#include "basicXMLHandlingLib.h"
#include "COPERNICUSAccessLib.h"

keyValue *updateS1OrbitsOfType(char *orbitType, char *localS1OrbitsDirectory, char *lastAvailableDate, char *toDate, CSVStruct *credentials) ;
char *cleanPreciseOrbitDir(char *localS1OrbitsDirectory) ;
void usage() ;
CSVStruct *getASFWebList(char *orbitType, char *localS1OrbitsDirectory, char *lastAvailableDate) ;
CSVStruct *getESAWebList(char *orbitType, char *localS1OrbitsDirectory, char *fromDate, char *toDate, CSVStruct **dataID, CSVStruct **dataSize) ;


int main(int argc, const char * argv[]) {
    char *S1_ORBDir = NULL, *aPath ;
    char *lastAvailableDate = NULL ;
    char lastPreciseOrbiteDate[10], *toDate = NULL ;
    char test = 0 ;
    int i, numberOfAddedFiles ;
    keyValue *output ;
    time_t aTimeVal ;
    struct tm *aTimeStruct ;
    CSVStruct *credentials = NULL ;

    if (!argc || isFlagPresent(argc, argv, "h") || isArgumentPresent(argc, argv, "-help")) {
        usage() ;
    }
    
    i = 1 ;
    while (i < argc){
        if (isDir((char *)argv[i])) {
            S1_ORBDir = initStringWithString((char *)argv[i]) ;
            i = argc ;
        }
        i++ ;
    }
    if (!S1_ORBDir) {
        if ((S1_ORBDir = initStringWithString(getenv("S1_ORBITS_DIR"))) == NULL) {
            usage() ;
        }
    }

    if (!isArgumentPresent(argc, argv, "-ASF")) {
        credentials = getCopernicusCredentials() ;
    }
    
    if ((i = isArgumentPresent(argc, argv, "from="))) {
        lastAvailableDate = initStringWithString((char *)(argv[i] + 5)) ;
        test = 1 ;
    }
    
    
    if (!isDir(S1_ORBDir)) {
        printf("Invalid S1 orbits directory\n") ;
        usage() ;
    }
    
    /* Proceed */
    printf("updateS1Orbits is running\n") ;

    if (lastAvailableDate) {
        printf("\t---> Orbit database update/verification will start from date %s\n", lastAvailableDate) ;
    }
    else {
        lastAvailableDate = cleanPreciseOrbitDir(S1_ORBDir) ;
        printf("\t---> Last available date of Precise orbite in local data base is %s\n", lastAvailableDate) ; 
    }

    /* Computing expected time of last available precise orbit */
    aTimeVal = time(NULL) ;
    aTimeStruct = gmtime(&aTimeVal) ;
    aTimeStruct->tm_mday -= 21 ;
    aTimeVal = mktime(aTimeStruct) ;
    sprintf(lastPreciseOrbiteDate, "%4d%02d%02d", 1900 + aTimeStruct->tm_year, aTimeStruct->tm_mon + 1, aTimeStruct->tm_mday) ;

    /* Updating precise orbit directory */
    toDate = addDaysToDate(lastAvailableDate, toDate, 31) ;
    output = updateS1OrbitsOfType("POEORB", S1_ORBDir, lastAvailableDate, toDate, credentials) ;
    numberOfAddedFiles = i = getIntValForKeyIn(output, "Number") ;
    /* If requesting data from COPERNICUS server, we have to work recusrsively since we limited request to one month of orbits to avoid forced connection closure by server */
    if (credentials) {
        while (i || strcmp(toDate, lastPreciseOrbiteDate) < 0) {
            free(lastAvailableDate) ;
            lastAvailableDate = initStringWithString(getStringValForKeyIn(output, "Last")) ;
            toDate = addDaysToDate(lastAvailableDate, toDate, 31) ;

            output = updateS1OrbitsOfType("POEORB", S1_ORBDir, lastAvailableDate, toDate, credentials) ;
            i = getIntValForKeyIn(output, "Number") ;
            numberOfAddedFiles += i ;
       }
    }
    
    if(numberOfAddedFiles)
        printf("\n%d orbit files were added into %s/AUX_POEORB\n\n", numberOfAddedFiles, S1_ORBDir) ;
    else
        printf("\nNo orbit files downloaded. %s is up to date\n\n", S1_ORBDir) ;
    

    if(test) {
        free(lastAvailableDate) ;
        lastAvailableDate = cleanPreciseOrbitDir(S1_ORBDir) ;
    }
    printf("Last PRECISE orbit date available in local data base is now %s\n", lastAvailableDate) ;
    freeKeyValueList(output) ;

    /* Updating restituted orbit directory */
    toDate = addDaysToDate(lastAvailableDate, toDate, 31) ;
    output = updateS1OrbitsOfType("RESORB", S1_ORBDir, lastAvailableDate, toDate, credentials) ;
    numberOfAddedFiles = getIntValForKeyIn(output, "Number") ;
    if(numberOfAddedFiles)
        printf("\n%d orbit files were added into %s/AUX_RESORB\n\n", numberOfAddedFiles, S1_ORBDir) ;
    else
        printf("\nNo orbit files downloaded. %s is up to date\n\n", S1_ORBDir) ;

    free(lastAvailableDate) ;
    freeKeyValueList(output) ;

    aPath = expandEnvironmentVariablesInPath("${HOME}/.CopernicusServerAccess") ;
    if (fileExistsAtPath(aPath)) {
        unlink(aPath) ;
    }
    free(aPath) ;
    free(S1_ORBDir) ;


    return 0;
}

keyValue *updateS1OrbitsOfType(char *orbitType, char *localS1OrbitsDirectory, char *fromDate, char *toDate, CSVStruct *credentials)
{
    char *dirName ;
    char *orbitDir = NULL ;
    char *orbitFilePath = NULL ;
    char **existingOrbitFiles ;
    char *mainServer ;
    char *baseURL = NULL ;
    char *fileURL = NULL ;
    char *command = NULL ;
    char *outputPath = NULL ;
    char textLine[BUFSIZ] ;
    char *orbitFileName ;
    char mustFileBeDownloaded, isPOEORB, downloadOK ;
    int i, j, k, N, numberOfAddedFiles ;
    size_t fileSize ;
    rawFileDescriptor *orbitFile ;
    struct stat st;   
    CSVStruct *webList = NULL, *csv ;
    CSVStruct *tokens ;
    CSVStruct *dataId ;
    CSVStruct *dataSize = NULL ;
    static time_t start = 0, now ;
    keyValue *outputResults ;


    isPOEORB = (!strcmp(orbitType, "POEORB")) ;
    dirName = initStringWith2Strings("AUX_", orbitType) ;

    orbitDir = initStringWith3Strings(localS1OrbitsDirectory, "/", dirName) ;
    if (!isDir(orbitDir)) {
        if(mkdir((const char *)orbitDir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create directory at path %s\n", orbitDir) ;
            ase(ertex) ;
        }
    }
    chdir(orbitDir) ;
    if (!isWriteAccessGrantedAtPath(orbitDir)) {
        ase("\n-/-> Write access denied at output path. Change your access rights before retrying\n") ;
    }


    /* Get local listing of already downloaded orbits */
    existingOrbitFiles = getDirectoryEntriesAtPath(orbitDir) ;
    N = getNumberOfDirectoryEntriesAtPath(orbitDir) ;

    if (!isPOEORB) {
        printf("\n---> RESORB management\n\t---> RESORB directory cleaning: \n") ;
        for (i = 0; i < N ; i++) {

            if (strncmp(existingOrbitFiles[i] + 42, fromDate, 8) < 0) {
                printf("\t---> Removing RESTITUTED orbit now replaced by PRECISE ones\n\t%s\n", existingOrbitFiles[i]) ;
                orbitFilePath = initStringWith3Strings(orbitDir, "/", existingOrbitFiles[i]) ;
                if (unlink(orbitFilePath)) {
                    printf("\t-/-> Failed to remove file...\n") ;
                }
                printf("\n") ;

                free(orbitFilePath) ;
                free(existingOrbitFiles[i]) ;
                for (k = i; k < N - 1; k++) {
                    existingOrbitFiles[k] = existingOrbitFiles[k + 1] ;
                }
                N-- ;
                i-- ;
            }
        }       
    }
    

    /* Get on line orbit listing */
    if(credentials) {
        /* We deal with COPERNICUS servers */
        /* Get Web listing and try to login */
        webList = getESAWebList(orbitType, localS1OrbitsDirectory, fromDate, toDate, &dataId, &dataSize) ;
        if (!start) {
            start = connectToCopernicusServer(credentials) ;
        }
        else {
            now = time(NULL) ;
            /* Normally COPERNICUS connection closes after 600 seconds. Let's take a one minute margin */
            if (now - start > 540) {
                start = refreshConnection(tokens, credentials) ;
                freeCSVStruct(tokens) ;
            }
        }
        
        if((tokens = getCopernicusTokens()) == NULL) {
            /* May be we even pass the one hour delay for repetitive reconection. So let's try a new session */
            start = connectToCopernicusServer(credentials) ;
            if((tokens = getCopernicusTokens()) == NULL) {
                ase("Failed to connect to Copernicus server\n") ;
            }
        }
    }
    else {
        /* We deal with ASF */
        mainServer = initStringWithString("s1qc.asf.alaska.edu/") ;
        convertStringToLowercase(dirName) ;
        baseURL = initStringWith4Strings("https://", mainServer, dirName, "/") ;
        webList = getASFWebList(orbitType, localS1OrbitsDirectory, fromDate) ;
        free(dirName) ;
        free(mainServer) ;
    }

    numberOfAddedFiles = 0 ;
    if (webList) {        
        for (i = 0; i < webList->numberOfEntries ; i++) {
            orbitFileName = initStringWithString(webList->stringVal[i]) ;
            outputPath = initStringWith3Strings(orbitDir, "/", orbitFileName) ;
            
            j = 0 ;        
            mustFileBeDownloaded = 1 ;
            if (N) {
                while (j < N && mustFileBeDownloaded) {
                    mustFileBeDownloaded *= (!strcmp(existingOrbitFiles[j], orbitFileName))? 0 : 1 ;
                    j++ ;
                }
                if (!mustFileBeDownloaded) {
                    free(existingOrbitFiles[j - 1]) ;
                    for (k = j - 1; k < N - 1; k++) {
                        existingOrbitFiles[k] = existingOrbitFiles[k + 1] ;
                    }
                    N-- ;
                }
            }
            mustFileBeDownloaded *= (!isPOEORB && strncmp(orbitFileName + 42, fromDate, 11) < 0)? 0 : 1 ;
            
            if (mustFileBeDownloaded) {
                if (isPOEORB) {
                    if (strncmp(orbitFileName + 42, fromDate, 8) > 0) {
                        memcpy(fromDate, orbitFileName + 42, 8) ;
                    }
                    for (j = 0; j <  N; j++) {
                        if (!strncmp(existingOrbitFiles[j], orbitFileName, 3) && !strncmp(existingOrbitFiles[j] + 42, orbitFileName + 42, 8) && strncmp(existingOrbitFiles[j] + 25, orbitFileName + 25, 15) < 0) {
                            orbitFilePath = initStringWith3Strings(orbitDir, "/", existingOrbitFiles[j]) ;
                            unlink(orbitFilePath) ;
                            free(orbitFilePath) ;
                            printf("\n---> A new Precise orbit is available for date %.8s\n", orbitFileName + 42) ;
                            printf("---> Removing orbit file %s from data base\n", existingOrbitFiles[j]) ;
                            printf("---> It will be replaced by new available one\n") ;
                            free(existingOrbitFiles[j]) ;
                            for (k = j; k < N - 1; k++) {
                                existingOrbitFiles[k] = existingOrbitFiles[k + 1] ;
                            }
                            N-- ;
                        }
                    }
                }
                
                printf("\n---> Downloading orbit file %s\n", orbitFileName) ;
                if (credentials) {
                    csv = addStringValInCSVStruct("curl -H \"Authorization: Bearer ", NULL) ;
                    csv = addStringValInCSVStruct(tokens->stringVal[0], csv) ;
                    csv = addStringValInCSVStruct("\" 'https://catalogue.dataspace.copernicus.eu/odata/v1/Products(", csv) ;
                    csv = addStringValInCSVStruct(dataId->stringVal[i], csv) ;
                    csv = addStringValInCSVStruct(")/$value' --location-trusted --output ", csv) ;
                    csv = addStringValInCSVStruct(outputPath, csv) ;

                    command = getStringFromCSV(csv) ;

                    freeCSVStruct(csv) ;

                    now = time(NULL) ;
                    if (now - start > 540) {
                        start = refreshConnection(tokens, credentials) ;
                        freeCSVStruct(tokens) ;
                        if((tokens = getCopernicusTokens()) == NULL) {
                            ase("Failed to refresh Copernicus server connection.\n") ;
                        } 
                    }
                }
                else {
                    fileURL = initStringWith3Strings(baseURL, "/", orbitFileName) ;
                    command = initStringWith4Strings("stdbuf -o0 curl -# -b ~/.urs_cookies -c ~/.urs_cookies -L -n ", fileURL, " > ", outputPath) ;
                    free(fileURL) ;
                }

//                printf("%s\n", command) ;
                downloadOK = 5 ;
                do {
                    system(command) ;
                    if (!fileExistsAtPath(outputPath)) {
                        printf("\t-/-> No file saved at expected path. Retrying...\n") ;
                        downloadOK -= 2 ;
                    }
                    else {
                        stat(outputPath, &st);
                        if (st.st_size > 25) {
                            orbitFile = openRawFileForReadingAtPath(outputPath) ;
                            if (dataSize) {
                                sscanf(dataSize->stringVal[i], "%ld", &fileSize) ;
                                if (orbitFile->fileLength != fileSize) {
                                    printf("\t-/-> Downloaded file has wrong size. Expected sise is %ld. Downloaded file size is %ld\n", fileSize, orbitFile->fileLength) ;
                                }
                            }
                            fseek(orbitFile->f, -23, SEEK_END) ;
                            fread(textLine, 1, 23, orbitFile->f) ;
                            if (isSubStringPresentInString(textLine, "</Earth_Explorer_File>")) {
                                numberOfAddedFiles++ ;
                                downloadOK = 0 ;
                            }
                            else {
                                printf("\n-/-> Somethings goes wrong. File does not bear the </Earth_Explorer_File> end tag. Retrying....\n") ;
                                downloadOK -= 2 ;
                                unlink(outputPath) ;
                            }
                            freeRawFileDescriptor(orbitFile) ;
                        }
                        else {
                            printf("\n-/-> Somethings goes wrong. Retrying....\n") ;
                            downloadOK -= 2 ;
                        }
                    }
                } while (downloadOK > 0);
                if (downloadOK < 0) {
                    ase("-/-> Too much problems. Better to quit\n\n") ;
                }
                
                free(command) ;
                free(outputPath) ;
                free(orbitFileName) ;
            }
        }
    }

    if (!numberOfAddedFiles) {
        outputResults = setStringValForKeyIn(NULL, toDate, "Last available date") ;
    }
    else {
        outputResults = setStringValForKeyIn(NULL, fromDate, "Last available date") ;
    }
    setIntValForKeyIn(outputResults, numberOfAddedFiles, "Number of added orbits") ;
        
    free(baseURL) ;
    free(orbitDir) ;

    for (i = 0; i < N; i++) {
        free(existingOrbitFiles[i]) ;
    }
    free(existingOrbitFiles) ;    
    freeCSVStruct(webList) ;
    freeCSVStruct(tokens) ;
    
    return (outputResults) ;
}

void usage()
{
    printf("updateS1Orbits [S1_ORBITS_DIR] [-ASF] [from=YYYYMMDD]\n") ;
    printf("Usage:\n") ;
    printf("Performs the update of the local Sentinel1 precise and restituted orbite data base\n") ;
    printf("By defaults, orbits are downloaded from COPERNICUS server using user id and password found in your .netrc file.\n") ;
    printf("If not existing, create a text file containing the following line :\n") ;
    printf("machine identity.dataspace.copernicus.eu login <your COPERNICUS login> password <your password>\n") ;
    printf("and save it in your HOME directory with name .netrc\n\n") ;
    printf("If willing to use ASF server, use the -ASF keyword.\n") ;
    printf("In that case, please, check on \nhttps://wiki.earthdata.nasa.gov/display/EL/How+To+Access+Data+With+cURL+And+Wget\n") ;
    printf("to correctly set your system and provide access to ASF server\n") ;
    printf("\n") ;
    printf("By default, S1 orbit database directory is defined in the S1_ORBITS_DIR environment variable\n") ;
    printf("If not defined or if willing to define another location, it can be provided as parameter.\n") ;
    printf("Provided directory must exists.\n") ;
    printf("Orbits will be stored in ./RESORB and ./POEORB subdirs respectively\n") ;
    printf("Those directories will be created if not existing.\n") ;
    printf("\n") ;
    printf("By default, database updating starts from the last available precise orbit date.\n") ;
    printf("If willing to verify or update the database from an other given date, \nthis one can be given in the form YYYYMMDD using the from= keyword.\n") ;
    printf("\n") ;
    exit(0) ;
}

char *cleanPreciseOrbitDir(char *localS1OrbitsDirectory)
{
    char *preciseOrbitDir ;
    char *lastAvailableDate ;
    char *orbit1, *orbit2 ;
    int i, j ;
    CSVStruct *existingOrbit ;

    /* Get local listing of already downloaded orbits */
    lastAvailableDate = allocStringOfLength(11) ;
    sprintf(lastAvailableDate, "20140401") ;
    printf("\t---> Reading local S1 PRECISE orbit directory\n") ;
    preciseOrbitDir = initStringWith2Strings(localS1OrbitsDirectory, "/AUX_POEORB/") ;
    existingOrbit = recursiveSearchOfFileInDir("_OPER_AUX_POEORB_OPOD_", preciseOrbitDir) ;
    if (existingOrbit) {
        /* Find last available one and remove duplicates */
        printf("\t---> Getting last available date\n") ;
        printf("\t---> Cleaning directory removing duplicates\n") ;
        for (i = 0; i < existingOrbit->numberOfEntries - 1; i++) {
            orbit1 = getPointerToFileNameInPath(existingOrbit->stringVal[i]) ;
            if (strncmp(lastAvailableDate, orbit1 + 42, 8) < 0) {
            memcpy(lastAvailableDate, orbit1 + 42, 8) ;
            }
            for (j = i + 1; j <  existingOrbit->numberOfEntries; j++) {
                orbit2 = getPointerToFileNameInPath(existingOrbit->stringVal[j]) ;
                if (!strncmp(orbit1, orbit2, 3) && !strncmp(orbit1 + 42, orbit2 + 42, 8)) {
                    if (strncmp(orbit1 + 25, orbit2 + 25, 15) < 0) {                        
                        unlink(existingOrbit->stringVal[i]) ;
                        removeStringValAtIndexInCSVStruct(i, existingOrbit) ;
                    }
                    else {
                        unlink(existingOrbit->stringVal[j]) ;
                        removeStringValAtIndexInCSVStruct(j, existingOrbit) ;
                    }
                    i-- ;
                    j = existingOrbit->numberOfEntries ;
                }
            }
        }       

        freeCSVStruct(existingOrbit) ;
    }
    free(preciseOrbitDir) ;

    return (lastAvailableDate) ;
}


CSVStruct *getASFWebList(char *orbitType, char *localS1OrbitsDirectory, char *lastAvailableDate)
{
    char *dirName ;
    char *orbitGenericString ;
    char *orbitDir = NULL ;
    char *mainServer ;
    char *baseURL = NULL ;
    char *listingPath = NULL ;
    char *command = NULL ;
    char textLine[BUFSIZ] ;
    char orbitFileName[_MAX_PATH_LENGTH_] ;
    char isPOEORB ;
    int i, j ;
    int fileNameStartIndex ;
    size_t fileSize ;
    CSVStruct *webList = NULL ;
    rawFileDescriptor *webListFile ;
    struct stat st;   


    isPOEORB = (!strcmp(orbitType, "POEORB")) ;
    dirName = initStringWith2Strings("AUX_", orbitType) ;

    /* Verifying local dir */
    orbitGenericString = initStringWith3Strings("_OPER_", dirName, "_OPOD_") ;
    orbitDir = initStringWith3Strings(localS1OrbitsDirectory, "/", dirName) ;
    chdir(orbitDir) ;

    /* Creating url request */
    printf("\nDownloading %s listing on ASF server\n", dirName) ;
    convertStringToLowercase(dirName) ;
    mainServer = initStringWithString("s1qc.asf.alaska.edu/") ;
    baseURL = initStringWith4Strings("https://", mainServer, dirName, "/") ;
    free(mainServer) ;

    /* Getting ASF directory */
    listingPath = initStringWith2Strings(orbitDir, "/orbitListing.txt") ;
    command = initStringWith4Strings("curl -ks ", baseURL, " > ", listingPath) ;
    system(command) ;

    free(command) ;
    free(orbitDir) ;
    free(dirName) ;
    free(baseURL) ;

    /* Verify all went smoothly */
    stat(listingPath, &st);
    if (!st.st_size) {
        ase("\t-/->\tListing empty...\n\t\tSorry, I have to quit\n\n") ;
    }

    webListFile = openRawFileForReadingAndWritingAtPath(listingPath) ;
    while (fgets(textLine, _MAX_COMMENT_LENGTH_, webListFile->f) != NULL) {
        if ((fileNameStartIndex = locateSubStringInString(textLine, orbitGenericString)) >= 0) {
            fileNameStartIndex -= 3 ;
            memcpy(orbitFileName, textLine + fileNameStartIndex, 77) ;
            orbitFileName[77] = '\0' ;
            if (!strncmp(getPointerToFileExtensionInPath(orbitFileName), "EOF", 3)  && strncmp(lastAvailableDate, orbitFileName + 42, 8) < 0) {
                webList = addStringValInCSVStruct(orbitFileName, webList) ;
//                stripExtensionAtEndOfPath(webList->stringVal[webList->numberOfEntries - 1]) ;
            }
        }
    }
    free(orbitGenericString) ;

    /* Create and clean list of available PRECISE orbits */
    if (webList && isPOEORB) {        
        printf("\t---> Clean PRECISE orbit listing removing duplicates\n") ;
        for (i = 0; i < webList->numberOfEntries - 1; i++) {
            for (j = i + 1; j <  webList->numberOfEntries; j++) {
                if (!strncmp(webList->stringVal[i], webList->stringVal[j], 3) && !strncmp(webList->stringVal[i] + 42, webList->stringVal[j] + 42, 8)) {
                    if (strncmp(webList->stringVal[i] + 25, webList->stringVal[j] + 25, 15) < 0) {                        
                        removeStringValAtIndexInCSVStruct(i, webList) ;
                    }
                    else {
                        removeStringValAtIndexInCSVStruct(j, webList) ;
                    }
                    i-- ;
                    j = webList->numberOfEntries ;
                }
            }
        }
    }

    freeRawFileDescriptor(webListFile) ;
    unlink(listingPath) ;
    free(listingPath) ;

    return (webList) ;
}


CSVStruct *getESAWebList(char *orbitType, char *localS1OrbitsDirectory, char *fromDate, char *toDate, CSVStruct **dataID, CSVStruct **dataSize)
{
    char *dirName, *searchResFile ;
    char *orbitDir = NULL ;
    char *mainServer ;
    char *baseURL = NULL, *queryURL ;
    char startDate[11], stopDate[11], *aDate ;
    char *command = NULL ;
    int startIndex, NRows, NItems ; 
    CSVStruct *webList = NULL ;
    CSVStruct *link = NULL ;
    CSVStruct *csv = NULL ;
    CSVStruct *csv1, *csv2 ; 
    xmlDocPtr doc ;
    xmlNodePtr cur;
    time_t aTimeVal ;
    struct tm *aTimeStruct ;

    dirName = initStringWith2Strings("AUX_", orbitType) ;

    /* Verifying local dir */
    orbitDir = initStringWith3Strings(localS1OrbitsDirectory, "/", dirName) ;
    searchResFile = initStringWith2Strings(orbitDir, "/search.json") ;
    chdir(orbitDir) ;

    /* Compute search start and stop dates */
    aDate = addDaysToDate(fromDate, NULL, -1) ;
    sprintf(startDate, "%.4s-%.2s-%.2s", aDate, aDate + 4, aDate + 6) ;
    aDate = addDaysToDate(toDate, aDate, +1) ;
    sprintf(stopDate, "%.4s-%.2s-%.2s", aDate, aDate + 4, aDate + 6) ;
    free(aDate) ;

    /* From ESA - COPERNICUS */
    mainServer = initStringWithString("catalogue.dataspace.copernicus.eu/odata/v1/Products") ;
    baseURL = initStringWith2Strings("\"https://", mainServer) ;

    /* Preparing Query */
    csv = addStringValInCSVStruct(baseURL, csv) ;
    csv = addStringValInCSVStruct("?\\$filter=Collection/Name+eq+%27SENTINEL-1%27+and+contains(Name,%27AUX_", csv) ;
    csv = addStringValInCSVStruct(orbitType, csv) ;
    csv = addStringValInCSVStruct("%27)+and+ContentDate/Start+gt%20", csv) ;
    csv = addStringValInCSVStruct(startDate, csv) ;
    csv = addStringValInCSVStruct("T00:00:00.000Z", csv) ;
    csv = addStringValInCSVStruct("+and+ContentDate/End+lt+", csv) ;
    csv = addStringValInCSVStruct(stopDate, csv) ;
    csv = addStringValInCSVStruct("T23:59:59.000Z\"", csv) ;

    queryURL = getStringFromCSV(csv) ;
    freeCSVStruct(csv) ;

    command = initStringWith4Strings("curl --silent -H \"Accept:application/json\" ", queryURL, " > ", searchResFile) ;  
//    printf("\n%s\n", command ) ; 
//    fflush(stdout) ;
    system(command) ;
    free(command) ;

    printf("\t---> Checking %s orbit availability on COPERNICUS server between %s and %s\n", orbitType, fromDate, toDate) ;
    if ((webList = getCSVForKeyInJsonFile(searchResFile, "Name"))) {
        *dataID = getCSVForKeyInJsonFile(searchResFile, "Id") ;
        *dataSize = getCSVForKeyInJsonFile(searchResFile, "ContentLength") ;

        /* Verify if other pages of listing are available */
        while ((link = getCSVForKeyInJsonFile(searchResFile, "@odata.nextLink"))) {
            queryURL = escapeCharInString(link->stringVal[0], "&") ;
            command = initStringWith4Strings("curl --silent -H \"Accept:application/json\" ", queryURL, " > ", searchResFile) ;  
            system(command) ;

            if ((csv2 = getCSVForKeyInJsonFile(searchResFile, "Name")))
            {
                csv1 = webList ;
                webList = concatenateCSVStructs(webList, csv2) ;
                freeCSVStruct(csv1) ;
                freeCSVStruct(csv2) ;

                csv1 = *dataID ;
                csv2 = getCSVForKeyInJsonFile(searchResFile, "Id") ;
                *dataID = concatenateCSVStructs(*dataID, csv2) ;
                freeCSVStruct(csv1) ;
                freeCSVStruct(csv2) ;

                csv1 = *dataSize ;
                csv2 = getCSVForKeyInJsonFile(searchResFile, "ContentLength") ;
                *dataSize = concatenateCSVStructs(*dataSize, csv2) ;
                freeCSVStruct(csv1) ;
                freeCSVStruct(csv2) ;
            }
            
            freeCSVStruct(link) ;
            free(queryURL) ;
            free(command) ;
        }
        
        printf("\t---> %d %s orbits available\n", webList->numberOfEntries, orbitType) ;
    }

    return (webList) ;
}
