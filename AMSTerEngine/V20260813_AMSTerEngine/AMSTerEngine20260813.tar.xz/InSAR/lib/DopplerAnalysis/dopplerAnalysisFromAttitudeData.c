
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  dopplerAnalysis
//
//  Created by Dominique Derauw on 17/10/12.
//  Copyright (c) 2012 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "dopplerAnalysis.h"


void estimateDopplerParameterFromOrbitography(struct infoImage *info)
{
    int i, j, k ;
    int xGridDim, yGridDim, azimuthGridSpacing, rangeGridSpacing ;
    double **MIR, **MRI, azimuthPosition, rotationAngle ;
    double averageHeight, rangePosition, *sol ;
    double *NDP, *NDPR, *RTR, *RT, *RS, *VS, *RSxRT, *WxRT, *WxRS, *VSxRT, *RS_RT, range, Rp ;
    double fDC, fR, lambda, *W, mu, pitch, yaw ;
    double ***DCGrid, **A, *cDC, *cDR ;
    geoRef *geo ;
    
    geo = allocAndInitGeorefStructureForTargetEllipsoid(info, info->ellRef) ;
	orbitInterpolation(info) ;
	approxRt(info) ;
    info->EarthRadiusAtSceneCenter = earthRadiusAtPoint(info->rangeDimension / 2., info->azimuthDimension / 2., 2000.0, geo) ;
    
    xGridDim = X_DC_GRID_DIM ;
    yGridDim = Y_DC_GRID_DIM ;
    DCGrid = matrixPileDouble(0, xGridDim - 1, 0, yGridDim - 1, 0, 1) ;
    
    MIR = matrixDouble(0, 2, 0, 2) ; /* Rotation matrix from inertial to rotating system */
    MRI = matrixDouble(0, 2, 0, 2) ; /* Rotation matrix from rotating to inertial system */
    RTR = vectorDouble(0, 2) ; /* On Earth position vector expressed in the rotating system */
    RT = NULL ; /* On Earth position vector expressed in the inertial system */
    RS = NULL ; /* Satellite position vector expressed in the inertial system */
    VS = NULL ; /* Satellite velocity vector expressed in the inertial system */
    NDP = NULL ; /* Normal to the Doppler plane expressed in the inertial system */
    NDPR = NULL ; /* Normal to the Doppler plane expressed in the rotating system */
    RS_RT = vectorDouble(0, 2) ; /* The range Vector */
    RSxRT = vectorDouble(0, 2) ;
    VSxRT = vectorDouble(0, 2) ;
    WxRT = vectorDouble(0, 2) ;
    WxRS = vectorDouble(0, 2) ;
    
    /* Earth rotation vector initialization */
    W = vectorDouble(0, 2) ; /* Earth rotation vector */
    W[0] = W[1] = 0 ;
    W[2] = geo->solving->w ;
    
    lambda = c0 / info->radarCarrierFrequency ;
    mu = 3.986e+14 ; /* Gravitational constant */
    averageHeight = 0. ;
    azimuthGridSpacing = (double)info->azimuthDimension / (yGridDim - 1) ;
    rangeGridSpacing = (double)info->rangeDimension / (xGridDim - 1) ;
    for (j = 0; j < yGridDim; j++) {
        /* For each azimuth line, we compute the state vector */
        azimuthPosition = j * azimuthGridSpacing ;
        calcStateVect(geo->solving->S, azimuthPosition, info) ;
                
        /* We must first compute the Earth rotation matrix corresponding to the time stamp of the current state vector */
        rotationAngle = geo->solving->w * geo->solving->S->t ;
        MRI[0][0] = MIR[0][0] = cos(rotationAngle) ;
        MRI[0][1] = MIR[1][0] =  -sin(rotationAngle) ;
        MRI[0][2] = MIR[2][0] =  0 ;
        MRI[1][0] = MIR[0][1] =  sin(rotationAngle) ;
        MRI[1][1] = MIR[1][1] =  cos(rotationAngle) ;
        MRI[1][2] =  MIR[2][1] = 0 ;
        MRI[2][0] =  MIR[0][2] = 0 ;
        MRI[2][1] =  MIR[1][2] = 0 ;
        MRI[2][2] =  MIR[2][2] = 1. ;
        
        /* We compute the satellite velocity and position vectors in the inertial system */
        RS = multMatVectDouble(MRI, geo->solving->S->P, 3) ;
        VS = multMatVectDouble(MRI, geo->solving->S->V, 3) ;
        
        /* We rotate the normal to the Doppler plane to take yaw and pitch into account */
        yaw = info->yaw[0] + info->yaw[1] * azimuthPosition + info->yaw[2] *pow(azimuthPosition, 2.) ;
        pitch = info->pitch[0] + info->pitch[1] * azimuthPosition + info->pitch[2] *pow(azimuthPosition, 2.) ;
        NDP = normalToDopplerPlane(RS, VS, yaw, pitch) ;
        
        /* We compute the normal to the Doppler plane, back in the rotating system */
        NDPR = multMatVectDouble(MIR, NDP, 3) ;
        
        /* Now, we will locate grid points on the rotating geoid */
        /* So, we have to transfer modified speed vector to correctly initialize the Doppler plane */
        for (k = 0; k < 3; k++) {
            geo->solving->S->V[k] = NDPR[k] ;
        }
        initOnSphereSolving(geo->solving) ;
        
        /* For each range position, we compute point location on the rotating geoid */
        for(i = 0; i < xGridDim; i++){
            rangePosition = i * rangeGridSpacing ;
            earthRadiusAtPoint(rangePosition, azimuthPosition, averageHeight, geo) ;
            sol = onSphereSolvingForPoint(rangePosition, azimuthPosition, averageHeight, geo) ;
            onEllipsoidProjection(RTR, sol, geo->solving) ;
            
            /* Now we return back in the inertial system to compute the Doppler centroid and rate */
            RT = multMatVectDouble(MRI, RTR, 3) ;
            
            /* We compute the range vector RS - RT */
            vectorDiff(RS_RT, RS, RT) ;
            range = vectorNorm(RS_RT) ;
            
            /* Now, we have everything to compute Rp, the first range vector derivative (cfr. " Synthetic Aperture Radar", Curlander & Mc Donough, p.568, eq. B.1.14) */
            vectorialProduct(RSxRT, RS, RT) ;
            Rp = (scalarProduct(VS, RS_RT) + scalarProduct(W, RSxRT)) / range ;
            
            /* Last thing to do is to compute the Doppler Centroid and the Doppler rate (cfr. " Synthetic Aperture Radar", Curlander & Mc Donough, p.571, eq. B.1.23 & B.1.24) */
            vectorialProduct(WxRS, W, RS) ;
            vectorialProduct(WxRT, W, RT) ;
            vectorialProduct(VSxRT, VS, RT) ;
            
            fDC = -2./(lambda * range) * (scalarProduct(VS, RS_RT) + scalarProduct(W, RSxRT)) ;
            fR =  -2./(lambda * range) * (-mu / pow(vectorNorm(RS), 3.) * scalarProduct(RS, RS_RT) + scalarProduct(VS, VS) - pow(Rp, 2.) + scalarProduct(WxRT, WxRS) + 2. * scalarProduct(W, VSxRT)) ;
            
            DCGrid[j][i][0] = fDC ;
            DCGrid[j][i][1] = fR ;
        }
        
        free(RS) ;
        free(RT) ;
        free(VS) ;
        free(NDP) ;
        free(NDPR) ;
    }
    freeVectorDouble(W, 0) ;
    freeVectorDouble(WxRS, 0) ;
    freeVectorDouble(WxRT, 0) ;
    freeVectorDouble(VSxRT, 0) ;
    freeVectorDouble(RSxRT, 0) ;
    freeVectorDouble(RS_RT, 0) ;
    freeVectorDouble(RTR, 0) ;
    freeMatrixDouble(MRI, 0, 0) ;
    freeMatrixDouble(MIR, 0, 0) ;
    freeGeoRef(geo) ;
    
    /* We compute the affine approximation of DC and DC rate from the DCGrid */
    A = DopplerPolynomialApproximation(DCGrid) ;
    
    /* We correct the linear terms to express them in [Hz]\[sec] */
    A[0][1] *= info->rangeSamplingFrequency / rangeGridSpacing ;
    A[1][1] *= info->rangeSamplingFrequency / rangeGridSpacing ;
    A[0][2] *= info->prf / azimuthGridSpacing ;
    A[1][2] *= info->prf / azimuthGridSpacing ;

    cDC = A[0] ;
    cDR = A[1] ;
    setStringValForKeyIn(info->parameterList, "", "") ;
    setStringValForKeyIn(info->parameterList, "Doppler computed from orbitography and attitude", "") ;
    setStringValForKeyIn(info->parameterList, "+++++++++++++++++++++++++++++++++++++++++++++++", "") ;
    setDoubleValForKeyIn(info->parameterList, cDC[0], "Doppler Centroid [Hz]") ;
    setDoubleValForKeyIn(info->parameterList, cDC[1], "Doppler Centroid range slope [Hz]/[sec]") ;
    setDoubleValForKeyIn(info->parameterList, cDC[2], "Doppler Centroid azimuth slope [Hz]/[sec]") ;
    setDoubleValForKeyIn(info->parameterList, cDR[0], "Doppler Rate [Hz][sec]") ;
    setDoubleValForKeyIn(info->parameterList, cDR[1], "Doppler Rate range slope [[Hz]/[sec]]/[sec]") ;
    setDoubleValForKeyIn(info->parameterList, cDR[2], "Doppler Rate azimuth slope [[Hz]/[sec]]/[sec]") ;
    
    freeMatrixPileDouble(DCGrid, 0, 0, 0) ;
    freeMatrixDouble(A, 0, 0) ;
}

double *normalToDopplerPlane(double *RS, double *VS, double yaw, double pitch)
{
    int i, j, k ;
    double *NDP ;
    double *X, *Y, *Z ;
    double alpha, beta, gamma ;
    double **MA, **MB, **MG, **ME, **MEI ;
    double **yawRotationMatrix, **pitchRotationMatrix ;
    double *V, *VP ;

    /* We allocate the loacal ALOS attached to the ALOS platform */
    X = vectorDouble(0, 2) ;
    Y = vectorDouble(0, 2) ;
    Z = vectorDouble(0, 2) ;
    
    /* We compute basis vector of the platform system expressed in the inertial system */
    for (k=0; k < 3; k++) {
        X[k] = VS[k] ;
        Z[k] = -RS[k] ;
    }
    normalizeVector(X) ;
    normalizeVector(Z) ;
    vectorialProduct(Y, Z, X) ;
    /* Remark: Position and velocity vectors are well in the same plane, but not necessarly orthogonal due to orbit excentricity */
    /* So, Y is wel defined as the normal to the plane containing Z and VS */
    /* But X needs to be redefined as the unit vector orthogonal to the YZ plane */
    vectorialProduct(X, Y, Z) ;
    
    /* We compute the Euler's angles */
    beta = acos(Z[2]) ;
    alpha = atan2(Z[0], -Z[1]) ;
    gamma = atan2(X[2], Y[2]) ;
    
    /* Euler's matrix building */
    /* The Euler Matrix is here the transform to go from the inertial system to the platform system as defined for ALOS (Z toward the Earth centre) */
    MA = matrixDouble(0, 2, 0, 2) ;
    MB = matrixDouble(0, 2, 0, 2) ;
    MG = matrixDouble(0, 2, 0, 2) ;
    
    MA[0][0] = MA[1][1] = cos(alpha) ;
    MA[0][1] = sin(alpha) ;
    MA[0][2] = MA[1][2] = 0 ;
    MA[2][2] = 1 ;
    MB[0][0] = 1 ;
    MB[0][1] = MB[0][2] = 0 ;
    MB[1][1] = MB[2][2] = cos(beta) ;
    MB[1][2] = sin(beta) ;
    MG[0][0] = MG[1][1] = cos(gamma) ;
    MG[0][1] = sin(gamma) ;
    MG[0][2] = MG[1][2] = 0 ;
    MG[2][2] = 1 ;

    for (i = 0; i < 2; i++) {
        for (j = i + 1; j < 3; j++) {
            MA[j][i] = pow(-1., i + j) * MA[i][j] ;
            MB[j][i] = pow(-1., i + j) * MB[i][j] ;
            MG[j][i] = pow(-1., i + j) * MG[i][j] ;
        }
    }
    
    /* We compute the Euler's matrix as the product of the three rotation matrix */
    MEI = multMatDouble(MB, MA, 3) ;
    ME = multMatDouble(MG, MEI, 3) ;
    /* And we compute the inverse transform */
    transposeMatrixDouble(MEI, ME, 3) ;
    
    /* We compute yaw and pitch rotation matrix as expressed in the platform referential */
    yaw *= PI/180. ;
    yawRotationMatrix = matrixDouble(0, 2, 0, 2) ;
    yawRotationMatrix[0][0] = yawRotationMatrix[1][1] = cos(yaw) ;
    yawRotationMatrix[0][1] = -sin(yaw) ;
    yawRotationMatrix[0][2] = yawRotationMatrix[1][2] = 0. ;
    yawRotationMatrix[2][2] = 1. ;
    for (i = 0; i < 2; i++) {
        for (j = i + 1; j < 3; j++) {
            yawRotationMatrix[j][i] = pow(-1., i + j) * yawRotationMatrix[i][j] ;
        }
    }
    
    pitch *= PI/180. ;
    pitchRotationMatrix = matrixDouble(0, 2, 0, 2) ;
    pitchRotationMatrix[0][0] = pitchRotationMatrix[2][2] = cos(pitch) ;
    pitchRotationMatrix[0][2] = -sin(pitch) ;
    pitchRotationMatrix[0][1] = pitchRotationMatrix[1][2] = 0. ;
    pitchRotationMatrix[1][1] = 1. ;
    for (i = 0; i < 2; i++) {
        for (j = i + 1; j < 3; j++) {
            pitchRotationMatrix[j][i] = pow(-1., i + j) * pitchRotationMatrix[i][j] ;
        }
    }
    
    /* We compute Velocity into the platform referential */
    VP = multMatVectDouble(ME, VS, 3) ;
    
    /* We rotate the velocity vector with respect to the yaw angle */
    V = multMatVectDouble(yawRotationMatrix, VP, 3) ;
    
    /* Finaly, we express the rotated velocity vector, which is the normal to the doppler plane, in the inertial system */
    NDP = multMatVectDouble(MEI, V, 3) ;

    freeVectorDouble(X, 0) ;
    freeVectorDouble(Y, 0) ;
    freeVectorDouble(Z, 0) ;
    freeVectorDouble(V, 0) ;
    freeVectorDouble(VP, 0) ;
    freeMatrixDouble(MA, 0, 0) ;
    freeMatrixDouble(MB, 0, 0) ;
    freeMatrixDouble(MG, 0, 0) ;
    freeMatrixDouble(ME, 0, 0) ;
    freeMatrixDouble(MEI, 0, 0) ;
    freeMatrixDouble(yawRotationMatrix, 0, 0) ;
    freeMatrixDouble(pitchRotationMatrix, 0, 0) ;
    
    V = vectorDouble(0, 2) ;
    for (k=0; k < 3; k++) {
        V[k] = VS[k] ;
    }
    
    return (NDP) ;
}

double **DopplerPolynomialApproximation(double ***DCGrid)
{
    int xGridDim, yGridDim ;
    int iX, iY, *index, N ;
    double **A, **M, *VDC, *VDR, sign ;

    xGridDim = X_DC_GRID_DIM ;
    yGridDim = Y_DC_GRID_DIM ;
    
    N = 5 ;
    index = vectorInt(1, N) ;
    VDC = vectorDouble(1, N) ;
    VDR = vectorDouble(1, N) ;
    M = matrixDouble(1, N, 1, N) ;
    A = matrixDouble(0, 1, 0, N - 1) ;
    for (iY = 1; iY <= N; iY++) {
        for (iX = 1; iX <= N; iX++) {
            M[iY][iX] = 0. ;
        }
        VDC[iY] = VDR[iY] = A[0][iY - 1] = A[1][iY - 1] = 0. ;
    }

    for (iY = 0; iY < yGridDim; iY++) {
        for (iX = 0; iX < xGridDim; iX++) {
            M[1][1]++ ;
            M[1][2] += (double)iX ;
            M[1][3] += (double)iY ;
            M[1][4] += pow((double)iX, 2.) ;
            M[1][5] += pow((double)iY, 2.) ;
            M[2][3] += (double)iX * (double)iY ;
            M[2][4] += pow((double)iX, 3.) ;
            M[2][5] += (double)iX * pow((double)iY, 2.) ;
            M[3][4] += pow((double)iX, 2.) * (double)iY ;
            M[3][5] += pow((double)iY, 3.) ;
            M[4][4] += pow((double)iX, 4.) ;
            M[4][5] += pow((double)iX, 2.) * pow((double)iY, 2.) ;
            M[5][5] += pow((double)iY, 4.) ;
            VDC[1] += DCGrid[iY][iX][0] ;
            VDR[1] += DCGrid[iY][iX][1] ;
            VDC[2] += DCGrid[iY][iX][0] * (double)iX ;
            VDR[2] += DCGrid[iY][iX][1] * (double)iX ;
            VDC[3] += DCGrid[iY][iX][0] * (double)iY ;
            VDR[3] += DCGrid[iY][iX][1] * (double)iY ;
            VDC[4] += DCGrid[iY][iX][0] * pow((double)iX, 2.) ;
            VDR[4] += DCGrid[iY][iX][1] * pow((double)iX, 2.)  ;
            VDC[5] += DCGrid[iY][iX][0] * pow((double)iY, 2.) ;
            VDR[5] += DCGrid[iY][iX][1] * pow((double)iY, 2.)  ;
        }
    }
    M[2][2] = M[1][4] ;
    M[3][3] = M[1][5] ;
    for (iY = 1; iY <= N; iY++) {
        for (iX = iY + 1; iX <= N; iX++) {
            M[iX][iY] = M[iY][iX] ;
        }
    }
    
    /* We limit the calculation to linear approx */
    N = 3 ;

    ludcmp(M, N, index, &sign) ;
    lubksb(M, N, index, VDC) ;
    lubksb(M, N, index, VDR) ;
    for (iX = 0; iX < N; iX++) {
        A[0][iX] = VDC[iX + 1] ;
        A[1][iX] = VDR[iX + 1] ;
    }

    return(A) ;
}

double *multMatVectDouble(double **M, double *V, int order)
{
    int i, j ;
    double *V2 ;
    
    V2 = vectorDouble(0, order - 1) ;
    for(i = 0; i < order; i++) {
        V2[i] = 0. ;
        for (j = 0; j < order; j++) {
            V2[i] += M[i][j] * V[j] ;
        }
    }
    return (V2) ;
}


double **multMatDouble( double **A, double**B, int rank)
{
    int i, j, k ;
    double **AB ;
    
    AB = matrixDouble(0, rank - 1, 0, rank - 1) ;
    for (i = 0; i < rank; i++) {
        for (j = 0; j < rank; j++) {
            AB[i][j] = 0 ;
            for (k = 0; k < rank; k++) {
                AB[i][j] += A[i][k] * B[k][j] ;
            }
        }
    }
    return (AB) ;
}


void transposeMatrixDouble(double **resultMatrix, double **A, int rank)
{
    int i, j ;
    
    for (i = 0; i < rank; i++) {
        for (j = 0; j < rank; j++) {
            resultMatrix[i][j] = A[j][i] ;
        }
    }
}