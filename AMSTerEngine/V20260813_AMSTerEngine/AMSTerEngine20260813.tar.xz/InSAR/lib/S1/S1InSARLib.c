
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


// 
//  S1InSARDataReaderLib.c
//  S1InSARDataReader
//
//  Created by Dominique Derauw on 25/09/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#include "S1InSARLib.h"
#include "ESDLib.h"


int S1Coregistration(CSVStruct *cl)
{
    char *InSARParametersPath = NULL, *outputFilePath, *aPath ;
    char InSARParametersFileFound ;
    char whatToDoWithMasterBursts ;
    char *selectedMasterPol, *selectedSlavePol, *selectedSuperMasterPol ;
    int    currentDirectoryFdesc, i ;
    SLCImageInfo *superMasterInfo, *masterInfo, *slaveInfo ;
    time_t startTime, endTime ;
    InSARParametersStruct *pInSAR ;
    CSVStruct *cl2 ;
    
    if(isArgumentPresentInCSV(cl, "help")|| isArgumentPresentInCSV(cl, "-h"))
        S1CoregistrationHelp() ;
    
    /* Change working directory to current directory */
    currentDirectoryFdesc = open(".", O_RDONLY) ;
    fchdir(currentDirectoryFdesc) ;
    
    InSARParametersFileFound = 0 ;
    i = 1 ;
    /* We first check each command line parameter to verify if it is the path of en existing file */
    /* If yes, this file is supposed to be an InSAR parameter file */
    while (i < cl->numberOfEntries) {
        InSARParametersPath = initStringWithString(cl->stringVal[i]) ;
        if(fileExistsAtPath(InSARParametersPath)) {
            InSARParametersFileFound = 1 ;
            break ;
        }
        i++ ;
        free(InSARParametersPath) ;
    }
    
    /* If no parameter points to an existing file, check in working directory */
    if(!InSARParametersFileFound) {
        InSARParametersPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
        if(!fileExistsAtPath(InSARParametersPath)){
            free(InSARParametersPath) ;
            InSARParametersPath = initStringWithString("./InSARParameters.txt") ;
            printf("Tested InSAR parameters path: %s\n", InSARParametersPath) ;
            if(!fileExistsAtPath(InSARParametersPath)) {
                printf("Fourt !\n") ;
                S1CoregistrationHelp() ;
            }
        }
        InSARParametersFileFound = 1 ;
    }
    
    time(&startTime) ;
    pInSAR = readInSARParametersFileAtPath(InSARParametersPath) ;
    if (!isSlaveValid(pInSAR->slaveImage)) {
        ase("Invalid slave image!\n\t-/-> Missing bursts in slave image.\n\t-/-> Nothing to coregister.\n") ;
    }

    /* Set flags */
    pInSAR->flag |= (isFlagPresentInCSV(cl, "n"))? _NO_RERAMPING_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(cl, "A"))? _ALL_POLARIZATIONS_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(cl, "q"))? _SQUINT_PHASE_REMOVAL_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(cl, "e"))? _ESD_ENABLED_ : pInSAR->flag ;

    if ((i = isArgumentPresentInCSV(cl, "dx="))) {
        sscanf(cl->stringVal[i] + 3, "%lf", &(pInSAR->xShift)) ;
    }
    
    if ((i = isArgumentPresentInCSV(cl, "dy="))) {
        sscanf(cl->stringVal[i] + 3, "%lf", &(pInSAR->yShift)) ;
    }
    

    /* Increase the system limit number of open files */
    setNumberOfAllowedOpenendFilesToMax() ;
    /* Initializing multi thread */
    maxThreads = numberOfThreads() ;
    
    /* Select polarization if requested */
    selectedMasterPol = selectedSlavePol = selectedSuperMasterPol = NULL ;
    if (!(pInSAR->flag & _ALL_POLARIZATIONS_)) {
        selectedMasterPol = initStringWithString(pInSAR->masterPolarizationChannel) ;
        sprintf(pInSAR->masterInfo->polMode, "%s", selectedMasterPol) ;
        selectedSlavePol = initStringWithString(pInSAR->slavePolarizationChannel) ;
        sprintf(pInSAR->slaveInfo->polMode, "%s", selectedSlavePol) ;
        pInSAR->masterInfo->numberOfLayers = pInSAR->slaveInfo->numberOfLayers = 1 ;
    }

    /* Re-create S1Specific info for slave  and master images */
    /* ***************************************************** */
    /* Slave image */
    slaveInfo = mergeFrameInfo(pInSAR->slaveImage, selectedSlavePol) ;
    freeInfoImage(pInSAR->slaveInfo) ;
    pInSAR->slaveInfo = slaveInfo ;
    
    /* Check if we deal with a super master image */
    if (pInSAR->masterInterpolation) {
        printf("\n\t---> Coregistration on a super master requested\n") ;
        outputFilePath = initStringWith3Strings(pInSAR->interpolatedMaster->dataDirectoryPath, "/SLCData.", pInSAR->masterPolarizationChannel) ;
        if ((pInSAR->flag & _ALL_POLARIZATIONS_ && !isSLCDataFilePresentInCSLImage(pInSAR->interpolatedMaster, NULL)) || !fileExistsAtPath(outputFilePath)) {
            aPath = initStringWith2Strings(pInSAR->SM2MpInSAR->whereAmI, "/TextFiles/InSARParameters.txt") ;
            cl2 = addStringValInCSVStruct("S1Coregistration", NULL) ;
            cl2 = addStringValInCSVStruct(aPath, cl2) ;
            if (pInSAR->flag & _NO_RERAMPING_) {
                cl2 = addStringValInCSVStruct("-n", cl2) ;
            }
            if (pInSAR->flag & _ALL_POLARIZATIONS_) {
                selectedSuperMasterPol = NULL ;
                cl2 = addStringValInCSVStruct("-A", cl2) ;
            }
            else {
                selectedSuperMasterPol = initStringWithString(pInSAR->SM2MpInSAR->masterPolarizationChannel) ;
            }
            printf("\t---> Master to super master coregistration apparently not done.\n") ;
            printf("\t---> Launching master to super master coregistration...\n") ;
            S1Coregistration(cl2) ;
            freeCSVStruct(cl2) ;
            free(aPath) ;
        }
        else {
            printf("\t---> Master to super master coregistration apparently already done.\n") ;
        }
        free(outputFilePath) ;

        /* Recreate S1Specific info for super master to master process */
        /* Super master image */
        superMasterInfo = mergeFrameInfo(pInSAR->SM2MpInSAR->masterImage, selectedSuperMasterPol) ;
        freeInfoImage(pInSAR->SM2MpInSAR->masterInfo) ;
        pInSAR->SM2MpInSAR->masterInfo = superMasterInfo ;
        
        /* Master image */
        /* Interpolated master image is the master of the current pair */
        masterInfo = mergeFrameInfo(pInSAR->SM2MpInSAR->interpolatedSlave, selectedMasterPol) ;
        freeInfoImage(pInSAR->masterInfo) ;
        pInSAR->masterInfo = masterInfo ;
        pInSAR->masterInfo->masterInfo = superMasterInfo ;
        freeCSLImageStructure(pInSAR->masterImage) ;
        pInSAR->masterImage = getCSLImageStructureAtPath(pInSAR->masterInfo->CSLImagePath) ;

        /* Interpolated master image is the slave of the super master */
        freeInfoImage(pInSAR->SM2MpInSAR->slaveInfo) ;
        pInSAR->SM2MpInSAR->slaveInfo = masterInfo ;
        pInSAR->SM2MpInSAR->interpolatedSlaveInfo = masterInfo ;
        initInSAR_GEO(pInSAR->SM2MpInSAR, _KEEPAOI_) ;
        
        /* Slave image */
        pInSAR->slaveInfo->superMasterInfo = superMasterInfo ;
        pInSAR->slaveInfo->masterInfo = masterInfo ;
        pInSAR->interpolatedSlaveInfo = slaveInfo ;
        pInSAR->interpolatedSlaveInfo->superMasterInfo = superMasterInfo ;
        
        /* Re-initiate super master to master burst transforms */
        printf("\t---> Init super master to master per-burst transforms\n") ;
        InSARBurstSelection(pInSAR->SM2MpInSAR) ;
        initPerBurstTransforms(pInSAR->SM2MpInSAR) ;
//        alignSlaveImage(pInSAR->SM2MpInSAR) ;

    }
    else {
        /* Master image */
        masterInfo = mergeFrameInfo(pInSAR->masterImage, selectedMasterPol) ;
        freeInfoImage(pInSAR->masterInfo) ;
        pInSAR->masterInfo = masterInfo ;
        pInSAR->slaveInfo->masterInfo = pInSAR->masterInfo ;
    }

    initInSAR_GEO(pInSAR, _KEEPAOI_) ;
    saveInSARParametersFileAtPath(pInSAR, InSARParametersPath) ;
    
    /* Determine common burst selection and copy new instance of master if burst selection differs from initial one */
    whatToDoWithMasterBursts = (isFlagPresentInCSV(cl, "t"))? _S1_TRASH_BURSTS_ : _S1_KEEP_BURSTS_ ;
    if (InSARBurstSelection(pInSAR) || (pInSAR->flag & _NO_RERAMPING_)) {
        copyMasterImageToDestination(pInSAR) ;
        whatToDoWithMasterBursts = _S1_TRASH_BURSTS_ ;
        pInSAR->flag |= _S1_MASTER_IMAGE_COPIED_ ;
    }
    
    /* Copy slave image to its destination */
    /* *********************************** */
    copySlaveImageToDestination(pInSAR) ;

    /* Initialize S1 coregistration */
    /* **************************** */
    printf("Init per-burst transforms\n") ;
    initPerBurstTransforms(pInSAR) ;
    
    /* Slave image per burst interpolation */
    burstsDeramping(pInSAR->interpolatedSlaveInfo, NULL) ;
    burstsInterpolation(pInSAR) ;
    burstsReramping(pInSAR->interpolatedSlaveInfo, pInSAR->masterInfo) ;

    if (pInSAR->flag & _ESD_ENABLED_) {
        double esdCorrectionPerSwath[3] = {0.0, 0.0, 0.0} ;
        int unsigned esdSwathIndex ;
        S1AdditionalInfo *esdSlaveSpecific ;
        burstDescriptor *esdSlaveBurst ;

        /* (ESD() prints its own "---> Extended Spectral Diversity" header
         *  and mirrors all subsequent output into TextFiles/ESDlog.txt.) */
        /* ESD needs master burst deramping coefficients (kt polynomial) */
        allocAndInitDerampingForBursts(pInSAR->masterInfo) ;
        ESD(pInSAR, esdCorrectionPerSwath) ;

        /* Re-copy original slave data so second pass starts from raw SLC */
        printf("\n---> Re-copying original slave data for second interpolation pass\n") ;
        copySlaveImageToDestination(pInSAR) ;

        /* Re-initialize per-burst transforms from orbital geometry */
        printf("Re-init per-burst transforms\n") ;
        initPerBurstTransforms(pInSAR) ;

        /* Apply ESD corrections to freshly initialized transforms */
        esdSlaveSpecific = pInSAR->interpolatedSlaveInfo->sensorSpecificInfo ;
        for (esdSwathIndex = esdSlaveSpecific->firstSwathIndex; esdSwathIndex <= esdSlaveSpecific->lastSwathIndex; esdSwathIndex++) {
            if (esdCorrectionPerSwath[esdSwathIndex] != 0.0) {
                printf("\tApplying ESD correction %.6f px to swath %d\n", esdCorrectionPerSwath[esdSwathIndex], esdSwathIndex) ;
                esdSlaveBurst = getFirstSelectedBurstInList(esdSlaveSpecific->burstList[esdSwathIndex]) ;
                while (esdSlaveBurst && esdSlaveBurst->isSelected) {
                    esdSlaveBurst->T[1][2] += esdCorrectionPerSwath[esdSwathIndex] ;
                    if (!(esdSlaveBurst = esdSlaveBurst->nextBurst)) {
                        break ;
                    }
                }
            }
        }

        /* Second interpolation pass with ESD-corrected transforms */
        printf("\n---> Second interpolation pass with ESD-corrected transforms\n") ;
        allocAndInitDerampingForBursts(pInSAR->interpolatedSlaveInfo) ;
        burstsDeramping(pInSAR->interpolatedSlaveInfo, NULL) ;
        burstsInterpolation(pInSAR) ;
        burstsReramping(pInSAR->interpolatedSlaveInfo, pInSAR->masterInfo) ;
    }

    /* Since images are coregistered, slave swath and burst must be aligned with master ones */
    alignSlaveImage(pInSAR) ;

    /* Update info image */
    saveS1InfoImage(pInSAR->interpolatedSlaveInfo, pInSAR->interpolatedSlave->infoDirectoryPath) ;
    
    if (pInSAR->flag & _NO_RERAMPING_) {
        pInSAR->masterInfo->flag |= _NO_RERAMPING_ ;
        pInSAR->interpolatedSlaveInfo->flag |= _NO_RERAMPING_ ;

        if (pInSAR->flag & _SQUINT_PHASE_REMOVAL_) {
            pInSAR->masterInfo->flag |= _SQUINT_PHASE_REMOVAL_ ;
            pInSAR->interpolatedSlaveInfo->flag |= _SQUINT_PHASE_REMOVAL_ ;
        }

        printf("\n---> Master image deramping\n");
        burstsDeramping(pInSAR->masterInfo, NULL) ;
        printf("\n---> Slave image deramping\n");
        burstsDeramping(pInSAR->interpolatedSlaveInfo, pInSAR->masterInfo) ;
    }
    
    /* Images stitching */
    /* Proceed with slave image stitching */
    printf("\nAssembling slave bursts in slave image...") ;
    concatenateBurstsIntoWideSwathImage(pInSAR->interpolatedSlave, pInSAR->interpolatedSlaveInfo, _S1_KEEP_BURSTS_) ;
    if (!isArgumentPresentInCSV(cl, "-keepBursts")) {
        trashSelectedBursts(pInSAR->interpolatedSlaveInfo) ;
    }

    /* Proceed with image stitching provided master image is not present due to previous processing on other area */
    if (!isSLCDataFilePresentInCSLImage(pInSAR->masterImage, pInSAR->masterInfo)) {
        printf("\nAssembling master bursts in master image...\n") ;
        concatenateBurstsIntoWideSwathImage(pInSAR->masterImage, pInSAR->masterInfo, _S1_KEEP_BURSTS_) ;

        if (whatToDoWithMasterBursts == _S1_TRASH_BURSTS_ && !isArgumentPresentInCSV(cl, "-keepBursts")) {
            trashSelectedBursts(pInSAR->masterInfo) ;
        }
    }
    
    freeS1Specific(pInSAR->masterInfo->sensorSpecificInfo, _S1_FREE_BURSTS_) ;
    freeS1Specific(pInSAR->slaveInfo->sensorSpecificInfo, _S1_FREE_BURSTS_) ;
    freeS1Specific(pInSAR->interpolatedSlaveInfo->sensorSpecificInfo, _S1_FREE_BURSTS_) ;
    if (pInSAR->masterInterpolation) {
        freeS1Specific(superMasterInfo->sensorSpecificInfo, _S1_FREE_BURSTS_) ;
    }

    saveInSARParametersFileAtPath(pInSAR, InSARParametersPath) ;

    freeInSARParametersStruct(pInSAR) ;
    free(InSARParametersPath) ;
    if (!(pInSAR->flag & _ALL_POLARIZATIONS_)) {
        free(selectedMasterPol) ;
        free(selectedSlavePol) ;
        if (selectedSuperMasterPol) {
            free(selectedSuperMasterPol) ;
        }
    }
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    
    return 0;
}

void S1CoregistrationHelp()
{
    printf("\nUsage:") ;
    printf("\n\tS1Coregistration [tA] \n") ;
    printf("\n\tThis routine will coregister a pair of SLC S1 data.\n") ;
    printf("By default, only the selected polarization in the InSARParameterFile is coregistered\n") ;
    printf("\nOptions:\n") ;
    printf("-A: All polarizations will be coregistered\n") ;
    printf("-t: All bursts of master image will be trashed after master image concatenation\n") ;
    printf("-e: Enable Extended Spectral Diversity (ESD) for sub-pixel azimuth coregistration\n") ;
    exit(0) ;
}


void transferAdditionalParameters(InSARParametersStruct *pInSAR, keyValue *parametersList)
{
    pInSAR->red.Fra = getIntValForKeyIn(parametersList, "Range reduction factor [pix]") ;
    pInSAR->red.Faz = getIntValForKeyIn(parametersList, "Azimuth reduction factor [pix]") ;
    
    pInSAR->coh.cor = getDoubleValForKeyIn(parametersList, "Coherence estimator range window size [pix]") ;
    pInSAR->coh.coa = getDoubleValForKeyIn(parametersList, "Coherence estimator azimuth window size [pix]") ;
    //    pInSAR->coh.spi = getDoubleValForKeyIn(parametersList, "Square spiral size [pix]") ;
    pInSAR->coh.spi = 1 ;
}



void burstsInterpolation(InSARParametersStruct *pInSAR)
{
    int unsigned layerIndex, swathIndex ;
    int unsigned burstIndex, numberOfBurstToProcess ;
    int unsigned firstBurstIndex, lastBurstIndex ;
    int unsigned iU ;
    int iS ;
    int numberOfThreads ;
    S1AdditionalInfo *slaveSpecific ;
    interpolationParameters *pInterpol, **ppInterpol ;
    burstDescriptor *slaveBurst ;

    slaveSpecific = pInSAR->interpolatedSlaveInfo->sensorSpecificInfo ;

//    pInterpol = allocInterpolationParameters() ;
//    pInterpol->pInSAR = pInSAR ;

    swathIndex = 0 ;

    if (pInSAR->flag & _VERBOSE_) {
        printf("\nSlave bursts interpolation\n") ;
    }
    
    for (layerIndex = 0; layerIndex < slaveSpecific->numberOfLayers; layerIndex++) {
        if (pInSAR->flag & _VERBOSE_) {
            printf("Layer %d interpolation\n", layerIndex) ;
            if (slaveSpecific->numberOfLayers > 1) {
            }
            else {
                printf("\n") ;
            }    
        }            

        for (swathIndex = slaveSpecific->firstSwathIndex; swathIndex <= slaveSpecific->lastSwathIndex; swathIndex++) {
            if (pInSAR->flag & _VERBOSE_) {
                printf("\tSwath %d\n", swathIndex) ;
            }            

            slaveBurst = getLastSelectedBurstInList(slaveSpecific->burstList[swathIndex]) ;            
            lastBurstIndex = slaveBurst->burstIndex ;
            slaveBurst = getFirstSelectedBurstInList(slaveSpecific->burstList[swathIndex]) ;            
            firstBurstIndex = slaveBurst->burstIndex ;
            numberOfBurstToProcess = lastBurstIndex - firstBurstIndex + 1 ;
            ppInterpol = malloc(numberOfBurstToProcess * sizeof(ppInterpol[0])) ;
            for (iU = 0; iU < numberOfBurstToProcess; iU++) {
                ppInterpol[iU] = allocInterpolationParameters() ;
                ppInterpol[iU]->pInSAR = pInSAR ;
            }
            
#ifdef _USE_OPENMP_
            numberOfThreads = (numberOfBurstToProcess < maxThreads)? numberOfBurstToProcess : maxThreads ;
            #pragma omp parallel num_threads(numberOfThreads)
            #pragma omp for schedule(auto) private(slaveBurst, pInterpol, iS)
#endif
            for (burstIndex = firstBurstIndex; burstIndex <= lastBurstIndex; burstIndex++) {
                slaveBurst = getBurstAtIndex(slaveSpecific->burstList[swathIndex], burstIndex) ;
                pInterpol = ppInterpol[burstIndex - firstBurstIndex] ;
//            }
            

//            while (slaveBurst->isSelected) {

                /* Per burst interpolation */
                memcpy(pInterpol->affineTransform[0], slaveBurst->T[0], 6 * sizeof(double)) ;
                if (pInSAR->flag & _VERBOSE_) {
                    printf("\t\tInterpolating burst %d of swath %d\n", slaveBurst->burstIndex, swathIndex) ;
                    printf("Used transform for burst %d of swath %d:\n", slaveBurst->burstIndex, swathIndex) ;
                    printf("X2 = %-21.15lf X1 + %-21.15lf Y1 + %-21.15lf\n", pInterpol->affineTransform[0][0], pInterpol->affineTransform[0][1], pInterpol->affineTransform[0][2] + slaveBurst->rangeTransformConstantTerm) ;
                    printf("Y2 = %-21.15lf X1 + %-21.15lf Y1 + %-21.15lf\n\n", pInterpol->affineTransform[1][0], pInterpol->affineTransform[1][1], pInterpol->affineTransform[1][2]) ;
                }       

                pInterpol->xDimOut = pInterpol->xDimIn = slaveBurst->xDim ;
                pInterpol->yDimOut = pInterpol->yDimIn = slaveBurst->yDim ;

                iS = 0 ;
                while (iS < 3 && iS < slaveBurst->deramping->dcPol->order) {
                    pInterpol->FDC[iS] = slaveBurst->dcPolynomial->coefs[iS] ;
                    iS++ ;
                }

                pInterpol->PRF = pInSAR->slaveInfo->prf ;
                pInterpol->fIn = slaveBurst->file[layerIndex] ;
                pInterpol->fOut = slaveBurst->file[layerIndex] ;
                pInterpol->dXFDC = 0 ;
                pInterpol->verbose = 0 ;

                interpolationCore(pInterpol) ;
    
//                if (!(slaveBurst = slaveBurst->nextBurst)) {
//                    break ;
//                }
            }

            for (iU = 0; iU < numberOfBurstToProcess; iU++) {
                ppInterpol[iU]->fIn = ppInterpol[iU]->fOut = NULL ;
                freeInterpolationParameters(ppInterpol[iU]) ;
            }
            free(ppInterpol) ;
        }
    }
//    pInterpol->fIn = pInterpol->fOut = NULL ;
//    freeInterpolationParameters(pInterpol) ;

    /* Now that slave bursts have the same dimensions than master ones, one must adapt their sizes and indexes */
//    alignSlaveBursts(pInSAR) ;
}


void adaptInSARparametersToS1(InSARParametersStruct *pInSAR)
{
    /* Requested reduction factors for coarse coregistration */
    pInSAR->red.Faz = AZIMUTH_REDUCTION_FACTOR ;
    pInSAR->red.Fra = RANGE_REDUCTION_FACTOR ;

    /* Window dimensions for coarse coregistration */
    pInSAR->corg.F_lenr = XDIM_COARSE_COR_WINDOW ;
    pInSAR->corg.F_lena = YDIM_COARSE_COR_WINDOW ;

    /* Window shifts for coarse coregistration */
    pInSAR->corg.Depra = X_COARSE_COR_WINDOW_SHIFT ;
    pInSAR->corg.Depaz = Y_COARSE_COR_WINDOW_SHIFT ;

    /* Coarse coregistration thresholds */
    pInSAR->corg.seuilcoh = CORRELATION_THRESHOLD ;
    pInSAR->corg.seuilra = COARSE_COR_X_FWHM ;
    pInSAR->corg.seuilaz = COARSE_COR_Y_FWHM ;

    /* Window dimension for fine coregistration */
    pInSAR->corf.F_lenr = XDIM_FINE_COR_WINDOW ;
    pInSAR->corf.F_lena = YDIM_FINE_COR_WINDOW ;

    /* Window shifts for fine coregistration */
    pInSAR->corf.Depra = X_FINE_COR_WINDOW_SHIFT ;
    pInSAR->corf.Depaz = Y_FINE_COR_WINDOW_SHIFT ;

    /* Fine coregistration error gaps */
    pInSAR->corf.errra = X_FINE_COR_ERROR ;
    pInSAR->corf.erraz = Y_FINE_COR_ERROR ;

    /* Fine coregistration thresholds */
    pInSAR->corf.seuilcoh = FINE_COR_THRESHOLD ;

    /* InSAR product computation parameters */
    pInSAR->coh.cor = XDIM_COH_WINDOW ;
    pInSAR->coh.coa = YDIM_COH_WINDOW ;
    pInSAR->coh.spi = SPI_COH_WINDOW ;
}


void translateAffineTransform(double **T, double dx, double dy)
{
    T[0][2] = T[0][0] * dx + T[0][1] * dy + T[0][2] - dx ;
    T[1][2] = T[1][0] * dx + T[1][1] * dy + T[1][2] - dy ;
}


/* Burst deramping functions */
/* Implementation and variable naming convention cope with document: */
/* "Definition of the TOPS SLC Deramping function for products generated by S1 IPF" */
/* Ref: COPE-GSEG-EOPG-TN-14-0025 */
void burstsDeramping(SLCImageInfo *info, SLCImageInfo *masterInfo)
{
    int unsigned swathIndex, layerIndex ;
    int unsigned iX, iY ;
    double rampPhase, azimuthTime ;
    double squintAngle, squintPhase, z1 ;
    double kt, tc ;
    double **affineTransform ;
    coord2D p1, p2 ; ;
    S1AdditionalInfo *S1Specific, *masterSpecific = NULL ;
    rawFileDescriptor *outputBurstFile = NULL ;
    CSVStruct *csv ;
    complexFloat **burst ;
    complexFloat derampingFactor ;
    derampingStructType *deramping ;
    burstDescriptor *currentBurst, *currentMasterBurst = NULL ;
    struct stateVect *aStateVector ;
    struct stateVect **ppStateVector ;
    int unsigned ompIndex, nThreads ;	 /* omp management */


    /* Allocate and init deramping structure */
    allocAndInitDerampingForBursts(info) ;

    S1Specific = info->sensorSpecificInfo ;
    if (masterInfo != NULL) {
        masterSpecific = masterInfo->sensorSpecificInfo ;
    }
    affineTransform = matrixDouble(0, 1, 0, 2) ;

    /* Read number of layers */
    csv = readCSVInString(info->polMode) ;

    /* Allocating a vector of pointer on state vectors depending on the number of threads */
    nThreads = (maxThreads > 0)? maxThreads : 1 ;
    ppStateVector = malloc(nThreads * sizeof(ppStateVector[0])) ;
    for (ompIndex = 0; ompIndex < nThreads; ompIndex++) {
        ppStateVector[ompIndex] = allocStateVector() ;
    }
    aStateVector = ppStateVector[0] ;

    /* loop on layers */
    for (layerIndex = 0; layerIndex < info->numberOfLayers; layerIndex++) {
        printf("\nBursts deramping - Sentinel 1 %d data: %s polarization layer\n", info->relativeOrbitNumber, csv->stringVal[layerIndex]) ;
        /* Loop on swath */
        for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
            printf("\tSwath %d\n", swathIndex) ;

            currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
            if (masterSpecific) {
                currentMasterBurst = getFirstSelectedBurstInList(masterSpecific->burstList[swathIndex]) ;
            }

            while (currentBurst->isSelected) {
                printf("\t\tDeramping burst %d of swath %d\n", currentBurst->burstIndex, swathIndex) ;

                /* Allocate burst */
                burst = matrixComplexFloat(0, currentBurst->yDim - 1, 0, currentBurst->xDim - 1) ;

                /* Rewind burst file */
                outputBurstFile = currentBurst->file[layerIndex] ;
                rewind(outputBurstFile->f) ;

                /* Read burst */
                fread(burst[0], sizeof(complexFloat), currentBurst->xDim * currentBurst->yDim, outputBurstFile->f) ;

                /* Update interpolation transfrom for burst under concern */
                if (masterInfo != NULL && !(info->flag & _NO_RERAMPING_)) {
                    memcpy(affineTransform[0], currentMasterBurst->T[0], 6 * sizeof(double)) ;
                }

                deramping = currentBurst->deramping ;
                if (masterInfo != NULL && (info->flag & _NO_RERAMPING_)) {
                    deramping = currentMasterBurst->deramping ;
                }
#pragma omp parallel num_threads(maxThreads)
#pragma omp for schedule(auto) private(p1, p2, iX, azimuthTime, kt, tc, rampPhase, derampingFactor, aStateVector, squintAngle, z1, squintPhase)
               /* Deramp burst */
                for (iY = 0; iY < currentBurst->yDim; iY++) {
#ifdef _USE_OPENMP_
                    aStateVector = ppStateVector[omp_get_thread_num()] ;
#else
                    aStateVector = ppStateVector[0] ;
#endif
                    p1.y = p2.y = (double)iY ;
                    azimuthTime = currentBurst->FPAT + p2.y * info->lineTimeInterval - deramping->t0 ;
                    calcStateVect(aStateVector, currentBurst->firstAzimuthIndex + p2.y, info) ;
                    for (iX = 0; iX < currentBurst->xDim; iX++) {
                        /* Compute range - azimuth position */
                        p1.x = p2.x = (double)iX ;
                        if (masterInfo != NULL  && !(info->flag & _NO_RERAMPING_)) {
                            planeAffineTransformOfCoord2D(&p1, &p2, affineTransform) ;
                            azimuthTime = currentBurst->FPAT + p2.y * info->lineTimeInterval - deramping->t0 ;
                        }

                        /* Compute parameters for the corresponding position */
                        kt = yValForPolynomial(deramping->ktPol, (double)p2.x) ;
                        tc = yValForPolynomial(deramping->tcPol, (double)p2.x) ;
//                        dc = yValForPolynomial(deramping->dcPol, (double)p2.x) ;

//                        rampPhase = -1. * PI * kt * pow(azimuthTime - tc, 2.) - TWOPI * dc * (azimuthTime - tc) ;
                        rampPhase = -1. * PI * kt * pow(azimuthTime - tc, 2.) ;

                        if (info->flag & _SQUINT_PHASE_REMOVAL_) {
                            squintAngle = asin(-1 * info->wavelength / 2. * kt * (azimuthTime - tc) / aStateVector->velocity) ;
                            z1 = info->slantRange[0] + (p2.x + currentBurst->firstRangeIndex) * info->rangeResolutionCell ;
                            squintPhase = -4 * PI / info->wavelength * z1 * (1. / cos(squintAngle) - 1.) ;

                            rampPhase = squintPhase ;
                        }
                        derampingFactor.r = cosf(rampPhase) ;
                        derampingFactor.i = sinf(rampPhase) ;
                        burst[iY][iX] = mC(burst[iY][iX], derampingFactor) ;
                    }
                }

                /* Save deramped burst */
                rewind(outputBurstFile->f) ;
                fwrite(burst[0], sizeof(complexFloat), currentBurst->xDim * currentBurst->yDim, outputBurstFile->f) ;
                freeMatrixComplexFloat(burst, 0, 0) ;

                if (masterSpecific) {
                    currentMasterBurst = currentMasterBurst->nextBurst ;
                }
                if (!(currentBurst = currentBurst->nextBurst)) {
                    break ;
                }
            }
        }
    }
    
    for (ompIndex = 0; ompIndex < nThreads; ompIndex++) {
        freeStateVector(ppStateVector[ompIndex]) ;
    }
    free(ppStateVector) ;
    freeCSVStruct(csv) ;
    freeMatrixDouble(affineTransform, 0, 0) ;
}


void burstDeramping(burstDescriptor *currentBurst, SLCImageInfo *info, SLCImageInfo *masterInfo)
{
    int unsigned iX, iY, swathIndex ;
    double rampPhase, azimuthTime ;
    double kt, tc, dc ;
    double **affineTransform ;
    coord2D p1, p2 ; ;
    complexFloat **burst ;
    complexFloat derampingFactor ;
    derampingStructType *deramping ;
    rawFileDescriptor *outputBurstFile = NULL ;

    affineTransform = matrixDouble(0, 1, 0, 2) ;

    /* Allocate burst */
    burst = matrixComplexFloat(0, currentBurst->yDim - 1, 0, currentBurst->xDim - 1) ;

    for (swathIndex = 0; swathIndex < currentBurst->numberOfLayers; swathIndex++) {
        /* Rewind burst file */
        outputBurstFile = currentBurst->file[swathIndex] ;
        rewind(outputBurstFile->f) ;

        /* Read burst */
        fread(burst[0], sizeof(complexFloat), currentBurst->xDim * currentBurst->yDim, outputBurstFile->f) ;

        /* Update interpolation transfrom for burst under concern */
        if (masterInfo != NULL) {
            memcpy(affineTransform[0], currentBurst->T[0], 6 * sizeof(double)) ;
        }

        deramping = currentBurst->deramping ;
        /* Deramp burst */
        for (iY = 0; iY < currentBurst->yDim; iY++) {
            p1.y = p2.y = (double)iY ;
            azimuthTime = currentBurst->FPAT + iY * info->lineTimeInterval - deramping->t0 ;
            for (iX = 0; iX < currentBurst->xDim; iX++) {
                /* Compute range - azimuth position */
                p1.x = p2.x = (double)iX ;
                if (masterInfo != NULL) {
                    planeAffineTransformOfCoord2D(&p1, &p2, affineTransform) ;
                    azimuthTime = currentBurst->FPAT + p2.y * info->lineTimeInterval - deramping->t0 ;
                }

                /* Compute parameters for the corresponding position */
                kt = yValForPolynomial(deramping->ktPol, (double)iX) ;
                tc = yValForPolynomial(deramping->tcPol, (double)iX) ;
                dc = yValForPolynomial(deramping->dcPol, (double)iX) ;

                rampPhase = -1. * PI * kt * pow(azimuthTime - tc, 2.) - TWOPI * dc * (azimuthTime - tc) ;

                derampingFactor.r = cosf(rampPhase) ;
                derampingFactor.i = sinf(rampPhase) ;
                burst[iY][iX] = mC(burst[iY][iX], derampingFactor) ;
            }
        }

        /* Save read and deramped burst line */
        rewind(outputBurstFile->f) ;
        fwrite(burst[0], sizeof(complexFloat), currentBurst->xDim * currentBurst->yDim, outputBurstFile->f) ;
    }
    freeMatrixComplexFloat(burst, 0, 0) ;
    freeMatrixDouble(affineTransform, 0, 0) ;
}


/* Burst reramping function */
/* If a master image info pointer is provided, it is supposed we deal with a coregistered slave image; in whitch case slave affine transform is taken into account */
void burstsReramping(SLCImageInfo *info, SLCImageInfo *masterInfo)
{
    int unsigned swathIndex, layerIndex ;
    int unsigned iX, iY ;
    double rampPhase, azimuthTime ;
    double kt, tc ;
    double **affineTransform ;
    coord2D p1, p2 ; ;
    S1AdditionalInfo *S1Specific ;
    rawFileDescriptor *outputBurstFile = NULL ;
    CSVStruct *csv ;
    complexFloat **burst ;
    complexFloat derampingFactor ;
    derampingStructType *deramping ;
    burstDescriptor *currentBurst ;


    S1Specific = info->sensorSpecificInfo ;
    affineTransform = matrixDouble(0, 1, 0, 2) ;

    /* Read number of layers */
    csv = readCSVInString(info->polMode) ;

    /* loop on layers */
    for (layerIndex = 0; layerIndex < info->numberOfLayers; layerIndex++) {
        printf("\nBursts re-ramping - Sentinel 1 %d data: %s polarization layer\n", info->relativeOrbitNumber, csv->stringVal[layerIndex]) ;
        /* Loop on swath */
        for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
            printf("\tSwath %d\n", swathIndex) ;

            currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
            while (currentBurst->isSelected) {
                printf("\t\tRe-ramping burst %d of swath %d\n", currentBurst->burstIndex, swathIndex) ;

                /* Allocate burst */
                burst = matrixComplexFloat(0, currentBurst->yDim - 1, 0, currentBurst->xDim - 1) ;

                /* Rewind burst file */
                outputBurstFile = currentBurst->file[layerIndex] ;
                rewind(outputBurstFile->f) ;

                /* Read burst */
                fread(burst[0], sizeof(complexFloat), currentBurst->xDim * currentBurst->yDim, outputBurstFile->f) ;

                /* Update interpolation transfrom for burst under concern */
                if (masterInfo != NULL) {
                    memcpy(affineTransform[0], currentBurst->T[0], 6 * sizeof(double)) ;
                }

                deramping = currentBurst->deramping ;

#pragma omp parallel num_threads(maxThreads)
#pragma omp for schedule(auto) private(p1, p2, azimuthTime, iX, kt, tc, rampPhase, derampingFactor)
//#pragma omp for schedule(auto) private(p1, p2, azimuthTime, iX, kt, tc, dc, rampPhase, derampingFactor)

                /* Reramp burst */
                for (iY = 0; iY < currentBurst->yDim; iY++) {
                    p1.y = p2.y = (double)iY ;
                    azimuthTime = currentBurst->FPAT + iY * info->lineTimeInterval - deramping->t0 ;
                    for (iX = 0; iX < currentBurst->xDim; iX++) {
                        /* Compute initial range - azimuth position */
                        p1.x = p2.x = (double)iX ;
                        if (masterInfo != NULL) {
                            planeAffineTransformOfCoord2D(&p1, &p2, affineTransform) ;
                            azimuthTime = currentBurst->FPAT + p2.y * info->lineTimeInterval - deramping->t0 ;
                        }

                        /* Compute parameters for the corresponding position */
                        kt = yValForPolynomial(deramping->ktPol, p2.x) ;
                        tc = yValForPolynomial(deramping->tcPol, p2.x) ;
//                        dc = yValForPolynomial(deramping->dcPol, p2.x) ;
//                        rampPhase = +1. * PI * kt * pow(azimuthTime - tc, 2.) + TWOPI * dc * (azimuthTime - tc) ;

                        rampPhase = +1. * PI * kt * pow(azimuthTime - tc, 2.) ;

                        derampingFactor.r = cosf(rampPhase) ;
                        derampingFactor.i = sinf(rampPhase) ;
                        burst[iY][iX] = mC(burst[iY][iX], derampingFactor) ;
                    }
                }

                /* Save re-ramped burst */
                rewind(outputBurstFile->f) ;
                fwrite(burst[0], sizeof(complexFloat), currentBurst->xDim * currentBurst->yDim, outputBurstFile->f) ;
                freeMatrixComplexFloat(burst, 0, 0) ;

                if (!(currentBurst = currentBurst->nextBurst)) {
                    break ;
                }
            }
        }
    }

    freeCSVStruct(csv) ;
    freeMatrixDouble(affineTransform, 0, 0) ;
}




char InSARBurstSelection(InSARParametersStruct *pInSAR)
{
    char isModified = 0 ;
    int unsigned swathIndex, thisSwathBurstCount, numberOfSelectedBursts ;
    int test ;
    S1AdditionalInfo *masterSpecific, *slaveSpecific ;
    coord2D aPoint ;
    burstDescriptor *masterBurst, *slaveBurst, *firstSlaveBurst, *firstMasterBurst ;
    burstDescriptor *lastSlaveBurst = NULL, *lastMasterBurst ;

    masterSpecific = (S1AdditionalInfo *)pInSAR->masterInfo->sensorSpecificInfo ;
    slaveSpecific = (S1AdditionalInfo *)pInSAR->slaveInfo->sensorSpecificInfo ;

    /* Reinit anxFPAT to recompute it for selected bursts */
    masterSpecific->anxFPAT = slaveSpecific->anxFPAT = 86400 ;

    for (swathIndex = 0; swathIndex < masterSpecific->numberOfSubSwaths; swathIndex++) {
        /* Re-init slave burst selection to 0 */
        if((firstSlaveBurst = getFirstSelectedBurstInList(slaveSpecific->burstList[swathIndex]))) {
            lastSlaveBurst = getLastSelectedBurstInList(slaveSpecific->burstList[swathIndex]) ;

            slaveBurst = firstSlaveBurst ;
            do {
                slaveBurst->isSelected = 0 ;
            } while ((slaveBurst != lastSlaveBurst) && (slaveBurst = slaveBurst->nextBurst));
        }
        /* Re-init master burst selection to 0 */
        thisSwathBurstCount = 0 ;
        if((firstMasterBurst = getFirstSelectedBurstInList(masterSpecific->burstList[swathIndex]))) {
            lastMasterBurst = getLastSelectedBurstInList(masterSpecific->burstList[swathIndex]) ;

            masterBurst = firstMasterBurst ;
            do {
                thisSwathBurstCount += (masterBurst->isSelected)? 1 : 0 ;
                masterBurst->isSelected = 0 ;
            } while ((masterBurst != lastMasterBurst) && (masterBurst = masterBurst->nextBurst));
        }

        if ((masterBurst = firstMasterBurst) && firstSlaveBurst) {
            numberOfSelectedBursts = 0 ;
            do {
                /* Re-init master burst selection to 0 */
                masterBurst->isSelected = 0 ;
                masterBurst->slaveBurst = masterBurst->masterBurst = NULL ;
                slaveBurst->slaveBurst = slaveBurst->masterBurst = NULL ;

                /* Compute location of central point of master burst */
                aPoint.x = (masterBurst->burstLocation->P[2].x + masterBurst->burstLocation->P[0].x) / 2. ;
                aPoint.y = (masterBurst->burstLocation->P[2].y + masterBurst->burstLocation->P[0].y) / 2. ;

                /* Test common burst superpositions */
                if ((slaveBurst = firstSlaveBurst)) {
                    do {
                        test = isPointIncludedInPolygon(&aPoint, slaveBurst->burstLocation) ;
                        masterBurst->isSelected |= test ;
                        slaveBurst->isSelected |= test ;
                        if (masterBurst->isSelected && !masterBurst->slaveBurst) {
                            masterBurst->slaveBurst = slaveBurst ;
                            slaveBurst->masterBurst = masterBurst ;
                            numberOfSelectedBursts += 1 ;
                        }
                    } while ((slaveBurst != lastSlaveBurst) && (slaveBurst = slaveBurst->nextBurst));
                }
            } while ((masterBurst != lastMasterBurst) && (masterBurst = masterBurst->nextBurst));
            isModified |= (numberOfSelectedBursts == thisSwathBurstCount)? 0 : 1 ;
        }
        else {
            isModified |= (!firstMasterBurst && !firstSlaveBurst)? 0 : 1 ;
        }
    }
    /* Update slave image anyway with respect to burst selection, in case master is smaller than slave */
    updateSpecificFieldsForSelectedBursts(pInSAR->slaveInfo) ;

    return (isModified) ;
}


void initPerBurstTransforms(InSARParametersStruct *pInSAR)
{
    int unsigned swathIndex, burstIndexShift ;
    double dxMaster, dxSlave, dyMaster, dySlave ;
    double **T ;
    polygon *burstAoI, *imageAoI ;
    S1AdditionalInfo *slaveSpecific, *masterSpecific ;
    burstDescriptor *slaveBurst, *masterBurst ;

    imageAoI = pInSAR->aoi ;
    pInSAR->aoi = burstAoI = allocPolygon(4) ;

    /* We are working on burst selection. Available transform was already computed for the whole scene selection */
    masterSpecific = pInSAR->masterInfo->sensorSpecificInfo ;
    slaveSpecific = pInSAR->interpolatedSlaveInfo->sensorSpecificInfo ;


    for (swathIndex = slaveSpecific->firstSwathIndex; swathIndex <= slaveSpecific->lastSwathIndex; swathIndex++) {
        slaveBurst = getFirstSelectedBurstInList(slaveSpecific->burstList[swathIndex]) ;
        masterBurst = getFirstSelectedBurstInList(masterSpecific->burstList[swathIndex]) ;

        /* We must take into account for the burst index shift, i.e. the fact that the firstBurstIndex is not necessarily the same in both images */
        burstIndexShift = masterBurst->burstIndex - slaveBurst->burstIndex ;
        while (slaveBurst->isSelected) {
            /* Get master burst corresponding to slave one */
            masterBurst = getBurstAtIndex(masterSpecific->burstList[swathIndex], slaveBurst->burstIndex + burstIndexShift) ;

            /* Check if burst are associated */
            if (!masterBurst->slaveBurst || !slaveBurst->slaveBurst) {
                masterBurst->slaveBurst = slaveBurst ;
                slaveBurst->masterBurst = masterBurst ;
            }
            
            /* First, we recompute the affine transform limiting the area of interest to the burst under concern */
            burstAoI->P[0].x = burstAoI->P[3].x = masterSpecific->firstRangePixelIndexForSubSwath[swathIndex] - masterSpecific->rangeIndexStart + masterBurst->rangeShift ;
            burstAoI->P[1].x = burstAoI->P[2].x = masterSpecific->lastRangePixelIndexForSubSwath[swathIndex] - masterSpecific->rangeIndexStart + masterBurst->rangeShift ;
            burstAoI->P[0].y = burstAoI->P[1].y = masterBurst->firstAzimuthIndex ;
            burstAoI->P[2].y = burstAoI->P[3].y = masterBurst->lastAzimuthIndex ;

            computeBaseLine(pInSAR) ;

            /* Then, we copy this global transform as the one valid for the selected burst */
            if (!slaveBurst->T) {
                slaveBurst->T = matrixDouble(0, 1, 0, 2) ;
            }
            memcpy(slaveBurst->T[0], pInSAR->slaveAffineTransform[0], 6 * sizeof(double)) ;

            /* Then we translate it to take into account master burst shift with respect to scene area */
            /* Scene starts at master->azimuthIndexStart, which corresponds to the First Pixel Azimuth Time of the master image */
            /* InSAR transform was computed with respect to burst selection */
            /* Consequently, we have to correct the firstRangeIndexForSubSwath and subtract the rangeIndexStart (which is the firstRangeIndexForSubSwath value of the first read Swath */
            dxMaster = masterSpecific->firstRangePixelIndexForSubSwath[swathIndex] - masterSpecific->rangeIndexStart + masterBurst->rangeShift ;
            dyMaster = masterBurst->firstAzimuthIndex - masterSpecific->azimuthIndexStart ;
            translateAffineTransform(slaveBurst->T, dxMaster, dyMaster) ;

            /* Since we work with bursts selection, one must account for global shift of slave burst within master full image frame */
            dxSlave = slaveSpecific->firstRangePixelIndexForSubSwath[swathIndex] - slaveSpecific->rangeIndexStart + slaveBurst->rangeShift ;
            dySlave = slaveBurst->firstAzimuthIndex - slaveSpecific->azimuthIndexStart ;
            slaveBurst->T[0][2] -= dxSlave - dxMaster ;
            slaveBurst->T[1][2] -= dySlave - dyMaster ;
            
            /* If we deal with a super master image, take super master to master transform into account */
            if (slaveBurst->masterBurst->T) {
                slaveBurst->masterBurst->T[0][2] += slaveBurst->masterBurst->rangeTransformConstantTerm ;
                T = combinedAffineTransform(slaveBurst->T, slaveBurst->masterBurst->T) ;
                freeMatrixDouble(slaveBurst->T, 0, 0) ;
                slaveBurst->T = T ;
                slaveBurst->masterBurst->T[0][2] -= slaveBurst->masterBurst->rangeTransformConstantTerm ;
            }
            slaveBurst->rangeTransformConstantTerm = floor(slaveBurst->T[0][2]) ;
            slaveBurst->T[0][2] -= slaveBurst->rangeTransformConstantTerm ;

            slaveBurst->T[0][2] += pInSAR->xShift ;
            slaveBurst->T[1][2] += pInSAR->yShift ;


            if (!(slaveBurst = slaveBurst->nextBurst)) {
                break ;
            }
        }
    }
    /* Restore initial area of interest and corresponding baseline parameters */
    freePolygon(pInSAR->aoi) ;
    pInSAR->aoi = imageAoI ;
    computeBaseLine(pInSAR) ;

}

/* Initialization of per-burst shift transforms that are used in coherence tracking processing */
void initPerBurstShiftTransforms(InSARParametersStruct *pInSAR)
{
    int unsigned swathIndex ;
    S1AdditionalInfo *slaveSpecific ;
    burstDescriptor *slaveBurst ;

    slaveSpecific = pInSAR->interpolatedSlaveInfo->sensorSpecificInfo ;

    for (swathIndex = slaveSpecific->firstSwathIndex; swathIndex <= slaveSpecific->lastSwathIndex; swathIndex++) {
        slaveBurst = getFirstSelectedBurstInList(slaveSpecific->burstList[swathIndex]) ;

        while (slaveBurst->isSelected) {
            if (slaveBurst->T) {
                freeMatrixDouble(slaveBurst->T, 0, 0) ;
            }
            slaveBurst->T = allocUnitaryAffineTransform() ;
            slaveBurst->T[0][2] = pInSAR->xShift ;
            slaveBurst->T[1][2] = pInSAR->yShift ;

            if (!(slaveBurst = slaveBurst->nextBurst)) {
                break ;
            }
        }
    }
}


/* After coregistration, azimuth index start of both images are identical */
void alignSlaveImage(InSARParametersStruct *pInSAR)
{
    int unsigned swathIndex ;
    int unsigned upShift ; 
    int rangeShift, azimuthShift, lineIndex ;
    double timeShift ;
    S1AdditionalInfo *slaveSpecific, *masterSpecific ;
    burstDescriptor *slaveBurst, *masterBurst ;

    if (pInSAR->interpolatedSlaveInfo->superMasterInfo) {
        masterSpecific = pInSAR->interpolatedSlaveInfo->superMasterInfo->sensorSpecificInfo ;
    }
    else {
        masterSpecific = pInSAR->masterInfo->sensorSpecificInfo ;
    }
    slaveSpecific = pInSAR->interpolatedSlaveInfo->sensorSpecificInfo ;

    slaveSpecific->rangeIndexStart = masterSpecific->rangeIndexStart ;
    slaveSpecific->azimuthIndexEnd += masterSpecific->azimuthIndexStart - slaveSpecific->azimuthIndexStart ;
    slaveSpecific->azimuthIndexStart = masterSpecific->azimuthIndexStart ;


    for (swathIndex = slaveSpecific->firstSwathIndex; swathIndex <= slaveSpecific->lastSwathIndex; swathIndex++) {
        slaveSpecific->firstValidSampleForSubSwath[swathIndex] = masterSpecific->firstValidSampleForSubSwath[swathIndex] ;
        slaveSpecific->superpositionStartIndex[swathIndex] = masterSpecific->superpositionStartIndex[swathIndex] ;
        slaveSpecific->superpositionWidth[swathIndex] = masterSpecific->superpositionWidth[swathIndex] ;
        slaveSpecific->nearRangeTime[swathIndex] = masterSpecific->nearRangeTime[swathIndex] ;
        slaveSpecific->firstRangePixelIndexForSubSwath[swathIndex] = masterSpecific->firstRangePixelIndexForSubSwath[swathIndex] ;
        
        azimuthShift = slaveSpecific->firstAzimuthLineIndexForSubSwath[swathIndex] - masterSpecific->firstAzimuthLineIndexForSubSwath[swathIndex] ;
        slaveSpecific->firstAzimuthLineIndexForSubSwath[swathIndex] -= azimuthShift ;
        slaveSpecific->lastAzimuthLineIndexForSubSwath[swathIndex] -= azimuthShift ;
        
        masterBurst = getFirstSelectedBurstInList(masterSpecific->burstList[swathIndex]) ;
        slaveBurst = getFirstSelectedBurstInList(slaveSpecific->burstList[swathIndex]) ;
        slaveSpecific->nearRangeTime[swathIndex] = masterSpecific->nearRangeTime[swathIndex] ;
        slaveSpecific->nearRangeTime[swathIndex] = masterSpecific->nearRangeTime[swathIndex] ;

        while (slaveBurst->isSelected) {
            slaveBurst->lastRangeIndex += masterBurst->firstRangeIndex - slaveBurst->firstRangeIndex ;
            slaveBurst->firstRangeIndex = masterBurst->firstRangeIndex ;
            rangeShift = slaveBurst->rangeShift = masterBurst->rangeShift ;
            
            slaveBurst->firstValidSample = slaveBurst->firstValidSample - slaveBurst->rangeShift - slaveBurst->rangeTransformConstantTerm ;
            slaveBurst->firstValidSample = masterBurst->firstValidSample = MAX(slaveBurst->firstValidSample, masterBurst->firstValidSample) ;
            slaveBurst->lastValidSample = slaveBurst->lastValidSample - slaveBurst->rangeShift - slaveBurst->rangeTransformConstantTerm ;
            slaveBurst->lastValidSample = masterBurst->lastValidSample = MIN(slaveBurst->lastValidSample, masterBurst->lastValidSample) ;

            azimuthShift = slaveBurst->firstAzimuthIndex - masterBurst->firstAzimuthIndex ;
            slaveBurst->firstAzimuthIndex -= azimuthShift ;
            slaveBurst->lastAzimuthIndex -= azimuthShift ;

            slaveBurst->superpositionAzimuthIndex -= azimuthShift ;
            slaveBurst->midSuperpositionAzimuthIndex -= azimuthShift ;

            timeShift = masterBurst->FPAT - slaveBurst->FPAT ;
            slaveBurst->FPAT = masterBurst->FPAT ;
            slaveBurst->MPAT += timeShift ;
            slaveBurst->LPAT += timeShift ;

            azimuthShift = (int)rint(slaveBurst->T[1][2]) ;
            if (azimuthShift > 0) {
                for (lineIndex = 0; lineIndex < (int)slaveBurst->yDim - azimuthShift; lineIndex++) {
                    if (slaveBurst->firstValidSampleOfLine[lineIndex + azimuthShift] == -1) {
                        slaveBurst->firstValidSampleOfLine[lineIndex] = -1 ;
                    }
                    else {
                        slaveBurst->firstValidSampleOfLine[lineIndex] = slaveBurst->firstValidSampleOfLine[lineIndex + azimuthShift] - rangeShift ;
                        slaveBurst->firstValidSampleOfLine[lineIndex] = (slaveBurst->firstValidSampleOfLine[lineIndex] < 0)? 0 : slaveBurst->firstValidSampleOfLine[lineIndex] ;
                    }
                    if (slaveBurst->lastValidSampleOfLine[lineIndex + azimuthShift] == -1) {
                        slaveBurst->lastValidSampleOfLine[lineIndex] = -1 ;
                    }
                    else {
                        slaveBurst->lastValidSampleOfLine[lineIndex] = slaveBurst->lastValidSampleOfLine[lineIndex + azimuthShift] - rangeShift ;
                        slaveBurst->lastValidSampleOfLine[lineIndex] = (slaveBurst->lastValidSampleOfLine[lineIndex] >= (int)(slaveBurst->xDim))? (int)(slaveBurst->xDim - 1) : slaveBurst->lastValidSampleOfLine[lineIndex] ;
                    }
                }
                for (; lineIndex < (int)slaveBurst->yDim; lineIndex++) {
                    slaveBurst->firstValidSampleOfLine[lineIndex] = slaveBurst->lastValidSampleOfLine[lineIndex] =  - 1 ;
                }
            }
            else {
                if (azimuthShift) {                    
                    for (lineIndex = (int)slaveBurst->yDim - 1; lineIndex >= -azimuthShift; lineIndex--) {
                        if (slaveBurst->firstValidSampleOfLine[lineIndex + azimuthShift] == -1) {
                            slaveBurst->firstValidSampleOfLine[lineIndex] = -1 ;
                        }
                        else {
                            slaveBurst->firstValidSampleOfLine[lineIndex] = slaveBurst->firstValidSampleOfLine[lineIndex + azimuthShift] - rangeShift ;
                            slaveBurst->firstValidSampleOfLine[lineIndex] = (slaveBurst->firstValidSampleOfLine[lineIndex] < 0)? 0 : slaveBurst->firstValidSampleOfLine[lineIndex] ;
                        }
                        if (slaveBurst->lastValidSampleOfLine[lineIndex + azimuthShift] == -1) {
                            slaveBurst->lastValidSampleOfLine[lineIndex] =  -1 ;
                        }
                        else {
                            slaveBurst->lastValidSampleOfLine[lineIndex] = slaveBurst->lastValidSampleOfLine[lineIndex + azimuthShift] - rangeShift ;
                            slaveBurst->lastValidSampleOfLine[lineIndex] = (slaveBurst->lastValidSampleOfLine[lineIndex] >= (int)slaveBurst->xDim)? (int)slaveBurst->xDim - 1 : slaveBurst->lastValidSampleOfLine[lineIndex] ;
                        }
                    }
                    for (; lineIndex >= 0; lineIndex--) {
                        slaveBurst->firstValidSampleOfLine[lineIndex] = slaveBurst->lastValidSampleOfLine[lineIndex] =  - 1 ;
                    }  
                }            
            }

            /* Mid azimuth superposition indexes must be equal to avoid mixing up and down bursts lines */
            slaveBurst->midSuperpositionAzimuthIndex = masterBurst->midSuperpositionAzimuthIndex = (masterBurst->midSuperpositionAzimuthIndex + slaveBurst->midSuperpositionAzimuthIndex) / 2 ;
            if (!slaveBurst->nextBurst || !slaveBurst->nextBurst->isSelected) {
                slaveBurst->midSuperpositionAzimuthIndex = slaveBurst->lastAzimuthIndex + 1 ;
                masterBurst->midSuperpositionAzimuthIndex = masterBurst->lastAzimuthIndex + 1 ;
            }

            masterBurst = masterBurst->nextBurst ;
            if (!(slaveBurst = slaveBurst->nextBurst)) {
                break ;
            }

        }
    }
}






void copyMasterImageToDestination(InSARParametersStruct *pInSAR)
{
    char *aFileName, *initialMasterImageLocation, *newMasterImageLocation = NULL, *infoImageFilePath, *masterInfoFilePath ;
    char *sourceFilePath, *destFilePath, isFrameSelected ;
    char *selectedPolarization ;
    int frameIndex, numberOfFrames ;
    int unsigned swathIndex ;
    int xyShift, initialRangeIndexStart ;
    double FPAT0 ;
    CSLImage *destinationImageContainer, *destinationFrame, *sourceFrame ;
    SLCImageInfo *destinationInfo ;
    S1AdditionalInfo *S1FrameSpecific, *S1ImageSpecific ;
    burstDescriptor *frameBurst, *sourceBurst = NULL ;
    keyValue *externalDEMParams ;

    S1ImageSpecific = pInSAR->masterInfo->sensorSpecificInfo ;
    selectedPolarization = initStringWithString(pInSAR->masterInfo->polMode) ;

    /* We store FPAT and LPAT of master image to correct DEM location correspondingly if required */
    FPAT0 = S1ImageSpecific->FPAT ;
    initialRangeIndexStart = S1ImageSpecific->rangeIndexStart ;

    /* Since some bursts were specifically selected for InSAR processing, update fields correspondingly */
    updateSpecificFieldsForSelectedBursts(pInSAR->masterInfo) ;
    pInSAR->ima1.lena = pInSAR->masterInfo->azimuthDimension ;
    pInSAR->ima1.lenr = pInSAR->masterInfo->rangeDimension ;

    /* Save initial location */
    initialMasterImageLocation = initStringWithString(pInSAR->masterImage->imageDirectoryPath) ;

    /* Create destination path */
    aFileName = getPointerToFileNameInPath(initialMasterImageLocation) ;
    newMasterImageLocation = initStringWith3Strings(pInSAR->whereAmI,"InSARProducts/", aFileName) ;

    /* Copy master image structure to destination */
    printf("\nCopy master image structure to working directory: %s\n", newMasterImageLocation) ;
    copyCSLImage(initialMasterImageLocation, newMasterImageLocation, _CSLIMAGE_HEADERS_ | _CSLIMAGE_OVERWRITE_) ;

    /* Save updated masterInfoImage for each frames taking into account InSAR burst selection */
    destinationImageContainer = getCSLImageStructureAtPath(newMasterImageLocation) ;
    numberOfFrames = getNumberOfFramesInCSLImage(destinationImageContainer) ;

    /* For each frame */
    for (frameIndex = 0; frameIndex < numberOfFrames; frameIndex++) {
        /* Read and init destination frame info using source frame info */
        sprintf(accessPath, "%s/Frame%1d.csl", pInSAR->masterImage->dataDirectoryPath, frameIndex) ;
        sourceFrame = getCSLImageStructureAtPath(accessPath) ;
        destinationInfo = readInfoImageInCSLImage(sourceFrame) ;
        S1FrameSpecific = initS1SpecificInfo(destinationInfo, sourceFrame->imageDirectoryPath) ;

        /* Select only requested polarization */
        sprintf(destinationInfo->polMode, "%s", selectedPolarization) ;
        S1FrameSpecific->numberOfLayers = destinationInfo->numberOfLayers = pInSAR->masterInfo->numberOfLayers ;

        /* Adapt burst selection to InSAR burst selection */
        isFrameSelected = 0 ;
        for (swathIndex = 0; swathIndex < S1FrameSpecific->numberOfSubSwaths; swathIndex++) {
            if ((frameBurst = S1FrameSpecific->burstList[swathIndex])) {
                sourceBurst = getFirstBurstOfFrameInList(S1ImageSpecific->burstList[swathIndex], frameIndex) ;
            }
            while (frameBurst) {
                frameBurst->isSelected = sourceBurst->isSelected ;
                isFrameSelected = (frameBurst->isSelected) ? 1 : isFrameSelected ;

                frameBurst = frameBurst->nextBurst ;
                sourceBurst = sourceBurst->nextBurst ;
            }
        }

        sprintf(accessPath, "%s/Frame%1d.csl", destinationImageContainer->dataDirectoryPath, frameIndex) ;
        destinationFrame = getCSLImageStructureAtPath(accessPath) ;
        if (isFrameSelected) {
            updateSpecificFieldsForSelectedBursts(destinationInfo) ;
            openBurstFilesForReadingAndWriting(destinationFrame, destinationInfo) ;

            /* Save frame infoImage in destination frame */
            infoImageFilePath = initStringWith2Strings(destinationFrame->infoDirectoryPath, "/SLCImageInfo.txt") ;
            saveS1InfoImage(destinationInfo, infoImageFilePath) ;
            free(infoImageFilePath) ;
        }
        else {
            sprintf(accessPath, "%s/burstSelection.txt", destinationFrame->infoDirectoryPath) ;
            unlink(accessPath) ;
        }

        freeCSLImageStructure(sourceFrame) ;
        freeCSLImageStructure(destinationFrame) ;
        freeS1Specific(S1FrameSpecific, _S1_TRASH_BURSTS_) ;
        freeInfoImage(destinationInfo) ;
    }

    infoImageFilePath = initStringWith2Strings(destinationImageContainer->infoDirectoryPath, "/SLCImageInfo.txt") ;
    masterInfoFilePath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/masterSLCImageInfo.txt") ;
    saveS1InfoImage(pInSAR->masterInfo, infoImageFilePath) ;
    copyFileAtPathToPath(infoImageFilePath, masterInfoFilePath) ;
    free(masterInfoFilePath) ;

    /* Copy selected master burst data to new location */
    copyCSLImage(initialMasterImageLocation, newMasterImageLocation, _CSLIMAGE_OVERWRITE_ | _CSLIMAGE_SELECTED_BURSTS_OUT_) ;

    /* Make link to external DEM if present */
    sourceFilePath = initStringWith2Strings(pInSAR->masterImage->dataDirectoryPath, "/externalSlantRangeDEM") ;
    if (fileExistsAtPath(sourceFilePath)) {
        destFilePath = initStringWith2Strings(destinationImageContainer->dataDirectoryPath, "/externalSlantRangeDEM") ;
        if (fileExistsAtPath(destFilePath)) {
            unlink(destFilePath) ;
        }
        if (symlink(sourceFilePath, destFilePath)) {
            ase("\n\t\t-/-> Failed to create link to external DEM file contained in original master image\n") ;
        }
        free(destFilePath) ;
        free(sourceFilePath) ;

        /* Make link to mask if present */
        sourceFilePath = initStringWith2Strings(pInSAR->masterImage->dataDirectoryPath, "/slantRangeMask") ;
        if (fileExistsAtPath(sourceFilePath)) {
            destFilePath = initStringWith2Strings(destinationImageContainer->dataDirectoryPath, "/slantRangeMask") ;
            if (fileExistsAtPath(destFilePath)) {
                unlink(destFilePath) ;
            }
            if (symlink(sourceFilePath, destFilePath)) {
                ase("\n\t\t-/-> Failed to create link to slantRangeMask file contained in original master image\n") ;
            }
            free(destFilePath) ;
        }                       
        free(sourceFilePath) ;

        /* Copy and adapt description text file */
        sourceFilePath = initStringWith2Strings(pInSAR->masterImage->infoDirectoryPath, "/externalSlantRangeDEM.txt") ;
        destFilePath = initStringWith2Strings(newMasterImageLocation, "/Info/externalSlantRangeDEM.txt") ;
        copyFileAtPathToPath(sourceFilePath, destFilePath) ;

        externalDEMParams = readParameterFileAtPath(destFilePath) ;
        xyShift = getIntValForKeyIn(externalDEMParams, "xMin") ;
        xyShift -= (S1ImageSpecific->rangeIndexStart - initialRangeIndexStart) ;
        setIntValForKeyIn(externalDEMParams, xyShift, "xMin") ;
        xyShift = getIntValForKeyIn(externalDEMParams, "xMax") ;
        xyShift -= (S1ImageSpecific->rangeIndexStart - initialRangeIndexStart) ;
        setIntValForKeyIn(externalDEMParams, xyShift, "xMax") ;
        
        xyShift = getIntValForKeyIn(externalDEMParams, "yMin") ;
        xyShift -= (int)roundl((S1ImageSpecific->FPAT - FPAT0) / S1ImageSpecific->lineTimeInterval) ;
        setIntValForKeyIn(externalDEMParams, xyShift, "yMin") ;
        xyShift = getIntValForKeyIn(externalDEMParams, "yMax") ;
        xyShift -= (int)roundl((S1ImageSpecific->FPAT - FPAT0) / S1ImageSpecific->lineTimeInterval) ;
        setIntValForKeyIn(externalDEMParams, xyShift, "yMax") ;
        writeParameterFileAtPath(externalDEMParams, destFilePath) ;

        freeKeyValueList(externalDEMParams) ;
        free(destFilePath) ;
    }
    free(sourceFilePath) ;

    /* Free initial CSL image structure */
    freeCSLImageStructure(pInSAR->masterImage) ;
    freeS1Specific(S1ImageSpecific, _S1_TRASH_BURSTS_) ;
    freeInfoImage(pInSAR->masterInfo) ;
    freeCSLImageStructure(destinationImageContainer) ;

    /* Read new CSL image structure */
    pInSAR->masterImage = getCSLImageStructureAtPath(newMasterImageLocation) ;
    removeEmptyFramesInCSLImage(pInSAR->masterImage) ;

    /* Re-intentiate infoImage for copied master image */
    pInSAR->masterInfo = mergeFrameInfo(pInSAR->masterImage, selectedPolarization) ;

    /* Re-initiate georef structure to take new master info into account */
    initInSAR_GEO(pInSAR, _KEEPAOI_) ;

    free(selectedPolarization) ;
}

void copySlaveImageToDestination(InSARParametersStruct *pInSAR)
{
    char *initialSlaveImageLocation, *newSlaveImageLocation = NULL, *infoImageFilePath, *slaveInfoFilePath ;
    char frameName[16], *inputFramePath, *outputFramePath ;
    char *selectedPolarization ;
    char isFrameSelected ;
    int frameIndex, numberOfFrames ;
    int unsigned swathIndex ;
    CSLImage *destinationImageContainer, *destinationFrame, *sourceFrame ;
    SLCImageInfo *frameInfo ;
    S1AdditionalInfo *S1FrameSpecific, *S1ImageSpecific, *slaveSpecific, *masterSpecific ;
    burstDescriptor *frameBurst, *sourceBurst = NULL, *slaveBurst, *masterBurst ;

    masterSpecific = pInSAR->masterInfo->sensorSpecificInfo ;
    S1ImageSpecific = pInSAR->slaveInfo->sensorSpecificInfo ;
    selectedPolarization = initStringWithString(pInSAR->slaveInfo->polMode) ;

    /* Save initial location */
    initialSlaveImageLocation = initStringWithString(pInSAR->slaveImage->imageDirectoryPath) ;

    /* Create destination path if required */
    newSlaveImageLocation = initStringWithString(pInSAR->interpolatedSlave->imageDirectoryPath) ;

    /* Copy slave image to destination */
    printf("\nCopy slave image to working directory: %s\n", newSlaveImageLocation) ;
    copyCSLImage(initialSlaveImageLocation, newSlaveImageLocation, _CSLIMAGE_HEADERS_ | _CSLIMAGE_INFO_ | _CSLIMAGE_OVERWRITE_) ;

    /* Save updated slaveInfoImage for each frames taking into account InSAR burst selection */
    destinationImageContainer = getCSLImageStructureAtPath(newSlaveImageLocation) ;
    numberOfFrames = getNumberOfFramesInCSLImage(destinationImageContainer) ;
    /* For each frame */
    for (frameIndex = 0; frameIndex < numberOfFrames; frameIndex++) {
        /* Read and init destination frame info using source frame info */
        sprintf(frameName, "Frame%1d.csl", frameIndex) ;
        inputFramePath = initStringWith3Strings(pInSAR->slaveImage->dataDirectoryPath, "/", frameName) ;
        sourceFrame = getCSLImageStructureAtPath(inputFramePath) ;
        frameInfo = readInfoImageInCSLImage(sourceFrame) ;
        S1FrameSpecific = initS1SpecificInfo(frameInfo, sourceFrame->imageDirectoryPath) ;

        /* Select only requested polarization */
        sprintf(frameInfo->polMode, "%s", selectedPolarization) ;
        S1FrameSpecific->numberOfLayers = frameInfo->numberOfLayers = pInSAR->slaveInfo->numberOfLayers ;

        /* Adapt burst selection to InSAR burst selection */
        isFrameSelected = 0 ;
        for (swathIndex = 0; swathIndex < S1FrameSpecific->numberOfSubSwaths; swathIndex++) {
            if ((frameBurst = S1FrameSpecific->burstList[swathIndex])) {
                sourceBurst = getFirstBurstOfFrameInList(S1ImageSpecific->burstList[swathIndex], frameIndex) ;
                while (frameBurst) {
                    if ((frameBurst->isSelected = sourceBurst->isSelected)) {
                        isFrameSelected = 1 ;
                    }

                    frameBurst = frameBurst->nextBurst ;
                    sourceBurst = sourceBurst->nextBurst ;
                }
            }
        }
        outputFramePath = initStringWith3Strings(destinationImageContainer->dataDirectoryPath, "/", frameName) ;
        destinationFrame = getCSLImageStructureAtPath(outputFramePath) ;
        if (isFrameSelected) {
            infoImageFilePath = initStringWith2Strings(destinationFrame->infoDirectoryPath, "/SLCImageInfo.txt") ;
            updateSpecificFieldsForSelectedBursts(frameInfo) ;
            updateBurstSelectionAtPath(frameInfo, destinationFrame->infoDirectoryPath) ;
            
            /* Copy slave burst image data to new location */
            openBurstFilesForReadingAndWriting(destinationFrame, frameInfo) ;
            copyCSLImage(inputFramePath, outputFramePath, _CSLIMAGE_OVERWRITE_ | _CSLIMAGE_SELECTED_BURSTS_OUT_) ;
            saveS1InfoImage(frameInfo, infoImageFilePath) ;
            free(infoImageFilePath) ;
        }
        else {
            sprintf(accessPath, "%s/burstSelection.txt", destinationFrame->infoDirectoryPath) ;
            unlink(accessPath) ;
        }
        
        free(inputFramePath) ;
        free(outputFramePath) ;
        freeCSLImageStructure(sourceFrame) ;
        freeCSLImageStructure(destinationFrame) ;
        freeS1Specific(S1FrameSpecific, _S1_FREE_BURSTS_) ;
        freeInfoImage(frameInfo) ;
    }

    /* Read new CSL image structure */
    if (pInSAR->interpolatedSlave) {
        freeCSLImageStructure(pInSAR->interpolatedSlave) ;
    }
    
    pInSAR->interpolatedSlave = getCSLImageStructureAtPath(newSlaveImageLocation) ;
    removeEmptyFramesInCSLImage(pInSAR->interpolatedSlave) ;
    
    /* Re-intentiate infoImage for copied slave image */
    pInSAR->interpolatedSlaveInfo = mergeFrameInfo(pInSAR->interpolatedSlave, selectedPolarization) ;
    pInSAR->interpolatedSlaveInfo->masterInfo = pInSAR->masterInfo ;
    pInSAR->interpolatedSlaveInfo->superMasterInfo = pInSAR->slaveInfo->superMasterInfo ;

    /* Save info image in interpolated image instance */
    saveS1InfoImage(pInSAR->interpolatedSlaveInfo, destinationImageContainer->infoDirectoryPath) ;
    infoImageFilePath = initStringWith2Strings(destinationImageContainer->infoDirectoryPath, "/SLCImageInfo.txt") ;
    slaveInfoFilePath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/slaveSLCImageInfo.txt") ;
    copyFileAtPathToPath(infoImageFilePath, slaveInfoFilePath) ;
    pInSAR->ima2.lenr = pInSAR->interpolatedSlaveInfo->rangeDimension ;
    pInSAR->ima2.lena = pInSAR->interpolatedSlaveInfo->azimuthDimension ;

    slaveSpecific = pInSAR->interpolatedSlaveInfo->sensorSpecificInfo ;
    for (swathIndex = slaveSpecific->firstSwathIndex; swathIndex <= slaveSpecific->lastSwathIndex; swathIndex++) {
        slaveBurst = getFirstSelectedBurstInList(slaveSpecific->burstList[swathIndex]) ;
        sourceBurst = getFirstSelectedBurstInList(S1ImageSpecific->burstList[swathIndex]) ;
        /* In case master image was copied, masterBurst must be reinitialized with ones in copied image */
        masterBurst = (pInSAR->flag & _S1_MASTER_IMAGE_COPIED_)? getFirstSelectedBurstInList(masterSpecific->burstList[swathIndex]) : sourceBurst->masterBurst ;
        while (slaveBurst && slaveBurst->isSelected) {
            slaveBurst->masterBurst = masterBurst ;
            slaveBurst = slaveBurst->nextBurst ;
            sourceBurst = sourceBurst->nextBurst ;
        }
    }
    

    free(infoImageFilePath) ;
    free(slaveInfoFilePath) ;
    free(selectedPolarization) ;
    free(initialSlaveImageLocation) ;
    free(newSlaveImageLocation) ;
    freeCSLImageStructure(destinationImageContainer) ;
}

