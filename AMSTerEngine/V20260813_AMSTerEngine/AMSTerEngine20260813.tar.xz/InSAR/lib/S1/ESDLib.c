/* 
*  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version. 
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 * 
 *  You should have received a copy of the GNU Affero General Public License 
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**************************************************
 * File name : ESDLib.c
 * Author : Quentin Glaude
 * Date : 2026-07-20
 * Copyright 2026 Quentin Glaude
 * Description : Extendid Spectral Diversity implementation 
 **************************************************/


#include <stdio.h>
#include "ESDLib.h"


/* ============================================================== */
/* Enhanced Spectral Diversity (ESD) static helper functions       */
/* ============================================================== */


/* Tee printf-style output: write to stdout and, if non-NULL, also to `f`.
 * Used by ESD() to mirror its console log into <project>/TextFiles/ESDlog.txt
 * without affecting the original on-screen behavior. */
static void esdLog(FILE *f, const char *fmt, ...)
{
    va_list ap1, ap2 ;
    va_start(ap1, fmt) ;
    va_copy(ap2, ap1) ;
    vprintf(fmt, ap1) ;
    if (f) {
        vfprintf(f, fmt, ap2) ;
        fflush(f) ;
    }
    va_end(ap1) ;
    va_end(ap2) ;
}


/* Compute coherence-weighted circular mean of differential phase */
static double ESDBurstDifferentialAveragePhase(float **differentialPhase,
                                                float **upperCoherence,
                                                float **lowerCoherence,
                                                int lenr, int lena)
{
    int iX, iY ;
    double coh, weight ;
    double sumR = 0.0, sumI = 0.0 ;

    for (iY = 0; iY < lena; iY++) {
        for (iX = 0; iX < lenr; iX++) {
            coh = (upperCoherence[iY][iX] < lowerCoherence[iY][iX]) ? upperCoherence[iY][iX] : lowerCoherence[iY][iX] ;
            if (coh > 0.2) {
                weight = (coh - 0.2) / 0.8 ;
                weight = weight * weight ;
                sumR += weight * cos((double)differentialPhase[iY][iX]) ;
                sumI += weight * sin((double)differentialPhase[iY][iX]) ;
            }
        }
    }

    return atan2(sumI, sumR) ;
}


/* Compute double-difference phase: arg(upper × conj(lower)) */
static void ESDDifferentialInterferogram(float **upperInterferogram,
                                          float **lowerInterferogram,
                                          float **outputDifferentialPhase,
                                          int lenr, int lena)
{
    int iX, iY ;
    complexFloat upper_c, lower_c, diff ;

    for (iY = 0; iY < lena; iY++) {
        for (iX = 0; iX < lenr; iX++) {
            upper_c.r = cosf(upperInterferogram[iY][iX]) ;
            upper_c.i = sinf(upperInterferogram[iY][iX]) ;
            lower_c.r = cosf(lowerInterferogram[iY][iX]) ;
            lower_c.i = sinf(lowerInterferogram[iY][iX]) ;
            diff = mC(upper_c, cC(lower_c)) ;
            outputDifferentialPhase[iY][iX] = phiC(diff) ;
        }
    }
}


/* In-memory interferogram + coherence computation for burst overlaps */
static void ESDInsicohmod(complexFloat **masterData,
                           complexFloat **slaveData,
                           int xDim, int yDim,
                           int rangeReductionFactor, int azimuthReductionFactor,
                           int cohRangeWindow, int cohAzimuthWindow,
                           float **outInterferogram,
                           float **outCoherence,
                           int *outLenr, int *outLena)
{
    int oX, oY, iX, iY ;
    int startX, startY ;
    double sumInterfR, sumInterfI ;
    double sumMasterPow, sumSlavePow ;
    double denominator ;

    *outLenr = (xDim - cohRangeWindow) / rangeReductionFactor + 1 ;
    *outLena = (yDim - cohAzimuthWindow) / azimuthReductionFactor + 1 ;

    for (oY = 0; oY < *outLena; oY++) {
        startY = oY * azimuthReductionFactor ;
        for (oX = 0; oX < *outLenr; oX++) {
            startX = oX * rangeReductionFactor ;

            sumInterfR = sumInterfI = 0.0 ;
            sumMasterPow = sumSlavePow = 0.0 ;

            for (iY = startY; iY < startY + cohAzimuthWindow; iY++) {
                for (iX = startX; iX < startX + cohRangeWindow; iX++) {
                    sumInterfR += (double)masterData[iY][iX].r * slaveData[iY][iX].r
                                + (double)masterData[iY][iX].i * slaveData[iY][iX].i ;
                    sumInterfI += (double)masterData[iY][iX].i * slaveData[iY][iX].r
                                - (double)masterData[iY][iX].r * slaveData[iY][iX].i ;
                    sumMasterPow += (double)masterData[iY][iX].r * masterData[iY][iX].r
                                  + (double)masterData[iY][iX].i * masterData[iY][iX].i ;
                    sumSlavePow  += (double)slaveData[iY][iX].r * slaveData[iY][iX].r
                                  + (double)slaveData[iY][iX].i * slaveData[iY][iX].i ;
                }
            }

            outInterferogram[oY][oX] = (float)atan2(sumInterfI, sumInterfR) ;
            denominator = sumMasterPow * sumSlavePow ;
            if (denominator < 1e-12) {
                outCoherence[oY][oX] = 0.0f ;
            }
            else {
                outCoherence[oY][oX] = (float)(sqrt(sumInterfR * sumInterfR + sumInterfI * sumInterfI) / sqrt(denominator)) ;
            }
        }
    }
}


#if ESD_DEBUG_RAW
/* Dump a raw full-resolution complex overlap buffer as an ENVI complex raster
 * (data type 6: interleaved float32 real,imag — matches complexFloat layout).
 * Used to inspect the single-overlap interferogram m.conj(s) and any residual
 * azimuth phase ramp BEFORE multilooking, which the multilooked debug dumps
 * average away. */
static void ESDDumpComplexBuffer(const char *dir, const char *name,
                                 complexFloat **data, int xDim, int yDim,
                                 FILE *esdLogFile)
{
    char rawPath[1024], hdrPath[1024] ;
    FILE *f ;
    int line ;

    sprintf(rawPath, "%s/%s.cpx", dir, name) ;
    f = fopen(rawPath, "wb") ;
    if (!f) return ;
    for (line = 0; line < yDim; line++)
        fwrite(data[line], sizeof(complexFloat), xDim, f) ;
    fclose(f) ;

    sprintf(hdrPath, "%s/%s.cpx.hdr", dir, name) ;
    f = fopen(hdrPath, "w") ;
    if (f) {
        fprintf(f, "ENVI\n") ;
        fprintf(f, "description = {%s}\n", name) ;
        fprintf(f, "samples = %d\n", xDim) ;
        fprintf(f, "lines = %d\n", yDim) ;
        fprintf(f, "bands = 1\n") ;
        fprintf(f, "header offset = 0\n") ;
        fprintf(f, "file type = ENVI Standard\n") ;
        fprintf(f, "data type = 6\n") ;
        fprintf(f, "interleave = BSQ\n") ;
        fprintf(f, "byte order = 0\n") ;
        fclose(f) ;
    }
    esdLog(esdLogFile, "\t\t  Wrote %s.cpx (%dx%d complex)\n", name, xDim, yDim) ;
}
#endif


/* Main ESD function: estimate and correct residual azimuth misregistration */
void ESD(InSARParametersStruct *pInSAR, double *esdCorrectionPerSwath)
{
    int unsigned swathIndex, layerIndex ;
    int overlapStart, overlapEnd, numOverlapLines ;
    int firstSample, lastSample, numSamples ;
    int localStartUpper, localStartLower ;
    int line ;
    int upperLenr, upperLena, lowerLenr, lowerLena ;
    int diffLenr, diffLena ;
    int cohRangeWindow, cohAzimuthWindow ;
    int rangeReductionFactor, azimuthReductionFactor ;
    double sumDy, sumWeight ;
    double previousPhase, averagePhase ;
    double kt, DT, Df, scalingFactor, Dy ;
    double meanCoherence ;
    double esdCorrection ;
    int iX, iY ;
    S1AdditionalInfo *masterSpecific, *slaveSpecific ;
    burstDescriptor *masterBurst, *nextMasterBurst ;
    burstDescriptor *slaveBurst, *nextSlaveBurst ;
    complexFloat **upperMasterData, **upperSlaveData ;
    complexFloat **lowerMasterData, **lowerSlaveData ;
    float **upperInterferogram, **upperCoherence ;
    float **lowerInterferogram, **lowerCoherence ;
    float **differentialPhase ;
    FILE *esdLogFile = NULL ;
    char *esdLogPath = NULL ;
#if ESD_DEBUG || ESD_DEBUG_RAW
    char *esdDebugDir = NULL ;
#endif

    masterSpecific = pInSAR->masterInfo->sensorSpecificInfo ;
    slaveSpecific = pInSAR->interpolatedSlaveInfo->sensorSpecificInfo ;

    layerIndex = 0 ;

    /* Open ESDlog.txt under the project's TextFiles directory. esdLog() tees
     * stdout into this file; failure to open silently falls back to stdout. */
    esdLogPath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/ESDlog.txt") ;
    esdLogFile = fopen(esdLogPath, "w") ;
    free(esdLogPath) ;

    esdLog(esdLogFile, "\n---> Extended Spectral Diversity\n") ;

#if ESD_DEBUG || ESD_DEBUG_RAW
    /* Debug dumps go into <project>/InSARProducts/debug/ — create it once. */
    esdDebugDir = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/debug") ;
    makeDirRecursively(esdDebugDir) ;
#endif

    /* Default coherence estimation parameters */
    cohRangeWindow = (int)pInSAR->coh.cor ;
    cohAzimuthWindow = (int)pInSAR->coh.coa ;
    rangeReductionFactor = pInSAR->red.Fra ;
    azimuthReductionFactor = pInSAR->red.Faz ;

    for (swathIndex = masterSpecific->firstSwathIndex; swathIndex <= masterSpecific->lastSwathIndex; swathIndex++) {
        sumDy = 0.0 ;
        sumWeight = 0.0 ;
        previousPhase = 0.0 ;

        masterBurst = getFirstSelectedBurstInList(masterSpecific->burstList[swathIndex]) ;
        slaveBurst = getFirstSelectedBurstInList(slaveSpecific->burstList[swathIndex]) ;
        if (!masterBurst || !masterBurst->isSelected) continue ;
        if (!slaveBurst || !slaveBurst->isSelected) continue ;

        esdLog(esdLogFile, "\tSwath %d (lineTimeInterval = %.12e s)\n", swathIndex, pInSAR->masterInfo->lineTimeInterval) ;

        while (masterBurst->nextBurst && masterBurst->nextBurst->isSelected
               && slaveBurst->nextBurst && slaveBurst->nextBurst->isSelected) {
            nextMasterBurst = masterBurst->nextBurst ;
            nextSlaveBurst = slaveBurst->nextBurst ;

            /* 1. Compute overlap geometry (in global azimuth indices) */
            overlapStart = (int)nextMasterBurst->firstAzimuthIndex + (int)nextMasterBurst->firstValidLine ;
            if ((int)masterBurst->firstAzimuthIndex + (int)masterBurst->firstValidLine > overlapStart) {
                overlapStart = (int)masterBurst->firstAzimuthIndex + (int)masterBurst->firstValidLine ;
            }

            overlapEnd = (int)masterBurst->firstAzimuthIndex + (int)masterBurst->lastValidLine ;
            if ((int)nextMasterBurst->firstAzimuthIndex + (int)nextMasterBurst->lastValidLine < overlapEnd) {
                overlapEnd = (int)nextMasterBurst->firstAzimuthIndex + (int)nextMasterBurst->lastValidLine ;
            }

            numOverlapLines = overlapEnd - overlapStart + 1 ;

            /* Skip if overlap too small for coherence estimation */
            if (numOverlapLines < cohAzimuthWindow + azimuthReductionFactor) {
                esdLog(esdLogFile, "\t\tBursts %d-%d: overlap too small (%d lines), skipping\n",
                       masterBurst->burstIndex, nextMasterBurst->burstIndex, numOverlapLines) ;
                masterBurst = nextMasterBurst ;
                continue ;
            }

            /* Valid sample range */
            firstSample = (masterBurst->firstValidSample > nextMasterBurst->firstValidSample) ?
                           masterBurst->firstValidSample : nextMasterBurst->firstValidSample ;
            lastSample = (masterBurst->lastValidSample < nextMasterBurst->lastValidSample) ?
                          masterBurst->lastValidSample : nextMasterBurst->lastValidSample ;
            numSamples = lastSample - firstSample + 1 ;

            if (numSamples < cohRangeWindow + rangeReductionFactor) {
                esdLog(esdLogFile, "\t\tBursts %d-%d: range too narrow (%d samples), skipping\n",
                       masterBurst->burstIndex, nextMasterBurst->burstIndex, numSamples) ;
                masterBurst = nextMasterBurst ;
                continue ;
            }

            esdLog(esdLogFile, "\t\tBursts %d-%d: overlap = %d lines, %d samples\n",
                   masterBurst->burstIndex, nextMasterBurst->burstIndex, numOverlapLines, numSamples) ;
            esdLog(esdLogFile, "\t\t  Overlap geometry: global start=%d, end=%d\n", overlapStart, overlapEnd) ;
            esdLog(esdLogFile, "\t\t  Upper burst: firstAzIdx=%u, firstValid=%u, lastValid=%u, xDim=%u, yDim=%u\n",
                   masterBurst->firstAzimuthIndex, masterBurst->firstValidLine,
                   masterBurst->lastValidLine, masterBurst->xDim, masterBurst->yDim) ;
            esdLog(esdLogFile, "\t\t  Lower burst: firstAzIdx=%u, firstValid=%u, lastValid=%u, xDim=%u, yDim=%u\n",
                   nextMasterBurst->firstAzimuthIndex, nextMasterBurst->firstValidLine,
                   nextMasterBurst->lastValidLine, nextMasterBurst->xDim, nextMasterBurst->yDim) ;
            esdLog(esdLogFile, "\t\t  Sample range: first=%d, last=%d\n", firstSample, lastSample) ;
            esdLog(esdLogFile, "\t\t  Timing: MPAT_upper=%.12f, MPAT_lower=%.12f\n",
                   masterBurst->MPAT, nextMasterBurst->MPAT) ;
            esdLog(esdLogFile, "\t\t  Timing: FPAT_upper=%.12f, FPAT_lower=%.12f\n",
                   masterBurst->FPAT, nextMasterBurst->FPAT) ;
            esdLog(esdLogFile, "\t\t  Slave upper: firstAzIdx=%u, xDim=%u, yDim=%u, firstValid=%u, lastValid=%u\n",
                   slaveBurst->firstAzimuthIndex, slaveBurst->xDim, slaveBurst->yDim,
                   slaveBurst->firstValidLine, slaveBurst->lastValidLine) ;
            esdLog(esdLogFile, "\t\t  Slave lower: firstAzIdx=%u, xDim=%u, yDim=%u, firstValid=%u, lastValid=%u\n",
                   nextSlaveBurst->firstAzimuthIndex, nextSlaveBurst->xDim, nextSlaveBurst->yDim,
                   nextSlaveBurst->firstValidLine, nextSlaveBurst->lastValidLine) ;
            esdLog(esdLogFile, "\t\t  localStartUpper(master)=%d, localStartLower(master)=%d\n",
                   overlapStart - (int)masterBurst->firstAzimuthIndex,
                   overlapStart - (int)nextMasterBurst->firstAzimuthIndex) ;
            esdLog(esdLogFile, "\t\t  localStartUpper(slave)=%d, localStartLower(slave)=%d\n",
                   overlapStart - (int)slaveBurst->firstAzimuthIndex,
                   overlapStart - (int)nextSlaveBurst->firstAzimuthIndex) ;
            esdLog(esdLogFile, "\t\t  Master burst indices: %u and %u\n",
                   masterBurst->burstIndex, nextMasterBurst->burstIndex) ;
            esdLog(esdLogFile, "\t\t  Slave burst indices:  %u and %u\n",
                   slaveBurst->burstIndex, nextSlaveBurst->burstIndex) ;

            /* 2. Extract overlap data from burst files */
            /* Upper pair: masterBurst & slaveBurst at overlap lines */
            localStartUpper = overlapStart - (int)masterBurst->firstAzimuthIndex ;
            upperMasterData = matrixComplexFloat(0, numOverlapLines - 1, 0, numSamples - 1) ;
            upperSlaveData = matrixComplexFloat(0, numOverlapLines - 1, 0, numSamples - 1) ;

            rewind(masterBurst->file[layerIndex]->f) ;
            for (line = 0; line < numOverlapLines; line++) {
                fseek(masterBurst->file[layerIndex]->f,
                      (long)((localStartUpper + line) * (int)masterBurst->xDim + firstSample) * (long)sizeof(complexFloat),
                      SEEK_SET) ;
                fread(upperMasterData[line], sizeof(complexFloat), numSamples, masterBurst->file[layerIndex]->f) ;
            }

            /* --- ESD slave-read coregistration alignment (FIX) ----------------
             * ESD() runs BEFORE alignSlaveImage(), so the interpolated slave
             * bursts are still in slave-frame indexing. Two corrections are
             * required so the slave overlap samples the SAME ground as master:
             *  (a) azimuth: read at the MASTER burst azimuth start. The slave
             *      burst's firstAzimuthIndex differs from the master's (per-burst
             *      azimuth drift); alignSlaveImage() later resets the slave's to
             *      the master's. We therefore REUSE the master localStartUpper
             *      and do NOT recompute it from slaveBurst->firstAzimuthIndex.
             *  (b) range: burstsInterpolation() applied only the FRACTIONAL range
             *      shift; the integer part (rangeTransformConstantTerm = floor of
             *      the range-transform constant, see initPerBurstTransforms())
             *      was deferred to alignSlaveImage(). Add it to the read column.
             * rangeShift is non-zero only for frame stitching (0 otherwise). */
            {
                int slaveFirstSample = firstSample + (int)slaveBurst->rangeTransformConstantTerm ;
                if (slaveFirstSample < 0) slaveFirstSample = 0 ;
                if (slaveFirstSample + numSamples > (int)slaveBurst->xDim)
                    slaveFirstSample = (int)slaveBurst->xDim - numSamples ;
                esdLog(esdLogFile,
                       "\t\t  [fix] upper slave: azStart=%d(master) slaveFirstAzIdx=%u "
                       "rgTransfConst=%.3f rangeShift=%d T[1][2]=%.4f -> readCol=%d (firstSample=%d)\n",
                       localStartUpper, slaveBurst->firstAzimuthIndex,
                       slaveBurst->rangeTransformConstantTerm, slaveBurst->rangeShift,
                       slaveBurst->T ? slaveBurst->T[1][2] : 0.0, slaveFirstSample, firstSample) ;
                rewind(slaveBurst->file[layerIndex]->f) ;
                for (line = 0; line < numOverlapLines; line++) {
                    fseek(slaveBurst->file[layerIndex]->f,
                          (long)((localStartUpper + line) * (int)slaveBurst->xDim + slaveFirstSample) * (long)sizeof(complexFloat),
                          SEEK_SET) ;
                    fread(upperSlaveData[line], sizeof(complexFloat), numSamples, slaveBurst->file[layerIndex]->f) ;
                }
            }

            /* Lower pair: nextMasterBurst & nextSlaveBurst at overlap lines */
            localStartLower = overlapStart - (int)nextMasterBurst->firstAzimuthIndex ;
            lowerMasterData = matrixComplexFloat(0, numOverlapLines - 1, 0, numSamples - 1) ;
            lowerSlaveData = matrixComplexFloat(0, numOverlapLines - 1, 0, numSamples - 1) ;

            rewind(nextMasterBurst->file[layerIndex]->f) ;
            for (line = 0; line < numOverlapLines; line++) {
                fseek(nextMasterBurst->file[layerIndex]->f,
                      (long)((localStartLower + line) * (int)nextMasterBurst->xDim + firstSample) * (long)sizeof(complexFloat),
                      SEEK_SET) ;
                fread(lowerMasterData[line], sizeof(complexFloat), numSamples, nextMasterBurst->file[layerIndex]->f) ;
            }

            /* --- ESD slave-read coregistration alignment (FIX) ----------------
             * Same correction as the upper slave read, applied to the lower
             * (nextSlaveBurst): reuse the MASTER localStartLower for azimuth and
             * add the deferred integer range shift (rangeTransformConstantTerm). */
            {
                int slaveFirstSample = firstSample + (int)nextSlaveBurst->rangeTransformConstantTerm ;
                if (slaveFirstSample < 0) slaveFirstSample = 0 ;
                if (slaveFirstSample + numSamples > (int)nextSlaveBurst->xDim)
                    slaveFirstSample = (int)nextSlaveBurst->xDim - numSamples ;
                esdLog(esdLogFile,
                       "\t\t  [fix] lower slave: azStart=%d(master) slaveFirstAzIdx=%u "
                       "rgTransfConst=%.3f rangeShift=%d T[1][2]=%.4f -> readCol=%d (firstSample=%d)\n",
                       localStartLower, nextSlaveBurst->firstAzimuthIndex,
                       nextSlaveBurst->rangeTransformConstantTerm, nextSlaveBurst->rangeShift,
                       nextSlaveBurst->T ? nextSlaveBurst->T[1][2] : 0.0, slaveFirstSample, firstSample) ;
                rewind(nextSlaveBurst->file[layerIndex]->f) ;
                for (line = 0; line < numOverlapLines; line++) {
                    fseek(nextSlaveBurst->file[layerIndex]->f,
                          (long)((localStartLower + line) * (int)nextSlaveBurst->xDim + slaveFirstSample) * (long)sizeof(complexFloat),
                          SEEK_SET) ;
                    fread(lowerSlaveData[line], sizeof(complexFloat), numSamples, nextSlaveBurst->file[layerIndex]->f) ;
                }
            }

            /* Data read verification: print first sample from middle line of each buffer */
            {
                int midLine = numOverlapLines / 2 ;
                int midSamp = numSamples / 2 ;
                esdLog(esdLogFile, "\t\t  Data check (mid-overlap): upperMaster=(%.4f,%.4f) upperSlave=(%.4f,%.4f)\n",
                       upperMasterData[midLine][midSamp].r, upperMasterData[midLine][midSamp].i,
                       upperSlaveData[midLine][midSamp].r, upperSlaveData[midLine][midSamp].i) ;
                esdLog(esdLogFile, "\t\t  Data check (mid-overlap): lowerMaster=(%.4f,%.4f) lowerSlave=(%.4f,%.4f)\n",
                       lowerMasterData[midLine][midSamp].r, lowerMasterData[midLine][midSamp].i,
                       lowerSlaveData[midLine][midSamp].r, lowerSlaveData[midLine][midSamp].i) ;
            }

#if ESD_DEBUG_RAW
            /* Raw full-resolution complex overlap buffers (master/slave,
             * upper/lower), exactly as ESD reads them, dumped before the
             * Insicohmod multilooking and before they are freed. These let the
             * single-overlap interferogram and the coherence-vs-shift landscape
             * be reconstructed offline (misregistration proof, prove_misreg.py). */
            {
                char rawName[256] ;
                sprintf(rawName, "ESD_raw_upperMaster_sw%d_b%d-%d",
                        swathIndex, masterBurst->burstIndex, nextMasterBurst->burstIndex) ;
                ESDDumpComplexBuffer(esdDebugDir, rawName, upperMasterData, numSamples, numOverlapLines, esdLogFile) ;
                sprintf(rawName, "ESD_raw_upperSlave_sw%d_b%d-%d",
                        swathIndex, masterBurst->burstIndex, nextMasterBurst->burstIndex) ;
                ESDDumpComplexBuffer(esdDebugDir, rawName, upperSlaveData, numSamples, numOverlapLines, esdLogFile) ;
                sprintf(rawName, "ESD_raw_lowerMaster_sw%d_b%d-%d",
                        swathIndex, masterBurst->burstIndex, nextMasterBurst->burstIndex) ;
                ESDDumpComplexBuffer(esdDebugDir, rawName, lowerMasterData, numSamples, numOverlapLines, esdLogFile) ;
                sprintf(rawName, "ESD_raw_lowerSlave_sw%d_b%d-%d",
                        swathIndex, masterBurst->burstIndex, nextMasterBurst->burstIndex) ;
                ESDDumpComplexBuffer(esdDebugDir, rawName, lowerSlaveData, numSamples, numOverlapLines, esdLogFile) ;
            }
#endif

            /* 3. Compute upper interferogram + coherence */
            upperInterferogram = matrixFloat(0, numOverlapLines - 1, 0, numSamples - 1) ;
            upperCoherence = matrixFloat(0, numOverlapLines - 1, 0, numSamples - 1) ;
            ESDInsicohmod(upperMasterData, upperSlaveData, numSamples, numOverlapLines,
                          rangeReductionFactor, azimuthReductionFactor,
                          cohRangeWindow, cohAzimuthWindow,
                          upperInterferogram, upperCoherence,
                          &upperLenr, &upperLena) ;
            freeMatrixComplexFloat(upperMasterData, 0, 0) ;
            freeMatrixComplexFloat(upperSlaveData, 0, 0) ;

            /* 4. Compute lower interferogram + coherence */
            lowerInterferogram = matrixFloat(0, numOverlapLines - 1, 0, numSamples - 1) ;
            lowerCoherence = matrixFloat(0, numOverlapLines - 1, 0, numSamples - 1) ;
            ESDInsicohmod(lowerMasterData, lowerSlaveData, numSamples, numOverlapLines,
                          rangeReductionFactor, azimuthReductionFactor,
                          cohRangeWindow, cohAzimuthWindow,
                          lowerInterferogram, lowerCoherence,
                          &lowerLenr, &lowerLena) ;
            freeMatrixComplexFloat(lowerMasterData, 0, 0) ;
            freeMatrixComplexFloat(lowerSlaveData, 0, 0) ;

            /* Use minimum output dimensions */
            diffLenr = (upperLenr < lowerLenr) ? upperLenr : lowerLenr ;
            diffLena = (upperLena < lowerLena) ? upperLena : lowerLena ;

            /* 5. Compute differential interferogram */
            /*     SNAP convention: forward × conj(backward) = lower × conj(upper) */
            differentialPhase = matrixFloat(0, diffLena - 1, 0, diffLenr - 1) ;
            ESDDifferentialInterferogram(lowerInterferogram, upperInterferogram,
                                          differentialPhase, diffLenr, diffLena) ;

            /* 6. Compute coherence-weighted average phase */
            averagePhase = ESDBurstDifferentialAveragePhase(differentialPhase,
                                                            upperCoherence, lowerCoherence,
                                                            diffLenr, diffLena) ;

            /* Compute mean coherence for weighting */
            meanCoherence = 0.0 ;
            for (iY = 0; iY < diffLena; iY++) {
                for (iX = 0; iX < diffLenr; iX++) {
                    meanCoherence += (upperCoherence[iY][iX] < lowerCoherence[iY][iX]) ?
                                      upperCoherence[iY][iX] : lowerCoherence[iY][iX] ;
                }
            }
            if (diffLenr * diffLena > 0) {
                meanCoherence /= (double)(diffLenr * diffLena) ;
            }

            /* Debug dumps: DDI phase, min-coherence, upper/lower coherence and
             * interferograms. Controlled by ESD_DEBUG at the top of this file;
             * files are written to <project>/InSARProducts/debug/. */
#if ESD_DEBUG
            /* Each dump is written as a raw float32 file with no extension,
             * then handed to generateENVIHeaderForFile(..., 0) which renames
             * it to .bil and writes the matching .hdr. Dimensions live in
             * the .hdr (samples/lines), so they're dropped from the name. */
            {
                char fileName[256], ddiPath[1024] ;
                FILE *ddiFile ;
                float *minCoh ;
                int p ;

                minCoh = (float *)malloc(diffLenr * sizeof(float)) ;

                sprintf(fileName, "ESD_DDI_phase_sw%d_b%d-%d",
                        swathIndex, masterBurst->burstIndex, nextMasterBurst->burstIndex) ;
                sprintf(ddiPath, "%s/%s", esdDebugDir, fileName) ;
                ddiFile = fopen(ddiPath, "wb") ;
                if (ddiFile) {
                    for (iY = 0; iY < diffLena; iY++)
                        fwrite(differentialPhase[iY], sizeof(float), diffLenr, ddiFile) ;
                    fclose(ddiFile) ;
                    generateENVIHeaderForFile(ddiPath, diffLenr, diffLena, 0) ;
                    esdLog(esdLogFile, "\t\t  Wrote %s.bil + .hdr\n", fileName) ;
                }

                sprintf(fileName, "ESD_DDI_mincoh_sw%d_b%d-%d",
                        swathIndex, masterBurst->burstIndex, nextMasterBurst->burstIndex) ;
                sprintf(ddiPath, "%s/%s", esdDebugDir, fileName) ;
                ddiFile = fopen(ddiPath, "wb") ;
                if (ddiFile) {
                    for (iY = 0; iY < diffLena; iY++) {
                        for (p = 0; p < diffLenr; p++)
                            minCoh[p] = (upperCoherence[iY][p] < lowerCoherence[iY][p]) ?
                                         upperCoherence[iY][p] : lowerCoherence[iY][p] ;
                        fwrite(minCoh, sizeof(float), diffLenr, ddiFile) ;
                    }
                    fclose(ddiFile) ;
                    generateENVIHeaderForFile(ddiPath, diffLenr, diffLena, 0) ;
                    esdLog(esdLogFile, "\t\t  Wrote %s.bil + .hdr\n", fileName) ;
                }

                sprintf(fileName, "ESD_upper_coh_sw%d_b%d-%d",
                        swathIndex, masterBurst->burstIndex, nextMasterBurst->burstIndex) ;
                sprintf(ddiPath, "%s/%s", esdDebugDir, fileName) ;
                ddiFile = fopen(ddiPath, "wb") ;
                if (ddiFile) {
                    for (iY = 0; iY < diffLena; iY++)
                        fwrite(upperCoherence[iY], sizeof(float), diffLenr, ddiFile) ;
                    fclose(ddiFile) ;
                    generateENVIHeaderForFile(ddiPath, diffLenr, diffLena, 0) ;
                    esdLog(esdLogFile, "\t\t  Wrote %s.bil + .hdr\n", fileName) ;
                }

                sprintf(fileName, "ESD_lower_coh_sw%d_b%d-%d",
                        swathIndex, masterBurst->burstIndex, nextMasterBurst->burstIndex) ;
                sprintf(ddiPath, "%s/%s", esdDebugDir, fileName) ;
                ddiFile = fopen(ddiPath, "wb") ;
                if (ddiFile) {
                    for (iY = 0; iY < diffLena; iY++)
                        fwrite(lowerCoherence[iY], sizeof(float), diffLenr, ddiFile) ;
                    fclose(ddiFile) ;
                    generateENVIHeaderForFile(ddiPath, diffLenr, diffLena, 0) ;
                    esdLog(esdLogFile, "\t\t  Wrote %s.bil + .hdr\n", fileName) ;
                }

                sprintf(fileName, "ESD_upper_interf_sw%d_b%d-%d",
                        swathIndex, masterBurst->burstIndex, nextMasterBurst->burstIndex) ;
                sprintf(ddiPath, "%s/%s", esdDebugDir, fileName) ;
                ddiFile = fopen(ddiPath, "wb") ;
                if (ddiFile) {
                    for (iY = 0; iY < diffLena; iY++)
                        fwrite(upperInterferogram[iY], sizeof(float), diffLenr, ddiFile) ;
                    fclose(ddiFile) ;
                    generateENVIHeaderForFile(ddiPath, diffLenr, diffLena, 0) ;
                    esdLog(esdLogFile, "\t\t  Wrote %s.bil + .hdr\n", fileName) ;
                }

                sprintf(fileName, "ESD_lower_interf_sw%d_b%d-%d",
                        swathIndex, masterBurst->burstIndex, nextMasterBurst->burstIndex) ;
                sprintf(ddiPath, "%s/%s", esdDebugDir, fileName) ;
                ddiFile = fopen(ddiPath, "wb") ;
                if (ddiFile) {
                    for (iY = 0; iY < diffLena; iY++)
                        fwrite(lowerInterferogram[iY], sizeof(float), diffLenr, ddiFile) ;
                    fclose(ddiFile) ;
                    generateENVIHeaderForFile(ddiPath, diffLenr, diffLena, 0) ;
                    esdLog(esdLogFile, "\t\t  Wrote %s.bil + .hdr\n", fileName) ;
                }

                free(minCoh) ;
            }
#endif


            freeMatrixFloat(upperInterferogram, 0, 0) ;
            freeMatrixFloat(upperCoherence, 0, 0) ;
            freeMatrixFloat(lowerInterferogram, 0, 0) ;
            freeMatrixFloat(lowerCoherence, 0, 0) ;
            freeMatrixFloat(differentialPhase, 0, 0) ;

            /* 7. Unwrap between consecutive burst overlaps */
            averagePhase = unwrappPhaseFromPointToPoint((float)averagePhase, (float)previousPhase) ;
            previousPhase = averagePhase ;

            /* 8. Convert phase to azimuth shift */
            kt = yValForPolynomial(masterBurst->deramping->ktPol, (double)(masterBurst->xDim / 2)) ;
            /* tCycle = non-overlapping burst duration (SNAP convention, SpectralDiversityOp.java).
             * Previously used MPAT difference, which gives burst center spacing (~3.6% shorter). */
            DT = ((double)masterBurst->yDim - (double)numOverlapLines) * pInSAR->masterInfo->lineTimeInterval ;
            Df = kt * DT ;
            scalingFactor = 1.0 / (pInSAR->masterInfo->lineTimeInterval * Df * TWOPI) ;
            Dy = -scalingFactor * averagePhase ;  /* Negation matches SNAP (SpectralDiversityOp.java:1159) */

            esdLog(esdLogFile, "\t\t\tInsicohmod output: upper %dx%d, lower %dx%d, diff %dx%d\n",
                   upperLenr, upperLena, lowerLenr, lowerLena, diffLenr, diffLena) ;
            esdLog(esdLogFile, "\t\t\tkt = %.4f Hz/s, DT = %.12f s, Df = %.4f Hz\n", kt, DT, Df) ;
            esdLog(esdLogFile, "\t\t\tscalingFactor = %.10e\n", scalingFactor) ;
            esdLog(esdLogFile, "\t\t\tPhase = %.6f rad, Dy = %.6f pixels (coh = %.3f)\n",
                   averagePhase, Dy, meanCoherence) ;

            /* 9. Accumulate weighted shift */
            sumWeight += meanCoherence ;
            sumDy += Dy * meanCoherence ;

            masterBurst = nextMasterBurst ;
            slaveBurst = nextSlaveBurst ;
        }

        /* 10. Compute constant correction for this swath */
        if (sumWeight > 0.0) {
            esdCorrection = sumDy / sumWeight ;
        }
        else {
            esdCorrection = 0.0 ;
            esdLog(esdLogFile, "\t\tWarning: no valid overlap observations for swath %d\n", swathIndex) ;
        }

        esdLog(esdLogFile, "\tESD correction for swath %d: %.6f pixels\n", swathIndex, esdCorrection) ;

        /* Store correction for caller to use after data re-copy */
        if (esdCorrectionPerSwath) {
            esdCorrectionPerSwath[swathIndex] = esdCorrection ;
        }
    }

#if ESD_DEBUG || ESD_DEBUG_RAW
    if (esdDebugDir) free(esdDebugDir) ;
#endif
    if (esdLogFile) fclose(esdLogFile) ;
}

