
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  S1OrbitManagement.c
//  S1DataReader
//
//  Created by Dominique Derauw on 20/10/16.
//  Copyright (c) 2016 Dominique Derauw. All rights reserved.
//

#include "S1OrbitManagement.h"


char *getPOEORBDirectory(keyValue *parametersList, int argc, const char *argv[])
{
    char *S1OrbitDirectory ;
    
    if ((S1OrbitDirectory = getenv("S1_PRECISES_ORBITS_DIR")) != NULL) {
        setStringValForKeyIn(parametersList, S1OrbitDirectory, "S1 precises orbits directory") ;
    }
    if ((S1OrbitDirectory = getNextArgument(argc, argv, "-o")) != NULL) {
        setStringValForKeyIn(parametersList, S1OrbitDirectory, "S1 precises orbits directory") ;
    }
    S1OrbitDirectory = getStringValForKeyIn(parametersList, "S1 precises orbits directory") ;
    
    return (S1OrbitDirectory) ;
}

int updateS1PreciseOrbitInCSLImageAtPath(char *imagePath) 
{
    int flag ;
    CSLImage *thisImage ; 

    thisImage = getCSLImageStructureAtPath(imagePath) ;
    flag = updateS1PreciseOrbitInCSLImage(thisImage) ;
    freeCSLImageStructure(thisImage) ;

    return(flag) ;
}


int updateS1PreciseOrbitInCSLImage(CSLImage *thisImage)
{
    char *S1OrbitDirectory ;
    int flag = 0 ; 
    SLCImageInfo *info ;

    /* Locate precise orbit directory */
    if ((S1OrbitDirectory = getenv("S1_ORBITS_DIR")) == NULL) {
        return(_S1_ORBIT_DIR_NOT_DEFINED_) ;
    }
    if ((info = readInfoImageInCSLImage(thisImage)) == NULL) {
        return(flag) ;
    }
    flag = manageS1OrbitsFor(thisImage, S1OrbitDirectory, info) ;

    freeInfoImage(info) ;

    return(flag) ;
}

int manageS1OrbitsFor(CSLImage *thisImage, char *auxiliaryDataDirectoryFilePath, SLCImageInfo *info) {
    char *infoImageFilePath, *auxiliaryDataFilePath = NULL, *oldInfoImageFilePath ;
    char *orbitDirectory ;
    int returnedValue ;
    
    returnedValue = _S1_ORBIT_NO_UPDATE_PERFORMED_ ;
    /* Read infoImage file path for the image under concern */
    infoImageFilePath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
    oldInfoImageFilePath = initStringWith2Strings(infoImageFilePath, ".old") ;
    if (!fileExistsAtPath(oldInfoImageFilePath)) {
        /* Get orbit file path */
        /* First we look for precise orbit */
        orbitDirectory = initStringWith2Strings(auxiliaryDataDirectoryFilePath, "/AUX_POEORB") ;
        if ((auxiliaryDataFilePath = findS1OrbitFilePath(info, orbitDirectory)) == NULL){
            /* If not found, look for restituted orbit */
            printf("\t\t\t-/-> Precise orbit not found. Looking for restituted one.\n") ;
            returnedValue = _S1_RESTITUTED_ORBIT_UPDATED_OK_ ;
            free(orbitDirectory) ;
            orbitDirectory = initStringWith2Strings(auxiliaryDataDirectoryFilePath, "/AUX_RESORB") ;
            if ((auxiliaryDataFilePath = findS1OrbitFilePath(info, orbitDirectory)) == NULL){
                returnedValue =_S1_RESTITUTED_ORBIT_NOT_FOUND_ ;
            }
        }
        else {
            returnedValue = _S1_PRECISE_ORBIT_UPDATED_OK_ ;
        }
        free(orbitDirectory) ;
        
        if (returnedValue == _S1_PRECISE_ORBIT_UPDATED_OK_ || returnedValue == _S1_RESTITUTED_ORBIT_UPDATED_OK_) {
            /* Save original infoImage file as .ori or .old depending it was replaced by PRECISE or RESTITUTED orbit */
            free(info->orbitTypeID) ;
            if (isSubStringPresentInString(auxiliaryDataFilePath, "_OPER_AUX_RESORB_")) {
                free(oldInfoImageFilePath) ;
                oldInfoImageFilePath = initStringWith2Strings(infoImageFilePath, ".ori") ;
                if (fileExistsAtPath(oldInfoImageFilePath)) {
                    info->orbitTypeID = initStringWithString("Restituted orbit") ;
                    returnedValue = _S1_RESTITUTED_ORBIT_ALREADY_UPDATED_ ;
                }
            }
            if (returnedValue != _S1_RESTITUTED_ORBIT_ALREADY_UPDATED_) {
                copyFileAtPathToPath(infoImageFilePath, oldInfoImageFilePath) ;
                
                /* Reading of precise orbit state vectors and interpolation for temporal resampling these vectors */
                readS1PreciseOrbitStateVectors(auxiliaryDataFilePath, info) ;
                
                /* We recompute the scene geolocation before saving */
                info->isOrbitInterpolationDone = 0 ;
                geolocateSceneOnEllipsoid(info, info->ellRef) ;
                
                /* Since precise orbits where interpolated, we save interpolated state vactors encompassing the data */
                if (returnedValue == _S1_PRECISE_ORBIT_UPDATED_OK_)   {
                    info->orbitTypeID = initStringWithString("Precise orbit") ;
                }
                else {
                    info->orbitTypeID = initStringWithString("Restituted orbit") ;
                }
                saveInfoImage(info, infoImageFilePath) ;
            }
        }
    }
    else {
        free(info->orbitTypeID) ;
        info->orbitTypeID = initStringWithString("Precise orbit") ;
        returnedValue = _S1_PRECISE_ORBIT_ALREADY_UPDATED_ ;
    }
    
    if (auxiliaryDataFilePath) {
        free(auxiliaryDataFilePath) ;
    }
    free(infoImageFilePath) ;
    free(oldInfoImageFilePath) ;
    
    return (returnedValue) ;
}

char isS1PreciseOrbitAvailable(SLCImageInfo *info, char *S1OrbitDirectory)
{
    char isOrbitAvailable = 0 ;
    char *orbitFilePath ;
    
    if ((orbitFilePath = findS1OrbitFilePath(info, S1OrbitDirectory))) {
        isOrbitAvailable = 1 ;
        free(orbitFilePath) ;
    }
    
    return (isOrbitAvailable) ;
}


char *findS1OrbitFilePath(SLCImageInfo *info, char *S1OrbitDirectory)
{
    char **directoryContent, *orbitFilePath, *idString ;
    char *subDirectory ;
    char *imageStartTime, *imageStopTime ;
    int i, isFileFound, numberOfEntries ;

    /* Init */
    orbitFilePath = NULL ;
    i = 0 ;
    isFileFound = -1 ;
    subDirectory = initStringWithString(getPointerToFileNameInPath(S1OrbitDirectory)) ;
    imageStartTime = allocStringOfLength(15) ;
    imageStopTime = allocStringOfLength(15) ;
    sprintf(imageStartTime, "%.15s", info->scene_id + 17) ;
    sprintf(imageStopTime, "%.15s", info->scene_id + 33) ;
    /* If the path to S1 orbit Files directory is given  */
    if (isDir(S1OrbitDirectory)) {
        directoryContent = getDirectoryContentAtPath(S1OrbitDirectory, &numberOfEntries) ;
        idString = initStringWith4Strings(info->platformName, "_OPER_", subDirectory, "_OPOD_") ;
        
        /* Locate orbit file encompassing acquisition time */
        while (i < numberOfEntries) {
            if (!strncmp(directoryContent[i], idString, 25)) {
                if ((strncmp(directoryContent[i] + 42, imageStartTime, 15) < 0) && (strncmp(directoryContent[i] + 58, imageStopTime, 15) > 0)) {
                    isFileFound = i ;
                    break ;
                }
            }
            i++ ;
        }
        
        if (isFileFound >= 0) {
            orbitFilePath = initStringWith3Strings(S1OrbitDirectory, "/", directoryContent[isFileFound]) ;
        }
        
        freeDirectoryEntries(directoryContent, numberOfEntries) ;
        free(idString) ;
    }
    free(subDirectory) ;
    free(imageStartTime) ;
    free(imageStopTime) ;

    return (orbitFilePath) ;
}



void readS1PreciseOrbitStateVectors(char *S1OrbitDirectory, SLCImageInfo *info)
{
    char vectorDate[11] ;
    int i, hh, mm, firstVectorIndex, lastVectorIndex ;
    double vectorTime, ss ;
    xmlDocPtr ORBXMLDoc ;
    CSVStruct *csv ;
 
    ORBXMLDoc = getdoc(S1OrbitDirectory) ;
    csv = readCSVInXMLFileForXPath((xmlChar*)"//UTC", ORBXMLDoc) ;

    /* Init */
    i = 0 ;
    vectorDate[10] = '\0' ;
    
    /* Locate first state vector of corresponding date */
    do {
        memcpy(vectorDate, csv->stringVal[i] + 4, 10) ;
        removeAnyOccurrenceOfSubStringInString(vectorDate, "-") ;
        i++ ;
    } while (strncmp(vectorDate, info->acquisitionDate, 8) < 0 && i < csv->numberOfEntries);
    i-- ;
    
    /* Locate last state vector just before First Pixel Azimuth Time */
    do {
        sscanf(csv->stringVal[i] + 15, "%2d:%2d:%lf", &hh, &mm, &ss) ;
        vectorTime = 3600. * hh + 60. * mm + ss ;
        i++ ;
    } while (vectorTime < info->FPAT);
    i-- ;
    firstVectorIndex = i - 1 ;
    
    /* Locate first state vector after Last Pixel Azimuth Time */
    do {
        sscanf(csv->stringVal[i] + 15, "%2d:%2d:%lf", &hh, &mm, &ss) ;
        vectorTime = 3600. * hh + 60. * mm + ss ;
        i++ ;
    } while (vectorTime < info->LPAT);
    lastVectorIndex = i ;
    freeCSVStruct(csv) ;
    
    if (info->S) {
        freeVectorOfStateVectorsOfLength(info->S, info->nVect) ;
    }
    
    info->nVect = lastVectorIndex - firstVectorIndex + 1 ;
    if (info->nVect < NUMBER_OF_STATE_VECTORS) {
        info->nVect = NUMBER_OF_STATE_VECTORS ;
        firstVectorIndex-- ;
        lastVectorIndex = firstVectorIndex + NUMBER_OF_STATE_VECTORS - 1 ;
    }
    info->S = allocVectorOfStateVectorsOfLength(info->nVect) ;
    
    for (i = 0; i < info->nVect; i++) {
        csv = readCSVInXMLFileForXPathOccurenceN((xmlChar*)"//UTC", ORBXMLDoc, firstVectorIndex + i) ;
        sscanf(csv->stringVal[0] + 15, "%2d:%2d:%lf", &hh, &mm, &ss) ;
        info->S[i].t = 3600. * hh + 60. * mm + ss ;
        freeCSVStruct(csv) ;
        
        csv = readCSVInXMLFileForXPathOccurenceN((xmlChar*)"//X", ORBXMLDoc, firstVectorIndex + i) ;
        sscanf(csv->stringVal[0], "%lf", info->S[i].P) ;
        freeCSVStruct(csv) ;
        
        csv = readCSVInXMLFileForXPathOccurenceN((xmlChar*)"//Y", ORBXMLDoc, firstVectorIndex + i) ;
        sscanf(csv->stringVal[0], "%lf", info->S[i].P + 1) ;
        freeCSVStruct(csv) ;
        
        csv = readCSVInXMLFileForXPathOccurenceN((xmlChar*)"//Z", ORBXMLDoc, firstVectorIndex + i) ;
        sscanf(csv->stringVal[0], "%lf", info->S[i].P + 2) ;
        freeCSVStruct(csv) ;
        
        csv = readCSVInXMLFileForXPathOccurenceN((xmlChar*)"//VX", ORBXMLDoc, firstVectorIndex + i) ;
        sscanf(csv->stringVal[0], "%lf", info->S[i].V) ;
        freeCSVStruct(csv) ;
        
        csv = readCSVInXMLFileForXPathOccurenceN((xmlChar*)"//VY", ORBXMLDoc, firstVectorIndex + i) ;
        sscanf(csv->stringVal[0], "%lf", info->S[i].V + 1) ;
        freeCSVStruct(csv) ;
        
        csv = readCSVInXMLFileForXPathOccurenceN((xmlChar*)"//VZ", ORBXMLDoc, firstVectorIndex + i) ;
        sscanf(csv->stringVal[0], "%lf", info->S[i].V + 2) ;
        freeCSVStruct(csv) ;
    }

    xmlFreeDoc(ORBXMLDoc) ;
}

void outputOrbitUpdateMessage(rawFileDescriptor *logFile, int flag)
{
    if (flag == _S1_RESTITUTED_ORBIT_NOT_FOUND_) {
        printf("\t\t-/-> Restituted orbit not found.\n") ;
        if (logFile) {
            fseek(logFile->f, 0, SEEK_END) ;
            writeToLog(logFile->f, "\t\t-/-> Restituted orbit not found.\n") ;
        }
        
        flag = _S1_ORBIT_NO_UPDATE_PERFORMED_ ;
    }
    
    switch (flag) {
        case _S1_ORBIT_NO_UPDATE_PERFORMED_:
            printf("\t\t-/-> No orbit update performed.\n") ;
            break;
        
        case _S1_PRECISE_ORBIT_ALREADY_UPDATED_:
            printf("\t\t---> Precise orbit update already performed.\n") ;
            break;
        
        case _S1_RESTITUTED_ORBIT_ALREADY_UPDATED_:
            printf("\t\t---> Restituted orbit update already performed.\n") ;
            break;
        
        case _S1_RESTITUTED_ORBIT_UPDATED_OK_:
            printf("\t\t---> Restituted orbit update performed.\n") ;
            break;
        
        case _S1_PRECISE_ORBIT_UPDATED_OK_:
            printf("\t\t---> Precise orbit update performed.\n") ;
            break;
        
        default:
        break;
    }

    if (logFile)
    {
        fseek(logFile->f, 0, SEEK_END) ;
        switch (flag) {
            case _S1_ORBIT_NO_UPDATE_PERFORMED_:
                writeToLog(logFile->f, "\t\t-/-> No orbit update performed.\n") ;
                break;
            
            case _S1_PRECISE_ORBIT_ALREADY_UPDATED_:
                writeToLog(logFile->f, "\t\t---> Precise orbit update already performed.\n") ;
                break;
            
            case _S1_RESTITUTED_ORBIT_ALREADY_UPDATED_:
                writeToLog(logFile->f, "\t\t---> Restituted orbit update already performed.\n") ;
                break;
            
            case _S1_RESTITUTED_ORBIT_UPDATED_OK_:
                writeToLog(logFile->f, "\t\t---> Restituted orbit update performed.\n") ;
                break;
            
            case _S1_PRECISE_ORBIT_UPDATED_OK_:
                writeToLog(logFile->f, "\t\t---> precise orbit update performed.\n") ;
                break;
            
            default:
                break;
        }
        fflush(logFile->f) ;
    }
}
