
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  S1ETADManagement.c
//  S1DataReader
//
//  Created by Dominique Derauw on 09/04/2025.
//  Copyright © SAREOS - Dominique Derauw. All rights reserved.
//


#include "infoImageS1.h"
#include "S1DataReaderLib.h"


/* This function looks for an ETAD .SAFE file corresponding to a Sentinel1 acquisition within a given directory */
/* It returns NULL if not found */
char *findETADFile(char *S1FileName, char *dir)
{
    char *aString = NULL ;
    CSVStruct *csv, *csv2 ;

    aString = allocStringOfLength(64) ;
    memcpy(aString, S1FileName, 62) ;
    memcpy(aString + 7, "ETA__AX", 7) ;

    csv = recursiveSearchOfDirInDir(aString, dir) ;
    free(aString) ; 
    if (!csv) {
        return(NULL) ;
    }
    
    if (csv) {
        if (isSubStringPresentInString(getPointerToFileExtensionInPath(csv->stringVal[0]), "SAFE")){
            csv2 = recursiveSearchOfFilesWithExtensionInDir("nc", csv->stringVal[0]) ;
            if (csv2) {
                aString = initStringWithString(csv2->stringVal[0]) ;
            }
            freeCSVStruct(csv2) ;
        }
    }
    freeCSVStruct(csv) ;

    return (aString) ;
}

/* Read and save in corresponding burst image all ETAD data layers, attribute list and dimentions from ETAD .nc file */
void updateETADDataIntoS1Frame(CSLImage *aFrame, char *ETADDataDir)
{
    char *ETADFilePath, ncPath[16] ;
    char *burstPath, *ETADDataPath, *ncGroupAttsPath ;
    int swathIndex, burstIndex, burstID0 ;
    int ncID, groupID, ncStatus ;
    SLCImageInfo *frameInfo ;
    S1AdditionalInfo *S1FrameSpecific ;
    S1BurstSelection *burstSelection ;
    groupStruct *rootGroup, *swathGroup ;
    ncAtb *attList ;
    keyValue *pList ;

    frameInfo = readInfoImageInCSLImage(aFrame) ;
    S1FrameSpecific = initS1SpecificInfo(frameInfo, aFrame->imageDirectoryPath) ;
    printf("\t\t---> Managing frame %s\n", frameInfo->scene_id) ;
    if ((ETADFilePath = findETADFile(frameInfo->scene_id, ETADDataDir))) {
        burstSelection = getS1BurstSelectionForImage(aFrame) ;
        ncStatus = nc_open(ETADFilePath, NC_NOWRITE, &ncID) ;
        ncStatusCheck(ncStatus) ;
        rootGroup = ncGetSubGroupsForGroup(NULL, ncID) ;
        groupID = getGroupIdForPath(rootGroup, "/") ;
        attList = ncGetGroupAtts(groupID, NC_GLOBAL) ;
        pList = getGroupAtts(attList) ;

        for ( swathIndex = burstSelection->firstSwathIndex; swathIndex <= burstSelection->lastSwathIndex; swathIndex++) {
            sprintf(ncPath, "/IW%d", swathIndex + 1) ;
            groupID = getGroupIdForPath(rootGroup, ncPath) ;
            swathGroup = ncGetSubGroupsForGroup(NULL, groupID) ;
            sscanf(swathGroup->subGroup[0]->groupName, "Burst%d", &burstID0) ;

            for ( burstIndex = burstSelection->firstBurstIndex[swathIndex]; burstIndex <= burstSelection->lastBurstIndex[swathIndex]; burstIndex++) {
                burstPath = burstSelection->burstPath[swathIndex][burstIndex] ;
                ETADDataPath = initStringWith2Strings(burstPath, "/ETADData") ;
                if (!isDir(ETADDataPath)){
                    if(mkdir(ETADDataPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
                        sprintf(ertex, "Failed to create ETAD data directory at path %s\n", ETADDataPath) ;
                        ase(ertex) ;
                    }
                }
                
                sprintf(ncPath, "/IW%d/Burst%0*d", swathIndex + 1, 4, 3 * burstIndex + burstID0) ;
                ncReadAndSaveGroupVars(ETADFilePath, ncPath, ETADDataPath) ;

                ncGroupAttsPath = initStringWith2Strings(ETADDataPath, "/ncGroupAtts.txt") ;
                appendParameterFileAtPath(pList, ncGroupAttsPath) ;
                free(ncGroupAttsPath) ;
            }
            freeSubGroupsOfGroup(swathGroup) ;
        }

        freeSubGroupsOfGroup(rootGroup) ;
        freeGroupStruct(rootGroup) ;
        ncStatus = nc_close(ncID) ;
        ncStatusCheck(ncStatus) ;
    
            
        freeS1BurstSelection(burstSelection) ;
        free(ETADFilePath) ;
    }
    else {
        printf("\t\t-/-> No ETAD file found for current frame. Skipping ETAD update.\n") ;
    }
    freeS1Specific(S1FrameSpecific, _S1_TRASH_BURSTS_) ;
    freeInfoImage(frameInfo) ;
}


char isETADPresentInCSLImage(CSLImage *thisImage)
{
    char *aPath, itsOK = 1 ;
    int unsigned swathIndex ;
    SLCImageInfo *info ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst ;

    info = mergeFrameInfo(thisImage, NULL) ;
    S1Specific = info->sensorSpecificInfo ;
    if (!S1Specific) {
        return (0) ;
    }
    

    for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
        if ((currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]))) {
            do {
                aPath = initStringWith2Strings(currentBurst->burstImage->imageDirectoryPath, "/ETAData") ;
                itsOK |= (isDir(aPath)) ;
                free(aPath) ;
                currentBurst = currentBurst->nextBurst ;                
            } while (currentBurst && currentBurst->isSelected);
        }
    }

    freeS1Specific(S1Specific, _S1_FREE_BURSTS_) ;
    freeInfoImage(info) ;

    return (itsOK) ;
}

S1ETADLayers *allocETADLayersStruct()
{
    S1ETADLayers *ETAD ;

    ETAD = calloc(sizeof(ETAD[0]), 1) ;
    ETAD->layer = calloc(10, sizeof(ETAD->layer[0])) ;

    return (ETAD) ;
}

void freeETADLayersStruct(S1ETADLayers *ETAD)
{
    size_t i ;

    for (i = 0; i < 10; i++) {
        if (ETAD->layer[i]) {
            freeGridMap(ETAD->layer[i]) ;
        }
        
    }
    free(ETAD->layer) ;
    free(ETAD) ;
}

/* Load all requested ETAD layers within burst structure */
void loadETADLayersIntoBursts(SLCImageInfo *info, int layerSelection)
{
    int unsigned swathIndex, testVal, ETADLayerIndex ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst ;
    S1ETADLayers *ETAD ;

    S1Specific = info->sensorSpecificInfo ;


    for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
        currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
        while (currentBurst && currentBurst->isSelected && layerSelection) {
            ETAD = currentBurst->ETAD = allocETADLayersStruct() ;
            testVal = 1 ;
            for ( ETADLayerIndex = 0; ETADLayerIndex < 10; ETADLayerIndex++) {
                if (layerSelection & testVal) {
                   loadETADLayerIntoBurst(ETADLayerIndex, currentBurst) ; 
                }   
                
                testVal = testVal << 1 ;
            }    
            ETAD->bistaticCorrectionAz = ETAD->layer[0] ;
            ETAD->dopplerRangeShiftRg = ETAD->layer[1] ;
            ETAD->fmMismatchCorrectionAz = ETAD->layer[2] ;
            ETAD->geodeticCorrectionAz = ETAD->layer[3] ;
            ETAD->geodeticCorrectionRg = ETAD->layer[4] ;
            ETAD->ionosphericCorrectionRg = ETAD->layer[5] ;
            ETAD->sumOfCorrectionsAz = ETAD->layer[6] ;
            ETAD->sumOfCorrectionsRg = ETAD->layer[7] ;
            ETAD->troposphericCorrectionRg = ETAD->layer[8] ;
            ETAD->height = ETAD->layer[9] ;

            if (currentBurst->T) {
                currentBurst->T[0][2] += currentBurst->rangeTransformConstantTerm ;
            }
            
            
            currentBurst = currentBurst->nextBurst ;
        }
    }
}

/* Load a given ETAD layer within burst structure */
void loadETADLayerIntoBurst(size_t ETADLayerIndex, burstDescriptor *currentBurst)
{
    char *layerPath, *layerParamsPath, *groupParamsPath ;
    size_t Nx, Ny, typeSize, iX, iY ;
    double x0, y0, xScaling, yScaling, val ;
    rawFileDescriptor *layerFile ;
    keyValue *layerParams, *ncGroupParams ; ;
    gridMap *thisGrid ;
    S1ETADLayers *thisLayer ;

    layerPath = initStringWith3Strings(currentBurst->burstImage->imageDirectoryPath, "/ETADData/", (char *)(ETADLayerName[ETADLayerIndex])) ;
    layerFile = openRawFileForReadingAndWritingAtPath(layerPath) ;
    layerParamsPath = initStringWith2Strings(layerPath, ".txt") ;
    layerParams = readParameterFileAtPath(layerParamsPath) ;
    groupParamsPath = initStringWith2Strings(currentBurst->burstImage->imageDirectoryPath, "/ETADData/ncGroupAtts.txt") ;
    ncGroupParams = readParameterFileAtPath(groupParamsPath) ;

    Nx = getIntValForKeyIn(layerParams, "rangeExtent") ;
    Ny = getIntValForKeyIn(layerParams, "azimuthExtent") ;
    typeSize = sizeof(double) ;

    thisLayer = currentBurst->ETAD ;
    thisGrid = thisLayer->layer[ETADLayerIndex] = createGridOfSize(Ny, Nx, 1, 1, typeSize) ;
    fread(thisGrid->M[0], typeSize, Nx * Ny, layerFile->f) ;
    
    
    /* Computing burst to ETAD transform */
    thisLayer->gridSamplingRange = getDoubleValForKeyIn(ncGroupParams, "gridSamplingRange") ;
    thisLayer->gridSamplingAzimuth = getDoubleValForKeyIn(ncGroupParams, "gridSamplingAzimuth") ;
    thisLayer->rangeTimeMin = getDoubleValForKeyIn(ncGroupParams, "rangeTimeMin") ;
    thisLayer->azimuthTimeMin = getSecondsFromFormattedDate(getStringValForKeyIn(ncGroupParams, "azimuthTimeMin")) ;
    thisLayer->gridStartRangeTime = getDoubleValForKeyIn(ncGroupParams, "gridStartRangeTime") ;
    thisLayer->gridStartAzimuthTime = getDoubleValForKeyIn(ncGroupParams, "gridStartAzimuthTime") ;
    thisLayer->averageZeroDopplerVelocity = getDoubleValForKeyIn(ncGroupParams, "averageZeroDopplerVelocity") ;
    thisLayer->instrumentTimingCalibrationRange = getDoubleValForKeyIn(ncGroupParams, "instrumentTimingCalibrationRange") ;
    thisLayer->instrumentTimingCalibrationAzimuth = getDoubleValForKeyIn(ncGroupParams, "instrumentTimingCalibrationAzimuth") ;
    
    thisGrid->T = matrixDouble(0, 1, 0, 2) ;
    
    x0 = thisLayer->rangeTimeMin + thisLayer->gridStartRangeTime ;
    x0 = (currentBurst->FPRT - x0) / thisLayer->gridSamplingRange ;
    y0 = thisLayer->azimuthTimeMin + thisLayer->gridStartAzimuthTime ;
    y0 = (currentBurst->FPAT - y0) / thisLayer->gridSamplingAzimuth ;
    xScaling = 1. / currentBurst->rangeSamplingFrequency / thisLayer->gridSamplingRange ;
    yScaling = 1. / currentBurst->azimuthSamplingFrequency / thisLayer->gridSamplingAzimuth ;
    
    thisGrid->T[0][0] = yScaling ;
    thisGrid->T[0][2] = y0 ;
    thisGrid->T[1][1] = xScaling ;
    thisGrid->T[1][2] = x0 ;
   
/*
    freeRawFileDescriptor(layerFile) ;
    free(layerPath) ;
    layerPath = initStringWith2Strings(currentBurst->burstImage->imageDirectoryPath, "/ETADData/brol") ;
    layerFile = openRawFileForReadingAndWritingAtPath(layerPath) ;
    for ( iY = 0; iY < currentBurst->yDim; iY++) {
        for (iX = 0; iX < currentBurst->xDim; iX++) {
            val = interpolGridForImageCoordinate(thisGrid, iY, iX) ;
            val = weightedExtrapolationOfGridForImageCoordinate(thisGrid, iY, iX) ;
            fwrite(&val, 8, 1, layerFile->f) ;
        }
    }
*/

    free(layerPath) ;
    free(layerParamsPath) ;
    free(groupParamsPath) ;
    freeRawFileDescriptor(layerFile) ;
    freeKeyValuePair(layerParams) ;
    freeKeyValuePair(ncGroupParams) ;

}


/* Compute ETAD phase delay in seconds */
double ETADPhaseDelayAtPoint(double rangePosition, double azimuthPosition, SLCImageInfo *masterInfo, SLCImageInfo *slaveInfo)
{
    int unsigned iX, iY ;
    double phaseDelay = 0 ;
    double *phaseDelays ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst, *consideredBurst ;
    coord2D pos ;

    S1Specific = masterInfo->sensorSpecificInfo ;
    phaseDelays = masterInfo->ETADPhaseDelays ;

    iX = pos.x = (int unsigned)(floor(rangePosition)) + S1Specific->rangeIndexStart ;
    iY = pos.y = (int unsigned )(floor(azimuthPosition)) + S1Specific->azimuthIndexStart ;

    if ((currentBurst = getBurstForPoint(S1Specific, iX, iY))) {
        pos.y -= currentBurst->firstAzimuthIndex ;
        pos.x -= currentBurst->firstRangeIndex ;
        consideredBurst = currentBurst ;
        if (slaveInfo) {
            phaseDelays = slaveInfo->ETADPhaseDelays ;
            consideredBurst = currentBurst->slaveBurst ;
            planeAffineTransformOfCoord2D(&pos, &pos, consideredBurst->T) ;
        }

        if(consideredBurst->ETAD->troposphericCorrectionRg) {
            phaseDelays[2] = weightedExtrapolationOfGridForImageCoordinate(consideredBurst->ETAD->troposphericCorrectionRg, pos.y, pos.x) ;
            phaseDelay += phaseDelays[2] ;
        }
        if(consideredBurst->ETAD->geodeticCorrectionRg) {
            phaseDelays[1] = weightedExtrapolationOfGridForImageCoordinate(consideredBurst->ETAD->geodeticCorrectionRg, pos.y, pos.x) ;
            phaseDelay += phaseDelays[1] ;
        }
        if(consideredBurst->ETAD->ionosphericCorrectionRg) {
            phaseDelays[0] = weightedExtrapolationOfGridForImageCoordinate(consideredBurst->ETAD->ionosphericCorrectionRg, pos.y, pos.x) ;
            phaseDelay += phaseDelays[0] ;
        }
/*
        if(consideredBurst->ETAD->sumOfCorrectionsAz) {
            phaseDelays[0] = weightedExtrapolationOfGridForImageCoordinate(consideredBurst->ETAD->sumOfCorrectionsAz, pos.y, pos.x) ;
        }
*/
        phaseDelay += consideredBurst->ETAD->instrumentTimingCalibrationRange ;
    }
    
    return (phaseDelay) ;
}

double ETADHeightAtPoint(double rangePosition, double azimuthPosition, SLCImageInfo *info)
{
    int iX, iY ;
    double height = 0 ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst ;

    S1Specific = info->sensorSpecificInfo ;

    iX = (int)(floor(rangePosition)) + S1Specific->rangeIndexStart ;
    iY = (int)(floor(azimuthPosition)) + S1Specific->azimuthIndexStart ;
    
    if ((currentBurst = getBurstForPoint(S1Specific, iX, iY))) {
        iY -= currentBurst->firstAzimuthIndex ;
        iX -= currentBurst->firstRangeIndex ;
        if(currentBurst->ETAD->troposphericCorrectionRg) {
            height += weightedExtrapolationOfGridForImageCoordinate(currentBurst->ETAD->height, iY, iX) ;
        }
    }

    return (height) ;
}

/* Returns the ETAD range and azimuth shifts in meter for the requested image position */
coord2D ETADGeoreferencingShift(double rangePosition, double azimuthPosition, SLCImageInfo *info)
{
    int iX, iY ;
    coord2D shift ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst ;

    S1Specific = info->sensorSpecificInfo ;

    iX = (int)(floor(rangePosition)) + S1Specific->rangeIndexStart ;
    iY = (int)(floor(azimuthPosition)) + S1Specific->azimuthIndexStart ;

    shift.x = shift.y = 0 ;
    if ((currentBurst = getBurstForPoint(S1Specific, iX, iY))) {
        iY -= currentBurst->firstAzimuthIndex ;
        iX -= currentBurst->firstRangeIndex ;
        if(currentBurst->ETAD->sumOfCorrectionsRg) {
            shift.x += weightedExtrapolationOfGridForImageCoordinate(currentBurst->ETAD->sumOfCorrectionsRg, iY, iX) ;
        }
        else {
            if (currentBurst->ETAD->troposphericCorrectionRg) {
                shift.x += weightedExtrapolationOfGridForImageCoordinate(currentBurst->ETAD->troposphericCorrectionRg, iY, iX) ;
            }
            if (currentBurst->ETAD->ionosphericCorrectionRg) {
                shift.x += weightedExtrapolationOfGridForImageCoordinate(currentBurst->ETAD->ionosphericCorrectionRg, iY, iX) ;
            }
            if (currentBurst->ETAD->dopplerRangeShiftRg) {
                shift.x += weightedExtrapolationOfGridForImageCoordinate(currentBurst->ETAD->dopplerRangeShiftRg, iY, iX) ;
            }
            if (currentBurst->ETAD->geodeticCorrectionRg) {
                shift.x += weightedExtrapolationOfGridForImageCoordinate(currentBurst->ETAD->geodeticCorrectionRg, iY, iX) ;
            }
            shift.x += currentBurst->ETAD->instrumentTimingCalibrationRange ;
        }
        if(currentBurst->ETAD->sumOfCorrectionsAz) {
            shift.y += weightedExtrapolationOfGridForImageCoordinate(currentBurst->ETAD->sumOfCorrectionsAz, iY, iX) ;
        }
        else {
            if (currentBurst->ETAD->bistaticCorrectionAz) {
                shift.y += weightedExtrapolationOfGridForImageCoordinate(currentBurst->ETAD->bistaticCorrectionAz, iY, iX) ;
            }
            if (currentBurst->ETAD->fmMismatchCorrectionAz) {
                shift.y += weightedExtrapolationOfGridForImageCoordinate(currentBurst->ETAD->fmMismatchCorrectionAz, iY, iX) ;
            }
            if (currentBurst->ETAD->geodeticCorrectionAz) {
                shift.y += weightedExtrapolationOfGridForImageCoordinate(currentBurst->ETAD->geodeticCorrectionAz, iY, iX) ;
            }
            shift.y += currentBurst->ETAD->instrumentTimingCalibrationAzimuth ;
        }
    }

    return (shift) ;
}