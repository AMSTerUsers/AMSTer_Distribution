
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ReadInfoImageFromCEOS.c
 *  
 *
 *  Created by Dominique Derauw on Mon Sep 22 2003.
 *  Copyright (c) 2003 Dominique Derauw All rights reserved.
 *
 */

#include "infoImageERS.h"

struct infoImage	*readInfoImageFromCEOSHeader(struct CEOS_VDF *vdf, struct CEOS_LF *lf, struct CEOS_IMOF *imof)
{
    char date[10] ;
    char isRSAT1 = 0 ;
    int			i, hh, mm ;
    double		ss, aDouble ;
    struct infoImage	*info ;
    union intChar4 *uInt ;
    
    
    info = allocInfoImage() ;
    
    if (!strncmp(lf->fdr_fix.file_name, "RSAT-1", 6)) {
        isRSAT1 = 1 ;
    }

    sprintf(info->platformName, "%.16s", lf->dss->mission_identifier) ; info->platformName[17] = '\0' ;
	stripWhiteCharsAtEndOfString(info->platformName) ;
    sprintf(info->polMode, "%s", "VV") ;
    info->beamNumber = 0 ;
    memcpy(info->productID,  vdf->fpr[1].ref_file_name,  16) ;
    for(i = 0; i < 16; i++) if(info->productID[i] == '\0') info->productID[i] = '\40' ;
    info->productID[16] = '\0' ;
    memcpy(info->scene_id,  vdf->text.scene_id,  40) ;
    for(i = 0; i < 40; i++) if(info->scene_id[i] == '\0') info->scene_id[i] = '\40' ;
    info->scene_id[40] = '\0' ;
    memcpy(info->scene_loc, vdf->text.scene_loc, 40) ;
    for(i = 0; i < 40; i++) if(info->scene_loc[i] == '\0') info->scene_loc[i] = '\40' ;
    info->scene_loc[40] = '\0' ;
    
    sprintf(date, "%.8s", lf->dss->input_scene_center_time) ;
    info->acquisitionDate = initStringWithString(date) ;
    info->lookDirection = RIGHT_LOOKING ;
    
    if(imof == (struct CEOS_IMOF *)NULL) {
        info->azimuthDimension = readIntInASCIIStringOfLength(vdf->fpr[1].ref_file_nrecs, 8) ; info->azimuthDimension-- ;
        info->rangeDimension = readIntInASCIIStringOfLength(vdf->fpr[1].ref_file_max_reclen, 8) ; info->rangeDimension = (info->rangeDimension - 12) / 4 ;
    }
    else {
        info->rangeDimension = readIntInASCIIStringOfLength(imof->imof_var.SAR_data_bytes_per_rec, 8) / 4 ;
        info->azimuthDimension = readIntInASCIIStringOfLength(imof->imof_var.nlines_data_set, 8) ;
    }
    info->wavelength = readDoubleInASCIIStringOfLength(lf->dss->radar_wavelength, 16) ;
    info->radarCarrierFrequency = readDoubleInASCIIStringOfLength(lf->dss->radar_freq, 8) ;
    if(info->radarCarrierFrequency)
		info->radarCarrierFrequency *= 1.e+9 ; 
	else {
		info->radarCarrierFrequency = speedOfLight / info->wavelength ;
	}

	info->rangeSamplingFrequency = readDoubleInASCIIStringOfLength(lf->dss->sampling, 16) ;
    info->rangeBandwidth = readDoubleInASCIIStringOfLength(lf->dss->total_look_bandwidth_range, 16) ;
    if (!isRSAT1) {
        info->rangeSamplingFrequency *= 1.e6 ;
        info->rangeBandwidth *= 1.e6 ;        
    }
    
    info->prf = readDoubleInASCIIStringOfLength(lf->dss->nominal_prf,16) ; 
    info->lineTimeInterval = 1. / info->prf ;
    info->azimuthBandwidth = readDoubleInASCIIStringOfLength(lf->dss->total_look_bandwidth_az,16) ; 
    info->azimuthResolutionCell = readDoubleInASCIIStringOfLength(lf->dss->line_spacing, 16) ; 
    info->rangeResolutionCell = readDoubleInASCIIStringOfLength(lf->dss->pixel_spacing_range, 16) ; 

    if (!isRSAT1) {
        info->fdc[0] = readDoubleInASCIIStringOfLength(lf->dss->c_track_dop_freq_const_early_image, 16) ; 
        info->fdc[1] = readDoubleInASCIIStringOfLength(lf->dss->c_track_dop_freq_lin_early_image, 16) ; 
        info->fdc[2] = readDoubleInASCIIStringOfLength(lf->dss->c_track_dop_freq_quad_early_image, 16) ;
    }
    else {
        uInt = (union intChar4 *)imof->dataRecordHeader[1].fdc_mid ;
        if (isArchBigEndian()) {
            swapInt(&uInt->intVal) ;
        }
        info->fdc[0] = (double)uInt->intVal ;
        info->fdc[1] = info->fdc[2] = 0 ;
    }
    
/* conversion de [Hz]/[sec] en [Hz]/[pix] */
/*    info->fdc[1] *= 2. * info->Dz / c0 ; */
/*    info->fdc[2] *= pow(2. * info->Dz / c0, 2.) ; */

    if (!isRSAT1) {
        info->twoWayRangeTime[0] = readDoubleInASCIIStringOfLength(lf->dss->zero_dop_range_time_f_pixel, 16) * 1.e-3 ;
        info->twoWayRangeTime[1] = readDoubleInASCIIStringOfLength(lf->dss->zero_dop_range_time_c_pixel, 16) * 1.e-3 ;
        info->twoWayRangeTime[2] = readDoubleInASCIIStringOfLength(lf->dss->zero_dop_range_time_l_pixel, 16) * 1.e-3 ;
        for(i = 0; i < 3; i++) info->slantRange[i] = c0/2. * info->twoWayRangeTime[i] ;

        hh = readIntInASCIIStringOfLength(&lf->dss->zero_dop_az_time_f_pixel[12], 2) ;
        mm = readIntInASCIIStringOfLength(&lf->dss->zero_dop_az_time_f_pixel[15], 2) ;
        ss = readDoubleInASCIIStringOfLength(&lf->dss->zero_dop_az_time_f_pixel[18], 6) ;
        info->FPAT = 3600.*hh + 60.*mm + ss ;
        hh = readIntInASCIIStringOfLength(&lf->dss->zero_dop_az_time_l_pixel[12], 2) ;
        mm = readIntInASCIIStringOfLength(&lf->dss->zero_dop_az_time_l_pixel[15], 2) ;
        ss = readDoubleInASCIIStringOfLength(&lf->dss->zero_dop_az_time_l_pixel[18], 6) ;
        info->LPAT = 3600.*hh + 60.*mm + ss ;
    }
    else {
        uInt = (union intChar4 *)imof->dataRecordHeader[1].sr_first ;
        if (isArchBigEndian()) {
            swapInt(&uInt->intVal) ;
        }
        info->slantRange[0] = (double)uInt->intVal ;
        uInt = (union intChar4 *)imof->dataRecordHeader[1].sr_mid ;
        if (isArchBigEndian()) {
            swapInt(&uInt->intVal) ;
        }
        info->slantRange[1] = (double)uInt->intVal ;
        uInt = (union intChar4 *)imof->dataRecordHeader[1].sr_last ;
        if (isArchBigEndian()) {
            swapInt(&uInt->intVal) ;
        }
        info->slantRange[2] = (double)uInt->intVal ;

        if (info->slantRange[2] < info->slantRange[0]) {
            aDouble = info->slantRange[2] ;
            info->slantRange[2] = info->slantRange[0] ;
            info->slantRange[0] = aDouble ;
        }
        

        for (i = 0; i < 3; i++) {
            info->twoWayRangeTime[i] = 2./c0 * info->slantRange[i] ;
        }
        
        uInt = (union intChar4 *)imof->dataRecordHeader[0].acq_msec ;
        if (isArchBigEndian()) {
            swapInt(&uInt->intVal) ;
        }
        info->FPAT = (double)uInt->intVal / 1000. ;

        uInt = (union intChar4 *)imof->dataRecordHeader[2].acq_msec ;
        if (isArchBigEndian()) {
            swapInt(&uInt->intVal) ;
        }
        info->LPAT = (double)uInt->intVal / 1000. ;

        if (info->LPAT < info->FPAT) {
            aDouble = info->FPAT ;
            info->FPAT = info->LPAT ;
            info->LPAT = aDouble ;
        }
        
    }
    
    if (!isRSAT1) {
        info->incidenceAngle[0] = readDoubleInASCIIStringOfLength(lf->facility[0]->first_range_pixel_mid_az_incid_angle, 16) ;
        info->incidenceAngle[1] = readDoubleInASCIIStringOfLength(lf->facility[0]->center_range_pixel_mid_az_incid_angle, 16) ;
        info->incidenceAngle[2] = readDoubleInASCIIStringOfLength(lf->facility[0]->last_range_pixel_mid_az_incid_angle, 16) ;
    }
    else {
        info->incidenceAngle[1] = readDoubleInASCIIStringOfLength(lf->dss->incidence_angle_center, 8) ;
    }
    
    info->FVT = readDoubleInASCIIStringOfLength(lf->platform->sec_of_day_of_data, 22) ;
    info->Dt = readDoubleInASCIIStringOfLength(lf->platform->data_points_time_gap, 22) ;
    info->nVect = readIntInASCIIStringOfLength(lf->platform->num_data_points, 4) ; 
    if((info->S = (struct stateVect *)malloc(info->nVect * sizeof(struct stateVect))) == NULL)
        ase("State vector allocation error\n") ;
    for(i=0; i<info->nVect; i++) {
        info->S[i].P = vectorDouble(0, 2) ;
        info->S[i].V = vectorDouble(0, 2) ;
        info->S[i].P[0] = readDoubleInASCIIStringOfLength(lf->state[i].x, 22) ;
        info->S[i].P[1] = readDoubleInASCIIStringOfLength(lf->state[i].y, 22) ;
        info->S[i].P[2] = readDoubleInASCIIStringOfLength(lf->state[i].z, 22) ;
        info->S[i].V[0] = readDoubleInASCIIStringOfLength(lf->state[i].vx, 22) ;
        info->S[i].V[1] = readDoubleInASCIIStringOfLength(lf->state[i].vy, 22) ;
        info->S[i].V[2] = readDoubleInASCIIStringOfLength(lf->state[i].vz, 22) ;
		info->S[i].t = info->FVT + i * info->Dt ;
	}

	info->aX = info->aY = info->aZ = info->aVx= info->aVy= info->aVz = NULL ;
	info->isOrbitInterpolationDone = 0 ;

    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL)
        ase("Erreur d'allocation de *info->ellRef\n") ;
    memcpy(info->ellRef->ellipsoidID, lf->dss->ellipsoid_designator, 40) ;
    for(i = 0; i < 16; i++) if(info->ellRef->ellipsoidID[i] == '\0') info->ellRef->ellipsoidID[i] = '\40' ;
    info->ellRef->ellipsoidID[16] = '\0' ;
    info->ellRef->a = readDoubleInASCIIStringOfLength(lf->dss->ellipsoid_semimajor_axis, 16) ;
    info->ellRef->b = readDoubleInASCIIStringOfLength(lf->dss->ellipsoid_semiminor_axis, 16) ;
    info->ellRef->a *= 1000. ;
    info->ellRef->b *= 1000. ;
    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;
    
	/* Geolocate scene on reference ellipsoid */
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
	info->EarthRadiusAtSceneCenter = 6371221. ;
	info->loc = allocQuadrilateral() ;
    if (!isRSAT1) {
        geolocateSceneOnEllipsoid(info, info->ellRef) ;
    }
    
    return info ;
}
