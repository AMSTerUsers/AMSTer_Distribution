
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageCSK.c
//  CSKDataReader
//
//  Created by Dominique Derauw on 14/08/12.
//  Copyright (c) 2012 Dominique Derauw. All rights reserved.
//

#include "infoImageTSX.h"


struct infoImage *createSLCImageInfoFromTSXXMLFile(char *filePath)
{
    char *aString, *georefXMLFilePath, coSSCID[5] ;
    int		i, i0, stateVectorIndex, anIndex, anInt = 0, minX, maxX, minY, maxY ;
    double	aDouble, secondsPerPixels ;
    double  diffAvg, diffAvg0 ;
    double  hh, mm, ss ;
    double  *stateVectorsTime ;
    struct infoImage	*info ;
    
    CSVStruct *csv ;
    CSVStruct *csvX, *csvY, *csvZ, *csvVX, *csvVY, *csvVZ, *csvAzTime, *csvRangeTime ;
   
	xmlDocPtr doc, georefDoc ;
    
	doc = getdoc(filePath);
    info = allocInfoImage() ;
    
    /* Image data depth: Do we deal with short float values? */
    info->flag = 0 ;
    if (isSubStringPresentInString(filePath, "BTX1") || isSubStringPresentInString(filePath, "BRX2") || isSubStringPresentInString(filePath, "MON1") || isSubStringPresentInString(filePath, "MON2")) {
        info->flag |= _SHORT_FLOAT_ ;
        sscanf(getPointerToFileNameInPath(filePath) + 14, "%4s", coSSCID) ;
    }

    
    /* Satellite ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//generalHeader/mission", doc))) {
        if (info->flag & _SHORT_FLOAT_) {
            sprintf(info->platformName, "%s_%s", csv->stringVal[0], coSSCID) ;
        }
        else {
            sprintf(info->platformName, "%s", csv->stringVal[0]) ;
        }
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->platformName, "%s", "Unknown sensor") ; 
    }
    
    /* Acquisition date */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sceneInfo/start/timeUTC", doc))) {
        info->acquisitionDate = allocStringOfLength(10) ;
        sprintf(info->acquisitionDate, "%.10s", csv->stringVal[0]) ;
        removeAnyOccurrenceOfSubStringInString(info->acquisitionDate, "-") ;
        freeCSVStruct(csv) ;
    }

    /* Polarisation mode */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//imageData[@layerIndex]/polLayer", doc))) {
        for (i = 0; i < csv->numberOfEntries; i++) {
            if(!i) {
                sprintf(info->polMode, "%s", csv->stringVal[0]) ; 
            }
            else {
                aString = initStringWithString(info->polMode) ;
                sprintf(info->polMode, "%s, %s", aString, csv->stringVal[i]) ; 
                free(aString) ;
            }

        }
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->platformName, "%s", "Unknown polarisation") ; 
    }

    
    /* Beam ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//instrument/settings/beamID", doc))) {
        sscanf(csv->stringVal[0], "strip_%d", &(info->beamNumber)) ;
        freeCSVStruct(csv) ;
    }
    else {
        info->beamNumber = -1 ; 
    }
    
    /* Product ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//productVariant", doc))) {
        sprintf(info->productID, "%s", csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->productID, "Unknown product") ;
    }
    
    /* Scene ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sceneID", doc))) {
        sprintf(info->scene_id, "%s", csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->scene_id, "No scene ID") ;
    }
    
    /* Scene location */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sceneCenterCoord/lon", doc))) {
        sscanf(csv->stringVal[0], "%lf", &aDouble) ;
        sprintf(info->scene_loc, "Center longitude: %.4g\t", aDouble) ;
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->scene_loc, "Center longitude: ???\t") ;
    }
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sceneCenterCoord/lat", doc))) {
        sscanf(csv->stringVal[0], "%lf", &aDouble) ;
        aString = initStringWithString(info->scene_loc) ;
        sprintf(info->scene_loc, "%sCenter latitude: %.4g", aString, aDouble) ;
        free(aString) ;
        freeCSVStruct(csv) ;
    }
    else {
        aString = initStringWithString(info->scene_loc) ;
        sprintf(info->scene_loc, "%sCenter latitude: ???", aString) ;
        free(aString) ;
    }
   
    /* Look direction defined as Right looking */
    info->lookDirection = RIGHT_LOOKING ;
    if((csv = getAttributeInXMLDocForXPath((xmlChar*)"//calibrationInfoAndInstrumentCharacteristics/absCalFactor[@lookDirection]", doc))) {
        if (!strncmp(csv->stringVal[0], "left", 4)) {
            info->lookDirection = LEFT_LOOKING ;
        }
        sscanf(csv->stringVal[0], "%d", &(info->rangeDimension)) ;
        freeCSVStruct(csv) ;
    }
    
    /* SLC data dimensions */
    info->azimuthDimension = 0 ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//imageDataInfo/imageRaster/numberOfRows", doc))) {
        sscanf(csv->stringVal[0], "%d", &(info->azimuthDimension)) ;
        freeCSVStruct(csv) ;
    }
    info->rangeDimension = 0 ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//imageDataInfo/imageRaster/numberOfColumns", doc))) {
        sscanf(csv->stringVal[0], "%d", &(info->rangeDimension)) ;
        freeCSVStruct(csv) ;
    }
    
    
    /* Radar carrier frequency */
    info->radarCarrierFrequency = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//instrument/radarParameters/centerFrequency", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->radarCarrierFrequency)) ;
        freeCSVStruct(csv) ;
    }
    
    /* Wavelength */
    info->wavelength = speedOfLight / info->radarCarrierFrequency ;
    
    /* Range sampling frequency */
    info->rangeSamplingFrequency = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//instrument/settings/RSF", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->rangeSamplingFrequency)) ;
        freeCSVStruct(csv) ;
    }
    
    /* Min and max slant range time */
    info->twoWayRangeTime[0] = info->slantRange[0] = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//productInfo/sceneInfo/rangeTime/firstPixel", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->twoWayRangeTime[0])) ;
        freeCSVStruct(csv) ;
    }
    
    info->twoWayRangeTime[2] = info->slantRange[2] = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//productInfo/sceneInfo/rangeTime/lastPixel", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->twoWayRangeTime[2])) ;
        freeCSVStruct(csv) ;
    }
    
    info->twoWayRangeTime[1] = (info->twoWayRangeTime[0] + info->twoWayRangeTime[2]) / 2. ;
    for(i = 0; i < 3; i++) info->slantRange[i] = c0 / 2. * info->twoWayRangeTime[i];
    
    /* Range bandwidth and resolution cell */
    info->rangeBandwidth = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//processingParameter/rangeLookBandwidth", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->rangeBandwidth)) ;
        freeCSVStruct(csv) ;
    }
    info->rangeApodizationCoefficient = 0.60 ;
    
    info->rangeResolutionCell = secondsPerPixels = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//productInfo/imageDataInfo/imageRaster/rowSpacing[@units ='s']", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(secondsPerPixels)) ;
        freeCSVStruct(csv) ;
    }
    info->rangeResolutionCell = secondsPerPixels * c0 / 2. ;
    
    /* PRF */
    info->prf = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//productSpecific/complexImageInfo/commonPRF", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->prf)) ;
        freeCSVStruct(csv) ;
    }
    
    /* Azimuth Bandwith and resolution */ 
    info->azimuthBandwidth = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//processingParameter/azimuthLookBandwidth", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->azimuthBandwidth)) ;
        freeCSVStruct(csv) ;
    }

    info->azimuthResolutionCell = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//productSpecific/complexImageInfo/projectedSpacingAzimuth", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->azimuthResolutionCell)) ;
        freeCSVStruct(csv) ;
    }

    info->lineTimeInterval = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//productInfo/imageDataInfo/imageRaster/columnSpacing[@units ='s']", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->lineTimeInterval)) ;
        freeCSVStruct(csv) ;
    }
    
    /* Doppler polynomial with respect to range in [Hz]/[pixel] */
    /* Remark: This is an approximation */
    /* For TerraSAR-X, several range polynomials are given for different range gates */
    /* The nowadays InSAR processor only uses a single polynomial supposed to ba valid for the whole image */
    /* we thus comput an average of each polynomial coefficient */
    aDouble = info->fdc[0] = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//doppler/dopplerCentroid/dopplerEstimate/combinedDoppler/coefficient[@exponent = '0']", doc))) {
        for (i = 0; i < csv->numberOfEntries; i++) {
            sscanf(csv->stringVal[i], "%lf", &(aDouble)) ;
            info->fdc[0] += aDouble ;
        }
        info->fdc[0] /= csv->numberOfEntries ;
        freeCSVStruct(csv) ;
    }
    
    aDouble = info->fdc[1] = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//doppler/dopplerCentroid/dopplerEstimate/combinedDoppler/coefficient[@exponent = '1']", doc))) {
        for (i = 0; i < csv->numberOfEntries; i++) {
            sscanf(csv->stringVal[i], "%lf", &(aDouble)) ;
            info->fdc[1] += aDouble ;
        }
        info->fdc[1] /= csv->numberOfEntries ;
        freeCSVStruct(csv) ;
    }
    info->fdc[1] *= secondsPerPixels ;
    
    aDouble = info->fdc[2] = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//doppler/dopplerCentroid/dopplerEstimate/combinedDoppler/coefficient[@exponent = '2']", doc))) {
        for (i = 0; i < csv->numberOfEntries; i++) {
            sscanf(csv->stringVal[i], "%lf", &(aDouble)) ;
            info->fdc[2] += aDouble ;
        }
        info->fdc[2] /= csv->numberOfEntries ;
        freeCSVStruct(csv) ;
    }
    info->fdc[2] *= pow(secondsPerPixels, 2.) ;
    
    /* azimuth times and incidence angles */
    info->FPAT = info->LPAT = 0. ;
    if((csvX = readCSVInXMLFileForXPath((xmlChar*)"//sceneInfo/sceneCornerCoord/refColumn", doc))) {
        csvY = readCSVInXMLFileForXPath((xmlChar*)"//sceneInfo/sceneCornerCoord/refRow", doc) ;
        csvAzTime = readCSVInXMLFileForXPath((xmlChar*)"//sceneInfo/sceneCornerCoord/azimuthTimeUTC", doc) ;
        csvRangeTime = readCSVInXMLFileForXPath((xmlChar*)"//sceneInfo/sceneCornerCoord/rangeTime", doc) ;
        
        /* We look for the record corresponding to the first azimuth pixel at closest range */
        sscanf(csvX->stringVal[0], "%d", &minX) ;
        sscanf(csvY->stringVal[0], "%d", &minY) ;
        anIndex = 0 ;
        for (i = 0; i < csvY->numberOfEntries; i++) {
            sscanf(csvY->stringVal[i], "%d", &anInt) ;
            if (anInt <= minY) {
                minY = anInt ;
                sscanf(csvX->stringVal[i], "%d", &anInt) ;
                if (anInt <= minX) {
                    minX = anInt ;
                    anIndex = i ;
                }
            }
        }

        sscanf(&(csvAzTime->stringVal[anIndex][11]), "%lf", &(hh)) ;
        sscanf(&(csvAzTime->stringVal[anIndex][14]), "%lf", &(mm)) ;
        sscanf(&(csvAzTime->stringVal[anIndex][17]), "%lf", &(ss)) ;
        info->FPAT = 3600. * hh + 60. * mm + ss ; ;
        info->FPAT -= (minY - 1) * info->lineTimeInterval ;

        
        /* We look for the record corresponding to the last azimuth pixel at far range */
        sscanf(csvX->stringVal[0], "%d", &maxX) ;
        sscanf(csvY->stringVal[0], "%d", &maxY) ;
        anIndex = 0 ;
        for (i = 0; i < csvY->numberOfEntries; i++) {
            sscanf(csvY->stringVal[i], "%d", &anInt) ;
            if (anInt >= maxY) {
                maxY = anInt ;
                sscanf(csvX->stringVal[i], "%d", &anInt) ;
                if (anInt >= maxX) {
                    maxX = anInt ;
                    anIndex = i ;
                }
            }
        }
        sscanf(csvRangeTime->stringVal[anIndex], "%lf", &info->slantRange[2]) ;
        sscanf(&(csvAzTime->stringVal[anIndex][11]), "%lf", &(hh)) ;
        sscanf(&(csvAzTime->stringVal[anIndex][14]), "%lf", &(mm)) ;
        sscanf(&(csvAzTime->stringVal[anIndex][17]), "%lf", &(ss)) ;
        info->LPAT = 3600. * hh + 60. * mm + ss ;
        info->slantRange[2] *= c0/2. ;
        info->slantRange[1] = (info->slantRange[0] + info->slantRange[2])/2. ;
        
        freeCSVStruct(csvX) ;
        freeCSVStruct(csvY) ;
        freeCSVStruct(csvAzTime) ;
        freeCSVStruct(csvRangeTime) ;
    }
    

    
    /* State vectors */
    /* First Vector Time */
    info->FVT = 0. ;
    info->nVect = 0 ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//orbit/orbitHeader/firstStateTime/firstStateTimeUTC", doc))) {
        sscanf(&(csv->stringVal[0][11]), "%lf", &(hh)) ;
        sscanf(&(csv->stringVal[0][14]), "%lf", &(mm)) ;
        sscanf(&(csv->stringVal[0][17]), "%lf", &(ss)) ;
        info->FVT = 3600. * hh + 60. * mm + ss ; ;
        freeCSVStruct(csv) ;
    }

    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//orbit/orbitHeader/numStateVectors", doc))) {
        sscanf(csv->stringVal[0], "%d", &(info->nVect)) ;
        freeCSVStruct(csv) ;
    }        
    
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//orbit/orbitHeader/stateVectorTimeSpacing", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->Dt)) ;
        freeCSVStruct(csv) ;
    }        
    
    if(info->nVect) {
        /* We extract all state vectors time positions */
        stateVectorsTime = vectorDouble(0, info->nVect - 1) ;
        csv = readCSVInXMLFileForXPath((xmlChar*)"//orbit/stateVec/timeUTC", doc) ;
        for (i = 0; i < csv->numberOfEntries; i++) {
            sscanf(&(csv->stringVal[i][11]), "%lf", &(hh)) ;
            sscanf(&(csv->stringVal[i][14]), "%lf", &(mm)) ;
            sscanf(&(csv->stringVal[i][17]), "%lf", &(ss)) ;
            stateVectorsTime[i] = 3600. * hh + 60. * mm + ss ; ;
        }
        freeCSVStruct(csv) ;
        
        /* Now we extract all positions and velocities */
        csvX = readCSVInXMLFileForXPath((xmlChar*)"//orbit/stateVec/posX", doc) ;
        csvY = readCSVInXMLFileForXPath((xmlChar*)"//orbit/stateVec/posY", doc) ;
        csvZ = readCSVInXMLFileForXPath((xmlChar*)"//orbit/stateVec/posZ", doc) ;
        csvVX = readCSVInXMLFileForXPath((xmlChar*)"//orbit/stateVec/velX", doc) ;
        csvVY = readCSVInXMLFileForXPath((xmlChar*)"//orbit/stateVec/velY", doc) ;
        csvVZ = readCSVInXMLFileForXPath((xmlChar*)"//orbit/stateVec/velZ", doc) ;
        
        /* We wil select only the five state vectors encompassing the data */
        i0 = 0 ;
        if(info->nVect > 5) {
            i0 = 0 ;
            diffAvg0 = fabs((info->LPAT + info->FPAT)/2. - (stateVectorsTime[4] + stateVectorsTime[0])/2.) ;
            for (i = 0; i < info->nVect - 5; i++) {
                diffAvg = fabs((info->LPAT + info->FPAT)/2. - (stateVectorsTime[i + 4] + stateVectorsTime[i])/2.) ;
                if(diffAvg < diffAvg0) {
                    diffAvg0 = diffAvg ;
                    i0 = i ;
                }
            }
            info->nVect = 5 ;
            info->FVT = stateVectorsTime[i0] ;
        }
        
        if((info->S = (struct stateVect *)malloc(info->nVect * sizeof(struct stateVect))) == NULL)
            ase("State vector allocation error\n") ;
        for(i = 0; i < info->nVect; i++) {
            stateVectorIndex = i0 + i ;
            info->S[i].P = vectorDouble(0, 2) ;
            info->S[i].V = vectorDouble(0, 2) ;
            sscanf(csvX->stringVal[stateVectorIndex], "%lf", &(info->S[i].P[0])) ;
            sscanf(csvY->stringVal[stateVectorIndex], "%lf", &(info->S[i].P[1])) ;
            sscanf(csvZ->stringVal[stateVectorIndex], "%lf", &(info->S[i].P[2])) ;
            sscanf(csvVX->stringVal[stateVectorIndex], "%lf", &(info->S[i].V[0])) ;
            sscanf(csvVY->stringVal[stateVectorIndex], "%lf", &(info->S[i].V[1])) ;
            sscanf(csvVZ->stringVal[stateVectorIndex], "%lf", &(info->S[i].V[2])) ;
            info->S[i].t = stateVectorsTime[stateVectorIndex] ;
        }
        
        freeCSVStruct(csvX) ;
        freeCSVStruct(csvY) ;
        freeCSVStruct(csvZ) ;
        freeCSVStruct(csvVX) ;
        freeCSVStruct(csvVY) ;
        freeCSVStruct(csvVZ) ;       
   }
    
	info->aX = info->aY = info->aZ = info->aVx= info->aVy= info->aVz = NULL ;
	info->isOrbitInterpolationDone = 0 ;
    
    /* Reference ellipsoid */
    /* First, we look for the path to the GEOREF.xml file */
    csv = readCSVInXMLFileForXPath((xmlChar*)"//productComponents/annotation/type", doc) ;
    anIndex = 0 ;
    for (i = 0; i < csv->numberOfEntries; i++) {
        if(!strcmp(csv->stringVal[i], "GEOREF"))
            anIndex = i + 1 ;
    }
    freeCSVStruct(csv) ;
    
    sprintf(aComment, "//productComponents/annotation[%d]/file/location/path", anIndex) ;
    csv = readCSVInXMLFileForXPath((xmlChar*)aComment, doc) ;
    aString = initStringWith3Strings(getDirectoryPathFromPath(filePath), "/", csv->stringVal[0]) ;
    freeCSVStruct(csv) ;

    sprintf(aComment, "//productComponents/annotation[%d]/file/location/filename", anIndex) ;
    csv = readCSVInXMLFileForXPath((xmlChar*)aComment, doc) ;
    georefXMLFilePath = initStringWith3Strings(aString, "/", csv->stringVal[0]) ;
    freeCSVStruct(csv) ;
    free(aString) ;

    /* Now that we have the path, we can open the XML file */
    georefDoc = getdoc(georefXMLFilePath) ;

    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL)
        ase("Erreur d'allocation de *info->ellRef\n") ;
    
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//geoReference/referenceFrames/sphere/ellipsoidID", georefDoc))) {
        sprintf(info->ellRef->ellipsoidID, "%s", csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->ellRef->ellipsoidID, "Undefined ellipsoid") ;
    }
    
    info->ellRef->a = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//geoReference/referenceFrames/sphere/semiMajorAxis", georefDoc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->ellRef->a)) ;
        freeCSVStruct(csv) ;
    }
    
    info->ellRef->b = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//geoReference/referenceFrames/sphere/semiMinorAxis", georefDoc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->ellRef->b)) ;
        freeCSVStruct(csv) ;
    }
    
    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;
    
	/* Geolocate scene on reference ellipsoid */
    info->sceneAverageHeight = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sceneInfo/sceneAverageHeight",doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->sceneAverageHeight)) ;
        freeCSVStruct(csv) ;
    }
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
	info->EarthRadiusAtSceneCenter = 6371221. ;
	info->loc = allocQuadrilateral() ;
    info->incidenceAngle[0] = 0. ;
	geolocateSceneOnEllipsoid(info, info->ellRef) ;
	
	xmlFreeDoc(georefDoc);
	xmlFreeDoc(doc);
	xmlCleanupParser();

    return info ;
}




