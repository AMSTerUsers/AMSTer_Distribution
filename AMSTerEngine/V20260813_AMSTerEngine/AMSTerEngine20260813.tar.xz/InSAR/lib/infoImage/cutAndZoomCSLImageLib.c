
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  cutAndZoomCSLImageLib.c
//  cutAndZoomCSLImage
//
//  Created by Dominique Derauw on 16/12/2020.
//  Copyright (c) 2020 Dominique Derauw. All rights reserved.
//

#include "cutAndZoomCSLImage.h"



int cutAndZoomMain(CSVStruct *csv_CL) {
	char *aString, *inputFilePath, *outputFilePath, withMirroring, enlargedZone, isGEO ;
    char *aPath, *kmlFilePath, *DEMFilePath ;
    int xDimIn, yDimIn, iPol, i ;
	double **transformCoefficients, Ax, By ;
    double *H = NULL, hAvg ;
	keyValue *paramList ;
	rawFileDescriptor *inputFile, *outputFile, *tempFile ;
    time_t startTime, endTime ;
    CSLImage *inputCSLImage, *outputCSLImage = NULL ;
    SLCImageInfo *info = NULL ;
    CSVStruct *pol = NULL ;
    quadrilateral *qAoI, *qAoI2 ;
    polygon *aoi, *aoi2 = NULL ;
    externalDEMStruct *externalDEM ;

	if(csv_CL->numberOfEntries == 1 || isFlagPresentInCSV(csv_CL, "h") || isArgumentPresentInCSV(csv_CL, "-help")) {
        cutAndZoomUsage() ;
    }
    if(isArgumentPresentInCSV(csv_CL, "-create")) {
        createCutAndZoomParameterFileAtPath(csv_CL->stringVal[1]) ;
        return (0) ;
    }
	time(&startTime) ;

    /* Check if enlarged zone is requested */
	enlargedZone = isFlagPresentInCSV(csv_CL, "e") ;
    
    /* Check if mirroring is requested for interpolation process */
	withMirroring = isFlagPresentInCSV(csv_CL, "m") ;

    /* Check if scene average height is forced to a specific value */
    hAvg = -9999 ;
    if ((i = isArgumentPresentInCSV(csv_CL, "H="))) {
        sscanf(csv_CL->stringVal[i] + 2, "%lf", &hAvg) ;
    }
    


	/* Allocate transform */
	transformCoefficients = (double **)matrixDouble(0, 3, 0, 2) ;
	
	/* Read parameter File */ 
	paramList = readParameterFileAtPath((char *)csv_CL->stringVal[1]) ;
	
	/* Get input/output file location */
	if((aString = getStringValForKeyIn(paramList, "Input file path")) == NULL)
		ase("Missing parameter: \"Input file path\"") ;
	inputFilePath = readFirstStringIn(aString) ;
    
    inputCSLImage = NULL ;
    /* Determine if we deal with a CSL image structure */
    if ((inputCSLImage = getCSLImageStructureAtPath(inputFilePath))) {
        free(inputFilePath) ;
        
        /* Read corresponding infoImage file */
        info = readInfoImageInCSLImage(inputCSLImage) ;
        pol = readCSVInString(info->polMode) ;
    }
    else {
        ase("Input image is not a CSL format image") ;
    }
    
    /* Get X/Y input dimensions */
    xDimIn = info->rangeDimension ;
    yDimIn = info->azimuthDimension ;

    
    if((aString = getStringValForKeyIn(paramList, "Output file path")) == NULL) {
		ase("Missing parameter: \"Output file path\"") ;
    }
	outputFilePath = readFirstStringIn(aString) ;
    
    /* If we deal with CSL images, create directory structure at indicated path */
    outputCSLImage = createCSLDirectoryStructureAtPath(outputFilePath, 0) ;
    free(outputFilePath) ;
	
	/* Get zoom coefficients */
    Ax = getDoubleValForKeyIn(paramList, "X zoom") ;
    By = getDoubleValForKeyIn(paramList, "Y zoom") ;
    
    /* Get area of interest */
    /* First look for a kml */
    if ((kmlFilePath = getStringValForKeyIn(paramList, "kml"))) {
        aoi = getPolygonalAoIFromKMLFile(kmlFilePath) ;
        isGEO = 1 ;
    }
    /* If not found ...*/
    if (!aoi) {
        /* Read given aoi */
        isGEO = (!strncmp(getStringValForKeyIn(paramList, "Coordinate"), "GEO", 3)) ? 1 : 0 ;
        aoi = allocQuadrilateral() ;
        aoi->P[0].x = aoi->P[3].x = getDoubleValForKeyIn(paramList, "X0" ) ;
        aoi->P[2].x = aoi->P[1].x = getDoubleValForKeyIn(paramList, "X2" ) ;
        aoi->P[0].y = aoi->P[1].y = getDoubleValForKeyIn(paramList, "Y0" ) ;
        aoi->P[2].y = aoi->P[3].y = getDoubleValForKeyIn(paramList, "Y2" ) ;
    }
    if (!aoi->P[0].x && !aoi->P[0].y && !aoi->P[2].x && !aoi->P[2].y) {
        aoi->P[2].x = aoi->P[1].x= info->rangeDimension - 1 ;
        aoi->P[2].y = aoi->P[3].y = info->azimuthDimension - 1 ;
        isGEO = 0 ;
    }
    
    if (isGEO) {
        if (enlargedZone) {
            aoi2 = getCopyOfPolygon(aoi) ;
            convertAoIFromDeg2SRAForHeight(aoi, info, 0) ;
            convertAoIFromDeg2SRAForHeight(aoi2, info, 5000) ;
        }
        else {
            DEMFilePath = getStringValForKeyIn(paramList, "Georeferenced DEM file path") ;
            if ((externalDEM = openExternalDEMFile(DEMFilePath, csv_CL))) {
    //            info->sceneAverageHeight = updateSceneAverageHeight(inputCSLImage, externalDEM) ;   
                H = getLocalHeightsOfAoISummits(getStringValForKeyIn(paramList, "kml"), getStringValForKeyIn(paramList, "Georeferenced DEM file path"), info->sceneAverageHeight) ;
                convertAoIFromDeg2SRA(aoi, info, H) ;
            }
            else {
                if (hAvg != -9999) {
                    convertAoIFromDeg2SRAForHeight(aoi, info, hAvg) ;
                }
                else {
                    convertAoIFromDeg2SRAForHeight(aoi, info, info->sceneAverageHeight) ;
                }
            }
        }
    }

    qAoI = circumscribedRectangleOfPolygon(aoi) ;
    if (aoi2) {
        qAoI2 = circumscribedRectangleOfPolygon(aoi2) ;
        qAoI->P[0].x = (qAoI2->P[0].x > qAoI->P[0].x)? qAoI->P[0].x : qAoI2->P[0].x ;
        qAoI->P[0].y = (qAoI2->P[0].y > qAoI->P[0].y)? qAoI->P[0].y : qAoI2->P[0].y ;
        qAoI->P[2].x = (qAoI2->P[2].x < qAoI->P[2].x)? qAoI->P[2].x : qAoI2->P[2].x ;
        qAoI->P[2].y = (qAoI2->P[2].y < qAoI->P[2].y)? qAoI->P[2].y : qAoI2->P[2].y ;
        freePolygon(qAoI2) ;
        freePolygon(aoi2) ;
    }
        
    aoi->P[0].x = qAoI->P[0].x = (qAoI->P[0].x > 0)? qAoI->P[0].x : 0 ;
    aoi->P[0].y = qAoI->P[0].y = (qAoI->P[0].y > 0)? qAoI->P[0].y : 0 ;
    aoi->P[2].x = qAoI->P[2].x = (qAoI->P[2].x < info->rangeDimension - 1)? qAoI->P[2].x : info->rangeDimension - 1 ;
    aoi->P[2].y = qAoI->P[2].y = (qAoI->P[2].y < info->azimuthDimension - 1)? qAoI->P[2].y : info->azimuthDimension - 1 ;

    setIntValForKeyIn(paramList, aoi->P[0].x, "X0 = lower left corner X coordinate") ;
    setIntValForKeyIn(paramList, aoi->P[0].y, "Y0 = lower left corner Y coordinate") ;
    setIntValForKeyIn(paramList, aoi->P[2].x, "X2 = upper right corner X coordinate") ;
    setIntValForKeyIn(paramList, aoi->P[2].y, "Y2 = upper right corner Y coordinate") ;
    setStringValForKeyIn(paramList, "SRA" , "Coordinate system [SRA / GEO]") ;

    writeParameterFileAtPath(paramList, csv_CL->stringVal[1]) ;
    
    /* We deal with a CSL image, adapt infoImage file taking into account the zoom factors and the area of intersest */
    info->rangeDimension = (int)ceil(Ax * (qAoI->P[2].x - qAoI->P[0].x + 1)) ;
    info->azimuthDimension = (int)ceil(By * (qAoI->P[2].y - qAoI->P[0].y + 1)) ;
    info->FPAT += info->lineTimeInterval * qAoI->P[0].y ;
    info->twoWayRangeTime[0] += 2. / c0 * (info->rangeResolutionCell * qAoI->P[0].x) ;
    info->rangeResolutionCell /= Ax ;
    info->azimuthResolutionCell /= By ;
    info->lineTimeInterval /= By ;
    info->slantRange[0] = c0 / 2. * info->twoWayRangeTime[0] ;
    info->slantRange[2] = info->slantRange[0] + info->rangeDimension * info->rangeResolutionCell ;
    info->slantRange[1] = (info->slantRange[0] + info->slantRange[2]) / 2. ;
    info->incidenceAngle[0] = 0. ;
    geolocateSceneOnEllipsoid(info, info->ellRef) ;
    info->LPAT = info->FPAT + (info->azimuthDimension - 1) * info->lineTimeInterval ;
    
    aPath = initStringWith2Strings(outputCSLImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
    saveInfoImage(info, aPath) ;
    saveInfoKmlInDir(info, outputCSLImage->infoDirectoryPath) ;
    free(aPath) ;
    
    sprintf(accessPath, "%s/tempFile", outputCSLImage->dataDirectoryPath) ;
    tempFile = openRawFileForReadingAndWritingAtPath(accessPath) ;
    tempFile->xDim = info->rangeDimension ;
    tempFile->yDim = qAoI->P[2].y - qAoI->P[0].y + 1 ;
    
    transformCoefficients[0][0] = 1./Ax ;
    transformCoefficients[0][1] = 0. ;
    transformCoefficients[0][2] = 0. ;
    transformCoefficients[1][0] = 0. ;
    transformCoefficients[1][1] = 1./By ;
    transformCoefficients[1][2] = 0. ;
	
	printf("Data extraction and interpolation:\n") ;
	printf("Input file: %s\n", inputCSLImage->imageDirectoryPath) ;
	printf("Output file: %s\n", outputCSLImage->imageDirectoryPath) ;
    printf("\nArea of interest:\n") ;
    printf("Lower left slant range - azimuth coordinate : (%d ; %d)\n", (int)qAoI->P[0].x, (int)qAoI->P[0].y) ;
    printf("Upper right slant range -  azimuth coordinate : (%d ; %d)\n\n", (int)qAoI->P[2].x, (int)qAoI->P[2].y) ;
    printf("Applied transform: \n") ;
	printf("x2 = %-7.3f * x1 + %-7.3f * y1 + %-7.3f\n", transformCoefficients[0][0], transformCoefficients[0][1], transformCoefficients[0][2]) ;
	printf("y2 = %-7.3f * x1 + %-7.3f * y1 + %-7.3f\n", transformCoefficients[1][0], transformCoefficients[1][1], transformCoefficients[1][2]) ;
	printf("Input dimension: xDim = %d\tyDim = %d\n", xDimIn, yDimIn) ;
	printf("Output dimension: xDim = %d\tyDim = %d\n", info->rangeDimension, info->azimuthDimension) ;
    
    /* Get frequency shifts if present */
    transformCoefficients[2][0] = getDoubleValForKeyIn(paramList, "X frequency shift") ;
    transformCoefficients[2][1] = getDoubleValForKeyIn(paramList, "X sampling frequency") ;
    transformCoefficients[3][0] = getDoubleValForKeyIn(paramList, "Y frequency shift") ;
    transformCoefficients[3][1] = getDoubleValForKeyIn(paramList, "Y sampling frequency") ;
	
    
    for (iPol = 0; iPol < pol->numberOfEntries; iPol++) {
        inputFilePath = initStringWith3Strings(inputCSLImage->dataDirectoryPath, "/SLCData.", pol->stringVal[iPol]) ;
        if((inputFile = openRawFileForReadingAtPath(inputFilePath)) == NULL) {
            sprintf(aComment, "Unable to open file for reading at path: %s\n", inputFilePath) ;
            ase(aComment) ;
        }
        /* Get X/Y dimensions */
        inputFile->xDim = xDimIn ;
        inputFile->yDim = yDimIn ;
        inputFile->aoi = qAoI ;

        printf("\n\t---> Processing file %s\n", inputFile->fileName) ;
        
        outputFilePath = initStringWith3Strings(outputCSLImage->dataDirectoryPath, "/SLCData.", pol->stringVal[iPol]) ;
        if((outputFile = openRawFileForWritingAtPath(outputFilePath)) == NULL) {
            sprintf(aComment, "Unable to open file for writting at path: %s\n", outputFilePath) ;
            ase(aComment) ;
        }
        /* Compute output dimension if required */
        outputFile->xDim = info->rangeDimension ;
        outputFile->yDim = info->azimuthDimension ;
        
        if (isAffineTransformUnitary(transformCoefficients)) {
            extractAoI(inputFile, outputFile) ;
        }
        else {
            /* X dimension interpolation */
            interpolComplexAlongXAxis(inputFile, transformCoefficients, tempFile, withMirroring) ;
            
            /* Y dimension interpolation */
            interpolComplexAlongYAxis(tempFile, transformCoefficients, outputFile, withMirroring) ;
        }
        inputFile->aoi = NULL ;
        freeRawFileDescriptor(inputFile) ;
        freeRawFileDescriptor(outputFile) ;
        free(inputFilePath) ;
        free(outputFilePath) ;
        rewind(tempFile->f) ;
    }

    freeVectorDouble(H, 0) ;
    freePolygon(aoi) ;
    freePolygon(qAoI) ;
    freeRawFileDescriptor(tempFile) ;
    unlink(accessPath) ;
    freeMatrixDouble(transformCoefficients, 0, 0) ;
    freeKeyValueList(paramList) ;
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    
	return 0 ;
}



void cutAndZoomUsage() 
{
	printf("%s\n%s\n","Usage:", "cutAndZoomCSLImage pathToParameterFile [-create] [-e] [H=hAvg]") ;
    printf("\t-create: Allows creating an interface text file at indicated path\n") ;
    printf("\t-e:      extended zone\n") ;
    printf("By default, when used with a kml, cutAndZoom calculates de slant range DEM crop location using the external DEM if provided.\n") ;
    printf("If external DEM is not available, location calculation is based on scene average height.\n") ;
    printf("If this latter one is not known or set by default to 0, it may be given as hAvg value using option H=hAVg.\n") ;
    printf("Option -e allows calculating the slant range azimuth aoi corresponding to given kml \nas the union of the one calculated at altitude 0 and at altitude 5000m.\n") ;
 
	exit(0) ;
}

void createCutAndZoomParameterFileAtPath(char *aPath)
{
	keyValue *paramList ;
	
	paramList = allocAKeyValuePair() ;
	
	setStringValForKeyIn(paramList, "Cut and Zoom parameter file", "") ;
	setStringValForKeyIn(paramList, "***************************", "") ;
	setStringValForKeyIn(paramList, "inputFilePath\t\t", "Input file path in CSL format") ;
	setStringValForKeyIn(paramList, "outputFilePath\t\t", "Output file path") ;
	setStringValForKeyIn(paramList, "aPath\t\t", "Georeferenced DEM file path") ;
	setStringValForKeyIn(paramList, "", "") ;
	setStringValForKeyIn(paramList, "Zoom factors", "") ;
	setStringValForKeyIn(paramList, "1.0\t\t", "X zoom factor") ;
	setStringValForKeyIn(paramList, "1.0\t\t", "Y zoom factor") ;
    setStringValForKeyIn(paramList, "", "") ;
    setStringValForKeyIn(paramList, "Area of interest (if all zeros, the whole input image is considered)", "") ;
    setStringValForKeyIn(paramList, "GEO", "Coordinate system [SRA / GEO]") ;
    setStringValForKeyIn(paramList, "0", "X0 = lower left corner X coordinate") ;
    setStringValForKeyIn(paramList, "0", "Y0 = lower left corner Y coordinate") ;
    setStringValForKeyIn(paramList, "0", "X2 = upper right corner X coordinate") ;
    setStringValForKeyIn(paramList, "0", "Y2 = upper right corner Y coordinate") ;
    setStringValForKeyIn(paramList, "pathToKMLFile", "kml file path (.kml polygon saved from Google Earth)") ;

	writeParameterFileAtPath(paramList, aPath) ;
    
    return ;
}



void extractAoI(rawFileDescriptor *input, rawFileDescriptor *output)
{
    int iY, lineSize ;
    size_t seekVal ;
    complexFloat *V ;
    
    lineSize = (int)(input->aoi->P[2].x - input->aoi->P[0].x) + 1 ;
    V = vectorComplexFloat(0, lineSize - 1) ;
    rewind(output->f) ;
    seekVal = (size_t)(input->aoi->P[0].y * input->xDim + input->aoi->P[0].x) * COMPLEX_FLOAT_SIZE  ;
    for (iY = input->aoi->P[0].y; iY <= input->aoi->P[2].y; iY++, seekVal += input->xDim * COMPLEX_FLOAT_SIZE) {
        fseek(input->f, seekVal, SEEK_SET) ;
        fread(V, COMPLEX_FLOAT_SIZE, lineSize, input->f) ;
        fwrite(V, COMPLEX_FLOAT_SIZE, lineSize, output->f) ;
    }
}

