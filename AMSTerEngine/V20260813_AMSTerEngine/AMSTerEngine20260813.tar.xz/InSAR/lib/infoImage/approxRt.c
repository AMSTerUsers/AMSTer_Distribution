
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  approxRt.c
 *  genInfoImage
 *
 *  Created by Dominique Derauw on Mon Sep 29 2003.
 *  Copyright (c) 2003 Dominique Derauw. All rights reserved.
 *
 */

#include "approxRt.h"

/* Approximation du rayon terrestre pour l'ensemble de l'image */
/* Calcul des coefficients des polynomes d'ordre 2 donnant le rayon terrestre */
/* Il s'agit de polynomes du type Rt = Rt0 + a1x X + a1z Z + a2x X*X + a2z Z*Z */
/* dont les coefficients sont obtenus par moindre carrés */
double	*approxRt(SLCImageInfo *ima)
{
    int			i, j, *indexVector, Nx, Ny, N = 5 ;
    double		Rt0, xpix, rpix ;
    double		**M, *VRt, signe ;
	geoRef *geoRefPointer ;
    
	geoRefPointer = allocAndInitGeorefStructureForTargetEllipsoid(ima, ima->ellRef) ;
    ima->EarthRadiusPolynomial = vectorDouble(0, 4) ;
	
    Nx = Ny = 5 ;
    M = matrixDouble(1, N, 1, N) ;
    VRt = vectorDouble(1, N) ;
    indexVector = vectorInt(1, N) ;
    for(i = 1; i <= N; i++) {
        VRt[i] = 0. ;
        for(j = 1; j <= N; j++)
            M[i][j] = 0. ;
    }
    for(i = 0; i < Nx + 1; i++) {
        xpix = (double)i * ima->azimuthDimension / (double)Nx ;
        for(j = 0; j < Ny + 1; j++) {
            rpix = (double)j * ima->rangeDimension / (double)Ny ;
            Rt0 = earthRadiusAtPoint(rpix, xpix, ima->sceneAverageHeight, geoRefPointer) ;
            M[1][1] ++ ;
            M[1][2] += xpix ;
            M[1][3] += rpix ;
            M[1][4] += pow(xpix, 2.) ;
            M[1][5] += pow(rpix, 2.) ;
            
            M[2][3] += xpix * rpix ;
            M[2][4] += pow(xpix, 3.) ;
            M[2][5] += xpix * pow(rpix, 2.) ;
            
            M[3][4] += pow(xpix, 2.) * rpix ;
            M[3][5] += pow(rpix, 3.) ;
            
            M[4][4] += pow(xpix, 4.) ;
            M[4][5] += pow(xpix, 2.) * pow(rpix, 2.) ;
            
            M[5][5] += pow(rpix, 4.) ;

            VRt[4] += Rt0 * pow(xpix, 2.) ;
            VRt[5] += Rt0 * pow(rpix, 2.) ;
            VRt[2] += Rt0 * xpix ;
            VRt[3] += Rt0 * rpix ;
            VRt[1] += Rt0 ;
            }
    }
    for(i = 1; i <= N; i++)
        for(j= i+1; j <= N; j++)
            M[j][i] = M[i][j] ;
    
    M[2][2] = M[1][4] ;
    M[3][3] = M[1][5] ;
    
    ludcmp(M, N, indexVector, &signe) ;
    lubksb(M, N, indexVector, VRt) ;
    for(i = 1; i <= N; i++) ima->EarthRadiusPolynomial[i-1] = VRt[i] ;

    freeMatrixDouble(M, 1, 1) ;
    freeVectorDouble(VRt, 1) ;
    freeVectorInt(indexVector, 1) ;
    freeGeoRef(geoRefPointer) ;
	
	return(ima->EarthRadiusPolynomial) ;
}

double approximateEarthRadiusAtRangeAzimuthPosition(int rangePosition, int azimuthPosition, double *EarthRadiusPolynomial) 
{
	return(EarthRadiusPolynomial[0] + azimuthPosition * EarthRadiusPolynomial[1] + rangePosition * EarthRadiusPolynomial[2] + pow((double)azimuthPosition, 2.) * EarthRadiusPolynomial[3] + pow((double)rangePosition, 2.) * EarthRadiusPolynomial[4]) ;
}


/* The following function verify if the average height H of the scene is compatible with the sensor distance S, the minimum slant range z and the Earth radius RT */
/* Espacially in airborne systems, if the local height is set to zero by default, it can lead to a situation where S, RT + H and z does not form a triangle (S > RT + z) */
void sceneAverageHeightCrossCheck(SLCImageInfo *info)
{
    double xPix, rPix ;             /* azimuth and range coordinates in pixels */
    double S, z, Hmin, incidenceAngle = 0, Rt ;
    geoRef *gR  ;

    if (info->incidenceAngle[1]) {
        xPix = (double)info->azimuthDimension / 2. ;
        rPix = (double)info->rangeDimension / 2. ;
        incidenceAngle = PI/ 180 *info->incidenceAngle[1] ;
    }
    else{
        xPix = (double)info->azimuthDimension / 2. ;
        rPix = 0. ;
        incidenceAngle = PI/ 180 *info->incidenceAngle[0] ;
    }
    if (incidenceAngle) {
        gR = allocAndInitGeorefStructureForTargetEllipsoid(info, info->ellRef) ;
        calcStateVect(gR->solving->S, (double)xPix, gR->params->info) ;
        initOnSphereSolving(gR->solving) ;
        
        /* We  initialize the Earth radius with value at scene centre */
        info->EarthRadiusAtSceneCenter = Rt = earthRadiusAtPoint(rPix, xPix, 0, gR) ;

        /* We  initialize the Earth radius with value at nadir */
//        onEllipsoidProjection(gR->solving->V3, gR->solving->S->P, gR->solving) ;
//        info->EarthRadiusAtSceneCenter = Rt = vectorNorm(gR->solving->V3) ;
        
        S = vectorNorm(gR->solving->S->P) ;
        z = gR->params->info->slantRange[0] + rPix * gR->params->info->rangeResolutionCell ;
        
        Hmin = sqrt(pow(S, 2.) - pow(z * sin(incidenceAngle), 2.)) - z*cos(incidenceAngle) - Rt ;
        info->sceneAverageHeight = (Hmin > info->sceneAverageHeight && Hmin < 5000)? Hmin : info->sceneAverageHeight ;
        
        rPix = (double)info->rangeDimension / 2. ;
        info->EarthRadiusAtSceneCenter = earthRadiusAtPoint(rPix, xPix, info->sceneAverageHeight, gR) ;
        
        freeGeoRef(gR) ;
    }
}

