
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  CSLImageFormat.c
 *  ERSDataReader
 *
 *  Created by Dominique Derauw on 10/10/11.
 *  Copyright 2011 Dominique Derauw. All rights reserved.
 *
 */

#include "CSLImageFormat.h"
#include "errno.h"

CSLImage *createCSLDirectoryStructureAtPath(char *aPath, int satelliteID)
{
    char *extension ;
    CSLImage *aCSLImage ;

    if ((aPath = expandEnvironmentVariablesInPath(aPath)) == NULL) {
        return (NULL) ;
    }
    aCSLImage = allocAndInitCSLImage() ;
    
    if (!(extension = getPointerToLastFileExtensionInPath(aPath))) {
        aCSLImage->imageDirectoryPath = allocStringOfLength(strlen(aPath) + 4) ;
        sprintf(aCSLImage->imageDirectoryPath, "%s.csl", aPath) ;
    }
    else {
        if (strncmp(extension, "csl", 3)) {
            aCSLImage->imageDirectoryPath = allocStringOfLength(strlen(aPath) + 4) ;
            sprintf(aCSLImage->imageDirectoryPath, "%s.csl", aPath) ;
        }
        else {
            aCSLImage->imageDirectoryPath = initStringWithString(aPath) ;
        }
    }

    createCSLDirectoryStructureFor(aCSLImage, satelliteID) ;
    free(aPath) ;

    return (aCSLImage) ;
}

CSLImage *createCSLDirectoryStructureFor(CSLImage *aCSLImage, int satelliteID)
{
    char *CSLImageParentDirectory, *readmePath, *subDirName ;
    char *aPath ;
	rawFileDescriptor *readmeFile ;


    if (!(aPath = aCSLImage->imageDirectoryPath)) {
        ase("Failed to create CSLImage. imageDirectoryPath not defined\n") ;
    }

	if((CSLImageParentDirectory = getDirectoryPathFromPath(aPath)) == NULL) {
		sprintf(ertex, "%s is not a valid directory path\n", aPath) ;
		ase(ertex) ;
	}

	if(!isWriteAccessGrantedAtPath(CSLImageParentDirectory)) {
		sprintf(ertex, "Write acces denied for path %s\n", aPath) ;
		ase(ertex) ;
	}

	if(isDir(aCSLImage->imageDirectoryPath)) {
		printf("File already exists at path %s\n", aCSLImage->imageDirectoryPath) ;
        printf("Overwrite? [Y/N]\n") ;
        if((char)getchar() != 'Y' && (char)getchar() != 'y') {
            sprintf(ertex, "No overwriting upon user's request") ;
            ase(ertex) ;
        }
        getchar() ;
        removeDirectoryAtPath(aCSLImage->imageDirectoryPath) ;
	}

	if(mkdir((const char *)aCSLImage->imageDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
		sprintf(ertex, "Failed to create image directory at path %s\n", aPath) ;
		ase(ertex) ;
	}

	aCSLImage->dataDirectoryPath = allocStringOfLength(strlen(aCSLImage->imageDirectoryPath) + 5L) ;
	sprintf(aCSLImage->dataDirectoryPath, "%s/Data", aCSLImage->imageDirectoryPath) ;
	if(mkdir((const char *)aCSLImage->dataDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
		sprintf(ertex, "Failed to create image directory at path %s\n", aCSLImage->dataDirectoryPath) ;
		ase(ertex) ;
	}

	readmePath = allocStringOfLength(strlen(aCSLImage->dataDirectoryPath) + 13) ;
	sprintf(readmePath, "%s/_readme.txt", aCSLImage->dataDirectoryPath) ;
	readmeFile = openRawFileForWritingAtPath(readmePath) ;
	fprintf(readmeFile->f, "This directory contains image data in raw format.\nDo not change names or location!\n") ;
	fprintf(readmeFile->f, "Complete format description should be explained in a text file in the ../Info directory for each data file.\n") ;
    freeRawFileDescriptor(readmeFile) ;
	free(readmePath) ;

	aCSLImage->headersDirectoryPath = allocStringOfLength(strlen(aCSLImage->imageDirectoryPath) + 8) ;
	sprintf(aCSLImage->headersDirectoryPath, "%s/Headers", aCSLImage->imageDirectoryPath) ;
	if(mkdir((const char *)aCSLImage->headersDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
		sprintf(ertex, "Failed to create image directory at path %s\n", aCSLImage->headersDirectoryPath) ;
		ase(ertex) ;
	}
    if (satelliteID == __SENTINEL1__) {
        if(!strncmp(getPointerToFileNameInPath(aCSLImage->imageDirectoryPath), "Frame", 5)) {
            subDirName = initStringWith2Strings(aCSLImage->headersDirectoryPath, "/calibration") ;
            if(mkdir((const char *)subDirName, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
                sprintf(ertex, "Failed to create image calibration directory at path %s\n", subDirName) ;
                ase(ertex) ;
            }
            free(subDirName) ;
        }
    }

	readmePath = allocStringOfLength(strlen(aCSLImage->headersDirectoryPath) + 13) ;
	sprintf(readmePath, "%s/_readme.txt", aCSLImage->headersDirectoryPath) ;
	readmeFile = openRawFileForWritingAtPath(readmePath) ;
	fprintf(readmeFile->f, "This directory contains original headers data in their native format.\nDo not change names or location!\n") ;
    freeRawFileDescriptor(readmeFile) ;
	free(readmePath) ;

	aCSLImage->infoDirectoryPath = allocStringOfLength(strlen(aCSLImage->imageDirectoryPath) + 5) ;
	sprintf(aCSLImage->infoDirectoryPath, "%s/Info", aCSLImage->imageDirectoryPath) ;
	if(mkdir((const char *)aCSLImage->infoDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
		sprintf(ertex, "Failed to create image directory at path %s\n", aCSLImage->infoDirectoryPath) ;
		ase(ertex) ;
	}

    if (satelliteID == __SENTINEL1__) {
        subDirName = initStringWith2Strings(aCSLImage->infoDirectoryPath, "/PerBurstInfo") ;
        if(mkdir((const char *)subDirName, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create image per-burst info directory at path %s\n", subDirName) ;
            ase(ertex) ;
        }
        free(subDirName) ;
    }

	readmePath = allocStringOfLength(strlen(aCSLImage->infoDirectoryPath) + 13) ;
	sprintf(readmePath, "%s/_readme.txt", aCSLImage->infoDirectoryPath) ;
	readmeFile = openRawFileForWritingAtPath(readmePath) ;
	fprintf(readmeFile->f, "This directory should contains text files describing specific format for each data file in ../Data directory.\n") ;
	fprintf(readmeFile->f, "It should also contains additional info text file required for further processing.\nDo not change names or location!\n") ;
    freeRawFileDescriptor(readmeFile) ;
	free(readmePath) ;

	free(CSLImageParentDirectory) ;

	return(aCSLImage) ;
}


CSLImage *allocAndInitCSLImage()
{
	CSLImage *aCSLImage ;

    if((aCSLImage = malloc(sizeof(CSLImage))) == NULL) {
		ase("Failed to allocate CSLImage structure") ;
        exit(-1 );
    }
	aCSLImage->numberOfDataFiles = aCSLImage->numberOfHeaderFiles = aCSLImage->numberOfInfoFiles = aCSLImage->numberOfFrames = 0 ;
    aCSLImage->dataFileNames = aCSLImage->headerFileNames = aCSLImage->infoFileNames = NULL ;
    aCSLImage->imageDirectoryPath = aCSLImage->dataDirectoryPath = aCSLImage->headersDirectoryPath = aCSLImage->infoDirectoryPath = NULL ;
    aCSLImage->dataTypeID = -1 ;

	return(aCSLImage) ;
}


/* List CSL images in given directory */
CSVStruct *listCSLImagesInDir(char *aDir)
{
    int i ;
    CSVStruct *CSLImageList = NULL ;

    CSLImageList = listDirectoriesOfNameInDir(".csl", aDir) ;
    if (CSLImageList) {
        for (i = 0; i < CSLImageList->numberOfEntries; i++) {
                if (!isSLCImageInfoPresentInCSLImageAtPath(CSLImageList->stringVal[i])) {
                printf("\t-/-> No SLCInfoImage.txt file found within .csl image at path %s\n\t\t---> Skipping it\n", CSLImageList->stringVal[i]) ;
                removeStringValAtIndexInCSVStruct(i, CSLImageList) ;
            }
        }    
    }
    
    return(CSLImageList) ;
}

/* Simply check if given file path is a .csl path. If not, extension .csl is appended to given path */
char *getCSLImagePathFromPath (char *imagePath) 
{
    char *accesPath, *aPath ;

    if ((aPath = expandEnvironmentVariablesInPath(imagePath)) == NULL) {
        return (NULL) ;
    }

    if (!getPointerToLastFileExtensionInPath(aPath)) {
        accesPath = initStringWith2Strings(aPath, ".csl") ;
    }
    else {
        if(!strncmp(getPointerToLastFileExtensionInPath(aPath), "csl", 3)) {
            accesPath = initStringWithString(aPath) ;
        }
        else {
            accesPath = initStringWith2Strings(aPath, ".csl") ;
        }
    }
    free(aPath) ;

    return accesPath ;
}

char isSLCImageInfoPresentInCSLImageAtPath(char *imagePath) 
{
    char *SLCImageInfoFilePath, checkVal ;

    SLCImageInfoFilePath = initStringWith2Strings(imagePath, "/Info/SLCImageInfo.txt") ;
    checkVal = fileExistsAtPath(SLCImageInfoFilePath) ;
    free(SLCImageInfoFilePath) ;

    return(checkVal) ;
}

char isCSLImageAtPath(char *imagePath)
{
    CSLImage *aCSLImage ;

    if ((aCSLImage = getCSLImageStructureAtPath(imagePath)) == NULL) {
        return (0) ;
    }
    freeCSLImageStructure(aCSLImage) ;

    return(1) ;
}

CSLImage *getCSLImageStructureAtPath(char *imagePath)
{
    char *accesPath ;
    CSLImage *aCSLImage ;

    /* Must be a .csl path */
    if ((accesPath = getCSLImagePathFromPath(imagePath)) == NULL) {
        return (NULL) ;
    }

    /* Must be a directory */
    if(!isDir(accesPath)) {
        free(accesPath) ;
        return(NULL) ;
    }

    aCSLImage = allocAndInitCSLImage() ;
    aCSLImage->imageDirectoryPath = initStringWithString(accesPath) ;

    /* A Data directory must exist */
    aCSLImage->dataDirectoryPath = initStringWith2Strings(accesPath, "/Data") ;
    if (!isDir(aCSLImage->dataDirectoryPath)) {
        freeCSLImageStructure(aCSLImage) ;
        free(accesPath) ;
        return(NULL) ;
    }
    aCSLImage->dataFileNames = getDirectoryEntriesAtPath(aCSLImage->dataDirectoryPath) ;
    aCSLImage->numberOfDataFiles = getNumberOfDirectoryEntriesAtPath(aCSLImage->dataDirectoryPath) ;

    /* A Header directory should exist */
    aCSLImage->headersDirectoryPath = initStringWith2Strings(accesPath, "/Headers") ;
    aCSLImage->headerFileNames = getDirectoryEntriesAtPath(aCSLImage->headersDirectoryPath) ;
    aCSLImage->numberOfHeaderFiles = getNumberOfDirectoryEntriesAtPath(aCSLImage->headersDirectoryPath) ;

    /* An Info directory must exist and it must contain an SLCInfoImage.txt text file */
    aCSLImage->infoDirectoryPath = initStringWith2Strings(accesPath, "/Info") ;
    if (!isDir(aCSLImage->infoDirectoryPath)) {
        freeCSLImageStructure(aCSLImage) ;
        free(accesPath) ;
        return(NULL) ;
    }
    aCSLImage->infoFileNames = getDirectoryEntriesAtPath(aCSLImage->infoDirectoryPath) ;
    aCSLImage->numberOfInfoFiles = getNumberOfDirectoryEntriesAtPath(aCSLImage->infoDirectoryPath) ;

    free(accesPath) ;

    return(aCSLImage) ;
}


void freeCSLImageStructure(CSLImage *aCSLImage)
{
	int i ;

    if (aCSLImage) {
        if(aCSLImage->dataFileNames) {
            for(i = 0; i < aCSLImage->numberOfDataFiles; i++) {
                if (aCSLImage->dataFileNames[i]) {
                    free(aCSLImage->dataFileNames[i]) ;
                    aCSLImage->dataFileNames[i]= NULL ;
                }
            }
            free(aCSLImage->dataFileNames) ;
            aCSLImage->dataFileNames = NULL ;
        }

        if(aCSLImage->headerFileNames) {
            for(i = 0; i < aCSLImage->numberOfHeaderFiles; i++) {
                if (aCSLImage->headerFileNames[i]) {
                    free(aCSLImage->headerFileNames[i]) ;
                    aCSLImage->headerFileNames[i]= NULL ;
                }
            }
            free(aCSLImage->headerFileNames) ;
            aCSLImage->headerFileNames = NULL ;
        }

        if(aCSLImage->infoFileNames) {
            for(i = 0; i < aCSLImage->numberOfInfoFiles; i++) {
                if (aCSLImage->infoFileNames[i]) {
                    free(aCSLImage->infoFileNames[i]) ;
                    aCSLImage->infoFileNames[i]= NULL ;
                }
            }
            free(aCSLImage->infoFileNames) ;
            aCSLImage->infoFileNames = NULL ;
        }

        if (aCSLImage->dataDirectoryPath) {
            free(aCSLImage->dataDirectoryPath) ;
            aCSLImage->dataDirectoryPath = NULL ;
        }
        if (aCSLImage->headersDirectoryPath) {
            free(aCSLImage->headersDirectoryPath) ;
            aCSLImage->headersDirectoryPath = NULL ;
        }
        if (aCSLImage->infoDirectoryPath) {
            free(aCSLImage->infoDirectoryPath) ;
            aCSLImage->infoDirectoryPath = NULL ;
        }
        if (aCSLImage->imageDirectoryPath) {
            free(aCSLImage->imageDirectoryPath) ;
            aCSLImage->imageDirectoryPath = NULL ;
        }

        free(aCSLImage) ;
        aCSLImage = NULL ;
    }
}


char isFilePresentInCSLImage(CSLImage *anImage, char *aFileName)
{
    int index ;

    for (index = 0; index < anImage->numberOfDataFiles; index++) {
        if (!strcmp(aFileName, anImage->dataFileNames[index])) {
            return (1) ;
        }
    }
    for (index = 0; index < anImage->numberOfHeaderFiles; index++) {
        if (!strcmp(aFileName, anImage->headerFileNames[index])) {
            return (1) ;
        }
    }
    for (index = 0; index < anImage->numberOfInfoFiles; index++) {
        if (!strcmp(aFileName, anImage->infoFileNames[index])) {
            return (1) ;
        }
    }
    return (0) ;
}

/* This function is mainly aimed at Sentinel1 (or TOPSAR) image handling to verify that stitched image is well present and with the correct dimension */
/* All requested polarization must be present to return true */
/* If *info is NULL, info is read from infiImage.txt file contained in the .csl image */
char isSLCDataFilePresentInCSLImage(CSLImage *anImage, SLCImageInfo *info)
{
    char doNotForgetToFreeInfoImage = 0 ;
    char isOk = 1, *filePath ;
    int i ;
    off_t fileSize ;
    CSVStruct *pol ;

    if (!isCSLImageAtPath(anImage->imageDirectoryPath)) {
        return (0) ;
    }
    
    if (!info) {
        doNotForgetToFreeInfoImage = 1 ;
        info = readInfoImageInCSLImage(anImage) ;
    }
    
    fileSize = (off_t)(info->rangeDimension * info->azimuthDimension * sizeof(complexFloat)) ;
    pol = readCSVInString(info->polMode) ;
    for (i = 0; i < pol->numberOfEntries; i++) {
        filePath = initStringWith3Strings(anImage->dataDirectoryPath, "/SLCData.", pol->stringVal[i]) ;
        if (isOk && fileExistsAtPath(filePath)) {
            isOk *= (fileSize == getFileLengthAtPath(filePath)) ;
        }
        else {
            isOk = 0 ;
//            printf("Expected file size of image %s\n", filePath) ;
//            printf("%d X %d X sizeof(complexFloat) = %lld\n", info->rangeDimension, info->azimuthDimension, fileSize) ;
//            printf("Effective file size:\t\t\t%lld\n\n", getFileLengthAtPath(filePath)) ;
        }
        free(filePath) ;
    }
    freeCSVStruct(pol) ;
    
    if (doNotForgetToFreeInfoImage) {
        freeInfoImage(info) ;
    }
    
    return (isOk) ;
}

char *getPathToFileInCSLImage(CSLImage *anImage, char *aFileName)
{
    int index ;
    size_t fileNameLength ;

    fileNameLength = strlen(aFileName) ;
    for (index = 0; index < anImage->numberOfDataFiles; index++) {
        if (!strncmp(anImage->dataFileNames[index], aFileName, fileNameLength)) {
            return (anImage->dataFileNames[index]) ;
        }
    }
    for (index = 0; index < anImage->numberOfHeaderFiles; index++) {
        if (!strncmp(anImage->headerFileNames[index], aFileName, fileNameLength)) {
            return (anImage->headerFileNames[index]) ;
        }
    }
    for (index = 0; index < anImage->numberOfInfoFiles; index++) {
        if (!strncmp(anImage->infoFileNames[index], aFileName, fileNameLength)) {
            return (anImage->infoFileNames[index]) ;
        }
    }
    return (NULL) ;
}


void copyCSLImage(char *inputImagePath, char *destinationPath, int flag)
{
    char frameFlag ;
    char *aPath, burstName[15], *inputBurstPath, *outputBurstPath ;
    char *inputPath, *outputPath, aKey[_MAX_COMMENT_LENGTH_] ;
    char *inputFramePath, *outputFramePath, frameName[20] ;
    int index ;
    int frameIndex, numberOfFrames ;
    int swathIndex, firstSwathIndex, lastSwathIndex ;
    int burstIndex, firstBurstIndex, numberOfSelectedBursts ;
    int layerIndex ;
    CSLImage *inputImage, *outputImage ;
    keyValue *burstSelection ;
    CSVStruct *csv, *pol ;
    SLCImageInfo *info ;

    if ((inputImage = getCSLImageStructureAtPath(inputImagePath)) == NULL) {
        sprintf(ertex, "Failed to copy CSL image.\n---> No valid input image at path %s", inputImagePath) ;
        ase(ertex) ;
    }
    numberOfFrames = getNumberOfFramesInCSLImage(inputImage) ;

    if (flag & _CSLIMAGE_OVERWRITE_ && isCSLImageAtPath(destinationPath)) {
        if ((outputImage = getCSLImageStructureAtPath(destinationPath)) == NULL) {
            sprintf(ertex, "Failed to overwrite CSL image.\n---> No valid output image at path %s", destinationPath) ;
            ase(ertex) ;
        }
    }
    else {
        info = readInfoImageInCSLImage(inputImage) ;
        outputImage = createCSLDirectoryStructureAtPath(destinationPath, info->sensorID) ;
        freeInfoImage(info) ;
    }

    /* Copy data files included in each frame */
    if (flag & _CSLIMAGE_DATA_) {
        if (numberOfFrames) {
            for (frameIndex = 0; frameIndex < numberOfFrames; frameIndex++) {
                frameFlag = _CSLIMAGE_DATA_ | _CSLIMAGE_OVERWRITE_ ;
                sprintf(frameName, "Frame%1d.csl", frameIndex) ;
                inputFramePath = initStringWith3Strings(inputImage->dataDirectoryPath, "/", frameName) ;
                outputFramePath = initStringWith3Strings(outputImage->dataDirectoryPath, "/", frameName) ;
                copyCSLImage(inputFramePath, outputFramePath, frameFlag) ;
                free(inputFramePath) ;
                free(outputFramePath) ;
            }
            for (index = 0; index < inputImage->numberOfDataFiles; index++) {
                inputPath = initStringWith3Strings(inputImage->dataDirectoryPath, "/", inputImage->dataFileNames[index]) ;
                outputPath = initStringWith3Strings(outputImage->dataDirectoryPath, "/", inputImage->dataFileNames[index]) ;
                if (fileExistsAtPath(inputPath)) {
                    copyFileAtPathToPath(inputPath, outputPath) ;
                }
                free(inputPath) ;
                free(outputPath) ;
            }
       }
        else {
            copyDirAtPathToPath(inputImage->dataDirectoryPath, outputImage->dataDirectoryPath) ;
        }
    }

    /* Copy bursts included in each frames considering burstSelection.txt file include either in the input image or already updated in the output image */
    if (flag & _CSLIMAGE_SELECTED_BURSTS_IN_ || flag & _CSLIMAGE_SELECTED_BURSTS_OUT_) {
        if (numberOfFrames) {
            for (frameIndex = 0; frameIndex < numberOfFrames; frameIndex++) {
                frameFlag = _CSLIMAGE_OVERWRITE_ ;
                frameFlag |= (flag & _CSLIMAGE_SELECTED_BURSTS_IN_)? _CSLIMAGE_SELECTED_BURSTS_IN_ : 0 ;
                frameFlag |= (flag & _CSLIMAGE_SELECTED_BURSTS_OUT_)? _CSLIMAGE_SELECTED_BURSTS_OUT_ : 0 ;
                sprintf(frameName, "Frame%1d.csl", frameIndex) ;
                inputFramePath = initStringWith3Strings(inputImage->dataDirectoryPath, "/", frameName) ;
                outputFramePath = initStringWith3Strings(outputImage->dataDirectoryPath, "/", frameName) ;
                copyCSLImage(inputFramePath, outputFramePath, frameFlag) ;
                free(inputFramePath) ;
                free(outputFramePath) ;
            }
        }
        else {
            if (flag & _CSLIMAGE_SELECTED_BURSTS_IN_) {
                aPath = initStringWith2Strings(inputImage->infoDirectoryPath, "/burstSelection.txt") ;
            }
            else {
                aPath = initStringWith2Strings(outputImage->infoDirectoryPath, "/burstSelection.txt") ;
            }

            /* If a burstSelection.txt file exists, then there is a burst selection to copy... */
            if (fileExistsAtPath(aPath)) {
                burstSelection = readParameterFileAtPath(aPath) ;
                free(aPath) ;

                pol = readCSVInString(getStringValForKeyIn(burstSelection, "Polarization")) ;
                firstSwathIndex = getIntValForKeyIn(burstSelection, "First swath index") ;
                lastSwathIndex = getIntValForKeyIn(burstSelection, "Last swath index") ;

                for (swathIndex = firstSwathIndex; swathIndex <= lastSwathIndex; swathIndex++) {
                    sprintf(aKey, "Swath %1d burst selection", swathIndex) ;
                    if((csv = getCSVValForKeyIn(burstSelection, aKey)) == NULL) {
                        ase("Failed to read burst selection in image") ;
                    }
                    sscanf(csv->stringVal[0], "%d", &firstBurstIndex) ;
                    numberOfSelectedBursts = csv->numberOfEntries ;
                    freeCSVStruct(csv) ;

                    for (layerIndex = 0; layerIndex < pol->numberOfEntries; layerIndex++) {
                        for (burstIndex = firstBurstIndex; burstIndex < firstBurstIndex + numberOfSelectedBursts; burstIndex++) {
                            sprintf(burstName, "SW%1db%1d.csl", swathIndex, burstIndex) ;
                            inputBurstPath = initStringWith3Strings(inputImage->dataDirectoryPath, "/", burstName) ;

                            /* Test if we deal with S1 .csl new format in input */
                            if (isDir(inputBurstPath)) {
                                inputPath = initStringWith3Strings(inputBurstPath, "/Data/SLCData.", pol->stringVal[layerIndex]) ;
                            }
                            else {
                                sprintf(burstName, "SW%1d.b%1d.%s", swathIndex, burstIndex, pol->stringVal[layerIndex]) ;
                                inputPath = initStringWith3Strings(inputImage->dataDirectoryPath, "/", burstName) ;
                                freeCSLImageStructure(createCSLDirectoryStructureAtPath(outputBurstPath, __SENTINEL1__)) ;
                            }
                            
                            /* Output is necessarily in new format */
                            outputBurstPath = initStringWith3Strings(outputImage->dataDirectoryPath, "/", burstName) ;
                            outputPath = initStringWith3Strings(outputBurstPath, "/Data/SLCData.", pol->stringVal[layerIndex]) ;

                            copyFileAtPathToPath(inputPath, outputPath) ;

                            free(inputPath) ;
                            free(outputPath) ;

                            /* Now deal with ETAD data if present */
                            inputPath = initStringWith2Strings(inputBurstPath, "/ETADData") ;
                            if (!layerIndex && isDir(inputPath)) {
                                outputPath = initStringWith2Strings(outputBurstPath, "/ETADData") ;
                                copyDirAtPathToPath(inputPath, outputPath) ;
                                free(outputPath) ;                            
                            }
                            free(inputBurstPath) ;
                            free(outputBurstPath) ;
                            free(inputPath) ;
                        }
                    }
                }
                freeKeyValueList(burstSelection) ;
                freeCSVStruct(pol) ;
            }
        }
    }



    if (flag & _CSLIMAGE_HEADERS_) {
        if (numberOfFrames) {
            for (frameIndex = 0; frameIndex < numberOfFrames; frameIndex++) {
                frameFlag = _CSLIMAGE_OVERWRITE_ ;
                frameFlag |= _CSLIMAGE_HEADERS_  ;
                sprintf(frameName, "Frame%1d.csl", frameIndex) ;
                inputFramePath = initStringWith3Strings(inputImage->dataDirectoryPath, "/", frameName) ;
                outputFramePath = initStringWith3Strings(outputImage->dataDirectoryPath, "/", frameName) ;
                copyCSLImage(inputFramePath, outputFramePath, frameFlag) ;
                free(inputFramePath) ;
                free(outputFramePath) ;
            }
        }
        else {
            copyDirAtPathToPath(inputImage->headersDirectoryPath, outputImage->headersDirectoryPath) ;
        }
    }

    if (flag & _CSLIMAGE_INFO_) {
        if (numberOfFrames) {
            for (frameIndex = 0; frameIndex < numberOfFrames; frameIndex++) {
                frameFlag = _CSLIMAGE_OVERWRITE_ ;
                frameFlag |= (flag & _CSLIMAGE_INFO_)? _CSLIMAGE_INFO_ : 0 ;
                sprintf(frameName, "Frame%1d.csl", frameIndex) ;
                inputFramePath = initStringWith3Strings(inputImage->dataDirectoryPath, "/", frameName) ;
                outputFramePath = initStringWith3Strings(outputImage->dataDirectoryPath, "/", frameName) ;
                copyCSLImage(inputFramePath, outputFramePath, frameFlag) ;
                free(inputFramePath) ;
                free(outputFramePath) ;
            }
        }
        else {
                copyDirAtPathToPath(inputImage->infoDirectoryPath, outputImage->infoDirectoryPath) ;
        }
    }
    freeCSLImageStructure(inputImage) ;
    freeCSLImageStructure(outputImage) ;
}

gridMap *allocAndInitExternalFileGridForImage(CSLImage *anImage, char *fileName)
{
    char *aPath ;
    int Nx, Ny, dNx, dNy, iX, iY ;
    void *aFileLine ;
    keyValue *fileDescription, *aKeyVal ;
    gridMap *fileGrid ;
    rawFileDescriptor *theFile ;
    size_t typeSize ;

    /* Verify that the requested external file is available at predefined location */
    aPath = initStringWith3Strings(anImage->dataDirectoryPath, "/", fileName) ;
    if ((theFile = openRawFileForReadingAtPath(aPath)) == NULL) {
        free(aPath) ;
        return (NULL) ;
    }
    free(aPath) ;

    /* Verify that a file description is available at predefined location */
    aPath = initStringWith4Strings(anImage->infoDirectoryPath, "/", fileName, ".txt") ;
    if (!fileExistsAtPath(aPath)) {
        free(aPath) ;
        aPath = initStringWith2Strings(anImage->infoDirectoryPath, "/externalSlantRangeDEM.txt") ;
        if (!fileExistsAtPath(aPath)) {
            free(aPath) ;
            printf("\t-/-> No description available for file %s\n", fileName) ;
            return (NULL) ;
        }
    }

    /* Read description file */
    fileDescription = readParameterFileAtPath(aPath) ;
    free(aPath) ;

    /* Read necessary file parameters */
    Nx = getIntValForKeyIn(fileDescription, "X size of projected products") ;
    Ny = getIntValForKeyIn(fileDescription, "Y size of projected products") ;
    dNx = getIntValForKeyIn(fileDescription, "X sampling of projected product") ;
    dNy = getIntValForKeyIn(fileDescription, "Y sampling of projected product") ;
    typeSize = (theFile->fileLength == (size_t)(Nx * Ny))? 1 : 4 ;
    if (typeSize == 4) {
        if (theFile->fileLength != (size_t)4 * Nx * Ny) {
            printf("\t-/-> %s External file dimensions do not corresponds to those given in description file.\n", fileName) ;
            return (NULL) ;
        }
    }
    

    /* init Grid */
    if ((fileGrid = createGridOfSize(Nx, Ny, dNx, dNy, typeSize)) == NULL) {
        return (fileGrid) ;
    }
    switch (fileGrid->typeSize) {
    case 1:
        fileGrid->charVal = (char **)fileGrid->M ;
        break;
    
    case 4:
        fileGrid->floatVal = (float **)fileGrid->M ;
        break;
    
    default:
        ase("\t-/-> allocAndInitExternalFileGridForImage: File type not taken into account\n") ;
        break;
    }
    
    fileGrid->x0 = getDoubleValForKeyIn(fileDescription, "xMin") ;
    fileGrid->y0 = getDoubleValForKeyIn(fileDescription, "yMin") ;
    if((aKeyVal = isKeyValContainingStringPresent(fileDescription, "Excluding value"))) {
        if (!strncmp(aKeyVal->stringVal, "NaN", 3)) {
            fileGrid->noVal = genFloatNaN() ;
        }
        else {
            sscanf(aKeyVal->stringVal, "%lf ", &(fileGrid->noVal)) ;
        }
    }

    /* Transfer file values to grid */
    /* Yes, I know it's stupid, but grid values are transposed with respect to saved slant range DEM... */
    /* First verify type of file. If byte, we suppose we deal with a binary mask */
    aFileLine = vectorOfType(0, Nx - 1, typeSize) ;
    for (iY = 0; iY < Ny; iY++) {
        if ((fread(aFileLine, typeSize, Nx, theFile->f)) != (size_t)Nx) {
            ase("\t -/-> Grid initialization for mask failed. I have to stop here. Sorry...") ;
        }
        for (iX = 0; iX < Nx; iX++) {
            memcpy(fileGrid->M[iX] + iY * typeSize, aFileLine + typeSize * iX, typeSize) ;
        }
    }
    freeVectorOfType(aFileLine, 0, typeSize) ;
    freeRawFileDescriptor(theFile) ;
    freeKeyValueList(fileDescription) ;

    return (fileGrid) ;
}

SLCImageInfo *readInfoImageInCSLImage(CSLImage *aCSLImage)
{
    char *aPath ;
    SLCImageInfo *infoImage ;

    aPath = initStringWith2Strings(aCSLImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
    infoImage = readInfoImageFromTextFile(aPath) ;
    free(aPath) ;

    return (infoImage) ;
}

SLCImageInfo *readInfoImageInCSLImageAtPath(char *imagePath)
{
    char *aPath ;
    CSLImage *aCSLImage ;
    SLCImageInfo *infoImage = NULL ;

    if ((aCSLImage = getCSLImageStructureAtPath(imagePath))) {
        aPath = initStringWith2Strings(aCSLImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
        infoImage = readInfoImageFromTextFile(aPath) ;
        infoImage->CSLImagePath = initStringWithString(imagePath) ;
        free(aPath) ;   
        freeCSLImageStructure(aCSLImage) ;     
    }

    return (infoImage) ;
}

void saveInfoImageInCSLImage(SLCImageInfo *infoImage, CSLImage *aCSLImage)
{
    char *aPath ;

    aPath = initStringWith2Strings(aCSLImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
    saveInfoImage(infoImage, aPath) ;
    free(aPath) ;
}

/* infoImage.txt file is read. Then orbit is interpolated and scene geolocation is performed */
SLCImageInfo *readAndInitInfoImageInCSLImage(CSLImage *aCSLImage)
{
    SLCImageInfo *infoImage = NULL ;

    if ((infoImage = readInfoImageInCSLImage(aCSLImage))) {
        orbitInterpolation(infoImage) ;
        geolocateSceneOnEllipsoid(infoImage, infoImage->ellRef) ;
    }

    return (infoImage) ;
}



CSLImage **getFrameListInCSLImage(CSLImage *aCSLImage, size_t *numberOfFrames)
{
    int i ;
    CSVStruct *frameNameList ;
    CSLImage **frameList ;

    if ((frameNameList = recursiveSearchOfDirInDir("Frame", aCSLImage->dataDirectoryPath)) == NULL) {
        return (NULL) ;
    }
    *numberOfFrames = frameNameList->numberOfEntries ;

    if ((frameList = malloc(frameNameList->numberOfEntries * sizeof(CSLImage*))) == NULL) {
        ase("\t-/->\tFailed to allocate frame list.") ;
    }

    for (i = 0; i < frameNameList->numberOfEntries; i++) {
        if ((frameList[i] = getCSLImageStructureAtPath(frameNameList->stringVal[i])) == NULL) {
            sprintf(ertex, "Wrong frame. Frame at path %s is not a .csl image", frameNameList->stringVal[i]) ;
            ase(ertex) ;
        }
    }

    freeCSVStruct(frameNameList) ;

    return (frameList) ;
}

void freeCSLImageListing(CSLImage **imageList, int numberOfImages) 
{
    int i ;

    for ( i = 0; i < numberOfImages; i++) {
        freeCSLImageStructure(imageList[i]) ;
    }
    free(imageList) ;
}


int unsigned  getNumberOfFramesInCSLImage(CSLImage *aCSLImage)
{
    char **directoryEntries ;
    int unsigned frameCount ;
    int numberOfEntries, i ;

    directoryEntries = getDirectoryContentAtPath(aCSLImage->dataDirectoryPath, &numberOfEntries) ;

    frameCount = 0 ;
    for (i = 0; i < numberOfEntries; i++) {
        frameCount += (!strncmp("Frame", directoryEntries[i], 5))? 1 : 0 ;
    }

    freeDirectoryEntries(directoryEntries, numberOfEntries) ;
    return (frameCount) ;
}


/* If frame is already existing in container, its index is returned */
/* If not present, -1 is returned */
int getFrameIndexInCSLImage(CSLImage *aCSLImage, SLCImageInfo *newFrameInfo)
{
    char isPresent ;
    int frameIndex, numberOfFrames ;
    SLCImageInfo *existingFrameInfo ;
    CSVStruct *newFrameID = NULL, *existingFrameID = NULL ;

    numberOfFrames = getNumberOfFramesInCSLImage(aCSLImage) ;
    isPresent = -1 ;
    newFrameID = readCSVInString(newFrameInfo->scene_id) ;
    for (frameIndex = 0; frameIndex < numberOfFrames; frameIndex++) {
        sprintf(accessPath, "%s/Frame%1d.csl/Info/SLCImageInfo.txt", aCSLImage->dataDirectoryPath, frameIndex) ;
        existingFrameInfo = readInfoImageFromTextFile(accessPath) ;
        existingFrameID = readCSVInString(existingFrameInfo->scene_id) ;
        if (!strcmp(newFrameID->stringVal[0], existingFrameID->stringVal[0])) {
            isPresent = frameIndex ;
            break ;
        }
        if (!strncmp(newFrameID->stringVal[0], existingFrameID->stringVal[0], 62)) {
            /* If we find a new frame that is a Normal Archive while the existing one is a Fast-24h, we force overwriting */
            if (isSubStringPresentInString(existingFrameID->stringVal[1], "Fast") && isSubStringPresentInString(newFrameID->stringVal[1], "ArchNormal")) {
                printf("\t---> Existing \"Fast-24h\" frame will be removed and replaced by \"ArchNormal\" one\n") ;
                newFrameInfo->flag |= _CSLIMAGE_FORCE_OVERWRITTING_ ;
            }
            else {
                /* If strangely, we find another frame that is also an ArchNormal, we cancel overwritting, forcing to keep existing frame */
                newFrameInfo->flag |= _CSLIMAGE_CANCEL_OVERWRITTING_ ;
            }
            isPresent = frameIndex ;
            break ;
        }

    }
    freeInfoImage(existingFrameInfo) ;
    freeCSVStruct(existingFrameID) ;
    freeCSVStruct(newFrameID) ;

    return (isPresent) ;
}


/* Frame ordering */
/* Since this is done each time a new frame is added with highest frame index, we just have to locate it within preceeding frames */
int getNewFrameIndexInCSLImage(CSLImage *imageContainer, double frameFPAT)
{
    char stop, *commandLine ;
    int frameIndex, numberOfFrames ;
    CSLImage *currentFrame  ;
    SLCImageInfo *currentInfo ;

    numberOfFrames = getNumberOfFramesInCSLImage(imageContainer) ;
    frameIndex = numberOfFrames ;

    stop = 0 ;
    while (frameIndex > 0 && !stop) {
        frameIndex-- ;
        sprintf(accessPath, "%s/Frame%1d.csl", imageContainer->dataDirectoryPath, frameIndex) ;
        if ((currentFrame = getCSLImageStructureAtPath(accessPath)) == NULL) {
            sprintf(ertex, "Wrong frame. Frame at path %s is not a .csl image", accessPath) ;
            ase(ertex) ;
        }
        currentInfo = readInfoImageInCSLImage(currentFrame) ;

        if (frameFPAT < currentInfo->FPAT) {
            sprintf(accessPath, "%s/Frame%1d.csl", imageContainer->dataDirectoryPath, frameIndex + 1) ;
            printf("\t\t---> Re-ordering frames\n") ;
            if ((rename(currentFrame->imageDirectoryPath, accessPath))) {
                printf("Error code : %d\n", errno) ;
                perror("\t\t-/-> Failed to rename frame.\n") ;
                commandLine = initStringWith4Strings("mv -f , ", currentFrame->imageDirectoryPath, " ", accessPath) ;
                printf("\t\t---> Trying to use mv instead:\n\t\t%s\n", commandLine) ;
                if(system(commandLine)) {
                    perror("\t\t-/-> Failed to mv frame.\n") ;
                }
            }
        }
        else {
            frameIndex++ ;
            stop = 1 ;
        }

        freeInfoImage(currentInfo) ;
        freeCSLImageStructure(currentFrame) ;
    }

    return (frameIndex) ;
}

/* Get list of .csl image within directory */
CSVStruct *getListingOfCSLImagesInDir(char *inputDir, char *fromDate, char *toDate)
{
    char **directoryListing, *aPath ;
    int i, N, isSelected ;
    CSVStruct *CSLImageDirList = NULL, *dateList = NULL ;
    CSLImage *anImage ;
    SLCImageInfo *imageInfo ;
    
    directoryListing = getDirectoryContentAtPath(inputDir, &N) ;
    for (i = 0; i < N; i++) {
        aPath = initStringWith3Strings(inputDir, "/", directoryListing[i]) ;
        if ((anImage = getCSLImageStructureAtPath(aPath))) {
            isSelected = 1 ;
            if (fromDate || toDate) {
                imageInfo = readInfoImageInCSLImage(anImage) ;
                if (fromDate) {
                    isSelected = (strncmp(fromDate, imageInfo->acquisitionDate, 8) <= 0)? 1 : 0 ; 
                }
                if (toDate && isSelected) {
                    isSelected = (strncmp(toDate, imageInfo->acquisitionDate, 8) >= 0)? 1 : 0 ; 
                }
                freeInfoImage(imageInfo) ;
            }
            if (isSelected) {
                CSLImageDirList = addStringValInCSVStruct(aPath, CSLImageDirList) ;
            }
        }
        free(aPath) ;
    }
    freeCSVStruct(dateList) ;
    freeDirectoryEntries(directoryListing, N) ;
    
    return (CSLImageDirList) ;
}

/* Remove empty frames */
/* After interferometric burst selection, master and slave images might be copied into InSAR processing directory */
/* If interferometric burst selection lead to rejecting some frames, these ones must be removed from the image container */
/* Empty frames are identified by the missing burstSelection.txt file */
void removeEmptyFramesInCSLImage(CSLImage *imageContainer)
{
    char *newFrameFilePath ;
    int frameIndex, numberOfFrames ;
    CSLImage *currentFrame  ;
    CSVStruct *csv ;

    numberOfFrames = getNumberOfFramesInCSLImage(imageContainer) ;
    frameIndex = 0 ;
    while (frameIndex < numberOfFrames) {
        sprintf(accessPath, "%s/Frame%1d.csl", imageContainer->dataDirectoryPath, frameIndex) ;
        if ((currentFrame = getCSLImageStructureAtPath(accessPath)) == NULL) {
            sprintf(ertex, "Wrong frame. Frame at path %s is not a .csl image", accessPath) ;
            ase(ertex) ;
        }

        /* If frame must be removed, proceed */
        if (!(csv = recursiveSearchOfFileInDir("burstSelection.txt", currentFrame->infoDirectoryPath))) {
            removeDirectoryAtPath(currentFrame->imageDirectoryPath) ;

            for (; frameIndex < numberOfFrames - 1; frameIndex++) {
                newFrameFilePath = initStringWithString(accessPath) ;
                sprintf(accessPath, "%s/Frame%1d.csl", imageContainer->dataDirectoryPath, frameIndex + 1) ;
                rename(accessPath, newFrameFilePath) ;
            }
            frameIndex = -1 ;
            numberOfFrames-- ;
        }
        freeCSVStruct(csv) ;
        freeCSLImageStructure(currentFrame) ;

        frameIndex++ ;
    }
}


void renameCSLImage(CSLImage *aCSLImage, char *newName)
{
    char *CSLImageParentDirectory ;
    char *aPath, *oldPath ;
    
    
    if (!(aPath = aCSLImage->imageDirectoryPath)) {
        ase("Failed to rename CSLImage. imageDirectoryPath not defined\n") ;
    }
    
    if((CSLImageParentDirectory = getDirectoryPathFromPath(aPath)) == NULL) {
        sprintf(ertex, "%s is not a valid directory path\n", aPath) ;
        ase(ertex) ;
    }
    
    if(!isWriteAccessGrantedAtPath(CSLImageParentDirectory)) {
        sprintf(ertex, "Write acces denied for path %s\n", aPath) ;
        ase(ertex) ;
    }
    
    oldPath = initStringWithString(aCSLImage->imageDirectoryPath) ;
    free(aCSLImage->imageDirectoryPath) ;
    if (getPointerToLastFileExtensionInPath(newName)) {
        aCSLImage->imageDirectoryPath = initStringWith2Strings(CSLImageParentDirectory, newName) ;
    }
    else {
        aCSLImage->imageDirectoryPath = initStringWith3Strings(CSLImageParentDirectory, newName, ".csl") ;
    }

    free(aCSLImage->dataDirectoryPath) ;
    aCSLImage->dataDirectoryPath = allocStringOfLength(strlen(aCSLImage->imageDirectoryPath) + 5L) ;
    sprintf(aCSLImage->dataDirectoryPath, "%s/Data", aCSLImage->imageDirectoryPath) ;
    
    free(aCSLImage->headersDirectoryPath) ;
    aCSLImage->headersDirectoryPath = allocStringOfLength(strlen(aCSLImage->imageDirectoryPath) + 8) ;
    sprintf(aCSLImage->headersDirectoryPath, "%s/Headers", aCSLImage->imageDirectoryPath) ;
    
    free(aCSLImage->infoDirectoryPath) ;
    aCSLImage->infoDirectoryPath = allocStringOfLength(strlen(aCSLImage->imageDirectoryPath) + 5) ;
    sprintf(aCSLImage->infoDirectoryPath, "%s/Info", aCSLImage->imageDirectoryPath) ;
   
    rename(oldPath, aCSLImage->imageDirectoryPath) ;
    
    free(CSLImageParentDirectory) ;
    free(oldPath) ;
}



/* This function check zero borders of images to extract the aoi corresponding to the effective image */
/* Function created to cope with SAOCOM images bordered by very large empty (zero) borders */
quadrilateral *getMaxAoiOfCSLImage(CSLImage *thisImage)
{
    char *inputFilePath ; 
    char testMin, testMax, testSup = 0 ;
    int iY, Nx, Ny, iXInf, iXSup ;
    int iMin, iMax ;
    size_t lineLength ;
    SLCImageInfo *info ;
    CSVStruct *SLCDataFile ;
    rawFileDescriptor *inputFile ;
    complexFloat *aLine ;
    quadrilateral *aoi = NULL;

    info = readInfoImageInCSLImage(thisImage) ;
    SLCDataFile = recursiveSearchOfFileNamesInDir("SLCData", thisImage->dataDirectoryPath) ;
    if (SLCDataFile) {
        inputFilePath = initStringWith3Strings(thisImage->dataDirectoryPath, "/", SLCDataFile->stringVal[0]) ;
        freeCSVStruct(SLCDataFile) ;
        if (!(inputFile = openRawFileForReadingAtPath(inputFilePath))) {
            free(inputFilePath) ;
            ase("\t-/-> Failed to open polarization layer into CSL image.\n") ;
        }
        
        Nx = info->rangeDimension ;
        Ny = info->azimuthDimension ;
        lineLength = (size_t)Nx ;
        aLine = vectorComplexFloat(0, Nx - 1) ;
        aoi = allocQuadrilateral() ;
        aoi->P[0].x = aoi->P[2].x = -1 ;
        aoi->P[0].y = aoi->P[2].y = 0 ;
        for (iY = 0; iY < Ny; iY++) {
            if (fread(aLine, sizeof(aLine[0]), lineLength, inputFile->f) != lineLength) {
                ase("Failed to read line in input file\n") ;
            }
            iMin = iXInf = 0 ;
            iMax = iXSup = Nx - 1 ;
            testMin = testMax = 1 ;
            while ((testMin || testMax) && (iXInf < Nx/2 + 1)) {
                if (testMin && !aLine[iXInf].r && !aLine[iXInf].i) {
                    iMin++ ;
                }
                else {
                    testMin = 0 ;
                }
                
                if (testMax && aLine[iXSup].r && !aLine[iXSup].i) {
                    iMax-- ;
                }
                else {
                    testMax = 0 ;
                }

                iXInf++ ;
                iXSup-- ;
            }

            if (iXInf >= iXSup) {
                if (!testSup) {
                    aoi->P[0].y++ ;
                }
                else {
                    aoi->P[2].y = iY ;
                    break ;
                }
            }
            else {
                aoi->P[0].x = (aoi->P[0].x == -1)? iXInf : (aoi->P[0].x > iXInf)? iXInf : aoi->P[0].x ;
                aoi->P[2].x = (aoi->P[2].x == -1)? iXSup : (aoi->P[2].x < iXSup)? iXSup : aoi->P[2].x ;
                testSup = 1 ;
            }
        }
        
        freeVectorOfType(aLine, 0, 8) ;
        freeRawFileDescriptor(inputFile) ;
        free(inputFilePath) ;
    }
    else {
        ase("\t-/-> Polarization layer not found in CSL image structure.\n\t-/-> Cannot procced to look for cropping area\n") ;
        freeInfoImage(info); 
    }
    freeInfoImage(info); 
 
    if (aoi->P[0].x == -1 && aoi->P[2].x == -1 && !aoi->P[0].y && !aoi->P[2].y) {
        aoi->P[0].x = aoi->P[0].y = 0 ;
        aoi->P[2].x = Nx - 1 ;
        aoi->P[2].y = Ny - 1 ;
    }

    return (aoi) ;
}

/* This fuction adapt an infoImage text file of a CSL Image to a given aoi */
/* If saveIt is set, the infoImage is updated within the image */
/* The allocated and updated infoImage is returned and it is the responsibility of the caller to release it. */
SLCImageInfo *adaptInfoImageOfCSLImageToAoi(CSLImage *thisImage, quadrilateral *aoi, char saveIt) 
{
    char *aPath ;
    SLCImageInfo *info ;

    info = readInfoImageInCSLImage(thisImage) ;

    info->rangeDimension = (int)ceil(aoi->P[2].x - aoi->P[0].x + 1) ;
    info->azimuthDimension = (int)ceil(aoi->P[2].y - aoi->P[0].y + 1) ;
    info->FPAT += info->lineTimeInterval * aoi->P[0].y ;
    info->twoWayRangeTime[0] += 2. / c0 * (info->rangeResolutionCell * aoi->P[0].x) ;
    info->slantRange[0] = c0 / 2. * info->twoWayRangeTime[0] ;
    info->slantRange[2] = info->slantRange[0] + info->rangeDimension * info->rangeResolutionCell ;
    info->slantRange[1] = (info->slantRange[0] + info->slantRange[2]) / 2. ;
    info->incidenceAngle[0] = 0. ;
    geolocateSceneOnEllipsoid(info, info->ellRef) ;
    info->LPAT = info->FPAT + (info->azimuthDimension - 1) * info->lineTimeInterval ;
    
    if (saveIt)     {
        aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
        saveInfoImage(info, aPath) ;
        free(saveInfoKmlInDir(info, thisImage->infoDirectoryPath)) ;
        free(aPath) ;
    }
    
    return(info) ;
}

void cropCSLImageToAoi(CSLImage *thisImage, quadrilateral *aoi) 
{
    char *inputFilePath, *outputFilePath ;
    int iY, Nx, iPol ;
    int iXMin, iXMax, iYMin, iYMax ;
    size_t lineLength, seekVal ;
    SLCImageInfo *info ;
    rawFileDescriptor *inputFile, *outputFile ;
    CSVStruct *polMode ;
    complexFloat *aLine ;

    info = readInfoImageInCSLImage(thisImage) ;
    Nx = info->rangeDimension ;
    freeInfoImage(info) ;
    
    info = adaptInfoImageOfCSLImageToAoi(thisImage, aoi, 1) ;
    polMode = readCSVInString(info->polMode) ;
    iXMin = (int)ceil(aoi->P[0].x) ;
    iXMax = (int)floor(aoi->P[2].x) ;
    iYMin = (int)ceil(aoi->P[0].y) ;
    iYMax = (int)floor(aoi->P[2].y) ;

    for (iPol = 0; iPol < polMode->numberOfEntries; iPol++) {
        inputFilePath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", polMode->stringVal[iPol]) ;
        if (fileExistsAtPath(inputFilePath)) {
            if((inputFile = openRawFileForReadingAtPath(inputFilePath)) == NULL) {
                sprintf(aComment, "Unable to open file for reading at path: %s\n", inputFilePath) ;
                ase(aComment) ;
            }
            outputFilePath = initStringWith2Strings(thisImage->dataDirectoryPath, "/temp") ;
            if((outputFile = openRawFileForWritingAtPath(outputFilePath)) == NULL) {
                sprintf(aComment, "Unable to open file for writting at path: %s\n", outputFilePath) ;
                ase(aComment) ;
            }
        
            lineLength = (size_t)(iXMax - iXMin) + 1 ;
            aLine = vectorComplexFloat(0, lineLength - 1) ;
            seekVal = (size_t)(iYMin * Nx + iXMin) * COMPLEX_FLOAT_SIZE  ;
            for (iY = iYMin; iY <= iYMax; iY++, seekVal += Nx * COMPLEX_FLOAT_SIZE) {
                fseek(inputFile->f, seekVal, SEEK_SET) ;
                fread(aLine, COMPLEX_FLOAT_SIZE, lineLength, inputFile->f) ;
                fwrite(aLine, COMPLEX_FLOAT_SIZE, lineLength, outputFile->f) ;
            } 
            freeVectorComplexFloat(aLine, 0) ;   

            freeRawFileDescriptor(inputFile) ;
            freeRawFileDescriptor(outputFile) ;
            unlink(inputFilePath) ;
            rename(outputFilePath, inputFilePath) ;
            free(outputFilePath) ;
        }
        free(inputFilePath) ;
    }

    freeCSVStruct(polMode) ;
    freeInfoImage(info); 
}
