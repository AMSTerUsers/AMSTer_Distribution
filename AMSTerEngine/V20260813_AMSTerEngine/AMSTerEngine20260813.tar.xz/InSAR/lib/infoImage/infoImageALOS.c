
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ReadInfoImageFromCEOS.c
 *  Including some ALOS specificities
 *
 *
 *  Created by Dominique Derauw on Mon Sep 22 2003.
 *  Copyright (c) 2003 Dominique Derauw All rights reserved.
 *
 */

#include "infoImageALOS.h"

struct infoImage	*readInfoImageFromALOSHeader(ALOSHeader *header, int swathNumber)
{
    char isRaw ;
	char polCode[3] ;
	short tPolCode, rPolCode ;
    int i0 = 0, i, ms, anInt ;
    int numberOfPolarizationChannels ;
//    int numberOfDataRecords ;
    int dataRecordLength, dataRecordHeaderLength, numberOfSamplesPerLine ;
    double  diffAvg, diffAvg0 ;
    struct infoImage	*info ;
	struct ALOS_VDF *vdf ;
	struct ALOS_LF *lf;
	struct ALOS_IMOF **imof ;
    ALOSRawInfoImage *rawInfo ;
    keyValue *infoParams ;

    info = allocInfoImage() ;

	vdf = header->vdf ;
	lf = header->lf ;
	imof = header->imof ;

    sprintf(info->platformName, "%.3s : %.16s", vdf->fpr[0].ref_file_name, lf->dss->mission_identifier) ; info->platformName[23] = '\0' ;
	stripWhiteCharsAtEndOfString(info->platformName) ;

    info->productionTime = allocStringOfLength(8) ;
    sprintf(info->productionTime, "%.8s", vdf->text.prod_creat_loc_date + 31) ;

    info->acquisitionDate = allocStringOfLength(8) ;
    sprintf(info->acquisitionDate, "%.8s", lf->dss->input_scene_center_time) ;

	sprintf(polCode, "HV") ;
	memcpy(&tPolCode, imof[0]->signalDataRecord->transmittedPolarizationCode, 2) ;
	memcpy(&rPolCode, imof[0]->signalDataRecord->receivedPolarizationCode, 2) ;
	if(!isArchBigEndian()) {
		swapShort(&tPolCode) ;
		swapShort(&rPolCode) ;
	}

    switch (header->vdf->text.prod_type_id[10]) {
    case 'D':
        numberOfPolarizationChannels = 2 ;
    	sprintf(info->polMode, "%.1s%.1s, %.1s%.1s", &polCode[tPolCode], &polCode[rPolCode], &polCode[tPolCode], &polCode[1 - rPolCode]) ;
        break;
    case 'Q':
        numberOfPolarizationChannels = 4 ;
        sprintf(info->polMode, "HH, HV, VH, VV") ;
        break;
    default:
        numberOfPolarizationChannels = 1 ;
	    sprintf(info->polMode, "%.1s%.1s", &polCode[tPolCode], &polCode[rPolCode]) ;
        break;
    }

    if (!strncmp(vdf->text.prod_type_id + 8 , "W", 1)) {
        memcpy(&anInt, vdf->text.header.rec_seq_num, 4) ;
	    if(!isArchBigEndian()) {
            swapInt(&anInt) ;
        }
        info->numberOfSubswaths = (anInt - 4) / numberOfPolarizationChannels ;
    }
    info->lookDirection = (!strncmp(vdf->text.prod_type_id + 11, "R", 1))? RIGHT_LOOKING : LEFT_LOOKING ;
    

    info->beamNumber = swathNumber ;
    memcpy(info->productID,  vdf->text.prod_type_id + 8,  32) ;
    info->productID[32] = '\0' ;
    stripWhiteCharsAtEndOfString(info->productID) ;

    memcpy(info->scene_id,  vdf->text.scene_id,  40) ;
    info->scene_id[40] = '\0' ;
    stripWhiteCharsAtEndOfString(info->scene_id) ;

    memcpy(info->scene_loc, vdf->text.scene_loc, 40) ;
    info->scene_loc[40] = '\0' ;
    stripWhiteCharsAtEndOfString(info->scene_loc) ;

    isRaw = isSubStringPresentInString(info->productID, "PSRA") ;

	if(header->imof == NULL) {
//		numberOfDataRecords = readIntInASCIIStringOfLength(header->vdf->fpr[1].ref_file_nrecs, 8) - 1 ;
		dataRecordLength = readIntInASCIIStringOfLength(header->vdf->fpr[1].ref_file_max_reclen, 8) ;
		dataRecordHeaderLength = 412 ;
		numberOfSamplesPerLine = (dataRecordLength - dataRecordHeaderLength) / 4 ;
	}
	else {
//		numberOfDataRecords = readIntInASCIIStringOfLength(header->imof[0]->imof_var.data_nrecs, 6) ;
		dataRecordLength = readIntInASCIIStringOfLength(header->imof[swathNumber]->imof_var.data_rec_len, 6) ;
		dataRecordHeaderLength = dataRecordLength - readIntInASCIIStringOfLength(header->imof[swathNumber]->imof_var.SAR_data_bytes_per_rec, 8) ;
		numberOfSamplesPerLine = (dataRecordLength - dataRecordHeaderLength) / readIntInASCIIStringOfLength(header->imof[swathNumber]->imof_var.nbytes_group, 4) ;
	}

    if(isRaw) {
        info->rangeDimension = numberOfSamplesPerLine ;
    }
    else {
        info->rangeDimension = readIntInASCIIStringOfLength(imof[swathNumber]->imof_var.groups_per_line, 8) ;
    }
	info->azimuthDimension = readIntInASCIIStringOfLength(imof[swathNumber]->imof_var.nlines_data_set, 8) ;

	info->wavelength = readDoubleInASCIIStringOfLength(lf->dss->radar_wavelength, 16) ;
	info->radarCarrierFrequency = speedOfLight / info->wavelength ;

	info->rangeSamplingFrequency = readDoubleInASCIIStringOfLength(lf->dss->sampling, 16) * 1.e6 ;
    info->rangeBandwidth = readDoubleInASCIIStringOfLength(lf->dss->bandwidth_look_range, 16) ;
    if(!info->rangeBandwidth) {
        info->rangeBandwidth = readDoubleInASCIIStringOfLength(lf->dss->range_pulse_length, 16) * readDoubleInASCIIStringOfLength(lf->dss->range_pulse_amplitude_const, 16) ;
    }

    info->prf = readDoubleInASCIIStringOfLength(lf->dss->nominal_prf,16) ;
	info->prf *= 1.e-3 ;

    /* If PALSAR is in QaudPol Mode, prf must be devided by two to take into account the alternating polarisation mode at emission */
    /* Bug found by N. Grunfeld Brook, CONAE, July 3, 2013 */
// !! Found to be completely false for ALOS2. Anyway, this is not logical. So, removed!! (20170707)
//    if (numberOfPolarizationChannels == 4) {
//        info->prf /= 2. ;
//    }
    info->lineTimeInterval = 1. / info->prf ;
    if(isRaw) {
        info->azimuthBandwidth = UNDEFINEDVALUE ;
        info->azimuthResolutionCell = 0 ;
        info->rangeResolutionCell = c0 / 2. / info->rangeSamplingFrequency ;
        info->fdc[0] = 0 ;
        info->fdc[1] = 0 ;
        info->fdc[2] = 0 ;
    }
    else {
        info->azimuthBandwidth = readDoubleInASCIIStringOfLength(lf->dss->total_look_bandwidth_az,16) ;
        info->azimuthResolutionCell = readDoubleInASCIIStringOfLength(lf->dss->line_spacing, 16) ;
        info->rangeResolutionCell = readDoubleInASCIIStringOfLength(lf->dss->pixel_spacing_range, 16) ;
        info->fdc[0] = readDoubleInASCIIStringOfLength(lf->dss->c_track_dop_freq_const_early_image, 16) ;
        info->fdc[1] = readDoubleInASCIIStringOfLength(lf->dss->c_track_dop_freq_lin_early_image, 16) ;
        info->fdc[2] = readDoubleInASCIIStringOfLength(lf->dss->c_track_dop_freq_quad_early_image, 16) ;
    }

/* conversion de [Hz]/[sec] en [Hz]/[pix] */
/*    info->fdc[1] *= 2. * info->Dz / c0 ; */
/*    info->fdc[2] *= pow(2. * info->Dz / c0, 2.) ; */

    /* Apparently, for ALOS2 data, range_gate_early_edge_start_image has not the same meaning and does not give the twoWayRangeTime */
    /* Therefore, minimum slant range is read directly from the signal data record (if present) of the first line of the first channel */
    if(imof == NULL) {
        info->twoWayRangeTime[0] = readDoubleInASCIIStringOfLength(lf->dss->range_gate_early_edge_start_image, 16)  * 1.e-6 ;
        info->slantRange[0] = speedOfLight/2. * info->twoWayRangeTime[0] ;
    }
    else {
        memcpy(&anInt, imof[swathNumber]->signalDataRecord->slantRangeToFirstPixel, 4) ;
        if (!isArchBigEndian()) {
            swapInt(&anInt) ;
        }
        info->slantRange[0] = (double)anInt ;
        info->twoWayRangeTime[0] = 2 * info->slantRange[0] / speedOfLight ;
    }

    info->slantRange[1] = info->slantRange[0] + info->rangeDimension / 2. * info->rangeResolutionCell ;
	info->slantRange[2] = info->slantRange[0] + info->rangeDimension * info->rangeResolutionCell ;
	for(i = 0; i < 3; i++)
		info->incidenceAngle[i] = 0. ;
	memcpy(&ms, imof[swathNumber]->signalDataRecord->sceneStartMillisecondsOfDay, 4) ;
	if(!isArchBigEndian())
		swapInt(&ms) ;
	info->FPAT = (double)ms * 1.e-3 ;
	info->LPAT = info->FPAT + info->azimuthDimension / info->prf ;
    info->FVT = readDoubleInASCIIStringOfLength(lf->platform->sec_of_day_of_data, 22) ;

    info->Dt = readDoubleInASCIIStringOfLength(lf->platform->data_points_time_gap, 22) ;
    info->nVect = readIntInASCIIStringOfLength(lf->platform->num_data_points, 4) ;

    /* We wil select only the five state vectors encompassing the data */
    if(info->nVect > 5) {
        i0 = 0 ;
        diffAvg0 = fabs((info->LPAT + info->FPAT)/2. - (info->FVT + 2. * info->Dt)) ;
        for (i = 0; i < info->nVect - 5; i++) {
            diffAvg = fabs((info->LPAT + info->FPAT)/2. - (info->FVT + (i + 2.) * info->Dt)) ;
            if(diffAvg < diffAvg0) {
                diffAvg0 = diffAvg ;
                i0 = i ;
            }
        }
        info->nVect = 5 ;
        info->FVT += i0 * info->Dt ;
    }

    if((info->S = (struct stateVect *)malloc(info->nVect * sizeof(struct stateVect))) == NULL)
        ase("State vector allocation error\n") ;
    for(i = 0; i < info->nVect; i++) {
        info->S[i].P = vectorDouble(0, 2) ;
        info->S[i].V = vectorDouble(0, 2) ;
        info->S[i].P[0] = readDoubleInASCIIStringOfLength(lf->state[i0 + i].x, 22) ;
        info->S[i].P[1] = readDoubleInASCIIStringOfLength(lf->state[i0 + i].y, 22) ;
        info->S[i].P[2] = readDoubleInASCIIStringOfLength(lf->state[i0 + i].z, 22) ;
        info->S[i].V[0] = readDoubleInASCIIStringOfLength(lf->state[i0 + i].vx, 22) ;
        info->S[i].V[1] = readDoubleInASCIIStringOfLength(lf->state[i0 + i].vy, 22) ;
        info->S[i].V[2] = readDoubleInASCIIStringOfLength(lf->state[i0 + i].vz, 22) ;
		info->S[i].t = info->FVT + i * info->Dt ;
	}

    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL)
        ase("Erreur d'allocation de *info->ellRef\n") ;
    memcpy(info->ellRef->ellipsoidID, lf->dss->ellipsoid_designator, 40) ;
    for(i = 0; i < 16; i++) if(info->ellRef->ellipsoidID[i] == '\0') info->ellRef->ellipsoidID[i] = '\40' ;
    info->ellRef->ellipsoidID[16] = '\0' ;
    info->ellRef->a = readDoubleInASCIIStringOfLength(lf->dss->ellipsoid_semimajor_axis, 16) ;
    info->ellRef->b = readDoubleInASCIIStringOfLength(lf->dss->ellipsoid_semiminor_axis, 16) ;
    info->ellRef->a *= 1000. ;
    info->ellRef->b *= 1000. ;
    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;

	/* Geolocate scene on reference ellipsoid */
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
	info->EarthRadiusAtSceneCenter = 6371221. ;
    info->sceneAverageHeight = 0.0 ;
	info->loc = allocQuadrilateral() ;
	geolocateSceneOnEllipsoid(info, info->ellRef) ;

    info->sensorSpecificInfo = NULL ;
    if(isRaw) {
        if((rawInfo = malloc(sizeof(ALOSRawInfoImage))) == NULL)
            ase("Failed to allocate ALOS Raw info structure") ;
        
        infoParams = allocAKeyValuePair() ;
        info->parameterList = infoParams ;
        
        rawInfo->isRaw = 1 ;
        info->sensorSpecificInfo = rawInfo ;
        rawInfo->rangePulseAmplitudeCoefficient = vectorDouble(0, 4) ;
        info->azimuthResolutionCell = UNDEFINEDVALUE ;
        info->fdc[0] = UNDEFINEDVALUE ;
        info->fdc[1] = UNDEFINEDVALUE ;
        info->fdc[2] = UNDEFINEDVALUE ;
        rawInfo->antennaMechanicalBoresightAngle = readDoubleInASCIIStringOfLength(lf->dss->antenna_mech_bor, 16) ;
        rawInfo->antennaElectronicBoresightAngle = readDoubleInASCIIStringOfLength(lf->dss->antennaElectronicBoresight, 16) ;
        rawInfo->twoWayAntennaAzimuthBeamWidth = readDoubleInASCIIStringOfLength(lf->dss->twoWayAntennaAzimuthWidth, 16) ;
        rawInfo->twoWayAntennaElevationBeamWidth = readDoubleInASCIIStringOfLength(lf->dss->twoWayAntennaElevationWidth, 16) ;
        rawInfo->rangePulseLength = readDoubleInASCIIStringOfLength(lf->dss->range_pulse_length, 16) ;
        rawInfo->rangePulseAmplitudeCoefficient[0] = readDoubleInASCIIStringOfLength(lf->dss->range_pulse_amplitude_const, 16) ;
        rawInfo->rangePulseAmplitudeCoefficient[1] = readDoubleInASCIIStringOfLength(lf->dss->range_pulse_amplitude_lin, 16) ;
        rawInfo->rangePulseAmplitudeCoefficient[2] = readDoubleInASCIIStringOfLength(lf->dss->range_pulse_amplitude_quad, 16) ;
        rawInfo->rangePulseAmplitudeCoefficient[3] = readDoubleInASCIIStringOfLength(lf->dss->range_pulse_amplitude_cube, 16) ;
        rawInfo->rangePulseAmplitudeCoefficient[4] = readDoubleInASCIIStringOfLength(lf->dss->range_pulse_amplitude_quart, 16) ;
        rawInfo->yawSteering = ((char)readIntInASCIIStringOfLength(lf->dss->yawSteeringModeFlag, 4) == 0) ;
        rawInfo->IDCBias = readFloatInASCIIStringOfLength(lf->dss->dc_bias_i, 16) ;
        rawInfo->QDCBias = readFloatInASCIIStringOfLength(lf->dss->dc_bias_q, 16) ;


        setStringValForKeyIn(infoParams, "", "") ;
        setStringValForKeyIn(infoParams, "RAW data specific parameters", "") ;
        setStringValForKeyIn(infoParams, "****************************", "") ;
        setDoubleValForKeyIn(infoParams, rawInfo->antennaElectronicBoresightAngle, "Antenna electronic boresight angle [°]") ;
        setDoubleValForKeyIn(infoParams, rawInfo->antennaMechanicalBoresightAngle, "Antenna mechanical boresight angle [°]") ;
        setDoubleValForKeyIn(infoParams, rawInfo->twoWayAntennaAzimuthBeamWidth, "Two-way antenna azimuth 3db beamwidth") ;
        setDoubleValForKeyIn(infoParams, rawInfo->twoWayAntennaElevationBeamWidth, "Two-way antenna elevation 3db beamwidth") ;
        setDoubleValForKeyIn(infoParams, rawInfo->rangePulseLength, "Range pulse duration [microseconds]") ;
        setDoubleValForKeyIn(infoParams, rawInfo->rangePulseAmplitudeCoefficient[0], "Range pulse constant coefficient [Hz]") ;
        setDoubleValForKeyIn(infoParams, rawInfo->rangePulseAmplitudeCoefficient[1], "Range pulse linear coefficient [Hz]/[sec]") ;
        setDoubleValForKeyIn(infoParams, rawInfo->rangePulseAmplitudeCoefficient[2], "Range pulse quadratic coefficient") ;
        setDoubleValForKeyIn(infoParams, rawInfo->rangePulseAmplitudeCoefficient[3], "Range pulse cubic coefficient") ;
        setDoubleValForKeyIn(infoParams, rawInfo->rangePulseAmplitudeCoefficient[4], "Range pulse quartic coefficient") ;
        setDoubleValForKeyIn(infoParams, rawInfo->IDCBias, "I DC Bias") ;
        setDoubleValForKeyIn(infoParams, rawInfo->QDCBias, "Q DC Bias") ;
        if (rawInfo->yawSteering) {
            setStringValForKeyIn(infoParams, "Yaw-steered", "Yaw steering mode") ;
        }
        else
            setStringValForKeyIn(infoParams, "No yaw-steering", "Yaw steering mode") ;
        
        ALOSAttitudeDataInterpolation(info, header->lf->attitude) ;
        setStringValForKeyIn(infoParams, "", "") ;
        setStringValForKeyIn(infoParams, "Attitude data", "") ;
        setStringValForKeyIn(infoParams, "+++++++++++++", "") ;
        setStringValForKeyIn(infoParams, "Pitch polynomial: pitch = pitch0 + pitch1 * azimuthPosition + pitch2 * azimuthPosition^2", "") ;
        setDoubleValForKeyIn(infoParams, info->pitch[0], "pitch0") ;
        setDoubleValForKeyIn(infoParams, info->pitch[1], "pitch1") ;
        setDoubleValForKeyIn(infoParams, info->pitch[2], "pitch2") ;
        setStringValForKeyIn(infoParams, "Roll polynomial: roll = roll0 + roll1 * azimuthPosition + roll2 * azimuthPosition^2", "") ;
        setDoubleValForKeyIn(infoParams, info->roll[0], "roll0") ;
        setDoubleValForKeyIn(infoParams, info->roll[1], "roll1") ;
        setDoubleValForKeyIn(infoParams, info->roll[2], "roll2") ;
        setStringValForKeyIn(infoParams, "Yaw polynomial: yaw = yaw0 + yaw1 * azimuthPosition + yaw2 * azimuthPosition^2", "") ;
        setDoubleValForKeyIn(infoParams, info->yaw[0], "yaw0") ;
        setDoubleValForKeyIn(infoParams, info->yaw[1], "yaw1") ;
        setDoubleValForKeyIn(infoParams, info->yaw[2], "yaw2") ;
        
        estimateDopplerParameterFromOrbitography(info) ;
    }

    return info ;
}
