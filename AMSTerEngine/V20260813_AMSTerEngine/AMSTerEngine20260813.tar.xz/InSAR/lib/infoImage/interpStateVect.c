
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  interpStateVect.c
 *  lecheader
 *
 *  Created by Dominique Derauw on Wed Feb 20 2002.
 *  Copyright (c) 2001 Dominique Derauw All rights reserved.
 *
 */

#include "interpStateVect.h"
#include "polynomials.h"

void calcStateVect(struct stateVect    *S, double azimuthPosition, struct infoImage *info)
{
    xPolynomial poly ;
    
    S->azimuthPosition = azimuthPosition ;
    S->t = azimuthPosition * info->lineTimeInterval + info->FPAT - info->FVT ;
    
    poly.order= info->polynomialOrder ;
    poly.coefs = info->aX ;
    S->P[0] = yValForPolynomial(&poly, S->t) ;
    poly.coefs = info->aY ;
    S->P[1] = yValForPolynomial(&poly, S->t) ;
    poly.coefs = info->aZ ;
    S->P[2] = yValForPolynomial(&poly, S->t) ;
    poly.coefs = info->aVx ;
    S->V[0] = yValForPolynomial(&poly, S->t) ;
    poly.coefs = info->aVy ;
    S->V[1] = yValForPolynomial(&poly, S->t) ;
    poly.coefs = info->aVz ;
    S->V[2] = yValForPolynomial(&poly, S->t) ;
    
    S->satDistance = vectorNorm(S->P) ;
    S->velocity = vectorNorm(S->V) ;
    
}

void calcStateVectLin(struct stateVect    *S, double azimuthPosition, struct infoImage *info)
{
    S->azimuthPosition = azimuthPosition ;
    S->t = azimuthPosition * info->lineTimeInterval + info->FPAT - info->FVT ;
    
    S->P[0] = info->aX[info->polynomialOrder + 1] + S->t * info->aX[info->polynomialOrder + 2] ;
    S->P[1] = info->aY[info->polynomialOrder + 1] + S->t * info->aY[info->polynomialOrder + 2] ;
    S->P[2] = info->aZ[info->polynomialOrder + 1] + S->t * info->aZ[info->polynomialOrder + 2] ;
    S->V[0] = info->aVx[info->polynomialOrder + 1] + S->t * info->aVx[info->polynomialOrder + 2] ;
    S->V[1] = info->aVy[info->polynomialOrder + 1] + S->t * info->aVy[info->polynomialOrder + 2] ;
    S->V[2] = info->aVz[info->polynomialOrder + 1] + S->t * info->aVz[info->polynomialOrder + 2] ;
}


/* Interpolation des vecteurs d'état */
void	interpolStateVect(struct infoImage *ima)
{
    int		i, j, N, *indexI ;
    double	**T, signe ;
    
    /* Interpolation des vecteurs d'état */
    N = ima->nVect ;
    indexI = vectorInt(1, N) ;
    T = matrixDouble(1, N, 1, N) ;
    for(i = 0; i < N; i++)	{
            ima->aX[i] = ima->S[i].P[0] ;
            ima->aY[i] = ima->S[i].P[1] ;
            ima->aZ[i] = ima->S[i].P[2] ;
            ima->aVx[i] = ima->S[i].V[0] ;
            ima->aVy[i] = ima->S[i].V[1] ;
            ima->aVz[i] = ima->S[i].V[2] ;
            for(j = 0; j < N; j++)
                if(i || j) T[i + 1][j + 1] = pow(i * ima->Dt, (double)j) ; 
    }
	T[1][1] = 1. ;
    ludcmp(T, N, indexI, &signe) ;
    lubksb(T, N, indexI, &ima->aX[-1]) ;
    lubksb(T, N, indexI, &ima->aY[-1]) ;
    lubksb(T, N, indexI, &ima->aZ[-1]) ;
    lubksb(T, N, indexI, &ima->aVx[-1]) ;
    lubksb(T, N, indexI, &ima->aVy[-1]) ;
    lubksb(T, N, indexI, &ima->aVz[-1]) ;
}

void orbitInterpolation(struct infoImage *info)
{
    int		j, k, l, N, *indexI ;
    double	**T, signe, *timeStamp, *aVector ;
    double t1, t0, v0, v1, det ;
    double sigmaX ;
    xPolynomial *poly ;
	
	if(!info->polynomialOrder || (info->polynomialOrder >= info->nVect))
		info->polynomialOrder = (info->nVect - 1 > MAX_POL_ORDER_FOR_ORBIT_INTERPOL)? MAX_POL_ORDER_FOR_ORBIT_INTERPOL : info->nVect - 1 ;
	
	if(!info->isOrbitInterpolationDone) {
	/* initialize polynome coefficients for positions and velocity components */
    /* Linear approximation will be stored at end of vectors */
		if(info->aX == NULL) info->aX = vectorDouble(0, info->polynomialOrder + 2) ;
		if(info->aY == NULL) info->aY = vectorDouble(0, info->polynomialOrder + 2) ;
		if(info->aZ == NULL) info->aZ = vectorDouble(0, info->polynomialOrder + 2) ;
		if(info->aVx == NULL) info->aVx = vectorDouble(0, info->polynomialOrder + 2) ;
		if(info->aVy == NULL) info->aVy = vectorDouble(0, info->polynomialOrder + 2) ;
		if(info->aVz == NULL) info->aVz = vectorDouble(0, info->polynomialOrder + 2) ;
		
		N = info->polynomialOrder + 1 ;
		indexI = vectorInt(1, N) ;
		T = matrixDouble(1, N, 1, N) ;
		for(k = 1; k <= N; k++) {
			info->aX[k - 1] = 0. ;
			info->aY[k - 1] = 0. ;
			info->aZ[k - 1] = 0. ;
			info->aVx[k - 1] = 0. ;
			info->aVy[k - 1] = 0. ;
			info->aVz[k - 1] = 0. ;
			for(l = k; l <= N; l++) {
				T[k][l] = T[l][k] = 0.0 ;
			}
		}
		
		timeStamp = vectorDouble(0, info->nVect) ;
		for(j = 0; j < info->nVect; j++)
			timeStamp[j] = info->S[j].t - info->FVT ;
		
		/* Compute matrix  and vectors for mean square interpolation */
		for(k = 0; k < N; k++) {
			for(j = 0; j < info->nVect; j++) {
				info->aX[k] += pow(timeStamp[j],(double)k) * info->S[j].P[0] ;
				info->aY[k] += pow(timeStamp[j],(double)k) * info->S[j].P[1] ;
				info->aZ[k] += pow(timeStamp[j],(double)k) * info->S[j].P[2] ;
				info->aVx[k] += pow(timeStamp[j],(double)k) * info->S[j].V[0] ;
				info->aVy[k] += pow(timeStamp[j],(double)k) * info->S[j].V[1] ;
				info->aVz[k] += pow(timeStamp[j],(double)k) * info->S[j].V[2] ;
			}
			for(l = k; l < N; l++) {
				for(j = 0; j < info->nVect; j++) {
					T[k + 1][l + 1] += pow(timeStamp[j], (double)(k + l)) ;
				}
			}
		}
		
		for(k = 1; k <= N; k++) {
			for(l = k + 1; l <= N; l++) 
				T[l][k] = T[k][l] ;
		}

		ludcmp(T, N, indexI, &signe) ;
		lubksb(T, N, indexI, &info->aX[-1]) ;
		lubksb(T, N, indexI, &info->aY[-1]) ;
		lubksb(T, N, indexI, &info->aZ[-1]) ;
		lubksb(T, N, indexI, &info->aVx[-1]) ;
		lubksb(T, N, indexI, &info->aVy[-1]) ;
		lubksb(T, N, indexI, &info->aVz[-1]) ;
        
        /* Compute errors */
        sigmaX = 0 ;
        poly = allocXPolynomialOfOrder(N) ;
        aVector = poly->coefs ;
        poly->coefs = info->aX ;
        for (j = 0; j < info->nVect; j++) {
            sigmaX += pow(info->S[j].P[0] - yValForPolynomial(poly, info->S[j].t - info->FVT), 2.) ;
        }
        sigmaX = sqrt(sigmaX) ;
        poly->coefs = aVector ;
        freeXPolynomial(poly) ;
 /*
        for (j = 0; j < N; j++) {
            printf("ax[%d] = %g\taVx[%d] = %g\n", j, info->aX[k], j, info->aVx[j]) ;
            printf("ay[%d] = %g\taVy[%d] = %g\n", j, info->aY[k], j, info->aVy[j]) ;
            printf("az[%d] = %g\taVz[%d] = %g\n", j, info->aZ[k], j, info->aVz[j]) ;
        }
 */       
		info->isOrbitInterpolationDone = 1 ;
        
        /* Linear approximation of positions */
        t1 = timeStamp[info->nVect -1] ;
        t0 = timeStamp [0] ;
        T[1][1] = t1 - t0 ;
        T[2][1] = T[1][2] = (pow(t1, 2.) - pow(t0, 2.)) / 2. ;
        T[2][2] = (pow(t1, 3.) - pow(t0, 3.)) / 3. ;
        det = T[1][1] * T[2][2] - T[2][1] * T[1][2] ;
        v0 = v1 = 0 ;
        for (j = 0; j <= info->polynomialOrder; j++) {
            v0 += info->aX[j] * (pow(t1, (double)(j + 1)) - pow(t0, (double)(j + 1))) / (double)(j + 1) ;
            v1 += info->aX[j] * (pow(t1, (double)(j + 2)) - pow(t0, (double)(j + 2))) / (double)(j + 2) ;
        }
        info->aX[info->polynomialOrder + 1] = (T[2][2] * v0 - T[2][1] * v1)/det ;
        info->aX[info->polynomialOrder + 2] = (T[1][1] * v1 - T[1][2] * v0)/det ;
        
        v0 = v1 = 0 ;
        for (j = 0; j <= info->polynomialOrder; j++) {
            v0 += info->aY[j] * (pow(t1, (double)(j + 1)) - pow(t0, (double)(j + 1))) / (double)(j + 1) ;
            v1 += info->aY[j] * (pow(t1, (double)(j + 2)) - pow(t0, (double)(j + 2))) / (double)(j + 2) ;
        }
        info->aY[info->polynomialOrder + 1] = (T[2][2] * v0 - T[2][1] * v1)/det ;
        info->aY[info->polynomialOrder + 2] = (T[1][1] * v1 - T[1][2] * v0)/det ;
        
        v0 = v1 = 0 ;
        for (j = 0; j <= info->polynomialOrder; j++) {
            v0 += info->aZ[j] * (pow(t1, (double)(j + 1)) - pow(t0, (double)(j + 1))) / (double)(j + 1) ;
            v1 += info->aZ[j] * (pow(t1, (double)(j + 2)) - pow(t0, (double)(j + 2))) / (double)(j + 2) ;
        }
        info->aZ[info->polynomialOrder + 1] = (T[2][2] * v0 - T[2][1] * v1)/det ;
        info->aZ[info->polynomialOrder + 2] = (T[1][1] * v1 - T[1][2] * v0)/det ;
        
        /* Linear approximation of velocities */
        v0 = v1 = 0 ;
        for (j = 0; j <= info->polynomialOrder; j++) {
            v0 += info->aVx[j] * (pow(t1, (double)(j + 1)) - pow(t0, (double)(j + 1))) / (double)(j + 1) ;
            v1 += info->aVx[j] * (pow(t1, (double)(j + 2)) - pow(t0, (double)(j + 2))) / (double)(j + 2) ;
        }
        info->aVx[info->polynomialOrder + 1] = (T[2][2] * v0 - T[2][1] * v1)/det ;
        info->aVx[info->polynomialOrder + 2] = (T[1][1] * v1 - T[1][2] * v0)/det ;
        
        v0 = v1 = 0 ;
        for (j = 0; j <= info->polynomialOrder; j++) {
            v0 += info->aVy[j] * (pow(t1, (double)(j + 1)) - pow(t0, (double)(j + 1))) / (double)(j + 1) ;
            v1 += info->aVy[j] * (pow(t1, (double)(j + 2)) - pow(t0, (double)(j + 2))) / (double)(j + 2) ;
        }
        info->aVy[info->polynomialOrder + 1] = (T[2][2] * v0 - T[2][1] * v1)/det ;
        info->aVy[info->polynomialOrder + 2] = (T[1][1] * v1 - T[1][2] * v0)/det ;
        
        v0 = v1 = 0 ;
        for (j = 0; j <= info->polynomialOrder; j++) {
            v0 += info->aVz[j] * (pow(t1, (double)(j + 1)) - pow(t0, (double)(j + 1))) / (double)(j + 1) ;
            v1 += info->aVz[j] * (pow(t1, (double)(j + 2)) - pow(t0, (double)(j + 2))) / (double)(j + 2) ;
        }
        info->aVz[info->polynomialOrder + 1] = (T[2][2] * v0 - T[2][1] * v1)/det ;
        info->aVz[info->polynomialOrder + 2] = (T[1][1] * v1 - T[1][2] * v0)/det ;
                
 		freeVectorDouble(timeStamp, 0) ;
		freeVectorInt(indexI, 1) ;
		freeMatrixDouble(T, 1, 1) ;
	}
}

void	stateVectorsReferentialTranslation(struct infoImage *ima, ellipsoid *ellProj)
{
    int	i ;
    
    for(i = 0; i < ima->nVect; i++) {
        ima->S[i].P[0] -= ellProj->X0 ; 
        ima->S[i].P[1] -= ellProj->Y0 ; 
        ima->S[i].P[2] -= ellProj->Z0 ; 
    }
    interpolStateVect(ima) ;
}

