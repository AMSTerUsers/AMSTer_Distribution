
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageCSK.c
//  CSKDataReader
//
//  Created by Dominique Derauw on 14/08/12.
//  Copyright (c) 2012 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "infoImageCSK.h"



struct infoImage *createSLCImageInfoFromCSKHeaderFor(keyValue *header)
{
    char *aString, *groupName, aKey[128], *layerPol, *datasetName ;
    int		i, i0, stateVectorIndex, numberOfLayers, numberOfDatasets ;
    double	*aDouble, secondsPerPixels ;
    double  diffAvg, diffAvg0 ;
    double  Rt, S, z ;
    double  *stateVectorsTime, *satellitePosition, *satelliteVelocity ;
    struct infoImage	*info ;
    keyValue *aKeyValue ;

    info = allocInfoImage() ;

    /* Satellite ID */
    if((aString = getStringValForKeyIn(header, "Satellite ID")) == NULL) {
        sprintf(info->platformName, "%s", "Unknown sensor") ;
    }
    else {
        sprintf(info->platformName, "%s", aString) ;
        if (strstr(info->platformName, "CSK")) {
            info->sensorID  = __CSK__ ;
        }
        sprintf(info->platformName, "%s", aString) ;
        if (strstr(info->platformName, "SSAR")) {
            info->sensorID  = __CSG__ ;
        }
        if (strstr(info->platformName, "KMPS5")) {
            info->sensorID  = __K5__ ;
        }
    }

    if((aString = getStringValForKeyIn(header, "Scene Sensing Start UTC")) != NULL) {
        info->acquisitionDate = allocStringOfLength(10) ;
        sprintf(info->acquisitionDate, "%.10s", aString) ;
        removeAnyOccurrenceOfSubStringInString(info->acquisitionDate, "-") ;
    }

    /* Polarisation mode and SLC dimensions */
    datasetName = NULL ;
    info->rangeDimension = 0 ;
    info->azimuthDimension = 0 ;
    numberOfDatasets = getIntValForKeyIn(header, "Number of datasets") ;
    if (numberOfDatasets) {
        for (i = 0; i < numberOfDatasets; i++) {
            sprintf(aKey, "Dataset %d name", i+1) ;
            datasetName = getStringValForKeyIn(header, aKey) ;
             if (isSubStringPresentInString(datasetName, "/SBI") || isSubStringPresentInString(datasetName, "/IMG")) {
                sprintf(aKey, "Dataset %d X size", i+1) ;
                info->rangeDimension = getIntValForKeyIn(header, aKey) ;
                sprintf(aKey, "Dataset %d Y size", i+1) ;
                info->azimuthDimension = getIntValForKeyIn(header, aKey) ;
            }
        }        
    }
    else {
        printf("\t-/-> No data sets referenced in hdf5 files.\n") ;
    }
    
    groupName = NULL ;
    numberOfLayers = getIntValForKeyIn(header, "Number of layers") ;
    if(numberOfLayers) {
        for (i = 0; i < numberOfLayers; i++) {
            sprintf(aKey, "Group name of layer %d", i+1) ;
            groupName = getStringValForKeyIn(header, aKey) ;
            sprintf(aKey, "%s Polarisation", groupName) ;
            if (!(layerPol = getStringValForKeyIn(header, aKey))) {
                sprintf(aKey, "Polarization") ;
                layerPol = getStringValForKeyIn(header, aKey) ;
            }
            
            if(!i) {
                sprintf(info->polMode, "%s", layerPol) ;
            }
            else {
                aString = initStringWithString(info->polMode) ;
                sprintf(info->polMode, "%s, %s", aString, layerPol) ;
                free(aString) ;
            }
        }
        sprintf(aKey, "Group name of layer 1") ;
        groupName = getStringValForKeyIn(header, aKey) ;
    }
    else {
        sprintf(info->polMode, "%s", "Unknown polarisation") ;
    }

    /* Beam ID */
    if((aString = getStringValForKeyIn(header, "Subswaths Number")) == NULL) {
        info->beamNumber = -9999 ;
    }
    else {
        info->beamNumber = getIntValForKeyIn(header, "Subswaths Number") ;
    }

    /* Product ID */
    if((aString = getStringValForKeyIn(header, "Product Type")) == NULL) {
        sprintf(info->productID, "%s", "Unknown product") ;
    }
    else {
        sprintf(info->productID, "%s", aString) ;
    }

    /* Scene ID */
    if((aString = getStringValForKeyIn(header, "Product Filename")) == NULL) {
        sprintf(info->scene_id, "%s", "No scene ID") ;
    }
    else {
        sprintf(info->scene_id, "%s", aString) ;
    }

    /* Scene location */
    if((aKeyValue = isKeyValPresent(header, "Scene Centre Geodetic Coordinates")) == NULL) {
        sprintf(info->scene_loc, "%s", "Unknown localization") ;
    }
    else {
        aDouble = (double *)(aKeyValue->value) ;
        sprintf(info->scene_loc, "Center longitude: %lf\t Center latitude: %lf", aDouble[0], aDouble[1]) ;
    }

    /* Look direction */
    if((aKeyValue = isKeyValPresent(header, "Look Side")) == NULL) {
        sprintf(info->scene_loc, "%s", "Sensor supposed to be right looking") ;
        info->lookDirection = RIGHT_LOOKING ;
    }
    else {
        if (!strncmp(aKeyValue->stringVal, "RIGHT", 5)) {
            info->lookDirection = RIGHT_LOOKING ;
        }
        else
            info->lookDirection = LEFT_LOOKING ;
    }

    /* Wavelength */
    info->wavelength = getDoubleValForKeyIn(header, "Radar Wavelength") ;

    /* Radar carrier frequency */
    info->radarCarrierFrequency = getDoubleValForKeyIn(header, "Radar Frequency") ;
    if(!info->radarCarrierFrequency){
		info->radarCarrierFrequency = speedOfLight / info->wavelength ;
	}

    /* Radar bandwidth */
    if((aString = getStringValForKeyIn(header, "Group name of layer 1")) != NULL) {
        sprintf(aKey, "%s Range Focusing Bandwidth", aString) ;
        info->rangeBandwidth = getDoubleValForKeyIn(header, aKey) ;
    }

    /* Radar apodization coefficient */
    info->rangeApodizationCoefficient = getDoubleValForKeyIn(header, "Range Focusing Weighting Coefficient") ;

    /* Range sampling frequency */
    sprintf(aKey, "%s Sampling Rate", groupName) ;
	info->rangeSamplingFrequency = getDoubleValForKeyIn(header, aKey) ;

    /* Min and max slant range */
    info->twoWayRangeTime[0] = getDoubleValForKeyIn(header, "Zero Doppler Range First Time") ;
    info->twoWayRangeTime[2] = getDoubleValForKeyIn(header, "Zero Doppler Range Last Time") ;
    info->twoWayRangeTime[1] = (info->twoWayRangeTime[0] + info->twoWayRangeTime[2]) / 2. ;
    for(i = 0; i < 3; i++) info->slantRange[i] = c0 / 2. * info->twoWayRangeTime[i] ;

    /* Range resolution cell */
    secondsPerPixels = getDoubleValForKeyIn(header, "Column Time Interval") ;
    if ((aKeyValue = isKeyValPresent(header, "Column Spacing")) == NULL) {
        info->rangeResolutionCell = secondsPerPixels * c0 / 2. ;  
    }
    else {
        sscanf(aKeyValue->stringVal, "%lg ", &(info->rangeResolutionCell)) ;
    }
    

    /* PRF */
    sprintf(aKey, "%s PRF", groupName) ;
    info->prf = getDoubleValForKeyIn(header, aKey) ;
    info->lineTimeInterval = getDoubleValForKeyIn(header, "Line Time Interval") ;
    if (!info->lineTimeInterval) {
        info->lineTimeInterval = 1. / info->prf ;
    }

    /* Azimuth Bandwith and resolution */
    sprintf(aKey, "%s Azimuth Focusing Bandwidth", groupName) ;
    info->azimuthBandwidth = getDoubleValForKeyIn(header, aKey) ;
    info->azimuthResolutionCell = getDoubleValForKeyIn(header, "Line Spacing") ;

    /* Doppler polynomial with respect to range in [Hz]/[pixel] */
    if((aKeyValue = isKeyValPresent(header, "Centroid vs Range Time Polynomial")) == NULL) {
        sprintf(aKey, "%s Doppler Centroid vs Range Time Polynomial", groupName) ;
        aKeyValue = isKeyValPresent(header, aKey) ;
    }
    if (aKeyValue) {
        aDouble = (double *)(aKeyValue->value) ;
        info->fdc[0] = aDouble[0] ;
        info->fdc[1] = aDouble[1] * secondsPerPixels ;
        info->fdc[2] = aDouble[2] * pow(secondsPerPixels, 2.) ;
    }
    else {
        info->fdc[0] = info->fdc[1] = info->fdc[2] = 0.0 ;
    }

    /* azimuth times */
    info->FPAT = getDoubleValForKeyIn(header, "Zero Doppler Azimuth First Time") ;
    info->LPAT = getDoubleValForKeyIn(header, "Zero Doppler Azimuth Last Time") ;

    /* Incidence angles */
    info->incidenceAngle[0] = getDoubleValForKeyIn(header, "Near Incidence Angle") ;
    info->incidenceAngle[2] = getDoubleValForKeyIn(header, "Far Incidence Angle") ;

    Rt = getDoubleValForKeyIn(header, "Centre Earth Radius") ;
    S = Rt + getDoubleValForKeyIn(header, "Satellite Height") ;
    z = info->slantRange[1] ;
    if(Rt && S && z) {
        info->incidenceAngle[1] = 180./PI * acos((pow(S, 2.) - pow(Rt, 2.) - pow(z, 2.))/(2. * Rt * z)) ;
    }
    else {
        info->incidenceAngle[1] = (info->incidenceAngle[0] + info->incidenceAngle[2])/ 2. ;
    }


    /* State vectors */
    if((aKeyValue = isKeyValPresent(header, "State Vectors Times")) == NULL) {
        info->FVT = 0.0 ;
        info->nVect = 0 ;
    }
    else {
        stateVectorsTime = (double *)(aKeyValue->value) ;
        aKeyValue = isKeyValPresent(header, "ECEF Satellite Position") ;
        if (!(info->nVect = getIntValForKeyIn(header, "Number of State Vectors"))) {
            sscanf(aKeyValue->stringVal, "Vector DOUBLE of length %d", &info->nVect) ;
            info->nVect /= 3 ;
        }
        
        info->Dt = (info->nVect > 1)? stateVectorsTime[1] - stateVectorsTime[0] : 0 ;
        satellitePosition = (aKeyValue)->value ;
        satelliteVelocity = (isKeyValPresent(header, "ECEF Satellite Velocity"))->value ;

        /* We wil select only the five state vectors encompassing the data */
        i0 = 0 ;
        if(info->nVect > 5) {
            diffAvg0 = fabs((info->LPAT + info->FPAT)/2. - (stateVectorsTime[4] + stateVectorsTime[0])/2.) ;
            for (i = 0; i < info->nVect - 5; i++) {
                diffAvg = fabs((info->LPAT + info->FPAT)/2. - (stateVectorsTime[i + 4] + stateVectorsTime[i])/2.) ;
                if(diffAvg < diffAvg0) {
                    diffAvg0 = diffAvg ;
                    i0 = i ;
                }
            }
            info->nVect = 5 ;
            info->FVT = stateVectorsTime[i0] ;
        }

        if((info->S = (struct stateVect *)malloc(info->nVect * sizeof(struct stateVect))) == NULL)
            ase("State vector allocation error\n") ;
        for(i = 0; i < info->nVect; i++) {
            stateVectorIndex = i0 + i ;
            info->S[i].P = vectorDouble(0, 2) ;
            info->S[i].V = vectorDouble(0, 2) ;
            info->S[i].P[0] = satellitePosition[3 * stateVectorIndex] ;
            info->S[i].P[1] = satellitePosition[3 * stateVectorIndex + 1] ;
            info->S[i].P[2] = satellitePosition[3 * stateVectorIndex + 2] ;
            info->S[i].V[0] = satelliteVelocity[3 * stateVectorIndex] ;
            info->S[i].V[1] = satelliteVelocity[3 * stateVectorIndex + 1] ;
            info->S[i].V[2] = satelliteVelocity[3 * stateVectorIndex + 2] ;
            info->S[i].t = stateVectorsTime[stateVectorIndex] ;
        }
    }


	info->aX = info->aY = info->aZ = info->aVx= info->aVy= info->aVz = NULL ;
	info->isOrbitInterpolationDone = 0 ;

    /* Reference ellipsoid */
    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL)
        ase("Erreur d'allocation de *info->ellRef\n") ;

    if((aString = getStringValForKeyIn(header, "Ellipsoid Designator")) == NULL) {
        sprintf(info->ellRef->ellipsoidID, "%s", "Unknown ellipsoid") ;
    }
    else {
        sprintf(info->ellRef->ellipsoidID, "%s", aString) ;
    }

    info->ellRef->a = getDoubleValForKeyIn(header, "Ellipsoid Semimajor Axis") ;
    info->ellRef->b = getDoubleValForKeyIn(header, "Ellipsoid Semiminor Axis") ;
    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;

	/* Geolocate scene on reference ellipsoid */
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
	info->EarthRadiusAtSceneCenter = 6371221. ;
	info->loc = allocQuadrilateral() ;
	geolocateSceneOnEllipsoid(info, info->ellRef) ;

    return info ;
}

