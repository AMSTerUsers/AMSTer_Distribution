
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageESAR.c
//  ESARDataReader
//
//  Created by Dominique Derauw on 26/02/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "infoImageESAR.h"


SLCImageInfo *createSLCInfoImageForESARData(keyValue *readerParams)
{
    char *genericFileName, *ESARDirectory, aPath[_MAX_PATH_LENGTH_], aString[MAXSTRINGLENGTH] ;
    char *areaCode, *hms ;
    int i, j, anInt, N ;
    double hh, mm, ss ;
    double satDistance ;
    double *sol, *Pg ;
    struct infoImage *info ;
    keyValue *ESARParams ;
    rawFileDescriptor *aDataFile ;
    ESARSLCStateVect anSLCStateVector ;
    ESARMLStateVect aMLStateVector ;
    struct stateVect *stateVectors ;
    geoRef *geo ;

    ESARDirectory = getStringValForKeyIn(readerParams, "ESAR") ;
    if (!isReadAccessGrantedAtPath(ESARDirectory)) {
        ase("Cannot access ESAR data directory") ;
    }
    genericFileName = getFileNameFromPath(ESARDirectory) ;
    /* Seperate generic file name and area code */
    replaceNSubStringInString(genericFileName, "_", ".") ;
    areaCode = initStringWithString(getPointerToLastFileExtensionInPath(genericFileName)) ;
    stripExtensionAtEndOfPath(genericFileName) ;
    
    sprintf(aPath, "%s/e%s_ch1_%s.txt", ESARDirectory, genericFileName, areaCode) ;
    if (!fileExistsAtPath(aPath)) {
        ase("Main header file not found");
    }
    ESARParams = readESARHeaderAtPath(aPath) ;
    
    info = allocInfoImage() ;
    sprintf(info->productID, "%s", getStringValForKeyIn(ESARParams, "0.08")) ;
    sprintf(aString, "Date: %s\tmission: %s\tPass: %s\tTrack: %s", getStringValForKeyIn(ESARParams, "0.27"), getStringValForKeyIn(ESARParams, "0.10"), getStringValForKeyIn(ESARParams, "0.11"), getStringValForKeyIn(ESARParams, "0.12")) ;
    sprintf(info->scene_id, "%s", aString) ;
    sprintf(info->platformName, "%s", getStringValForKeyIn(ESARParams, "0.02")) ;
    sprintf(info->scene_loc, "%s", getStringValForKeyIn(ESARParams, "0.09")) ;
    sprintf(info->polMode, "%s", getStringValForKeyIn(ESARParams, "0.47")) ;
    replaceNSubStringInString(info->polMode, "-", ",") ;
    info->numberOfLayers = getIntValForKeyIn(ESARParams, "0.21") ;
    info->lookDirection = -1. ;
    
    /* To get data dimension, we need to open one data channel and read the 4 byte header preceeding the data */
    if (!strncmp(getStringValForKeyIn(readerParams, "Read coregistered"), "NO", 2)) {
        sprintf(aString, "%s/i%s_ch1_%s_slc.dat", ESARDirectory, genericFileName, areaCode) ;
    }
    else
        sprintf(aString, "%s/i%s_ch1_%s_slc.dat.final", ESARDirectory, genericFileName, areaCode) ;
    if((aDataFile = openRawFileForReadingAtPath(aString)) == NULL)
        ase("Failed to open first channel data file") ;
    fread(&info->rangeDimension, sizeof(int), 1, aDataFile->f) ;
    if (!isArchBigEndian()) {
        swap4bytesStruct(&info->rangeDimension) ;
    }
    fread(&info->azimuthDimension, sizeof(int), 1, aDataFile->f) ;
    if (!isArchBigEndian()) {
        swap4bytesStruct(&info->azimuthDimension) ;
    }
    freeRawFileDescriptor(aDataFile) ;
    
    info->radarCarrierFrequency = getDoubleValForKeyIn(ESARParams, "0.14") ;
    info->radarCarrierFrequency *= 1.e9 ;
    info->wavelength = speedOfLight / info->radarCarrierFrequency ;
    
    info->rangeSamplingFrequency = getDoubleValForKeyIn(ESARParams, "0.22") ;
    info->rangeSamplingFrequency *= 1.0e6 ;
    
    info->rangeResolutionCell = getDoubleValForKeyIn(ESARParams, "0.23") ;
    info->azimuthResolutionCell = getDoubleValForKeyIn(ESARParams, "0.76") ;
    
    info->prf = getDoubleValForKeyIn(ESARParams, "0.60") ;
    /* Visibly, ESAR data is also resampled along azimuth. Therefore, the line time interval cannot be computed from the prf */
    /* We compute it from the given azimuth sampling and init.forw_velocity value */
    info->lineTimeInterval = info->azimuthResolutionCell / getDoubleValForKeyIn(ESARParams, "0.78") ;
    
    info->rangeBandwidth = getDoubleValForKeyIn(ESARParams, "0.37") ;
    
    /* There is no info in the header concerning the azimuth bandwidth. So we take the prf a s the upper limit */
    info->azimuthBandwidth = info->prf ;
    
    /* We estimate a constant DC from squint and velocity values */
    info->fdc = vectorDouble(0, 2) ;
    info->fdc[0] = -2. * getDoubleValForKeyIn(ESARParams, "1.08") / getDoubleValForKeyIn(ESARParams, "0.15") * sin(PI/180. * getDoubleValForKeyIn(ESARParams, "0.67")) ;
    info->fdc[1] = info->fdc[2] = 0 ;
    
    /* We estimate the minimum slant range from the range_delay value */
    info->slantRange = vectorDouble(0, 2) ;
    info->slantRange[0] = getDoubleValForKeyIn(ESARParams, "0.63") * 1.e-6 * getDoubleValForKeyIn(ESARParams, "0.16") / 2. ;
    info->slantRange[0] += getDoubleValForKeyIn(ESARParams, "0.56") * info->rangeResolutionCell ;
    info->slantRange[1] = info->slantRange[0] + info->rangeDimension / 2 * info->rangeResolutionCell ;
    info->slantRange[2] = info->slantRange[0] + (info->rangeDimension - 1) * info->rangeResolutionCell ;
    
    /* Incidence angle estimates from mean sensor altitude */
    info->incidenceAngle = vectorDouble(0, 2) ;
    info->incidenceAngle[0] = 180/PI * acos(getDoubleValForKeyIn(ESARParams, "0.79") / info->slantRange[0]) ;
    info->incidenceAngle[1] = 180/PI * acos(getDoubleValForKeyIn(ESARParams, "0.79") / info->slantRange[1]) ;
    info->incidenceAngle[2] = 180/PI * acos(getDoubleValForKeyIn(ESARParams, "0.79") / info->slantRange[2]) ;
    
    
    hms = getStringValForKeyIn(ESARParams, "0.30") ;
    sscanf(hms, "%lf:%lf:%lf", &hh, &mm, &ss);
    info->FPAT = 3600 * hh + 60 * mm + ss ;
    
    hms = getStringValForKeyIn(ESARParams, "0.31") ;
    sscanf(hms, "%lf:%lf:%lf", &hh, &mm, &ss);
    info->LPAT = 3600 * hh + 60 * mm + ss ;
    
    sprintf(aPath, "%s/track_wgs84_slc%s_ch1_%s.dat", ESARDirectory, genericFileName, areaCode) ;
    if (fileExistsAtPath(aPath)) {
        /* We will read all state vectors, supposing there is one state vector for each azmuth line */
        info->nVect = info->azimuthDimension ;
        info->FVT = info->FPAT ;
        info->Dt = info->lineTimeInterval ;

        if((aDataFile = openRawFileForReadingAtPath(aPath)) == NULL)
            ase("Failed to open first channel data file") ;
        fread(&anInt, sizeof(int), 1, aDataFile->f) ;
        if (!isArchBigEndian()) {
            swap4bytesStruct(&anInt) ;
        }
        fread(&anInt, sizeof(int), 1, aDataFile->f) ;
        if (!isArchBigEndian()) {
            swap4bytesStruct(&anInt) ;
        }

        /* This is the state vector reader for rectified state vectors */
        /* If uncommenting it, also uncomment the corresponding structure in infoImageESAR.h */
        
        if (anInt != info->nVect) {
            ase("Number of state vectors does not corresponds to number of azimuth records") ;
        }
        
        /* Now that we have the number of required state vectors, we can allocate them */
        info->S = allocVectorOfStateVectorsOfLength(info->nVect) ;
        for (i = 0; i < info->nVect; i++) {
            info->S[i].t = info->FVT + i * info->lineTimeInterval ;
            fread(&anSLCStateVector, sizeof(ESARSLCStateVect), 1, aDataFile->f) ;
            info->S[i].P[0] = anSLCStateVector.xRectified ;
            info->S[i].P[1] = anSLCStateVector.yRectified ;
            info->S[i].P[2] = anSLCStateVector.zRectified ;
            if (!isArchBigEndian()) {
                swapDouble(info->S[i].P) ;
                swapDouble(info->S[i].P + 1) ;
                swapDouble(info->S[i].P + 2) ;
            }
        }
        
        /* We compute the velocity vector every N points in azimuth an compute a moving average to smooth it */
        
        N = 100 ;
        for (i = 0; i < info->nVect - N; i++) {
            info->S[i].V[0] = (info->S[i + N].P[0] - info->S[i].P[0]) / (N * info->lineTimeInterval) ;
            info->S[i].V[1] = (info->S[i + N].P[1] - info->S[i].P[1]) / (N * info->lineTimeInterval) ;
            info->S[i].V[2] = (info->S[i + N].P[2] - info->S[i].P[2]) / (N * info->lineTimeInterval) ;
        }
        for (; i < info->nVect; i++) {
            info->S[i].V[0] = info->S[i - 1].V[0] ;
            info->S[i].V[1] = info->S[i - 1].V[1] ;
            info->S[i].V[2] = info->S[i - 1].V[2] ;
        }
        
        for (i = 0; i < info->nVect - N; i++) {
            for (j = 1; j < N; j++) {
                info->S[i].V[0] += info->S[i + j].V[0] ;
                info->S[i].V[1] += info->S[i + j].V[1] ;
                info->S[i].V[2] += info->S[i + j].V[2] ;
            }
            info->S[i].V[0] /= N ;
            info->S[i].V[1] /= N ;
            info->S[i].V[2] /= N ;
        }
        for (; i < info->nVect; i++) {
            info->S[i].V[0] = info->S[i - 1].V[0] ;
            info->S[i].V[1] = info->S[i - 1].V[1] ;
            info->S[i].V[2] = info->S[i - 1].V[2] ;
        }
        
        /* We will keep one state vector over N to reduce their number */
        stateVectors = allocVectorOfStateVectorsOfLength(info->nVect / N + 1) ;
        for (i = 0; i < info->nVect / N; i++) {
            stateVectors[i].t = info->S[i * N].t ;
            for (j = 0; j < 3; j++) {
                stateVectors[i].P[j] = info->S[i * N].P[j] ;
                stateVectors[i].V[j] = info->S[i * N].V[j] ;
            }
        }
        stateVectors[i].t = info->S[info->nVect / N].t ;
        for (j = 0; j < 3; j++) {
            stateVectors[i].P[j] = info->S[info->nVect / N].P[j] ;
            stateVectors[i].V[j] = info->S[info->nVect / N].V[j] ;
        }
        freeVectorOfStateVectorsOfLength(info->S, info->nVect) ;
        info->S = stateVectors ;
        info->nVect = info->nVect / N + 1 ;
    }
    else {
        /* In the case of MLGeometry track, we will consider that the time stamp starts at init.time_start_of_track */
        hms = getStringValForKeyIn(ESARParams, "0.28") ;
        sscanf(hms, "%lf:%lf:%lf", &hh, &mm, &ss);
        info->FVT = 3600 * hh + 60 * mm + ss ;
        sprintf(aPath, "%s/track_wgs84%s_ch1_%s.dat", ESARDirectory, genericFileName, areaCode) ;
        if (!fileExistsAtPath(aPath)) {
            ase("Antenna track file not found");
        }
        
        if((aDataFile = openRawFileForReadingAtPath(aPath)) == NULL)
            ase("Failed to open first channel data file") ;
        fread(&anInt, sizeof(int), 1, aDataFile->f) ;
        if (!isArchBigEndian()) {
            swap4bytesStruct(&anInt) ;
        }
        fread(&anInt, sizeof(int), 1, aDataFile->f) ;
        if (!isArchBigEndian()) {
            swap4bytesStruct(&anInt) ;
        }
        
        /* Multilook geometry state vector reading */
        info->nVect = anInt ;
        info->S = allocVectorOfStateVectorsOfLength(info->nVect) ;
        for (i = 0; i < info->nVect; i++) {
            fread(&aMLStateVector, sizeof(ESARMLStateVect), 1, aDataFile->f) ;
            info->S[i].P[0] = aMLStateVector.x ;
            info->S[i].P[1] = aMLStateVector.y ;
            info->S[i].P[2] = aMLStateVector.z ;
            info->S[i].V[0] = aMLStateVector.vX ;
            info->S[i].V[1] = aMLStateVector.vY ;
            info->S[i].V[2] = aMLStateVector.vZ ;
            info->S[i].t = aMLStateVector.timeStamp ;
            if (!isArchBigEndian()) {
                swapDouble(info->S[i].P) ;
                swapDouble(info->S[i].P + 1) ;
                swapDouble(info->S[i].P + 2) ;
                swapDouble(info->S[i].V) ;
                swapDouble(info->S[i].V + 1) ;
                swapDouble(info->S[i].V + 2) ;
                swapDouble(&info->S[i].t) ;
            }
//            info->S[i].t += info->FPAT ;
        }
   }
    
    
    info->aX = info->aY = info->aZ = info->aVx= info->aVy= info->aVz = NULL ;
	info->isOrbitInterpolationDone = 0 ;

    /* Reference ellipsoid */
    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL)
        ase("Failed to allocate reference ellipsoid\n") ;
    info->ellRef->a = 6.378137000000000e+06 ; // Predefined as WGS84
    info->ellRef->b = 6.356752314245000e+06 ; // Predefined as WGS84

    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;
    
	/* Geolocate scene on reference ellipsoid */
    info->sceneAverageHeight = getDoubleValForKeyIn(ESARParams, "4.05") ;
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
	info->EarthRadiusAtSceneCenter = 6371221. ;
	info->loc = allocQuadrilateral() ;
//    info->incidenceAngle[0] = 0. ;
        
    /* Since we deal with airborne data, we had beter to verify that the approximate Earth radius is convenient to lead to a georeferencing solution */
    satDistance = vectorNorm(info->S[info->nVect / 2].P) ;
    if (info->EarthRadiusAtSceneCenter > satDistance || info->EarthRadiusAtSceneCenter < satDistance - info->slantRange[0] * cos(PI / 180. * info->incidenceAngle[0])) {
        /* We compute a Earth radius corresponding to a null heigtht at nearest range */
        info->EarthRadiusAtSceneCenter = satDistance - (info->slantRange[0] * cos(PI / 180. * info->incidenceAngle[0])) ;
    }

    /* Now that we are sure to have a solution, we will compute a first approximation of the Earth radius at scene center */
    orbitInterpolation(info) ;
    geo = allocAndInitGeorefStructureForTargetEllipsoid(info, info->ellRef) ;
	Pg = vectorDouble(0, 2) ;
    calcStateVect(geo->solving->S, info->azimuthDimension / 2., info) ;
    initOnSphereSolving(geo->solving) ;
	
    satDistance = sqrt(scalarProduct(geo->solving->S->P, geo->solving->S->P)) ;
    
    geo->solving->Rt = info->EarthRadiusAtSceneCenter ;
	if((sol = onSphereSolvingForPoint(info->rangeDimension / 2., info->azimuthDimension / 2., info->sceneAverageHeight, geo)) == NULL)
        return(0) ;
	onEllipsoidProjection(Pg, sol, geo->solving) ;
	info->EarthRadiusAtSceneCenter = vectorNorm(Pg) ;
    if (!info->sceneAverageHeight) {
        /* if scene average height is null, we will compute a first average height to ensure finding geoprojection solutions */
        info->sceneAverageHeight = satDistance - info->slantRange[0] * cos(PI / 180. * info->incidenceAngle[0]) - info->EarthRadiusAtSceneCenter ;
        
        /* Now we can compue a correct Earth radius */
        info->EarthRadiusAtSceneCenter = earthRadiusAtPoint(info->rangeDimension / 2., info->azimuthDimension / 2., info->sceneAverageHeight, geo) ;
        /* And update the average height at scene centre */
        info->sceneAverageHeight = satDistance - info->slantRange[1] * cos(geo->solving->alpha_at) - info->EarthRadiusAtSceneCenter ;
    }

	geolocateSceneOnEllipsoid(info, info->ellRef) ;
    
    /* Reference range */
    info->referenceRange = 0 ;
    
    info->parameterList = ESARParams ;
    
    freeVectorDouble(Pg, 0) ;
    freeGeoRef(geo) ;

    return (info) ;
}


keyValue *readESARHeaderAtPath(char *aPath)
{
    char aTextLine[MAXSTRINGLENGTH] ;
    char key[45], *stringValue ;
    keyValue *pList ;
    rawFileDescriptor *inputFile ;
    
    pList = allocAKeyValuePair() ;
    inputFile = openRawFileForReadingAtPath(aPath) ;
    while (!feof(inputFile->f)) {
        fgets(aTextLine, MAXSTRINGLENGTH, inputFile->f) ;
        if (strlen(aTextLine) >= 44) {
            sprintf(key, "%.44s", aTextLine) ;
            stripWhiteCharsAtEndOfString(key) ;
            stringValue = &aTextLine[44] ;
            stripWhiteCharsAtEndOfString(stringValue) ;
            setStringValForKeyIn(pList, stringValue, key) ;
        }
    }
    
    return (pList) ;
}
