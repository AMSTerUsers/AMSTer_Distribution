
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  calcStateVect.c
 *  georef
 *
 *  Created by Dominique Derauw on Thu Feb 21 2002.
 *  Copyright (c) 2001 Dominique Derauw All rights reserved.
 *
 */

#include "stateVect.h"

struct stateVect *allocStateVector()
{
    struct stateVect *aStateVector ;
    
    if((aStateVector = (struct stateVect *)malloc(sizeof(struct stateVect))) == NULL) {
        perror("Failed to allocate a state vector") ;
        exit(-1) ;
    }
    aStateVector->P = vectorDouble(0, 2) ;
    aStateVector->V = vectorDouble(0, 2) ;
    
    return(aStateVector) ;
}

void freeStateVector(struct stateVect *aStateVector)
{
    freeVectorDouble(aStateVector->P, 0) ;
    freeVectorDouble(aStateVector->V, 0) ;
    free(aStateVector) ;
}


struct stateVect *allocVectorOfStateVectorsOfLength(int numberOfStateVectors)
{
    int i ;
    struct stateVect *stateVector ;
    
    if (!numberOfStateVectors) {
        return(NULL) ;
    }
    
    if ((stateVector = (struct stateVect *)malloc(numberOfStateVectors * sizeof(struct stateVect))) == NULL) {
        perror("Failed to allocate state vectors") ;
        exit(-1) ;
    }
    for (i = 0; i < numberOfStateVectors; i++) {
        stateVector[i].P = vectorDouble(0, 2) ;
        stateVector[i].V = vectorDouble(0, 2) ;
        
    }
    
    return(stateVector) ;
}

void copyStateVect(struct stateVect *source, struct stateVect *dest)
{
    dest->t = source->t ;
    dest->azimuthPosition = source->azimuthPosition ;
    dest->satDistance = source->satDistance ;
    dest->velocity = source->velocity ;
    memcpy(dest->P, source->P, 3 * sizeof(double)) ;
    memcpy(dest->V, source->V, 3 * sizeof(double)) ;
}

void freeVectorOfStateVectorsOfLength(struct stateVect *stateVector, int numberOfStateVectors)
{
    int i ;
    
    for (i = 0; i < numberOfStateVectors; i++) {
        if (stateVector[i].P) {
            freeVectorDouble(stateVector[i].P, 0) ;
            stateVector[i].P = NULL ;
        }
        if (stateVector[i].V) {
            freeVectorDouble(stateVector[i].V, 0) ;
            stateVector[i].V = NULL ;
        }
    }
    free(stateVector) ;
}

