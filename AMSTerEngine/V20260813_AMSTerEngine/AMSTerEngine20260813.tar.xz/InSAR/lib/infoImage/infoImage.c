
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  infoImage.c
 *  lecheader
 *
 *  Created by Dominique Derauw on Mon Feb 18 2002.
 *  Copyright (c) 2001 Dominique Derauw All rights reserved.
 *
 */

#include "infoImage.h"


struct infoImage *readInfoImageFromTextFile(char *filePath)
{
	char *aKey, *aStringVal ;
    int i, numberOfDigits, divider ;
    struct infoImage	*info ;
	keyValue *params ;
    CSVStruct *csv ;

	params = readParameterFileAtPath(filePath) ;

    info = allocInfoImage() ;

    info->CSLImagePath = initStringWithString(getStringValForKeyIn(params, "CSL")) ;    

	sprintf(info->platformName, "%s", getStringValForKeyIn(params, "Sensor")) ;
    if (strstr(info->platformName, "ERS1")) {
        info->sensorID  = __ERS1__ ;
    }
    if (strstr(info->platformName, "ERS2")) {
        info->sensorID  = __ERS2__ ;
    }
    if (strstr(info->platformName, "ENVI") || !strcmp(info->platformName, "Envi")) {
        info->sensorID  = __ENVISAT__ ;
    }
    if (strstr(info->platformName, "SENTINEL1") || (info->sensorID == -1 && strstr(info->platformName, "S1"))) {
        info->sensorID  = __SENTINEL1__ ;
    }
    if (!strncmp(info->platformName, "ALOS", 4)) {
        info->sensorID  = __ALOS__ ;
    }
    if (strstr(info->platformName, "ALOS2")) {
        info->sensorID  = __ALOS2__ ;
    }
    if (strstr(info->platformName, "CSK")) {
        info->sensorID  = __CSK__ ;
    }
    if (strstr(info->platformName, "TSX")) {
        info->sensorID  = __TSX__ ;
    }
    if (strstr(info->platformName, "TDX")) {
        info->sensorID  = __TDX__ ;
    }
    if (!strncmp(info->platformName, "RS2", 3)) {
        info->sensorID  = __RSAT2__ ;
    }
    if (strstr(info->platformName, "RADARSAT-2")) {
        info->sensorID  = __RSAT2__ ;
    }
    if (strstr(info->platformName, "KMPS5")) {
        info->sensorID  = __K5__ ;
    }
    if (strstr(info->platformName, "PAZ-1")) {
        info->sensorID  = __PAZ1__ ;
    }
    if (strstr(info->platformName, "SAOCOM_1A")) {
        info->sensorID  = __SAOCOM1A__ ;
    }
    if (strstr(info->platformName, "SAOCOM_1B")) {
        info->sensorID  = __SAOCOM1B__ ;
    }
    if (strstr(info->platformName, "ICEYE")) {
        info->sensorID  = __ICEYE__ ;
    }

    /* Read available polarization to ddetermine number of layers */
	sprintf(info->polMode, "%s", getStringValForKeyIn(params, "Pol")) ;
	sortPolarizations(info) ;               /* Sorting at each reading may appear stupid. Its only to be compatible with already read S1 data archives */
    info->polScheme = readCSVInString(info->polMode) ;
    info->numberOfLayers = info->polScheme->numberOfEntries ;

    /* Beam ID */
	info->beamNumber = getIntValForKeyIn(params, "Beam ID") ;

    /* Product ID */
    aStringVal = getStringValForKeyIn(params, "Product") ;
    if (aStringVal) {
        sprintf(info->productID, "%s", aStringVal) ;
    }
    else{
        sprintf(info->productID, " ") ;
    }

    /* Relative orbit number */
    if (isKeyValPresent(params, "Relative orbit")) {
        info->relativeOrbitNumber = getIntValForKeyIn(params, "Relative orbit") ;
    }

    /* Relative frame number */
    if (isKeyValPresent(params, "Relative frame")) {
        info->relativeFrameNumber = getIntValForKeyIn(params, "Relative frame") ;
    }

    /* Scene ID */
	sprintf(info->scene_id, "%s", getStringValForKeyIn(params, "Scene ID")) ;
	sprintf(info->scene_loc, "%s", getStringValForKeyIn(params, "Scene location")) ;

	/* Acquisition time */
	info->FPAT = getDoubleValForKeyIn(params, "First pixel azimuth time") ;
	info->LPAT = getDoubleValForKeyIn(params, "Last pixel azimuth time") ;
    if((aStringVal = getStringValForKeyIn(params, "Acquisition date")) != NULL) {
        info->acquisitionDate = initStringWithString(aStringVal) ;
        genAcquisitionTimeFromDate(info) ;
    }
    else {
        ase("No acquisition date found in infoImage.\n") ;
    }

    /* Production time */
    info->productionTime = NULL ;
    if (isKeyValPresent(params, "Production time")) {
        info->productionTime = initStringWithString(getStringValForKeyIn(params, "Production time")) ;
    }
    

    info->heading = initStringWithString(getStringValForKeyIn(params, "Heading direction")) ;
    info->headingVal = getDoubleValForKeyIn(params, "Azimuth heading") ;

    if ((aStringVal = getStringValForKeyIn(params, "Look direction")) != NULL) {
        info->lookDirection = (!strncmp(aStringVal, "R", 1))? 1. : -1. ;
    }
    else info->lookDirection = 1. ;

	info->rangeDimension = getIntValForKeyIn(params, "Range dimension") ;
	info->azimuthDimension = getIntValForKeyIn(params, "Azimuth dimension") ;
    info->radarCarrierFrequency = getDoubleValForKeyIn(params, "RCF") ;
    if (!(info->wavelength = getDoubleValForKeyIn(params, "Wavelength"))) {
        info->wavelength = speedOfLight / info->radarCarrierFrequency ;
    }
	info->rangeSamplingFrequency = getDoubleValForKeyIn(params, "RSF") ;
    info->rangeApodizationCoefficient = getDoubleValForKeyIn(params, "Range apodization coefficient") ;
	info->rangeResolutionCell = getDoubleValForKeyIn(params, "Range sampling") ;
	info->azimuthResolutionCell = getDoubleValForKeyIn(params, "Azimuth sampling") ;
	info->prf = getDoubleValForKeyIn(params, "PRF") ;
	info->lineTimeInterval = getDoubleValForKeyIn(params, "Line time interval") ;
    if (!info->lineTimeInterval) {
        info->lineTimeInterval = 1. / info->prf ;
    }
	info->rangeBandwidth = getDoubleValForKeyIn(params, "Range bandwidth") ;
	info->azimuthBandwidth = getDoubleValForKeyIn(params, "Azimuth bandwidth") ;
	info->fdc[0] = getDoubleValForKeyIn(params, "Doppler Centroid (constant term)") ;
	info->fdc[1] = getDoubleValForKeyIn(params, "Doppler Centroid (linear term)") ;
	info->fdc[2] = getDoubleValForKeyIn(params, "Doppler Centroid (quadratic term)") ;
	info->twoWayRangeTime[0] = getDoubleValForKeyIn(params, "Minimum two-way slant range time") ;
	info->slantRange[0] = getDoubleValForKeyIn(params, "Minimum slant range") ;
	info->slantRange[1] = getDoubleValForKeyIn(params, "Median slant range") ;
	info->slantRange[2] = getDoubleValForKeyIn(params, "Maximum slant range") ;
	info->incidenceAngle[0] = getDoubleValForKeyIn(params, "Incidence angle at minimum") ;
	info->incidenceAngle[1] = getDoubleValForKeyIn(params, "Incidence angle at median") ;
	info->incidenceAngle[2] = getDoubleValForKeyIn(params, "Incidence angle at maximum") ;
    

    if (isKeyValPresent(params, "Orbit type")) {
        info->orbitTypeID = initStringWithString(getStringValForKeyIn(params, "Orbit type")) ;
    }
    else {
        if (info->sensorID == __SENTINEL1__) {
            info->orbitTypeID = initStringWithString("Unknown") ;
        }
    }
	info->nVect = getIntValForKeyIn(params, "Number of state vectors") ;
//	info->FVT = getDoubleValForKeyIn(params, "First state vector azimuth time") ;
//	info->Dt = getDoubleValForKeyIn(params, "Time delay between state vectors") ;

    info->S = allocVectorOfStateVectorsOfLength(info->nVect) ;
	aKey = allocStringOfLength(25) ;
    numberOfDigits = 1 ;
    divider = 10 ;
    for(i = 0; i < info->nVect; i++) {
        if (i / divider >= 1) {
            divider *= 10 ;
            numberOfDigits++ ;
        }
		sprintf(aKey, "State vector time[%*d]", numberOfDigits, i) ;
		info->S[i].t = getDoubleValForKeyIn(params, aKey) ;
		sprintf(aKey, "X[%*d]", numberOfDigits, i) ;
		info->S[i].P[0] = getDoubleValForKeyIn(params, aKey) ;
		sprintf(aKey, "Y[%*d]", numberOfDigits, i) ;
		info->S[i].P[1] = getDoubleValForKeyIn(params, aKey) ;
		sprintf(aKey, "Z[%*d]", numberOfDigits, i) ;
		info->S[i].P[2] = getDoubleValForKeyIn(params, aKey) ;
		sprintf(aKey, "vX[%*d]", numberOfDigits, i) ;
		info->S[i].V[0] = getDoubleValForKeyIn(params, aKey) ;
		sprintf(aKey, "vY[%*d]", numberOfDigits, i) ;
		info->S[i].V[1] = getDoubleValForKeyIn(params, aKey) ;
		sprintf(aKey, "vZ[%*d]", numberOfDigits, i) ;
		info->S[i].V[2] = getDoubleValForKeyIn(params, aKey) ;
	}
    info->FVT = (info->nVect)? info->S[0].t : 0 ;

	free(aKey) ;

    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL) {
        perror("infoImage.c:112\nFailed to allocate reference ellipsoid pointer\n") ;
        exit(-1) ;
    }
 	sprintf(info->ellRef->ellipsoidID, "%s", getStringValForKeyIn(params, "Ellipsoid ID")) ;
	info->ellRef->a = getDoubleValForKeyIn(params, "Semi major axis") ;
	info->ellRef->b = getDoubleValForKeyIn(params, "Semi minor axis") ;
	info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a - info->ellRef->b) ;
	info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0 ;

	info->isOrbitInterpolationDone = 0 ;
    info->aX = info->aY = info->aZ = info->aVx = info->aVy = info->aVz = NULL ;
    info->sceneAverageHeight = getDoubleValForKeyIn(params, "Scene average height") ;
    
    info->EarthRadiusAtSceneCenter = getDoubleValForKeyIn(params, "Earth radius at scene centre") ;
	if(plError == KEY_VALUE_NOT_FOUND) info->EarthRadiusAtSceneCenter = 6371221 ;
/* for compatibility with CSL CIS */
    info->EarthRadiusAtSceneCenter = (info->EarthRadiusAtSceneCenter == -9999)? 6371221 : info->EarthRadiusAtSceneCenter ; 
    info->sceneAverageHeight = (info->sceneAverageHeight == -9999)? 0 : info->sceneAverageHeight ;
    info->incidenceAngle[1] = (info->incidenceAngle[1] == -9999)? 0 : info->incidenceAngle[1] ;

	info->loc->P[0].x = PI/180. * getDoubleValForKeyIn(params, "(0;0) longitude") ;
    info->loc->P[0].y = PI/180. * getDoubleValForKeyIn(params, "(0;0) latitude") ;
    info->loc->P[1].x = PI/180. * getDoubleValForKeyIn(params, "(maxRange;0) longitude") ;
    info->loc->P[1].y = PI/180. * getDoubleValForKeyIn(params, "(maxRange;0) latitude") ;
    info->loc->P[3].x = PI/180. * getDoubleValForKeyIn(params, "(0;maxAzimuth) longitude") ;
    info->loc->P[3].y = PI/180. * getDoubleValForKeyIn(params, "(0;maxAzimuth) latitude") ;
    info->loc->P[2].x = PI/180. * getDoubleValForKeyIn(params, "(maxRange;maxAzimuth) longitude") ;
    info->loc->P[2].y = PI/180. * getDoubleValForKeyIn(params, "(maxRange;maxAzimuth) latitude") ;

    info->locUTM->P[0].x = getDoubleValForKeyIn(params, "(0;0) Easting") ;
    info->locUTM->P[0].y = getDoubleValForKeyIn(params, "(0;0) Northing") ;
    info->locUTM->P[1].x = getDoubleValForKeyIn(params, "(maxRange;0) Easting") ;
    info->locUTM->P[1].y = getDoubleValForKeyIn(params, "(maxRange;0) Northing") ;
    info->locUTM->P[3].x = getDoubleValForKeyIn(params, "(0;maxAzimuth) Easting") ;
    info->locUTM->P[3].y = getDoubleValForKeyIn(params, "(0;maxAzimuth) Northing") ;
    info->locUTM->P[2].x = getDoubleValForKeyIn(params, "(maxRange;maxAzimuth) Easting") ;
    info->locUTM->P[2].y = getDoubleValForKeyIn(params, "(maxRange;maxAzimuth) Northing") ;

    info->aoi->P[0].x = info->aoi->P[3].x = 0 ;
    info->aoi->P[1].x = info->aoi->P[2].x = info->rangeDimension - 1 ;
    info->aoi->P[0].y = info->aoi->P[1].y = 0 ;
    info->aoi->P[2].y = info->aoi->P[3].y = info->azimuthDimension - 1 ;

    info->parameterList = params ;
    info->pitch = info->pitchRate = info->roll = info->rollRate = info->yaw = info->yawRate = NULL ;

    return info ;
}

/* Save info image at given path */
void	saveInfoImage(struct infoImage *info, char *outputFilePath)
{
    int i, numberOfDigits, divider ;
    char buffer[80] ;
    rawFileDescriptor *outputFile ;

    /* Sauvegarde du fichier infoImage */
    /* ------------------------------- */
    if((outputFile = openRawFileForWritingAtPath(outputFilePath)) == NULL) {
        sprintf (ertex, "infoImage.c:157\nFailed to create file %s\n", outputFilePath) ;
        perror (ertex) ;
        exit(-1) ;
    }

    fprintf(outputFile->f, "/* Scene ID and location */\n") ;
    fprintf(outputFile->f, "/* ********************* */\n") ;
    if (info->CSLImagePath) {
        fprintf(outputFile->f, "%s\t\t/* CSL image path */\n", info->CSLImagePath) ;
    }
    
    fprintf(outputFile->f, "%s\t\t/* Sensor ID */\n", info->platformName) ;
    if (info->acquisitionDate != NULL) {
        fprintf(outputFile->f, "%s\t\t/* Acquisition date */\n", info->acquisitionDate) ;
        genAcquisitionTimeFromDate(info) ;
        strftime(buffer,80,"%H:%M:%S", info->acquisitionTime_tm) ;
        fprintf(outputFile->f, "%s\t\t/* Acquisition time */\n", buffer) ;
    }

    if (info->productionTime) {
        fprintf(outputFile->f, "%s\t\t/* Production time */\n", info->productionTime) ;
    }
    

    if (info->heading != NULL) {
        fprintf(outputFile->f, "%s\t\t/* Heading direction */\n", info->heading) ;
    }
    if (info->headingVal) {
        fprintf(outputFile->f, "%-.16g\t\t/* Azimuth heading */\n", info->headingVal) ;
    }

    if (info->polScheme) {
        sprintf(info->polMode, "%s", info->polScheme->stringVal[0]) ;
        for ( i = 1; i < info->polScheme->numberOfEntries; i++){
            sprintf(info->polMode + strlen(info->polMode), ", %s", info->polScheme->stringVal[i]) ;
        }        
    }
    sortPolarizations(info) ;
    fprintf(outputFile->f, "%s\t\t/* Polarisation mode */\n", info->polMode) ;
    
    fprintf(outputFile->f, "%-1d\t\t/* Beam ID */\n", info->beamNumber) ;

    if (info->relativeOrbitNumber < 0) {
        fprintf(outputFile->f, "%s\t\t/* Product ID */\n", info->productID) ;
    }
    else {
        fprintf(outputFile->f, "%d\t\t/* Relative orbit number */\n", info->relativeOrbitNumber) ;

    }
    if (info->relativeFrameNumber >= 0) {
        fprintf(outputFile->f, "%d\t\t/* Relative frame number */\n", info->relativeFrameNumber) ;
    }

    fprintf(outputFile->f, "%s\t\t/* Scene ID */\n", info->scene_id) ;
    fprintf(outputFile->f, "%s\t\t/* Scene location */\n", info->scene_loc) ;

    fprintf(outputFile->f, "\n/* Main characteristics */\n") ;
    fprintf(outputFile->f, "/* ******************** */\n") ;
    if (info->lookDirection == 1.) {
        fprintf(outputFile->f, "Right looking\t\t\t/* Look direction */\n") ;
    }
    else fprintf(outputFile->f, "Left looking\t\t\t/* Look direction */\n") ;

    fprintf(outputFile->f, "%-8d\t\t\t/* Range dimension [pixels] */\n", info->rangeDimension) ;
    fprintf(outputFile->f, "%-8d\t\t\t/* Azimuth dimension [pixels] */\n", info->azimuthDimension) ;
    fprintf(outputFile->f, "%-.16g\t\t/* RCF: Radar carrier frequency [Hz] */\n", info->radarCarrierFrequency) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Wavelength [m] */\n", info->wavelength) ;
    fprintf(outputFile->f, "%-.16g\t\t/* RSF: Range sampling frequency [Hz] */\n", info->rangeSamplingFrequency) ;
    if(info->rangeBandwidth)
        fprintf(outputFile->f, "%-.16g\t\t/* Range bandwidth */\n", info->rangeBandwidth) ;
    if (info->rangeApodizationCoefficient) {
        fprintf(outputFile->f, "%-.16g\t\t/* Range apodization coefficient */\n", info->rangeApodizationCoefficient) ;
    }
    fprintf(outputFile->f, "%-.16g\t\t/* Azimuth sampling [m] */\n", info->azimuthResolutionCell) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Range sampling [m] */\n", info->rangeResolutionCell) ;
    fprintf(outputFile->f, "%-.16g\t\t/* PRF */\n", info->prf) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Line time interval */\n", info->lineTimeInterval) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Azimuth bandwidth */\n", info->azimuthBandwidth) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Doppler Centroid (constant term) [Hz] */\n", info->fdc[0]) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Doppler Centroid (linear term) [Hz]/[s] */\n", info->fdc[1]) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Doppler Centroid (quadratic term) [Hz]/[s][s]*/\n", info->fdc[2]) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Minimum two-way slant range time */\n", info->twoWayRangeTime[0]) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Minimum slant range */\n", info->slantRange[0]) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Median slant range */\n", info->slantRange[1]) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Maximum slant range */\n", info->slantRange[2]) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Incidence angle at minimum slant range [deg] */\n", info->incidenceAngle[0]) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Incidence angle at median slant range [deg] */\n", info->incidenceAngle[1]) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Incidence angle at maximum slant range [deg] */\n", info->incidenceAngle[2]) ;
    fprintf(outputFile->f, "%-.16g\t\t/* First pixel azimuth time [s] */\n", info->FPAT) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Last pixel azimuth time [s] */\n", info->LPAT) ;


    fprintf(outputFile->f, "\n/* State vectors */\n") ;
    fprintf(outputFile->f, "/* ************* */\n") ;
    if (info->orbitTypeID) {
        fprintf(outputFile->f, "%s\t\t/* Orbit type */\n", info->orbitTypeID) ;
    }
    
    fprintf(outputFile->f, "%-8d\t\t\t/* Number of state vectors */\n", info->nVect) ;
//    fprintf(outputFile->f, "%-.16g\t\t/* First state vector azimuth time [s] */\n", info->FVT) ;
//    fprintf(outputFile->f, "%-.16g\t\t/* Time delay between state vectors [s] */\n", info->Dt) ;
    numberOfDigits = 1 ;
    divider = 10 ;
    for(i = 0; i < info->nVect; i++) {
        if (i / divider >= 1) {
            divider *= 10 ;
            numberOfDigits++ ;
        }
        fprintf(outputFile->f, "\n/* Position vector %d :*/\n", i) ;
        fprintf(outputFile->f, "%-.16g\t\t/* State vector time[%d] */\n", info->S[i].t, i) ;
        fprintf(outputFile->f, "%-.16g\t\t/* X[%*d] */\n", info->S[i].P[0], numberOfDigits, i) ;
        fprintf(outputFile->f, "%-.16g\t\t/* Y[%*d] */\n", info->S[i].P[1], numberOfDigits, i) ;
        fprintf(outputFile->f, "%-.16g\t\t/* Z[%*d] */\n", info->S[i].P[2], numberOfDigits, i) ;
        fprintf(outputFile->f, "\n/* Velocity vector %d :*/\n", i) ;
        fprintf(outputFile->f, "%-.16g\t\t/* vX[%*d] */\n", info->S[i].V[0], numberOfDigits, i) ;
        fprintf(outputFile->f, "%-.16g\t\t/* vY[%*d] */\n", info->S[i].V[1], numberOfDigits, i) ;
        fprintf(outputFile->f, "%-.16g\t\t/* vZ[%*d] */\n", info->S[i].V[2], numberOfDigits, i) ;
    }


    fprintf(outputFile->f, "\n/* Reference ellipsoid */\n") ;
    fprintf(outputFile->f, "/* ******************* */\n") ;
    fprintf(outputFile->f, "%s\t\t/* Ellipsoid ID */\n", info->ellRef->ellipsoidID) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Semi major axis */\n", info->ellRef->a) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Semi minor axis */\n", info->ellRef->b) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Inverse flattening coefficient 1/f */\n", info->ellRef->f_1) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Square of the first excentricity */\n", info->ellRef->e2) ;

    fprintf(outputFile->f, "\n/* Geolocation on reference ellipsoid */\n") ;
    fprintf(outputFile->f, "/* ********************************** */\n") ;
    fprintf(outputFile->f, "%-.16g\t\t/* Scene average height */\n", info->sceneAverageHeight) ;
    fprintf(outputFile->f, "%-.16g\t\t/* Earth radius at scene centre */\n", info->EarthRadiusAtSceneCenter) ;
    fprintf(outputFile->f, "%-.15g\t\t/* (0;0) longitude */\n", 180./PI * info->loc->P[0].x) ;
    fprintf(outputFile->f, "%-.15g\t\t/* (0;0) latitude */\n", 180./PI * info->loc->P[0].y) ;
    fprintf(outputFile->f, "%-.15g\t\t/* (maxRange;0) longitude */\n", 180./PI * info->loc->P[1].x) ;
    fprintf(outputFile->f, "%-.15g\t\t/* (maxRange;0) latitude */\n", 180./PI * info->loc->P[1].y) ;
    fprintf(outputFile->f, "%-.15g\t\t/* (0;maxAzimuth) longitude */\n", 180./PI * info->loc->P[3].x) ;
    fprintf(outputFile->f, "%-.15g\t\t/* (0;maxAzimuth) latitude */\n", 180./PI * info->loc->P[3].y) ;
    fprintf(outputFile->f, "%-.15g\t\t/* (maxRange;maxAzimuth) longitude */\n", 180./PI * info->loc->P[2].x) ;
    fprintf(outputFile->f, "%-.15g\t\t/* (maxRange;maxAzimuth) latitude */\n", 180./PI * info->loc->P[2].y) ;

    fprintf(outputFile->f, "\n/* UTM Geolocation */\n") ;
    fprintf(outputFile->f, "/* *************** */\n") ;
    fprintf(outputFile->f, "%s\t\t/*UTM Zone */\n", info->UTMZone) ;
    fprintf(outputFile->f, "%-11.2f\t\t/* (0;0) Easting */\n", info->locUTM->P[0].x) ;
    fprintf(outputFile->f, "%-11.2f\t\t/* (0;0) Northing */\n",  info->locUTM->P[0].y) ;
    fprintf(outputFile->f, "%-11.2f\t\t/* (maxRange;0) Easting */\n", info->locUTM->P[1].x) ;
    fprintf(outputFile->f, "%-11.2f\t\t/* (maxRange;0) Northing */\n", info->locUTM->P[1].y) ;
    fprintf(outputFile->f, "%-11.2f\t\t/* (0;maxAzimuth) Easting */\n", info->locUTM->P[3].x) ;
    fprintf(outputFile->f, "%-11.2f\t\t/* (0;maxAzimuth) Northing */\n", info->locUTM->P[3].y) ;
    fprintf(outputFile->f, "%-11.2f\t\t/* (maxRange;maxAzimuth) Easting */\n",  info->locUTM->P[2].x) ;
    fprintf(outputFile->f, "%-11.2f\t\t/* (maxRange;maxAzimuth) Northing */\n", info->locUTM->P[2].y) ;

    freeRawFileDescriptor(outputFile) ;
}

char *saveInfoKmlInDir(SLCImageInfo *info, char *destDir)
{
    char *kmlFilePath, *aPath ;
    CSVStruct *filePathComponents ;

    filePathComponents = addStringValInCSVStruct(destDir, NULL) ;
    filePathComponents = addStringValInCSVStruct("/", filePathComponents) ;
    filePathComponents = addStringValInCSVStruct(info->platformName, filePathComponents) ;
    filePathComponents = addStringValInCSVStruct("_", filePathComponents) ;
    filePathComponents = addStringValInCSVStruct(info->acquisitionDate, filePathComponents) ;

    if (info->heading) {
        if (!strncmp(info->heading, "D",1)) {
            filePathComponents = addStringValInCSVStruct("_D", filePathComponents) ;
        }
        else {
            filePathComponents = addStringValInCSVStruct("_A", filePathComponents) ;
        }
    }

    if (info->suffix) {
        filePathComponents = addStringValInCSVStruct("_", filePathComponents) ;
        filePathComponents = addStringValInCSVStruct(info->suffix, filePathComponents) ;
    }
    
    filePathComponents = addStringValInCSVStruct(".kml", filePathComponents) ;
    aPath = getStringFromCSV(filePathComponents) ;
    kmlFilePath = replaceSubStringsInString(aPath, "//", "/") ;
    free(aPath) ;

    genKMLForPolygonAtPath(info->loc, kmlFilePath) ;

    freeCSVStruct(filePathComponents) ;

    return (kmlFilePath) ;
}

struct infoImage *allocInfoImage(void)
{
    struct infoImage *info ;

    if((info = (struct infoImage *)malloc(sizeof(struct infoImage))) == NULL) {
        perror("Failed to allocate infoImage pointer") ;
        exit(-1) ;
    }

    info->acquisitionDate = NULL ;
    info->productionTime = NULL ;
    info->suffix = NULL ;
    info->acquisitionTime = 0 ;
    info->acquisitionTime_tm = NULL ;
    info->heading = NULL ;
    info->orbitTypeID = NULL ;
    info->CSLImagePath = NULL ;


    info->sensorID = -1 ;
    info->relativeOrbitNumber = -1 ;
    info->relativeFrameNumber = -1 ;
    info->numberOfSubswaths = 1 ;
    info->swathIndex = 0 ;
    info->twoWayRangeTime = vectorDouble(0, 2) ;
    info->slantRange = vectorDouble(0, 2) ;
    info->fdc = vectorDouble(0, 2) ;
    info->dcFrequencyRate = vectorDouble(0, 2) ;
    info->incidenceAngle = vectorDouble(0, 2) ;
    info->sensorSpecificInfo = NULL ;

    info->aX = info->aY = info->aZ = NULL ;
    info->aVx = info->aVy = info->aVz = NULL ;
    info->ellRef = NULL ;
    info->parameterList = NULL ;
    info->pitch = info->pitchRate = NULL ;
    info->roll = info->rollRate = NULL ;
    info->yaw = info->yawRate = NULL ;
    info->sceneAverageHeight = 0.0 ;
    info->rangeApodizationCoefficient = 0.0 ;
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
    info->S = NULL ;
    info->loc = allocQuadrilateral() ;
    info->locUTM = allocQuadrilateral() ;
    info->aoi = allocQuadrilateral() ;
    info->flag = 0 ;
    info->isOrbitInterpolationDone = 0 ;
    info->ETADPhaseDelays = NULL ;
    info->masterInfo = NULL ;
    info->superMasterInfo = NULL ;
    info->polScheme = NULL ;


    return (info) ;
}


void freeInfoImage(struct infoImage *info)
{
    if (info) {
        if (info->acquisitionDate) {
            free(info->acquisitionDate) ;
            info->acquisitionDate = NULL ;
        }
        
        if (info->productionTime) {
            free(info->productionTime) ;
            info->productionTime = NULL ;
        }
        
        if (info->orbitTypeID) {
            free(info->orbitTypeID) ;
            info->orbitTypeID = NULL ;
        }
        
        if (info->suffix) {
            free(info->suffix) ;
            info->suffix = NULL ;
        }
        
        if (info->CSLImagePath) {
            free(info->CSLImagePath) ;
            info->CSLImagePath = NULL ;
        }
        
        if (info->sensorSpecificInfo) {
            free(info->sensorSpecificInfo) ;
            info->sensorSpecificInfo = NULL ;
        }
        
        if(info->acquisitionTime_tm != NULL) {
            free(info->acquisitionTime_tm) ;
            info->acquisitionTime_tm = NULL ;
        }

        if (info->heading) {
            free(info->heading) ;
        }
        
        if(info->twoWayRangeTime != NULL) {
            freeVectorDouble(info->twoWayRangeTime, 0) ;
            info->twoWayRangeTime = NULL ;
        }
        if(info->slantRange != NULL) {
            freeVectorDouble(info->slantRange, 0) ;
            info->slantRange = NULL ;
        }
        if(info->fdc != NULL) {
            freeVectorDouble(info->fdc, 0) ;
            info->fdc = NULL ;
        }
        if(info->dcFrequencyRate != NULL) {
            freeVectorDouble(info->dcFrequencyRate, 0) ;
            info->dcFrequencyRate = NULL ;
        }
        if(info->incidenceAngle != NULL) {
            freeVectorDouble(info->incidenceAngle, 0) ;
            info->incidenceAngle = NULL ;
        }
        if(info->S != NULL) {
            freeVectorOfStateVectorsOfLength(info->S, info->nVect) ;
            info->S = NULL ;
        }
        
        freeOrbitInterpolation(info) ;

        if(info->ellRef != NULL) {
            free(info->ellRef) ;
            info->ellRef = NULL ;
        }

        if(info->parameterList != NULL) {
            freeKeyValueList(info->parameterList) ;
            info->parameterList= NULL ;
        }

        if(info->pitch != NULL) {
            free(info->pitch) ;
            info->pitch = NULL ;
        }
        if(info->pitchRate != NULL) {
            free(info->pitchRate) ;
        }
        if(info->roll != NULL) {
            free(info->roll) ;
        }
        if(info->rollRate != NULL) {
            free(info->rollRate) ;
        }
        if(info->yaw != NULL) {
            free(info->yaw) ;
        }
        if(info->yawRate != NULL) {
            free(info->yawRate) ;
        }
        
        if (info->loc) {
            freePolygon(info->loc) ;
            info->loc = NULL ;
        }
        if (info->locUTM) {
            freePolygon(info->locUTM) ;
            info->locUTM = NULL ;
        }
        if (info->aoi) {
            freePolygon(info->aoi) ;
            info->aoi = NULL ;
        }
        if (info->ETADPhaseDelays) {
            freeVectorDouble(info->ETADPhaseDelays, 0) ;
        }
        if (info->polScheme) {
            freeCSVStruct(info->polScheme) ;
            info->polScheme = NULL ;
        }
        
        

        free(info) ;
    }
}


void freeOrbitInterpolation(struct infoImage *info)
{
    info->polynomialOrder = 0 ;
    info->isOrbitInterpolationDone = 0 ;

    if(info->aX != NULL) {
        freeVectorDouble(info->aX, 0) ;
        info->aX = NULL ;
    }
    if(info->aY != NULL) {
        freeVectorDouble(info->aY, 0) ;
        info->aY = NULL ;
    }
    if(info->aZ != NULL) {
        freeVectorDouble(info->aZ, 0) ;
        info->aZ = NULL ;
    }
    if(info->aVx != NULL) {
        freeVectorDouble(info->aVx, 0) ;
        info->aVx = NULL ;
    }
    if(info->aVy != NULL) {
        freeVectorDouble(info->aVy, 0) ;
        info->aVy = NULL ;
    }
    if(info->aVz != NULL) {
        freeVectorDouble(info->aVz, 0) ;
        info->aVz = NULL ;
    }
}

char *convertUTCStartTimeIntoAcquisitionDate(char *UTCStartTime)
{
    char *acquistionDate, aMonth[4] ;
    char YYYY[5], MM[3], DD[3] ;

    sprintf(YYYY, "%.4s", &UTCStartTime[7]) ;
    sprintf(DD, "%.2s", UTCStartTime) ;
    sprintf(aMonth, "%.3s", &UTCStartTime[3]) ;
    sprintf(MM, "%.2d", monthIndex(aMonth) + 1) ;

    acquistionDate = initStringWith3Strings(YYYY, MM, DD) ;

    return(acquistionDate) ;
}


void genAcquisitionTimeFromDate(SLCImageInfo *info)
{
    struct divr qr ;

    if (info->acquisitionTime_tm == NULL) {
        if ((info->acquisitionTime_tm = malloc(sizeof(struct tm))) == NULL) {
            ase("Failed to allocate acquisitionTime_tm broken-down time structure.\n") ;
        }
    }

    qr = divr(info->FPAT, 3600) ;
    info->acquisitionTime_tm->tm_hour = qr.q ;
    qr = divr(qr.r, 60) ;
    info->acquisitionTime_tm->tm_min = qr.q ;
    info->acquisitionTime_tm->tm_sec = (int)qr.r ;
    sscanf(info->acquisitionDate, "%4d%2d%2d", &(info->acquisitionTime_tm->tm_year), &(info->acquisitionTime_tm->tm_mon), &(info->acquisitionTime_tm->tm_mday)) ;
    info->acquisitionTime_tm->tm_year -= 1900 ;
    info->acquisitionTime_tm->tm_mon -= 1 ;
    info->acquisitionTime_tm->tm_isdst = 0 ;

    info->acquisitionTime = timegm(info->acquisitionTime_tm) ;
}

/* This function will simply order available polarizations in the following order: VV, HH, VH, HV */
/* This will ensure that when initializing interferometry without any polarisaation selection, initialization will be automatically performed using  aligned polarizations */
/* And also avoid mixing burst of different pol in case of S1 frame stitching */
void sortPolarizations(SLCImageInfo *info)
{
    int index, count ;
    CSVStruct *csv ;

    csv = readCSVInString(info->polMode) ;
    count = 0 ;
    for (index = 0; index < csv->numberOfEntries; index++) {
        count += (strncmp(csv->stringVal[index], "VV", 2))? 0 : 1 ;
        count += (strncmp(csv->stringVal[index], "HH", 2))? 0 : 2 ;
        count += (strncmp(csv->stringVal[index], "VH", 2))? 0 : 4 ;
        count += (strncmp(csv->stringVal[index], "HV", 2))? 0 : 8 ;
    }
    freeCSVStruct(csv) ;
    
    switch (count) {
        case 5:
            sprintf(info->polMode, "VV, VH") ;
            break;

        case 10:
            sprintf(info->polMode, "HH, HV") ;
            break;

        case 15:
            sprintf(info->polMode, "VV, HH, VH, HV") ;
            break;

        default:
            break;
    }
}
