
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  infoImage.c
 *  lecheader
 *
 *  Created by Dominique Derauw on Mon Feb 18 2002.
 *  Copyright (c) 2001 Dominique Derauw All rights reserved.
 *
 */

#include "infoImageEnvisat.h"

struct infoImage	*readInfoImageFromEnvisatHeader(ENVISAT_HEADER *header)
{
	char isAP, *aString ;
    int			i, hh, mm ;
    double		ss ;
    struct infoImage	*info ;

    info = allocInfoImage() ;

    sprintf(info->polMode, "%.1s%.1s", &header->Specific_Product.Polarization_MD1[0], &header->Specific_Product.Polarization_MD1[2]) ;
	isAP = ((strncmp(&header->Main_Product->Product_File_Name.Product_Id[4], "AP", 2)) == 0) ;
	if(isAP) {
        aString = initStringWithString(info->polMode) ;
		sprintf(info->polMode, "%s, %.1s%.1s", aString, &header->Specific_Product.Polarization_MD2[0], &header->Specific_Product.Polarization_MD2[2]) ;
        free(aString) ;
	}

	sprintf(info->platformName, "%s", "ENVISAT") ;
    info->beamNumber = header->Specific_Product.Swath_Number[2] - 48 ;
    memcpy(info->productID,  header->Main_Product->Product_File_Name.Product_Id,  10) ;
    for(i = 10; i < 16; i++) info->productID[i] = '\40' ;
    info->productID[16] = '\0' ;
    sprintf(info->scene_id, "ORBIT %.6s %.27s", header->Main_Product->Abs_Orbit, header->Main_Product->UTC_Start_Time) ;
    info->scene_id[40] = '\0' ;

    info->acquisitionDate = convertUTCStartTimeIntoAcquisitionDate(header->Main_Product->UTC_Start_Time) ;

    sprintf(info->scene_loc, "Center lat : %6.2f  Center lon : %6.2f", header->Geolocation_Grid[5].Latitude_First[5] * 1e-6, header->Geolocation_Grid[5].Longitude_First[5] * 1e-6) ;
    info->scene_loc[40] = '\0' ;

    info->lookDirection = RIGHT_LOOKING ;

    sscanf(header->Specific_Product.Line_Length_Value, "%d", &info->rangeDimension) ;
    sscanf(header->Specific_Product.DSD[10].Number_DSR, "%d", &info->azimuthDimension) ;

    info->radarCarrierFrequency = header->Main_Process_Param.Radar_Frequency ;
    info->wavelength = speedOfLight / info->radarCarrierFrequency ;
    info->rangeSamplingFrequency = header->Main_Process_Param.Range_Sampling_Rate ;
    info->prf = header->Main_Process_Param.flPulse_Repetition_Frequency[0] ;
    info->lineTimeInterval = 1. / info->prf ;
    info->azimuthBandwidth = header->Main_Process_Param.Processed_Azimuth_Bandwidth ;
    info->rangeBandwidth = header->Main_Process_Param.flTX_Pulse_Bandwidth[0] ;
    info->azimuthResolutionCell = header->Main_Process_Param.Azimuth_Sample_Spacing ;
    info->rangeResolutionCell = header->Main_Process_Param.Range_Sample_Spacing ;
    info->fdc[0] = header->Doppler_Centroid_Param.Doppler_Centroid_Coef[0] ;
    info->fdc[1] = header->Doppler_Centroid_Param.Doppler_Centroid_Coef[1] ;
    info->fdc[2] = header->Doppler_Centroid_Param.Doppler_Centroid_Coef[2] ;

    info->twoWayRangeTime[0] = header->Geolocation_Grid[5].Slant_Range_Time_First[0] * 1e-9 ;
    info->twoWayRangeTime[1] = header->Geolocation_Grid[5].Slant_Range_Time_First[5] * 1e-9 ;
    info->twoWayRangeTime[2] = header->Geolocation_Grid[5].Slant_Range_Time_First[10] * 1e-9 ;
    for(i = 0; i < 3; i++) info->slantRange[i] = c0/2. * info->twoWayRangeTime[i] ;

	hh = readIntInASCIIStringOfLength(&header->Specific_Product.First_Azimuth_Time[12], 2) ;
	mm = readIntInASCIIStringOfLength(&header->Specific_Product.First_Azimuth_Time[15], 2) ;
	ss = readDoubleInASCIIStringOfLength(&header->Specific_Product.First_Azimuth_Time[18], 9) ;
    info->FPAT = 3600.*hh + 60.*mm + ss ;
	hh = readIntInASCIIStringOfLength(&header->Specific_Product.Last_Azimuth_Time[12], 2) ;
	mm = readIntInASCIIStringOfLength(&header->Specific_Product.Last_Azimuth_Time[15], 2) ;
	ss = readDoubleInASCIIStringOfLength(&header->Specific_Product.Last_Azimuth_Time[18], 9) ;
    info->LPAT = 3600.*hh + 60.*mm + ss ;

    info->incidenceAngle[0] = header->Geolocation_Grid[5].Incidence_Angle_First[0] ;
    info->incidenceAngle[1] = header->Geolocation_Grid[5].Incidence_Angle_First[5] ;
    info->incidenceAngle[2] = header->Geolocation_Grid[5].Incidence_Angle_First[10] ;
    info->nVect = 5 ;
    if((info->S = (struct stateVect *)malloc(info->nVect * sizeof(struct stateVect))) == NULL)
        ase("Erreur d'allocation de info->S\n") ;
    for(i=0; i<info->nVect; i++) {
        info->S[i].P = vectorDouble(0, 2) ;
        info->S[i].V = vectorDouble(0, 2) ;
        info->S[i].P[0] = (double)header->Main_Process_Param.Orbit_State[i].X_Position_Earth * 1e-2 ;
        info->S[i].P[1] = (double)header->Main_Process_Param.Orbit_State[i].Y_Position_Earth * 1e-2 ;
        info->S[i].P[2] = (double)header->Main_Process_Param.Orbit_State[i].Z_Position_Earth * 1e-2 ;
        info->S[i].V[0] = (double)header->Main_Process_Param.Orbit_State[i].X_Velocity_Earth * 1e-5 ;
        info->S[i].V[1] = (double)header->Main_Process_Param.Orbit_State[i].Y_Velocity_Earth * 1e-5 ;
        info->S[i].V[2] = (double)header->Main_Process_Param.Orbit_State[i].Z_Velocity_Earth * 1e-5 ;
        info->S[i].t = (double)header->Main_Process_Param.Orbit_State[i].Time_State_Vector.seconds + header->Main_Process_Param.Orbit_State[i].Time_State_Vector.microseconds * 1e-6 ;
	}
    info->FVT = info->S[0].t ;
    info->Dt = info->S[1].t - info->S[0].t ;

	info->aX = info->aY = info->aZ = info->aVx= info->aVy= info->aVz = NULL ;
	info->isOrbitInterpolationDone = 0 ;

    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL)
        ase("Erreur d'allocation de *info->ellRef\n") ;
    sprintf(info->ellRef->ellipsoidID, "GEM6") ;
    info->ellRef->a = 6378144.0 ;
    info->ellRef->b = 6356759 ;
    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;

	/* Geolocate scene on reference ellipsoid */
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
	info->EarthRadiusAtSceneCenter = 6371221. ;
	geolocateSceneOnEllipsoid(info, info->ellRef) ;

    return info ;
}

ENVISAT_HEADER *readEnvisatHeader(char *filePath)
{
	FILE *envisatFile ;
	ENVISAT_HEADER *header ;

	if ((envisatFile = fopen (filePath, "r")) == NULL)
		ase("Unable to open ENVISAT File") ;

	header = allocEnvisatHeader() ;
	readMainProductHeader(header, envisatFile) ;
	readSpecificProductHeader(header, envisatFile) ;
	readSummaryQualityRecord(header, envisatFile) ;
	readMainProcessParametersRecord(header, envisatFile) ;
	readDopplerCentroidParametersRecord(header, envisatFile) ;
	readSlantToGroundRangeConversionGrid(header, envisatFile) ;
	readChirpParametersRecord(header, envisatFile) ;
	readAntennaPatternRecord(header, envisatFile) ;
	readGeolocationGrid(header, envisatFile) ;
	readMapProjectionRecord(header, envisatFile) ;

	fclose(envisatFile) ;
	return header ;
}

/*
void readDopplerCentroidParametersRecord(ENVISAT_HEADER *header, FILE *f1)
{
	int	indiceDSD ;
    DCC_ADSR_HEADER_CHAR		DCC_Header ;

    if((DCC_Header = (DCC_ADSR_HEADER_CHAR *)calloc (1, sizeof(DCC_ADSR_HEADER_CHAR))) == NULL)
		ase("Unable to allocate Summary Quality Record") ;

    if((indiceDSD = getIndexOfDSD("GEOLOCATION GRID", header)) != -1) {
        seekFileForDSD(f1, header, indiceDSD, 0) ;
        fread ((DCC_ADSR_HEADER_CHAR *)DCC_Header, sizeof(DCC_ADSR_HEADER_CHAR), 1, f1) ;

	}
}

*/




void readMapProjectionRecord(ENVISAT_HEADER *header, FILE *f1)
{
	int	indiceDSD, i ;
    GADS_HEADER_CHAR *Map_Projection ;

    if((Map_Projection = (GADS_HEADER_CHAR *)calloc (1, sizeof(GADS_HEADER_CHAR))) == NULL)
		ase("Unable to allocate Summary Quality Record") ;

    if((indiceDSD = getIndexOfDSD("MAP PROJECTION", header)) != -1) {
        seekFileForDSD(f1, header, indiceDSD, 0) ;
        fread ((GADS_HEADER_CHAR *)Map_Projection, sizeof(GADS_HEADER_CHAR), 1, f1) ;

		sscanf (Map_Projection->Map_Projection_Des, "%32s", header->Map_Projection_Param.Map_Projection_Des) ;
		memcpy (&header->Map_Projection_Param.Number_Samples_Line, Map_Projection->Number_Samples_Line, 4) ;
		memcpy (&header->Map_Projection_Param.Number_Lines, Map_Projection->Number_Lines, 4) ;
		memcpy (&header->Map_Projection_Param.Inter_Sample_Distance, Map_Projection->Inter_Sample_Distance, 4) ;
		memcpy (&header->Map_Projection_Param.Inter_Line_Distance, Map_Projection->Inter_Line_Distance, 4) ;
		memcpy (&header->Map_Projection_Param.Output_Scene_Orientation, Map_Projection->Output_Scene_Orientation, 4) ;
		strncpy (header->Map_Projection_Param.Spare1, Map_Projection->Spare1, 40) ;
		memcpy (&header->Map_Projection_Param.Platform_Heading, Map_Projection->Platform_Heading, 4) ;
		sscanf (Map_Projection->Ellipsoid_Name, "%32s", header->Map_Projection_Param.Ellipsoid_Name) ;
		memcpy (&header->Map_Projection_Param.Semi_Major_Axis, Map_Projection->Semi_Major_Axis, 4) ;
		memcpy (&header->Map_Projection_Param.Semi_Minor_Axis, Map_Projection->Semi_Minor_Axis, 4) ;
		memcpy (&header->Map_Projection_Param.Datum_Shift_dx, Map_Projection->Datum_Shift_dx, 4) ;
		memcpy (&header->Map_Projection_Param.Datum_Shift_dy, Map_Projection->Datum_Shift_dy, 4) ;
		memcpy (&header->Map_Projection_Param.Datum_Shift_dz, Map_Projection->Datum_Shift_dz, 4) ;
		memcpy (&header->Map_Projection_Param.Average_Scene_Height, Map_Projection->Average_Scene_Height, 4) ;
		strncpy (header->Map_Projection_Param.Spare2, Map_Projection->Spare2, 12) ;
		sscanf (Map_Projection->Map_Projection, "%32s", header->Map_Projection_Param.Map_Projection) ;
		sscanf (Map_Projection->UTM_Descriptor, "%32s", header->Map_Projection_Param.UTM_Descriptor) ;
		sscanf (Map_Projection->UTM_Signature, "%4s", header->Map_Projection_Param.UTM_Signature) ;
		memcpy (&header->Map_Projection_Param.UTM_Map_Easting, Map_Projection->UTM_Map_Easting, 4) ;
		memcpy (&header->Map_Projection_Param.UTM_Map_Northing, Map_Projection->UTM_Map_Northing, 4) ;
		memcpy (&header->Map_Projection_Param.UTM_Projection_Longitude, Map_Projection->UTM_Projection_Longitude, 4) ;
		memcpy (&header->Map_Projection_Param.UTM_Projection_Latitude, Map_Projection->UTM_Projection_Latitude, 4) ;
		memcpy (&header->Map_Projection_Param.UTM_Parallel_1, Map_Projection->UTM_Parallel_1, 4) ;
		memcpy (&header->Map_Projection_Param.UTM_Parallel_2, Map_Projection->UTM_Parallel_2, 4) ;
		memcpy (&header->Map_Projection_Param.UTM_Scale_Factor, Map_Projection->UTM_Scale_Factor, 4) ;
		sscanf (Map_Projection->UPS_Descriptor, "%32s", header->Map_Projection_Param.UPS_Descriptor) ;
		memcpy (&header->Map_Projection_Param.UPS_Projection_Longitude, Map_Projection->UPS_Projection_Longitude, 4) ;
		memcpy (&header->Map_Projection_Param.UPS_Projection_Latitude, Map_Projection->UPS_Projection_Latitude, 4) ;
		memcpy (&header->Map_Projection_Param.UPS_Scale_Factor, Map_Projection->UPS_Scale_Factor, 4) ;
		sscanf (Map_Projection->NSP_Descriptor, "%32s", header->Map_Projection_Param.NSP_Descriptor) ;
		memcpy (&header->Map_Projection_Param.NSP_Map_Easting, Map_Projection->NSP_Map_Easting, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Map_Northing, Map_Projection->NSP_Map_Northing, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Projection_Longitude, Map_Projection->NSP_Projection_Longitude, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Projection_Latitude, Map_Projection->NSP_Projection_Latitude, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Parallel_1, Map_Projection->NSP_Parallel_1, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Parallel_2, Map_Projection->NSP_Parallel_2, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Parallel_3, Map_Projection->NSP_Parallel_3, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Parallel_4, Map_Projection->NSP_Parallel_4, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Meridian_1, Map_Projection->NSP_Meridian_1, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Meridian_2, Map_Projection->NSP_Meridian_2, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Meridian_3, Map_Projection->NSP_Meridian_3, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Dependant_1, Map_Projection->NSP_Dependant_1, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Dependant_2, Map_Projection->NSP_Dependant_2, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Dependant_3, Map_Projection->NSP_Dependant_3, 4) ;
		memcpy (&header->Map_Projection_Param.NSP_Dependant_4, Map_Projection->NSP_Dependant_4, 4) ;
		memcpy (&header->Map_Projection_Param.Top_Left_Northing, Map_Projection->Top_Left_Northing, 4) ;
		memcpy (&header->Map_Projection_Param.Top_Left_Easting, Map_Projection->Top_Left_Easting, 4) ;
		memcpy (&header->Map_Projection_Param.Top_Right_Northing, Map_Projection->Top_Right_Northing, 4) ;
		memcpy (&header->Map_Projection_Param.Top_Right_Easting, Map_Projection->Top_Right_Easting, 4) ;
		memcpy (&header->Map_Projection_Param.Bottom_Right_Northing, Map_Projection->Bottom_Right_Northing, 4) ;
		memcpy (&header->Map_Projection_Param.Bottom_Right_Easting, Map_Projection->Bottom_Right_Easting, 4) ;
		memcpy (&header->Map_Projection_Param.Bottom_Left_Northing, Map_Projection->Bottom_Left_Northing, 4) ;
		memcpy (&header->Map_Projection_Param.Bottom_Left_Easting, Map_Projection->Bottom_Left_Easting, 4) ;
		memcpy (&header->Map_Projection_Param.Top_Left_Latitude, Map_Projection->Top_Left_Latitude, 4) ;
		memcpy (&header->Map_Projection_Param.Top_Left_Longitude, Map_Projection->Top_Left_Longitude, 4) ;
		memcpy (&header->Map_Projection_Param.Top_Right_Latitude, Map_Projection->Top_Right_Latitude, 4) ;
		memcpy (&header->Map_Projection_Param.Top_Right_Longitude, Map_Projection->Top_Right_Longitude, 4) ;
		memcpy (&header->Map_Projection_Param.Bottom_Right_Latitude, Map_Projection->Bottom_Right_Latitude, 4) ;
		memcpy (&header->Map_Projection_Param.Bottom_Right_Longitude, Map_Projection->Bottom_Right_Longitude, 4) ;
		memcpy (&header->Map_Projection_Param.Bottom_Left_Latitude, Map_Projection->Bottom_Left_Latitude, 4) ;
		memcpy (&header->Map_Projection_Param.Bottom_Left_Longitude, Map_Projection->Bottom_Left_Longitude, 4) ;
		strncpy (header->Map_Projection_Param.Spare3, Map_Projection->Spare3, 32) ;

		for (i = 0 ; i < 8 ; i++)
			memcpy (&header->Map_Projection_Param.Coefficient_Position[i], &Map_Projection->Coefficient_Position[i*4], 4) ;
		for (i = 0 ; i < 8 ; i++)
			memcpy (&header->Map_Projection_Param.Coefficient_Projection[i], &Map_Projection->Coefficient_Projection[i*4], 4) ;
		strncpy (header->Map_Projection_Param.Spare4, Map_Projection->Spare4, 35) ;

		if(!isArchBigEndian()) {
			swap4bytesStruct(&header->Map_Projection_Param.Number_Samples_Line) ;
			swap4bytesStruct(&header->Map_Projection_Param.Number_Lines) ;
			swapFloat(&header->Map_Projection_Param.Inter_Sample_Distance) ;
			swapFloat(&header->Map_Projection_Param.Inter_Line_Distance) ;
			swapFloat(&header->Map_Projection_Param.Output_Scene_Orientation) ;
			swapFloat(&header->Map_Projection_Param.Platform_Heading) ;
			swapFloat(&header->Map_Projection_Param.Semi_Major_Axis) ;
			swapFloat(&header->Map_Projection_Param.Semi_Minor_Axis) ;
			swapFloat(&header->Map_Projection_Param.Datum_Shift_dx) ;
			swapFloat(&header->Map_Projection_Param.Datum_Shift_dy) ;
			swapFloat(&header->Map_Projection_Param.Datum_Shift_dz) ;
			swapFloat(&header->Map_Projection_Param.Average_Scene_Height) ;
			swapFloat(&header->Map_Projection_Param.UTM_Map_Easting) ;
			swapFloat(&header->Map_Projection_Param.UTM_Map_Northing) ;
			swap4bytesStruct(&header->Map_Projection_Param.UTM_Projection_Longitude) ;
			swap4bytesStruct(&header->Map_Projection_Param.UTM_Projection_Latitude) ;
			swapFloat(&header->Map_Projection_Param.UTM_Parallel_1) ;
			swapFloat(&header->Map_Projection_Param.UTM_Parallel_2) ;
			swapFloat(&header->Map_Projection_Param.UTM_Scale_Factor) ;
			swap4bytesStruct(&header->Map_Projection_Param.UPS_Projection_Longitude) ;
			swap4bytesStruct(&header->Map_Projection_Param.UPS_Projection_Latitude) ;
			swapFloat(&header->Map_Projection_Param.UPS_Scale_Factor) ;
			swapFloat(&header->Map_Projection_Param.NSP_Map_Easting) ;
			swapFloat(&header->Map_Projection_Param.NSP_Map_Northing) ;
			swap4bytesStruct(&header->Map_Projection_Param.NSP_Projection_Longitude) ;
			swap4bytesStruct(&header->Map_Projection_Param.NSP_Projection_Latitude) ;
			swapFloat(&header->Map_Projection_Param.NSP_Parallel_1) ;
			swapFloat(&header->Map_Projection_Param.NSP_Parallel_2) ;
			swapFloat(&header->Map_Projection_Param.NSP_Parallel_3) ;
			swapFloat(&header->Map_Projection_Param.NSP_Parallel_4) ;
			swapFloat(&header->Map_Projection_Param.NSP_Meridian_1) ;
			swapFloat(&header->Map_Projection_Param.NSP_Meridian_2) ;
			swapFloat(&header->Map_Projection_Param.NSP_Meridian_3) ;
			swapFloat(&header->Map_Projection_Param.NSP_Dependant_1) ;
			swapFloat(&header->Map_Projection_Param.NSP_Dependant_2) ;
			swapFloat(&header->Map_Projection_Param.NSP_Dependant_3) ;
			swapFloat(&header->Map_Projection_Param.NSP_Dependant_4) ;
			swapFloat(&header->Map_Projection_Param.Top_Left_Northing) ;
			swapFloat(&header->Map_Projection_Param.Top_Left_Easting) ;
			swapFloat(&header->Map_Projection_Param.Top_Right_Northing) ;
			swapFloat(&header->Map_Projection_Param.Top_Right_Easting) ;
			swapFloat(&header->Map_Projection_Param.Bottom_Right_Northing) ;
			swapFloat(&header->Map_Projection_Param.Bottom_Right_Easting) ;
			swapFloat(&header->Map_Projection_Param.Bottom_Left_Northing) ;
			swapFloat(&header->Map_Projection_Param.Bottom_Left_Easting) ;
			swapFloat(&header->Map_Projection_Param.Top_Left_Latitude) ;
			swapFloat(&header->Map_Projection_Param.Top_Left_Longitude) ;
			swapFloat(&header->Map_Projection_Param.Top_Right_Latitude) ;
			swapFloat(&header->Map_Projection_Param.Top_Right_Longitude) ;
			swapFloat(&header->Map_Projection_Param.Bottom_Right_Latitude) ;
			swapFloat(&header->Map_Projection_Param.Bottom_Right_Longitude) ;
			swapFloat(&header->Map_Projection_Param.Bottom_Left_Latitude) ;
			swapFloat(&header->Map_Projection_Param.Bottom_Left_Longitude) ;

			for (i = 0 ; i < 8 ; i++)
				swapFloat(&header->Map_Projection_Param.Coefficient_Position[i]) ;
			for (i = 0 ; i < 8 ; i++)
				swapFloat(&header->Map_Projection_Param.Coefficient_Projection[i]) ;
		}

	}
}




void readGeolocationGrid(ENVISAT_HEADER *header, FILE *f1)
{
	int	indiceDSD, i, j ;
    GEOLOCATION_GRID_HEADER_CHAR	*Geolocation_Grid ;

    if((Geolocation_Grid = (GEOLOCATION_GRID_HEADER_CHAR *)calloc (1, sizeof(GEOLOCATION_GRID_HEADER_CHAR))) == NULL)
		ase("Unable to allocate Summary Quality Record") ;

    if((indiceDSD = getIndexOfDSD("GEOLOCATION GRID", header)) != -1) {
        seekFileForDSD(f1, header, indiceDSD, 0) ;
        for (j = 0 ; j < 11 ; j++) {
            fread ((GEOLOCATION_GRID_HEADER_CHAR *)Geolocation_Grid, sizeof(GEOLOCATION_GRID_HEADER_CHAR), 1, f1) ;
            memcpy (&header->Geolocation_Grid[j].Doppler_Azimuth_Time_First.days, &Geolocation_Grid->Doppler_Azimuth_Time_First[0], 4) ;
            memcpy (&header->Geolocation_Grid[j].Doppler_Azimuth_Time_First.seconds, &Geolocation_Grid->Doppler_Azimuth_Time_First[4], 4) ;
            memcpy (&header->Geolocation_Grid[j].Doppler_Azimuth_Time_First.microseconds, &Geolocation_Grid->Doppler_Azimuth_Time_First[8], 4) ;
            header->Geolocation_Grid[j].Attachment = Geolocation_Grid->Attachment ;
            memcpy (&header->Geolocation_Grid[j].Range_Line_Number, Geolocation_Grid->Range_Line_Number, 4) ;
            memcpy (&header->Geolocation_Grid[j].Number_Output_Lines, Geolocation_Grid->Number_Output_Lines, 4) ;
            memcpy (&header->Geolocation_Grid[j].Track_Heading, Geolocation_Grid->Track_Heading, 4) ;
            for (i = 0 ; i < 11 ; i++)
                memcpy (&header->Geolocation_Grid[j].Range_Sample_Number_First[i], &Geolocation_Grid->Range_Sample_Number_First[i*4], 4) ;

            for (i = 0 ; i < 11 ; i++)
                memcpy (&header->Geolocation_Grid[j].Slant_Range_Time_First[i], &Geolocation_Grid->Slant_Range_Time_First[i*4], 4) ;

            for (i = 0 ; i < 11 ; i++)
                memcpy (&header->Geolocation_Grid[j].Incidence_Angle_First[i], &Geolocation_Grid->Incidence_Angle_First[i*4], 4) ;

            for (i = 0 ; i < 11 ; i++)
                memcpy (&header->Geolocation_Grid[j].Latitude_First[i], &Geolocation_Grid->Latitude_First[i*4], 4) ;

            for (i = 0 ; i < 11 ; i++)
                memcpy (&header->Geolocation_Grid[j].Longitude_First[i], &Geolocation_Grid->Longitude_First[i*4], 4) ;

            strncpy (header->Geolocation_Grid[j].Spare1,Geolocation_Grid->Spare1, 22) ;
            memcpy (&header->Geolocation_Grid[j].Doppler_Azimuth_Time_Last.days, &Geolocation_Grid->Doppler_Azimuth_Time_Last[0], 4) ;
            memcpy (&header->Geolocation_Grid[j].Doppler_Azimuth_Time_Last.seconds, &Geolocation_Grid->Doppler_Azimuth_Time_Last[4], 4) ;
            memcpy (&header->Geolocation_Grid[j].Doppler_Azimuth_Time_Last.microseconds, &Geolocation_Grid->Doppler_Azimuth_Time_Last[8], 4) ;
            for (i = 0 ; i < 11 ; i++)
                memcpy (&header->Geolocation_Grid[j].Range_Sample_Number_Last[i], &Geolocation_Grid->Range_Sample_Number_Last[i*4], 4) ;

            for (i = 0 ; i < 11 ; i++)
                memcpy (&header->Geolocation_Grid[j].Slant_Range_Time_Last[i], &Geolocation_Grid->Slant_Range_Time_Last[i*4], 4) ;

            for (i = 0 ; i < 11 ; i++)
                memcpy (&header->Geolocation_Grid[j].Incidence_Angle_Last[i], &Geolocation_Grid->Incidence_Angle_Last[i*4], 4) ;

            for (i = 0 ; i < 11 ; i++)
                memcpy (&header->Geolocation_Grid[j].Latitude_Last[i], &Geolocation_Grid->Latitude_Last[i*4], 4) ;

            for (i = 0 ; i < 11 ; i++)
                memcpy (&header->Geolocation_Grid[j].Longitude_Last[i], &Geolocation_Grid->Longitude_Last[i*4], 4) ;

            strncpy (header->Geolocation_Grid[j].Spare2, Geolocation_Grid->Spare2, 22) ;

			if(!isArchBigEndian()) {
				swap4bytesStruct(&header->Geolocation_Grid[j].Doppler_Azimuth_Time_First.days) ;
				swap4bytesStruct(&header->Geolocation_Grid[j].Doppler_Azimuth_Time_First.seconds) ;
				swap4bytesStruct(&header->Geolocation_Grid[j].Doppler_Azimuth_Time_First.microseconds) ;
				swap4bytesStruct(&header->Geolocation_Grid[j].Range_Line_Number) ;
				swap4bytesStruct(&header->Geolocation_Grid[j].Number_Output_Lines) ;
				swapFloat(&header->Geolocation_Grid[j].Track_Heading) ;
				for (i = 0 ; i < 11 ; i++)
					swap4bytesStruct(&header->Geolocation_Grid[j].Range_Sample_Number_First[i]) ;

				for (i = 0 ; i < 11 ; i++)
					swapFloat(&header->Geolocation_Grid[j].Slant_Range_Time_First[i]) ;

				for (i = 0 ; i < 11 ; i++)
					swapFloat(&header->Geolocation_Grid[j].Incidence_Angle_First[i]) ;

				for (i = 0 ; i < 11 ; i++)
					swap4bytesStruct(&header->Geolocation_Grid[j].Latitude_First[i]) ;

				for (i = 0 ; i < 11 ; i++)
					swap4bytesStruct(&header->Geolocation_Grid[j].Longitude_First[i]) ;

				swap4bytesStruct(&header->Geolocation_Grid[j].Doppler_Azimuth_Time_Last.days) ;
				swap4bytesStruct(&header->Geolocation_Grid[j].Doppler_Azimuth_Time_Last.seconds) ;
				swap4bytesStruct(&header->Geolocation_Grid[j].Doppler_Azimuth_Time_Last.microseconds) ;
				for (i = 0 ; i < 11 ; i++)
					swap4bytesStruct(&header->Geolocation_Grid[j].Range_Sample_Number_Last[i]) ;

				for (i = 0 ; i < 11 ; i++)
					swapFloat(&header->Geolocation_Grid[j].Slant_Range_Time_Last[i]) ;

				for (i = 0 ; i < 11 ; i++)
					swapFloat(&header->Geolocation_Grid[j].Incidence_Angle_Last[i]) ;

				for (i = 0 ; i < 11 ; i++)
					swap4bytesStruct(&header->Geolocation_Grid[j].Latitude_Last[i]) ;

				for (i = 0 ; i < 11 ; i++)
					swap4bytesStruct(&header->Geolocation_Grid[j].Longitude_Last[i]) ;
			}

        }
	}
}





void readAntennaPatternRecord(ENVISAT_HEADER *header, FILE *f1)
{
	int	indiceDSD ;

    if((indiceDSD = getIndexOfDSD("MDS1 ANTENNA", header)) != -1)
		header->Antenna_ElevationMDS1 = readAntennaElevationPatternForDSD(indiceDSD, header, f1) ;

    if((indiceDSD = getIndexOfDSD("MDS2 ANTENNA", header)) != -1)
		header->Antenna_ElevationMDS2 = readAntennaElevationPatternForDSD(indiceDSD, header, f1) ;
}


ANTENNA_ELEVATION_HEADER *readAntennaElevationPatternForDSD(int indiceDSD, ENVISAT_HEADER *header, FILE *f1)
{
    int		i, j ;
    long	numberOfRecords ;
    ANTENNA_ELEVATION_HEADER_CHAR	*Antenna_Elevation ;
    ANTENNA_ELEVATION_HEADER	*antennaElevationPattern ;

    if ((Antenna_Elevation = (ANTENNA_ELEVATION_HEADER_CHAR *)calloc (1, sizeof(ANTENNA_ELEVATION_HEADER_CHAR))) == NULL)
		ase("Unable to allocate Antenna Patern Record") ;

    sscanf (header->Specific_Product.DSD[indiceDSD].Number_DSR, "%lu", &numberOfRecords) ;
    if ((antennaElevationPattern = (ANTENNA_ELEVATION_HEADER *)calloc (numberOfRecords, sizeof(ANTENNA_ELEVATION_HEADER))) == NULL)
		ase("Unable to allocate Antenna Patern Record") ;

    for(j = 0 ; j < numberOfRecords; j++) {
        seekFileForDSD(f1, header, indiceDSD, j) ;
		fread ((ANTENNA_ELEVATION_HEADER_CHAR *)Antenna_Elevation, sizeof(ANTENNA_ELEVATION_HEADER_CHAR), 1, f1) ;

        memcpy (&antennaElevationPattern[j].Doppler_Azimuth_Time.days, &Antenna_Elevation->Doppler_Azimuth_Time[0], 4) ;
		memcpy (&antennaElevationPattern[j].Doppler_Azimuth_Time.seconds, &Antenna_Elevation->Doppler_Azimuth_Time[4], 4) ;
        memcpy (&antennaElevationPattern[j].Doppler_Azimuth_Time.microseconds, &Antenna_Elevation->Doppler_Azimuth_Time[8], 4) ;
		antennaElevationPattern[j].Attachment = Antenna_Elevation->Attachment ;
        sscanf (Antenna_Elevation->Beam_Id, "%3s", antennaElevationPattern[j].Beam_Id) ;
        for (i = 0 ; i < 11 ; i++)
        {
            memcpy (&antennaElevationPattern[j].Slant_Range_Time[i], &Antenna_Elevation->Slant_Range_Time[4 * i], 4) ;
            memcpy (&antennaElevationPattern[j].Elevation_Angles[i], &Antenna_Elevation->Elevation_Angles[4  * i], 4) ;
            memcpy (&antennaElevationPattern[j].Antenna_Elevation[i], &Antenna_Elevation->Antenna_Elevation[i*4], 4) ;
        }
        strncpy (antennaElevationPattern[j].Spare, Antenna_Elevation->Spare, 14) ;

		if(!isArchBigEndian()) {
			swap4bytesStruct(&antennaElevationPattern[j].Doppler_Azimuth_Time.days) ;
			swap4bytesStruct(&antennaElevationPattern[j].Doppler_Azimuth_Time.seconds) ;
			swap4bytesStruct(&antennaElevationPattern[j].Doppler_Azimuth_Time.microseconds) ;
			for (i = 0 ; i < 11 ; i++)
			{
				swapFloat(&antennaElevationPattern[j].Slant_Range_Time[i]) ;
				swapFloat(&antennaElevationPattern[j].Elevation_Angles[i]) ;
				swapFloat(&antennaElevationPattern[j].Antenna_Elevation[i]) ;
			}
		}

    }
    free(Antenna_Elevation) ;
    return antennaElevationPattern ;
}



void readChirpParametersRecord(ENVISAT_HEADER *header, FILE *f1)
{
	int	indiceDSD, i, j ;
    CHIRP_HEADER_CHAR		*Chirp_Parameters ;

    if((Chirp_Parameters = (CHIRP_HEADER_CHAR *)calloc (1, sizeof(CHIRP_HEADER_CHAR))) == NULL)
		ase("Unable to allocate Summary Quality Record") ;

    if((indiceDSD = getIndexOfDSD("CHIRP PARAM ADS", header)) != -1) {
        seekFileForDSD(f1, header, indiceDSD, 0) ;
        fread ((CHIRP_HEADER_CHAR *)Chirp_Parameters, sizeof(CHIRP_HEADER_CHAR), 1, f1) ;

        memcpy (&header->Chirp_Parameters.Doppler_Azimuth_Time.days, &Chirp_Parameters->Doppler_Azimuth_Time[0], 4) ;
        memcpy (&header->Chirp_Parameters.Doppler_Azimuth_Time.seconds, &Chirp_Parameters->Doppler_Azimuth_Time[4], 4) ;
        memcpy (&header->Chirp_Parameters.Doppler_Azimuth_Time.microseconds, &Chirp_Parameters->Doppler_Azimuth_Time[8], 4) ;
        header->Chirp_Parameters.Attachment = Chirp_Parameters->Attachment ;
        sscanf (Chirp_Parameters->Beam_Id, "%3s", header->Chirp_Parameters.Beam_Id) ;
        sscanf (Chirp_Parameters->Tx_Rx_Polarization, "%3s", header->Chirp_Parameters.Tx_Rx_Polarization) ;
        memcpy (&header->Chirp_Parameters.Pulse_Width, Chirp_Parameters->Pulse_Width, 4) ;
        memcpy (&header->Chirp_Parameters.Side_Lobe, Chirp_Parameters->Side_Lobe, 4) ;
        memcpy (&header->Chirp_Parameters.ISLR, Chirp_Parameters->ISLR, 4) ;
        memcpy (&header->Chirp_Parameters.Peak_Location, Chirp_Parameters->Peak_Location, 4) ;
        memcpy (&header->Chirp_Parameters.Chirp_Power, Chirp_Parameters->Chirp_Power, 4) ;
        memcpy (&header->Chirp_Parameters.Elevation_Gain, Chirp_Parameters->Elevation_Gain, 4) ;
        strncpy (header->Chirp_Parameters.Spare1, Chirp_Parameters->Spare1, 16) ;
        for (i = 0 ; i < 32 ; i++)
        {
            for(j = 0; j < 3; j++)
                memcpy (&header->Chirp_Parameters.Calibration_Pulse[i].Max_Cal_Pulses[j], &Chirp_Parameters->Calibration_Pulse[i].Max_Cal_Pulses[4 * j], 4) ;
            for(j = 0; j < 3; j++)
                memcpy (&header->Chirp_Parameters.Calibration_Pulse[i].Average_Cal_Pulse[j], &Chirp_Parameters->Calibration_Pulse[i].Average_Cal_Pulse[4 * j], 4) ;
            memcpy (&header->Chirp_Parameters.Calibration_Pulse[i].Average_Cal_Pulse_1A, Chirp_Parameters->Calibration_Pulse[i].Average_Cal_Pulse_1A, 4) ;
            for(j = 0; j < 4; j++)
                memcpy (&header->Chirp_Parameters.Calibration_Pulse[i].Extracted_Phase[j], &Chirp_Parameters->Calibration_Pulse[i].Extracted_Phase[4 * j], 4) ;
        }

        strncpy (header->Chirp_Parameters.Spare2, Chirp_Parameters->Spare2, 16) ;

		if(!isArchBigEndian()) {
			swap4bytesStruct(&header->Chirp_Parameters.Doppler_Azimuth_Time.days) ;
			swap4bytesStruct(&header->Chirp_Parameters.Doppler_Azimuth_Time.seconds) ;
			swap4bytesStruct(&header->Chirp_Parameters.Doppler_Azimuth_Time.microseconds) ;
			swapFloat(&header->Chirp_Parameters.Pulse_Width) ;
			swapFloat(&header->Chirp_Parameters.Side_Lobe) ;
			swapFloat(&header->Chirp_Parameters.ISLR) ;
			swapFloat(&header->Chirp_Parameters.Peak_Location) ;
			swapFloat(&header->Chirp_Parameters.Chirp_Power) ;
			swapFloat(&header->Chirp_Parameters.Elevation_Gain) ;
			for (i = 0 ; i < 32 ; i++)
			{
				for(j = 0; j < 3; j++)
					swapFloat(&header->Chirp_Parameters.Calibration_Pulse[i].Max_Cal_Pulses[j]) ;
				for(j = 0; j < 3; j++)
					swapFloat(&header->Chirp_Parameters.Calibration_Pulse[i].Average_Cal_Pulse[j]) ;
				swapFloat(&header->Chirp_Parameters.Calibration_Pulse[i].Average_Cal_Pulse_1A) ;
				for(j = 0; j < 4; j++)
					swapFloat(&header->Chirp_Parameters.Calibration_Pulse[i].Extracted_Phase[j]) ;
			}
		}

	}

	free(Chirp_Parameters) ;
}



void readSlantToGroundRangeConversionGrid(ENVISAT_HEADER *header, FILE *f1)
{
	int indiceDSD, numberOfRecords, i, j ;
    SR_GR_CONVERSION_HEADER_CHAR	SR_GR_Conversion ;

    if (!isSLC(header)) {
        if((indiceDSD = getIndexOfDSD("SR GR ADS", header)) != -1) {
			if((numberOfRecords = getNumberOfRecordsForDSD("SR GR ADS", header))) {
				if((header->SR_GR_Conversion = (SR_GR_CONVERSION_HEADER *)malloc(numberOfRecords * sizeof(SR_GR_CONVERSION_HEADER))) != NULL) {
					for(j = 0; j < numberOfRecords; j++) {
						seekFileForDSD(f1, header, indiceDSD, j) ;
						fread ((SR_GR_CONVERSION_HEADER_CHAR *)&SR_GR_Conversion, sizeof(SR_GR_CONVERSION_HEADER_CHAR), 1, f1) ;

						memcpy (&header->SR_GR_Conversion[j].Doppler_Azimuth_Time.days, &SR_GR_Conversion.Doppler_Azimuth_Time[0], 4) ;
						memcpy (&header->SR_GR_Conversion[j].Doppler_Azimuth_Time.seconds, &SR_GR_Conversion.Doppler_Azimuth_Time[4], 4) ;
						memcpy (&header->SR_GR_Conversion[j].Doppler_Azimuth_Time.microseconds, &SR_GR_Conversion.Doppler_Azimuth_Time[8], 4) ;
						header->SR_GR_Conversion[j].Attachment = SR_GR_Conversion.Attachment ;
						memcpy (&header->SR_GR_Conversion[j].Slant_Range_Time, SR_GR_Conversion.Slant_Range_Time, 4) ;
						memcpy (&header->SR_GR_Conversion[j].Ground_Range_Origin, SR_GR_Conversion.Ground_Range_Origin, 4) ;
						for(i = 0; i < 5; i++)
							memcpy (&header->SR_GR_Conversion[j].Coefficient[i], &SR_GR_Conversion.Coefficient[4 * i], 4) ;
						strncpy (header->SR_GR_Conversion[j].Spare, SR_GR_Conversion.Spare, 14) ;
					}

					if(!isArchBigEndian()) {
						swap4bytesStruct(&header->SR_GR_Conversion[j].Doppler_Azimuth_Time.days) ;
						swap4bytesStruct(&header->SR_GR_Conversion[j].Doppler_Azimuth_Time.seconds) ;
						swap4bytesStruct(&header->SR_GR_Conversion[j].Doppler_Azimuth_Time.microseconds) ;
						swapFloat(&header->SR_GR_Conversion[j].Slant_Range_Time) ;
						swapFloat(&header->SR_GR_Conversion[j].Ground_Range_Origin) ;
						for(i = 0; i < 5; i++)
							swapFloat(&header->SR_GR_Conversion[j].Coefficient[i]) ;
					}

				}
			}
        }
    }
}



void readDopplerCentroidParametersRecord(ENVISAT_HEADER *header, FILE *f1)
{
	int	indiceDSD, i ;
    DCC_ADSR_HEADER_CHAR		*DCC_Header ;

    if((DCC_Header = (DCC_ADSR_HEADER_CHAR *)calloc (1, sizeof(DCC_ADSR_HEADER_CHAR))) == NULL)
		ase("Unable to allocate Summary Quality Record") ;

    if((indiceDSD = getIndexOfDSD("DOP CENTROID", header)) != -1) {
        seekFileForDSD(f1, header, indiceDSD, 0) ;
        fread ((DCC_ADSR_HEADER_CHAR *)DCC_Header, sizeof(DCC_ADSR_HEADER_CHAR), 1, f1) ;

        memcpy (&header->Doppler_Centroid_Param.Doppler_Azimuth_Time.days, &DCC_Header->Doppler_Azimuth_Time[0], 4) ;
		memcpy (&header->Doppler_Centroid_Param.Doppler_Azimuth_Time.seconds, &DCC_Header->Doppler_Azimuth_Time[4], 4) ;
		memcpy (&header->Doppler_Centroid_Param.Doppler_Azimuth_Time.microseconds, &DCC_Header->Doppler_Azimuth_Time[8], 4) ;
    	header->Doppler_Centroid_Param.Attachment = DCC_Header->Attachment ;
        memcpy (&header->Doppler_Centroid_Param.Slant_Range_Time, DCC_Header->Slant_Range_Time, 4) ;
/* !! Les trois premiers termes ci après sont repectivement a0FDC, a1FDC, a2FDC */
        for(i = 0; i < 5; i++)
            memcpy (&header->Doppler_Centroid_Param.Doppler_Centroid_Coef[i], &DCC_Header->Doppler_Centroid_Coef[4 * i], 4) ;
        memcpy (&header->Doppler_Centroid_Param.Doppler_Centroid_Confidence, DCC_Header->Doppler_Centroid_Confidence, 4) ;
        strncpy (header->Doppler_Centroid_Param.Spare, DCC_Header->Spare, 14) ;

		if(!isArchBigEndian()) {
			swap4bytesStruct(&header->Doppler_Centroid_Param.Doppler_Azimuth_Time.days) ;
	    	swap4bytesStruct(&header->Doppler_Centroid_Param.Doppler_Azimuth_Time.seconds) ;
	    	swap4bytesStruct(&header->Doppler_Centroid_Param.Doppler_Azimuth_Time.microseconds) ;
			swapFloat(&header->Doppler_Centroid_Param.Slant_Range_Time) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Doppler_Centroid_Param.Doppler_Centroid_Coef[i]) ;
			swapFloat(&header->Doppler_Centroid_Param.Doppler_Centroid_Confidence) ;
		}
    }
}



void readMainProcessParametersRecord(ENVISAT_HEADER *header, FILE *f1)
{
	int	indiceDSD, i ;
    MPP_ADSR_HEADER_CHAR *Main_Process ;

    if((Main_Process = (MPP_ADSR_HEADER_CHAR *)calloc (1, sizeof(MPP_ADSR_HEADER_CHAR))) == NULL)
		ase("Unable to allocate Summary Quality Record") ;

    if((indiceDSD = getIndexOfDSD("MAIN PROCESSING PARAMS ADS", header)) != -1) {
        seekFileForDSD(f1, header, indiceDSD, 0) ;
        fread ((MPP_ADSR_HEADER_CHAR *)Main_Process, sizeof(MPP_ADSR_HEADER_CHAR), 1, f1) ;

        memcpy (&header->Main_Process_Param.First_Azimuth_Time.days, &Main_Process->First_Azimuth_Time[0], 4) ;
        memcpy (&header->Main_Process_Param.First_Azimuth_Time.seconds, &Main_Process->First_Azimuth_Time[4], 4) ;
        memcpy (&header->Main_Process_Param.First_Azimuth_Time.microseconds, &Main_Process->First_Azimuth_Time[8], 4) ;
        header->Main_Process_Param.Attachment_Flag = Main_Process->Attachment_Flag ;
        memcpy (&header->Main_Process_Param.Last_Azimuth_Time.days, &Main_Process->Last_Azimuth_Time[0], 4) ;
        memcpy (&header->Main_Process_Param.Last_Azimuth_Time.seconds, &Main_Process->Last_Azimuth_Time[4], 4) ;
        memcpy (&header->Main_Process_Param.Last_Azimuth_Time.microseconds, &Main_Process->Last_Azimuth_Time[8], 4) ;
        strncpy (header->Main_Process_Param.Work_Order_Id, Main_Process->Work_Order_Id, 12) ;
        memcpy (&header->Main_Process_Param.Time_Difference, Main_Process->Time_Difference, 4) ;
        strncpy (header->Main_Process_Param.Swath_Number, Main_Process->Swath_Number, 3) ;

/* !! Dz */
        memcpy (&header->Main_Process_Param.Range_Sample_Spacing, Main_Process->Range_Sample_Spacing, 4) ;
        memcpy (&header->Main_Process_Param.Azimuth_Sample_Spacing, Main_Process->Azimuth_Sample_Spacing, 4) ;
        memcpy (&header->Main_Process_Param.Azimuth_Spacing_InTime, Main_Process->Azimuth_Spacing_InTime, 4) ;

/* !! lena */
        memcpy (&header->Main_Process_Param.Number_Output_Range, Main_Process->Number_Output_Range, 4) ;

/* !!  lenr */
        memcpy (&header->Main_Process_Param.Number_Samples, Main_Process->Number_Samples, 4) ;
        strncpy (header->Main_Process_Param.Output_Data_Type, Main_Process->Output_Data_Type, 5) ;
        strncpy (header->Main_Process_Param.Spare1, Main_Process->Spare1, 51) ;
        header->Main_Process_Param.Raw_Analysis = Main_Process->Raw_Analysis ;
        header->Main_Process_Param.Antenna_Elevation = Main_Process->Antenna_Elevation ;
        header->Main_Process_Param.Reconstructed_Chirp = Main_Process->Reconstructed_Chirp ;
        header->Main_Process_Param.Slant_Range_Conversion = Main_Process->Slant_Range_Conversion ;
        header->Main_Process_Param.Doppler_Centroid_Estimation = Main_Process->Doppler_Centroid_Estimation ;
        header->Main_Process_Param.Doppler_Ambiguity_Estimation = Main_Process->Doppler_Ambiguity_Estimation ;
        header->Main_Process_Param.Range_Spreading_Loss = Main_Process->Range_Spreading_Loss ;
        header->Main_Process_Param.Detection = Main_Process->Detection ;
        header->Main_Process_Param.Look_Sommation = Main_Process->Look_Sommation ;
        header->Main_Process_Param.RMS_Equalization = Main_Process->RMS_Equalization ;
        header->Main_Process_Param.Antenna_Gain = Main_Process->Antenna_Gain ;
        strncpy (header->Main_Process_Param.Spare2, Main_Process->Spare2, 10) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.Number_Input_Gaps, Main_Process->MDS1_Raw.Number_Input_Gaps, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.Number_Missing_Lines, Main_Process->MDS1_Raw.Number_Missing_Lines, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.Range_Sample, Main_Process->MDS1_Raw.Range_Sample, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.Range_Lines, Main_Process->MDS1_Raw.Range_Lines, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Channel_Bias, Main_Process->MDS1_Raw.I_Channel_Bias, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.Q_Channel_Bias, Main_Process->MDS1_Raw.Q_Channel_Bias, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Channel_Std_Deviation, Main_Process->MDS1_Raw.I_Channel_Std_Deviation, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.Q_Channel_Std_Deviation, Main_Process->MDS1_Raw.Q_Channel_Std_Deviation, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Q_Gain, Main_Process->MDS1_Raw.I_Q_Gain, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Q_Quadrature, Main_Process->MDS1_Raw.I_Q_Quadrature, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Bias_Upper, Main_Process->MDS1_Raw.I_Bias_Upper, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Bias_Lower, Main_Process->MDS1_Raw.I_Bias_Lower, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.Q_Bias_Upper, Main_Process->MDS1_Raw.Q_Bias_Upper, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.Q_Bias_Lower, Main_Process->MDS1_Raw.Q_Bias_Lower, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Q_Gain_Lower, Main_Process->MDS1_Raw.I_Q_Gain_Lower, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Q_Gain_Upper, Main_Process->MDS1_Raw.I_Q_Gain_Upper, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Q_Quadrature_Lower, Main_Process->MDS1_Raw.I_Q_Quadrature_Lower, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Q_Quadrature_Upper, Main_Process->MDS1_Raw.I_Q_Quadrature_Upper, 4) ;
        header->Main_Process_Param.MDS1_Raw.I_Bias_Significance = Main_Process->MDS1_Raw.I_Bias_Significance ;
        header->Main_Process_Param.MDS1_Raw.Q_Bias_Significance = Main_Process->MDS1_Raw.Q_Bias_Significance ;
        header->Main_Process_Param.MDS1_Raw.I_Q_Gain_Significance = Main_Process->MDS1_Raw.I_Q_Gain_Significance ;
        header->Main_Process_Param.MDS1_Raw.I_Q_Quadrature_Significance = Main_Process->MDS1_Raw.I_Q_Quadrature_Significance ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Channel_Correction, Main_Process->MDS1_Raw.I_Channel_Correction, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.Q_Channel_Correction, Main_Process->MDS1_Raw.Q_Channel_Correction, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Q_Gain_Correction, Main_Process->MDS1_Raw.I_Q_Gain_Correction, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Raw.I_Q_Quadrature_Correction, Main_Process->MDS1_Raw.I_Q_Quadrature_Correction, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.Number_Input_Gaps, Main_Process->MDS2_Raw.Number_Input_Gaps, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.Number_Missing_Lines, Main_Process->MDS2_Raw.Number_Missing_Lines, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.Range_Sample, Main_Process->MDS2_Raw.Range_Sample, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.Range_Lines, Main_Process->MDS2_Raw.Range_Lines, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Channel_Bias, Main_Process->MDS2_Raw.I_Channel_Bias, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.Q_Channel_Bias, Main_Process->MDS2_Raw.Q_Channel_Bias, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Channel_Std_Deviation, Main_Process->MDS2_Raw.I_Channel_Std_Deviation, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.Q_Channel_Std_Deviation, Main_Process->MDS2_Raw.Q_Channel_Std_Deviation, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Q_Gain, Main_Process->MDS2_Raw.I_Q_Gain, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Q_Quadrature, Main_Process->MDS2_Raw.I_Q_Quadrature, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Bias_Upper, Main_Process->MDS2_Raw.I_Bias_Upper, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Bias_Lower, Main_Process->MDS2_Raw.I_Bias_Lower, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.Q_Bias_Upper, Main_Process->MDS2_Raw.Q_Bias_Upper, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.Q_Bias_Lower, Main_Process->MDS2_Raw.Q_Bias_Lower, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Q_Gain_Lower, Main_Process->MDS2_Raw.I_Q_Gain_Lower, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Q_Gain_Upper, Main_Process->MDS2_Raw.I_Q_Gain_Upper, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Q_Quadrature_Lower, Main_Process->MDS2_Raw.I_Q_Quadrature_Lower, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Q_Quadrature_Upper, Main_Process->MDS2_Raw.I_Q_Quadrature_Upper, 4) ;
        header->Main_Process_Param.MDS2_Raw.I_Bias_Significance = Main_Process->MDS2_Raw.I_Bias_Significance ;
        header->Main_Process_Param.MDS2_Raw.Q_Bias_Significance = Main_Process->MDS2_Raw.Q_Bias_Significance ;
        header->Main_Process_Param.MDS2_Raw.I_Q_Gain_Significance = Main_Process->MDS2_Raw.I_Q_Gain_Significance ;
        header->Main_Process_Param.MDS2_Raw.I_Q_Quadrature_Significance = Main_Process->MDS2_Raw.I_Q_Quadrature_Significance ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Channel_Correction, Main_Process->MDS2_Raw.I_Channel_Correction, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.Q_Channel_Correction, Main_Process->MDS2_Raw.Q_Channel_Correction, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Q_Gain_Correction, Main_Process->MDS2_Raw.I_Q_Gain_Correction, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Raw.I_Q_Quadrature_Correction, Main_Process->MDS2_Raw.I_Q_Quadrature_Correction, 4) ;
        strncpy (header->Main_Process_Param.Spare3, Main_Process->Spare3, 32) ;
        memcpy (&header->Main_Process_Param.MDS1_Downlink.On_Board_Time[0], &Main_Process->MDS1_Downlink.On_Board_Time[0], 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Downlink.On_Board_Time[1], &Main_Process->MDS1_Downlink.On_Board_Time[4], 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Downlink.Sensing_Time.days, &Main_Process->MDS1_Downlink.Sensing_Time[0], 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Downlink.Sensing_Time.seconds, &Main_Process->MDS1_Downlink.Sensing_Time[4], 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Downlink.Sensing_Time.microseconds, &Main_Process->MDS1_Downlink.Sensing_Time[8], 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Downlink.On_Board_Time[0], &Main_Process->MDS2_Downlink.On_Board_Time[0], 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Downlink.On_Board_Time[1], &Main_Process->MDS2_Downlink.On_Board_Time[4], 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Downlink.Sensing_Time.days, &Main_Process->MDS2_Downlink.Sensing_Time[0], 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Downlink.Sensing_Time.seconds, &Main_Process->MDS2_Downlink.Sensing_Time[4], 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Downlink.Sensing_Time.microseconds, &Main_Process->MDS2_Downlink.Sensing_Time[8], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usStart_Time_First_Line[i], &Main_Process->usStart_Time_First_Line[2 * i], 2) ;

        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usStart_Time_Last_Line[i], &Main_Process->usStart_Time_Last_Line[2 * i], 2) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usPulse_Interval[i], &Main_Process->usPulse_Interval[2 * i], 2) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usTX_Pulse_Length[i], &Main_Process->usTX_Pulse_Length[2 * i], 2) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usTX_Pulse_Bandwidth[i], &Main_Process->usTX_Pulse_Bandwidth[2 * i], 2) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usEcho_Window[i], &Main_Process->usEcho_Window[2 * i], 2) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usUpconverter[i], &Main_Process->usUpconverter[2 * i], 2) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usDownconverter[i], &Main_Process->usDownconverter[2 * i], 2) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usResampling[i], &Main_Process->usResampling[2 * i], 2) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usBeam_Adjustment[i], &Main_Process->usBeam_Adjustment[2 *i], 2) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usAntenna_Beam[i], &Main_Process->usAntenna_Beam[2 * i], 2) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.usAuxiliary_Tx[i], &Main_Process->usAuxiliary_Tx[2 * i], 2) ;
        strncpy (header->Main_Process_Param.Spare4, Main_Process->Spare4, 60) ;

        memcpy (&header->Main_Process_Param.Sampling_Windows_Err, Main_Process->Sampling_Windows_Err, 4) ;
        memcpy (&header->Main_Process_Param.PRI_Code_Err, Main_Process->PRI_Code_Err, 4) ;
        memcpy (&header->Main_Process_Param.TX_Pulse_Length_Err, Main_Process->TX_Pulse_Length_Err, 4) ;
        memcpy (&header->Main_Process_Param.TX_Pulse_Bandwidth_Err, Main_Process->TX_Pulse_Bandwidth_Err, 4) ;
        memcpy (&header->Main_Process_Param.Echo_Window_Err, Main_Process->Echo_Window_Err, 4) ;
        memcpy (&header->Main_Process_Param.Upconverter_Err, Main_Process->Upconverter_Err, 4) ;
        memcpy (&header->Main_Process_Param.Downconverter_Err, Main_Process->Downconverter_Err, 4) ;
        memcpy (&header->Main_Process_Param.Resampling_Err, Main_Process->Resampling_Err, 4) ;
        memcpy (&header->Main_Process_Param.Beam_Adjustment_Err, Main_Process->Beam_Adjustment_Err, 4) ;
        memcpy (&header->Main_Process_Param.Antenna_Beam_Err, Main_Process->Antenna_Beam_Err, 4) ;
        strncpy (header->Main_Process_Param.Spare5, Main_Process->Spare5, 26) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.flStart_Time_First_Line[i], &Main_Process->flStart_Time_First_Line[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.flStart_Time_Last_Line[i], &Main_Process->flStart_Time_Last_Line[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.ulNumber_Sample_Window[i], &Main_Process->ulNumber_Sample_Window[4 * i], 4) ;
    /* !! PRF */
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.flPulse_Repetition_Frequency[i], &Main_Process->flPulse_Repetition_Frequency[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.flTX_Pulse_Length[i], &Main_Process->flTX_Pulse_Length[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.flTX_Pulse_Bandwidth[i], &Main_Process->flTX_Pulse_Bandwidth[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.flEcho_Window[i], &Main_Process->flEcho_Window[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.flUpconverter[i], &Main_Process->flUpconverter[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.flDownconverter[i], &Main_Process->flDownconverter[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.flResampling[i], &Main_Process->flResampling[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.flBeam_Adjustment[i], &Main_Process->flBeam_Adjustment[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.Antenna_Beam_Set[i], &Main_Process->Antenna_Beam_Set[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.flAuxiliary_Tx[i], &Main_Process->flAuxiliary_Tx[4 * i], 4) ;
        strncpy (header->Main_Process_Param.Spare6, Main_Process->Spare6, 82) ;
        memcpy (&header->Main_Process_Param.First_Sample, Main_Process->First_Sample, 4) ;
        memcpy (&header->Main_Process_Param.Range_Reference, Main_Process->Range_Reference, 4) ;
        memcpy (&header->Main_Process_Param.Range_Sampling_Rate, Main_Process->Range_Sampling_Rate, 4) ;

    /* !! nu */
        memcpy (&header->Main_Process_Param.Radar_Frequency, Main_Process->Radar_Frequency, 4) ;
        memcpy (&header->Main_Process_Param.Number_Range_Looks, Main_Process->Number_Range_Looks, 2) ;
        strncpy (header->Main_Process_Param.Filter_Window_Type, Main_Process->Filter_Window_Type, 7) ;
        memcpy (&header->Main_Process_Param.Window_Coefficient, Main_Process->Window_Coefficient, 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.Range_Look_Bandwidth[i], &Main_Process->Range_Look_Bandwidth[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.Total_Range_Bandwidth[i], &Main_Process->Total_Range_Bandwidth[4 * i], 4) ;
        for(i = 0; i < 4; i++)
            memcpy (&header->Main_Process_Param.SS1.Chirp_Amplitude_Coef[i], &Main_Process->SS1.Chirp_Amplitude_Coef[4 * i], 4) ;

        for(i = 0; i < 4; i++)
            memcpy (&header->Main_Process_Param.SS1.Chirp_Phase_Coef[i], &Main_Process->SS1.Chirp_Phase_Coef[4 * i], 4) ;
        for(i = 0; i < 4; i++)
            memcpy (&header->Main_Process_Param.SS2.Chirp_Amplitude_Coef[i], &Main_Process->SS2.Chirp_Amplitude_Coef[4 * i], 4) ;
        for(i = 0; i < 4; i++)
            memcpy (&header->Main_Process_Param.SS2.Chirp_Phase_Coef[i], &Main_Process->SS2.Chirp_Phase_Coef[4 * i], 4) ;
        for(i = 0; i < 4; i++)
            memcpy (&header->Main_Process_Param.SS3.Chirp_Amplitude_Coef[i], &Main_Process->SS3.Chirp_Amplitude_Coef[4 * i], 4) ;
        for(i = 0; i < 4; i++)
            memcpy (&header->Main_Process_Param.SS3.Chirp_Phase_Coef[i], &Main_Process->SS3.Chirp_Phase_Coef[4 * i], 4) ;
        for(i = 0; i < 4; i++)
            memcpy (&header->Main_Process_Param.SS4.Chirp_Amplitude_Coef[i], &Main_Process->SS4.Chirp_Amplitude_Coef[4 * i], 4) ;
        for(i = 0; i < 4; i++)
            memcpy (&header->Main_Process_Param.SS4.Chirp_Phase_Coef[i], &Main_Process->SS4.Chirp_Phase_Coef[4 * i], 4) ;
        for(i = 0; i < 4; i++)
            memcpy (&header->Main_Process_Param.SS5.Chirp_Amplitude_Coef[i], &Main_Process->SS5.Chirp_Amplitude_Coef[4 * i], 4) ;
        for(i = 0; i < 4; i++)
            memcpy (&header->Main_Process_Param.SS5.Chirp_Phase_Coef[i], &Main_Process->SS5.Chirp_Phase_Coef[4 * i], 4) ;
        strncpy (header->Main_Process_Param.Spare7, Main_Process->Spare7, 60) ;
        memcpy (&header->Main_Process_Param.Number_Input_Lines, Main_Process->Number_Input_Lines, 4) ;
        memcpy (&header->Main_Process_Param.Number_Azimuth_Looks, Main_Process->Number_Azimuth_Looks, 2) ;
        memcpy (&header->Main_Process_Param.Azimuth_Look_Bandwidth, Main_Process->Azimuth_Look_Bandwidth, 4) ;

    /* !! ABW */
        memcpy (&header->Main_Process_Param.Processed_Azimuth_Bandwidth, Main_Process->Processed_Azimuth_Bandwidth, 4) ;
        strncpy (header->Main_Process_Param.Matched_Filter_Type, Main_Process->Matched_Filter_Type, 7) ;
        memcpy (&header->Main_Process_Param.Window_Coef, Main_Process->Window_Coef, 4) ;
        for(i = 0; i < 3; i++)
            memcpy (&header->Main_Process_Param.Azimuth_FMRate[i], &Main_Process->Azimuth_FMRate[4 * i], 4) ;
        memcpy (&header->Main_Process_Param.Slant_Range_Time, Main_Process->Slant_Range_Time, 4) ;
        memcpy (&header->Main_Process_Param.Doppler_Measure, Main_Process->Doppler_Measure, 4) ;
        strncpy (header->Main_Process_Param.Spare8, Main_Process->Spare8, 68) ;
        memcpy (&header->Main_Process_Param.MDS1_Calibration.Processor_Scaling_Factor, Main_Process->MDS1_Calibration.Processor_Scaling_Factor, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Calibration.External_Scaling_Factor, Main_Process->MDS1_Calibration.External_Scaling_Factor, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Calibration.Processor_Scaling_Factor, Main_Process->MDS2_Calibration.Processor_Scaling_Factor, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Calibration.External_Scaling_Factor, Main_Process->MDS2_Calibration.External_Scaling_Factor, 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.Noise_Power[i], &Main_Process->Noise_Power[4 * i], 4) ;
        for(i = 0; i < 5; i++)
            memcpy (&header->Main_Process_Param.Noise_Lines[i], &Main_Process->Noise_Lines[4 * i], 4) ;
        strncpy (header->Main_Process_Param.Spare9, Main_Process->Spare9, 64) ;
        strncpy (header->Main_Process_Param.Spare10, Main_Process->Spare10, 12) ;
        memcpy (&header->Main_Process_Param.MDS1_Process.Real_Data_Mean, Main_Process->MDS1_Process.Real_Data_Mean, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Process.Imaginary_Data_Mean, Main_Process->MDS1_Process.Imaginary_Data_Mean, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Process.Real_Std_Deviation, Main_Process->MDS1_Process.Real_Std_Deviation, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Process.Imaginary_Std_Deviation, Main_Process->MDS1_Process.Imaginary_Std_Deviation, 4) ;
        memcpy (&header->Main_Process_Param.MDS2_Process.Real_Data_Mean, Main_Process->MDS2_Process.Real_Data_Mean, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Process.Imaginary_Data_Mean, Main_Process->MDS2_Process.Imaginary_Data_Mean, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Process.Real_Std_Deviation, Main_Process->MDS2_Process.Real_Std_Deviation, 4) ;
        memcpy (&header->Main_Process_Param.MDS1_Process.Imaginary_Std_Deviation, Main_Process->MDS2_Process.Imaginary_Std_Deviation, 4) ;
        strncpy (header->Main_Process_Param.Spare11, Main_Process->Spare11, 52) ;
        strncpy (header->Main_Process_Param.Compres_Method_Echo, Main_Process->Compres_Method_Echo, 4) ;
        strncpy (header->Main_Process_Param.Compres_Ratio_Echo, Main_Process->Compres_Ratio_Echo, 3) ;
        strncpy (header->Main_Process_Param.Compres_Method_Init_Calib, Main_Process->Compres_Method_Init_Calib, 4) ;
        strncpy (header->Main_Process_Param.Compres_Ratio_Init_Calib, Main_Process->Compres_Ratio_Init_Calib, 3) ;
        strncpy (header->Main_Process_Param.Compres_Method_Period_Calib, Main_Process->Compres_Method_Period_Calib, 4 ) ;
        strncpy (header->Main_Process_Param.Compres_Ratio_Period_Calib, Main_Process->Compres_Ratio_Period_Calib, 3) ;
        strncpy (header->Main_Process_Param.Compres_Method_Noise, Main_Process->Compres_Method_Noise, 4) ;
        strncpy (header->Main_Process_Param.Compres_Ratio_Noise, Main_Process->Compres_Ratio_Noise, 3) ;
        strncpy (header->Main_Process_Param.Spare12, Main_Process->Spare12, 64) ;
        for(i = 0; i < 4 ; i++)
            memcpy (&header->Main_Process_Param.Number_Slant_Range[i], &Main_Process->Number_Slant_Range[4 * i], 4) ;
        for(i = 0; i < 5 ; i++)
            memcpy (&header->Main_Process_Param.Number_Lines_Burst[i], &Main_Process->Number_Lines_Burst[4 * i], 4) ;
        strncpy (header->Main_Process_Param.Spare13, Main_Process->Spare13, 44) ;

    /* !! */
        for (i = 0 ; i < 5 ; i++)
        {
            memcpy (&header->Main_Process_Param.Orbit_State[i].Time_State_Vector.days, &Main_Process->Orbit_State[i].Time_State_Vector[0], 4) ;
    /* !! Day et seconds déterminent le FVT. Attention, a priori, le Dt entre les vecteurs d'état n'est pas necessairement constant. Il faut donc modifier l'interpolation des vecteur d'état en conséquence dans coprede7.c. La coordonnée temporelle des vecteurs d'état dans les images SLC est calculée a partir du Dt1 (ou du Dt2) : (i-1) * Dt1. Dans le cas des données ENVISAT, cette valeur doit être remplacée par celle qui est directement lue ici, de laquelle il faut encore soustraire  FVT1 pour être compatible avec coprede7.c*/
            memcpy (&header->Main_Process_Param.Orbit_State[i].Time_State_Vector.seconds, &Main_Process->Orbit_State[i].Time_State_Vector[4], 4) ;
            memcpy (&header->Main_Process_Param.Orbit_State[i].Time_State_Vector.microseconds, &Main_Process->Orbit_State[i].Time_State_Vector[8], 4) ;
            memcpy (&header->Main_Process_Param.Orbit_State[i].X_Position_Earth, Main_Process->Orbit_State[i].X_Position_Earth, 4) ;
            memcpy (&header->Main_Process_Param.Orbit_State[i].Y_Position_Earth, Main_Process->Orbit_State[i].Y_Position_Earth, 4) ;
            memcpy (&header->Main_Process_Param.Orbit_State[i].Z_Position_Earth, Main_Process->Orbit_State[i].Z_Position_Earth, 4) ;
            memcpy (&header->Main_Process_Param.Orbit_State[i].X_Velocity_Earth, Main_Process->Orbit_State[i].X_Velocity_Earth, 4) ;
            memcpy (&header->Main_Process_Param.Orbit_State[i].Y_Velocity_Earth, Main_Process->Orbit_State[i].Y_Velocity_Earth, 4) ;
            memcpy (&header->Main_Process_Param.Orbit_State[i].Z_Velocity_Earth, Main_Process->Orbit_State[i].Z_Velocity_Earth, 4) ;
        }
        strncpy (header->Main_Process_Param.Spare14, Main_Process->Spare14, 64) ;

		if(!isArchBigEndian()) {
			swap4bytesStruct(&header->Main_Process_Param.First_Azimuth_Time.days) ;
			swap4bytesStruct(&header->Main_Process_Param.First_Azimuth_Time.seconds) ;
			swap4bytesStruct(&header->Main_Process_Param.First_Azimuth_Time.microseconds) ;
			swap4bytesStruct(&header->Main_Process_Param.Last_Azimuth_Time.days) ;
			swap4bytesStruct(&header->Main_Process_Param.Last_Azimuth_Time.seconds) ;
			swap4bytesStruct(&header->Main_Process_Param.Last_Azimuth_Time.microseconds) ;
			swapFloat(&header->Main_Process_Param.Time_Difference) ;

			/* !! Dz */
			swapFloat(&header->Main_Process_Param.Range_Sample_Spacing) ;
			swapFloat(&header->Main_Process_Param.Azimuth_Sample_Spacing) ;
			swapFloat(&header->Main_Process_Param.Azimuth_Spacing_InTime) ;

			/* !! lena */
			swap4bytesStruct(&header->Main_Process_Param.Number_Output_Range) ;

			/* !!  lenr */
			swap4bytesStruct(&header->Main_Process_Param.Number_Samples) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS1_Raw.Number_Input_Gaps) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS1_Raw.Number_Missing_Lines) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS1_Raw.Range_Sample) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS1_Raw.Range_Lines) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Channel_Bias) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.Q_Channel_Bias) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Channel_Std_Deviation) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.Q_Channel_Std_Deviation) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Q_Gain) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Q_Quadrature) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Bias_Upper) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Bias_Lower) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.Q_Bias_Upper) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.Q_Bias_Lower) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Q_Gain_Lower) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Q_Gain_Upper) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Q_Quadrature_Lower) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Q_Quadrature_Upper) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Channel_Correction) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.Q_Channel_Correction) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Q_Gain_Correction) ;
			swapFloat(&header->Main_Process_Param.MDS1_Raw.I_Q_Quadrature_Correction) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS2_Raw.Number_Input_Gaps) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS2_Raw.Number_Missing_Lines) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS2_Raw.Range_Sample) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS2_Raw.Range_Lines) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Channel_Bias) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.Q_Channel_Bias) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Channel_Std_Deviation) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.Q_Channel_Std_Deviation) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Q_Gain) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Q_Quadrature) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Bias_Upper) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Bias_Lower) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.Q_Bias_Upper) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.Q_Bias_Lower) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Q_Gain_Lower) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Q_Gain_Upper) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Q_Quadrature_Lower) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Q_Quadrature_Upper) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Channel_Correction) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.Q_Channel_Correction) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Q_Gain_Correction) ;
			swapFloat(&header->Main_Process_Param.MDS2_Raw.I_Q_Quadrature_Correction) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS1_Downlink.On_Board_Time[0]) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS1_Downlink.On_Board_Time[1]) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS1_Downlink.Sensing_Time.days) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS1_Downlink.Sensing_Time.seconds) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS1_Downlink.Sensing_Time.microseconds) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS2_Downlink.On_Board_Time[0]) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS2_Downlink.On_Board_Time[1]) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS2_Downlink.Sensing_Time.days) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS2_Downlink.Sensing_Time.seconds) ;
			swap4bytesStruct(&header->Main_Process_Param.MDS2_Downlink.Sensing_Time.microseconds) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usStart_Time_First_Line[i]) ;

			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usStart_Time_Last_Line[i]) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usPulse_Interval[i]) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usTX_Pulse_Length[i]) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usTX_Pulse_Bandwidth[i]) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usEcho_Window[i]) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usUpconverter[i]) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usDownconverter[i]) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usResampling[i]) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usBeam_Adjustment[i]) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usAntenna_Beam[i]) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.usAuxiliary_Tx[i]) ;

			swap4bytesStruct(&header->Main_Process_Param.Sampling_Windows_Err) ;
			swap4bytesStruct(&header->Main_Process_Param.PRI_Code_Err) ;
			swap4bytesStruct(&header->Main_Process_Param.TX_Pulse_Length_Err) ;
			swap4bytesStruct(&header->Main_Process_Param.TX_Pulse_Bandwidth_Err) ;
			swap4bytesStruct(&header->Main_Process_Param.Echo_Window_Err) ;
			swap4bytesStruct(&header->Main_Process_Param.Upconverter_Err) ;
			swap4bytesStruct(&header->Main_Process_Param.Downconverter_Err) ;
			swap4bytesStruct(&header->Main_Process_Param.Resampling_Err) ;
			swap4bytesStruct(&header->Main_Process_Param.Beam_Adjustment_Err) ;
			swap4bytesStruct(&header->Main_Process_Param.Antenna_Beam_Err) ;

			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.flStart_Time_First_Line[i]) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.flStart_Time_Last_Line[i]) ;
			for(i = 0; i < 5; i++)
				swap4bytesStruct(&header->Main_Process_Param.ulNumber_Sample_Window[i]) ;
			/* !! PRF */
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.flPulse_Repetition_Frequency[i]) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.flTX_Pulse_Length[i]) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.flTX_Pulse_Bandwidth[i]) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.flEcho_Window[i]) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.flUpconverter[i]) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.flDownconverter[i]) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.flResampling[i]) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.flBeam_Adjustment[i]) ;
			for(i = 0; i < 5; i++)
				swap2bytesStruct(&header->Main_Process_Param.Antenna_Beam_Set[i]) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.flAuxiliary_Tx[i]) ;

			swap4bytesStruct(&header->Main_Process_Param.First_Sample) ;
			swapFloat(&header->Main_Process_Param.Range_Reference) ;
			swapFloat(&header->Main_Process_Param.Range_Sampling_Rate) ;

			/* !! nu */
			swapFloat(&header->Main_Process_Param.Radar_Frequency) ;
			swap2bytesStruct(&header->Main_Process_Param.Number_Range_Looks) ;
			swapFloat(&header->Main_Process_Param.Window_Coefficient) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.Range_Look_Bandwidth[i]) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.Total_Range_Bandwidth[i]) ;
			for(i = 0; i < 4; i++)
				swapFloat(&header->Main_Process_Param.SS1.Chirp_Amplitude_Coef[i]) ;

			for(i = 0; i < 4; i++)
				swapFloat(&header->Main_Process_Param.SS1.Chirp_Phase_Coef[i]) ;
			for(i = 0; i < 4; i++)
				swapFloat(&header->Main_Process_Param.SS2.Chirp_Amplitude_Coef[i]) ;
			for(i = 0; i < 4; i++)
				swapFloat(&header->Main_Process_Param.SS2.Chirp_Phase_Coef[i]) ;
			for(i = 0; i < 4; i++)
				swapFloat(&header->Main_Process_Param.SS3.Chirp_Amplitude_Coef[i]) ;
			for(i = 0; i < 4; i++)
				swapFloat(&header->Main_Process_Param.SS3.Chirp_Phase_Coef[i]) ;
			for(i = 0; i < 4; i++)
				swapFloat(&header->Main_Process_Param.SS4.Chirp_Amplitude_Coef[i]) ;
			for(i = 0; i < 4; i++)
				swapFloat(&header->Main_Process_Param.SS4.Chirp_Phase_Coef[i]) ;
			for(i = 0; i < 4; i++)
				swapFloat(&header->Main_Process_Param.SS5.Chirp_Amplitude_Coef[i]) ;
			for(i = 0; i < 4; i++)
				swapFloat(&header->Main_Process_Param.SS5.Chirp_Phase_Coef[i]) ;

			swap4bytesStruct(&header->Main_Process_Param.Number_Input_Lines) ;
			swap2bytesStruct(&header->Main_Process_Param.Number_Azimuth_Looks) ;
			swapFloat(&header->Main_Process_Param.Azimuth_Look_Bandwidth) ;

			/* !! ABW */
			swapFloat(&header->Main_Process_Param.Processed_Azimuth_Bandwidth) ;
			swapFloat(&header->Main_Process_Param.Window_Coef) ;
			for(i = 0; i < 3; i++)
				swapFloat(&header->Main_Process_Param.Azimuth_FMRate[i]) ;

			swapFloat(&header->Main_Process_Param.Slant_Range_Time) ;
			swapFloat(&header->Main_Process_Param.Doppler_Measure) ;
			swapFloat(&header->Main_Process_Param.MDS1_Calibration.Processor_Scaling_Factor) ;
			swapFloat(&header->Main_Process_Param.MDS1_Calibration.External_Scaling_Factor) ;
			swapFloat(&header->Main_Process_Param.MDS2_Calibration.Processor_Scaling_Factor) ;
			swapFloat(&header->Main_Process_Param.MDS2_Calibration.External_Scaling_Factor) ;
			for(i = 0; i < 5; i++)
				swapFloat(&header->Main_Process_Param.Noise_Power[i]) ;
			for(i = 0; i < 5; i++)
				swap4bytesStruct(&header->Main_Process_Param.Noise_Lines[i]) ;

			swapFloat(&header->Main_Process_Param.MDS1_Process.Real_Data_Mean) ;
			swapFloat(&header->Main_Process_Param.MDS1_Process.Imaginary_Data_Mean) ;
			swapFloat(&header->Main_Process_Param.MDS1_Process.Real_Std_Deviation) ;
			swapFloat(&header->Main_Process_Param.MDS1_Process.Imaginary_Std_Deviation) ;
			swapFloat(&header->Main_Process_Param.MDS2_Process.Real_Data_Mean) ;
			swapFloat(&header->Main_Process_Param.MDS1_Process.Imaginary_Data_Mean) ;
			swapFloat(&header->Main_Process_Param.MDS1_Process.Real_Std_Deviation) ;
			swapFloat(&header->Main_Process_Param.MDS1_Process.Imaginary_Std_Deviation) ;
			for(i = 0; i < 4 ; i++)
				swap4bytesStruct(&header->Main_Process_Param.Number_Slant_Range[i]) ;
			for(i = 0; i < 5 ; i++)
				swap4bytesStruct(&header->Main_Process_Param.Number_Lines_Burst[i]) ;

			for (i = 0 ; i < 5 ; i++)
			{
				swap4bytesStruct(&header->Main_Process_Param.Orbit_State[i].Time_State_Vector.days) ;
				swap4bytesStruct(&header->Main_Process_Param.Orbit_State[i].Time_State_Vector.seconds) ;
				swap4bytesStruct(&header->Main_Process_Param.Orbit_State[i].Time_State_Vector.microseconds) ;
				swap4bytesStruct(&header->Main_Process_Param.Orbit_State[i].X_Position_Earth) ;
				swap4bytesStruct(&header->Main_Process_Param.Orbit_State[i].Y_Position_Earth) ;
				swap4bytesStruct(&header->Main_Process_Param.Orbit_State[i].Z_Position_Earth) ;
				swap4bytesStruct(&header->Main_Process_Param.Orbit_State[i].X_Velocity_Earth) ;
				swap4bytesStruct(&header->Main_Process_Param.Orbit_State[i].Y_Velocity_Earth) ;
				swap4bytesStruct(&header->Main_Process_Param.Orbit_State[i].Z_Velocity_Earth) ;
			}
		}
	}
}



void readSummaryQualityRecord(ENVISAT_HEADER *header, FILE *f1)
{
	int	indiceDSD ;
    SQ_ADSR_HEADER_CHAR	*SQ_MDS1 ;

    if((SQ_MDS1 = (SQ_ADSR_HEADER_CHAR *)calloc (1, sizeof(SQ_ADSR_HEADER_CHAR))) == NULL)
		ase("Unable to allocate Summary Quality Record") ;

    if((indiceDSD = getIndexOfDSD("MDS1 SQ ADS", header)) != -1) {
        seekFileForDSD(f1, header, indiceDSD, 0) ;
        fread ((SQ_ADSR_HEADER_CHAR *)SQ_MDS1, sizeof(SQ_ADSR_HEADER_CHAR), 1, f1) ;

        memcpy (&header->SQ_MDS1.Zero_Doppler_Time.days, &SQ_MDS1->Zero_Doppler_Time[0], 4) ;
        memcpy (&header->SQ_MDS1.Zero_Doppler_Time.seconds, &SQ_MDS1->Zero_Doppler_Time[4], 4) ;
        memcpy (&header->SQ_MDS1.Zero_Doppler_Time.microseconds, &SQ_MDS1->Zero_Doppler_Time[8], 4) ;
        header->SQ_MDS1.Attachment_Flag = SQ_MDS1->Attachment_Flag ;
        header->SQ_MDS1.Input_Mean_Flag = SQ_MDS1->Input_Mean_Flag ;
        header->SQ_MDS1.Input_Standard_Deviation_Flag = SQ_MDS1->Input_Standard_Deviation_Flag ;
        header->SQ_MDS1.Significant_Gaps_Flag = SQ_MDS1->Significant_Gaps_Flag ;
        header->SQ_MDS1.Missing_Lines_Flag = SQ_MDS1->Missing_Lines_Flag ;
        header->SQ_MDS1.Doppler_Centroid_Flag = SQ_MDS1->Doppler_Centroid_Flag ;
        header->SQ_MDS1.Doppler_Ambiguity_Flag = SQ_MDS1->Doppler_Ambiguity_Flag ;
        header->SQ_MDS1.Output_Mean_Flag = SQ_MDS1->Output_Mean_Flag ;
        header->SQ_MDS1.Output_Standard_Flag = SQ_MDS1->Output_Standard_Flag ;
        header->SQ_MDS1.Chirp_Flag = SQ_MDS1->Chirp_Flag ;
        header->SQ_MDS1.Data_Missing_Flag = SQ_MDS1->Data_Missing_Flag ;
        header->SQ_MDS1.Invalid_Downlink_Flag = SQ_MDS1->Invalid_Downlink_Flag ;
        strncpy (header->SQ_MDS1.Spare1, SQ_MDS1->Spare1, 7) ;
        memcpy (&header->SQ_MDS1.Max_Percent_Chirp, SQ_MDS1->Max_Percent_Chirp, 4) ;
        memcpy (&header->SQ_MDS1.First_Sidelobe_Chirp, SQ_MDS1->First_Sidelobe_Chirp, 4) ;
        memcpy (&header->SQ_MDS1.ISLR_Chirp, SQ_MDS1->ISLR_Chirp, 4) ;
        memcpy (&header->SQ_MDS1.Mean_Input_Quality, SQ_MDS1->Mean_Input_Quality, 4) ;
        memcpy (&header->SQ_MDS1.Mean_Input_Value, SQ_MDS1->Mean_Input_Value, 4) ;
        memcpy (&header->SQ_MDS1.Standard_Deviation_Quality, SQ_MDS1->Standard_Deviation_Quality, 4) ;
        memcpy (&header->SQ_MDS1.Input_Standard_Deviation, SQ_MDS1->Input_Standard_Deviation, 4) ;
        memcpy (&header->SQ_MDS1.Doppler_Confidence, SQ_MDS1->Doppler_Confidence, 4) ;
        memcpy (&header->SQ_MDS1.Doppler_Quality, SQ_MDS1->Doppler_Quality, 4) ;
        memcpy (&header->SQ_MDS1.Mean_Output_Quality, SQ_MDS1->Mean_Output_Quality, 4) ;
        memcpy (&header->SQ_MDS1.Mean_Output_Value, SQ_MDS1->Mean_Output_Value, 4) ;
        memcpy (&header->SQ_MDS1.Standard_Deviation_Output, SQ_MDS1->Standard_Deviation_Output, 4) ;
        memcpy (&header->SQ_MDS1.Output_Standard_Deviation, SQ_MDS1->Output_Standard_Deviation, 4) ;
        memcpy (&header->SQ_MDS1.Max_Missing_Lines, SQ_MDS1->Max_Missing_Lines, 4) ;
        memcpy (&header->SQ_MDS1.Max_Missing_Gaps, SQ_MDS1->Max_Missing_Gaps, 4) ;
        memcpy (&header->SQ_MDS1.Number_Missing_Lines, SQ_MDS1->Number_Missing_Lines, 4) ;
        strncpy (header->SQ_MDS1.Spare2, SQ_MDS1->Spare2, 15) ;
        memcpy (&header->SQ_MDS1.Input_Data_Mean.r, SQ_MDS1->Input_Data_Mean.r, 4) ;
        memcpy (&header->SQ_MDS1.Input_Data_Mean.i, SQ_MDS1->Input_Data_Mean.i, 4) ;
        memcpy (&header->SQ_MDS1.Input_Data_Standard_Deviation.r, SQ_MDS1->Input_Data_Standard_Deviation.r, 4) ;
        memcpy (&header->SQ_MDS1.Input_Data_Standard_Deviation.i, SQ_MDS1->Input_Data_Standard_Deviation.i, 4) ;
        memcpy (&header->SQ_MDS1.Number_Gaps, SQ_MDS1->Number_Gaps, 4) ;
        memcpy (&header->SQ_MDS1.Number_Lines_Excluding_Gaps, SQ_MDS1->Number_Lines_Excluding_Gaps, 4) ;
        memcpy (&header->SQ_MDS1.Output_Data_Mean.r, SQ_MDS1->Output_Data_Mean.r, 4) ;
        memcpy (&header->SQ_MDS1.Output_Data_Mean.i, SQ_MDS1->Output_Data_Mean.i, 4) ;
        memcpy (&header->SQ_MDS1.Output_Data_Standard_Deviation.r, SQ_MDS1->Output_Data_Standard_Deviation.r, 4) ;
        memcpy (&header->SQ_MDS1.Output_Data_Standard_Deviation.i, SQ_MDS1->Output_Data_Standard_Deviation.i, 4) ;
        memcpy (&header->SQ_MDS1.Number_Errors, SQ_MDS1->Number_Errors, 4) ;
        strncpy (header->SQ_MDS1.Spare3, SQ_MDS1->Spare3, 16) ;

		if(!isArchBigEndian()) {
			swap4bytesStruct(&header->SQ_MDS1.Zero_Doppler_Time.days) ;
			swap4bytesStruct(&header->SQ_MDS1.Zero_Doppler_Time.seconds) ;
			swap4bytesStruct(&header->SQ_MDS1.Zero_Doppler_Time.microseconds) ;
			swapFloat(&header->SQ_MDS1.Max_Percent_Chirp) ;
			swapFloat(&header->SQ_MDS1.First_Sidelobe_Chirp) ;
			swapFloat(&header->SQ_MDS1.ISLR_Chirp) ;
			swapFloat(&header->SQ_MDS1.Mean_Input_Quality) ;
			swapFloat(&header->SQ_MDS1.Mean_Input_Value) ;
			swapFloat(&header->SQ_MDS1.Standard_Deviation_Quality) ;
			swapFloat(&header->SQ_MDS1.Input_Standard_Deviation) ;
			swapFloat(&header->SQ_MDS1.Doppler_Confidence) ;
			swapFloat(&header->SQ_MDS1.Doppler_Quality) ;
			swapFloat(&header->SQ_MDS1.Mean_Output_Quality) ;
			swapFloat(&header->SQ_MDS1.Mean_Output_Value) ;
			swapFloat(&header->SQ_MDS1.Standard_Deviation_Output) ;
			swapFloat(&header->SQ_MDS1.Output_Standard_Deviation) ;
			swapFloat(&header->SQ_MDS1.Max_Missing_Lines) ;
			swapFloat(&header->SQ_MDS1.Max_Missing_Gaps) ;
			swap4bytesStruct(&header->SQ_MDS1.Number_Missing_Lines) ;
			swapFloat(&header->SQ_MDS1.Input_Data_Mean.r) ;
			swapFloat(&header->SQ_MDS1.Input_Data_Mean.i) ;
			swapFloat(&header->SQ_MDS1.Input_Data_Standard_Deviation.r) ;
			swapFloat(&header->SQ_MDS1.Input_Data_Standard_Deviation.i) ;
			swapFloat(&header->SQ_MDS1.Number_Gaps) ;
			swapFloat(&header->SQ_MDS1.Number_Lines_Excluding_Gaps) ;
			swapFloat(&header->SQ_MDS1.Output_Data_Mean.r) ;
			swapFloat(&header->SQ_MDS1.Output_Data_Mean.i) ;
			swapFloat(&header->SQ_MDS1.Output_Data_Standard_Deviation.r) ;
			swapFloat(&header->SQ_MDS1.Output_Data_Standard_Deviation.i) ;
			swap4bytesStruct(&header->SQ_MDS1.Number_Errors) ;
		}
	}

    if(isAP(header)) {
		if((indiceDSD = getIndexOfDSD("MDS2 SQ ADS", header)) != -1) {
			seekFileForDSD(f1, header, indiceDSD, 0) ;
			fread ((SQ_ADSR_HEADER_CHAR *)SQ_MDS1, sizeof(SQ_ADSR_HEADER_CHAR), 1, f1) ;

            memcpy (&header->SQ_MDS2.Zero_Doppler_Time.days, &SQ_MDS1->Zero_Doppler_Time[0], 4) ;
			memcpy (&header->SQ_MDS2.Zero_Doppler_Time.seconds, &SQ_MDS1->Zero_Doppler_Time[4], 4) ;
            memcpy (&header->SQ_MDS2.Zero_Doppler_Time.microseconds, &SQ_MDS1->Zero_Doppler_Time[8], 4) ;
            header->SQ_MDS2.Attachment_Flag = SQ_MDS1->Attachment_Flag ;
            header->SQ_MDS2.Input_Mean_Flag = SQ_MDS1->Input_Mean_Flag ;
            header->SQ_MDS2.Input_Standard_Deviation_Flag = SQ_MDS1->Input_Standard_Deviation_Flag ;
            header->SQ_MDS2.Significant_Gaps_Flag = SQ_MDS1->Significant_Gaps_Flag ;
            header->SQ_MDS2.Missing_Lines_Flag = SQ_MDS1->Missing_Lines_Flag ;
            header->SQ_MDS2.Doppler_Centroid_Flag = SQ_MDS1->Doppler_Centroid_Flag ;
            header->SQ_MDS2.Doppler_Ambiguity_Flag = SQ_MDS1->Doppler_Ambiguity_Flag ;
            header->SQ_MDS2.Output_Mean_Flag = SQ_MDS1->Output_Mean_Flag ;
            header->SQ_MDS2.Output_Standard_Flag = SQ_MDS1->Output_Standard_Flag ;
            header->SQ_MDS2.Chirp_Flag = SQ_MDS1->Chirp_Flag ;
            header->SQ_MDS2.Data_Missing_Flag = SQ_MDS1->Data_Missing_Flag ;
            header->SQ_MDS2.Invalid_Downlink_Flag = SQ_MDS1->Invalid_Downlink_Flag ;
            strncpy (header->SQ_MDS2.Spare1, SQ_MDS1->Spare1, 7) ;
            memcpy (&header->SQ_MDS2.Max_Percent_Chirp, SQ_MDS1->Max_Percent_Chirp, 4) ;
            memcpy (&header->SQ_MDS2.First_Sidelobe_Chirp, SQ_MDS1->First_Sidelobe_Chirp, 4) ;
            memcpy (&header->SQ_MDS2.ISLR_Chirp, SQ_MDS1->ISLR_Chirp, 4) ;
            memcpy (&header->SQ_MDS2.Mean_Input_Quality, SQ_MDS1->Mean_Input_Quality, 4) ;
            memcpy (&header->SQ_MDS2.Mean_Input_Value, SQ_MDS1->Mean_Input_Value, 4) ;
            memcpy (&header->SQ_MDS2.Standard_Deviation_Quality, SQ_MDS1->Standard_Deviation_Quality, 4) ;
            memcpy (&header->SQ_MDS2.Input_Standard_Deviation, SQ_MDS1->Input_Standard_Deviation, 4) ;
            memcpy (&header->SQ_MDS2.Doppler_Confidence, SQ_MDS1->Doppler_Confidence, 4) ;
            memcpy (&header->SQ_MDS2.Doppler_Quality, SQ_MDS1->Doppler_Quality, 4) ;
            memcpy (&header->SQ_MDS2.Mean_Output_Quality, SQ_MDS1->Mean_Output_Quality, 4) ;
            memcpy (&header->SQ_MDS2.Mean_Output_Value, SQ_MDS1->Mean_Output_Value, 4) ;
            memcpy (&header->SQ_MDS2.Standard_Deviation_Output, SQ_MDS1->Standard_Deviation_Output, 4) ;
            memcpy (&header->SQ_MDS2.Output_Standard_Deviation, SQ_MDS1->Output_Standard_Deviation, 4) ;
            memcpy (&header->SQ_MDS2.Max_Missing_Lines, SQ_MDS1->Max_Missing_Lines, 4) ;
            memcpy (&header->SQ_MDS2.Max_Missing_Gaps, SQ_MDS1->Max_Missing_Gaps, 4) ;
            memcpy (&header->SQ_MDS2.Number_Missing_Lines, SQ_MDS1->Number_Missing_Lines, 4) ;
            strncpy (header->SQ_MDS2.Spare2, SQ_MDS1->Spare2, 15) ;
            memcpy (&header->SQ_MDS2.Input_Data_Mean.r, SQ_MDS1->Input_Data_Mean.r, 4) ;
            memcpy (&header->SQ_MDS2.Input_Data_Mean.i, SQ_MDS1->Input_Data_Mean.i, 4) ;
            memcpy (&header->SQ_MDS2.Input_Data_Standard_Deviation.r, SQ_MDS1->Input_Data_Standard_Deviation.r, 4) ;
            memcpy (&header->SQ_MDS2.Input_Data_Standard_Deviation.i, SQ_MDS1->Input_Data_Standard_Deviation.i, 4) ;
            memcpy (&header->SQ_MDS2.Number_Gaps, SQ_MDS1->Number_Gaps, 4) ;
            memcpy (&header->SQ_MDS2.Number_Lines_Excluding_Gaps, SQ_MDS1->Number_Lines_Excluding_Gaps, 4) ;
            memcpy (&header->SQ_MDS2.Output_Data_Mean.r, SQ_MDS1->Output_Data_Mean.r, 4) ;
            memcpy (&header->SQ_MDS2.Output_Data_Mean.i, SQ_MDS1->Output_Data_Mean.i, 4) ;
            memcpy (&header->SQ_MDS2.Output_Data_Standard_Deviation.r, SQ_MDS1->Output_Data_Standard_Deviation.r, 4) ;
            memcpy (&header->SQ_MDS2.Output_Data_Standard_Deviation.i, SQ_MDS1->Output_Data_Standard_Deviation.i, 4) ;
            memcpy (&header->SQ_MDS2.Number_Errors, SQ_MDS1->Number_Errors, 4) ;
            strncpy (header->SQ_MDS2.Spare3, SQ_MDS1->Spare3, 16) ;
        }
		if(!isArchBigEndian()) {
			swap4bytesStruct(&header->SQ_MDS2.Zero_Doppler_Time.days) ;
			swap4bytesStruct(&header->SQ_MDS2.Zero_Doppler_Time.seconds) ;
            swap4bytesStruct(&header->SQ_MDS2.Zero_Doppler_Time.microseconds) ;
            swapFloat(&header->SQ_MDS2.Max_Percent_Chirp) ;
            swapFloat(&header->SQ_MDS2.First_Sidelobe_Chirp) ;
            swapFloat(&header->SQ_MDS2.ISLR_Chirp) ;
            swapFloat(&header->SQ_MDS2.Mean_Input_Quality) ;
            swapFloat(&header->SQ_MDS2.Mean_Input_Value) ;
            swapFloat(&header->SQ_MDS2.Standard_Deviation_Quality) ;
            swapFloat(&header->SQ_MDS2.Input_Standard_Deviation) ;
            swapFloat(&header->SQ_MDS2.Doppler_Confidence) ;
            swapFloat(&header->SQ_MDS2.Doppler_Quality) ;
            swapFloat(&header->SQ_MDS2.Mean_Output_Quality) ;
            swapFloat(&header->SQ_MDS2.Mean_Output_Value) ;
            swapFloat(&header->SQ_MDS2.Standard_Deviation_Output) ;
            swapFloat(&header->SQ_MDS2.Output_Standard_Deviation) ;
            swapFloat(&header->SQ_MDS2.Max_Missing_Lines) ;
            swapFloat(&header->SQ_MDS2.Max_Missing_Gaps) ;
            swap4bytesStruct(&header->SQ_MDS2.Number_Missing_Lines) ;
            swapFloat(&header->SQ_MDS2.Input_Data_Mean.r) ;
            swapFloat(&header->SQ_MDS2.Input_Data_Mean.i) ;
            swapFloat(&header->SQ_MDS2.Input_Data_Standard_Deviation.r) ;
            swapFloat(&header->SQ_MDS2.Input_Data_Standard_Deviation.i) ;
            swapFloat(&header->SQ_MDS2.Number_Gaps) ;
            swapFloat(&header->SQ_MDS2.Number_Lines_Excluding_Gaps) ;
            swapFloat(&header->SQ_MDS2.Output_Data_Mean.r) ;
            swapFloat(&header->SQ_MDS2.Output_Data_Mean.i) ;
            swapFloat(&header->SQ_MDS2.Output_Data_Standard_Deviation.r) ;
            swapFloat(&header->SQ_MDS2.Output_Data_Standard_Deviation.i) ;
            swap4bytesStruct(&header->SQ_MDS2.Number_Errors) ;
		}
    }
}


void readSpecificProductHeader(ENVISAT_HEADER *header, FILE *f1)
{
    if(fread((SPECIFIC_PRODUCT_HEADER *)(&header->Specific_Product), 1, sizeof(SPECIFIC_PRODUCT_HEADER), f1) != sizeof(SPECIFIC_PRODUCT_HEADER))
		ase("Failed to read Specific Product header") ;
}


void readMainProductHeader(ENVISAT_HEADER *header, FILE *f1)
{
    if(fread((MAIN_PRODUCT_HEADER *)(header->Main_Product), 1, sizeof(MAIN_PRODUCT_HEADER), f1) != sizeof(MAIN_PRODUCT_HEADER))
		ase("Failed to read Main Product Header") ;
}

ENVISAT_HEADER *allocEnvisatHeader(void)
{
	ENVISAT_HEADER *header ;

    if((header = (ENVISAT_HEADER *)calloc (1, sizeof(ENVISAT_HEADER))) == NULL)
		ase("Unable to allocate ENVISAT Header structure") ;
    if ((header->Main_Product = (MAIN_PRODUCT_HEADER *)calloc (1, sizeof(MAIN_PRODUCT_HEADER))) == NULL)
		ase("Unable to allocate ENVISAT Main Profuct Header structure") ;

	return header ;
}

int getIndexOfDSD(char *DSDName, ENVISAT_HEADER *header)
{
    int			indiceDSD, i ;
    unsigned long	numberOfRecords ;

    indiceDSD = -1 ;
    for(i = 0; i< 18; i++) {
		if(!strncmp(header->Specific_Product.DSD[i].Data_Set_Name, DSDName, strlen(DSDName))) {
            sscanf(header->Specific_Product.DSD[i].Number_DSR, "%lu", &numberOfRecords) ;
            if(numberOfRecords) indiceDSD = i ;
        }
    }

    return indiceDSD ;
}


void seekFileForDSD(FILE *f1, ENVISAT_HEADER *header, int indiceDSD, int indexOfRecord)
{
    long	fileOffset, recordSize ;

    sscanf(header->Specific_Product.DSD[indiceDSD].DS_Offset_Value, "%ld", &fileOffset) ;
    sscanf(header->Specific_Product.DSD[indiceDSD].DSR_Size_Value, "%ld", &recordSize) ;
	fileOffset += recordSize * indexOfRecord ;
    if(fseek(f1, fileOffset, SEEK_SET)) {
        if(errno == EBADF) ase("The stream specified is not a seekable stream. \n") ;
        if(errno == EINVAL) ase("The whence argument is invalid or the resulting file position indicator would be set to a negative value. \n") ;
        if(errno == EOVERFLOW) ase("The resulting file offset would be a value which cannot be represented correctly in an object of type off_t for fseeko() and ftello() or long for fseek() and ftell(). \n") ;
    }
 }

int getNumberOfRecordsForDSD(char *DSDName, ENVISAT_HEADER *header)
{
	int	i ;
    int	numberOfRecords = 0 ;

    for(i = 0; i< 18; i++) {
		if(!strncmp(header->Specific_Product.DSD[i].Data_Set_Name, DSDName, strlen(DSDName)))
            sscanf(header->Specific_Product.DSD[i].Number_DSR, "%d", &numberOfRecords) ;
    }

    return numberOfRecords ;
}

char isAP(ENVISAT_HEADER *header)
{
    return (((strncmp (&header->Main_Product->Product_File_Name.Product_Id[4], "AP", 2)) == 0)) ;
}

char isSLC(ENVISAT_HEADER *header)
{
    return (((strncmp (&header->Main_Product->Product_File_Name.Product_Id[4], "IMS_1P", 6)) == 0) ||
            ((strncmp (&header->Main_Product->Product_File_Name.Product_Id[4], "APS_1P", 6)) == 0)) ;
}

char isPRI(ENVISAT_HEADER *header)
{
    return (((strncmp (&header->Main_Product->Product_File_Name.Product_Id[4], "IMP_1P", 6)) == 0) ||
            ((strncmp (&header->Main_Product->Product_File_Name.Product_Id[4], "APP_1P", 6)) == 0)) ;
}

char isGeocoded(ENVISAT_HEADER *header)
{
    return (((strncmp (&header->Main_Product->Product_File_Name.Product_Id[4], "IMG_1P", 6)) == 0) ||
            ((strncmp (&header->Main_Product->Product_File_Name.Product_Id[4], "APG_1P", 6)) == 0)) ;
}


/* ROI_PAC EnviSAT data reader */
SLCImageInfo *createInfoImageFromROI_PAC_RSCFile(char *ROI_PACDirectoryPath)
{
    char *aPath, *rscPath, *slcPath, **directoryEntries ;
    int i, numberOfEntries ;
    SLCImageInfo *info ;
    keyValue *ROI_PACKeyValueList ;

    /* Read directory content eand look for .rsc file(s) */
    if ((directoryEntries = getDirectoryContentAtPath(ROI_PACDirectoryPath, &numberOfEntries)) == NULL) {
        ase("ROI_PAC directory is empty...") ;
    }
    for (i = 0; i < numberOfEntries; i++) {
        if (!strcmp((aPath = getPointerToLastFileExtensionInPath(directoryEntries[i])), "slc")) {
            break ;
        }
    }
    if (i == numberOfEntries) {
        ase("No .slc files found into ROI_PAC directory") ;
    }

    /* Verify that the corresponding slc file is present in ROI_PAC directory */
    slcPath= initStringWith3Strings(ROI_PACDirectoryPath, "/", directoryEntries[i]) ;
    rscPath= initStringWith2Strings(slcPath, ".rsc") ;
    if (!fileExistsAtPath(rscPath)) {
        ase("No rsc file corresponding to the .slc file found") ;
    }

    ROI_PACKeyValueList = convertRSCFileToKeyValueList(rscPath) ;
    info = allocInfoImage() ;

    sprintf(info->productID, "ROI_PAC EnviSAT data") ;
    info->sensorID = __ENVISAT__ ;
    sprintf(info->scene_id, "Orbit number %s", getStringValForKeyIn(ROI_PACKeyValueList, "ORBIT")) ;
    sprintf(info->scene_loc, "Scene centre: Longitude = %f\tLatitude = %f", getFloatValForKeyIn(ROI_PACKeyValueList, "LONG"), getFloatValForKeyIn(ROI_PACKeyValueList, "LAT")) ;
    sprintf(info->polMode, "%s", getStringValForKeyIn(ROI_PACKeyValueList, "POL")) ;
    removeAnyOccurrenceOfSubStringInString(info->polMode, "/") ;
    sprintf(info->platformName, "%s",getStringValForKeyIn(ROI_PACKeyValueList, "PLATFORM")) ;
    info->acquisitionDate = allocStringOfLength(8) ;
    sprintf(info->acquisitionDate, "%.8s", getStringValForKeyIn(ROI_PACKeyValueList, "FIRST_FRAME_SCENE_CENTER_TIME")) ;
    sscanf(getStringValForKeyIn(ROI_PACKeyValueList, "BEAM"), "IS%d", &info->beamNumber) ;
    info->rangeDimension = getIntValForKeyIn(ROI_PACKeyValueList, "WIDTH") ;
    info->azimuthDimension = getIntValForKeyIn(ROI_PACKeyValueList, "YMAX") + 1 ;
    info->nVect = 0 ;


    info->lookDirection = RIGHT_LOOKING ;
    info->wavelength = getDoubleValForKeyIn(ROI_PACKeyValueList, "WAVELENGTH") ;
    info->radarCarrierFrequency = c0 / info->wavelength ;
    info->rangeSamplingFrequency = getDoubleValForKeyIn(ROI_PACKeyValueList, "RANGE_SAMPLING_FREQUENCY") ;
    info->rangeResolutionCell = getDoubleValForKeyIn(ROI_PACKeyValueList, "RANGE_PIXEL_SIZE") ;
    info->azimuthResolutionCell = getDoubleValForKeyIn(ROI_PACKeyValueList, "AZIMUTH_PIXEL_SIZE") ;
    info->prf = getDoubleValForKeyIn(ROI_PACKeyValueList, "PRF") ;
    info->lineTimeInterval = 1. / info->prf ;
    info->rangeBandwidth = getDoubleValForKeyIn(ROI_PACKeyValueList, "PULSE_LENGTH") * getDoubleValForKeyIn(ROI_PACKeyValueList, "CHIRP_SLOPE") ;
    info->azimuthBandwidth = info->prf * 0.8 ; /* Estimate of the azimuth bandwidth since not given within the ROI_PAC .rsc file */
    info->fdc[0] = getDoubleValForKeyIn(ROI_PACKeyValueList, "DOPPLER_RANGE0") * info->prf ;
    info->fdc[1] = getDoubleValForKeyIn(ROI_PACKeyValueList, "DOPPLER_RANGE1") * info->prf * info->rangeSamplingFrequency ;
    info->fdc[2] = getDoubleValForKeyIn(ROI_PACKeyValueList, "DOPPLER_RANGE2") * info->prf * pow(info->rangeSamplingFrequency, 2.) ;
    info->slantRange[0] = getDoubleValForKeyIn(ROI_PACKeyValueList, "STARTING_RANGE") - getDoubleValForKeyIn(ROI_PACKeyValueList, "RANGE_BIAS") ;
    info->slantRange[1] = info->slantRange[0] + info->rangeDimension / 2. * info->rangeResolutionCell ;
    info->slantRange[2] = info->slantRange[0] + info->rangeDimension * info->rangeResolutionCell ;
    info->twoWayRangeTime[0] = 2. * info->slantRange[0] / c0 ;
    info->FPAT = getDoubleValForKeyIn(ROI_PACKeyValueList, "FIRST_LINE_UTC") ;
    info->LPAT = getDoubleValForKeyIn(ROI_PACKeyValueList, "LAST_LINE_UTC") ;
    info->isOrbitInterpolationDone = 0 ;
    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL)
        ase("Erreur d'allocation de *info->ellRef\n") ;
    sprintf(info->ellRef->ellipsoidID, "GEM6") ;
    info->ellRef->a = 6378144.0 ;
    info->ellRef->b = 6356759 ;
    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;

    /* Geolocation of scene on reference ellipsoid cannot be performed since orbits are not included in ROI_PAC data */
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
    info->EarthRadiusAtSceneCenter = 6371221. ;
    for (i = 0; i < info->loc->N; i++) {
        info->loc->P[i].x = info->loc->P[i].y = info->locUTM->P[i].x = info->locUTM->P[i].y = 0. ;
    }
    sprintf(info->UTMZone, "???") ;


    for (i = 0; i < numberOfEntries; i++) {
        free(directoryEntries[i]) ;
    }
    free(directoryEntries) ;
    free(slcPath) ;
    free(rscPath) ;

    return (info) ;
}

keyValue *convertRSCFileToKeyValueList(char *aPath)
{
    char aKey[_MAX_COMMENT_LENGTH_], aValue[_MAX_COMMENT_LENGTH_] ;
    keyValue *aList ;
    rawFileDescriptor *aFile ;

    aList = allocAKeyValuePair() ;
    if ((aFile = openRawFileForReadingAtPath(aPath)) == NULL) {
        ase("Failed to open .rsc file") ;
    }

    while ((fgets(aComment, _MAX_COMMENT_LENGTH_, aFile->f)) != NULL) {
        sscanf(aComment, "%s %s", aKey, aValue) ;
        stripWhiteCharsAtEndOfString(aKey) ;
        stripWhiteCharsAtEndOfString(aValue) ;
        setStringValForKeyIn(aList, aValue, aKey) ;
    }

    freeRawFileDescriptor(aFile) ;

    return (aList) ;
}
