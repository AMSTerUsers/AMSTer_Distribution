
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageRSAT2.c
//  RSAT2DAtaReader
//
//  Created by Dominique Derauw on 12/02/15.
//  Copyright SAREOS (c) 2015 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "infoImageRSAT2.h"


struct infoImage *createSLCImageInfoForRSAT2Data(char *productInfoFilePAth)
{
    char *aString ;
    int		i, i0, stateVectorIndex ;
    double	aDouble ;
    double  diffAvg, diffAvg0 ;
    double  *stateVectorsTime ;
    struct infoImage	*info ;
    RSAT2AdditionalInfo *RSAT2Specific ;
    
    CSVStruct *csv, *csv2 ;
    CSVStruct *csvX, *csvY, *csvZ, *csvVX, *csvVY, *csvVZ ;
    
	xmlDocPtr doc ;
    
	doc = getdoc(productInfoFilePAth);
    info = allocInfoImage() ;
    info->sensorSpecificInfo = RSAT2Specific = malloc(sizeof(*RSAT2Specific)) ;
    
    /* Satellite ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//*[local-name() = 'satellite']", doc))) {
        sprintf(info->platformName, "%s", csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->platformName, "%s", "Unknown sensor") ;
    }
    
    /* Acquisition date */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//rawDataStartTime", doc))) {
        info->acquisitionDate = allocStringOfLength(10) ;
        sprintf(info->acquisitionDate, "%.10s", csv->stringVal[0]) ;
        removeAnyOccurrenceOfSubStringInString(info->acquisitionDate, "-") ;
        freeCSVStruct(csv) ;
    }

    
    /* Polarisation mode */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//radarParameters/polarizations", doc))) {
        if (csv->numberOfEntries == 1) {
            csv2 = readWhiteCharSeperatedValuesInString(csv->stringVal[0]) ;
        }
        else
            csv2 = csv ;
        
        for (i = 0; i < csv2->numberOfEntries; i++) {
            if(!i) {
                sprintf(info->polMode, "%s", csv2->stringVal[0]) ;
            }
            else {
                aString = initStringWith3Strings(info->polMode, ", ", csv2->stringVal[i]) ;
                sprintf(info->polMode, "%s", aString) ;
                free(aString) ;
            }
            
        }
        if (csv->numberOfEntries == 1) {
            freeCSVStruct(csv2) ;
        }
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->platformName, "%s", "Unknown polarisation") ;
    }
    
    
    /* Beam ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sourceAttributes/beamModeMnemonic", doc))) {
        sscanf(csv->stringVal[0], "%*1c%d", &(info->beamNumber)) ;
    }
    else {
        info->beamNumber = -1 ;
        csv = allocCSVStruct() ;
        addStringValInCSVStruct("?", csv) ;
    }
    
    /* Product ID */
    if((csv2 = readCSVInXMLFileForXPath((xmlChar*)"//radarParameters/acquisitionType", doc))) {
        sprintf(info->productID, "%s - %s", csv->stringVal[0], csv2->stringVal[0]) ;
        freeCSVStruct(csv) ;
        freeCSVStruct(csv2) ;
    }
    else {
        sprintf(info->productID, "Unknown product") ;
    }
    
    /* Scene ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sourceAttributes/imageId", doc))) {
        sprintf(info->scene_id, "%s", csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->scene_id, "No scene ID") ;
    }
    
    /* Scene location */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sceneCenterCoord/lon", doc))) {
        sscanf(csv->stringVal[0], "%lf", &aDouble) ;
        sprintf(info->scene_loc, "Center longitude: %.4g\t", aDouble) ;
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->scene_loc, "Center longitude: ???\t") ;
    }
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sceneCenterCoord/lat", doc))) {
        sscanf(csv->stringVal[0], "%lf", &aDouble) ;
        aString = initStringWithString(info->scene_loc) ;
        sprintf(info->scene_loc, "%sCenter latitude: %.4g", aString, aDouble) ;
        free(aString) ;
        freeCSVStruct(csv) ;
    }
    
    /* Look direction defined as Right looking */
    info->lookDirection = RIGHT_LOOKING ;
    if((csv = getAttributeInXMLDocForXPath((xmlChar*)"//radarParameters/antennaPointing", doc))) {
        if (!strncmp(csv->stringVal[0], "Left", 4)) {
            info->lookDirection = LEFT_LOOKING ;
        }
        sscanf(csv->stringVal[0], "%d", &(info->rangeDimension)) ;
        freeCSVStruct(csv) ;
    }
    
    
    /* SLC data dimensions */
    info->azimuthDimension = 0 ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//imageAttributes/rasterAttributes/numberOfLines", doc))) {
        sscanf(csv->stringVal[0], "%d", &(info->azimuthDimension)) ;
        freeCSVStruct(csv) ;
    }
    info->rangeDimension = 0 ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//imageAttributes/rasterAttributes/numberOfSamplesPerLine", doc))) {
        sscanf(csv->stringVal[0], "%d", &(info->rangeDimension)) ;
        freeCSVStruct(csv) ;
    }
    
    
    /* Radar carrier frequency */
    info->radarCarrierFrequency = 5.405e+09 ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sourceAttributes/radarParameters/radarCenterFrequency", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->radarCarrierFrequency)) ;
        freeCSVStruct(csv) ;
    }
    info->wavelength = c0 / info->radarCarrierFrequency ;
    
    /* Range sampling frequency */
    info->rangeSamplingFrequency = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//radarParameters/adcSamplingRate", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->rangeSamplingFrequency)) ;
        freeCSVStruct(csv) ;
    }
    
    /* ADC sampling rate on I an Q channels ==> x 2. */
    /* info->rangeSamplingFrequency *= 2. ; */
    
    /* Range bandwidth and resolution cell */
    info->rangeBandwidth = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sarProcessingInformation/totalProcessedRangeBandwidth", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->rangeBandwidth)) ;
        freeCSVStruct(csv) ;
    }
    
    info->rangeResolutionCell = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//imageAttributes/rasterAttributes/sampledPixelSpacing", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->rangeResolutionCell)) ;
        freeCSVStruct(csv) ;
    }
    
    /* Min and max slant range */
    info->twoWayRangeTime[0] = info->slantRange[0] = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sarProcessingInformation/slantRangeNearEdge", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->slantRange[0])) ;
        freeCSVStruct(csv) ;
    }
    info->twoWayRangeTime[0] = 2. / c0 * info->slantRange[0] ;
    info->slantRange[1] = info->slantRange[0] + info->rangeDimension / 2 * info->rangeResolutionCell ;
    info->slantRange[2] = info->slantRange[0] + info->rangeDimension * info->rangeResolutionCell ;
    
    /* PRF */
    info->prf = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//radarParameters/pulseRepetitionFrequency", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->prf)) ;
        freeCSVStruct(csv) ;
    }
    
    /* Azimuth Bandwith and resolution */
    info->azimuthBandwidth = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sarProcessingInformation/totalProcessedAzimuthBandwidth", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->azimuthBandwidth)) ;
        freeCSVStruct(csv) ;
    }
    
    info->azimuthResolutionCell = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//imageAttributes/rasterAttributes/sampledLineSpacing", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->azimuthResolutionCell)) ;
        freeCSVStruct(csv) ;
    }
    
    /* Doppler polynomial with respect to range in [Hz]/[pixel] */
    aDouble = info->fdc[0] = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//dopplerCentroid/dopplerCentroidCoefficients", doc))) {
        if((csv2 = readWhiteCharSeperatedValuesInString(csv->stringVal[0]))) {
            if (csv2->numberOfEntries >= 3) {
                for (i = 0; i < 3; i++) {
                    sscanf(csv2->stringVal[i], "%lf", &(info->fdc[i])) ;
                }
            }
            else {
                for (i = 0; i < csv2->numberOfEntries; i++) {
                    sscanf(csv2->stringVal[i], "%lf", &(info->fdc[i])) ;
                }
                for (; i < 3; i++) {
                    info->fdc[i] = 0. ;
                }
            }
            freeCSVStruct(csv2) ;
        }
        freeCSVStruct(csv) ;
    }
    
    /* azimuth times */
    info->FPAT = info->LPAT = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sarProcessingInformation/zeroDopplerTimeFirstLine", doc))) {
        info->FPAT = getTimeValInSecFromDateFormat(csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sarProcessingInformation/zeroDopplerTimeLastLine", doc))) {
        info->LPAT = getTimeValInSecFromDateFormat(csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }

    /* Verify time ordering of data */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//imageAttributes/rasterAttributes/lineTimeOrdering", doc))) {
        if((RSAT2Specific->isAzimuthFlipped = !strcmp(csv->stringVal[0], "Decreasing"))) {
            aDouble = info->FPAT ;
            info->FPAT = info->LPAT ;
            info->LPAT = aDouble ;
        }
        freeCSVStruct(csv) ;
    }
    
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//imageAttributes/rasterAttributes/pixelTimeOrdering", doc))) {
        RSAT2Specific->isRangeFlipped = !strcmp(csv->stringVal[0], "Decreasing") ;
        freeCSVStruct(csv) ;
    }
    
    /* lineTimeInterval */
    /* In the case of RadarSAT, line time interval must be computed from azimuth times and azimuth dimention */
    /* Inverse of the PRF does not correspond to effective line time interval */
    info->lineTimeInterval = (info->LPAT - info->FPAT) / (info->azimuthDimension - 1) ;
    
    
    /* Incidence angles */
    
    info->incidenceAngle[0] = info->incidenceAngle[1] = info->incidenceAngle[2] = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sarProcessingInformation/incidenceAngleNearRange", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->incidenceAngle[0])) ;
        freeCSVStruct(csv) ;
    }
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//sarProcessingInformation/incidenceAngleFarRange", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->incidenceAngle[2])) ;
        freeCSVStruct(csv) ;
    }

    
    /* State vectors */
    /* First Vector Time */
    info->FVT = 0. ;
    info->nVect = 0 ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//orbitAndAttitude/orbitInformation/stateVector/timeStamp", doc))) {
        info->nVect = csv->numberOfEntries ;
        if(info->nVect) {
            /* We extract all state vectors time positions */
            stateVectorsTime = vectorDouble(0, info->nVect - 1) ;
            for (i = 0; i < csv->numberOfEntries; i++) {
                stateVectorsTime[i] = getTimeValInSecFromDateFormat(csv->stringVal[i]) ;
            }
            
            /* Now we extract all positions and velocities */
            csvX = readCSVInXMLFileForXPath((xmlChar*)"//orbitAndAttitude/orbitInformation/stateVector/xPosition", doc) ;
            csvY = readCSVInXMLFileForXPath((xmlChar*)"//orbitAndAttitude/orbitInformation/stateVector/yPosition", doc) ;
            csvZ = readCSVInXMLFileForXPath((xmlChar*)"//orbitAndAttitude/orbitInformation/stateVector/zPosition", doc) ;
            csvVX = readCSVInXMLFileForXPath((xmlChar*)"//orbitAndAttitude/orbitInformation/stateVector/xVelocity", doc) ;
            csvVY = readCSVInXMLFileForXPath((xmlChar*)"//orbitAndAttitude/orbitInformation/stateVector/yVelocity", doc) ;
            csvVZ = readCSVInXMLFileForXPath((xmlChar*)"//orbitAndAttitude/orbitInformation/stateVector/zVelocity", doc) ;
            
            /* We wil select only the five state vectors encompassing the data */
            i0 = 0 ;
            info->FVT = stateVectorsTime[i0] ;
            if(info->nVect > 5) {
                i0 = 0 ;
                diffAvg0 = fabs((info->LPAT + info->FPAT)/2. - (stateVectorsTime[4] + stateVectorsTime[0])/2.) ;
                for (i = 0; i < info->nVect - 5; i++) {
                    diffAvg = fabs((info->LPAT + info->FPAT)/2. - (stateVectorsTime[i + 4] + stateVectorsTime[i])/2.) ;
                    if(diffAvg < diffAvg0) {
                        diffAvg0 = diffAvg ;
                        i0 = i ;
                    }
                }
                info->nVect = 5 ;
                info->FVT = stateVectorsTime[i0] ;
            }
            
            if((info->S = (struct stateVect *)malloc(info->nVect * sizeof(struct stateVect))) == NULL)
                ase("State vector allocation error\n") ;
            for(i = 0; i < info->nVect; i++) {
                stateVectorIndex = i0 + i ;
                info->S[i].P = vectorDouble(0, 2) ;
                info->S[i].V = vectorDouble(0, 2) ;
                sscanf(csvX->stringVal[stateVectorIndex], "%lf", &(info->S[i].P[0])) ;
                sscanf(csvY->stringVal[stateVectorIndex], "%lf", &(info->S[i].P[1])) ;
                sscanf(csvZ->stringVal[stateVectorIndex], "%lf", &(info->S[i].P[2])) ;
                sscanf(csvVX->stringVal[stateVectorIndex], "%lf", &(info->S[i].V[0])) ;
                sscanf(csvVY->stringVal[stateVectorIndex], "%lf", &(info->S[i].V[1])) ;
                sscanf(csvVZ->stringVal[stateVectorIndex], "%lf", &(info->S[i].V[2])) ;
                info->S[i].t = stateVectorsTime[stateVectorIndex] ;
            }
            
            freeCSVStruct(csvX) ;
            freeCSVStruct(csvY) ;
            freeCSVStruct(csvZ) ;
            freeCSVStruct(csvVX) ;
            freeCSVStruct(csvVY) ;
            freeCSVStruct(csvVZ) ;
        }
        freeCSVStruct(csv) ;
    }
    info->Dt = info->S[1].t - info->S[0].t ;

    
    
	info->aX = info->aY = info->aZ = info->aVx= info->aVy= info->aVz = NULL ;
	info->isOrbitInterpolationDone = 0 ;
    
    /* Reference ellipsoid */
    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL)
        ase("Erreur d'allocation de *info->ellRef\n") ;
    
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//geographicInformation/referenceEllipsoidParameters/ellipsoidName", doc))) {
        sprintf(info->ellRef->ellipsoidID, "%s", csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->ellRef->ellipsoidID, "Undefined ellipsoid") ;
    }
    
    info->ellRef->a = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//geographicInformation/referenceEllipsoidParameters/semiMajorAxis", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->ellRef->a)) ;
        freeCSVStruct(csv) ;
    }
    
    info->ellRef->b = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//geographicInformation/referenceEllipsoidParameters/semiMinorAxis", doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->ellRef->b)) ;
        freeCSVStruct(csv) ;
    }
    
    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;
    
	/* Geolocate scene on reference ellipsoid */
    info->sceneAverageHeight = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//geographicInformation/referenceEllipsoidParameters/geodeticTerrainHeight",doc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->sceneAverageHeight)) ;
        freeCSVStruct(csv) ;
    }
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
	info->EarthRadiusAtSceneCenter = 6371221. ;
	info->loc = allocQuadrilateral() ;
    info->incidenceAngle[0] = 0. ;
	geolocateSceneOnEllipsoid(info, info->ellRef) ;
	
	xmlFreeDoc(doc);
	xmlCleanupParser();
    
    return info ;
}


double getTimeValInSecFromDateFormat(char* aDateChar)
{
    float hh, mm, ss ;
    double timeVal ;
    
    sscanf(aDateChar, "%*11s %f:%f:%f", &hh, &mm, &ss) ;
    timeVal = 3600. * hh + 60. * mm + ss  ;
    
    return (timeVal) ;
}




