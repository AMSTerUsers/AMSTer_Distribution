
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageICEYE.c
//  ICEYEDataReader
//
//  (re)Created by Dominique Derauw on february 2022.
//  Copyright (c) 2022 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "infoImageICEYE.h"



struct infoImage *createSLCImageInfoFromICEYEHeader(keyValue *header, CSVStruct *stateVectorTime)
{
    char *aString, *layerPol ;
    int		i, i0, stateVectorIndex ;
    double	*aDouble, secondsPerPixels ;
    double *posX, *posY, *posZ, *velX, *velY, *velZ ;
    double  *stateVectorsTime ;
    struct infoImage	*info ;
    keyValue *aKeyValue ;

    info = allocInfoImage() ;

    /* Satellite ID */
    if((aString = getStringValForKeyIn(header, "satellite_name")) == NULL) {
        sprintf(info->platformName, "%s", "Unknown sensor") ;
    }
    else {
        sprintf(info->platformName, "%s", aString) ;
        if (strstr(info->platformName, "ICEYE")) {
            info->sensorID  = __ICEYE__ ;
        }
    }

    if((aString = getStringValForKeyIn(header, "acquisition_start_utc")) != NULL) {
        info->acquisitionDate = allocStringOfLength(10) ;
        sprintf(info->acquisitionDate, "%.10s", aString) ;
        removeAnyOccurrenceOfSubStringInString(info->acquisitionDate, "-") ;
    }

    /* Polarisation mode */
    layerPol = getStringValForKeyIn(header, "polarization") ;
    sprintf(info->polMode, "%s", layerPol) ;

    /* Beam ID - Not defined for ICEYE*/
    info->beamNumber = -9999 ;

    /* Product ID */
    if((aString = getStringValForKeyIn(header, "product_type")) == NULL) {
        sprintf(info->productID, "%s", "Unknown product") ;
    }
    else {
        sprintf(info->productID, "%s", aString) ;
    }

    /* Scene ID */
    if((aString = getStringValForKeyIn(header, "product_name")) == NULL) {
        sprintf(info->scene_id, "%s", "No scene ID") ;
    }
    else {
        sprintf(info->scene_id, "%s", aString) ;
    }

    /* Look direction */
    if((aKeyValue = isKeyValPresent(header, "look_side")) == NULL) {
        sprintf(info->scene_loc, "%s", "Sensor supposed to be right looking") ;
        info->lookDirection = RIGHT_LOOKING ;
    }
    else {
        if (!strncmp(aKeyValue->stringVal, "right", 5)) {
            info->lookDirection = RIGHT_LOOKING ;
        }
        else
            info->lookDirection = LEFT_LOOKING ;
    }

    /* SLC data dimensions */
    info->azimuthDimension = getIntValForKeyIn(header, "number_of_azimuth_samples") ;
    info->rangeDimension = getIntValForKeyIn(header, "number_of_range_samples") ;


    /* Radar carrier frequency */
    info->radarCarrierFrequency = getDoubleValForKeyIn(header, "carrier_frequency") ;

    /* Wavelength */
    info->wavelength = c0 / info->radarCarrierFrequency ;

    /* Radar bandwidth */
    info->rangeBandwidth = getDoubleValForKeyIn(header, "chirp_bandwidth") ;

    /* Radar apodization coefficient - Not defined for ICEYE - Taking Hamming by default */
    info->rangeApodizationCoefficient = .54 ;

    /* Range sampling frequency */
	info->rangeSamplingFrequency = getDoubleValForKeyIn(header, "range_sampling_rate") ;
    secondsPerPixels = 1 / info->rangeSamplingFrequency ;

    /* Range resolution cell */
    info->rangeResolutionCell = getDoubleValForKeyIn(header, "slant_range_spacing") ;

    /* Min and max slant range */
    info->twoWayRangeTime[0] = getDoubleValForKeyIn(header, "first_pixel_time") ;
    info->twoWayRangeTime[2] = info->twoWayRangeTime[0] + info->rangeDimension / info->rangeSamplingFrequency ;
    info->twoWayRangeTime[1] = (info->twoWayRangeTime[0] + info->twoWayRangeTime[2]) / 2. ;
    for(i = 0; i < 3; i++) info->slantRange[i] = c0 / 2. * info->twoWayRangeTime[i] ;


    /* PRF */
    info->prf = getDoubleValForKeyIn(header, "processing_prf") ;
    info->lineTimeInterval = 1. / info->prf ;

    /* Azimuth Bandwith and resolution */
    info->azimuthBandwidth = getDoubleValForKeyIn(header, "total_processed_bandwidth_azimuth") ;
    info->azimuthResolutionCell = getDoubleValForKeyIn(header, "azimuth_ground_spacing") ;

    /* Doppler polynomial with respect to range in [Hz]/[pixel] */
    if((aKeyValue = isKeyValPresent(header, "Centroid vs Range Time Polynomial")) == NULL) {
        info->fdc[0] = info->fdc[1] = info->fdc[2] = 0.0 ;
    }
    else {
        aDouble = (double *)(aKeyValue->value) ;
        info->fdc[0] = aDouble[0] ;
        info->fdc[1] = aDouble[1] * secondsPerPixels ;
        info->fdc[2] = aDouble[2] * pow(secondsPerPixels, 2.) ;
    }

    /* azimuth times */
    aDouble = vectorDouble(0, 2) ;
    aString = getStringValForKeyIn(header, "zerodoppler_start_utc") ;
    sscanf(aString, "%*10sT%2lf:%2lf:%lf", aDouble, aDouble + 1, aDouble + 2) ;
    info->FPAT =  3600 * aDouble[0] + 60 * aDouble[1] + aDouble[2] ;
    aString = getStringValForKeyIn(header, "zerodoppler_end_utc") ;
    sscanf(aString, "%*10sT%2lf:%2lf:%lf", aDouble, aDouble + 1, aDouble + 2) ;
    info->LPAT =  3600 * aDouble[0] + 60 * aDouble[1] + aDouble[2] ;


    /* State vectors */
    info->nVect = getIntValForKeyIn(header, "Number of State Vectors") ;
    stateVectorsTime = vectorDouble(0, info->nVect - 1) ;
    posX = (isKeyValPresent(header, "posX"))->value ;
    posY = (isKeyValPresent(header, "posY"))->value ;
    posZ = (isKeyValPresent(header, "posZ"))->value ;
    velX = (isKeyValPresent(header, "velX"))->value ;
    velY = (isKeyValPresent(header, "velY"))->value ;
    velZ = (isKeyValPresent(header, "velZ"))->value ;
    for (i = 0; i < info->nVect; i++) {
        sscanf(stateVectorTime->stringVal[i], "%*10sT%2lf:%2lf:%lf", aDouble, aDouble + 1, aDouble + 2) ;
        stateVectorsTime[i] = 3600 * aDouble[0] + 60 * aDouble[1] + aDouble[2] ;
    }
    freeVectorDouble(aDouble, 0) ;
    
    info->Dt = (info->nVect > 1)? stateVectorsTime[1] - stateVectorsTime[0] : 0 ;

    /* We select only the state vectors encompassing the data */
    i0 = 0 ;
    while (info->FPAT > stateVectorsTime[i0]) {
        i0++ ;
    }
    i0 -= (i0)? 0 : 1 ;
    i = i0 ;
    while (info->LPAT > stateVectorsTime[i]) {
        i++ ;
    }
    info->nVect = i - i0 + 1 ;
    info->FVT = stateVectorsTime[i0] ;


    if((info->S = (struct stateVect *)malloc(info->nVect * sizeof(struct stateVect))) == NULL) {
        ase("State vector allocation error\n") ;
    }
    for(i = 0; i < info->nVect; i++) {
        stateVectorIndex = i0 + i ;
        info->S[i].P = vectorDouble(0, 2) ;
        info->S[i].V = vectorDouble(0, 2) ;
        info->S[i].P[0] = posX[stateVectorIndex] ;
        info->S[i].P[1] = posY[stateVectorIndex] ;
        info->S[i].P[2] = posZ[stateVectorIndex] ;
        info->S[i].V[0] = velX[stateVectorIndex] ;
        info->S[i].V[1] = velY[stateVectorIndex] ;
        info->S[i].V[2] = velZ[stateVectorIndex] ;
        info->S[i].t = stateVectorsTime[stateVectorIndex] ;
    }
    
	info->aX = info->aY = info->aZ = info->aVx= info->aVy= info->aVz = NULL ;
	info->isOrbitInterpolationDone = 0 ;

    /* Reference ellipsoid - Default to WGS84 */
    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL)
        ase("Erreur d'allocation de *info->ellRef\n") ;

    if((aString = getStringValForKeyIn(header, "geo_ref_system")) == NULL) {
        sprintf(info->ellRef->ellipsoidID, "%s", "WGS84") ;
    }
    else {
        sprintf(info->ellRef->ellipsoidID, "%s", aString) ;
    }

    info->ellRef->a = WGS84_A ;
    info->ellRef->b = WGS84_B ;
    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;

	/* Geolocate scene on reference ellipsoid */
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
	info->EarthRadiusAtSceneCenter = 6371221. ;
    info->sceneAverageHeight = getDoubleValForKeyIn(header, "avg_scene_height") ;
	info->loc = allocQuadrilateral() ;
	geolocateSceneOnEllipsoid(info, info->ellRef) ;

    /* Scene location */
    sprintf(info->scene_loc, "Center longitude: %8.3lf\t Center latitude: %8.3lf", 90/PI * (info->loc->P[0].x + info->loc->P[2].x), 90/PI * (info->loc->P[0].y + info->loc->P[2].y)) ;

    return info ;
}

