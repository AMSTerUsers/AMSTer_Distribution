
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageS1.c
//  S1DataReader
//
//  Created by Dominique Derauw on 7/01/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "infoImageS1.h"

struct infoImage *createSLCImageInfoForS1Data(char *aPath, char *polarization)
{
    char **ADSFileName, **MDSFilePath, **ADSFilePath, **CADSFilePath ;
    char *S1AccessPath, *MDSDirectory, *ADSDirectory, *CADSDirectory, *aString ; ;
    int unsigned i, numberOfMDS, numberOfLayers, numberOfSubSwaths ;
    int sliceNumber ;
    int absoluteOrbitNumber, relativeOrbitShift ;
    float lon, lat ;
    struct infoImage *info ;
 	xmlDocPtr *ADSXMLDoc, *CADSXMLDoc = NULL ;

    CSVStruct *csv ;
    S1AdditionalInfo *S1Specific ;
    polygon *area ;

    if ((S1AccessPath = expandEnvironmentVariablesInPath(aPath)) == NULL) {
        printf("\t\t-/-> S1 invalid access path\n") ;
        return (NULL) ;
    }

    if (!isDir(S1AccessPath)) {
        printf("\t\t-/-> S1 invalid access path\n") ;
        return(NULL) ;
    }
    
    /* Get ADS file names */
    ADSDirectory = initStringWith2Strings(S1AccessPath, "/annotation") ;
    if((ADSFileName = getADSFileNames(ADSDirectory, polarization, &numberOfMDS)) == NULL) {
        sprintf(ertex, "\t\t-/->%s data reading cancelled.\n\t\tRequested polarisation(s) not found.\n", S1AccessPath) ;
        free (ADSDirectory) ;
        return (NULL) ;
    }

    /* Get ADS file paths */
    ADSFilePath = getADSFilePath(ADSDirectory, ADSFileName, numberOfMDS) ;

    /* Open ADS XML files */
    ADSXMLDoc = openADSXMLFiles(ADSFilePath, numberOfMDS) ;

    /* First, test if image is a referenced slice of a data take */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//imageInformation/sliceNumber", ADSXMLDoc[0]))) {
        sscanf(csv->stringVal[0], "%d", &sliceNumber) ;
        freeCSVStruct(csv) ;
    }
    if (!sliceNumber) {
        sprintf(ertex, "\t\t-/-> Image is probably a specific focusing and not a slice of a given data take. Better to skip it.\n") ;
        printf("%s", ertex) ;

        /* Free XML docs and file paths*/
        for (i = 0; i < numberOfMDS; i++) {
            free(ADSFileName[i]) ;
            free(ADSFilePath[i]) ;
            xmlFreeDoc(ADSXMLDoc[i]) ;
        }
        free(ADSFileName) ;
        free(ADSFilePath) ;
        free(ADSXMLDoc) ;

        return (NULL) ;
    }
    
 
    /* Get MDS File paths */
    MDSDirectory = initStringWith2Strings(S1AccessPath, "/measurement") ;
    MDSFilePath = getMDSFilePath(MDSDirectory, ADSFileName, numberOfMDS) ;

    /* Get calibration file paths */
    CADSDirectory = initStringWith2Strings(ADSDirectory, "/calibration") ;
    CADSFilePath = getCADSFilePath(CADSDirectory, ADSFileName, numberOfMDS) ;

    /* Open calibration XML files */
    if (isValidDirectoryForPath(CADSDirectory)) {
        CADSXMLDoc = openADSXMLFiles(CADSFilePath, numberOfMDS) ;
    }


    /* Allocate infoImage structure */
    info = allocInfoImage() ;

    /* Determine the number of swaths from product mode (SM = 1, IW = 3 and EW = 5 sub swaths) */
    csv = getCSVForPathInADS("//adsHeader/mode", ADSXMLDoc[0]) ;
    numberOfSubSwaths = (strncmp(csv->stringVal[0], "S", 1))? (strncmp(csv->stringVal[0], "IW", 2))? 5 : 3 : 1 ;
    freeCSVStruct(csv) ;


    /* Determine number of layers */
    numberOfLayers = (numberOfSubSwaths == numberOfMDS)? 1 : 2 ;

    /* Generate S1 specific information from Annotation Data Sets */
    info->sensorSpecificInfo = S1Specific = (S1AdditionalInfo *)allocAndInitS1Specifics(numberOfLayers, numberOfSubSwaths, ADSXMLDoc, CADSXMLDoc) ;

    /* Transfer MDS & ADS file path to S1Specific */
    S1Specific->MDSFilePath = MDSFilePath ;
    S1Specific->ADSFilePath = ADSFilePath ;

    /* Product type */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//adsHeader/productType", ADSXMLDoc[0]))) {
        if (strcmp(csv->stringVal[0], "SLC")) {
            perror("This is not an SLC product...") ;
            exit(-1) ;
        }
        freeCSVStruct(csv) ;
    }
    else {
        perror("Product type not defined...") ;
        exit(-1) ;
    }

    /* Satellite ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//adsHeader/missionId", ADSXMLDoc[0]))) {
        sprintf(info->platformName, "%s", csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->platformName, "%s", "Unknown sensor") ;
    }

    /* Acquisition date */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//adsHeader/startTime", ADSXMLDoc[0]))) {
        info->acquisitionDate = allocStringOfLength(10) ;
        sprintf(info->acquisitionDate, "%.10s", csv->stringVal[0]) ;
        removeAnyOccurrenceOfSubStringInString(info->acquisitionDate, "-") ;
        freeCSVStruct(csv) ;
    }
    else {
            ase("Failed to read S1 start time\n") ;
    }


    /* Polarisation mode */
    info->numberOfLayers = numberOfLayers ;
    csv = getCSVForPathInADS("//adsHeader/polarisation", ADSXMLDoc[0]) ;
    sprintf(info->polMode, "%s", csv->stringVal[0]) ;
    freeCSVStruct(csv) ;
    if (info->numberOfLayers == 2) {
        aString = initStringWithString(info->polMode) ;
        csv = getCSVForPathInADS("//adsHeader/polarisation", ADSXMLDoc[S1Specific->numberOfSubSwaths]) ;
        sprintf(info->polMode, "%s, %s", aString, csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
        free(aString) ;
    }
    info->polScheme = readCSVInString(info->polMode) ;

    /* Relative orbit number */
    absoluteOrbitNumber = 0 ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//absoluteOrbitNumber", ADSXMLDoc[0]))) {
        sscanf(csv->stringVal[0], "%d", &absoluteOrbitNumber) ;
        freeCSVStruct(csv) ;
    }
    
    /* Per-satellite phase offset between absolute orbit counter and the shared 175-track grid */
    /* S1C changed position in the orbital plane on 2026-06-24 (transition to S1C+S1D operations), */
    /* hence two offsets depending on acquisition date (see https://sar-mpc.eu/about/faq/) */
    if (!strncmp(info->platformName, "S1C", 3)) {
        relativeOrbitShift = (strncmp(info->acquisitionDate, "20260624", 8) < 0)? 172 : 99 ;
    }
    else {
        relativeOrbitShift = (!strncmp(info->platformName, "S1A", 3))? 73 : (!strncmp(info->platformName, "S1B", 3))? 27 : 42 ;
    }
    info->relativeOrbitNumber = div(absoluteOrbitNumber - relativeOrbitShift, 175).rem + 1 ;

    /* Product ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//adsHeader/mode", ADSXMLDoc[0]))) {
        sprintf(info->productID, "%s", csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }

    /* Beam ID */
    info->beamNumber = 0 ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//adsHeader/swath", ADSXMLDoc[0]))) {
        if (!strcmp(info->productID, "SM") || !strcmp(info->productID, csv->stringVal[0])) {
            if (!strcmp(info->productID, "SM")) {
                sscanf(csv->stringVal[0], "SM%d", &(info->beamNumber)) ;
            }
            else {
                sscanf(csv->stringVal[0], "%*1s%d", &(info->beamNumber)) ;
            }
            sprintf(info->productID, "SM") ;
        }
        freeCSVStruct(csv) ;
    }

    /* Scene ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//timelinessCategory", ADSXMLDoc[0]))) {
        aString = initStringWithString(getPointerToFileNameInPath(S1AccessPath)) ;
        stripExtensionAtEndOfPath(aString) ;
        sprintf(info->scene_id, "%s, %s", aString, csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
        free(aString) ;
    }
    else {
        sprintf(info->scene_id, "No scene ID") ;
    }

    /* Look direction defined as Right looking */
    info->lookDirection = RIGHT_LOOKING ;

    /* PRF */
    info->lineTimeInterval = S1Specific->lineTimeInterval ;
    info->prf = 1. / info->lineTimeInterval ;
    csv = getCSVForPathInADS("//generalAnnotation/downlinkInformationList/downlinkInformation/prf", ADSXMLDoc[0]) ;
    sscanf(csv->stringVal[0], "%lf", &(info->prf)) ;
    freeCSVStruct(csv) ;


    /* SLC data dimensions */
    info->azimuthDimension = (int)round((S1Specific->LPAT - S1Specific->FPAT) / info->lineTimeInterval) + 1 ;
    info->rangeDimension = S1Specific->rangeDimension ;

    /* First pixel Azimuth Time */
    info->FPAT = S1Specific->FPAT ;

    /* Last pixel Azimuth Time */
    info->LPAT = S1Specific->LPAT ;

    /* Radar carrier frequency */
    info->radarCarrierFrequency = 0. ;
    csv = getCSVForPathInADS("//generalAnnotation/productInformation/radarFrequency", ADSXMLDoc[0]) ;
    sscanf(csv->stringVal[0], "%lf", &(info->radarCarrierFrequency)) ;
    freeCSVStruct(csv) ;

    /* Wavelength */
    info->wavelength = speedOfLight / info->radarCarrierFrequency ;

    /* Range sampling frequency */
    info->rangeSamplingFrequency = S1Specific->rangeSamplingFrequency ;

    /* Range resolution cell */
    info->rangeResolutionCell = 0. ;
    csv = getCSVForPathInADS("//imageAnnotation/imageInformation/rangePixelSpacing", ADSXMLDoc[0]) ;
    sscanf(csv->stringVal[0], "%lf", &(info->rangeResolutionCell)) ;
    freeCSVStruct(csv) ;

    /* Range bandwidth  */
    info->rangeBandwidth = 0. ;
    csv = getCSVForPathInADS("//rangeProcessing/processingBandwidth", ADSXMLDoc[0]) ;
    sscanf(csv->stringVal[0], "%lf", &(info->rangeBandwidth)) ;
    freeCSVStruct(csv) ;

    /* Range apodization coefficient  */
    info->rangeApodizationCoefficient = 0. ;
    csv = getCSVForPathInADS("//rangeProcessing/windowCoefficient", ADSXMLDoc[0]) ;
    sscanf(csv->stringVal[0], "%lf", &(info->rangeApodizationCoefficient)) ;
    freeCSVStruct(csv) ;

    /* Min and max slant range */
    info->twoWayRangeTime[0] = info->slantRange[0] = 0. ;
    csv = getCSVForPathInADS("//imageAnnotation/imageInformation/slantRangeTime", ADSXMLDoc[0]) ;
    sscanf(csv->stringVal[0], "%lf", &(info->twoWayRangeTime[0])) ;
    freeCSVStruct(csv) ;
    info->slantRange[0] = c0 / 2. * info->twoWayRangeTime[0] ;
    info->slantRange[2] = info->slantRange[0] + info->rangeDimension * info->rangeResolutionCell ;
    info->slantRange[1] = (info->slantRange[0] + info->slantRange[2]) / 2. ;

    /* Azimuth Bandwith and resolution */
    info->azimuthBandwidth = 0. ;
    csv = getCSVForPathInADS("//azimuthProcessing/processingBandwidth", ADSXMLDoc[0]) ;
    sscanf(csv->stringVal[0], "%lf", &(info->azimuthBandwidth)) ;
    freeCSVStruct(csv) ;

    info->azimuthResolutionCell = 0. ;
    csv = getCSVForPathInADS("//imageAnnotation/imageInformation/azimuthPixelSpacing", ADSXMLDoc[0]) ;
    sscanf(csv->stringVal[0], "%lf", &(info->azimuthResolutionCell)) ;
    freeCSVStruct(csv) ;

    /* Doppler centroid approximation */
    if (info->fdc != NULL) {
        freeVectorDouble(info->fdc, 0) ;
    }
    info->fdc = approxFDCForS1(info) ;

    /* Read and select state vectors */
    info->orbitTypeID = initStringWithString("Prelimiary orbit") ;
    info->S = readAndSelectStateVectors(ADSXMLDoc, info) ;
    info->FVT = info->S[0].t ;
    info->Dt = -1 ; /* Delta T between state vectors not necessarily constant */
    info->aX = info->aY = info->aZ = info->aVx= info->aVy= info->aVz = NULL ;
	info->isOrbitInterpolationDone = 0 ;

    /* Reference ellipsoid */
    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL) {
        perror("Erreur d'allocation de *info->ellRef\n") ;
        exit(-1) ;
    }

    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//ellipsoidName", ADSXMLDoc[0]))) {
        sprintf(info->ellRef->ellipsoidID, "%s", csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    else {
        sprintf(info->ellRef->ellipsoidID, "WGS84 (I suppose..)") ;
    }

    info->ellRef->a = 6.378137000000000e+06 ; // Predefined as WGS84
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//ellipsoidSemiMajorAxis", ADSXMLDoc[0]))) {
        sscanf(csv->stringVal[0], "%lf", &(info->ellRef->a)) ;
        freeCSVStruct(csv) ;
    }

    info->ellRef->b = 6.356752314245000e+06 ; // Predefined as WGS84
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//ellipsoidSemiMinorAxis", ADSXMLDoc[0]))) {
        sscanf(csv->stringVal[0], "%lf", &(info->ellRef->b)) ;
        freeCSVStruct(csv) ;
    }

    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;

	/* Geolocate scene on reference ellipsoid */
    info->sceneAverageHeight = computeAverageTerrainHeightFromS1ADS(ADSXMLDoc, info) ;
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
	info->EarthRadiusAtSceneCenter = 6371221. ;
    info->incidenceAngle[0] = 0. ;
	geolocateSceneOnEllipsoid(info, info->ellRef) ;

    /* If we deal with IW or EW data, geolocate each burs */
    if (strncmp(info->productID, "SM", 2)) {
        geolocatBursts(info) ;
    }

    /* Scene centre approxilmate location */
    area = circumscribedRectangleOfPolygon(info->loc) ;
    lat = 180./PI * (area->P[0].y + area->P[2].y) / 2. ;
    lon = 180./PI * (area->P[0].x + area->P[2].x) / 2. ;
    sprintf(info->scene_loc, "Center longitude: %.4g\tCenter latitude: %.4g", lon, lat) ;
    freePolygon(area) ;

    /* Reference range */
    info->referenceRange = 0 ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//referenceRange", ADSXMLDoc[0]))) {
        sscanf(csv->stringVal[0], "%lf", &(info->referenceRange)) ;
        freeCSVStruct(csv) ;
    }

    /* Free XML docs */
    for (i = 0; i < numberOfMDS; i++) {
        xmlFreeDoc(ADSXMLDoc[i]) ;
    }
    free(ADSXMLDoc) ;
    
    if (isValidDirectoryForPath(CADSDirectory)) {
        for (i = 0; i < numberOfMDS; i++) {
            xmlFreeDoc(CADSXMLDoc[i]) ;
        }
        free(CADSXMLDoc) ;
    }
    xmlCleanupParser();


    for (i = 0; i < numberOfMDS; i++) {
        free(ADSFileName[i]) ;
        free(CADSFilePath[i]) ;
        
    }
    free(ADSFileName) ;
    free(CADSFilePath) ;
    free(ADSDirectory) ;
    free(MDSDirectory) ;
    free(CADSDirectory) ;
    free(S1AccessPath) ;

    /* All done. */

    return(info) ;
}

CSVStruct *concatenateXMLInfoFromXMLDocsAtPath(xmlChar *anXMLPath, xmlDocPtr *xmlDoc, int numberOfEntries)
{
    int i ;
    CSVStruct *csv ;

    csv = NULL ;
    for (i = 0; i < numberOfEntries; i++) {
        csv = addCSVFromXMLFileForXPath(anXMLPath, xmlDoc[i], csv) ;
    }

    return (csv) ;
}


char *setS1HourFormatFromTimeVal(double timeVal)
{
    char *timeChar ;
    int hh, mm ;
    double ss ;
    struct divr qr ;

    timeChar = allocStringOfLength(16) ;
    qr = divr(timeVal, 3600) ;
    hh = (int)qr.q ;
    timeVal -= 3600 * hh ; ;
    qr = divr(timeVal, 60) ;
    mm = (int)qr.q ;
    ss = qr.r ;

    sprintf(timeChar, "%02d:%02d:%08.6f", hh, mm, ss) ;

    return (timeChar) ;
}


/* We will look for any required additional information to perform sound data reading */
/* Attention!!! In reference S1-RS-MDA-52-7440 (Sentinel-1 Product Definition) it is clearly stated that: */
/* Dual-polarisation products are provided in the form of two images each corresponding to a different polarisation channel (HH, VV, HV or VH). */
/* The images have the same product characteristics and are co-registered. */
/* Consequently, we consider that we only have to look inside the firsts MDS corresponding to the first polarisation scheme to get all what we need */
/* In other words, perfect burst synchronisation between polarisation scheme is expected. */
/* All parameters for same swath and same bursts are considered identicals whatever the polarisation */
S1AdditionalInfo *allocS1Specific(int numberOfLayers, int numberOfSubSwaths)
{
    int swathIndex ;
    S1AdditionalInfo *S1Specific ;

    /* S1Specific structure initialisation */
    if((S1Specific = malloc(sizeof(S1AdditionalInfo))) == NULL) {
        perror("Failed to allocate S1 specific structure") ;
        exit(-1) ;
    }

    S1Specific->numberOfLayers = numberOfLayers ;
    S1Specific->selectedLayer = -1 ;
    S1Specific->numberOfSubSwaths = numberOfSubSwaths ;
    S1Specific->firstSwathIndex = 0 ;
    S1Specific->lastSwathIndex = numberOfSubSwaths - 1 ;
    S1Specific->numberOfBursts = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->swathXDim = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->azimuthSteeringRate = vectorDouble(0, numberOfSubSwaths - 1) ;
    S1Specific->nearRangeTime = vectorDouble(0, numberOfSubSwaths - 1) ;
    S1Specific->rangeBandwidth = vectorDouble(0, numberOfSubSwaths - 1) ;
    S1Specific->rangeApodizationCoefficient = vectorDouble(0, numberOfSubSwaths - 1) ;
    S1Specific->azimuthBandwidth = vectorDouble(0, numberOfSubSwaths - 1) ;
    S1Specific->dcEstimates = malloc(numberOfSubSwaths * sizeof(perBurstDCEstimates)) ;
    S1Specific->firstRangePixelIndexForSubSwath = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->lastRangePixelIndexForSubSwath = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->firstValidSampleForSubSwath = vectorInt(0, numberOfSubSwaths - 1) ;
    S1Specific->lastValidSampleForSubSwath = vectorInt(0, numberOfSubSwaths - 1) ;
    S1Specific->numberOfValidSamples = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->superpositionStartIndex = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->superpositionEndIndex = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->superpositionWidth = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->midSuperpositionIndex = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->firstAzimuthLineIndexForSubSwath = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->lastAzimuthLineIndexForSubSwath = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->swathAzimuthSize = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
    S1Specific->azimuthFmRate = malloc(numberOfSubSwaths * sizeof(azimuthFmRateType)) ;

    S1Specific->calibrationXGridDim = NULL ;
    S1Specific->calibrationYGridDim = NULL ;
    S1Specific->calibrationRangeIndex = NULL ;
    S1Specific->calibrationAzimuthIndex = NULL ;
    S1Specific->sigmaNought = NULL ;
    S1Specific->betaNought = NULL ;
    S1Specific->gamma = NULL ;
    S1Specific->dn = NULL ;


    S1Specific->FPAT = S1Specific->anxFPAT = 86400 ;
    S1Specific->LPAT = 0. ;

    S1Specific->burstList = malloc(numberOfSubSwaths * sizeof(burstDescriptor *)) ;
    for (swathIndex = 0; swathIndex < numberOfSubSwaths; swathIndex++) {
        S1Specific->burstList[swathIndex] = NULL ;
    }

    return S1Specific ;
}

burstDescriptor *allocBurstDescriptor(burstDescriptor *preceedingBurst)
{
    burstDescriptor *aBurst ;

    if((aBurst = malloc(sizeof(burstDescriptor))) == NULL)
        ase("Failed to allocate burst descriptor") ;

    aBurst->burstIndex = 0 ;
    if (preceedingBurst) {
        aBurst->burstIndex = preceedingBurst->burstIndex + 1 ;
        preceedingBurst->nextBurst = aBurst ;
    }
    aBurst->isSelected = 0 ;
    aBurst->rangeShift = 0 ;
    aBurst->burstLocation = allocQuadrilateral() ;
    aBurst->burstImage = NULL ;
    aBurst->file = NULL ;
    aBurst->T = NULL ;
    aBurst->deramping = NULL ;
    aBurst->preceedingBurst = preceedingBurst ;
    aBurst->nextBurst = NULL ;
    aBurst->masterBurst = NULL ;
    aBurst->slaveBurst = NULL ;
    aBurst->dcPolynomial = NULL ;
    aBurst->ETAD = NULL ;

    return (aBurst) ;
}

void freeBurstDescriptor(burstDescriptor *currentBurst)
{
    int unsigned layerIndex ;

    if(currentBurst->burstLocation) {
        freePolygon(currentBurst->burstLocation) ;
    }

    if (currentBurst->file) {
        for (layerIndex = 0; layerIndex < currentBurst->numberOfLayers; layerIndex++) {
            if (currentBurst->file[layerIndex]) {
                freeRawFileDescriptor(currentBurst->file[layerIndex]) ;
            }
        }
    }
    free(currentBurst->file) ;

    if (currentBurst->burstImage) {
        freeCSLImageStructure(currentBurst->burstImage) ;
    }

    if (currentBurst->firstValidSample) {
        freeVectorInt(currentBurst->firstValidSampleOfLine, 0) ;
    }

    if (currentBurst->lastValidSampleOfLine) {
        freeVectorInt(currentBurst->lastValidSampleOfLine, 0) ;
    }

    if (currentBurst->T) {
        freeMatrixDouble(currentBurst->T, 0, 0) ;
    }

    if (currentBurst->deramping) {
        freeDerampingStruct(currentBurst->deramping) ;
    }

    if (currentBurst->dcPolynomial) {
        freeXPolynomial(currentBurst->dcPolynomial) ;
    }

    if (currentBurst->ETAD) {
        freeETADLayersStruct(currentBurst->ETAD) ;
    }
    
    

    free(currentBurst) ;
}

void freeBurstDescriptorList(burstDescriptor *firstBurst)
{
    burstDescriptor *currentBurst, *nextBurst ;

    currentBurst = firstBurst ;
    while (currentBurst) {
        nextBurst = currentBurst->nextBurst ;
        freeBurstDescriptor(currentBurst) ;
        currentBurst = nextBurst ;
    }
}

void freeAllBursts(S1AdditionalInfo *S1Specific)
{
    int unsigned swathIndex ;

    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        freeBurstDescriptorList(S1Specific->burstList[swathIndex]) ;
    }
}

S1AdditionalInfo *allocAndInitS1Specifics(int unsigned numberOfLayers, int unsigned numberOfSubSwaths, xmlDocPtr *ADSXMLDoc, xmlDocPtr *CADSXMLDoc)
{
    char *dcPolynomialName ;
    int  unsigned uj, swathIndex, burstIndex, lineIndex ;
    int j, k, dcMethod ;
    int calibrationVectorsCount, calibrationVectorLength, calibrationAzimuthIndex, calibrationRangeIndex ;
    int linesPerBurst, samplesPerBurst ;
    int firstRangePixelIndexForSubSwath, lastRangePixelIndexForSubSwath ;
    CSVStruct *csv, *csv2 ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst, *preceedingBurst ;

    S1Specific = allocS1Specific(numberOfLayers, numberOfSubSwaths) ;
    S1Specific->numberOfLayers = numberOfLayers ;

    /* Calibration LUT allocation */
    if (CADSXMLDoc) {
        S1Specific->calibrationXGridDim = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
        S1Specific->calibrationYGridDim = vectorIntUnsigned(0, numberOfSubSwaths - 1) ;
        S1Specific->calibrationRangeIndex = malloc(numberOfSubSwaths * sizeof(double **)) ;
        S1Specific->calibrationAzimuthIndex = malloc(numberOfSubSwaths * sizeof(double *)) ;
        S1Specific->sigmaNought = malloc(numberOfSubSwaths * sizeof(double **)) ;
        S1Specific->betaNought = malloc(numberOfSubSwaths * sizeof(double **)) ;
        S1Specific->gamma = malloc(numberOfSubSwaths * sizeof(double **)) ;
        S1Specific->dn = malloc(numberOfSubSwaths * sizeof(double **)) ;
    }

    /* We need the azimuth time interval */
    csv = getCSVForPathInADS("//imageAnnotation/imageInformation/azimuthTimeInterval", ADSXMLDoc[0]) ;
    sscanf(csv->stringVal[0], "%lf", &S1Specific->lineTimeInterval) ;
    freeCSVStruct(csv) ;

    /* Range sampling frequency */
    S1Specific->rangeSamplingFrequency = 0. ;
    csv = getCSVForPathInADS("//generalAnnotation/productInformation/rangeSamplingRate", ADSXMLDoc[0]) ;
    sscanf(csv->stringVal[0], "%lf", &(S1Specific->rangeSamplingFrequency)) ;
    freeCSVStruct(csv) ;

    /* Two way range time */
    csv = getCSVForPathInADS("//imageAnnotation/imageInformation/slantRangeTime", ADSXMLDoc[0]) ;
    sscanf(csv->stringVal[0], "%lf", &(S1Specific->twoWayRangeTime)) ;
    freeCSVStruct(csv) ;


    /* Which DC method? */
    /* **************** */
    csv = getCSVForPathInADS("//dcMethod", ADSXMLDoc[0]) ;
    /* dcMethod is either "Data Analysis" or "Orbit and Attitude" or "Predefined" */
    /* strncmp will lead to a negative, a null or a positive value respectively */
    dcMethod = strncmp(csv->stringVal[0], "O", 1) ;
    if (dcMethod) {
        if (dcMethod < 0) {
            dcPolynomialName = initStringWithString("//dataDcPolynomial") ;
        }
        else    /* In case dcMethod is predefined, we select the geometry polynomial because there is no definition of preselected values in format document... */
            dcPolynomialName = initStringWithString("//geometryDcPolynomial") ;
    }
    else
        dcPolynomialName = initStringWithString("//geometryDcPolynomial") ;
    freeCSVStruct(csv) ;

    /* Read, alloc and init per swath and per burst info */
    /* ************************************************* */
    /* Read number of burst per swath */
    csv = NULL ;
    for (swathIndex = 0; swathIndex < numberOfSubSwaths; swathIndex++) {
        if((csv = getAttributeInXMLDocForXPath((xmlChar *)"//burstList[@count]", ADSXMLDoc[swathIndex])) == NULL) {
            perror("Failed to read //burstList[@count] in ADS");
            exit(-1) ;
        }
        sscanf(csv->stringVal[0], "%d", &S1Specific->numberOfBursts[swathIndex]) ;
        freeCSVStruct(csv) ;
    }

    for (swathIndex = 0; swathIndex < numberOfSubSwaths; swathIndex++) {
        /* Azimuth steering rate */
        S1Specific->azimuthSteeringRate[swathIndex] = 0. ;
        csv = getCSVForPathInADS("//generalAnnotation/productInformation/azimuthSteeringRate", ADSXMLDoc[swathIndex]) ;
        sscanf(csv->stringVal[0], "%lf", S1Specific->azimuthSteeringRate + swathIndex) ;
        S1Specific->azimuthSteeringRate[swathIndex] *= PI / 180. ;
        freeCSVStruct(csv) ;

        /* read range bandwith for this swath */
        csv = getCSVForPathInADS("//rangeProcessing/processingBandwidth", ADSXMLDoc[swathIndex]) ;
        sscanf(csv->stringVal[0], "%lf", &S1Specific->rangeBandwidth[swathIndex]) ;
        freeCSVStruct(csv) ;

        /* read range apodization coefficient for this swath */
        csv = getCSVForPathInADS("//rangeProcessing/windowCoefficient", ADSXMLDoc[swathIndex]) ;
        sscanf(csv->stringVal[0], "%lf", &S1Specific->rangeApodizationCoefficient[swathIndex]) ;
        freeCSVStruct(csv) ;

        /* Read azimuth bandwidth for this swath */
        csv = getCSVForPathInADS("//azimuthProcessing/processingBandwidth", ADSXMLDoc[swathIndex]) ;
        sscanf(csv->stringVal[0], "%lf", &S1Specific->azimuthBandwidth[swathIndex]) ;
        freeCSVStruct(csv) ;

        if (S1Specific->numberOfBursts[swathIndex]) {
            /* Read number of lines per burst */
            csv = getCSVForPathInADS("//linesPerBurst", ADSXMLDoc[swathIndex]) ;
            sscanf(csv->stringVal[0], "%d", &linesPerBurst) ;
            freeCSVStruct(csv) ;

            /* Read number of samples per line */
            csv = getCSVForPathInADS("//samplesPerBurst", ADSXMLDoc[swathIndex]) ;
            sscanf(csv->stringVal[0], "%d", &samplesPerBurst) ;
            freeCSVStruct(csv) ;

            csv = getCSVForPathInADS("//imageInformation/slantRangeTime", ADSXMLDoc[swathIndex]) ;
            sscanf(csv->stringVal[0], "%lf", &S1Specific->nearRangeTime[swathIndex]) ;
            freeCSVStruct(csv) ;

            /* Determine first and last range index for each subswath */
            S1Specific->swathXDim[swathIndex] = samplesPerBurst ;
            firstRangePixelIndexForSubSwath = (int)round((S1Specific->nearRangeTime[swathIndex] - S1Specific->nearRangeTime[0]) * S1Specific->rangeSamplingFrequency) ;
            lastRangePixelIndexForSubSwath = firstRangePixelIndexForSubSwath + samplesPerBurst - 1 ;
            S1Specific->firstRangePixelIndexForSubSwath[swathIndex] = firstRangePixelIndexForSubSwath ;
            S1Specific->lastRangePixelIndexForSubSwath[swathIndex] = lastRangePixelIndexForSubSwath ;
            S1Specific->rangeIndexStart = 0 ;

            /* Read burst azimuth start time */
            csv = getCSVForPathInADS("//burst/azimuthTime", ADSXMLDoc[swathIndex]) ;
            csv2 = getCSVForPathInADS("//burst/azimuthAnxTime", ADSXMLDoc[swathIndex]) ;

            currentBurst = preceedingBurst = S1Specific->burstList[swathIndex] ;
            for (burstIndex = 0; burstIndex < S1Specific->numberOfBursts[swathIndex]; burstIndex++) {
                /* Burst chaine allocation and initialization */
                currentBurst = allocBurstDescriptor(preceedingBurst) ;
                currentBurst->frameIndex = 0 ;
                currentBurst->swathIndex = swathIndex ;
                currentBurst->isSelected = 1 ;
                currentBurst->xDim = samplesPerBurst ;
                currentBurst->yDim = linesPerBurst ;
                currentBurst->firstValidSample = 0 ;
                currentBurst->lastValidSample = samplesPerBurst - 1 ;
                currentBurst->firstValidSampleOfLine = vectorInt(0, currentBurst->yDim - 1) ;
                currentBurst->lastValidSampleOfLine = vectorInt(0, currentBurst->yDim - 1) ;
                currentBurst->rangeSamplingFrequency = S1Specific->rangeSamplingFrequency ;
                currentBurst->azimuthSamplingFrequency = 1. / S1Specific->lineTimeInterval ;
                currentBurst->FPAT = getSecondsFromFormattedDate(csv->stringVal[burstIndex]) ;
                sscanf(csv2->stringVal[burstIndex], "%lf", &currentBurst->anxFPAT) ;
                currentBurst->LPAT = currentBurst->FPAT + (linesPerBurst - 1) * S1Specific->lineTimeInterval ;
                currentBurst->MPAT = currentBurst->FPAT + linesPerBurst * S1Specific->lineTimeInterval / 2. ;
                S1Specific->FPAT = (S1Specific->FPAT > currentBurst->FPAT)? currentBurst->FPAT : S1Specific->FPAT ;
                S1Specific->LPAT = (S1Specific->LPAT < currentBurst->LPAT)? currentBurst->LPAT : S1Specific->LPAT ;
                S1Specific->anxFPAT = (S1Specific->anxFPAT > currentBurst->anxFPAT)? currentBurst->anxFPAT : S1Specific->anxFPAT ;
                currentBurst->firstRangeIndex = firstRangePixelIndexForSubSwath ;
                currentBurst->lastRangeIndex = lastRangePixelIndexForSubSwath ;
                currentBurst->FPRT = S1Specific->nearRangeTime[swathIndex] ;
                currentBurst->LPRT = currentBurst->FPRT + (currentBurst->xDim - 1) / S1Specific->rangeSamplingFrequency ;
                currentBurst->numberOfLayers = S1Specific->numberOfLayers ;
                currentBurst->file = calloc(S1Specific->numberOfLayers, sizeof(rawFileDescriptor *)) ;
                currentBurst->rangeTransformConstantTerm = 0 ;

                preceedingBurst = currentBurst ;
                if (!S1Specific->burstList[swathIndex]) {
                    S1Specific->burstList[swathIndex] = preceedingBurst ;
                }
            }
            freeCSVStruct(csv) ;
            freeCSVStruct(csv2) ;

            /* Reading of first and last valid pixel index for each line of each burst */

            /* Read firstValidSampleOfLine vectors for each burst in each MDS */
            S1Specific->firstValidSampleForSubSwath[swathIndex] = 0 ;
            csv = getCSVForPathInADS("//burst/firstValidSample", ADSXMLDoc[swathIndex]) ;
            for (burstIndex = 0; burstIndex < S1Specific->numberOfBursts[swathIndex]; burstIndex++) {
                if ((csv2 = readWhiteCharSeperatedValuesInString(csv->stringVal[burstIndex])) == NULL) {
                    perror("Failed to read firstValidSample vector") ;
                    exit(-1) ;
                }

                /* Get current burst descriptor */
                currentBurst = getBurstAtIndex(S1Specific->burstList[swathIndex], burstIndex) ;

                /* Read firstValidSampleOfLine vector for current burst */
                for (lineIndex = 0; lineIndex < currentBurst->yDim; lineIndex++) {
                    sscanf(csv2->stringVal[lineIndex], "%d", currentBurst->firstValidSampleOfLine + lineIndex) ;
                }
                lineIndex = 0 ;
                while (currentBurst->firstValidSampleOfLine[lineIndex] == -1) {
                    lineIndex++ ;
                }
                currentBurst->firstValidLine = lineIndex ;
                while (currentBurst->firstValidSampleOfLine[lineIndex] != -1) {
                    currentBurst->firstValidSample = (currentBurst->firstValidSample < currentBurst->firstValidSampleOfLine[lineIndex])? currentBurst->firstValidSampleOfLine[lineIndex] : currentBurst->firstValidSample ;
                    lineIndex++ ;
                }
                currentBurst->firstValidSample ++ ;
                currentBurst->lastValidLine = lineIndex - 1 ;

                S1Specific->firstValidSampleForSubSwath[swathIndex] = (S1Specific->firstValidSampleForSubSwath[swathIndex] < currentBurst->firstValidSample)? currentBurst->firstValidSample : S1Specific->firstValidSampleForSubSwath[swathIndex] ;

                freeCSVStruct(csv2 );
            }
            freeCSVStruct(csv) ;
            /* Compute swath superposition start indexes */
            S1Specific->superpositionStartIndex[swathIndex] = S1Specific->firstRangePixelIndexForSubSwath[swathIndex] + S1Specific->firstValidSampleForSubSwath[swathIndex] - S1Specific->firstRangePixelIndexForSubSwath[S1Specific->firstSwathIndex] ;

            /* Read lastValidSampleOfLine vectors for each burst in each MDS */
            S1Specific->lastValidSampleForSubSwath[swathIndex] = INT32_MAX ;
            csv = getCSVForPathInADS("//burst/lastValidSample", ADSXMLDoc[swathIndex]) ;
            for (burstIndex = 0; burstIndex < S1Specific->numberOfBursts[swathIndex]; burstIndex++) {
                if ((csv2 = readWhiteCharSeperatedValuesInString(csv->stringVal[burstIndex])) == NULL) {
                    perror("Failed to read lastValidSample vector") ;
                    exit(-1) ;
                }

                /* Get current burst descriptor */
                currentBurst = getBurstAtIndex(S1Specific->burstList[swathIndex], burstIndex) ;
                /* Read firstValidSampleOfLine vector for current burst */
                for (lineIndex = 0; lineIndex < currentBurst->yDim; lineIndex++) {
                    sscanf(csv2->stringVal[lineIndex], "%d", currentBurst->lastValidSampleOfLine + lineIndex) ;
                    if (currentBurst->lastValidSampleOfLine[lineIndex] != -1) {
                        currentBurst->lastValidSample = (currentBurst->lastValidSample > currentBurst->lastValidSampleOfLine[lineIndex])? currentBurst->lastValidSampleOfLine[lineIndex] : currentBurst->lastValidSample ;
                    }
                }
                currentBurst->lastValidSample -- ;
                currentBurst->numberOfValidSamples = currentBurst->lastValidSample - currentBurst->firstValidSample + 1 ;

                S1Specific->lastValidSampleForSubSwath[swathIndex] = (S1Specific->lastValidSampleForSubSwath[swathIndex] > currentBurst->lastValidSample)? currentBurst->lastValidSample : S1Specific->lastValidSampleForSubSwath[swathIndex] ;
                
                freeCSVStruct(csv2 );
            }
            freeCSVStruct(csv) ; 

            S1Specific->numberOfValidSamples[swathIndex] = S1Specific->lastValidSampleForSubSwath[swathIndex] - S1Specific->firstValidSampleForSubSwath[swathIndex] + 1 ;
            /* Compute swath superposition indexes, which are located in next swath */
            if (swathIndex != S1Specific->firstSwathIndex) {
                S1Specific->superpositionEndIndex[swathIndex] = S1Specific->firstRangePixelIndexForSubSwath[swathIndex - 1] + S1Specific->lastValidSampleForSubSwath[swathIndex - 1] - S1Specific->firstRangePixelIndexForSubSwath[S1Specific->firstSwathIndex];
                S1Specific->superpositionWidth[swathIndex] = S1Specific->superpositionEndIndex[swathIndex] - S1Specific->superpositionStartIndex[swathIndex] + 1 ;
                S1Specific->midSuperpositionIndex[swathIndex] = S1Specific->superpositionStartIndex[swathIndex] + S1Specific->superpositionWidth[swathIndex] / 2 ;
            }
        }
        else {
            csv = getCSVForPathInADS("//productFirstLineUtcTime", ADSXMLDoc[0]) ;
            S1Specific->FPAT = getSecondsFromFormattedDate(csv->stringVal[0]) ;
            freeCSVStruct(csv) ;
            csv = getCSVForPathInADS("//productLastLineUtcTime", ADSXMLDoc[0]) ;
            S1Specific->LPAT = getSecondsFromFormattedDate(csv->stringVal[0]) ;
            freeCSVStruct(csv) ;
            csv = getCSVForPathInADS("//imageInformation/numberOfSamples", ADSXMLDoc[swathIndex]) ;
            sscanf(csv->stringVal[0], "%d", &S1Specific->swathXDim[swathIndex]) ;
            S1Specific->rangeDimension = S1Specific->swathXDim[swathIndex] ;
            S1Specific->lastRangePixelIndexForSubSwath[0] = S1Specific->rangeDimension - 1 ;
            freeCSVStruct(csv) ;
        }

        /* Allocate DC estimates and read azimuth times */
        /* Allocate DC estimates for this burst */
        csv = getCSVForPathInADS("//dcEstimate/azimuthTime", ADSXMLDoc[swathIndex]) ;
        S1Specific->dcEstimates[swathIndex].numberOfEstimates = csv->numberOfEntries ;
        S1Specific->dcEstimates[swathIndex].azimuthTime = vectorDouble(0, S1Specific->dcEstimates[swathIndex].numberOfEstimates - 1) ;
        S1Specific->dcEstimates[swathIndex].t0 = vectorDouble(0, S1Specific->dcEstimates[swathIndex].numberOfEstimates - 1) ;

        /* Allocate polynomial coefficients */
        if((S1Specific->dcEstimates[swathIndex].dcPolynomial = malloc(S1Specific->dcEstimates[swathIndex].numberOfEstimates * sizeof(xPolynomial *))) == NULL) {
            perror("Failed to alocate DC polynomial") ;
            exit(-1) ;
        }

        /* Read dc polynomials azimuth time */
        for (uj = 0; uj < S1Specific->dcEstimates[swathIndex].numberOfEstimates; uj++) {
            S1Specific->dcEstimates[swathIndex].azimuthTime[uj] = getSecondsFromFormattedDate(csv->stringVal[uj]) ;
        }
        freeCSVStruct(csv) ;


        /* Read dc estimate time origins t0 */
        csv = getCSVForPathInADS("//dcEstimate/t0", ADSXMLDoc[swathIndex]) ;
        for (uj = 0; uj < S1Specific->dcEstimates[swathIndex].numberOfEstimates; uj++) {
            sscanf(csv->stringVal[uj], "%lf", &(S1Specific->dcEstimates[swathIndex].t0[uj])) ;
        }
        freeCSVStruct(csv ) ;

        /* Read dc polynomials for each bursts (It is not said that there is one polynomial per burst. Therefore we use the number of entries) */
        csv = getCSVForPathInADS(dcPolynomialName, ADSXMLDoc[swathIndex]) ;
        for (j = 0; j < csv->numberOfEntries; j++) {
            if ((csv2 = readWhiteCharSeperatedValuesInString(csv->stringVal[j])) == NULL) {
                perror("Failed to read dc polynomial coefficients") ;
                exit(-1) ;
            }
            S1Specific->dcEstimates[swathIndex].dcPolynomial[j] = allocXPolynomialOfOrder(csv2->numberOfEntries - 1) ;
            for (k = 0; k < csv2->numberOfEntries; k++) {
                sscanf(csv2->stringVal[k], "%lf", &(S1Specific->dcEstimates[swathIndex].dcPolynomial[j]->coefs[k])) ;
            }
            freeCSVStruct(csv2) ;
        }
        freeCSVStruct(csv) ;

        /* Azimuth FM rate polynomials */
        /* *************************** */
        /* Read number of azimuth FM rate polynomials */
        if((csv = getAttributeInXMLDocForXPath((xmlChar *)"//azimuthFmRateList[@count]", ADSXMLDoc[swathIndex])) == NULL) {
            perror("Failed to read //azimuthFmRateList[@count] in ADS") ;
            exit(-1) ;
        }
        sscanf(csv->stringVal[0], "%d", &S1Specific->azimuthFmRate[swathIndex].numberOfRecords) ;
        freeCSVStruct(csv) ;

        /* Allocate Azimuth FM rate records */
        S1Specific->azimuthFmRate[swathIndex].azimuthTime = vectorDouble(0, S1Specific->azimuthFmRate[swathIndex].numberOfRecords - 1) ;
        S1Specific->azimuthFmRate[swathIndex].t0 = vectorDouble(0, S1Specific->azimuthFmRate[swathIndex].numberOfRecords - 1) ;

        /* Allocate polynomial coefficients */
        if((S1Specific->azimuthFmRate[swathIndex].azimuthFmratePolynomial = malloc(S1Specific->azimuthFmRate[swathIndex].numberOfRecords * sizeof(xPolynomial *))) == NULL) {
            perror("Failed to alocate azimuth FM rate polynomials") ;
            exit(-1) ;
        }

        /* Read azimuth FM rate polynomials azimuth time */
        csv = getCSVForPathInADS("//azimuthFmRateList/azimuthFmRate/azimuthTime", ADSXMLDoc[swathIndex]) ;
        for (uj = 0; uj < S1Specific->azimuthFmRate[swathIndex].numberOfRecords; uj++) {
            S1Specific->azimuthFmRate[swathIndex].azimuthTime[uj] = getSecondsFromFormattedDate(csv->stringVal[uj]) ;
        }
        freeCSVStruct(csv) ;


        /* Read azimuth FM rate polynomials time origins t0 */
        csv = getCSVForPathInADS("//azimuthFmRateList/azimuthFmRate/t0", ADSXMLDoc[swathIndex]) ;
        for (uj = 0; uj < S1Specific->azimuthFmRate[swathIndex].numberOfRecords; uj++) {
            sscanf(csv->stringVal[uj], "%lf", &(S1Specific->azimuthFmRate[swathIndex].t0[uj])) ;
        }
        freeCSVStruct(csv ) ;

        /* Allocate FM Rate polynomials */
        for (uj = 0; uj < S1Specific->azimuthFmRate[swathIndex].numberOfRecords; uj++) {
            S1Specific->azimuthFmRate[swathIndex].azimuthFmratePolynomial[uj] = allocXPolynomialOfOrder(2) ;
        }

        /* Read azimuth FM rate polynomials coefficient c0 */
        csv = readCSVInXMLFileForXPath((xmlChar*)"//azimuthFmRateList/azimuthFmRate/c0", ADSXMLDoc[swathIndex]) ;
        if (csv != NULL) {
            /* if not null, it means that azimuth FM rate is well coded as c0, C1 and C2 xml independent values */
            for (uj = 0; uj < S1Specific->azimuthFmRate[swathIndex].numberOfRecords; uj++) {
                sscanf(csv->stringVal[uj], "%lf", &(S1Specific->azimuthFmRate[swathIndex].azimuthFmratePolynomial[uj]->coefs[0])) ;
            }
            freeCSVStruct(csv ) ;

            /* Read azimuth FM rate polynomials coefficient c1 */
            csv = getCSVForPathInADS("//azimuthFmRateList/azimuthFmRate/c1", ADSXMLDoc[swathIndex]) ;
            for (uj = 0; uj < S1Specific->azimuthFmRate[swathIndex].numberOfRecords; uj++) {
                sscanf(csv->stringVal[uj], "%lf", &(S1Specific->azimuthFmRate[swathIndex].azimuthFmratePolynomial[uj]->coefs[1])) ;
            }
            freeCSVStruct(csv ) ;

            /* Read azimuth FM rate polynomials coefficient c2 */
            csv = getCSVForPathInADS("//azimuthFmRateList/azimuthFmRate/c2", ADSXMLDoc[swathIndex]) ;
            for (uj = 0; uj < S1Specific->azimuthFmRate[swathIndex].numberOfRecords; uj++) {
                sscanf(csv->stringVal[uj], "%lf", &(S1Specific->azimuthFmRate[swathIndex].azimuthFmratePolynomial[uj]->coefs[2])) ;
            }
            freeCSVStruct(csv ) ;
        }
        else {
        /* if csv is null, we will test if coefficients are saved in the new format, i.e. as white character separated values */
            csv = getCSVForPathInADS("//azimuthFmRateList/azimuthFmRate/azimuthFmRatePolynomial", ADSXMLDoc[swathIndex]) ;
            for (uj = 0; uj < S1Specific->azimuthFmRate[swathIndex].numberOfRecords; uj++) {
                if ((csv2 = readWhiteCharSeperatedValuesInString(csv->stringVal[uj])) == NULL) {
                    perror("Failed to read azimuthFmRatePolynomial vector") ;
                    exit(-1) ;
                }
                if (csv2->numberOfEntries != 3) {
                    perror("Incorrect size for azimuthFmRatePolynomial vector") ;
                    exit(-1) ;
                }
                for (k = 0; k < 3; k++) {
                    sscanf(csv2->stringVal[k], "%lf", &S1Specific->azimuthFmRate[swathIndex].azimuthFmratePolynomial[uj]->coefs[k]) ;
                }
                freeCSVStruct(csv2 );
            }
            freeCSVStruct(csv ) ;
        }
    }
    /* Now that we have read all swath info, we have the range dimension of the scene */
    S1Specific->rangeDimension = S1Specific->lastRangePixelIndexForSubSwath[numberOfSubSwaths - 1] + 1 ;

    /* Calibration LUT reading */
    /* *********************** */
    for (swathIndex = 0; swathIndex < numberOfSubSwaths; swathIndex++) {
        if (CADSXMLDoc) {
            /* Read number of calibration vectors */
            if((csv = getAttributeInXMLDocForXPath((xmlChar *)"//calibrationVectorList[@count]", CADSXMLDoc[swathIndex])) == NULL) {
                perror("Failed to read //calibrationVectorList[@count] in ADS");
                exit(-1) ;
            }
            sscanf(csv->stringVal[0], "%d", &calibrationVectorsCount) ;
            S1Specific->calibrationYGridDim[swathIndex] = calibrationVectorsCount ;
            freeCSVStruct(csv) ;

            /* Read calibration vector length */
            /* We suppose this length is a constant within a swath */
            if((csv = getAttributeInXMLDocForXPath((xmlChar *)"//calibrationVector/pixel[@count]", CADSXMLDoc[swathIndex])) == NULL) {
                perror("Failed to read //calibrationVectorList/pixel[@count] in ADS");
                exit(-1) ;
            }
            sscanf(csv->stringVal[0], "%d", &calibrationVectorLength) ;
            S1Specific->calibrationXGridDim[swathIndex] = calibrationVectorLength ;
            freeCSVStruct(csv) ;

            S1Specific->calibrationRangeIndex[swathIndex] = matrixDouble(0, calibrationVectorsCount - 1, 0, calibrationVectorLength - 1) ;
            S1Specific->calibrationAzimuthIndex[swathIndex] = vectorDouble(0, calibrationVectorLength - 1) ;
            S1Specific->sigmaNought[swathIndex] = matrixDouble(0, calibrationVectorsCount - 1, 0, calibrationVectorLength - 1) ;
            S1Specific->betaNought[swathIndex] = matrixDouble(0, calibrationVectorsCount - 1, 0, calibrationVectorLength - 1) ;
            S1Specific->gamma[swathIndex] = matrixDouble(0, calibrationVectorsCount - 1, 0, calibrationVectorLength - 1) ;
            S1Specific->dn[swathIndex] = matrixDouble(0, calibrationVectorsCount - 1, 0, calibrationVectorLength - 1) ;

            /* Read calibration range index vectors */
            csv = getCSVForPathInADS("//calibrationVector/pixel", CADSXMLDoc[swathIndex]) ;
            for (calibrationAzimuthIndex = 0; calibrationAzimuthIndex < calibrationVectorsCount; calibrationAzimuthIndex++) {
                if ((csv2 = readWhiteCharSeperatedValuesInString(csv->stringVal[calibrationAzimuthIndex])) == NULL) {
                    perror("Failed to read calibration range index vector") ;
                    exit(-1) ;
                }
                for (calibrationRangeIndex = 0; calibrationRangeIndex < calibrationVectorLength; calibrationRangeIndex++) {
                    if (calibrationRangeIndex <= csv2->numberOfEntries) {
                        sscanf(csv2->stringVal[calibrationRangeIndex], "%lf", S1Specific->calibrationRangeIndex[swathIndex][calibrationAzimuthIndex] + calibrationRangeIndex) ;
                    }
                }
                freeCSVStruct(csv2) ;
            }
            freeCSVStruct(csv) ;

            /* Read calibration azimuth index */
            /* The given index value does not corresponds to the zero Doppler azimuth time. Therefore, we read this latter one and convert it in azimuth index */
            csv = getCSVForPathInADS("//calibrationVector/azimuthTime", CADSXMLDoc[swathIndex]) ;
            for (calibrationAzimuthIndex = 0; calibrationAzimuthIndex < calibrationVectorsCount; calibrationAzimuthIndex++) {
                S1Specific->calibrationAzimuthIndex[swathIndex][calibrationAzimuthIndex] = (getSecondsFromFormattedDate(csv->stringVal[calibrationAzimuthIndex]) - S1Specific->FPAT) / S1Specific->lineTimeInterval ;
            }
            freeCSVStruct(csv) ;

            /* Read sigma0 LUT */
            csv = getCSVForPathInADS("//calibrationVector/sigmaNought", CADSXMLDoc[swathIndex]) ;
            for (calibrationAzimuthIndex = 0; calibrationAzimuthIndex < calibrationVectorsCount; calibrationAzimuthIndex++) {
                if ((csv2 = readWhiteCharSeperatedValuesInString(csv->stringVal[calibrationAzimuthIndex])) == NULL) {
                    perror("Failed to read sigma0 LUT") ;
                    exit(-1) ;
                }
                for (calibrationRangeIndex = 0; calibrationRangeIndex < calibrationVectorLength; calibrationRangeIndex++) {
                    if (calibrationRangeIndex <= csv2->numberOfEntries) {
                        sscanf(csv2->stringVal[calibrationRangeIndex], "%lf", S1Specific->sigmaNought[swathIndex][calibrationAzimuthIndex] + calibrationRangeIndex) ;
                    }
                }
                freeCSVStruct(csv2) ;
            }
            freeCSVStruct(csv) ;

            /* Read beta0 LUT */
            csv = getCSVForPathInADS("//calibrationVector/betaNought", CADSXMLDoc[swathIndex]) ;
            for (calibrationAzimuthIndex = 0; calibrationAzimuthIndex < calibrationVectorsCount; calibrationAzimuthIndex++) {
                if ((csv2 = readWhiteCharSeperatedValuesInString(csv->stringVal[calibrationAzimuthIndex])) == NULL) {
                    perror("Failed to read beta0 LUT") ;
                    exit(-1) ;
                }
                for (calibrationRangeIndex = 0; calibrationRangeIndex < calibrationVectorLength; calibrationRangeIndex++) {
                    if (calibrationRangeIndex <= csv2->numberOfEntries) {
                        sscanf(csv2->stringVal[calibrationRangeIndex], "%lf", S1Specific->betaNought[swathIndex][calibrationAzimuthIndex] + calibrationRangeIndex) ;
                    }
                }
                freeCSVStruct(csv2) ;
            }
            freeCSVStruct(csv) ;

            /* Read gamma LUT */
            csv = getCSVForPathInADS("//calibrationVector/gamma", CADSXMLDoc[swathIndex]) ;
            for (calibrationAzimuthIndex = 0; calibrationAzimuthIndex < calibrationVectorsCount; calibrationAzimuthIndex++) {
                if ((csv2 = readWhiteCharSeperatedValuesInString(csv->stringVal[calibrationAzimuthIndex])) == NULL) {
                    perror("Failed to read gamma LUT") ;
                    exit(-1) ;
                }
                for (calibrationRangeIndex = 0; calibrationRangeIndex < calibrationVectorLength; calibrationRangeIndex++) {
                    if (calibrationRangeIndex <= csv2->numberOfEntries) {
                        sscanf(csv2->stringVal[calibrationRangeIndex], "%lf", S1Specific->gamma[swathIndex][calibrationAzimuthIndex] + calibrationRangeIndex) ;
                    }
                }
                freeCSVStruct(csv2) ;
            }
            freeCSVStruct(csv) ;

            /* Read dn LUT */
            csv = getCSVForPathInADS("//calibrationVector/dn", CADSXMLDoc[swathIndex]) ;
            for (calibrationAzimuthIndex = 0; calibrationAzimuthIndex < calibrationVectorsCount; calibrationAzimuthIndex++) {
                if ((csv2 = readWhiteCharSeperatedValuesInString(csv->stringVal[calibrationAzimuthIndex])) == NULL) {
                    perror("Failed to read dn LUT") ;
                    exit(-1) ;
                }
                for (calibrationRangeIndex = 0; calibrationRangeIndex < calibrationVectorLength; calibrationRangeIndex++) {
                    if (calibrationRangeIndex <= csv2->numberOfEntries) {
                        sscanf(csv2->stringVal[calibrationRangeIndex], "%lf", S1Specific->dn[swathIndex][calibrationAzimuthIndex] + calibrationRangeIndex) ;
                    }
                }
                freeCSVStruct(csv2) ;
            }
            freeCSVStruct(csv) ;

        }
    }

    S1Specific->azimuthIndexStart = 0 ;
    S1Specific->azimuthIndexEnd = (int)round((S1Specific->LPAT - S1Specific->FPAT) / S1Specific->lineTimeInterval) ;

    /* Now that we have first and last pixel azimut times per bursts, we determine corresponding indexes with respect to image first pixel azimuth time */
    /* For IW or EW mode only */
    updateAzimuthIndexesForBursts(S1Specific) ;

    free(dcPolynomialName) ;

    S1Specific->flag = 0 ;

    return (S1Specific) ;
}

void freeS1Specific (S1AdditionalInfo *S1Specific, char freeBurstDescriptors)
{
    int unsigned i, j, k ,swathIndex ;

    if (!S1Specific) {
        return ;
    }
    
    if (freeBurstDescriptors) {
        freeAllBursts(S1Specific) ;
    }
    free(S1Specific->burstList) ;

    if (S1Specific->betaNought) {
        for (i = 0; i < S1Specific->numberOfSubSwaths; i++) {
            freeMatrixDouble(S1Specific->calibrationRangeIndex[i], 0, 0) ;
            freeVectorDouble(S1Specific->calibrationAzimuthIndex[i], 0) ;
            freeMatrixDouble(S1Specific->sigmaNought[i], 0, 0) ;
            freeMatrixDouble(S1Specific->betaNought[i], 0, 0) ;
            freeMatrixDouble(S1Specific->gamma[i], 0, 0) ;
            freeMatrixDouble(S1Specific->dn[i], 0, 0) ;
        }
        free(S1Specific->calibrationRangeIndex) ;
        free(S1Specific->calibrationAzimuthIndex) ;
        free(S1Specific->sigmaNought) ;
        free(S1Specific->betaNought) ;
        free(S1Specific->gamma) ;
        free(S1Specific->dn) ;
        freeVectorIntUnsigned(S1Specific->calibrationXGridDim, 0) ;
        freeVectorIntUnsigned(S1Specific->calibrationYGridDim, 0) ;
    }

    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        freeVectorDouble(S1Specific->dcEstimates[swathIndex].azimuthTime, 0) ;
        freeVectorDouble(S1Specific->dcEstimates[swathIndex].t0, 0) ;
        for (j = 0; j < S1Specific->dcEstimates[swathIndex].numberOfEstimates; j++) {
            freeXPolynomial(S1Specific->dcEstimates[swathIndex].dcPolynomial[j]) ;
        }
        free(S1Specific->dcEstimates[swathIndex].dcPolynomial) ;

        freeVectorDouble(S1Specific->azimuthFmRate[swathIndex].azimuthTime, 0) ;
        freeVectorDouble(S1Specific->azimuthFmRate[swathIndex].t0, 0) ;
        for (j = 0; j < S1Specific->azimuthFmRate[swathIndex].numberOfRecords; j++) {
            freeXPolynomial(S1Specific->azimuthFmRate[swathIndex].azimuthFmratePolynomial[j]) ;
        }
        free(S1Specific->azimuthFmRate[swathIndex].azimuthFmratePolynomial) ;
    }
    free(S1Specific->dcEstimates) ;
    free(S1Specific->azimuthFmRate) ;
    
    for (i = 0; i < S1Specific->numberOfLayers; i++) {
        for (j = 0; j < S1Specific->numberOfSubSwaths; j++) {
            k = i * S1Specific->numberOfSubSwaths + j ;
            if (S1Specific->MDSFilePath != NULL) {
                free(S1Specific->MDSFilePath[k]) ;
            }
            if (S1Specific->ADSFilePath[k] != NULL) {
                free(S1Specific->ADSFilePath[k]) ;
            }
         }
    }
    
    freeVectorIntUnsigned(S1Specific->numberOfBursts, 0) ;
    freeVectorIntUnsigned(S1Specific->swathXDim, 0) ;
    freeVectorDouble(S1Specific->azimuthSteeringRate, 0) ;
    freeVectorDouble(S1Specific->nearRangeTime, 0) ;
    freeVectorDouble(S1Specific->rangeBandwidth, 0) ;
    freeVectorDouble(S1Specific->rangeApodizationCoefficient, 0) ;
    freeVectorDouble(S1Specific->azimuthBandwidth, 0) ;
    freeVectorIntUnsigned(S1Specific->firstRangePixelIndexForSubSwath, 0 ) ;
    freeVectorIntUnsigned(S1Specific->lastRangePixelIndexForSubSwath, 0 ) ;
    freeVectorInt(S1Specific->firstValidSampleForSubSwath, 0 ) ;
    freeVectorInt(S1Specific->lastValidSampleForSubSwath, 0 ) ;
    freeVectorIntUnsigned(S1Specific->numberOfValidSamples, 0 ) ;
    freeVectorIntUnsigned(S1Specific->superpositionStartIndex, 0 ) ;
    freeVectorIntUnsigned(S1Specific->superpositionEndIndex, 0 ) ;
    freeVectorIntUnsigned(S1Specific->superpositionWidth, 0 ) ;
    freeVectorIntUnsigned(S1Specific->midSuperpositionIndex, 0 ) ;
    freeVectorIntUnsigned(S1Specific->firstAzimuthLineIndexForSubSwath, 0 ) ;
    freeVectorIntUnsigned(S1Specific->lastAzimuthLineIndexForSubSwath, 0 ) ;
    freeVectorIntUnsigned(S1Specific->swathAzimuthSize, 0 ) ;

    free(S1Specific->MDSFilePath) ;
    free(S1Specific->ADSFilePath) ;
}


double *approxFDCForS1(struct infoImage *info)
{
    int i, j, N, *indexVector, counts = 0 ;
    int  unsigned swathIndex ;
    int  unsigned dcEstimateIndex ;
    double rangeIndex ;
    double **M, *V, *avgCoeffs ;
    double rangeTime, x, azimuthTime ;
    double dc0, dc1, signe ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst ;

    S1Specific = info->sensorSpecificInfo ;

    M = matrixDouble(1, 3, 1, 3) ;
    V = vectorDouble(1, 3) ;
    avgCoeffs = vectorDouble(0, 2) ;
    indexVector = vectorInt(1, 3) ;

    
    /* If we deal with IW or EW data, we associate an order 2 dc polynomial to each burst at center azimuth */
    if (strncmp(info->productID, "SM", 2)) {
        for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
            currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
            while (currentBurst->isSelected) {
                
                /* Mean square initialization */
                for (i = 1; i <= 3; i++) {
                    for (j = i; j <= 3; j++) {
                        M[i][j] = M[j][i] = 0. ;
                    }
                    avgCoeffs[i - 1] = V[i] = 0. ;
                }

                if (currentBurst->dcPolynomial == NULL) {
                    currentBurst->dcPolynomial = allocXPolynomialOfOrder(2) ;
                }
                
                /* Mean square calculation */
                N = 5 ;
                azimuthTime = currentBurst->MPAT ;
                for (i = 0; i < N; i++) {
                    /* Compute range time  of point i within a burst range line */
                    rangeIndex = (double) (i * (currentBurst->xDim /(N-1))) ;
                    rangeTime = currentBurst->FPRT + rangeIndex / info->rangeSamplingFrequency ;

                    /* Determine azimuth position and equivalent dc estimate */
                    dcEstimateIndex = 0 ;
                    while (azimuthTime > S1Specific->dcEstimates[swathIndex].azimuthTime[dcEstimateIndex] && dcEstimateIndex < S1Specific->dcEstimates[swathIndex].numberOfEstimates - 1) {
                        dcEstimateIndex++ ;
                    }
                    dcEstimateIndex = (!dcEstimateIndex)? 1 : dcEstimateIndex ;

                    /* We will compute the dc values for both polynomials encompassing the considered azimuth time */
                    /* Linear inerpolation between both at considered azimuth time will give the requested dc value */

                    /* Compute x value for dc upper polynomial */
                    x = rangeTime - S1Specific->dcEstimates[swathIndex].t0[dcEstimateIndex] ;
                    dc1 = yValForPolynomial(S1Specific->dcEstimates[swathIndex].dcPolynomial[dcEstimateIndex], x);

                    /* Compute x value for dc lower polynomial */
                    x = rangeTime - S1Specific->dcEstimates[swathIndex].t0[dcEstimateIndex - 1] ;
                    dc0 = yValForPolynomial(S1Specific->dcEstimates[swathIndex].dcPolynomial[dcEstimateIndex - 1], x);

                    /* Compute requested dc value and save it in dc0 */
                    dc0 += (dc1 - dc0) / (S1Specific->dcEstimates[swathIndex].azimuthTime[dcEstimateIndex] - S1Specific->dcEstimates[swathIndex].azimuthTime[dcEstimateIndex - 1]) * (azimuthTime - S1Specific->dcEstimates[swathIndex].azimuthTime[dcEstimateIndex - 1]) ;

                    /* Mean square calculation */
                    M[1][2] += rangeIndex ;
                    M[1][3] += pow(rangeIndex, 2.) ;
                    M[2][3] += pow(rangeIndex, 3.) ;
                    M[3][3] += pow(rangeIndex, 4.) ;
                    V[1] += dc0 ;
                    V[2] += dc0 * rangeIndex ;
                    V[3] += dc0 * pow(rangeIndex, 2.) ;
                }
                M[1][1] = N ;
                M[2][1] = M[1][2] ;
                M[3][1] = M[2][2] = M[1][3] ;
                M[3][2] = M[2][3] ;

                ludcmp(M, 3, indexVector, &signe) ;
                lubksb(M, 3, indexVector, V) ;

                memcpy(currentBurst->dcPolynomial->coefs, V + 1, 3 * sizeof(V[0])) ;
                for (i = 1; i <= 3; i++) {
                    avgCoeffs[i - 1] += V[i] ;
                }
                counts++ ;

                if (!(currentBurst = currentBurst->nextBurst)) {
                    break ;
                }
            }
        }

        /* The followings is simply to fill up FDC values in infoImage with something else than zeros */
        /* So we take the average of the found coefficients for all the selected burst */
        for (i = 1; i <= 3; i++) {
            avgCoeffs[i - 1] /= counts ;
        }
    }
    else {
        /* For strip map data, we will simply average polynomial coefficients */
        N = MIN(S1Specific->dcEstimates[0].dcPolynomial[0]->order + 1, 3) ;
        for (dcEstimateIndex = 0; dcEstimateIndex < S1Specific->dcEstimates[0].numberOfEstimates; dcEstimateIndex++) {
            for(i = 0; i < N; i++) {
                avgCoeffs[i] += S1Specific->dcEstimates[0].dcPolynomial[dcEstimateIndex]->coefs[i] ;
            }
        }
         for(i = 0; i < N; i++) {
            avgCoeffs[i] /= S1Specific->dcEstimates[0].numberOfEstimates ;
        }
    }
    freeVectorInt(indexVector, 1) ;

    freeMatrixDouble(M, 1, 1) ;
    freeVectorDouble(V, 1) ;

    return (avgCoeffs) ;
}


struct stateVect *readAndSelectStateVectors(xmlDocPtr *ADSXMLDoc, struct infoImage *info)
{
    int i, numberOfStateVectors = 0, firstStateVectorIndex, currentStateVectorIndex ;
    double *timeStamp ;
    CSVStruct *csv, *csvX, *csvY, *csvZ, *csvVx, *csvVy, *csvVz ;
    struct stateVect *stateVectors ;

    if((csv = getAttributeInXMLDocForXPath((xmlChar *)"//orbitList[@count]", ADSXMLDoc[0])) == NULL) {
        perror("No orbitList found in annotation data set") ;
        exit(-1) ;
    }
    sscanf(csv->stringVal[0], "%d", &numberOfStateVectors) ;
    freeCSVStruct(csv) ;

    /* We will first extract state vectors time stamps to select those encompassing the image swath */
    timeStamp = vectorDouble(0, numberOfStateVectors - 1) ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//orbit/time", ADSXMLDoc[0])) == NULL) {
        perror("Something wrong in ADS...\nNo time stamps for state vecors\n") ;
        exit(-1) ;
    }
    if (csv->numberOfEntries != numberOfStateVectors) {
        perror("Something wrong in ADS...\nNumber of time stamps different from number of expected state vectors\n") ;
        exit(-1) ;
    }
    for (i = 0; i < numberOfStateVectors; i++) {
        timeStamp[i] = getSecondsFromFormattedDate(csv->stringVal[i]) ;
    }
    freeCSVStruct(csv) ;
    /* No information is given in reference document for that, but for now, we will consider that state vectors are time ordered */
    i = 0 ;
    do {
        firstStateVectorIndex = i ;
        i++ ;
    } while ((timeStamp[i] < info->FPAT) && (i < numberOfStateVectors));
    while ((timeStamp[i] < info->LPAT) && (i < numberOfStateVectors)) {
        i++ ;
    }
    i -= (i == numberOfStateVectors) ;
    info->nVect = numberOfStateVectors = i - firstStateVectorIndex + 1 ;

//info->nVect = numberOfStateVectors = 5 ;

    /* Now that we have the number of required state vectors, we can allocate them */
    info->S = stateVectors = allocVectorOfStateVectorsOfLength(numberOfStateVectors) ;

    /* Now, we extract all state vectors from ADS[0] */
    /* We reasonably suppose that these state vectors are the same for all subswaths */
    if ((csvX = readCSVInXMLFileForXPath((xmlChar*)"//orbit/position/x", ADSXMLDoc[0])) == NULL) {
        perror("No valid state vector X positions found in ADS...\n") ;
        exit(-1) ;
    }
    if ((csvY = readCSVInXMLFileForXPath((xmlChar*)"//orbit/position/y", ADSXMLDoc[0])) == NULL) {
        perror("No valid state vector Y positions found in ADS...\n") ;
        exit(-1) ;
    }
    if ((csvZ = readCSVInXMLFileForXPath((xmlChar*)"//orbit/position/z", ADSXMLDoc[0])) == NULL) {
        perror("No valid state vector Z positions found in ADS...\n") ;
        exit(-1) ;
    }
    if ((csvVx = readCSVInXMLFileForXPath((xmlChar*)"//orbit/velocity/x", ADSXMLDoc[0])) == NULL) {
        perror("No valid state vector Vx velocity found in ADS...\n") ;
        exit(-1) ;
    }
    if ((csvVy = readCSVInXMLFileForXPath((xmlChar*)"//orbit/velocity/y", ADSXMLDoc[0])) == NULL) {
        perror("No valid state vector Vy velocity found in ADS...\n") ;
        exit(-1) ;
    }
    if ((csvVz = readCSVInXMLFileForXPath((xmlChar*)"//orbit/velocity/z", ADSXMLDoc[0])) == NULL) {
        perror("No valid state vector Vz velocity found in ADS...\n") ;
        exit(-1) ;
    }



    /* Lets transfer values to state vector structure */
    for (i = 0; i < numberOfStateVectors; i++) {
        currentStateVectorIndex = firstStateVectorIndex + i ;
        stateVectors[i].t = timeStamp[currentStateVectorIndex] ;
        sscanf(csvX->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].P) ;
        sscanf(csvY->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].P + 1) ;
        sscanf(csvZ->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].P + 2) ;
        sscanf(csvVx->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].V) ;
        sscanf(csvVy->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].V + 1) ;
        sscanf(csvVz->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].V + 2) ;
    }

    freeCSVStruct(csvX) ;
    freeCSVStruct(csvY) ;
    freeCSVStruct(csvZ) ;
    freeCSVStruct(csvVx) ;
    freeCSVStruct(csvVy) ;
    freeCSVStruct(csvVz) ;
    freeVectorDouble(timeStamp, 0) ;


    return (stateVectors) ;
}



double computeAverageTerrainHeightFromS1ADS(xmlDocPtr *ADSXMLDoc, SLCImageInfo *info)
{
    int i, numberOfHeightsEstimates, firstHeightIndex ;
    double averageHeight, aHeightEstimate ;
    double *timeStamp ;
    CSVStruct *csv ;

    /* We will first extract terrain height estimates time stamps to select those encompassing the image swath */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//terrainHeightList/terrainHeight/azimuthTime", ADSXMLDoc[0])) == NULL) {
        perror("Something wrong in ADS...\nNo time stamps for height estimates\n") ;
        exit(-1) ;
    }
    numberOfHeightsEstimates = csv->numberOfEntries ;
    timeStamp = vectorDouble(0, numberOfHeightsEstimates - 1) ;

    for (i = 0; i < numberOfHeightsEstimates; i++) {
        timeStamp[i] = getSecondsFromFormattedDate(csv->stringVal[i]) ;
    }
    freeCSVStruct(csv) ;
    /* No information is given in reference document for that, but for now, we will consider that state vectors are time ordered */
    i = 0 ;
    do {
        firstHeightIndex = i ;
        i++ ;
    } while ((timeStamp[firstHeightIndex] < info->FPAT) && (i < numberOfHeightsEstimates));
    while ((timeStamp[i] < info->LPAT) && (i < numberOfHeightsEstimates)) {
        i++ ;
    }
    i -= (i == numberOfHeightsEstimates) ;
    numberOfHeightsEstimates = i - firstHeightIndex + 1 ;

    /* Get height estimates in ADS */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//terrainHeightList/terrainHeight/value", ADSXMLDoc[0])) == NULL) {
        perror("Something wrong in ADS...\nNo time stamps for state vecors\n") ;
        exit(-1) ;
    }

    /* Compute average */
    averageHeight = 0. ;
    for (i = 0; i < numberOfHeightsEstimates; i++) {
        sscanf(csv->stringVal[i], "%lf", &aHeightEstimate) ;
        averageHeight += aHeightEstimate ;
    }
    averageHeight /= numberOfHeightsEstimates ;
    freeVectorDouble(timeStamp, 0) ;
    freeCSVStruct(csv) ;

    return (averageHeight) ;
}



/* Small function for reading xml value in Annotation Data Set with error handling */
CSVStruct *getCSVForPathInADS(char *xmlPath, xmlDocPtr xmlDoc) {
    CSVStruct *csv ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)xmlPath, xmlDoc)) == NULL) {
        sprintf(ertex, "Failed to read %s in ADS", xmlPath) ;
        perror(ertex) ;
        exit(-1) ;
    }
    return (csv) ;
}


void allocAndInitDerampingForBursts(SLCImageInfo *infoImage)
{
    int i, j, azimuthIndex, polynomialOrder ;
    int unsigned iX, swathIndex ;
    double t0, diff, diff0, rangeTime, t_t0 ;
    double sensorVelocity, ks, ka, tc0, dc ;
    double range, alpha ;
    double **M, *Vkt, *Vtc, *Vdc ;
    S1AdditionalInfo *S1Specific ;
    struct stateVect *stateVector ;
    derampingStructType *deramping ;
    burstDescriptor *currentBurst ;

    /* Alloc a state vector */
    stateVector = allocStateVector() ;

    S1Specific = infoImage->sensorSpecificInfo ;

    for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
        if ((currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]))) {
            while (currentBurst->isSelected) {
                if((deramping = malloc(sizeof(*deramping))) == NULL) {
                    perror("Failed to allocate deramping structure") ;
                    exit(-1) ;
                }
                currentBurst->deramping = deramping ;

                /* Zero doppler time of burst center */
                deramping->t0 = t0 = currentBurst->MPAT ;

                /* Compute state vector at mid burst */
                azimuthIndex = currentBurst->firstAzimuthIndex + currentBurst->yDim / 2 ;
                calcStateVect(stateVector, azimuthIndex, infoImage) ;
                sensorVelocity = stateVector->velocity ;

                /* Compute ks; Doppler centroid rate induced by the steering rate of the antenna */
                ks = 2. * sensorVelocity / infoImage->wavelength * S1Specific->azimuthSteeringRate[swathIndex] ;

                /* Localize dc estimate polynomials */
                /* Compute difference in time between polynomial azimuth time and burst central time */
                diff0 = fabs(S1Specific->dcEstimates[swathIndex].azimuthTime[0] - t0) ;
                deramping->dcEstimateIndex = 0 ;
                for (iX = 1; iX < S1Specific->dcEstimates[swathIndex].numberOfEstimates; iX++) {
                    diff = fabs(S1Specific->dcEstimates[swathIndex].azimuthTime[iX] - t0) ;
                    if (diff > diff0) {
                        deramping->dcEstimateIndex = iX - 1 ;
                        break ;
                    }
                    diff0 = diff ;
                }

                /* Localize fm rate polynomials */
                /* Compute difference in time between polynomial azimuth time and burst central time */
                diff0 = fabs(S1Specific->azimuthFmRate[swathIndex].azimuthTime[0] - t0) ;
                deramping->fmRateIndex = 0 ;
                for (iX = 1; iX < S1Specific->azimuthFmRate[swathIndex].numberOfRecords; iX++) {
                    diff = fabs(S1Specific->azimuthFmRate[swathIndex].azimuthTime[iX] - t0) ;
                    if (diff > diff0) {
                        deramping->fmRateIndex = iX - 1 ;
                        break ;
                    }
                    diff0 = diff ;
                }

                /* Reference mid burst time */
                tc0 = -1 * S1Specific->dcEstimates[swathIndex].dcPolynomial[deramping->dcEstimateIndex]->coefs[0] / S1Specific->azimuthFmRate[swathIndex].azimuthFmratePolynomial[deramping->fmRateIndex]->coefs[0] ;
                rangeTime = S1Specific->nearRangeTime[swathIndex] ;
                rangeTime = currentBurst->FPRT ;

                /* Doppler centroid estimate */
                t_t0 = rangeTime - S1Specific->dcEstimates[swathIndex].t0[deramping->fmRateIndex] ;
                dc = yValForPolynomial(S1Specific->dcEstimates[swathIndex].dcPolynomial[deramping->dcEstimateIndex], t_t0) ;

                /* Azimuth FM rate */
                t_t0 = rangeTime - S1Specific->azimuthFmRate[swathIndex].t0[deramping->fmRateIndex] ;
                ka = yValForPolynomial(S1Specific->azimuthFmRate[swathIndex].azimuthFmratePolynomial[deramping->fmRateIndex], t_t0) ;
                tc0 = -1 * dc / ka ;

                /* Allocate memory for kt and tc values as well as for corresponding polynomials */
                deramping->kt = vectorDouble(0, currentBurst->xDim - 1) ;
                deramping->tc = vectorDouble(0, currentBurst->xDim - 1) ;
                deramping->dc = vectorDouble(0, currentBurst->xDim - 1) ;
                polynomialOrder = S1Specific->dcEstimates[swathIndex].dcPolynomial[deramping->dcEstimateIndex]->order ;
                deramping->ktPol = allocXPolynomialOfOrder(polynomialOrder) ;
                deramping->tcPol = allocXPolynomialOfOrder(polynomialOrder) ;
                deramping->dcPol = allocXPolynomialOfOrder(polynomialOrder) ; ;

                /* Allocate required memory for mean square calculation of polynomials coefficients */
                M = matrixDouble(1, polynomialOrder + 1, 1, polynomialOrder + 1) ;
                Vkt = vectorDouble(1, polynomialOrder + 1) ;
                Vtc = vectorDouble(1, polynomialOrder + 1) ;
                Vdc = vectorDouble(1, polynomialOrder + 1) ;

                /* Initialize mean square calculation */
                for (i = 0; i <= polynomialOrder; i++) {
                    for (j = 0; j <= polynomialOrder; j++) {
                        M[i + 1][j + 1] = 0. ;
                    }
                    Vkt[i + 1] = Vtc[i + 1] = Vdc[i + 1] = 0. ;
                }

                /* Scale sensor velocity */
                sensorVelocity *= sqrt(infoImage->EarthRadiusAtSceneCenter / stateVector->satDistance) ;

                /* Perform mean square calculation of deramping polynomials */
                for (iX = 0; iX < currentBurst->xDim; iX++) {
                    rangeTime = S1Specific->nearRangeTime[swathIndex] + iX / infoImage->rangeSamplingFrequency ;
                    range = rangeTime * c0 / 2 ;
                    alpha = 1 + range / sensorVelocity * S1Specific->azimuthSteeringRate[swathIndex] ;

                    /* Doppler centroid estimate */
                    t_t0 = rangeTime - S1Specific->dcEstimates[swathIndex].t0[deramping->fmRateIndex] ;
                    dc = deramping->dc[iX] = yValForPolynomial(S1Specific->dcEstimates[swathIndex].dcPolynomial[deramping->dcEstimateIndex], t_t0) ;

                    /* Azimuth FM rate */
                    t_t0 = rangeTime - S1Specific->azimuthFmRate[swathIndex].t0[deramping->fmRateIndex] ;
                    ka = yValForPolynomial(S1Specific->azimuthFmRate[swathIndex].azimuthFmratePolynomial[deramping->fmRateIndex], t_t0) ;

                    /* Doppler centroid rate in the focused data */
                    deramping->kt[iX] = ks / alpha ;
                    deramping->kt[iX] = ka * ks / (ka - ks) ;

                    /* Reference azimuth time */
                    deramping->tc[iX] = -1. * dc / ka - tc0 ;

                    if(100 * (iX / 100) == iX) {
                        for (i = 0; i <= polynomialOrder; i++) {
                            for (j = 0; j <= polynomialOrder; j++) {
                                M[i + 1][j + 1] += pow(iX, (double)(i + j)) ;
                            }
                            Vkt[i + 1] += deramping->kt[iX] * pow(iX, (double)(i)) ;
                            Vtc[i + 1] += deramping->tc[iX] * pow(iX, (double)(i)) ;
                            Vdc[i + 1] += deramping->dc[iX] * pow(iX, (double)(i)) ;
                        }
                    }

                }

                /* Mean Square computation */
                linearSystemResolution(M, Vkt, polynomialOrder + 1) ;
                linearSystemResolution(M, Vtc, polynomialOrder + 1) ;
                linearSystemResolution(M, Vdc, polynomialOrder + 1) ;
                memcpy(deramping->ktPol->coefs, Vkt + 1, (polynomialOrder + 1) * sizeof(double)) ;
                memcpy(deramping->tcPol->coefs, Vtc + 1, (polynomialOrder + 1) * sizeof(double)) ;
                memcpy(deramping->dcPol->coefs, Vdc + 1, (polynomialOrder + 1) * sizeof(double)) ;

                freeMatrixDouble(M, 1, 1) ;
                freeVectorDouble(Vkt, 1) ;
                freeVectorDouble(Vtc, 1) ;
                freeVectorDouble(Vdc, 1) ;

                if (!(currentBurst = currentBurst->nextBurst)) {
                    break ;
                }
            }
        }
    }

    freeStateVector(stateVector) ;
}

void freeDerampingStruct(derampingStructType *deramp)
{
    freeVectorDouble(deramp->kt, 0) ;
    freeVectorDouble(deramp->tc, 0) ;
    freeVectorDouble(deramp->dc, 0) ;
    freeXPolynomial(deramp->ktPol) ;
    freeXPolynomial(deramp->tcPol) ;
    freeXPolynomial(deramp->dcPol) ;
    free(deramp) ;
}

char **getADSFileNames(char *ADSFilePath, char *polarization, int unsigned *nMDS)
{
    char *aPath, **ADSFileNames, *fileExtension ;
    char pol[3], testPol = 0 ;
    int i, j, j0, jMax, numberOfMDS, numberOfFiles, numberOfSubSwaths ;
    CSVStruct *csv, **csvNaming ;

    if (polarization != NULL && strlen(polarization) == 2) {
        /* Put requested polarizattion into lower case */
        for (i = 0; i < 2; i++) {
            if (polarization[i] >= 65 && polarization[i] <= 90) {
                pol[i] = polarization[i] + 32 ;
            }
        }
        pol[i] = 0 ;

        /* Verify if polarization must be selected */
        testPol = !strncmp(pol, "hh", 2) | !strncmp(pol, "vv", 2) | !strncmp(pol, "hv", 2) |!strncmp(pol, "vh", 2) ;
    }

    if((ADSFileNames = getDirectoryEntriesAtPath(ADSFilePath)) == NULL) {
        sprintf(ertex, "No Annotation Data Sets to read at path %s\nData reading cancelled.\n", ADSFilePath) ;
        perror(ertex) ;
        return(ADSFileNames) ;
    }
    numberOfFiles = getNumberOfDirectoryEntriesAtPath(ADSFilePath) ;

    /* Select only SLC S1 ADS files and test presence of requested pol if required */
    numberOfMDS = 0 ;
    for (i = 0; i < numberOfFiles; i++) {
        /* Get file name components to verify we deal with an SLC S1 ADS file */
        fileExtension = getPointerToLastFileExtensionInPath(ADSFileNames[i]) ;
        aPath = initStringWithString(ADSFileNames[i]) ;
        replaceNSubStringInString(aPath, "-", ",") ;
        csv = readCSVInString(aPath) ;
        if (csv->numberOfEntries < 4) {
            free(ADSFileNames[i]) ;
            numberOfFiles-- ;
            for (j = i; j < numberOfFiles; j++) {
                ADSFileNames[j] = ADSFileNames[j + 1] ;
            }
            ADSFileNames[j] = NULL ;
            i-- ;
        }
        else {
            if (strncmp(fileExtension, "xml", 3) || strncmp(csv->stringVal[0], "s1", 2)  || strncmp(csv->stringVal[2], "slc", 3)) {
                /* If not an xml SLC S1 ADS file, release file name */
                free(ADSFileNames[i]) ;
                numberOfFiles-- ;
                for (j = i; j < numberOfFiles; j++) {
                    ADSFileNames[j] = ADSFileNames[j + 1] ;
                }
                i-- ;
                ADSFileNames[j] = NULL ;
            }
            else {
                numberOfMDS++ ;
                /* Verify it is of the requested polarization. If not, release it */
                if (testPol) {
                    if (strncmp(csv->stringVal[3], pol, 2)) {
                        free(ADSFileNames[i]) ;
                        numberOfFiles-- ;
                        for (j = i; j < numberOfFiles; j++) {
                            ADSFileNames[j] = ADSFileNames[j + 1] ;
                        }
                        ADSFileNames[j] = NULL ;
                        i-- ;
                        numberOfMDS-- ;
                    }
                }
            }
        }
        free(aPath) ;
        freeCSVStruct(csv) ;
    }

    /* Normally, ADS should be sorted by polarization mode, but it is not clear into reference documents */
    /* It is simply said that the final index is given with respect to processing order, which is not a sufficient indication with respect to polarization or subswath order */
    /* Therefore, we will sort ADS with respect to polarization mode */
    /* If we deal with Strip Map, there is 1 or 2 MDS, if 3 or 6, we deal with IW, if 5 or 10, we deal with EW */
    numberOfSubSwaths = 1 ;
    if (numberOfMDS) {
        if((csvNaming = malloc(numberOfMDS * sizeof(CSVStruct *))) == NULL) {
            perror("Failed to allocate CSV structure") ;
            exit(-1) ;
        }
        for (i = 0; i < numberOfMDS; i++) {
            aPath = initStringWithString(ADSFileNames[i]) ;
            replaceNSubStringInString(aPath, "-", ",") ;
            csvNaming[i] = readCSVInString(aPath) ;
            free(aPath) ;
        }

        /* We sort ADS names with respect to the polarization mode */
        for (i = 0; i < numberOfMDS - 1; i++) {
            if (strncmp(csvNaming[i]->stringVal[3], csvNaming[i + 1]->stringVal[3],2)) {
                for (j = i + 2; j < numberOfMDS; j++) {
                    if (!strncmp(csvNaming[i]->stringVal[3], csvNaming[j]->stringVal[3],2)) {
                        aPath = ADSFileNames[i + 1] ;
                        ADSFileNames[i + 1] = ADSFileNames[j] ;
                        ADSFileNames[j] = aPath ;
                        csv = csvNaming[i + 1]  ;
                        csvNaming[i + 1] = csvNaming[j] ;
                        csvNaming[j] = csv ;
                        break ;
                    }
                }
            }
        }

        /* Now we will sort them by sub swath */
        numberOfSubSwaths = (numberOfMDS > 2) ? (numberOfMDS == 3 || numberOfMDS == 6)? 3 : 5 : 1 ;
        j0 = 0 ;
        jMax = numberOfSubSwaths ;
        for (i = 1; i < numberOfSubSwaths; i++) {
            for (j = j0; j < jMax - i; j++) {
                if (strcmp(csvNaming[j]->stringVal[1], csvNaming[j + 1]->stringVal[1]) > 0) {
                    aPath = ADSFileNames[j + 1] ;
                    ADSFileNames[j + 1] = ADSFileNames[j] ;
                    ADSFileNames[j] = aPath ;
                    csv = csvNaming[j + 1]  ;
                    csvNaming[j + 1] = csvNaming[j] ;
                    csvNaming[j] = csv ;
                }
            }
        }

        if (numberOfMDS > 5) {
            j0 = numberOfSubSwaths ;
            jMax = 2 * numberOfSubSwaths ;
            for (i = 1; i < numberOfSubSwaths; i++) {
                for (j = j0; j < jMax - i; j++) {
                    if (strcmp(csvNaming[j]->stringVal[1], csvNaming[j + 1]->stringVal[1]) > 0) {
                        aPath = ADSFileNames[j + 1] ;
                        ADSFileNames[j + 1] = ADSFileNames[j] ;
                        ADSFileNames[j] = aPath ;
                        csv = csvNaming[j + 1]  ;
                        csvNaming[j + 1] = csvNaming[j] ;
                        csvNaming[j] = csv ;
                    }
                }
            }
        }

        for (i = 0; i < numberOfMDS; i++) {
            freeCSVStruct(csvNaming[i]) ;
            stripExtensionAtEndOfPath(ADSFileNames[i]) ;
       }
        free(csvNaming) ;
    }

    if (!numberOfMDS) {
        free(ADSFileNames) ;
        ADSFileNames = NULL ;
        if (!testPol) {
            printf("\tNothing to read... Strange...\n") ;
        }
    }

    *nMDS = numberOfMDS ;
    return (ADSFileNames) ;
}

char *getExtensionOfMDSFiles(char *MDSFilePath)
{
    char *extension, *returnedExtension, **MDSFileNames ;
    int i, numberOfFiles ;

    MDSFileNames = getDirectoryEntriesAtPath(MDSFilePath) ;
    numberOfFiles = getNumberOfDirectoryEntriesAtPath(MDSFilePath) ;
    for (i = 0; i < numberOfFiles; i++) {
        extension = getPointerToLastFileExtensionInPath(MDSFileNames[i]) ;
        if (!strncmp(extension, "tif", 3) || !strncmp(extension, "TIF", 3) || !strncmp(extension, "tiff", 4) || !strncmp(extension, "TIFF", 4)) {
            returnedExtension = initStringWithString(extension) ;
            freeDirectoryEntries(MDSFileNames, numberOfFiles) ;
            return (returnedExtension) ;
        }
    }

    freeDirectoryEntries(MDSFileNames, numberOfFiles) ;
    return (NULL) ;
}



xmlDocPtr *openADSXMLFiles(char **ADSFilePath, int numberOfMDS)
{
    int i ;
    xmlDocPtr *ADSXMLDoc ;

    /* Allocate XML Doc pointer for each ADS */
    if((ADSXMLDoc = calloc(numberOfMDS, sizeof(*ADSXMLDoc))) == NULL) {
        perror("Failed to allocate xmlDocPtr for ADS") ;
        exit(-1) ;
    }

    /* Open XML Docs */
    for (i = 0; i < numberOfMDS; i++) {
        ADSXMLDoc[i] = getdoc(ADSFilePath[i]) ;
    }

    return (ADSXMLDoc) ;
}



char **getADSFilePath(char *ADSDirectory, char **ADSFileNames, int numberOfMDS)
{
    char **ADSFilePath ;
    int i ;

    /* Build MDS & ADS file paths */
    ADSFilePath = malloc(numberOfMDS * sizeof(char *)) ;
    for (i = 0; i < numberOfMDS; i++) {
        ADSFilePath[i] = initStringWith4Strings(ADSDirectory, "/", ADSFileNames[i], ".xml") ;
    }

    return (ADSFilePath) ;
}



char **getCADSFilePath(char *CADSDirectory, char **ADSFileNames, int numberOfMDS)
{
    char **calibrationFilePath ;
    int i ;

    /* Build MDS & ADS file paths */
    calibrationFilePath = malloc(numberOfMDS * sizeof(char *)) ;
    for (i = 0; i < numberOfMDS; i++) {
        calibrationFilePath[i] = initStringWith4Strings(CADSDirectory, "/calibration-", ADSFileNames[i], ".xml") ;
    }

    return (calibrationFilePath) ;
}



char **getMDSFilePath(char *MDSDirectory, char **ADSFileNames, int numberOfMDS)
{
    char **MDSFilePath, *MDSFileExtension ;
    int i ;
    long unsigned stringLength ;

    /* Build MDS file paths */
    MDSFilePath = malloc(numberOfMDS * sizeof(char *)) ;
    if (!(MDSFileExtension = getExtensionOfMDSFiles(MDSDirectory))) {
        return (NULL) ;
    }
    stringLength = strlen(MDSDirectory) + strlen(ADSFileNames[0]) + strlen(MDSFileExtension) + 2 ;
    for (i = 0; i < numberOfMDS; i++) {
        MDSFilePath[i] = allocStringOfLength(stringLength) ;
        sprintf(MDSFilePath[i], "%s/%s.%s", MDSDirectory, ADSFileNames[i], MDSFileExtension) ;
    }

    free(MDSFileExtension) ;
    return (MDSFilePath) ;
}



S1AdditionalInfo *initS1SpecificInfo(SLCImageInfo *info, char *CSLImagePath)
{
    char *ADSDirectory, **ADSFileNames, **ADSFilePath ;
    char *pol ;
    int unsigned  i, numberOfMDS, numberOfLayers, numberOfSubSwaths ;
    S1AdditionalInfo *S1Specific ;
    CSVStruct *csv ;
    xmlDocPtr *ADSXMLDoc ;

    /* Determine number of layers */
    csv = readCSVInString(info->polMode) ;
    info->numberOfLayers = numberOfLayers = csv->numberOfEntries ;

    /* Select polarisation if requested */
    pol = initStringWithString("ALL") ;
    if (numberOfLayers == 1) {
        free(pol) ;
        pol = initStringWithString(csv->stringVal[0]) ;
    }
    freeCSVStruct(csv) ;

    /* Get ADS file names */
    ADSDirectory = initStringWith2Strings(CSLImagePath, "/Headers") ;
    if((ADSFileNames = getADSFileNames(ADSDirectory, pol, &numberOfMDS)) == NULL) {
        printf("-/->\t%s: \n", info->scene_id) ;
        ase("\tNo Annotation Data Sets available for requested polarization(s)\n") ;
    }

    /* Get ADS file paths */
    ADSFilePath = getADSFilePath(ADSDirectory, ADSFileNames, numberOfMDS) ;

    /* Open ADS XML files */
    ADSXMLDoc = openADSXMLFiles(ADSFilePath, numberOfMDS) ;

    /* Determine the number of swaths from product mode (SM = 1, IW = 3 and EW = 5 sub swaths) */
    csv = getCSVForPathInADS("//adsHeader/mode", ADSXMLDoc[0]) ;
    numberOfSubSwaths = (strncmp(csv->stringVal[0], "S", 1))? (strncmp(csv->stringVal[0], "IW", 2))? 5 : 3 : 1 ;
    freeCSVStruct(csv) ;

    /* Generate S1 specific information from Annotation Data Sets */
    info->sensorSpecificInfo = S1Specific = (S1AdditionalInfo *)allocAndInitS1Specifics(numberOfLayers, numberOfSubSwaths, ADSXMLDoc, NULL) ;

    /* Update infoImage */
    /* Doppler centroid approximation */
    if (info->fdc != NULL) {
        freeVectorDouble(info->fdc, 0) ;
    }
    info->fdc = approxFDCForS1(info) ;

    /* Allocate ETAD Phase delays vector */
    info->ETADPhaseDelays = vectorDouble(0, 2) ;
    
    /* Reset FPAT and LPAT */
    info->FPAT = S1Specific->FPAT ;
    info->LPAT = S1Specific->LPAT ;

    /* Reset minimum slant range */
    /* Min and max slant range */
    info->twoWayRangeTime[0] = S1Specific->twoWayRangeTime ;
    info->slantRange[0] = c0 / 2. * info->twoWayRangeTime[0] ;
    info->slantRange[2] = info->slantRange[0] + info->rangeDimension * info->rangeResolutionCell ;
    info->slantRange[1] = (info->slantRange[0] + info->slantRange[2]) / 2. ;


    /* If we deal with IW or EW data, geolocate each burst */
    if (strncmp(info->productID, "SM", 2)) {
        geolocatBursts(info) ;
    }

    /* Transfer MDS & ADS file path to S1Specific */
    S1Specific->MDSFilePath = NULL ;
    S1Specific->ADSFilePath = ADSFilePath ;

    /* Free XML docs */
    for (i = 0; i < numberOfMDS; i++) {
        xmlFreeDoc(ADSXMLDoc[i]) ;
    }
    free(ADSXMLDoc) ;
    xmlCleanupParser();


    for (i = 0; i < numberOfMDS; i++) {
        free(ADSFileNames[i]) ;
    }
    free(ADSFileNames) ;
    free(ADSDirectory) ;
    free(pol) ;

    return(S1Specific) ;
}



void geolocatBursts(SLCImageInfo *info)
{
    int unsigned swathIndex ;
    double *xyz, *llh, *sol, x, y ;
    geoRef	*geo ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst ;

    S1Specific = info->sensorSpecificInfo ;

    /* Initialize georeferencing */
    orbitInterpolation(info) ;                                                                                    /* Interpolat orbit if required */
    geo = allocAndInitGeorefStructureForTargetEllipsoid(info, info->ellRef) ;
    x = (double)info->rangeDimension / 2. ;
    y = (double)info->azimuthDimension / 2. ;
    info->EarthRadiusAtSceneCenter = earthRadiusAtPoint(x, y, info->sceneAverageHeight, geo) ;                   /* Compute RT at centre of area */
    llh = vectorDouble(0, 2) ;
    sol = vectorDouble(0, 2) ;

    /* geo locate bursts */
    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
        while (currentBurst->isSelected) {
            /* lower left coordinate */
            x = (double)currentBurst->firstRangeIndex ;
            y = (double)currentBurst->firstAzimuthIndex ;
            geo->solving->Rt = earthRadiusAtPoint(x, y, info->sceneAverageHeight, geo) ;
            xyz = onSphereSolvingForPoint(x, y, info->sceneAverageHeight, geo)  ;
            onEllipsoidProjection(sol, xyz, geo->solving) ;
            XYZ2LonLatH(sol, llh, geo->solving) ;
            currentBurst->burstLocation->P[0].x = llh[0] ;
            currentBurst->burstLocation->P[0].y = llh[1] ;

            /* lower right coordinate */
            x = (double)currentBurst->lastRangeIndex ;
            y = (double)currentBurst->firstAzimuthIndex ;
            geo->solving->Rt = earthRadiusAtPoint(x, y, info->sceneAverageHeight, geo) ;
            xyz = onSphereSolvingForPoint(x, y, info->sceneAverageHeight, geo)  ;
            onEllipsoidProjection(sol, xyz, geo->solving) ;
            XYZ2LonLatH(sol, llh, geo->solving) ;
            currentBurst->burstLocation->P[1].x = llh[0] ;
            currentBurst->burstLocation->P[1].y = llh[1] ;

            /* upper right coordinate */
            x = (double)currentBurst->lastRangeIndex ;
            y = (double)currentBurst->lastAzimuthIndex ;
            geo->solving->Rt = earthRadiusAtPoint(x, y, info->sceneAverageHeight, geo) ;
            xyz = onSphereSolvingForPoint(x, y, info->sceneAverageHeight, geo)  ;
            onEllipsoidProjection(sol, xyz, geo->solving) ;
            XYZ2LonLatH(sol, llh, geo->solving) ;
            currentBurst->burstLocation->P[2].x = llh[0] ;
            currentBurst->burstLocation->P[2].y = llh[1] ;

            /* upper left coordinate */
            x = (double)currentBurst->firstRangeIndex ;
            y = (double)currentBurst->lastAzimuthIndex ;
            geo->solving->Rt = earthRadiusAtPoint(x, y, info->sceneAverageHeight, geo) ;
            xyz = onSphereSolvingForPoint(x, y, info->sceneAverageHeight, geo)  ;
            onEllipsoidProjection(sol, xyz, geo->solving) ;
            XYZ2LonLatH(sol, llh, geo->solving) ;
            currentBurst->burstLocation->P[3].x = llh[0] ;
            currentBurst->burstLocation->P[3].y = llh[1] ;
            if (!(currentBurst = currentBurst->nextBurst)) {
                break ;
            }
        }
    }

    freeVectorDouble(llh, 0) ;
    freeVectorDouble(sol, 0) ;
    freeGeoRef(geo) ;
}

/* Update burst selection text file within S1 image info directory */
void updateBurstSelectionAtPath(SLCImageInfo *info, char *infoDir)
{
    char aKey[32], *outputPath ;
    int unsigned swathIndex ;
    keyValue *burstSelection ;
    burstDescriptor *currentBurst ;
    S1AdditionalInfo *S1Specific ;
    CSVStruct *csv = NULL ;

    S1Specific = info->sensorSpecificInfo ;
    if (S1Specific) {
        /* Create burst selection text file */
        burstSelection = allocAKeyValuePair() ;
        setStringValForKeyIn(burstSelection, "Sentinel1 SLC Data burst selection", "") ;
        setStringValForKeyIn(burstSelection, "**********************************", "") ;
        setStringValForKeyIn(burstSelection, "", "") ;
        setStringValForKeyIn(burstSelection, info->polMode, "Polarization") ;
        setIntValForKeyIn(burstSelection, S1Specific->firstSwathIndex, "First swath index") ;
        setIntValForKeyIn(burstSelection, S1Specific->lastSwathIndex, "Last swath index") ;
        for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
            currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
            sprintf(aKey, "Swath %1d burst selection", swathIndex) ;
            while (currentBurst && currentBurst->isSelected) {
                csv = addIntValInCSVStruct(currentBurst->burstIndex, csv) ;
                currentBurst = currentBurst->nextBurst ;
            }
            setCSVValForKeyIn(burstSelection, csv, aKey) ;
            freeCSVStruct(csv) ;
            csv = NULL ;
        }
        outputPath = initStringWith2Strings(infoDir, "/burstSelection.txt") ;
        writeParameterFileAtPath(burstSelection, outputPath) ;
        freeKeyValueList(burstSelection) ;
        free(outputPath) ;
    }
}

/* Save S1 specific info image at given path */
/* If given path is a directory, it is supposed to be the info image directory */
void saveS1InfoImage(SLCImageInfo *info, char *aPath)
{
    char *infoDirectoryPath, *infoFilePath ;
    char *thisBurstInfoDir, burstID[16] ;
    char *sourcePath, *destinationPath ;
    int unsigned swathIndex ;
    int i ;
    S1AdditionalInfo *S1Specific ;
    CSVStruct *csv = NULL ;
    SLCImageInfo *newInfo ;
    burstDescriptor *currentBurst, *masterBurst ;
    keyValue *addParams ;

    S1Specific = info->sensorSpecificInfo ;
    if (isDir(aPath)) {
        infoDirectoryPath = initStringWithString(aPath) ;
    }
    else {
        infoDirectoryPath = getDirectoryPathFromPath(aPath) ;
    }
    infoFilePath = initStringWith2Strings(infoDirectoryPath, "/SLCImageInfo.txt") ;
    

    /* Remove all kml and SLCInfo files. They will be regenerated with their new burst index */
    if((csv = recursiveSearchOfFilesWithExtensionInDir("kml", infoDirectoryPath))) {
        for (i = 0; i < csv->numberOfEntries; i++) {
            unlink(csv->stringVal[i]) ;
        }
        freeCSVStruct(csv) ;
    }
    if((csv = recursiveSearchOfFileInDir("SLCImageInfo", infoDirectoryPath))) {
        for (i = 0; i < csv->numberOfEntries; i++) {
            unlink(csv->stringVal[i]) ;
        }
        freeCSVStruct(csv) ;
    }
    csv = NULL ;
    
    /* Save S1 info as such adding reference image if any */
    if (info->masterInfo) {
        addParams = allocAKeyValuePair() ;
        setStringValForKeyIn(addParams, "", "") ;
        setStringValForKeyIn(addParams, "Reference image", "") ;
        setStringValForKeyIn(addParams, "***************", "") ;
        setStringValForKeyIn(addParams, info->masterInfo->productID, "Reference image ID") ;
    }
    saveInfoImage(info, infoFilePath) ;
    free(saveInfoKmlInDir(info, infoDirectoryPath)) ;

    if (strcmp(info->productID, "SM")) {
        updateBurstSelectionAtPath(info, infoDirectoryPath) ;
        /* Read a new instance of info */
        newInfo = readInfoImageFromTextFile(infoFilePath) ;
        /* Modify and save new instances of info for each burst in each swath */
        for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {            

            sprintf(burstID, "swath%1d", swathIndex) ;
            sprintf(accessPath, "%s/SLCImageInfo.swath%1d.txt", infoDirectoryPath, swathIndex) ;
            
            newInfo->rangeDimension = S1Specific->swathXDim[swathIndex] ;
            newInfo->rangeBandwidth = S1Specific->rangeBandwidth[swathIndex] ;
            newInfo->rangeApodizationCoefficient = S1Specific->rangeApodizationCoefficient[swathIndex] ;
            newInfo->slantRange[0] = c0 / 2. * S1Specific->nearRangeTime[swathIndex] ;
            newInfo->slantRange[2] = newInfo->slantRange[0] + newInfo->rangeDimension * newInfo->rangeResolutionCell ;
            newInfo->slantRange[1] = (newInfo->slantRange[0] + newInfo->slantRange[2]) / 2. ;
            
            
            /* Save per burst info */
            currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
            while (currentBurst && currentBurst->isSelected) {
                thisBurstInfoDir = currentBurst->burstImage->infoDirectoryPath ;
                sprintf(burstID, "swath%1d.burst%d", swathIndex, currentBurst->burstIndex) ;
                sprintf(accessPath, "%s/SLCImageInfo.txt", thisBurstInfoDir) ;
                newInfo->suffix = initStringWithString(burstID) ;
                newInfo->FPAT = currentBurst->FPAT ;
                newInfo->LPAT = currentBurst->LPAT ;
                newInfo->azimuthDimension = (int)round((newInfo->LPAT - newInfo->FPAT) / info->lineTimeInterval) + 1 ;
                newInfo->fdc[0] = currentBurst->dcPolynomial->coefs[0] ;
                newInfo->fdc[1] = currentBurst->dcPolynomial->coefs[1] ;
                newInfo->fdc[2] = currentBurst->dcPolynomial->coefs[2] ;
                geolocateSceneOnEllipsoid(newInfo, info->ellRef) ;

                saveInfoImage(newInfo, accessPath) ;
                
                /* Consider transform params if any */
                if (currentBurst->masterBurst) {
                    masterBurst = currentBurst->masterBurst ;
                    addParams = allocAKeyValuePair() ;
                    setStringValForKeyIn(addParams, "", "") ;
                    setStringValForKeyIn(addParams, "Reference image", "") ;
                    setStringValForKeyIn(addParams, "***************", "") ;
                    setStringValForKeyIn(addParams, masterBurst->burstImage->imageDirectoryPath, "Reference image location") ;
                    setIntValForKeyIn(addParams, masterBurst->swathIndex, "Reference swath index") ;
                    setIntValForKeyIn(addParams, masterBurst->burstIndex, "Reference burst index") ;
                    setStringValForKeyIn(addParams, "", "") ;
                    setStringValForKeyIn(addParams, "Slave to reference image transform", "") ;
                    setDoubleValForKeyIn(addParams, currentBurst->T[0][0], "Ax") ;
                    setDoubleValForKeyIn(addParams, currentBurst->T[0][1], "Bx") ;
                    setDoubleValForKeyIn(addParams, currentBurst->T[0][2], "Cx") ;
                    setDoubleValForKeyIn(addParams, currentBurst->T[1][0], "Ay") ;
                    setDoubleValForKeyIn(addParams, currentBurst->T[1][1], "By") ;
                    setDoubleValForKeyIn(addParams, currentBurst->T[1][2], "Cy") ;
                    
                    appendParameterFileAtPath(addParams, accessPath) ;
                    
                    freeKeyValueList(addParams) ;
                }
                
                destinationPath = initStringWith4Strings(infoDirectoryPath, "/PerBurstInfo/SLCImageInfo.", burstID, ".txt") ;
                copyFileAtPathToPath(accessPath, destinationPath) ;
                free(destinationPath) ;

                sourcePath = saveInfoKmlInDir(newInfo, thisBurstInfoDir) ;
                destinationPath = initStringWith3Strings(infoDirectoryPath, "/PerBurstInfo/", getPointerToFileNameInPath(sourcePath)) ;
                copyFileAtPathToPath(sourcePath, destinationPath) ;
                free(sourcePath) ;
                free(destinationPath) ;
                free(newInfo->suffix) ;
                newInfo->suffix = NULL ;
                currentBurst = currentBurst->nextBurst ;
            }
        }
        freeInfoImage(newInfo) ;
    }

    free(infoDirectoryPath) ;
    free(infoFilePath) ;
}   

char selectS1Bursts(quadrilateral *aoi, SLCImageInfo *info, unsigned int coordinateSystem)
{
    char isSwathSelected ;
    int unsigned swathIndex, numberOfSubSwaths ;
    S1AdditionalInfo *S1Specific ;
    quadrilateral *burstAoI = NULL ;
    quadrilateral *requestedAoI ;
    burstDescriptor *currentBurst ;

    S1Specific = info->sensorSpecificInfo ;

    requestedAoI = getCopyOfPolygon(aoi) ;
    /* Convert GEO aoi in radian */
    if (coordinateSystem & _AOI_GEO_COORDINATE_SYSTEM_DEG_) {
        convertAoIFromDeg2Rad(requestedAoI) ;
    }
    if (coordinateSystem & _AOI_SRA_COORDINATE_SYSTEM_) {
        burstAoI = allocQuadrilateral() ;
    }
//    genKMLForPolygonAtPath(requestedAoI, "/home/dd/SAR/Processes/S1/Lux/LuxPol.kml") ;

    numberOfSubSwaths = S1Specific->numberOfSubSwaths ;

    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        isSwathSelected = 0 ;
        if((currentBurst = S1Specific->burstList[swathIndex])) {
            orderBurstList(currentBurst) ;
            do {
                if ((coordinateSystem & _AOI_GEO_COORDINATE_SYSTEM_DEG_) || (coordinateSystem & _AOI_GEO_COORDINATE_SYSTEM_RAD_)) {
                    burstAoI = currentBurst->burstLocation ;
                }
                else {
                    burstAoI->P[0].x = burstAoI->P[3].x = currentBurst->firstRangeIndex ;
                    burstAoI->P[1].x = burstAoI->P[2].x = currentBurst->lastRangeIndex ;
                    burstAoI->P[0].y = burstAoI->P[1].y = currentBurst->firstAzimuthIndex ;
                    burstAoI->P[2].y = burstAoI->P[3].y = currentBurst->lastAzimuthIndex ;
                }
                if ((currentBurst->isSelected = polygonesIntersects(burstAoI, requestedAoI))) {
                    isSwathSelected = 1 ;
                }

                currentBurst = currentBurst->nextBurst ;
            } while (currentBurst) ;
        }

        /* If some bursts are selected, update fields correspondingly */
        if (!isSwathSelected) {
            numberOfSubSwaths-- ;
        }
    }
    if (!numberOfSubSwaths) {
        printf("\t---> No bursts selected. Revise selected area...\n") ;
        return (0) ;
    }

    updateSpecificFieldsForSelectedBursts(info) ;

    if (coordinateSystem & _AOI_SRA_COORDINATE_SYSTEM_) {
        freePolygon(burstAoI) ;
    }
    freePolygon(requestedAoI) ;

    return (1) ;
}

void updateSpecificFieldsForSelectedBursts(SLCImageInfo *info)
{
    char isSwathSelected ;
    int unsigned swathIndex ;
    int unsigned firstAzimuthLineIndex, lastAzimuthLineIndex ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst, *lastBurst ; ;

    S1Specific = info->sensorSpecificInfo ;

    /* We init azimuthIndexStart and azimuthIndexEnd to find the min and max values by comparison */
    S1Specific->azimuthIndexStart = 100 * info->azimuthDimension ;
    S1Specific->azimuthIndexEnd = 0 ;

    /* Reinit FPAT to recompute it for selected bursts */
    S1Specific->FPAT = S1Specific->anxFPAT = 86400 ;
    S1Specific->LPAT = 0. ;

    /* Reinitialize firstSwathIndex to recompute it correctly */
    S1Specific->firstSwathIndex = S1Specific->numberOfSubSwaths ;
    S1Specific->lastSwathIndex = 0 ;

    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        /* We first recompute FPAT and LPAT for the whole image */

        /* We update anxFPAT, FPAT and LPAT to take burst selection into account */
        if ((currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]))) {
//            S1Specific->anxFPAT = (S1Specific->anxFPAT < currentBurst->anxFPAT)? S1Specific->anxFPAT : currentBurst->anxFPAT ;
            S1Specific->FPAT = (S1Specific->FPAT < currentBurst->FPAT)? S1Specific->FPAT : currentBurst->FPAT ;
            S1Specific->firstAzimuthLineIndexForSubSwath[swathIndex] = currentBurst->firstAzimuthIndex ;
        }
        if ((currentBurst = getLastSelectedBurstInList(S1Specific->burstList[swathIndex]))) {
            S1Specific->LPAT = (S1Specific->LPAT > currentBurst->LPAT)? S1Specific->LPAT : currentBurst->LPAT ;
            S1Specific->lastAzimuthLineIndexForSubSwath[swathIndex] = currentBurst->lastAzimuthIndex ;

            S1Specific->swathAzimuthSize[swathIndex] = S1Specific->lastAzimuthLineIndexForSubSwath[swathIndex] - S1Specific->firstAzimuthLineIndexForSubSwath[swathIndex] + 1 ;
            /* Update first and last swath index */
            S1Specific->firstSwathIndex = (swathIndex < S1Specific->firstSwathIndex)? swathIndex : S1Specific->firstSwathIndex ;
            S1Specific->lastSwathIndex = (swathIndex > S1Specific->lastSwathIndex)? swathIndex : S1Specific->lastSwathIndex ;
        }
    }
    info->FPAT = S1Specific->FPAT ;
    info->LPAT = S1Specific->LPAT ;
    updateAzimuthIndexesForBursts(S1Specific) ;
    
    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        isSwathSelected = 0 ;
        S1Specific->swathXDim[swathIndex] = 0 ;
        if((currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]))) {
            /* Re compute azimuth indexes for image taking merged bursts into account */
            firstAzimuthLineIndex = currentBurst->firstAzimuthIndex ;
            S1Specific->azimuthIndexStart = (S1Specific->azimuthIndexStart < firstAzimuthLineIndex)? S1Specific->azimuthIndexStart: firstAzimuthLineIndex ;

            lastBurst = getLastSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
            lastAzimuthLineIndex = lastBurst->lastAzimuthIndex ;
            S1Specific->azimuthIndexEnd = (S1Specific->azimuthIndexEnd > lastAzimuthLineIndex)? S1Specific->azimuthIndexEnd: lastAzimuthLineIndex ;
            
            isSwathSelected = 1 ;
        }

        /* Update near range time for subswath */
        S1Specific->nearRangeTime[swathIndex] = getNearRangeTimeInBurstList(S1Specific->burstList[swathIndex]) ;
        S1Specific->firstRangePixelIndexForSubSwath[swathIndex] = (int)round((S1Specific->nearRangeTime[swathIndex] - S1Specific->nearRangeTime[0]) * S1Specific->rangeSamplingFrequency) ;

        /* Determine first and last range index for each burst */
        if (isSwathSelected) {
            currentBurst = S1Specific->burstList[swathIndex] ;
            if(currentBurst) {
                do {
                    /* Update fields for selected bursts */
                    if (currentBurst->isSelected) {
                        currentBurst->firstRangeIndex = (int)round((currentBurst->FPRT - S1Specific->nearRangeTime[0]) * S1Specific->rangeSamplingFrequency) ;
                        currentBurst->lastRangeIndex = currentBurst->firstRangeIndex + currentBurst->xDim - 1 ;
                        currentBurst->rangeShift = currentBurst->firstRangeIndex - S1Specific->firstRangePixelIndexForSubSwath[swathIndex] ;
                        S1Specific->lastRangePixelIndexForSubSwath[swathIndex] = (S1Specific->lastRangePixelIndexForSubSwath[swathIndex] < currentBurst->lastRangeIndex)? currentBurst->lastRangeIndex : S1Specific->lastRangePixelIndexForSubSwath[swathIndex] ;
                        S1Specific->swathXDim[swathIndex] = (S1Specific->swathXDim[swathIndex] < currentBurst->xDim)? currentBurst->xDim : S1Specific->swathXDim[swathIndex] ;
                    }

                    currentBurst = currentBurst->nextBurst ;
                } while (currentBurst);
            }
        }
    }

    /* Now that we have the index of the first swath, we compute and save the new range index start */
    S1Specific->rangeIndexStart = (int)round((S1Specific->nearRangeTime[S1Specific->firstSwathIndex] - S1Specific->nearRangeTime[0]) * S1Specific->rangeSamplingFrequency) ;

    /* Update full scene dimensions */
    info->azimuthDimension = S1Specific->azimuthIndexEnd - S1Specific->azimuthIndexStart + 1 ;
    info->rangeDimension = (int)round((getFarRangeTimeInBurstList(S1Specific->burstList[S1Specific->lastSwathIndex]) - S1Specific->nearRangeTime[S1Specific->firstSwathIndex]) * S1Specific->rangeSamplingFrequency) + 1 ;
    info->aoi->P[0].x = info->aoi->P[3].x = 0 ;
    info->aoi->P[1].x = info->aoi->P[2].x = info->rangeDimension - 1 ;
    info->aoi->P[0].y = info->aoi->P[1].y = 0 ;
    info->aoi->P[2].y = info->aoi->P[3].y = info->azimuthDimension - 1 ;
    
    /* Transfer range dimension to S1Specific */
    S1Specific->rangeDimension = info->rangeDimension ;

    /* Update slant range for scene */
    info->twoWayRangeTime[0] = S1Specific->nearRangeTime[S1Specific->firstSwathIndex] ;
    info->slantRange[0] = c0 / 2. * S1Specific->nearRangeTime[S1Specific->firstSwathIndex] ;
    info->slantRange[2] = info->slantRange[0] + info->rangeDimension * info->rangeResolutionCell ;
    info->slantRange[1] = (info->slantRange[0] + info->slantRange[2]) / 2. ;


    /* Recompute geolocation of new scene */
    geolocateSceneOnEllipsoid(info, info->ellRef) ;

}

void updateAzimuthIndexesForBursts(S1AdditionalInfo *S1Specific)
{
    int unsigned swathIndex ;
    burstDescriptor *currentBurst, *nextBurst, *lastBurst ;

    /* Now that we have first and last pixel azimuth times per bursts, we determine corresponding indexes with respect to first frame first pixel azimuth time */
    /* For IW or EW mode only */
    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        orderBurstList(S1Specific->burstList[swathIndex]) ;
        if((currentBurst = S1Specific->burstList[swathIndex])) {
            do {
                currentBurst->firstAzimuthIndex = (int)round((currentBurst->FPAT - S1Specific->FPAT) / S1Specific->lineTimeInterval) ;
                currentBurst->lastAzimuthIndex = currentBurst->firstAzimuthIndex + currentBurst->yDim - 1 ;
                currentBurst->firstAzimuthIndexInMDS = currentBurst->burstIndex * currentBurst->yDim ;

                currentBurst = currentBurst->nextBurst ;
            } while (currentBurst);
        }

        if((currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]))) {
            lastBurst = getLastSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
            while ((nextBurst = currentBurst->nextBurst) && (currentBurst != lastBurst)) {
                /* The absolute start index of burst superposition is the first azimuth pixel index of the next burst taking into account the first valid line shift */
                currentBurst->superpositionAzimuthIndex = nextBurst->firstAzimuthIndex + nextBurst->firstValidLine ;
                currentBurst->midSuperpositionAzimuthIndex = (currentBurst->superpositionAzimuthIndex + currentBurst->firstAzimuthIndex + currentBurst->lastValidLine) / 2 ;

                currentBurst = currentBurst->nextBurst ;
            }
            /* Except for the last one for which there is no superposition. Therfore, we put an index outside the image azimuth dimension */
            lastBurst->midSuperpositionAzimuthIndex = lastBurst->superpositionAzimuthIndex = lastBurst->lastAzimuthIndex + 1 ;
        }
        /* Sub swath azimuth size */
        if ((currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]))) {
            nextBurst = getLastSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
            S1Specific->firstAzimuthLineIndexForSubSwath[swathIndex] = currentBurst->firstAzimuthIndex ;
            S1Specific->lastAzimuthLineIndexForSubSwath[swathIndex] = nextBurst->lastAzimuthIndex ;

            S1Specific->swathAzimuthSize[swathIndex] = nextBurst->lastAzimuthIndex - currentBurst->firstAzimuthIndex + 1 ;
        }
    }

}



void orderBurstList(burstDescriptor *burstList)
{
    burstDescriptor *currentBurst, *firstBurst ;

    if((currentBurst = burstList)) {
        do {
            firstBurst = getFirstBurstInList(currentBurst) ;
            if (firstBurst != currentBurst) {
                switchBursts(currentBurst, firstBurst) ;
                currentBurst = firstBurst ;
            }
            currentBurst = currentBurst->nextBurst ;
        } while (currentBurst);
    }

}

void orderBurstInImage(S1AdditionalInfo *S1Specific)
{
    int unsigned swathIndex ;

    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        orderBurstList(S1Specific->burstList[swathIndex]) ;
    }
    updateBurstIndexes(S1Specific) ;
}

void updateFrameIndexOfBursts(S1AdditionalInfo *S1Specific, int unsigned frameIndex)
{
    int unsigned swathIndex ;
    burstDescriptor *currentBurst ;

    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        currentBurst = S1Specific->burstList[swathIndex] ;
        while (currentBurst) {
            currentBurst->frameIndex = frameIndex ;
            currentBurst = currentBurst->nextBurst ;
        }
    }
}


void updateBurstIndexes(S1AdditionalInfo *S1Specific)
{
    int unsigned swathIndex ;
    burstDescriptor *currentBurst ;

    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        currentBurst = S1Specific->burstList[swathIndex] ;
        currentBurst->burstIndex = 0 ;
        currentBurst = currentBurst->nextBurst ;
        while (currentBurst) {
            currentBurst->burstIndex = currentBurst->preceedingBurst->burstIndex + 1 ;
            currentBurst = currentBurst->nextBurst ;
        }
    }
}


void copyAndUpdateBurstSelection(S1AdditionalInfo *destination, S1AdditionalInfo *source)
{
    int unsigned swathIndex ;
    burstDescriptor *destinationBurst, *sourceBurst ;

    for (swathIndex = 0; swathIndex < destination->numberOfSubSwaths; swathIndex++) {
        destinationBurst = destination->burstList[swathIndex] ;
        while (destinationBurst) {
            sourceBurst = getBurstAtFrameSwathIndex(source, destinationBurst->frameIndex, swathIndex, destinationBurst->burstIndex) ;
            if (sourceBurst) {
                destinationBurst->isSelected = sourceBurst->isSelected ;
            }

            destinationBurst = destinationBurst->nextBurst ;
        }
    }
}


burstDescriptor *getBurstAtFrameSwathIndex(S1AdditionalInfo *S1Specific, int unsigned frameIndex, int unsigned swathIndex, int unsigned burstIndex)
{
    burstDescriptor *currentBurst, *searchedBurst = NULL ; ;

        currentBurst = S1Specific->burstList[swathIndex] ;
        while (currentBurst) {
            if (currentBurst->frameIndex == frameIndex && currentBurst->burstIndex == burstIndex) {
                searchedBurst = currentBurst ;
                break ;
            }
            currentBurst = currentBurst->nextBurst ;
        }

    return(searchedBurst) ;
}


burstDescriptor *getBurstAtIndex(burstDescriptor *firstBurst, int unsigned anIndex)
{
    burstDescriptor *currentBurst ;

    currentBurst = firstBurst ;
    while (currentBurst) {
        if (currentBurst->burstIndex == anIndex) {
            break ;
        }
        currentBurst = currentBurst->nextBurst ;
    }

    return(currentBurst) ;
}


burstDescriptor *getFirstBurstInList(burstDescriptor *burstList)
{
    burstDescriptor *currentBurst, *firstBurst ;

    currentBurst = firstBurst = burstList ;
    if(currentBurst) {
        do {
            if (firstBurst->FPAT > currentBurst->FPAT) {
                firstBurst = currentBurst ;
            }

            currentBurst = currentBurst->nextBurst ;
        } while (currentBurst);
    }

    return (firstBurst) ;
}



burstDescriptor *getFirstBurstOfFrameInList(burstDescriptor *burstList, int unsigned frameIndex)
{
    burstDescriptor *currentBurst, *searchedBurst = NULL ;

    currentBurst = burstList ;
    orderBurstList(burstList) ;
    if(currentBurst) {
        do {
            if (currentBurst->frameIndex == frameIndex) {
                searchedBurst = currentBurst ;
                break ;
            }

            currentBurst = currentBurst->nextBurst ;
        } while (currentBurst);
    }

    return (searchedBurst) ;
}



burstDescriptor *getFirstSelectedBurstInList(burstDescriptor *burstList)
{
    double FPAT = 86400. ;
    burstDescriptor *currentBurst, *firstBurst ;

    firstBurst = NULL ;
    currentBurst = burstList ;
    if(currentBurst) {
        do {
            if (FPAT > currentBurst->FPAT && currentBurst->isSelected) {
                FPAT = currentBurst->FPAT ;
                firstBurst = currentBurst ;
            }

            currentBurst = currentBurst->nextBurst ;
        } while (currentBurst);
    }

    return (firstBurst) ;
}


burstDescriptor *getLastBurstInList(burstDescriptor *burstList)
{
    burstDescriptor *currentBurst, *lastBurst ;

    currentBurst = lastBurst = burstList ;
    if(currentBurst) {
        do {
            if (lastBurst->LPAT < currentBurst->LPAT) {
                lastBurst = currentBurst ;
            }

            currentBurst = currentBurst->nextBurst ;
        } while (currentBurst);
    }

    return (lastBurst) ;
}


burstDescriptor *getLastSelectedBurstInList(burstDescriptor *burstList)
{
    double LPAT = 0. ;
    burstDescriptor *currentBurst, *lastBurst ;

    lastBurst = NULL ;
    currentBurst = burstList ;
    if(currentBurst) {
        do {
            if (LPAT < currentBurst->LPAT && currentBurst->isSelected) {
                LPAT = currentBurst->LPAT ;
                lastBurst = currentBurst ;
            }

            currentBurst = currentBurst->nextBurst ;
        } while (currentBurst);
    }

    return (lastBurst) ;
}

void switchBursts(burstDescriptor *firstBurst, burstDescriptor *secondBurst)
{
    int anInt ;
    burstDescriptor *tempBurst ;

    tempBurst = firstBurst->preceedingBurst ;
    firstBurst->preceedingBurst = secondBurst->preceedingBurst ;
    secondBurst->preceedingBurst = tempBurst ;

    firstBurst->preceedingBurst->nextBurst = firstBurst ;
    secondBurst->preceedingBurst->nextBurst = secondBurst ;

    tempBurst = firstBurst->nextBurst ;
    firstBurst->nextBurst = secondBurst->nextBurst ;
    secondBurst->nextBurst = tempBurst ;

    firstBurst->nextBurst->preceedingBurst = firstBurst ;
    secondBurst->nextBurst->preceedingBurst = secondBurst ;

    anInt = firstBurst->burstIndex ;
    firstBurst->burstIndex = secondBurst->burstIndex ;
    secondBurst->burstIndex = anInt ;
}


double getNearRangeTimeInBurstList(burstDescriptor *burstList)
{
    double FPRT = 0.0 ;
    burstDescriptor *currentBurst ;

    currentBurst = burstList ;
    if(currentBurst) {
        FPRT = currentBurst->FPRT ;
        while (currentBurst->nextBurst) {
            currentBurst = currentBurst->nextBurst ;
            if (FPRT > currentBurst->FPRT) {
                FPRT = currentBurst->FPRT ;
            }
        } ;
    }

    return (FPRT) ;
}

double getFarRangeTimeInBurstList(burstDescriptor *burstList)
{
    double LPRT = 0.0 ;
    burstDescriptor *currentBurst ;

    currentBurst = burstList ;
    if(currentBurst) {
        LPRT = currentBurst->LPRT ;
        while (currentBurst->nextBurst) {
            currentBurst = currentBurst->nextBurst ;
            if (LPRT < currentBurst->LPRT) {
                LPRT = currentBurst->LPRT ;
            }
        } ;
    }

    return (LPRT) ;
}

double getNearRangeTimeInSelectedBurstList(burstDescriptor *burstList)
{
    double FPRT = 0.0 ;
    burstDescriptor *currentBurst ;

    currentBurst = burstList ;
    if(currentBurst) {
        while (!currentBurst->isSelected) {
            if(!(currentBurst = currentBurst->nextBurst))
                break ;
        }
        if (currentBurst) {
            FPRT = currentBurst->FPRT ;
            while (currentBurst->nextBurst) {
                currentBurst = currentBurst->nextBurst ;
                if (FPRT > currentBurst->FPRT && currentBurst->isSelected) {
                    FPRT = currentBurst->FPRT ;
                }
            } ;
        }
    }

    return (FPRT) ;
}

double getFarRangeTimeInSelectedBurstList(burstDescriptor *burstList)
{
    double LPRT = 0.0 ;
    burstDescriptor *currentBurst ;

    currentBurst = burstList ;
    if(currentBurst) {
        while (!currentBurst->isSelected) {
            if(!(currentBurst = currentBurst->nextBurst))
                break ;
        }
        if (currentBurst) {
            LPRT = currentBurst->LPRT ;
            while (currentBurst->nextBurst) {
                currentBurst = currentBurst->nextBurst ;
                if (LPRT < currentBurst->LPRT && currentBurst->isSelected) {
                    LPRT = currentBurst->LPRT ;
                }
            } ;
        }
    }

    return (LPRT) ;
}



burstDescriptor *getBurstForAzimuthLineInBurstList(burstDescriptor *burstList, int unsigned azimuthIndex)
{
    char isFound = 0 ;
    burstDescriptor *currentBurst ;

    currentBurst = burstList ;
    if(currentBurst) {
        do {
            if ((currentBurst->isSelected) && (currentBurst->firstAzimuthIndex <= azimuthIndex) && (azimuthIndex <= currentBurst->lastAzimuthIndex)) {
                isFound = 1 ;
                break ;
            }
            currentBurst = currentBurst->nextBurst ;
        } while (currentBurst);
    }

    return ((isFound)? currentBurst : NULL) ;
}


burstDescriptor *getBurstForPoint(S1AdditionalInfo *S1Specific, int unsigned rangeIndex, int unsigned azimuthIndex)
{
    int unsigned swathIndex ;
    burstDescriptor *currentBurst ;

    swathIndex = S1Specific->firstSwathIndex ;
    while (swathIndex < S1Specific->lastSwathIndex && rangeIndex > S1Specific->midSuperpositionIndex[swathIndex + 1]) {
        swathIndex++ ;
    }
    
    currentBurst = getBurstForAzimuthLineInBurstList(S1Specific->burstList[swathIndex], azimuthIndex) ;
    if (currentBurst && currentBurst->midSuperpositionAzimuthIndex < azimuthIndex) {
        currentBurst = (currentBurst->nextBurst)? (currentBurst->nextBurst->isSelected)? currentBurst->nextBurst : currentBurst : currentBurst ;
    }
    
    return(currentBurst) ;
}



/* Read each infoImage of each frame of each found S1 image and make a list with their respective ID */
CSVStruct *listReadS1FramesInDir(char *aDir)
{
    char *frameListFilePath ;
    size_t i, j ;
    size_t numberOfFrames, numberOfImages ;
    SLCImageInfo *frameInfo ;
    CSVStruct *imageList = NULL, *frameList = NULL, *csv ;
    CSLImage *currentImage, **currentFrame ;
    rawFileDescriptor *frameListFile ;
    
    printf("\n\t---> Getting listing of already read frames in destination directory\n") ;
    frameListFilePath = initStringWith2Strings(aDir, "/readFramesListing.txt") ;
    if ((frameListFile = openRawFileForReadingAtPath(frameListFilePath))) {
        printf("\t\t---> A list of already read frames exists. It will be used and updated with newly read ones.\n") ;
        while (fgets(aComment, _MAX_COMMENT_LENGTH_, frameListFile->f)) {
            stripWhiteCharsAtEndOfString(aComment) ;
            frameList = addStringValInCSVStruct(aComment, frameList) ;
        }
        freeRawFileDescriptor(frameListFile) ;
    }
    else {
        if ((imageList = getListingOfCSLImagesInDir(aDir, NULL, NULL))) {
            numberOfImages = (size_t)imageList->numberOfEntries ;
            printf("\t\t---> %ld image(s) found in destination directory.\n", numberOfImages) ;
            frameListFile = openRawFileForReadingAndWritingAtPath(frameListFilePath) ;
            for ( i = 0; i < numberOfImages; i++) {
                currentImage = getCSLImageStructureAtPath(imageList->stringVal[i]) ;
                currentFrame = getFrameListInCSLImage(currentImage, &numberOfFrames) ;

                for ( j = 0; j < numberOfFrames; j++) {
                    frameInfo = readInfoImageInCSLImage(currentFrame[j]) ;
                    csv = readCSVInString(frameInfo->scene_id) ;

                    frameList = addStringValInCSVStruct(csv->stringVal[0], frameList) ;
                    fprintf(frameListFile->f, "%s\n", csv->stringVal[0]) ;

                    freeCSVStruct(csv) ;
                    freeInfoImage(frameInfo) ;
                }
                freeCSLImageListing(currentFrame, numberOfFrames) ;
                freeCSLImageStructure(currentImage) ;
            }
            freeRawFileDescriptor(frameListFile) ;
            freeCSVStruct(imageList) ;
        }
    }
    free(frameListFilePath) ;

    return (frameList) ;
}
