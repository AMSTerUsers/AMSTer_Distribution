
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  infoImageS1.c
//  S1DataReader
//
//  Created by Dominique Derauw on 22/06/2020.
//  Copyright (c) 2020 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "infoImageSAOCOM.h"

struct infoImage *allocAndInitSLCImageInfoFromSAOCOMxemtFile(char *xemtAccesPath)
{
    char *aString ;
    float lon, lat ;
    double aDouble ; 
    struct infoImage *info ;
 	xmlDocPtr XEMTDoc ;
    CSVStruct *csv ;
    polygon *area ;

    /* Allocate infoImage structure */
    info = allocInfoImage() ;

    /* open xml doc */
    XEMTDoc = getdoc(xemtAccesPath) ;

    /* Satelite ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//productType/sub/platform", XEMTDoc))) {
        if (isSubStringPresentInString(csv->stringVal[0], "SAO1A")) {
            sprintf(info->platformName, "SAOCOM_1A") ;
        }
        else {
            sprintf(info->platformName, "SAOCOM_1B") ;
        }
        
        freeCSVStruct(csv) ;
    }
    else {
        ase("\t---> Error reading SAOCOM .xemt file - Unknown sensor") ;
    }

    /* Acquisition date */ 
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//acquisition/acquisitionTime/startTime", XEMTDoc))) {
        info->acquisitionDate = allocStringOfLength(10) ;
        sprintf(info->acquisitionDate, "%.10s", csv->stringVal[0]) ;
        removeAnyOccurrenceOfSubStringInString(info->acquisitionDate, "-") ;
        freeCSVStruct(csv) ;
    }
    else {
        ase("\t---> Error reading SAOCOM .xemt file - Acquisition date not found") ;
    }

    /* Production date */ 
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//production/productionTime", XEMTDoc))) {
        info->productionTime = allocStringOfLength(20) ;
        sprintf(info->productionTime, "%.19s", csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    else {
        ase("\t---> Error reading SAOCOM .xemt file - Production time not found") ;
    }


    /* Determine if we deal with stripmap or topsar data and set ProductID string */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//parameters/acqMode", XEMTDoc))) {
        addCSVFromXMLFileForXPath((xmlChar*)"//parameters/polMode", XEMTDoc, csv) ;
        addCSVFromXMLFileForXPath((xmlChar*)"//parameters/beamID", XEMTDoc, csv) ;
        if (csv->numberOfEntries == 3) {
            if (!strncmp(csv->stringVal[0], "T", 1)) {
                if (!strncmp(csv->stringVal[0] + 1, "N", 1)) {
                    sprintf(info->productID, "TOPSAR Narrow - Polarization mode: %s\n", csv->stringVal[1]) ;
                }
                else {
                    sprintf(info->productID, "TOPSAR Wide - Polarization mode: %s\n", csv->stringVal[1]) ;
                }
                info->beamNumber = 0 ;
            }
            else {
                sprintf(info->productID, "Stripmap mode - Polarization mode: %s\n", csv->stringVal[1]) ;
                sscanf(csv->stringVal[2] + 1, "%d", &(info->beamNumber)) ;
            }
        }
        else {
            ase("\t---> SAEOCOM .xemt file misconformed - missing parameters") ;
        }
        freeCSVStruct(csv) ;
    }

    /* Not yet ready for TopSAR */
    if (isSubStringPresentInString(info->productID, "TOPSAR")) {
        printf("\t---> SAOCOMDataReader not yet ready for TOPSAR mode\n Skip reading \n") ; 
        freeInfoImage(info) ;
        xmlFreeDoc(XEMTDoc) ;
        return (NULL) ;
    }




    /* Scene ID */
    if((csv = getAttributeInXMLDocForXPath((xmlChar*)"//product[@code]", XEMTDoc))) {
        addCSVFromXMLFileForXPath((xmlChar*)"//product/id", XEMTDoc, csv) ;
        sprintf(info->scene_id, "%s - %s", csv->stringVal[0], csv->stringVal[1]) ;
        freeCSVStruct(csv) ;
    }

    /* Polarization mode */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//parameters/acquiredPols", XEMTDoc))) {
        aString = replaceSubStringsInString(csv->stringVal[0], "-", ", ") ;
        sprintf(info->polMode, "%s", aString) ;
        freeCSVStruct(csv) ;
        csv = readCSVInString(aString) ;
        info->numberOfLayers = csv->numberOfEntries ;
        free(aString) ;
        freeCSVStruct(csv) ;
    }

    /* Relative orbit number */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//pathRow/Path", XEMTDoc))) {
        sscanf(csv->stringVal[0], "%d", &info->relativeOrbitNumber) ;
        freeCSVStruct(csv) ;
    }

    /* Relative frame number */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//pathRow/Row", XEMTDoc))) {
        sscanf(csv->stringVal[0], "%d", &info->relativeFrameNumber) ;
        freeCSVStruct(csv) ;
    }

    /* Look direction defined as Right looking */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//parameters/sideLooking", XEMTDoc))) {
        if (isStringValPresentInCSV("Right", csv)) {
            info->lookDirection = RIGHT_LOOKING ;
        }
        else {
            info->lookDirection = LEFT_LOOKING ;
        }
        freeCSVStruct(csv) ;
    }

    /* PRF */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//RasterInfo/LinesStep", XEMTDoc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->lineTimeInterval)) ;
        freeCSVStruct(csv) ;
    }
    info->prf = 1. / info->lineTimeInterval ;

    /* Radar carrier frequency */
    /* Should be perhaps updated on a layer by layer basis... */
    info->radarCarrierFrequency = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//parameters/fc", XEMTDoc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->radarCarrierFrequency)) ;
        freeCSVStruct(csv) ;
    }
    info->radarCarrierFrequency *= 1.0e6 ;

    /* Wavelength */
    info->wavelength = speedOfLight / info->radarCarrierFrequency ;

    /* Range sampling frequency and a range resolution cell */
    /* Sample step is given in seconds */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//RasterInfo/SamplesStep", XEMTDoc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->rangeResolutionCell)) ;
        freeCSVStruct(csv) ;
    }
    info->rangeSamplingFrequency = roundl(1. / info->rangeResolutionCell) ;
    info->rangeResolutionCell *= speedOfLight / 2. ;

    /* Range bandwidth  */
    info->rangeBandwidth = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//SwathInfo/ProcessedBandwidths/Brg_hz", XEMTDoc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->rangeBandwidth)) ;
        freeCSVStruct(csv) ;
    }

    /* Range apodization coefficient */
    /* to be read in ConfFile_ */
    info->rangeApodizationCoefficient = 0. ;


    /* Azimuth bandwidth  */
    info->azimuthBandwidth = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//SwathInfo/ProcessedBandwidths/Baz_hz", XEMTDoc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->azimuthBandwidth)) ;
        freeCSVStruct(csv) ;
    }

    /* SLC data dimensions */
    if((csv = readCSVInXMLFileForXPathOccurenceN((xmlChar*)"//imageAttributes/bands/band/nCols", XEMTDoc, 0))) {
        sscanf(csv->stringVal[0], "%d", &(info->rangeDimension)) ;
        freeCSVStruct(csv) ;
    }
    if((csv = readCSVInXMLFileForXPathOccurenceN((xmlChar*)"//imageAttributes/bands/band/nRows", XEMTDoc, 0))) {
        sscanf(csv->stringVal[0], "%d", &(info->azimuthDimension)) ;
        freeCSVStruct(csv) ;
    }

    /* Min and max slant range */
    info->twoWayRangeTime[0] = info->slantRange[0] = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//RasterInfo/SamplesStart", XEMTDoc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->twoWayRangeTime[0])) ;
        freeCSVStruct(csv) ;
    }
    info->slantRange[0] = c0 / 2. * info->twoWayRangeTime[0] ;
    info->slantRange[2] = info->slantRange[0] + info->rangeDimension * info->rangeResolutionCell ;
    info->slantRange[1] = (info->slantRange[0] + info->slantRange[2]) / 2. ;

    /* FPAT */
    info->FPAT = 0. ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//RasterInfo/LinesStart", XEMTDoc))) {
        info->FPAT = getTimeValInSecFromSAOCOMDateFormat(csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }

    /* LPAT */
    info->LPAT = info->FPAT + info->lineTimeInterval * (info->azimuthDimension - 1) ;


    /* Doppler centroid polynomial */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//SwathInfo/DopplerCentroid/pol/val", XEMTDoc))) {
        sscanf(csv->stringVal[0], "%lf", info->fdc) ;
        sscanf(csv->stringVal[1], "%lf", info->fdc + 1) ;
        sscanf(csv->stringVal[4], "%lf", info->fdc + 2) ;
        freeCSVStruct(csv) ;
    }

    /* Read and select state vectors */
    info->S = readAndSelectSAOCOMStateVectors(XEMTDoc, info) ;
    info->FVT = info->S[0].t ;
    info->Dt = -1 ; /* Delta T between state vectors not necessarily constant */
    info->aX = info->aY = info->aZ = info->aVx= info->aVy= info->aVz = NULL ;
	info->isOrbitInterpolationDone = 0 ;

    /* Reference ellipsoid */
    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL) {
        perror("Erreur d'allocation de *info->ellRef\n") ;
        exit(-1) ;
    }

    /* Ellipsoid reference name not found in SAOCOM header... */
    /* Supposed to be WGS84 */
    sprintf(info->ellRef->ellipsoidID, "WGS84") ;

    info->ellRef->a = 6.378137000000000e+06 ; // Predefined as WGS84
    info->ellRef->b = 6.356752314245000e+06 ; // Predefined as WGS84

    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (powl(info->ellRef->a, 2.) - powl(info->ellRef->b, 2.)) / powl(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;

    /* Scene average height */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//acquisitionCoordinates/startHeight", XEMTDoc))) {
        sscanf(csv->stringVal[0], "%lf", &info->sceneAverageHeight) ;
        freeCSVStruct(csv) ;
    }
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//acquisitionCoordinates/endHeight", XEMTDoc))) {
        sscanf(csv->stringVal[0], "%lf", &aDouble) ;
        freeCSVStruct(csv) ;
    }
    info->sceneAverageHeight = (info->sceneAverageHeight + aDouble) /2. ;


	/* Geolocate scene on reference ellipsoid */
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
	info->EarthRadiusAtSceneCenter = 6371221. ;
    info->incidenceAngle[0] = 0. ;
	geolocateSceneOnEllipsoid(info, info->ellRef) ;

    /* Azimuth sampling in meter must be computed since not explicitely given in headers */
    info->azimuthResolutionCell = sqrtl(powl(info->locUTM->P[3].x - info->locUTM->P[0].x, 2.) + powl(info->locUTM->P[3].y - info->locUTM->P[0].y, 2.)) / (info->azimuthDimension - 1) ;

    /* Scene centre approxilmate location */
    area = circumscribedRectangleOfPolygon(info->loc) ;
    lat = 180./PI * (area->P[0].y + area->P[2].y) / 2. ;
    lon = 180./PI * (area->P[0].x + area->P[2].x) / 2. ;
    sprintf(info->scene_loc, "Center longitude: %.4g\tCenter latitude: %.4g", lon, lat) ;
    freePolygon(area) ;

    /* Range reference distance */
    /* Set to 800000. Should be updated when reading ConfFile_GEC_HR */
    info->referenceRange = 800000. ;

    xmlFreeDoc(XEMTDoc) ;
    /* All done. */

    return(info) ;
}



double getTimeValInSecFromSAOCOMDateFormat(char* aDateChar)
{
    double hh, mm, ss ;
    double timeVal ;

    sscanf(aDateChar, "%*11s %lf:%lf:%lf", &hh, &mm, &ss) ;
    timeVal = 3600. * hh + 60. * mm + ss  ;

    return (timeVal) ;
}

struct stateVect *readAndSelectSAOCOMStateVectors(xmlDocPtr XEMTDoc, struct infoImage *info)
{
    int i, numberOfStateVectors = 0, firstStateVectorIndex, currentStateVectorIndex ;
    double *timeStamp ;
    CSVStruct *csv, *csvP, *csvV ;
    struct stateVect *stateVectors ;

    if((csv = readCSVInXMLFileForXPath((xmlChar *)"//StateVectorData/nSV_n", XEMTDoc)) == NULL) {
        perror("No orbitList found in .xemt file") ;
        exit(-1) ;
    }
    sscanf(csv->stringVal[0], "%d", &numberOfStateVectors) ;
    freeCSVStruct(csv) ;

    /* We will first extract state vectors time stamps to select those encompassing the image swath */
    timeStamp = vectorDouble(0, numberOfStateVectors - 1) ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//StateVectorData/t_ref_Utc", XEMTDoc)) == NULL) {
        perror("Something wrong in .xemt file...\nNo time stamps for state vecors\n") ;
        exit(-1) ;
    }
    timeStamp[0] = getTimeValInSecFromSAOCOMDateFormat(csv->stringVal[0]) ;
    freeCSVStruct(csv) ;

    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//StateVectorData/dtSV_s", XEMTDoc)) == NULL) {
        perror("Something wrong in .xemt file...\nAzimut time interval between state vectors not found.\n") ;
        exit(-1) ;
    }
    sscanf(csv->stringVal[0], "%lf", &info->Dt) ;
    freeCSVStruct(csv) ;
    for (i = 1; i < numberOfStateVectors; i++) {
        timeStamp[i] = timeStamp[i-1] + info->Dt ;
    }
    

    /* No information is given in reference document for that, but for now, we will consider that state vectors are time ordered */
    i = 0 ;
    do {
        firstStateVectorIndex = i ;
        i++ ;
    } while ((timeStamp[i] < info->FPAT) && (i < numberOfStateVectors));
    while ((timeStamp[i] < info->LPAT) && (i < numberOfStateVectors)) {
        i++ ;
    }
    i -= (i == numberOfStateVectors) ;
    info->nVect = numberOfStateVectors = i - firstStateVectorIndex + 1 ;

    /* Now that we have the number of required state vectors, we can allocate them */
    info->S = stateVectors = allocVectorOfStateVectorsOfLength(numberOfStateVectors) ;

    if ((csvP = readCSVInXMLFileForXPath((xmlChar*)"//StateVectorData/pSV_m/val", XEMTDoc)) == NULL) {
        perror("No valid state vector positions found in .xemt file...\n") ;
        exit(-1) ;
    }

    if ((csvV = readCSVInXMLFileForXPath((xmlChar*)"//StateVectorData/vSV_mOs/val", XEMTDoc)) == NULL) {
        perror("No valid state vector velocities found in .xemt file...\n") ;
        exit(-1) ;
    }


    /* Lets transfer values to state vector structure */
    for (i = 0; i < numberOfStateVectors; i++) {
        currentStateVectorIndex = firstStateVectorIndex + i ;
        stateVectors[i].t = timeStamp[currentStateVectorIndex] ;
        currentStateVectorIndex *= 3 ;
        sscanf(csvP->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].P) ;
        sscanf(csvV->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].V) ;
        currentStateVectorIndex++ ;
        sscanf(csvP->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].P + 1) ;
        sscanf(csvV->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].V + 1) ;
        currentStateVectorIndex++ ;
        sscanf(csvP->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].P + 2) ;
        sscanf(csvV->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].V + 2) ;
    }

    freeCSVStruct(csvP) ;
    freeCSVStruct(csvV) ;
    freeVectorDouble(timeStamp, 0) ;

    return (stateVectors) ;
}
