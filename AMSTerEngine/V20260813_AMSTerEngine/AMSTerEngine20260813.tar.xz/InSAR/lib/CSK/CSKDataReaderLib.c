
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  CSKDataReader
//
//  Created by Dominique Derauw on 2/07/12.
//  Copyright (c) 2012 Centre Spatial de Liège. All rights reserved.
//

#include <stdio.h>
#include "CSKDataReaderLib.h"

CSVStruct *CSKDataReader(CSVStruct *csv)
{
    char *aPath, *inputPath, *outputPath ; ;
    char *fileName, *outputDir ;
    char *outputFileName ;
    int i ;
	keyValue *parametersList, *header ;
	CSLImage *thisImage ;
	SLCImageInfo *info ;
    CSVStruct *H5Filepath = NULL ;
    CSVStruct *savedCSLImages = NULL ;
    CSVStruct *naming = NULL ;
	
    if(csv->numberOfEntries == 1 || isArgumentPresentInCSV(csv, "help") || isArgumentPresentInCSV(csv, "-h")) {
		CSKDataReaderHelp() ;
    }
    if(isArgumentPresentInCSV(csv, "-create")) {
		createCSKDataReaderParameterFileAtPath((char *)csv->stringVal[1]) ;
    }
    
    /* If parameter 1 is a directory, we will consider it contains one or more .h5 CSK files to be read */
    /* If parameter is an .h5 file, we read it. */
    if (isDir(csv->stringVal[1]) || !strncmp(getPointerToLastFileExtensionInPath(csv->stringVal[1]), "h5", 2)) {
        if (isDir(csv->stringVal[1])) {
            outputDir = csv->stringVal[1] ;
            if (csv->numberOfEntries == 3) {
                if (isDir(csv->stringVal[2])) {
                    outputDir = csv->stringVal[2] ;
                }
            }
            H5Filepath = recursiveSearchOfFilesWithExtensionInDir("h5", (char *)csv->stringVal[1]) ;
        }
        else {
            if (csv->numberOfEntries < 3) {
                ase("Output directory is missing") ;
            }
            outputDir = csv->stringVal[2] ;
            H5Filepath = addStringValInCSVStruct(csv->stringVal[1], H5Filepath) ;
        }

        for (i = 0; i < H5Filepath->numberOfEntries; i++) {
            inputPath = H5Filepath->stringVal[i] ;
            header = readCSKImageHeader(inputPath) ;
            info = createSLCImageInfoFromCSKHeaderFor(header) ;

            naming = addStringValInCSVStruct(info->platformName, NULL) ;
            naming = addStringValInCSVStruct("_", naming) ;
            naming = addStringValInCSVStruct(info->acquisitionDate, naming) ;
            naming = addStringValInCSVStruct("_", naming) ;
            if (!strncmp(info->heading, "A", 1)) {
                naming = addStringValInCSVStruct("A", naming) ;
            }
            else {
                naming = addStringValInCSVStruct("D", naming) ;
            }
            if (info->lookDirection ==1) {
                naming = addStringValInCSVStruct("R", naming) ;
            }
            else {
                naming = addStringValInCSVStruct("L", naming) ;
            }
            naming = addStringValInCSVStruct(".csl", naming) ;
            outputFileName = getStringFromCSV(naming) ;
            freeCSVStruct(naming) ;

            outputPath = initStringWith3Strings(outputDir, "/", outputFileName) ;
            if (!isCSLImageAtPath(outputPath) || !isArgumentPresentInCSV(csv, "keepExisting")) {
                fileName = getFileNameFromPath(inputPath) ;
                printf("\n\nReading CSK data %s\n", fileName) ;
                printf("\t---> Saved as %s\n", outputPath) ;
                
                thisImage = createCSLDirectoryStructureAtPath(outputPath, __CSK__) ;
                
                aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
                saveInfoImage(info, aPath) ;
                free(aPath) ;
                
                aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCCalibrationInfo.txt") ;
                createSLCCalibrationTextFileAtPath(header, aPath) ;
                free(aPath) ;

                readCSKImageData(inputPath, header, thisImage) ;
                savedCSLImages = addStringValInCSVStruct(outputPath, savedCSLImages) ;
                freeKeyValueList(header) ;
                freeCSLImageStructure(thisImage) ;
                freeInfoImage(info) ;
            }
            
            free(outputPath) ;
            free(outputFileName) ;
        }
        freeCSVStruct(H5Filepath) ;
    }
    else {
        parametersList = readParameterFileAtPath((char *)csv->stringVal[1]) ;
        inputPath = getStringValForKeyIn(parametersList, "Path to CSK data in HDF5 format")	;
        if (!fileExistsAtPath(inputPath)) {
            sprintf(ertex, "No file at indicated access path: %s\n", inputPath) ;
            ase(ertex) ;
        }
        outputPath = getStringValForKeyIn(parametersList, "Path to output image in CSL format") ;
        savedCSLImages = addStringValInCSVStruct(outputPath, savedCSLImages) ;
        
        if (!isArgumentPresentInCSV(csv, "keepExisting")) {
            thisImage = createCSLDirectoryStructureAtPath(outputPath, __CSK__) ;
            header = readCSKImageHeader(getStringValForKeyIn(parametersList, "Path to CSK data in HDF5 format")) ;
            info = createSLCImageInfoFromCSKHeaderFor(header) ;
            
            aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
            saveInfoImage(info, aPath) ;
            free(aPath) ;
            
            aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCCalibrationInfo.txt") ;
            createSLCCalibrationTextFileAtPath(header, aPath) ;
            free(aPath) ;

            readCSKImageData(inputPath, header, thisImage) ;

            freeKeyValueList(header) ;
            freeCSLImageStructure(thisImage) ;
            freeInfoImage(info) ;
        }
        freeKeyValueList(parametersList) ;
    }
	return savedCSLImages ;
}

void CSKDataReaderHelp()
{
    printf("\nUsage:") ;
    printf("\n-1-\tCSKDataReader /pathToParameterFile [-create]\n") ;
	printf("\n\tThis routine will read CSK data and save it in CSL format.\n");
	printf("\n\tIf adding \"-create\" command line parameter, \n\tan example parameter file will be created at indicated path.\n") ;
    printf("\n\n-2-\tCSKDataReader inputPath [outputPath]\n") ;
    printf("\n\tIn this form, CSKDataReader performs a bulk reading of\n\tall h5 data found within the directory given in input\n\tand all its subdirectories.") ;
    printf("\n\tIf an output path is not provided, all data\n\twill be saved within the input directory") ;
    printf("\n\t") ;
	exit(0) ;
}

void createCSKDataReaderParameterFileAtPath(char *aPath)
{
	keyValue *parameters ;
	
	parameters = allocAKeyValuePair() ;
	setStringValForKeyIn(parameters, "CSKDataReader parameter file", "") ;
	setStringValForKeyIn(parameters, "****************************", "") ;
	setStringValForKeyIn(parameters, "PathToHDF5File", "Path to CSK data in HDF5 format") ;
	setStringValForKeyIn(parameters, "outputFilePath", "Path to output image in CSL format") ;
	
	writeParameterFileAtPath(parameters, aPath) ;
	
	exit(0) ;
}

void createSLCCalibrationTextFileAtPath(keyValue *header, char *aPath) 
{
    char aKey[128], key2[128], *layerGroupName, *polMode, aFileName[128] ;
    int layerIndex, NLayers ;
    double  aDoubleValue ;
    keyValue *calibrationInfo, *aKeyVal ;
    
    
    calibrationInfo = allocAKeyValuePair() ;
    setStringValForKeyIn(calibrationInfo, "SLC calibration info text file", "") ;
    setStringValForKeyIn(calibrationInfo, "******************************", "") ;
    setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, "Azimuth Focusing Weighting Coefficient"), "Azimuth Hamming window coefficient") ;
    if(!(aDoubleValue = getDoubleValForKeyIn(header, "Rescaling Factor")))
       aDoubleValue = 1. ;
    setDoubleValForKeyIn(calibrationInfo, aDoubleValue, "Rescaling factor") ;
    if (!strncmp(getStringValForKeyIn(header, "Calibration Constant Compensation Flag"), "0", 1)) {
        setStringValForKeyIn(calibrationInfo, "NO", "Is calibration constant compensation performed") ;
    }
    else {
        setStringValForKeyIn(calibrationInfo, "YES", "Is calibration constant compensation performed") ;
    }

    setStringValForKeyIn(calibrationInfo, "", "") ;
    setStringValForKeyIn(calibrationInfo, "YES", "Is range spreading loss correction performed?") ;
    if ((aDoubleValue = getDoubleValForKeyIn(header, "Reference Slant Range")) == 1) {
        setStringValForKeyIn(calibrationInfo, "NO", "Is range spreading loss normalization performed?") ;
        setDoubleValForKeyIn(calibrationInfo, 0, "Reference slant range [m]") ;
        setDoubleValForKeyIn(calibrationInfo, 1, "Reference slant range exponent") ;
    }
    else {
        setStringValForKeyIn(calibrationInfo, "YES", "Is range spreading loss normalization performed?") ;
        setDoubleValForKeyIn(calibrationInfo, aDoubleValue, "Reference slant range [m]") ;
        setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, "Reference Slant Range Exponent"), "Reference slant range exponent") ;
    }
    setStringValForKeyIn(calibrationInfo, "", "") ;
    setStringValForKeyIn(calibrationInfo, "YES", "Is incidence angle correction performed?") ;
    if ((aDoubleValue = getDoubleValForKeyIn(header, "Reference Incidence Angle"))) {
        setStringValForKeyIn(calibrationInfo, "YES", "Is incidence angle normalization performed?") ;
        setDoubleValForKeyIn(calibrationInfo, aDoubleValue, "Reference incidence angle [deg]") ;
    }
    else {
        setStringValForKeyIn(calibrationInfo, "NO", "Is incidence angle normalization performed?") ;
        setDoubleValForKeyIn(calibrationInfo, 0, "Reference incidence angle") ;
    }
    setStringValForKeyIn(calibrationInfo, "", "") ;
    NLayers = getIntValForKeyIn(header, "Number of layers") ;
    setIntValForKeyIn(calibrationInfo, NLayers, "Number of data layers") ;
    for (layerIndex = 1; layerIndex <= NLayers; layerIndex++) {
        sprintf(aKey, "Group name of layer %d", layerIndex) ;
        layerGroupName = getStringValForKeyIn(header, aKey) ;
        sprintf(aKey, "%s Polarisation", layerGroupName) ;
        if (!(polMode = getStringValForKeyIn(header, aKey))) {
            sprintf(aKey, "Polarization") ;
            polMode = getStringValForKeyIn(header, aKey) ;
        }

        sprintf(aKey, "%s Calibration Constant", layerGroupName) ;
        sprintf(key2, "%s calibration constant", polMode) ;
        setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, aKey), key2) ;
        sprintf(key2, "Is %s elevation antenna pattern correction performed?", polMode) ;
        setStringValForKeyIn(calibrationInfo, "YES", key2) ;
        
        sprintf(aKey, "%s Beam Off-Nadir Angle", layerGroupName) ;
        sprintf(key2, "%s beam centre off-nadir angle [deg]", polMode) ;
        setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, aKey), key2) ;
        sprintf(aKey, "%s Range Antenna Pattern Origin", layerGroupName) ;
        sprintf(key2, "%s elevation antenna pattern origin with respect to beam centre [deg]", polMode) ;
        setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, aKey), key2) ;
        sprintf(aKey, "%s Range Antenna Pattern Resolution", layerGroupName) ;
        sprintf(key2, "%s elevation antenna pattern sampling [deg]", polMode) ;
        setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, aKey), key2) ;
        sprintf(aKey, "%s Range Antenna Pattern Gains", layerGroupName) ;
        aKeyVal = isKeyValPresent(header, aKey) ;
        sprintf(key2, "%s elevation antenna pattern file name", polMode) ;
        sprintf(aFileName, "%s_TwoWayElevationAntennaPattern.txt", polMode) ;
        setStringValForKeyIn(calibrationInfo, aFileName, key2) ;
        sprintf(key2, "%s elevation antenna pattern number of samples", polMode) ;
        setIntValForKeyIn(calibrationInfo, aKeyVal->dimensions[0], key2) ;
        sprintf(accessPath, "%s/%s", getDirectoryPathFromPath(aPath), aFileName) ;
        writeVectorAtPath(aKeyVal, accessPath) ;
        setStringValForKeyIn(calibrationInfo, "", "") ;
    }

    writeParameterFileAtPath(calibrationInfo, aPath) ;
    freeKeyValueList(calibrationInfo) ;
}

keyValue *readCSKImageHeader(char *inputPath) 
{
	hid_t   file ;              /* h5 file identifiers */
	hid_t	rootGroup ;
	keyValue *pListAll ;
	
	pListAll = allocAKeyValuePair() ;
    setStringValForKeyIn(pListAll, "_", "Text files directory") ;
    setStringValForKeyIn(pListAll, "_", "Data files directory") ;
    setIntValForKeyIn(pListAll, 0, "Number of datasets") ;
    setIntValForKeyIn(pListAll, 0, "Number of layers") ;
    setStringValForKeyIn(pListAll, inputPath, "HDF5 inputfilepath") ;
        
	/* Open the file */
	if((file = H5Fopen(inputPath, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0) {
        ase("Failed to open HDF5 CSK file") ;
    }
	
	/* Open root group */
	rootGroup = H5Oopen(file, "/", H5P_DEFAULT);

#if !defined(H5Ovisit_vers) || H5Ovisit_vers == 1  || H5Ovisit_vers == 2
        /* Visit groups iteratively to get all rank 0 data */
        H5Ovisit(rootGroup, H5_INDEX_CRT_ORDER, H5_ITER_NATIVE, getAllRank0Data, &pListAll);
        
        /* Visit group iteratively to identify all objects */
        H5Ovisit(rootGroup, H5_INDEX_CRT_ORDER, H5_ITER_NATIVE, visitObjectsIteratively, &pListAll);
#else 
        /* Visit groups iteratively to get all rank 0 data */
        H5Ovisit3(rootGroup, H5_INDEX_CRT_ORDER, H5_ITER_NATIVE, getAllRank0Data, &pListAll, H5O_INFO_ALL);
        
        /* Visit group iteratively to identify all objects */
        H5Ovisit3(rootGroup, H5_INDEX_CRT_ORDER, H5_ITER_NATIVE, visitObjectsIteratively, &pListAll, H5O_INFO_ALL);
#endif
    
	
    H5Oclose(rootGroup) ;
    H5Fclose(file) ;
	    
	return (pListAll) ;
}



void readCSKImageData(char *inputPath, keyValue *pListAll, CSLImage *thisImage) 
{
    char *aPath, *textFilePath = NULL, *datasetName, *polMode, aKey[64] ;
    char isSLC, bytesMustBeSwapped ;
	int rank, datasetNumber, datasetIndex ;
    int iY, i ;
    size_t count, bufferDim ;
    complexShort *aComplexShort ;
    complexFloat *aComplexFloat ,*aLine = NULL ;
	hsize_t	*datasetDim, *maxDims ;
    hsize_t *blockOffset, *blockDim, *blockCount ;
	hid_t   file, dataset;      /* File and dataset identifiers */
	hid_t	dataSpace, outputDataSpace ;			/* dataSpace identifier */
	hid_t	rootGroup ;
	hid_t dataType ;
    size_t dataTypeSize ;
    H5T_order_t dataTypeOrder ;
    rawFileDescriptor *outputDataFile, *readme ;
    void *buffer ;
    progressCounter *aCounter ;
    keyValue *savedDataCharacteristics ;
	    
    setStringValForKeyIn(pListAll, thisImage->headersDirectoryPath, "Text files directory") ;
    setStringValForKeyIn(pListAll, thisImage->dataDirectoryPath, "Data files directory") ;
    aPath = initStringWith2Strings(thisImage->headersDirectoryPath, "/keyVals.txt") ;
    writeParameterFileAtPath(pListAll, aPath) ;

    aPath = initStringWith2Strings(thisImage->headersDirectoryPath, "/_readme.txt") ;
    if(fileExistsAtPath(aPath))
        unlink(aPath) ;
    readme = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;
    fprintf(readme->f, "This directory contains CSK headers as extracted from HDF5 file attributes.\n") ;
    fprintf(readme->f, "HDF5 attributes belonging to different HDF5 datasets are saved in separate text files\n") ;
    fprintf(readme->f, "Each vector or matrix attribute is saved in a separate file with a header file name corresponding to the dataset it belongs.\n") ;
    freeRawFileDescriptor(readme) ;
    
	/* Open the h5 file */
	if((file = H5Fopen(inputPath, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0) {
        ase("Failed to open HDF5 CSK file") ;
    }

	/* Open root group */
	rootGroup = H5Oopen(file, "/", H5P_DEFAULT) ;

	/* Open the datasets sequentially */
    datasetNumber = getIntValForKeyIn(pListAll, "Number of datasets") ;
    for (datasetIndex = 1; datasetIndex <= datasetNumber; datasetIndex++) {
        /* Get dataset name */
        sprintf(aKey, "Dataset %d name", datasetIndex) ;
        datasetName = getStringValForKeyIn(pListAll, aKey) ;
        
        /* Open dataset in HDF5 file */
        dataset = H5Dopen2(file, datasetName, H5P_DEFAULT);
        
        /* Get dataset dataspace */
        dataSpace = H5Dget_space(dataset) ;
        
        /* Get dataset rank  */
        rank = H5Sget_simple_extent_ndims(dataSpace) ;
        if(rank && rank < 4) {
            /* Get data type description */
            dataType = H5Dget_type(dataset) ;
            dataTypeSize = H5Tget_size(dataType) ;
            dataTypeOrder = H5Tget_order(dataType) ;
            
            /* Allocate dimension vectors */
            datasetDim = malloc(rank * sizeof(hsize_t)) ;
            maxDims = malloc(rank * sizeof(hsize_t)) ;
            
            /* Get dataset full size */
            H5Sget_simple_extent_dims(dataSpace, datasetDim, maxDims) ;
            H5Sselect_none(dataSpace) ;
                        
            /* Set block dimension and offset */
            blockDim = malloc(rank * sizeof(hsize_t)) ;
            blockOffset = malloc(rank * sizeof(hsize_t)) ;
            blockCount = malloc(rank * sizeof(hsize_t)) ;
            
            bufferDim = 1 ;
            for (i = 0; i < rank; i++) {
                blockCount[i] = 1 ;
                blockDim[i] = datasetDim[i] ;
                blockOffset[i] = 0 ;
                if(i) bufferDim *= blockDim[i] ;
            }
            blockDim[0] = 1 ;
            outputDataSpace = H5Screate_simple(rank, blockDim, maxDims) ;
            
            /* Determine if data is a Single Look Complex image */
            isSLC = 0 ;
            bytesMustBeSwapped = 0 ;
            if(isSubStringPresentInString(datasetName, "SBI") || isSubStringPresentInString(datasetName, "IMG")) {
                if (isSubStringPresentInString(getStringValForKeyIn(pListAll, "Product Type"), "SCS")) {
                    isSLC = 1 ;
                    aLine = vectorComplexFloat(0, (int)datasetDim[1]) ;
                    bytesMustBeSwapped = !(isArchBigEndian() ^ (dataTypeOrder == H5T_ORDER_LE)) ;
                    setLongValForKeyIn(pListAll, datasetDim[1], "SLC range dimension") ;
                    setLongValForKeyIn(pListAll, datasetDim[0], "SLC azimuth dimension") ;
                }
            }
            
            /* Create output file */
            sprintf(aKey, "%.3s Polarisation", datasetName) ;
            polMode = getStringValForKeyIn(pListAll, aKey) ;
            if (!(polMode = getStringValForKeyIn(pListAll, aKey))) {
                sprintf(aKey, "Polarization") ;
                polMode = getStringValForKeyIn(pListAll, aKey) ;
            }

            if (isSLC) {
                aPath = initStringWith3Strings(getStringValForKeyIn(pListAll, "Data files directory"), "/SLCData.", polMode) ;
                textFilePath = initStringWith4Strings(thisImage->infoDirectoryPath, "/", getFileNameFromPath(aPath), ".txt") ;
            }
            else {
                replaceSubStringInString(datasetName, "/", ".") ;
                aPath = allocStringOfLength(256) ;
                sprintf(aPath, "%s/%s.%s", getStringValForKeyIn(pListAll, "Data files directory"), datasetName, polMode) ;
                textFilePath = initStringWith4Strings(thisImage->infoDirectoryPath, "/", getFileNameFromPath(aPath), ".txt") ;
            }
            outputDataFile = openRawFileForWritingAtPath(aPath) ;
            
            /* Alloc buffer */
            buffer = malloc(bufferDim * dataTypeSize) ;
            aCounter = initProgressCounterWithMinMaxValue(0, (int)datasetDim[0]) ;
            printf("\n\n Reading dataset %s\n", datasetName) ;
            
            for (iY = 0; iY < (int)datasetDim[0]; iY++) {
                blockOffset[0] = iY ;
                H5Sselect_hyperslab(dataSpace, H5S_SELECT_SET, blockOffset, NULL, blockCount, blockDim) ;
                H5Dread(dataset, dataType, outputDataSpace, dataSpace, H5P_DEFAULT, buffer) ;
                H5Sselect_none(dataSpace) ;
                if (isSLC) {
                    if (dataTypeSize == 2) {
                        aComplexShort = (complexShort *)buffer ;
                        for (i = 0; i < (int)blockDim[1]; i++) {
                            if (bytesMustBeSwapped) {
                                swapComplexShort(aComplexShort + i) ;
                            }
                            aLine[i].r = (float)aComplexShort[i].r ;
                            aLine[i].i = (float)aComplexShort[i].i ;
                        }
                        count = fwrite(aLine, sizeof(complexFloat), (size_t)blockDim[1], outputDataFile->f) ;
                        if (count != (size_t)blockDim[1]) {
                            ase("\t-/-> Write error. Failed to save SLC data file.\n") ;
                        }
                    }
                    else {
                        aComplexFloat = (complexFloat *)buffer ;
                        for (i = 0; i < (int)blockDim[1]; i++) {
                            if (bytesMustBeSwapped) {
                                swapComplexFloat(aComplexFloat + i) ;
                            }
                        }
                        count = fwrite(aComplexFloat, sizeof(complexFloat), (size_t)blockDim[1], outputDataFile->f) ;
                        if (count != (size_t)blockDim[1]) {
                            ase("\t-/-> Write error. Failed to save SLC data file.\n") ;
                        }
                    }
                }
                else {
                    count = fwrite(buffer, dataTypeSize, bufferDim, outputDataFile->f) ;
                    if (count != bufferDim) {
                        ase("\t-/-> Write error. Failed to save SLC data file.\n") ;
                    }
                }
                fflush(outputDataFile->f) ;
                updateProgressCounterForIndex(aCounter, iY );
            }
            updateProgressCounterForIndex(aCounter, iY );

            savedDataCharacteristics = allocAKeyValuePair() ;
            if(isSLC) {
                setStringValForKeyIn(savedDataCharacteristics, "SLC data structure", "") ;
                setStringValForKeyIn(savedDataCharacteristics, "******************", "") ;
                setStringValForKeyIn(savedDataCharacteristics, "complex", "Data type") ;
                setStringValForKeyIn(savedDataCharacteristics, "float - float", "Data structure") ;
            }
            else {
                setStringValForKeyIn(savedDataCharacteristics, aPath, "Data file") ;
                sprintf(aKey, "Dataset %d data type identifier", datasetIndex) ;
                setStringValForKeyIn(savedDataCharacteristics, getStringValForKeyIn(pListAll, aKey), "Data type identifier") ;
                sprintf(aKey, "Dataset %d data type size", datasetIndex) ;
                setStringValForKeyIn(savedDataCharacteristics, getStringValForKeyIn(pListAll, aKey), "Data type size [byte]") ;
            }
            if (isArchBigEndian()) {
                setStringValForKeyIn(savedDataCharacteristics, "Big endian", "Data byte order") ;
            }
            else {
                setStringValForKeyIn(savedDataCharacteristics, "Low endian", "Data byte order") ;
            }
            setLongValForKeyIn(savedDataCharacteristics, blockDim[1], "Number of columns") ;
            setLongValForKeyIn(savedDataCharacteristics, datasetDim[0], "Number of raws") ;
            writeParameterFileAtPath(savedDataCharacteristics, textFilePath) ;
            freeKeyValueList(savedDataCharacteristics) ;
            
            H5Tclose(dataType) ;
            freeRawFileDescriptor(outputDataFile) ;
            free(datasetDim) ;
            free(maxDims) ;
            free(blockDim) ;
            free(blockOffset) ;
            freeProgressCounter(aCounter) ;
            free(buffer) ;
            free(aPath) ;

        }
        H5Sclose(dataSpace) ;
        H5Dclose(dataset);
    }
    H5Oclose(rootGroup) ;
    H5Fclose(file) ;
}



/* Operator function */
static herr_t transferAttributeInfoToPList(hid_t parentObject, const char *childObjectName, const H5A_info_t *childObjectInfo, void *pList)
{
	char bytesMustBeSwapped, *aString, *groupName, *aKey ;
	int i, rank ;
    void *anArray ;         /* Pointer to the array attribute. */
 	hsize_t	*attributeDatasetDim, *attributeMaxDims ;
    hid_t attr, attributeType, attributeSpace;  /* Attribute, datatype and dataspace identifiers */	
    hsize_t sdim[64], typeSize;
    H5A_info_t ainfo[1] ;
    int npoints;             /* Number of elements in the array attribute. */
	
    /* Open the attribute using its childObjectName */
    attr = H5Aopen(parentObject, childObjectName, H5P_DEFAULT);
    
    /* Get attribute datatype, dataspace, rank, and dimensions */
    attributeType  = H5Aget_type(attr);
    attributeSpace = H5Aget_space(attr);
    rank = H5Sget_simple_extent_ndims(attributeSpace);
    H5Sget_simple_extent_dims(attributeSpace, sdim, NULL);
    H5Aget_info( attr, ainfo ) ;
	typeSize = H5Tget_size(attributeType) ;
	npoints = (int)H5Sget_simple_extent_npoints(attributeSpace);
	bytesMustBeSwapped = !(isArchBigEndian() ^ (H5Tget_order(attributeType) == H5T_ORDER_LE)) ;
	
    /* Allocate dimension vectors */
    attributeDatasetDim = malloc(rank * sizeof(hsize_t)) ;
    attributeMaxDims = malloc(rank * sizeof(hsize_t)) ;
    
    /* Get dataset full size */
    H5Sget_simple_extent_dims(attributeSpace, attributeDatasetDim, attributeMaxDims) ;
    
    /* If we are at a group level corresponding to a new layer S<nn>, key names must be prefixed */
    if((groupName = getStringValForKeyIn(pList, "Group name"))) {
        aKey = initStringWith3Strings(groupName, " ", (char *)childObjectName) ;
    }
    else {
        aKey = initStringWithString((char *)childObjectName) ;
    }
    
    /* Read array attribute and display its type and values */
	switch (H5Tget_class(attributeType)) {
		case H5T_INTEGER:
			if(typeSize == sizeof(char)) {
				anArray = vectorUChar(0, npoints - 1) ;
				H5Aread(attr, attributeType, anArray) ;
				setVectorUCharForKeyIn(pList, anArray, npoints, aKey) ;
			}
			if(typeSize == sizeof(short)) {
				anArray = vectorShort(0, npoints - 1) ;
				H5Aread(attr, attributeType, anArray) ;
				if(bytesMustBeSwapped) {
					for(i = 0; i < npoints; i++)
						swapInt(anArray + i * sizeof(short)) ;
				}
				setVectorShortForKeyIn(pList, anArray, npoints, aKey) ;
			}
			if(typeSize == sizeof(int)) {
				anArray = vectorInt(0, npoints - 1) ;
				H5Aread(attr, attributeType, anArray) ;
				if(bytesMustBeSwapped) {
					for(i = 0; i < npoints; i++)
						swapInt(anArray + i * sizeof(int)) ;
				}
				setVectorIntForKeyIn(pList, anArray, npoints, aKey) ;
			}
			break;
			
		case H5T_FLOAT:
			if(typeSize == sizeof(float)) {
				anArray = vectorFloat(0, npoints - 1) ;
				H5Aread(attr, attributeType, anArray) ;
				if(bytesMustBeSwapped) {
					for(i = 0; i < npoints; i++)
						swapFloat(anArray + i * sizeof(int)) ;
				}
				setVectorFloatForKeyIn(pList, anArray, npoints, aKey) ;
			}
			if(typeSize == sizeof(double)) {
				anArray = vectorDouble(0, npoints - 1) ;
				H5Aread(attr, attributeType, anArray) ;
				if(bytesMustBeSwapped) {
					for(i = 0; i < npoints; i++)
						swapDouble(anArray + i * sizeof(int)) ;
				}
				setVectorDoubleForKeyIn(pList, anArray, npoints, aKey) ;
			}
			break;
			
		case H5T_STRING:
			aString = allocStringOfLength(typeSize) ;
			H5Aread(attr, attributeType, aString) ;
			setStringValForKeyIn(pList, aString, aKey) ;
			free(aString) ;
			break;
			
		default:
			break;
	}
	free(aKey) ;
	
    /* Release all identifiers */
    H5Tclose(attributeType);
    H5Sclose(attributeSpace);
    H5Aclose(attr);
	
    return 0;
}


static herr_t visitObjectsIteratively(hid_t parentObject, const char *childObjectName, const H5O_info_t *childObjectInfo, void *globalPListAdress) 
{
	char *aPath, aKey[128], *aString ;
    int datasetIndex, layerIndex, rank ;
	keyValue *pList, *formerKeyValuePair, *pListAll ;
	hsize_t	datasetDim[4], maxDims[4] ;
	hid_t file, currentObject, currentDataset, currentDataspace, currentDataType ;
    H5T_class_t currentDataTypeIdentifier ;
    size_t currentDataTypeSize ;
    H5T_order_t currentDataTypeOrder ;
	
    /* Some initialization to silent Valgrind */
    rank = 0 ;
    datasetDim[0] = datasetDim[1] = datasetDim[2] = datasetDim[3] = 0 ;
	
    /* Get the starting point of keyValues */
	pListAll = *(keyValue **)globalPListAdress ;
    
    /* Alloc starting point of keyValues for this object */
	pList = allocAKeyValuePair() ;
    
	printf ("/") ;               /* Print root group in object path */
	
    /* Check if the current object is the root group, and if not print the full path name and type */
    if (childObjectName[0] == '.') {
//        printf ("%s :  (Root Group)\n", childObjectName);
		aPath = initStringWith2Strings(getStringValForKeyIn(pListAll, "Text files directory"), "/rootGroup.txt") ;
	}
    else {
        switch (childObjectInfo->type) {
            case H5O_TYPE_GROUP:
//                printf ("%s  (Group)\n", childObjectName);
                aString = getFileNameFromPath((char *)childObjectName) ;
                if(!strncmp(aString, "S", 1)) {
                    layerIndex = getIntValForKeyIn(pListAll, "Number of layers") ;
                    layerIndex++ ;
                    setIntValForKeyIn(pListAll, layerIndex, "Number of layers") ;
                    sprintf(aKey, "Group name of layer %d", layerIndex) ;
                    setStringValForKeyIn(pList, aString, aKey) ;
                    sprintf(aKey, "%s layer index", aString) ;
                    setIntValForKeyIn(pList, layerIndex, aKey) ;
                }
                free(aString) ;
                break;
            case H5O_TYPE_DATASET:
                /* Open the file */
                file = H5Fopen(getStringValForKeyIn(pListAll, "HDF5 input"), H5F_ACC_RDONLY, H5P_DEFAULT);
                /* Open dataset in HDF5 file */
                currentDataset = H5Dopen2(file, childObjectName, H5P_DEFAULT);

                /* Get dataset dataspace */
                currentDataspace = H5Dget_space(currentDataset) ;
                
                /* Get dataset rank  */
                rank = H5Sget_simple_extent_ndims(currentDataspace) ;

                /* Get data type description */
                currentDataType = H5Dget_type(currentDataset) ;
                currentDataTypeIdentifier = H5Tget_class(currentDataType) ;
                currentDataTypeSize = H5Tget_size(currentDataType) ;
                currentDataTypeOrder = H5Tget_order(currentDataType) ;

                /* for rank > 0, we are only interested in vectors and matrices */
                if (rank) {
                    printf ("%s  (Dataset)\n", childObjectName);
                    datasetIndex = getIntValForKeyIn(pListAll, "Number of datasets") ;
                    datasetIndex++ ;
                    setIntValForKeyIn(pListAll, datasetIndex, "Number of datasets") ;
                    sprintf(aKey, "Dataset %d name", datasetIndex) ;
                    aPath = allocStringOfLength(strlen(childObjectName) + 1) ;
                    sprintf(aPath, "%s", childObjectName) ;
                    setStringValForKeyIn(pList, aPath, aKey) ;
                    free(aPath) ;

                    /* Get dataset full size */
                    H5Sget_simple_extent_dims(currentDataspace, datasetDim, maxDims) ;
                    
                    /* Add info to pList */
                    sprintf(aKey, "Dataset %d X size [columns]", datasetIndex) ;
                    setLongValForKeyIn(pList, datasetDim[1], aKey) ;
                    sprintf(aKey, "Dataset %d Y size [rows]", datasetIndex) ;
                    setLongValForKeyIn(pList, datasetDim[0], aKey) ;
                    sprintf(aKey, "Dataset %d data type identifier", datasetIndex) ;
                    aString = getHD5DataTypeIdentifier(currentDataTypeIdentifier) ;
                    setStringValForKeyIn(pList, aString, aKey) ;
                    free(aString) ;
                    sprintf(aKey, "Dataset %d data type size [bytes]", datasetIndex) ;
                    setLongValForKeyIn(pList, currentDataTypeSize, aKey) ;
                    sprintf(aKey, "Dataset %d data type byte order", datasetIndex) ;
                    aString = getHD5DataTypeByteOrder(currentDataTypeOrder) ;
                    setStringValForKeyIn(pList, aString, aKey) ;
                    free(aString) ;
                }
                H5Tclose(currentDataType) ;
                H5Sclose(currentDataspace) ;
                H5Dclose(currentDataset) ;
                H5Fclose(file) ;

                break;
            case H5O_TYPE_NAMED_DATATYPE:
                printf ("%s  (Datatype)\n", childObjectName);
                break;
            default:
                printf ("%s  (Unknown)\n", childObjectName);
        }
        aString = initStringWithString((char *)childObjectName) ;
        replaceSubStringInString(aString, "/", ".") ;
		aPath = initStringWith4Strings(getStringValForKeyIn(pListAll, "Text files directory"), "/", aString, ".txt") ;
        free(aString) ;
	}
    
	currentObject = H5Oopen(parentObject, childObjectName, H5P_DEFAULT);
    H5Aiterate2(currentObject, H5_INDEX_CRT_ORDER, H5_ITER_NATIVE, NULL, transferAttributeInfoToPList, (void *)pList) ;
//    writeParameterFileAtPath(pList, aPath) ;
//    printf("File %s saved\n", aPath) ;
    free(aPath) ;
    
    formerKeyValuePair = NULL ;
    if (pList->nextOne) {
        formerKeyValuePair = NULL ;
        while(pListAll->nextOne != NULL) {
            formerKeyValuePair = pListAll ;
            pListAll = pListAll->nextOne ;
        }
        
        if(formerKeyValuePair != NULL) {
            freeKeyValuePair(pListAll) ;
            formerKeyValuePair->nextOne = pList ;
        }
        else {
            *(keyValue **)globalPListAdress = pList ;
            freeKeyValuePair(pListAll) ;
        }
    }
    else {
        freeKeyValuePair(pList) ;
    }

    H5Oclose(currentObject) ;

    
    return 0;
}



static herr_t getAllRank0Data(hid_t parentObject, const char *childObjectName, const H5O_info_t *childObjectInfo, void *rank0pList) 
{
	char aKey[128] ;
    char *utf8_r = NULL;
    int rank ;
	keyValue *pList ;
	hid_t file, currentDataset, currentDataspace, currentDataType, outputDataspace, memtype ;
    H5T_class_t currentDataTypeIdentifier ;
    size_t currentDataTypeSize ;
    H5T_cset_t stringType ;
    void *rank0Data ;

 
    rank0Data = malloc(512) ;
//	setlocale(LC_CTYPE, "en_US.UTF-8");

    /* Get the starting point of keyValues */
	pList = *(keyValue **)rank0pList ;

    /* Check if the current object is the root group, and if not print the full path name and type */
    if  (childObjectInfo->type == H5O_TYPE_DATASET) {
        /* Open the file */
        file = H5Fopen(getStringValForKeyIn(pList, "HDF5 input"), H5F_ACC_RDONLY, H5P_DEFAULT);
   
        /* Open dataset in HDF5 file */
        currentDataset = H5Dopen2(file, childObjectName, H5P_DEFAULT);

        /* Get dataset dataspace */
        currentDataspace = H5Dget_space(currentDataset) ;
        
        /* Get dataset rank  */
        rank = H5Sget_simple_extent_ndims(currentDataspace) ;

        if (!rank) {
            /* Get data type description */
            currentDataType = H5Dget_type(currentDataset) ;
            currentDataTypeIdentifier = H5Tget_class(currentDataType) ;
            currentDataTypeSize = H5Tget_size(currentDataType) ;
            outputDataspace = H5Dget_space (currentDataset);

//            outputDataspace = H5Screate(H5S_SCALAR) ;
            H5Dread(currentDataset, currentDataType, outputDataspace, currentDataspace, H5P_DEFAULT, rank0Data) ;
            sprintf(aKey, "%s", childObjectName) ;
            replaceNSubStringInString(aKey, "/", " ") ;
            stripWhiteCharsAtStartOfString(aKey) ;
            switch (currentDataTypeIdentifier) {
                case H5T_INTEGER:
                    if (currentDataTypeSize == 4) {
                        setIntValForKeyIn(pList, *(int *)rank0Data, aKey) ;
                    }
                    else {
                        setLongValForKeyIn(pList, *(long *)rank0Data, aKey) ;
                    }
                    break;
                    
                case H5T_FLOAT:
                    if (currentDataTypeSize == 4) {
                        setFloatValForKeyIn(pList, *(float *)rank0Data, aKey) ;
                    }
                    else {
                        setDoubleValForKeyIn(pList, *(double *)rank0Data, aKey) ;
                    }
                    break;
                    
                case H5T_STRING:

                    stringType = H5Tget_cset(currentDataType) ;
                    if (stringType == H5T_CSET_UTF8) {
                    /* Create the memory datatype. */
                        memtype = H5Tcopy (H5T_C_S1);
                        H5Tset_size (memtype, H5T_VARIABLE);
                        H5Tset_cset(memtype, H5T_CSET_UTF8);
                        H5Dread(currentDataset, memtype, H5S_ALL, H5S_ALL, H5P_DEFAULT, &utf8_r) ;
                        setStringValForKeyIn(pList, utf8_r, aKey) ;
                        H5Tclose(memtype) ;
                        free(utf8_r) ;
                    }
                    else {
                        setStringValForKeyIn(pList, (char *)rank0Data, aKey) ;
                    }
                break;


                default:
                    break;
            }
            H5Tclose(currentDataType) ;
            H5Sclose(outputDataspace) ;
        }
        H5Sclose(currentDataspace) ;
        H5Dclose(currentDataset) ;
        H5Fclose(file) ;
    }
    free(rank0Data) ;
    return 0;
}


char *getH5SpaceTypeIdentifier(H5T_class_t dataTypeIdentifier)
{
    char *aString ;
    
    switch (dataTypeIdentifier) {
        case H5S_NULL:
            aString = initStringWithString("H5T_NULL") ;
            break;
            
        case H5S_SCALAR:
            aString = initStringWithString("H5T_SCALAR") ;
            break;
            
        case H5S_SIMPLE:
            aString = initStringWithString("H5T_SIMPLE") ;
            break;
                 
        default:
            aString = initStringWithString("H5S_NO_CLASS?") ;
            break;
    }
    
    return(aString) ;
}
   


char *getHD5DataTypeIdentifier(H5T_class_t dataTypeIdentifier)
{
    char *aString ;
    
    switch (dataTypeIdentifier) {
        case H5T_INTEGER:
            aString = initStringWithString("H5T_INTEGER") ;
            break;
            
        case H5T_FLOAT:
            aString = initStringWithString("H5T_FLOAT") ;
            break;
            
        case H5T_STRING:
            aString = initStringWithString("H5T_STRING") ;
            break;
            
        case H5T_COMPOUND:
            aString = initStringWithString("H5T_COMPOUND") ;
            break;
            
        default:
            aString = initStringWithString("H5T_?") ;
            break;
    }
    
    return(aString) ;
}


char *getHD5DataTypeByteOrder(H5T_order_t dataTypeOrder)
{
    char *aString ;
    
    switch (dataTypeOrder) {
        case H5T_ORDER_LE:
            aString = initStringWithString("H5T_ORDER_LE") ;
            break;
            
        case H5T_ORDER_BE:
            aString = initStringWithString("H5T_ORDER_BE") ;
            break;
            
        default:
            aString = initStringWithString("H5T_?") ;
            break;
    }
    
    return(aString) ;
}
