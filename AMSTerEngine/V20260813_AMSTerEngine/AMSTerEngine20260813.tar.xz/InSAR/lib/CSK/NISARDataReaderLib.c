
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  NISARDataReaderLib.c
//  NISARDataReader
//
//  Created by Dominique Derauw on 20/12/2024.
//  Copyright © 2024 Dominique Derauw - SAREOS. All rights reserved.
//

#include "hdf5DataReaderLib.h"
#include "NISARDataReaderLib.h"


CSVStruct *NISARDataReader(CSVStruct *csv)
{
    char *outputDir = NULL, *dumpDir, *dirName, *keyValsPath ;
    char *outputDirFreqA, *outputDirFreqB ;
    char *requestedPolScheme = NULL, *requestedFrequency = NULL, *string1, *string2, *requestedLayer = NULL ;
    char *excludedFrequency = NULL ;
    size_t i ;
    CSVStruct *H5Filepath = NULL, *readImages = NULL ;
    CSVStruct *availablePolScheme, *excludedDatasetNames = NULL ;
    keyValue *pList ;
    SLCImageInfo *info, *info2 ;
    CSLImage *freqAImage, *freqBImage ;
    rawFileDescriptor *keyValsFile ;
    CSVStruct *polScheme = NULL ;

    if(csv->numberOfEntries == 1 || isArgumentPresentInCSV(csv, "help") || isArgumentPresentInCSV(csv, "-h")) {
		NISARDataReaderHelp() ;
    }

    /* If parameter 1 is a directory, we will consider it contains one or more .h5 files to be read */
    /* If parameter is an .h5 file, we read it. */
    if (!isDir(csv->stringVal[1])) {
        dumpDir = getPointerToLastFileExtensionInPath(csv->stringVal[1]) ;
        if (!dumpDir || strncmp(dumpDir, "h5", 2) != 0) {
            printf("\t-/-> first parameter must be a valid directory or a path to an hdf5 (.h5) file\n") ;
            NISARDataReaderHelp() ;
        }
    }

    /* Get output directory if given */
    for (i = 2; i < csv->numberOfEntries; i++) {
        if (!outputDir && isDir(csv->stringVal[i])) {
            outputDir = initStringWithString(csv->stringVal[i]) ;
        }
    }

    /* Check polarisation scheme request */
    if ((i = isArgumentPresentInCSV(csv, "P="))) {
        requestedPolScheme = initStringWithString(csv->stringVal[i] + 2) ;
    }
    
    /* Check frequency request */
    if ((i = isArgumentPresentInCSV(csv, "freq="))) {
        requestedFrequency = initStringWith3Strings("frequency", csv->stringVal[i] + 5, "/") ;
    }

    /* Build .h5 file listing */
    if (isDir(csv->stringVal[1])) {
        H5Filepath = recursiveSearchOfFilesWithExtensionInDir("h5", (char *)csv->stringVal[1]) ;
        if (!outputDir){
            outputDir = initStringWithString(csv->stringVal[1]) ;
        }
        
    }
    else {
        if (!strcmp(getPointerToFileExtensionInPath(csv->stringVal[1]), "h5")) {
            H5Filepath = addStringValInCSVStruct(csv->stringVal[1], H5Filepath) ;
            if (!outputDir){
                outputDir = getDirectoryPathFromPath(csv->stringVal[1]) ;
            }
        }
    }

    /* Check .h5 files are RSLC data files */
    if (H5Filepath) {
        for (i = 0; i < H5Filepath->numberOfEntries; i++) {
            if (!isSubStringPresentInString(H5Filepath->stringVal[i], "_RSLC_")) {
                printf("\t---> File %s is not an RSLC file\n\t Removing file from listing\n", H5Filepath->stringVal[i]) ;
                removeStringValAtIndexInCSVStruct(i, H5Filepath) ;
                i-- ;
            }
            if (isSubStringPresentInString(H5Filepath->stringVal[i], "_QA_STATS")) {
                printf("\t---> File %s is not an RSLC image\n\t Removing file from listing\n", H5Filepath->stringVal[i]) ;
                removeStringValAtIndexInCSVStruct(i, H5Filepath) ;
                i-- ;
            }
        }
    }
    
    if (!H5Filepath) {
        printf("\t-/-> No RSLC .h5 files found in input directory\nStopping here. \n\n") ;
        return(NULL) ;
    }
    
    if (!isWriteAccessGrantedAtPath(outputDir)) {
        ase("\t-/-> Write access denied in output directory.\n\n") ;
    }
    
    checkExistingNISARData(outputDir, H5Filepath, isFlagPresentInCSV(csv, "r")) ;
    
    /* Create Frequency A and B output directories */
    outputDirFreqA = initStringWith2Strings(outputDir, "/FrequencyA") ;
    outputDirFreqB = initStringWith2Strings(outputDir, "/FrequencyB") ;
    if (requestedFrequency) {
        if (!strcmp(requestedFrequency, "frequencyA/")) {
            free(outputDirFreqB) ;
            outputDirFreqB = NULL ;
            excludedFrequency = initStringWithString("frequencyB/") ;
        }        
        if (!strcmp(requestedFrequency, "frequencyB/")) {
            free(outputDirFreqA) ;
            outputDirFreqA = NULL ;
            excludedFrequency = initStringWithString("frequencyA/") ;
        }
    }
    makeDirRecursively(outputDirFreqA) ;
    makeDirRecursively(outputDirFreqB) ;

    /* Check if some dataset names should be excluded */
    /* Generate list of all readable NISAR products as excluded ones */
    /* And remove from the list, products to be kept */
    polScheme = addStringValInCSVStruct("VV", polScheme) ;
    polScheme = addStringValInCSVStruct("VH", polScheme) ;
    polScheme = addStringValInCSVStruct("HV", polScheme) ;
    polScheme = addStringValInCSVStruct("HH", polScheme) ;
    requestedLayer = initStringWith2Strings(requestedFrequency, requestedPolScheme) ;
    if (requestedLayer) {
        for (i = 0; i < polScheme->numberOfEntries; i++) {
            string1 = (polScheme)? polScheme->stringVal[i] : NULL ;
            string2 = initStringWith2Strings("/frequencyA/", string1) ;
            if (string2) {
                excludedDatasetNames = addStringValInCSVStruct(string2, excludedDatasetNames) ;
                free(string2) ;
            }
            if (isSubStringPresentInString(excludedDatasetNames->stringVal[excludedDatasetNames->numberOfEntries - 1], requestedLayer)) {
                removeStringValAtIndexInCSVStruct(excludedDatasetNames->numberOfEntries - 1, excludedDatasetNames) ;
            }
            
            string2 = initStringWith2Strings("/frequencyB/", string1) ;
            if (string2) {
                excludedDatasetNames = addStringValInCSVStruct(string2, excludedDatasetNames) ;
                free(string2) ;
            }
            if (isSubStringPresentInString(excludedDatasetNames->stringVal[excludedDatasetNames->numberOfEntries - 1], requestedLayer)) {
                removeStringValAtIndexInCSVStruct(excludedDatasetNames->numberOfEntries - 1, excludedDatasetNames) ;
            }
        }
    }
    
    /* Dump HDF5 data in destination directory */
    printf("\t---> Number of RSLC .h5 images to read: %d\n", H5Filepath->numberOfEntries) ;
    for (i = 0; i < (size_t)H5Filepath->numberOfEntries; i++) {
        /* Create destination directory */
        dirName = getFileNameFromPath(H5Filepath->stringVal[i]) ;
        stripExtensionAtEndOfPath(dirName) ;
        dumpDir = initStringWith3Strings(outputDir, "/", dirName) ;
        makeDirRecursively(dumpDir) ;

        /* Dump hdf5 file */
        printf("\n\t---> Reading %s file\n", H5Filepath->stringVal[i]) ;
        pList = hdf5Dump(H5Filepath->stringVal[i], dumpDir, isFlagPresentInCSV(csv, "v"), excludedDatasetNames) ;

        if (!(info = createSLCInfoImageForNISARData(dumpDir, requestedPolScheme))) {
            printf("\t-/-> .h5 file does not seems to be a valid RSLC NISAR file\n") ;
        }
        
        if (info) {  
            if (outputDirFreqA) {
                freqAImage = saveNISARDataInCSLImageStruct(outputDirFreqA, info) ;
                readImages = addStringValInCSVStruct(freqAImage->imageDirectoryPath, readImages) ;
                printf("\t---> Image saved as %s\n", freqAImage->imageDirectoryPath) ;
                keyValsPath = initStringWith2Strings(freqAImage->headersDirectoryPath, "/keyVals.txt") ;
                keyValsFile = openRawFileForWritingAtPath(keyValsPath) ;
                writeParameterListIntoRawFile(pList, keyValsFile) ;
                freeRawFileDescriptor(keyValsFile) ;
                free(keyValsPath) ;
                freeCSLImageStructure(freqAImage) ;
            }                 

            if (info->sensorSpecificInfo && outputDirFreqB) {
                info2 = info->sensorSpecificInfo ;
                freqBImage = saveNISARDataInCSLImageStruct(outputDirFreqB, info2) ;
                readImages = addStringValInCSVStruct(freqBImage->imageDirectoryPath, readImages) ;
                printf("\t---> Image saved as %s\n", freqBImage->imageDirectoryPath) ;
                keyValsPath = initStringWith2Strings(freqBImage->headersDirectoryPath, "/keyVals.txt") ;
                keyValsFile = openRawFileForWritingAtPath(keyValsPath) ;
                writeParameterListIntoRawFile(pList, keyValsFile) ;
                freeRawFileDescriptor(keyValsFile) ;
                free(keyValsPath) ;

                freeInfoImage(info2) ;
                info->sensorSpecificInfo = NULL ;
                freeCSLImageStructure(freqBImage) ;
            }
            freeInfoImage(info) ;
        }
        else {
            printf("\t-/-> Skipping file %s\n\tIt does not seems to be a NISAR data file.\n", H5Filepath->stringVal[i]) ;
        }
        removeDirectoryAtPath(dumpDir) ;

        freeKeyValueList(pList) ;
        free(dirName) ;
        free(dumpDir) ;
    }

    free(outputDir) ;
    free(outputDirFreqA) ;
    free(outputDirFreqB) ;
    freeCSVStruct(H5Filepath) ;

    return (readImages) ;
}

void NISARDataReaderHelp()
{
    printf("\nUsage:") ;
    printf("\n\tNISARDataReader inputPath [outputPath] [-rv] [P=XY] [freq=A/B]\n") ;
    printf("\n\tIn this form, NISARDataReader performs a bulk reading of\n\tall h5 data found within the directory given in input\n\tand all its subdirectories.") ;
    printf("\n\tIf an output path is not provided, all data\n\twill be saved within the input directory.") ;
    printf("\n\t-r: Force re-reading.") ;
    printf("\n\t-v: Verbose.") ;
    printf("\n\tP=XY: Polarization scheme selection. If requested polarisation scheme is available, only this one will be kept.") ;
    printf("\n\tfreq=A/B: Allows selecting the frequency channel that will be kept.") ;
    printf("\n\t") ;
	exit(0) ;
}

SLCImageInfo *createSLCInfoImageForNISARData(char *dumpDir, char *requestedPol)
{
    char *keyValsFilePath, isLBand, isFreqA, isFreqB ;
    char frequencyAB[11] ;
    SLCImageInfo *info, *info2 = NULL ;
    keyValue *params ;

    /* Read dumped keyValues */
    keyValsFilePath = initStringWith2Strings(dumpDir, "/keyVals.txt") ;
    params = readParameterFileAtPath(keyValsFilePath) ;
    
    /* Allocate infoImage structure */
    info = allocInfoImage() ;
    if (requestedPol) {
        info->polScheme = addStringValInCSVStruct(requestedPol, info->polScheme) ;
    }
    

    isFreqA = (isKeyValContainingStringPresent(params, "frequencyA") != NULL) ;
    isFreqB = (isKeyValContainingStringPresent(params, "frequencyB") != NULL) ;
    if (isFreqA) {
        sprintf(frequencyAB, "frequencyA") ;
    }
    else {
        sprintf(frequencyAB, "frequencyB") ;
    }
    
    initInfoImageForNISARFrequency(info, frequencyAB, dumpDir) ;

    /* If dealing with dual band, create frequency B info image*/
    if (isFreqA && isFreqB) {
        sprintf(frequencyAB, "frequencyB") ;
        info2 = allocInfoImage() ;
        if (requestedPol) {
            info2->polScheme = addStringValInCSVStruct(requestedPol, info2->polScheme) ;
        }
        initInfoImageForNISARFrequency(info2, frequencyAB, dumpDir) ;
        info->sensorSpecificInfo = info2 ;
        sprintf(info2->platformName, "%s", info->platformName) ;    

        /* Reference range */
        info2->referenceRange = 0 ;
    }
    free(keyValsFilePath) ;
    freeKeyValueList(params) ;

    return (info) ;
}


void initInfoImageForNISARFrequency(SLCImageInfo *info, char* frequencyAB, char *dumpDir)
{
    char *keyValsFilePath, isLBand, *aString, *aKey, *aFileName, frameNumber[4] ;
    char band[5], *swathsDir, *bandDir, *frequencyDir, *dopplerDir, *orbitDir, *paramsDir, *metaDataDir ;
    int iX ;
    double lon, lat ;
    polygon *area ;
    keyValue *params, *aKeyVal, *datasetParams ;
    datasetVals *thisDataset ;
    CSVStruct *csv ;

    /* Read dumped keyValues */
    keyValsFilePath = initStringWith2Strings(dumpDir, "/keyVals.txt") ;
    params = readParameterFileAtPath(keyValsFilePath) ;
    
    /* Satellite ID */
    /* Check product type */
    isLBand = (isKeyValContainingStringPresent(params, "LSAR") != NULL) ;
    if (!isLBand && !isKeyValContainingStringPresent(params, "SSAR")) {
        freeKeyValueList(params) ;
        free(keyValsFilePath) ;
        
        ase("Failed to determining product type. Neither LSAR nor SSAR keywords found\n") ;
    }

    if (isLBand) {
        sprintf(info->platformName, "NISAR-L") ;
        sprintf(band, "LSAR") ;
    }
    else {
        sprintf(info->platformName, "NISAR-S") ;
        sprintf(band, "SSAR") ;
    }

    /* Build base directories paths */
    bandDir = initStringWith3Strings(dumpDir, "/science/", band) ;
    swathsDir = initStringWith2Strings(bandDir, "/RSLC/swaths") ;
    frequencyDir = initStringWith3Strings(bandDir, "/RSLC/swaths/", frequencyAB) ;
    metaDataDir = initStringWith2Strings(bandDir, "/RSLC/metadata/") ;
    paramsDir = initStringWith2Strings(bandDir, "/RSLC/metadata/processingInformation/parameters/") ;
    dopplerDir = initStringWith2Strings(paramsDir, frequencyAB) ;
    orbitDir = initStringWith2Strings(bandDir, "/RSLC/metadata/orbit/") ;
    info->parameterList = allocAKeyValuePair () ;
    setStringValForKeyIn(info->parameterList, frequencyDir, "Frequency dir") ;
    setStringValForKeyIn(info->parameterList, metaDataDir, "Meta data dir") ;
    
    /* Acquisition date */
    info->acquisitionDate = allocStringOfLength(10) ;
    if ((aKeyVal = isKeyValContainingStringPresent(params, "zeroDopplerStartTime"))) {
        sprintf(info->acquisitionDate, "%.10s", aKeyVal->stringVal) ;
        removeAnyOccurrenceOfSubStringInString(info->acquisitionDate, "-") ;
    }
    
    /* Polarisation mode */
    csv = recursiveSearchOfFileInDir("listOfPolarizations", frequencyDir) ;
    thisDataset = readDumpedDatasetAtPath(csv->stringVal[0]) ;
    freeCSVStruct(csv) ;
    aString = allocStringOfLength(3) ;
    for (iX = 0; iX < thisDataset->dims[0]; iX++) {
        memcpy(aString, thisDataset->v + 2 * iX, 2) ;
        sprintf(info->polMode + iX * 4, "%s, ", aString) ;
    }
    info->polMode[strlen(info->polMode) - 2] =  '\0' ;
    free(aString) ;
    freeDatasetVals(thisDataset) ;

    if (info->polScheme) {
        csv = readCSVInString(info->polMode) ;
        for (iX = 0; iX < csv->numberOfEntries; iX++) {
            if (!strcmp(csv->stringVal[iX], info->polScheme->stringVal[0])) {
                break ;
            }
        }
        if (iX == csv->numberOfEntries) {
            ase("\t-/-> Requested polarization not available\n") ;
        }
        
        sprintf(info->polMode, "%s", info->polScheme->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    
    /* Relative orbit number only given in NISAR file name */
    aFileName = getPointerToFileNameInPath(dumpDir) ;
    sscanf(aFileName + 21, "%3d", &(info->relativeOrbitNumber)) ;
    
    /* Product ID */
    sprintf(info->productID, "%s", getStringValForKeyIn(params, "identification/granuleId")) ;
    
    /* Beam ID */
    info->beamNumber = 0 ;
    
    /* Scene ID */
    csv = NULL ;
    if ((aKeyVal = isKeyValContainingStringPresent(params, "missionId"))) {
        csv = addStringValInCSVStruct(aKeyVal->stringVal, csv) ;
    }
    if ((aKeyVal = isKeyValContainingStringPresent(params, "absoluteOrbitNumber"))) {
        csv = addStringValInCSVStruct(" - Absolute orbit number : ", csv) ;
        csv = addStringValInCSVStruct(aKeyVal->stringVal, csv) ;
    }
    if ((aKeyVal = isKeyValContainingStringPresent(params, "trackNumber"))) {
        csv = addStringValInCSVStruct(" - Track number : ", csv) ;
        csv = addStringValInCSVStruct(aKeyVal->stringVal, csv) ;
    }
    csv = addStringValInCSVStruct(" - Frame number : ", csv) ;
    if ((aKeyVal = isKeyValContainingStringPresent(params, "frameNumber"))) {
        csv = addStringValInCSVStruct(aKeyVal->stringVal, csv) ;
    }
    else {
        sscanf(aFileName + 27, "%3s", frameNumber) ;
        csv = addStringValInCSVStruct(frameNumber, csv) ;
    }
    aString = getStringFromCSV(csv) ;
    sprintf(info->scene_id, "%s", aString) ;
    free(aString) ;
    freeCSVStruct(csv) ;
    
    /* Look direction */
    if ((aKeyVal = isKeyValContainingStringPresent(params, "lookDirection"))) {
        convertStringToLowercase(aKeyVal->stringVal) ;
        info->lookDirection = (strcmp(aKeyVal->stringVal, "right") == 0)? RIGHT_LOOKING : LEFT_LOOKING ;
    }
    
    /* PRF */
    if ((aKeyVal = isKeyValContainingStringPresent(params, "nominalAcquisitionPRF"))) {
        sscanf(aKeyVal->stringVal, "%lf", &info->prf) ;
    }
    
    /* SLC data dimensions */
    csv = readCSVInString(info->polMode) ;
    aString = initStringWith2Strings(csv->stringVal[0], ".txt") ;
    freeCSVStruct(csv) ;
    if ((csv = recursiveSearchOfFileInDir(aString, swathsDir))) {
        datasetParams = readParameterFileAtPath(csv->stringVal[0]) ;
    }
    else {
        printf("\t-/-> Data file descriptor not found. Cannot determine data file size.\n") ;
        return ;
    }
    info->rangeDimension = getIntValForKeyIn(datasetParams, "Y") ;
    info->azimuthDimension = getIntValForKeyIn(datasetParams, "X") ;
    freeKeyValueList(datasetParams) ;
    freeCSVStruct(csv) ;
    free(aString) ;
    
    /* First and last pixel Azimuth Time */
    if ((aKeyVal = isKeyValContainingStringPresent(params, "zeroDopplerStartTime"))) {
        info->FPAT = getSecondsFromFormattedDate(aKeyVal->stringVal) ;
    }
    if ((aKeyVal = isKeyValContainingStringPresent(params, "zeroDopplerEndTime"))) {
        info->LPAT = getSecondsFromFormattedDate(aKeyVal->stringVal) ;
    }
    
    /* Radar carrier frequency */
    aKey = initStringWith2Strings(frequencyAB, "/acquiredCenterFrequency") ;
    if ((aKeyVal = isKeyValContainingStringPresent(params, aKey))) {
            sscanf(aKeyVal->stringVal, "%lf", &info->radarCarrierFrequency) ;
    }
    free(aKey) ;
    /* Wavelength */
    info->wavelength = speedOfLight / info->radarCarrierFrequency ;
    
    /* Range bandwidth  */
    aKey = initStringWith2Strings(frequencyAB, "/acquiredRangeBandwidth") ;
    if ((aKeyVal = isKeyValContainingStringPresent(params, aKey))) {
        sscanf(aKeyVal->stringVal, "%lf", &info->rangeBandwidth) ;
    //        printf("---> Acquired range bandwidth: %lf\n", info->rangeBandwidth) ;
    }
    free(aKey) ;
    
    /* Range sampling frequency */
    aKey = initStringWith2Strings(frequencyAB, "/processedRangeBandwidth") ;
    if ((aKeyVal = isKeyValContainingStringPresent(params, aKey))) {
        sscanf(aKeyVal->stringVal, "%lf", &info->rangeSamplingFrequency) ;
    //        printf("---> Processed range bandwidth: %lf\n", info->rangeSamplingFrequency) ;
    }
    free(aKey) ;

    /* Sampling frequency is said to be 1.2 times the range bandwith except for 77MHz data bandwidth */
    if (info->rangeBandwidth == 77000000) {
        info->rangeSamplingFrequency = 94000000 ;
    }
    else {
        info->rangeSamplingFrequency = 1.2 * info->rangeBandwidth ;
    }
    //    printf("---> Computed range sampling frequency: %lf\n", info->rangeSamplingFrequency) ;
    
    /* Range resolution cell */
    aKey = initStringWith2Strings(frequencyAB, "/slantRangeSpacing") ;
    if ((aKeyVal = isKeyValContainingStringPresent(params, aKey))) {
            sscanf(aKeyVal->stringVal, "%lf", &info->rangeResolutionCell) ;
    }
    free(aKey) ;

    /* Range apodization coefficient  */
    /* It is a Kaiser window of factor 1.6 that is used */
    /* We approximate it as a Hamming window */
    info->rangeApodizationCoefficient = 0.54 ; 
    
    /* Min and max slant range */
    csv = recursiveSearchOfFileInDir("slantRange", frequencyDir) ;
    thisDataset = readDumpedDatasetAtPath(csv->stringVal[0]) ;
    freeCSVStruct(csv) ;
    info->slantRange[0] = ((double *)thisDataset->v)[0] ;
    info->slantRange[2] = ((double *)thisDataset->v)[thisDataset->dims[0] - 1] ;
    info->slantRange[1] = (info->slantRange[0] + info->slantRange[2]) / 2. ;
    info->twoWayRangeTime[0] = 2. / c0 * info->slantRange[0] ;
    info->twoWayRangeTime[1] = 2. / c0 * info->slantRange[1] ;
    info->twoWayRangeTime[2] = 2. / c0 * info->slantRange[2] ;
    freeDatasetVals(thisDataset) ;
    
    /* Azimuth Bandwith, resolution and line time spacing */
    if ((aKeyVal = isKeyValContainingStringPresent(params, "processedAzimuthBandwidth"))) {
        sscanf(aKeyVal->stringVal, "%lf", &info->azimuthBandwidth) ;
    }
    if ((aKeyVal = isKeyValContainingStringPresent(params, "sceneCenterAlongTrackSpacing"))) {
        sscanf(aKeyVal->stringVal, "%lf", &info->azimuthResolutionCell) ;
    }
    if ((aKeyVal = isKeyValContainingStringPresent(params, "zeroDopplerTimeSpacing"))) {
        sscanf(aKeyVal->stringVal, "%lf", &info->lineTimeInterval) ;
    }
    
    /* FDC polynomial approximation */
    if (info->fdc != NULL) {
        freeVectorDouble(info->fdc, 0) ;
    }
    info->fdc = approxNISARFDC(dopplerDir, info) ;
    
    /* Read and select state vectors */
    readNISARStateVects(orbitDir, info) ;
    info->FVT = info->S[0].t ;
    info->Dt = -1 ; /* Delta T between state vectors not necessarily constant */
    info->aX = info->aY = info->aZ = info->aVx= info->aVy= info->aVz = NULL ;
    info->isOrbitInterpolationDone = 0 ;
    
    /* Reference ellipsoid */
    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL) {
        perror("Erreur d'allocation de *info->ellRef\n") ;
        exit(-1) ;
    }
    sprintf(info->ellRef->ellipsoidID, "WGS84") ;
    info->ellRef->a = 6.378137000000000e+06 ; // Predefined as WGS84
    info->ellRef->b = 6.356752314245000e+06 ; // Predefined as WGS84
    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;
    
    /* Geolocate scene on reference ellipsoid */
    info->sceneAverageHeight = computeAverageTerrainHeightForNISAR(paramsDir) ;
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
    info->EarthRadiusAtSceneCenter = 6371221. ;
    info->incidenceAngle[0] = 0. ;
    geolocateSceneOnEllipsoid(info, info->ellRef) ;
    
    /* Scene centre approxilmate location */
    area = circumscribedRectangleOfPolygon(info->loc) ;
    lat = 180./PI * (area->P[0].y + area->P[2].y) / 2. ;
    lon = 180./PI * (area->P[0].x + area->P[2].x) / 2. ;
    sprintf(info->scene_loc, "Center longitude: %.4g\tCenter latitude: %.4g", lon, lat) ;
    freePolygon(area) ;
    
    /* Reference range */
    info->referenceRange = 0 ;

    free(bandDir)  ;
    free(swathsDir) ;
    free(frequencyDir) ;
    free(metaDataDir) ;
    free(paramsDir) ;
    free(dopplerDir) ;
    free(orbitDir) ;
    freeKeyValueList(params) ;
    free(keyValsFilePath) ;
}


/* FDC polynomial approximation based on 2D LUT */
double *approxNISARFDC(char *dopplerDir, SLCImageInfo *info)
{
    char *aPath ;
    int ii, ij, iX, iY, *indexVector ;
    double **M, *V, *avgCoeffs, signe ;
    double rangeIndex, dc0 ;
    
    datasetVals *azimuth, *slantRange, *dc ;

    aPath = initStringWith2Strings(dopplerDir, "/zeroDopplerTime") ;
    azimuth = readDumpedDatasetAtPath(aPath) ;
    free(aPath) ; 
    aPath = initStringWith2Strings(dopplerDir, "/slantRange") ;
    slantRange = readDumpedDatasetAtPath(aPath) ;
    free(aPath) ; 
    aPath = initStringWith2Strings(dopplerDir, "/dopplerCentroid") ;
    dc = readDumpedDatasetAtPath(aPath) ;
    free(aPath) ; 

    M = matrixDouble(1, 3, 1, 3) ;
    V = vectorDouble(1, 3) ;
    avgCoeffs = vectorDouble(0, 2) ;
    indexVector = vectorInt(1, 3) ;

    /* FDC polynomial estimation by mean square calculation for each line of the 2D LUT and averaging*/
    for (iY = 0; iY < dc->dims[0]; iY++) {
        /* Mean square initialization */
        for (ii = 1; ii <= 3; ii++) {
            for (ij = ii; ij <= 3; ij++) {
                M[ii][ij] = M[ij][ii] = 0. ;
            }
            V[ii] = 0. ;
        }

        /* Mean square calculation */
        for (iX = 0; iX < dc->dims[1]; iX++) {
            rangeIndex = (((double *)slantRange->v)[iX] - info->slantRange[0]) / info->rangeResolutionCell ;
            dc0 = ((double **)dc->m)[iY][iX] ;
            M[1][2] += rangeIndex ;
            M[1][3] += pow(rangeIndex, 2.) ;
            M[2][3] += pow(rangeIndex, 3.) ;
            M[3][3] += pow(rangeIndex, 4.) ;
            V[1] += dc0 ;
            V[2] += dc0 * rangeIndex ;
            V[3] += dc0 * pow(rangeIndex, 2.) ;
        }
        M[1][1] = dc->dims[1] ;
        M[2][1] = M[1][2] ;
        M[3][1] = M[2][2] = M[1][3] ;
        M[3][2] = M[2][3] ;

        ludcmp(M, 3, indexVector, &signe) ;
        lubksb(M, 3, indexVector, V) ;

        for (iX = 1; iX <= 3; iX++) {
            avgCoeffs[iX - 1] += V[iX] / dc->dims[0] ;
        }
    }

    freeDatasetVals(dc) ;
    freeDatasetVals(slantRange) ;
    freeDatasetVals(azimuth) ;

    freeVectorInt(indexVector, 1) ;
    freeMatrixDouble(M, 1, 1) ;
    freeVectorDouble(V, 1) ;

    return (avgCoeffs) ;
}


/* Read NISAR state vectors in dumped hd5 dataset */
struct stateVect    *readNISARStateVects(char *orbitDir, SLCImageInfo *info) 
{
    char *aPath ;
    int i, numberOfStateVectors ;
    double **pos, **vel ;
    datasetVals *azimuthTime, *position, *velocity ;
    struct stateVect *stateVector ;

    aPath = initStringWith2Strings(orbitDir, "/time") ;
    azimuthTime = readDumpedDatasetAtPath(aPath) ;
    free(aPath) ; 
    aPath = initStringWith2Strings(orbitDir, "/position") ;
    position = readDumpedDatasetAtPath(aPath) ;
    free(aPath) ; 
    aPath = initStringWith2Strings(orbitDir, "/velocity") ;
    velocity = readDumpedDatasetAtPath(aPath) ;
    free(aPath) ; 

    info->nVect = numberOfStateVectors = azimuthTime->dims[0] ;
    info->Dt = -1 ; /* Delta T between state vectors not necessarily constant */
    info->S = stateVector = allocVectorOfStateVectorsOfLength(numberOfStateVectors) ;
    pos = ((double**)position->m) ;
    vel = ((double**)velocity->m) ;
    for (i = 0; i < numberOfStateVectors; i++) {
        stateVector[i].P[0] = pos[i][0] ;
        stateVector[i].P[1] = pos[i][1] ;
        stateVector[i].P[2] = pos[i][2] ;
        stateVector[i].V[0] = vel[i][0] ;
        stateVector[i].V[1] = vel[i][1] ;
        stateVector[i].V[2] = vel[i][2] ;
        stateVector[i].t = ((double*)azimuthTime->v)[i] ;
    }


    freeDatasetVals(velocity) ;
    freeDatasetVals(position) ;
    freeDatasetVals(azimuthTime) ;

    return info->S ;
}

double computeAverageTerrainHeightForNISAR(char *paramsDir)
{
    char *aPath ;
    int iX, iY, iYMax ;
    double avgHeight = 0 ;
    datasetVals *height ;

    aPath = initStringWith2Strings(paramsDir, "/referenceTerrainHeight") ;
    height = readDumpedDatasetAtPath(aPath) ;
    free(aPath) ; 

    iYMax = 0 ;
    if (height->rank == 2){
        iYMax = height->dims[1] - 1 ;
    }
    
    for ( iY = 0; iY <= iYMax; iY++) {
        for ( iX = 0; iX < height->dims[0]; iX++) {
            avgHeight += (iYMax)? ((float**)height->m)[iX][iY] : ((float*)height->v)[iX] ;
        }
    }
    avgHeight /= (iYMax)? height->dims[0] * iYMax : height->dims[0] ;

    freeDatasetVals(height) ;
    
    return (avgHeight) ;
}

/* Save/move NISAR dumped data into a .csl image structure to be created in outputDir */
/* Returns the created .csl image structure */
CSLImage *saveNISARDataInCSLImageStruct (char *outputDir, SLCImageInfo *info)
{
    char *frequencyDir, *metaDataDir, *sourceDir, *destDir, *imageName ;
    int iPol ;
    CSLImage *thisImage ;
    CSVStruct *pol ;

    sprintf(accessPath, "%s/NISAR_%.8s_%.1s.csl", outputDir, info->acquisitionDate, info->heading) ;
    thisImage = createCSLDirectoryStructureAtPath(accessPath, __NISAR__) ;

    saveInfoImageInCSLImage(info, thisImage) ;
    saveInfoKmlInDir(info, thisImage->infoDirectoryPath) ;

    frequencyDir = getStringValForKeyIn(info->parameterList, "Frequency dir") ;
    metaDataDir = getStringValForKeyIn(info->parameterList, "Meta data dir") ;
    destDir = initStringWith2Strings(thisImage->headersDirectoryPath, "/Metadata") ;
    rename(metaDataDir, destDir) ;
    free(destDir) ;

    pol = readCSVInString(info->polMode) ;
    for (iPol = 0; iPol < pol->numberOfEntries; iPol++) {
        destDir = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", pol->stringVal[iPol]) ;
        sourceDir = initStringWith3Strings(frequencyDir, "/", pol->stringVal[iPol]) ;
        rename(sourceDir, destDir) ;
        free(sourceDir) , 
        free(destDir) ;
    }
    freeCSVStruct(pol) ;

    return(thisImage) ;
}

/* Verification of existing NISAR data in .csl format based on NISAR naming convention */
void checkExistingNISARData(char *outputDir, CSVStruct *H5Filepath, int reread) 
{
    char *imageName, *h5FileName ;
    int i, j ; 
    CSVStruct *CSLImagePath ;


    printf("\t---> Number of images to be read : %d\n", H5Filepath->numberOfEntries) ;
    for (i = 0; i < H5Filepath->numberOfEntries; i++) {
        h5FileName = getPointerToFileNameInPath(H5Filepath->stringVal[i]) ;
        imageName = allocStringOfLength(32) ;
        sprintf(imageName, "NISAR_%.8s_%.1s.csl", h5FileName + 43, h5FileName +25) ;

        CSLImagePath = recursiveSearchOfDirInDir(imageName, outputDir) ;
        if (CSLImagePath) {
            printf("\t---> %s image corresponding to %s file allready present in destination directory\n", imageName, H5Filepath->stringVal[i]) ;
            if (reread) {
                for (j = 0; j < CSLImagePath->numberOfEntries; j++) {
                    printf("\t\t---> Removing existing image for rereading as requested\n\t\t%s\n", CSLImagePath->stringVal[j]) ;
                    removeDirectoryAtPath(CSLImagePath->stringVal[j]) ;
                }
            }
            else {
                printf("\t\t---> Removing existing .h5 image from listing to skip reading\n") ;
                removeStringValAtIndexInCSVStruct(i, H5Filepath) ;
                i-- ;
            }
            
            freeCSVStruct(CSLImagePath) ;
        }
        
        free(imageName) ;
    }
}
