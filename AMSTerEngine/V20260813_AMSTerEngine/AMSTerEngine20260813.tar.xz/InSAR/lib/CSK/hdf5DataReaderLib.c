
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
// hdf5DataReaderLib.c
//
// Created by Dominique Derauw on Fri Dec 20 2024
// Copyright (c) 2024 Dominique Derauw - SAREOS. All right reserved.
//

#include "hdf5DataReaderLib.h"


keyValue *hdf5Dump(char *inputPath, char *outputPath, char blahblah, CSVStruct *excludedDatasetNames)
{
    char *aPath ;
	hid_t   HDF5File;      /* File and dataset identifiers */
	hid_t	rootGroup ;
	herr_t  status;                /* Return value */
	keyValue *pListAll = NULL ;
    H5G_info_t groupe_info;


    pListAll = setStringValForKeyIn(pListAll, inputPath, "hdf5 file path") ;
    setStringValForKeyIn(pListAll, outputPath, "Dump directory") ;
    setIntValForKeyIn(pListAll, 0, "Number of vector datasets") ;
    setIntValForKeyIn(pListAll, 0, "Number of matrix datasets") ;
    setUCharValForKeyIn(pListAll, blahblah, "Verbose") ;
    if (excludedDatasetNames) {
        setCSVValForKeyIn(pListAll, excludedDatasetNames, "Excluded dataset names") ;
    }
    
    /* Open the file */
	if((HDF5File = H5Fopen(inputPath, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0) {
        ase("Failed to open HDF5 file") ;
    }
	
#if !defined(H5Ovisit_vers) || H5Ovisit_vers == 1  || H5Ovisit_vers == 2
/* Visit group iteratively to identify all objects */
    status = H5Ovisit(HDF5File, H5_INDEX_NAME, H5_ITER_NATIVE, scalarObjectScan, pListAll) ;
    status = H5Ovisit(HDF5File, H5_INDEX_NAME, H5_ITER_NATIVE, matrixAndVectorObjectsScan, pListAll) ;
    #else 
    /* Visit group iteratively to identify all objects */
    status = H5Ovisit3(HDF5File, H5_INDEX_NAME, H5_ITER_NATIVE, scalarObjectScan, pListAll, H5O_INFO_ALL) ;
    status = H5Ovisit3(HDF5File, H5_INDEX_NAME, H5_ITER_NATIVE, matrixAndVectorObjectsScan, pListAll, H5O_INFO_ALL) ;
#endif
    
    if (status < 0) {
        ase("failed to scan hdf file iteratively\n") ;
    }
    
    H5Fclose(HDF5File) ;
    
    aPath = initStringWith2Strings(outputPath, "/keyVals.txt") ;
    writeParameterFileAtPath(pListAll, aPath) ;
    free(aPath) ;

    return(pListAll) ;
}


// Scalar object scan call-back function
herr_t scalarObjectScan(hid_t objectID, const char *datasetName, const H5O_info_t *objectInfo, void *pList) {
    char aChar, *aString = NULL, blahblah ;
    int anInt ;
    float aFloat ;
    double aDouble ;
    hdf5DatasetDescriptor *h5 ;

    blahblah = getCharValForKeyIn(pList, "Verbose") ;
    /* If we deal with a dataset */
    if (objectInfo->type == H5O_TYPE_DATASET) {
        if((h5 = allocAndInitH5DatasetDescriptor(objectID, datasetName)) == NULL) {
            return (0) ;
        }


        if (h5->rank == 0) {
            /* Read and save data in pList */
            if (H5Tequal(h5->typeID, H5T_NATIVE_INT)) {
                H5Dread(h5->dataset, H5T_NATIVE_INT, H5S_ALL, H5S_ALL, H5P_DEFAULT, &anInt) ;
                setIntValForKeyIn(pList, anInt, datasetName) ;
                if (blahblah) {
                    printf("Nom: %-30s | Type: %-10s | Valeur: %d\n", datasetName, h5->dataTypeName, anInt) ;
                }
            }
            else if (H5Tequal(h5->typeID, H5T_NATIVE_FLOAT)) {
                H5Dread(h5->dataset, H5T_NATIVE_FLOAT, H5S_ALL, H5S_ALL, H5P_DEFAULT, &aFloat) ;
                setFloatValForKeyIn(pList, aFloat, datasetName) ;
                if (blahblah) {
                    printf("Nom: %-30s | Type: %-10s | Valeur: %f\n", datasetName, h5->dataTypeName, aFloat) ;
                }            }
            else if (H5Tequal(h5->typeID, H5T_NATIVE_DOUBLE)) {
                H5Dread(h5->dataset, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, &aDouble) ;
                setDoubleValForKeyIn(pList, aDouble, datasetName) ;
                if (blahblah) {
                    printf("Nom: %-30s | Type: %-10s | Valeur: %lf\n", datasetName, h5->dataTypeName, aDouble) ;
                }                
            }
            else if (H5Tequal(h5->typeID, H5T_NATIVE_CHAR)) {
                H5Dread(h5->dataset, H5T_NATIVE_CHAR, H5S_ALL, H5S_ALL, H5P_DEFAULT, &aChar) ;
                setUCharValForKeyIn(pList, aChar, datasetName) ;
                if (blahblah) {
                    printf("Nom: %-30s | Type: %-10s | Valeur: %c\n", datasetName, h5->dataTypeName, aChar) ;
                }
            }
            else if (H5Tget_class(h5->typeID) == H5T_STRING) {
                aString = getHDF5StringDataset(h5->dataset, h5->typeID) ;
                if (aString) {
                    setStringValForKeyIn(pList, aString, datasetName) ;
                    if (blahblah) {
                        printf("Nom: %-30s | Type: %-10s | Valeur: %s\n", datasetName, h5->dataTypeName, aString) ;
                    }
                    free(aString);
                }
            }
            
            /* Check object attributes */
            if (blahblah) {
                printDatasetAttributes(objectID, datasetName) ;
            }
            
        }
        freeH5DatasetDescriptor(h5) ;
    }
    return (0) ;
}


// Matrix and vector object scan call-back function
herr_t matrixAndVectorObjectsScan(hid_t objectID, const char *datasetName, const H5O_info_t *objectInfo, void *pList) { 
    char *fileName, *destDir, *filePath, *datasetPath, *aKey, blahblah ;
    int vectorObjectCount, matrixObjectCount ;
    size_t anIndex, xTileIndex, yTileIndex ;
    keyValue * thisPList = NULL ;
    rawFileDescriptor *outputDataFile ;
    hdf5DatasetDescriptor *h5 ;
    hsize_t i, j ;
    hsize_t currentChunkDims[2] ;
    herr_t status ; 
    tileTool *aTileTool ;   
    CSVStruct *excludedDatasetNames ;

    blahblah = getCharValForKeyIn(pList, "Verbose") ;
    excludedDatasetNames = getCSVValForKeyIn(pList, "Excluded dataset names") ;
    if (excludedDatasetNames) {
        for (anIndex = 0; anIndex < excludedDatasetNames->numberOfEntries; anIndex++) {
            if (isSubStringPresentInString(datasetName, excludedDatasetNames->stringVal[anIndex])) {
                return (0) ;
            }
        }
        freeCSVStruct(excludedDatasetNames) ;
    }
    
    /* If we deal with a dataset */
    if (objectInfo->type == H5O_TYPE_DATASET) {
        if((h5 = allocAndInitH5DatasetDescriptor(objectID, datasetName)) == NULL) {
            return (0) ;
        }

        fileName = getFileNameFromPath(datasetName) ;
        datasetPath = getDirectoryPathFromPath(datasetName) ;
        destDir = getStringValForKeyIn(pList, "Dump directory") ;
        vectorObjectCount = getIntValForKeyIn(pList, "Number of vector datasets") ;
        matrixObjectCount = getIntValForKeyIn(pList, "Number of matrix datasets") ;


        if (h5->rank == 1 || h5->rank == 2) {
            if (blahblah) {
                printf("\nDataset '%s'\n", datasetName);
                printDatasetAttributes(objectID, datasetName);
            }
            
            /* Create destination directory */
            destDir = initStringWith3Strings(destDir, "/", datasetPath) ;
            makeDirRecursively(destDir) ;
            filePath = initStringWith4Strings(destDir, "/", fileName, ".txt") ;

            /* create and save  key-value text file */
            thisPList = setStringValForKeyIn(thisPList, datasetName, "Full data set name") ;
            setIntValForKeyIn(thisPList, h5->rank, "Data rank") ;
            setLongValForKeyIn(thisPList, h5->datasetDims[0], "X dimension") ;

            aKey = initStringWith2Strings(fileName, "dataset path") ;
            free(aKey) ;
            if (h5->rank == 2) {
                setLongValForKeyIn(thisPList, h5->datasetDims[1], "Y dimension") ;
                matrixObjectCount++ ;
                setIntValForKeyIn(pList, matrixObjectCount, "Number of matrix dataset") ;
            }
            else {
                vectorObjectCount++ ;
                setIntValForKeyIn(pList, vectorObjectCount, "Number of vector dataset") ;
            }
            
            setStringValForKeyIn(thisPList, h5->dataTypeName, "Data type") ;
            setIntValForKeyIn(thisPList, h5->dataTypeSize, "Data type size") ;
            if (isArchBigEndian()) {
                setStringValForKeyIn(thisPList, "big endian", "Endianness") ;
            }
            else {
                setStringValForKeyIn(thisPList, "low endian", "Endianness") ;
            }
            
            outputDataFile = openRawFileForReadingAndWritingAtPath(filePath) ;
            writeParameterFileAtPath(thisPList, filePath) ;
            freeKeyValueList(thisPList) ;
            freeRawFileDescriptor(outputDataFile) ;
            free(filePath) ;

            /* Read and save data file */
            filePath = initStringWith3Strings(destDir, "/", fileName) ;
            if ((outputDataFile = openRawFileForReadingAndWritingAtPath(filePath))) {
                if (h5->rank == 1) {
                    H5Dread(h5->dataset, h5->typeID, H5S_ALL, H5S_ALL, H5P_DEFAULT, h5->dataTile) ;
                    fwrite(h5->dataTile, h5->dataTypeSize, h5->numberOfElements, outputDataFile->f) ;
                }
                else if (h5->rank == 2) {
                    if (h5->isChunked) {
                        aTileTool = allocTileTool() ;
                        aTileTool->typeSize = h5->dataTypeSize ;
                        aTileTool->output = outputDataFile ;
                        aTileTool->xDimOut = h5->datasetDims[1] ;
                        aTileTool->yDimOut = h5->datasetDims[0] ;
                        initTileToolWithSizes(aTileTool, h5->chunkDims[1], h5->chunkDims[0], 0, 0) ;

                        for (i = 0; i < h5->datasetDims[0]; i += h5->chunkDims[0]) {
                            for (j = 0; j < h5->datasetDims[1]; j += h5->chunkDims[1]) {
                                h5->offset[0] = i ;
                                h5->offset[1] = j ;
                                currentChunkDims[0] = (i + h5->chunkDims[0] <= h5->datasetDims[0]) ? h5->chunkDims[0] : h5->datasetDims[0] - i ;
                                currentChunkDims[1] = (j + h5->chunkDims[1] <= h5->datasetDims[1]) ? h5->chunkDims[1] : h5->datasetDims[1] - j ;
                                h5->memspace = H5Screate_simple(h5->rank, currentChunkDims, NULL) ;
                                    
                                status = H5Sselect_hyperslab(h5->dataspace, H5S_SELECT_SET, h5->offset, NULL, currentChunkDims, NULL);
                                status = H5Dread(h5->dataset, h5->typeID, h5->memspace, h5->dataspace, H5P_DEFAULT, aTileTool->tile[0]);
                                H5Sclose(h5->memspace) ;
                                
                                xTileIndex = j / h5->chunkDims[1] ;
                                yTileIndex = i / h5->chunkDims[0] ;
                                updateTileToolForIndexes(aTileTool, xTileIndex, yTileIndex) ;
                                writeTile(aTileTool) ;
                            }
                            updatePointProgressCounterForIndex(h5->aCounter, i) ;
                        }                    
                        updatePointProgressCounterForIndex(h5->aCounter, i) ;
                        freeTileTool(aTileTool) ;
                    }
                    else {
                        h5->memspace = H5Screate_simple(h5->rank, h5->chunkDims, NULL) ;
                        for ( i = 0; i < h5->datasetDims[0]; i++) {
                            h5->offset[0] = i ;

                            H5Sselect_hyperslab(h5->dataspace, H5S_SELECT_SET, h5->offset, NULL, h5->chunkDims, NULL) ;
                            status = H5Dread(h5->dataset, h5->typeID, h5->memspace, h5->dataspace, H5P_DEFAULT, h5->dataTile);                        
                            fwrite(h5->dataTile, h5->dataTypeSize, h5->datasetDims[1], outputDataFile->f);
                        }
                        H5Sclose(h5->memspace) ;
                    }
                 }
                freeRawFileDescriptor(outputDataFile) ;
            }
            free(destDir) ;            
            free(filePath) ;            
        }
        
        free(datasetPath) ;
        free(fileName) ;
        freeH5DatasetDescriptor(h5) ;
    }

    return (0) ;
}



// Get string representation of HDF5 data type
char* getHDF5TypeName(hid_t HDF5TypeID) {
    char *typeID ;

    if (H5Tequal(HDF5TypeID, H5T_NATIVE_INT)) {
        typeID = initStringWithString("int") ;
    }
    else if (H5Tequal(HDF5TypeID, H5T_NATIVE_FLOAT)) {
        typeID = initStringWithString("float") ;
    }
    else if (H5Tequal(HDF5TypeID, H5T_NATIVE_DOUBLE)) {
        typeID = initStringWithString("double") ;
    }
    else if (H5Tequal(HDF5TypeID, H5T_NATIVE_CHAR)) {
        typeID = initStringWithString("char") ;
    }
    else if (H5Tget_class(HDF5TypeID) == H5T_STRING){
        typeID = initStringWithString("string") ;
    }
    else {
        typeID = initStringWithString("unknown") ;
    }
        
    return typeID;
}

/* Get string contained in dataset */
char* getHDF5StringDataset(hid_t dataset, hid_t HDF5TypeID) {
    char *aString = NULL, *tempString = NULL ;
    size_t stringLength ;
    
    if (H5Tis_variable_str(HDF5TypeID)) {
        // Chaîne de longueur variable
        H5Dread(dataset, HDF5TypeID, H5S_ALL, H5S_ALL, H5P_DEFAULT, &tempString) ;
        if (tempString) {
            aString = strdup(tempString) ;
            H5free_memory(tempString) ;
        }
    } else {
        // Chaîne de longueur fixe
        stringLength = H5Tget_size(HDF5TypeID) ;
        aString = allocStringOfLength(++stringLength) ;
        H5Dread(dataset, HDF5TypeID, H5S_ALL, H5S_ALL, H5P_DEFAULT, aString);
    }
    
    return aString;
}

/* Alloc and init h5 dataset descriptor */
hdf5DatasetDescriptor *allocAndInitH5DatasetDescriptor(hid_t objectID, const char *datasetName)
{
    hdf5DatasetDescriptor *h5 ;
    H5T_order_t byteOrder ;

    if ((h5 = malloc(sizeof(*h5))) == NULL) {
        printf("\t\t-/-> Failed to allocate hdf5 dataset descriptor\n\t\t-/-> Skipping dataset %s\n", datasetName) ;
        return NULL ;
    }
    h5->dataTile = NULL ;

    /* Open dataset */
    h5->dataset = H5Dopen2(objectID, datasetName, H5P_DEFAULT);
    if (h5->dataset < 0) return NULL ;

    /* Get data set space */
    h5->dataspace = H5Dget_space(h5->dataset);
    if (h5->dataspace < 0) {
        H5Dclose(h5->dataset);
        return NULL;
    }

    /* Get datase creation property list */
    h5->dcpl = H5Dget_create_plist(h5->dataset);
    /* Get layout storage type */
    h5->layoutType = H5Pget_layout(h5->dcpl) ;

    /* Get data type, name and rank */
    h5->typeID = H5Dget_type(h5->dataset);
    h5->dataTypeName = getHDF5TypeName(h5->typeID) ;
    h5->rank = H5Sget_simple_extent_ndims(h5->dataspace) ;
    byteOrder = H5Tget_order(h5->typeID) ;
    if (isArchBigEndian()) {
        h5->bytesMustBeSwapped = (byteOrder == H5T_ORDER_LE)? 1 : 0 ;
    }
    else {
        h5->bytesMustBeSwapped = (byteOrder == H5T_ORDER_BE)? 1 : 0 ;
    }
    
    /* We deal only with matrix and vectors ;*/
    if (h5->rank) {
        h5->dataTypeSize = H5Tget_size(h5->typeID);
        h5->datasetDims = (hsize_t*)malloc(h5->rank * sizeof(hsize_t)) ;
        H5Sget_simple_extent_dims(h5->dataspace, h5->datasetDims, NULL);

        /* compute number of elements of dataset */
        h5->numberOfElements = 1;
        for (int i = 0; i < h5->rank; i++) {
            h5->numberOfElements *= h5->datasetDims[i];
        }
        
        /* Prepare line by line matrix reading */
        if (h5->rank == 2){
            h5->offset = (hsize_t*)malloc(h5->rank * sizeof(hsize_t)) ;
            h5->chunkDims = (hsize_t*)malloc(h5->rank * sizeof(hsize_t)) ;
            h5->offset[0] = h5->offset[1] = 0 ;
            h5->numberOfRows = h5->datasetDims[0] ;
            h5->currentRow = 0 ;
            h5->aCounter = NULL ;
            
            h5->isChunked = 0 ;
            if (h5->layoutType == H5D_CHUNKED) {
                h5->isChunked = H5Pget_chunk(h5->dcpl, 2, h5->chunkDims) ;
                h5->dataTile = malloc(h5->chunkDims[0] * h5->chunkDims[1] * h5->dataTypeSize) ;
                h5->aCounter = initProgressCounterWithMinMaxValue(0, h5->numberOfRows - 1) ;
            }
            else {
                h5->chunkDims[0] = 1 ;
                h5->chunkDims[1] = h5->datasetDims[1] ;
                h5->dataTile = malloc(h5->dataTypeSize * h5->datasetDims[1]) ;
            }
            
        }
        else {   
            h5->dataTile = malloc(h5->dataTypeSize * h5->numberOfElements) ;
        }
    }
    
    return (h5) ;
}

/* Free h5 dataset descriptor */
void freeH5DatasetDescriptor(hdf5DatasetDescriptor *h5)
{
    if (h5->dataTypeName) {
        free(h5->dataTypeName) ;
    }

    H5Tclose(h5->typeID) ;
    H5Dclose(h5->dataset) ;
    H5Sclose(h5->dataspace) ;
    if (h5->rank) {
        free(h5->datasetDims) ;  
    }
    if (h5->dataTile) {
        free(h5->dataTile) ;
    }

    
    if (h5->rank == 2) {
        free(h5->offset) ;
        free(h5->chunkDims) ;

        if (h5->aCounter) {
            freeProgressCounter(h5->aCounter) ;
        }
        
    }
    free(h5) ;
}

/* Attribute management functions */
/* ****************************** */

/* Read attribute content */
attributeInfo* readAttribute(hid_t attr_id) {
    char **tempStringArray, **savedStringArray ;
    size_t typeSize ;
    ssize_t nameSize ;
    attributeInfo *attInfo ;

    attInfo = (attributeInfo*)malloc(sizeof(attributeInfo)) ;
    
    /* Get attribute name */
    nameSize = H5Aget_name(attr_id, 0, NULL) ;
    attInfo->name = allocStringOfLength(nameSize) ;
    H5Aget_name(attr_id, nameSize + 1, attInfo->name) ;
    
    /* Get attribute type, type size and space */
    attInfo->typeID = H5Aget_type(attr_id) ;
    attInfo->spaceID = H5Aget_space(attr_id);
    attInfo->typeSize = H5Tget_size(attInfo->typeID) ;

    /* Get attribute rank and dimensions */
    attInfo->rank = H5Sget_simple_extent_ndims(attInfo->spaceID);
    attInfo->dims = NULL;
    
    attInfo->numberOfElements = 1;
    if (attInfo->rank > 0) {
        attInfo->dims = (hsize_t*)malloc(attInfo->rank * sizeof(hsize_t));
        H5Sget_simple_extent_dims(attInfo->spaceID, attInfo->dims, NULL);
        
        for (int i = 0; i < attInfo->rank; i++) {
            attInfo->numberOfElements *= attInfo->dims[i];
        }
    }
    
    /* Allocate attribute value space */
    if (H5Tget_class(attInfo->typeID) == H5T_STRING) {
        if (H5Tis_variable_str(attInfo->typeID)) {
            /* For variable string length arrays */
            tempStringArray = (char**)malloc(attInfo->numberOfElements * sizeof(char*));
            H5Aread(attr_id, attInfo->typeID, tempStringArray);
            
            /* Copy strings */
            attInfo->value = malloc(attInfo->numberOfElements * sizeof(char*));
            savedStringArray = (char**)attInfo->value;
            for (size_t i = 0; i < attInfo->numberOfElements; i++) {
                savedStringArray[i] = strdup(tempStringArray[i]) ;
                H5free_memory(tempStringArray[i]);
            }
            free(tempStringArray);
        } else {
            /* For constant string length arrays */
            attInfo->value = malloc(attInfo->numberOfElements * attInfo->typeSize + 1);
            H5Aread(attr_id, attInfo->typeID, attInfo->value);
            ((char*)attInfo->value)[attInfo->numberOfElements * attInfo->typeSize] = '\0';
        }
    } else {
        /* For numerical types */
        attInfo->value = malloc(attInfo->numberOfElements * attInfo->typeSize);
        H5Aread(attr_id, attInfo->typeID, attInfo->value);
    }
    
    return attInfo ;
}

/* Free attribute info */
void freeAttributeInfo(attributeInfo* attInfo) {
    char **stringArray ;

    if (attInfo) {
        free(attInfo->name) ;
        if (attInfo->dims) {
            free(attInfo->dims) ;
        }
        
        // Libération spéciale pour les tableaux de chaînes variables
        if (H5Tget_class(attInfo->typeID) == H5T_STRING && 
            H5Tis_variable_str(attInfo->typeID) && 
            attInfo->rank > 0) {

            stringArray = (char**)attInfo->value;
            for (size_t i = 0; i < attInfo->numberOfElements; i++) {
                free(stringArray[i]);
            }
        }
        
        free(attInfo->value);
        H5Tclose(attInfo->typeID);
        H5Sclose(attInfo->spaceID);
        free(attInfo);
    }
}


/* Display attribute value */
void printAttributeValue(attributeInfo* attInfo) {
    size_t N ;

    N = attInfo->numberOfElements ;
    // Afficher les dimensions si c'est un tableau
    if (attInfo->rank > 0) {
        printf("[");
        for (int i = 0; i < attInfo->rank; i++) {
            printf("%llu", (unsigned long long)attInfo->dims[i]);
            if (i < attInfo->rank - 1) printf("x");
        }
        printf("] ");
    }
    
    // Afficher les valeurs
    if (H5Tget_class(attInfo->typeID) == H5T_STRING) {
        if (H5Tis_variable_str(attInfo->typeID) && attInfo->rank > 0) {
            char** str_array = (char**)attInfo->value;
            printf("[");
            for (size_t i = 0; i < N; i++) {
                printf("\"%s\"", str_array[i]);
                if (i < N - 1) printf(", ");
            }
            printf("]");
        } else {
            printf("\"%s\"", (char*)attInfo->value);
        }
    }
    else if (H5Tequal(attInfo->typeID, H5T_NATIVE_INT)) {
        int* values = (int*)attInfo->value;
        if (attInfo->rank > 0) printf("[");
        for (size_t i = 0; i < N; i++) {
            printf("%d", values[i]);
            if (i < N - 1) printf(", ");
        }
        if (attInfo->rank > 0) printf("]");
    }
    else if (H5Tequal(attInfo->typeID, H5T_NATIVE_FLOAT)) {
        float* values = (float*)attInfo->value;
        if (attInfo->rank > 0) printf("[");
        for (size_t i = 0; i < N; i++) {
            printf("%f", values[i]);
            if (i < N - 1) printf(", ");
        }
        if (attInfo->rank > 0) printf("]");
    }
    else if (H5Tequal(attInfo->typeID, H5T_NATIVE_DOUBLE)) {
        double* values = (double*)attInfo->value;
        if (attInfo->rank > 0) printf("[");
        for (size_t i = 0; i < N; i++) {
            printf("%f", values[i]);
            if (i < N - 1) printf(", ");
        }
        if (attInfo->rank > 0) printf("]");
    }
}


/* Scan all dataset's attributes*/
void printDatasetAttributes(hid_t datasetID, const char* datasetName) {
    H5O_info_t obj_info ;
    attributeInfo* attInfo ;

#if !defined(H5Oget_info_vers) || H5Oget_info_vers == 1  || H5Oget_info_vers == 2
        H5Oget_info(datasetID, &obj_info) ;
#else
        H5Oget_info(datasetID, &obj_info, H5O_INFO_ALL) ;
#endif
    
    printf("Dataset attributes:\n") ;
    if (obj_info.num_attrs == 0) {
        printf("  None\n\n");
        return;
    }
    
    for (unsigned i = 0; i < obj_info.num_attrs; i++) {
        hid_t attr_id = H5Aopen_idx(datasetID, i);
        attributeInfo* attInfo = readAttribute(attr_id);
        
        printf("  - %s = ", attInfo->name);
        printAttributeValue(attInfo);
        printf("\n");
        
        freeAttributeInfo(attInfo);
        H5Aclose(attr_id);
    }
    printf("\n") ;
}


/* Read hdf5 dumped data set at given path (only vectors or matrices) */
/* Dataset path can be given as the dataset itself or as its .txt description file path */
datasetVals *readDumpedDatasetAtPath (char* aPath)
{
    char *txtPath, *datasetPath ;
    size_t numberOfElements ;
    keyValue *params ;
    datasetVals *thisDataset ;
    rawFileDescriptor *datasetFile ;

    datasetPath = initStringWithString(aPath) ;
    if (!getPointerToLastFileExtensionInPath(aPath)) {
        txtPath = initStringWith2Strings(aPath, ".txt") ;
    }
    else {
        txtPath = initStringWithString(aPath) ;
        stripExtensionAtEndOfPath(datasetPath) ;
    }
    
    params = readParameterFileAtPath(txtPath) ;
    thisDataset = malloc(sizeof(thisDataset[0])) ;
    thisDataset->v = thisDataset->m = NULL ;

    thisDataset->rank = getIntValForKeyIn(params, "Data rank") ;
    thisDataset->dims = malloc(thisDataset->rank * sizeof(thisDataset->dims[0])) ;
    thisDataset->typesize = getIntValForKeyIn(params, "Data type size") ;
    thisDataset->typeID = initStringWithString(getStringValForKeyIn(params, "data type")) ;

    datasetFile = openRawFileForReadingAtPath(datasetPath) ;
    numberOfElements = thisDataset->dims[0] = getIntValForKeyIn(params, "X") ;
    if (thisDataset->rank == 1) {
        thisDataset->v = vectorOfType(0, thisDataset->dims[0] - 1, thisDataset->typesize) ;
        fread(thisDataset->v, thisDataset->typesize, numberOfElements, datasetFile->f) ;
    }
    if (thisDataset->rank == 2) {
        thisDataset->dims[1] = getIntValForKeyIn(params, "Y") ;
        numberOfElements *= thisDataset->dims[1] ;
        thisDataset->m = matrixOfType(0, thisDataset->dims[0] - 1, 0, thisDataset->dims[1] - 1, thisDataset->typesize) ;
        fread(thisDataset->m[0], thisDataset->typesize, numberOfElements, datasetFile->f) ;
    }
    

    freeRawFileDescriptor(datasetFile) ;
    freeKeyValueList(params) ;
    free(txtPath) ;
    free(datasetPath) ;

    return (thisDataset) ;
}

void freeDatasetVals(datasetVals *thisDataset) 
{
    free(thisDataset->dims) ;
    if (thisDataset->rank == 1) {
        freeVectorOfType(thisDataset->v, 0, thisDataset->typesize) ;
    }
    else {
        freeMatrixOfType(thisDataset->m, 0, 0, thisDataset->typesize) ;
    }
    
    free (thisDataset) ;
}