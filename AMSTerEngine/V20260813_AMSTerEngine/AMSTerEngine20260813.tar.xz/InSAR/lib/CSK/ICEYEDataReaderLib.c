
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  ICEYEDataReader
//
//  (re-)Created by Dominique Derauw on 11/2/2022.
//  Copyright (c) 2022 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "ICEYEDataReaderLib.h"

CSVStruct *ICEYEDataReader(CSVStruct *csv)
{
    char *aPath, *inputPath, *outputDir ;
    char keepExisting ;
    int i ;
	keyValue *header ;
	CSLImage *thisImage ;
	SLCImageInfo *info ;
    CSVStruct *H5Filepath = NULL ;
    CSVStruct *savedCSLImages = NULL ;
    CSVStruct *stateVectorTime, *DCEstimateTime ;

//    char *keyValFilePath, keyValFileName[16] ;
	
    if(csv->numberOfEntries == 1 || isArgumentPresentInCSV(csv, "help") || isArgumentPresentInCSV(csv, "-h")) {
		ICEYEDataReaderHelp() ;
    }
    
    /* If parameter 1 is a directory, we will consider it contains one or more .h5 files to be read */
    /* If parameter is an .h5 file, we read it. */
    if (!isDir(csv->stringVal[1]) && !getPointerToLastFileExtensionInPath(csv->stringVal[1])) {
        printf("\t-/-> first parameter must be a valid directory or a path to an hdf5 (.h5) file\n") ;
        ICEYEDataReaderHelp() ;
    }
    
    if (isDir(csv->stringVal[1])) {
        outputDir = csv->stringVal[1] ;
        if (csv->numberOfEntries >= 3) {
            if (isDir(csv->stringVal[2])) {
                outputDir = csv->stringVal[2] ;
            }
        }
        H5Filepath = recursiveSearchOfFilesWithExtensionInDir("h5", (char *)csv->stringVal[1]) ;
    }
    else {
        if (csv->numberOfEntries < 3) {
            ase("Output directory is missing") ;
        }
        outputDir = csv->stringVal[2] ;
        H5Filepath = addStringValInCSVStruct(csv->stringVal[1], H5Filepath) ;
    }

    for (i = 0; i < H5Filepath->numberOfEntries; i++) {
        /* Getting HDF5 file path */
        inputPath = H5Filepath->stringVal[i] ;
        /* Read header */
        header = readICEYEHeader(inputPath) ;

/*
        aPath = getDirectoryPathFromPath(inputPath) ;
        sprintf(keyValFileName, "/keyvals%.1d.txt", i) ;
        keyValFilePath = initStringWith2Strings(aPath, keyValFileName) ;
        writeParameterFileAtPath(header, keyValFilePath) ;
        free(aPath) ;
        free(keyValFilePath) ;
*/
        /* Update output directory in header */
        setStringValForKeyIn(header, outputDir, "CSL image directory") ;
        /* Create image container */
        keepExisting = !isFlagPresentInCSV(csv, "r") ;
        thisImage = createCSLContainerForIceyeImage(header, keepExisting) ;

        if (thisImage) {
            printf("\nStart reading %s ICEYE image\n", getFileNameFromPath(thisImage->imageDirectoryPath)) ;
            readHDF5FloatMatrixDataset("dc_estimate_coeffs", header) ;
            stateVectorTime = readHDF5StringVectorDataset("state_vector_time_utc", header) ;
            setIntValForKeyIn(header, stateVectorTime->numberOfEntries, "Number of State Vectors") ;
            DCEstimateTime = readHDF5StringVectorDataset("dc_estimate_time_utc", header) ;
            readHDF5FloatVectorDataset("posX", header) ;
            readHDF5FloatVectorDataset("posY", header) ;
            readHDF5FloatVectorDataset("posZ", header) ;
            readHDF5FloatVectorDataset("velX", header) ;
            readHDF5FloatVectorDataset("velY", header) ;
            readHDF5FloatVectorDataset("velZ", header) ;

            /* Save header */
            aPath = initStringWith2Strings(thisImage->headersDirectoryPath, "/keyVals.txt") ;
            writeParameterFileAtPath(header, aPath) ;
            free(aPath) ;

            info = createSLCImageInfoFromICEYEHeader(header, stateVectorTime) ;
            
            aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
            saveInfoImage(info, aPath) ;
            free(aPath) ;
                            
            readIQComponents(header) ;
            savedCSLImages = addStringValInCSVStruct(getStringValForKeyIn(header, "CSL image filename"), savedCSLImages) ;
            freeCSLImageStructure(thisImage) ;
            freeInfoImage(info) ;
        }
        freeKeyValueList(header) ;
    }
    freeCSVStruct(H5Filepath) ;
    
	return savedCSLImages ;
}

void ICEYEDataReaderHelp()
{
    printf("\nUsage:") ;
    printf("\n\tICEYEDataReader inputPath [outputPath] [-r]\n") ;
    printf("\n\tIn this form, ICEYEDataReader performs a bulk reading of\n\tall h5 data found within the directory given in input\n\tand all its subdirectories.") ;
    printf("\n\tIf an output path is not provided, all data\n\twill be saved within the input directory") ;
    printf("\n\t-r: force re-reading.") ;
    printf("\n\t") ;
	exit(0) ;
}

void createICEYEDataReaderParameterFileAtPath(char *aPath)
{
	keyValue *parameters ;
	
	parameters = allocAKeyValuePair() ;
	setStringValForKeyIn(parameters, "ICEYEDataReader parameter file", "") ;
	setStringValForKeyIn(parameters, "*******************************", "") ;
	setStringValForKeyIn(parameters, "PathToHDF5File", "Path to ICEYE data in HDF5 format") ;
	setStringValForKeyIn(parameters, "outputFilePath", "Path to output image in CSL format") ;
	
	writeParameterFileAtPath(parameters, aPath) ;
	
	exit(0) ;
}

void createSLCCalibrationTextFileAtPath(keyValue *header, char *aPath) 
{
    char aKey[128], key2[128], *layerGroupName, *polMode, aFileName[128] ;
    int layerIndex, NLayers ;
    double  aDoubleValue ;
    keyValue *calibrationInfo, *aKeyVal ;
    
    
    calibrationInfo = allocAKeyValuePair() ;
    setStringValForKeyIn(calibrationInfo, "SLC calibration info text file", "") ;
    setStringValForKeyIn(calibrationInfo, "******************************", "") ;
    setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, "Azimuth Focusing Weighting Coefficient"), "Azimuth Hamming window coefficient") ;
    if(!(aDoubleValue = getDoubleValForKeyIn(header, "Rescaling Factor")))
       aDoubleValue = 1. ;
    setDoubleValForKeyIn(calibrationInfo, aDoubleValue, "Rescaling factor") ;
    if (!strncmp(getStringValForKeyIn(header, "Calibration Constant Compensation Flag"), "0", 1)) {
        setStringValForKeyIn(calibrationInfo, "NO", "Is calibration constant compensation performed") ;
    }
    else {
        setStringValForKeyIn(calibrationInfo, "YES", "Is calibration constant compensation performed") ;
    }

    setStringValForKeyIn(calibrationInfo, "", "") ;
    setStringValForKeyIn(calibrationInfo, "YES", "Is range spreading loss correction performed?") ;
    if ((aDoubleValue = getDoubleValForKeyIn(header, "Reference Slant Range")) == 1) {
        setStringValForKeyIn(calibrationInfo, "NO", "Is range spreading loss normalization performed?") ;
        setDoubleValForKeyIn(calibrationInfo, 0, "Reference slant range [m]") ;
        setDoubleValForKeyIn(calibrationInfo, 1, "Reference slant range exponent") ;
    }
    else {
        setStringValForKeyIn(calibrationInfo, "YES", "Is range spreading loss normalization performed?") ;
        setDoubleValForKeyIn(calibrationInfo, aDoubleValue, "Reference slant range [m]") ;
        setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, "Reference Slant Range Exponent"), "Reference slant range exponent") ;
    }
    setStringValForKeyIn(calibrationInfo, "", "") ;
    setStringValForKeyIn(calibrationInfo, "YES", "Is incidence angle correction performed?") ;
    if ((aDoubleValue = getDoubleValForKeyIn(header, "Reference Incidence Angle"))) {
        setStringValForKeyIn(calibrationInfo, "YES", "Is incidence angle normalization performed?") ;
        setDoubleValForKeyIn(calibrationInfo, aDoubleValue, "Reference incidence angle [deg]") ;
    }
    else {
        setStringValForKeyIn(calibrationInfo, "NO", "Is incidence angle normalization performed?") ;
        setDoubleValForKeyIn(calibrationInfo, 0, "Reference incidence angle") ;
    }
    setStringValForKeyIn(calibrationInfo, "", "") ;
    NLayers = getIntValForKeyIn(header, "Number of layers") ;
    setIntValForKeyIn(calibrationInfo, NLayers, "Number of data layers") ;
    for (layerIndex = 1; layerIndex <= NLayers; layerIndex++) {
        sprintf(aKey, "Group name of layer %d", layerIndex) ;
        layerGroupName = getStringValForKeyIn(header, aKey) ;
        sprintf(aKey, "%s Polarisation", layerGroupName) ;
        polMode = getStringValForKeyIn(header, aKey) ;
        sprintf(aKey, "%s Calibration Constant", layerGroupName) ;
        sprintf(key2, "%s calibration constant", polMode) ;
        setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, aKey), key2) ;
        sprintf(key2, "Is %s elevation antenna pattern correction performed?", polMode) ;
        setStringValForKeyIn(calibrationInfo, "YES", key2) ;
        
        sprintf(aKey, "%s Beam Off-Nadir Angle", layerGroupName) ;
        sprintf(key2, "%s beam centre off-nadir angle [deg]", polMode) ;
        setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, aKey), key2) ;
        sprintf(aKey, "%s Range Antenna Pattern Origin", layerGroupName) ;
        sprintf(key2, "%s elevation antenna pattern origin with respect to beam centre [deg]", polMode) ;
        setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, aKey), key2) ;
        sprintf(aKey, "%s Range Antenna Pattern Resolution", layerGroupName) ;
        sprintf(key2, "%s elevation antenna pattern sampling [deg]", polMode) ;
        setDoubleValForKeyIn(calibrationInfo, getDoubleValForKeyIn(header, aKey), key2) ;
        sprintf(aKey, "%s Range Antenna Pattern Gains", layerGroupName) ;
        aKeyVal = isKeyValPresent(header, aKey) ;
        sprintf(key2, "%s elevation antenna pattern file name", polMode) ;
        sprintf(aFileName, "%s_TwoWayElevationAntennaPattern.txt", polMode) ;
        setStringValForKeyIn(calibrationInfo, aFileName, key2) ;
        sprintf(key2, "%s elevation antenna pattern number of samples", polMode) ;
        setIntValForKeyIn(calibrationInfo, aKeyVal->dimensions[0], key2) ;
        sprintf(accessPath, "%s/%s", getDirectoryPathFromPath(aPath), aFileName) ;
        writeVectorAtPath(aKeyVal, accessPath) ;
        setStringValForKeyIn(calibrationInfo, "", "") ;
    }

    writeParameterFileAtPath(calibrationInfo, aPath) ;
    freeKeyValueList(calibrationInfo) ;
}


/* Get ICEYE header */
keyValue *readICEYEHeader(char *inputPath) 
{
	hid_t   HDF5File;      /* File and dataset identifiers */
	hid_t	rootGroup ;
	herr_t  ret;                /* Return value */
	keyValue *pListAll ;
	
    /* Initializing parameter list */
	pListAll = allocAKeyValuePair() ;
    setStringValForKeyIn(pListAll, "_", "CSL image directory") ;
    setStringValForKeyIn(pListAll, "_", "CSL image filename") ;
    setStringValForKeyIn(pListAll, inputPath, "HDF5 inputfilepath") ;
    setIntValForKeyIn(pListAll, 0, "Number of datasets") ;
    setIntValForKeyIn(pListAll, 0, "Number of layers") ;
    
	/* Open the file */
	if((HDF5File = H5Fopen(inputPath, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0) {
        ase("Failed to open HDF5 file") ;
    }
	
	/* Open root group */
	rootGroup = H5Oopen(HDF5File, "/", H5P_DEFAULT);
	
#if !defined(H5Ovisit_vers) || H5Ovisit_vers == 1  || H5Ovisit_vers == 2

        /* Visit groups iteratively to get all rank 0 data */
        H5Ovisit(rootGroup, H5_INDEX_CRT_ORDER, H5_ITER_NATIVE, getAllRank0Data, &pListAll);
        
        /* Visit group iteratively to identify all objects */
        H5Ovisit(rootGroup, H5_INDEX_CRT_ORDER, H5_ITER_NATIVE, visitObjectsIteratively, &pListAll);
#else 
        /* Visit groups iteratively to get all rank 0 data */
        H5Ovisit3(rootGroup, H5_INDEX_CRT_ORDER, H5_ITER_NATIVE, getAllRank0Data, &pListAll, H5O_INFO_ALL);
        
        /* Visit group iteratively to identify all objects */
        H5Ovisit3(rootGroup, H5_INDEX_CRT_ORDER, H5_ITER_NATIVE, visitObjectsIteratively, &pListAll, H5O_INFO_ALL);
#endif
    
    H5Oclose(rootGroup) ;
    H5Fclose(HDF5File) ;

    return(pListAll) ;
}

CSLImage *createCSLContainerForIceyeImage(keyValue *header, char keepExisting)
{
    char *imageFilePath, *outputFilename, *aString, *aPath ;
    CSVStruct *fileNameComponents = NULL ;
    CSLImage *thisImage = NULL ;
    rawFileDescriptor *readme ;

    /* Verify we deal with an ICEYE SLC image */
    aString = getStringValForKeyIn(header, "product_level") ;
    if (aString == NULL) {
        perror(".h5 file does not containes ICEYE image") ;
        return (NULL) ;
    }
    if (strncmp(aString, "SLC", 5)) {
        perror(".h5 file does not containes ICEYE SLC image") ;
        return (NULL) ;
    }

    aString = getStringValForKeyIn(header, "satellite_name") ;
    if (aString == NULL) {
        perror(".h5 file does not containes ICEYE image") ;
        return (NULL) ;
    }
    if (strncmp(aString, "ICEYE", 5)) {
        perror(".h5 file does not containes ICEYE SLC image") ;
        return (NULL) ;
    }

    /* Get ICEYE file name components */
    /* Start with satelite ID */
    fileNameComponents = addStringValInCSVStruct(aString, NULL) ;
    /* Get acquisition date */
    aString = getStringValForKeyIn(header, "acquisition_start_utc") ;
    sprintf(aComment, "_%.4s%.2s%.2s", aString, aString + 5, aString + 8) ;
    addStringValInCSVStruct(aComment, fileNameComponents) ;
    /* Get orbit direction */
    aString = getStringValForKeyIn(header, "orbit_direction") ;
    if (isSubStringPresentInString(aString, "ASC")) {
        addStringValInCSVStruct("_A", fileNameComponents) ;
    }
    else {
        addStringValInCSVStruct("_D", fileNameComponents) ;
    }
    addStringValInCSVStruct(".csl", fileNameComponents) ;

    /* Generate image output name */
    outputFilename = getStringFromCSV(fileNameComponents) ;
    freeCSVStruct(fileNameComponents) ;
    imageFilePath = initStringWith3Strings(getStringValForKeyIn(header, "CSL image directory"), "/", outputFilename) ;

    /* Verify if image already exists and if yes, if it must kept or removed */
    if (isCSLImageAtPath(imageFilePath)) {
        if (!keepExisting) {
            removeDirectoryAtPath(imageFilePath) ;  
        }
        else {
            printf("\n\nICEYE %s image already exists. Skip reading\n\n", outputFilename) ;
            return(NULL) ;
        }
    }

    /* Create image container */
    thisImage = createCSLDirectoryStructureAtPath(imageFilePath, NULL) ;

    /* Update header */ 
    setStringValForKeyIn(header, thisImage->imageDirectoryPath, "CSL image directory") ;
    setStringValForKeyIn(header, outputFilename, "CSL image filename") ;
    setStringValForKeyIn(header, thisImage->headersDirectoryPath, "Text files directory") ;
    setStringValForKeyIn(header, thisImage->dataDirectoryPath, "Data files directory") ;

    /* Create header directory readme file */
    aPath = initStringWith2Strings(thisImage->headersDirectoryPath, "/_readme.txt") ;
    if(fileExistsAtPath(aPath)) {
        unlink(aPath) ;            
    }
    readme = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;

    fprintf(readme->f, "This directory contains ICEYE headers as extracted from HDF5 file attributes.\n") ;
    fprintf(readme->f, "HDF5 attributes belonging to different HDF5 datasets are saved in separate text files\n") ;
    fprintf(readme->f, "Each vector or matrix attribute is saved in a separate file with a header file name corresponding to the dataset it belongs.\n") ;

    freeRawFileDescriptor(readme) ;

    /* Save header */
    aPath = initStringWith2Strings(thisImage->headersDirectoryPath, "/keyVals.txt") ;
    writeParameterFileAtPath(header, aPath) ;
    free(aPath) ;

    free(outputFilename) ;
    free(imageFilePath) ;

    return(thisImage) ;
}



/* Operator function */
static herr_t transferAttributeInfoToPList(hid_t parentObject, const char *childObjectName, const H5A_info_t *childObjectInfo, void *pList)
{
	char bytesMustBeSwapped, *aString, *groupName, *aKey ;
	int i, rank ;
    void *anArray ;         /* Pointer to the array attribute. */
 	hsize_t	*attributeDatasetDim, *attributeMaxDims ;
    hid_t attr, attributeType, attributeSpace;  /* Attribute, datatype and dataspace identifiers */	
    hsize_t sdim[64], typeSize;
    herr_t ret;
    H5A_info_t ainfo[1] ;
    int npoints;             /* Number of elements in the array attribute. */
	
    printf("Fourt!!!\n") ;


    /* Open the attribute using its childObjectName */
    attr = H5Aopen(parentObject, childObjectName, H5P_DEFAULT);
    
    /* Get attribute datatype, dataspace, rank, and dimensions */
    attributeType  = H5Aget_type(attr);
    attributeSpace = H5Aget_space(attr);
    rank = H5Sget_simple_extent_ndims(attributeSpace);
    ret = H5Sget_simple_extent_dims(attributeSpace, sdim, NULL);
    ret = H5Aget_info( attr, ainfo ) ;
	typeSize = H5Tget_size(attributeType) ;
	npoints = (int)H5Sget_simple_extent_npoints(attributeSpace);
	bytesMustBeSwapped = !(isArchBigEndian() ^ (H5Tget_order(attributeType) == H5T_ORDER_LE)) ;
	
    /* Allocate dimension vectors */
    attributeDatasetDim = malloc(rank * sizeof(hsize_t)) ;
    attributeMaxDims = malloc(rank * sizeof(hsize_t)) ;
    
    /* Get dataset full size */
    ret = H5Sget_simple_extent_dims(attributeSpace, attributeDatasetDim, attributeMaxDims) ;
    
    /* If we are at a group level corresponding to a new layer S<nn>, key names must be prefixed */
    if((groupName = getStringValForKeyIn(pList, "Group name"))) {
        aKey = initStringWith3Strings(groupName, " ", (char *)childObjectName) ;
    }
    else {
        aKey = initStringWithString((char *)childObjectName) ;
    }
    
    /* Read array attribute and display its type and values */
	switch (H5Tget_class(attributeType)) {
		case H5T_INTEGER:
			if(typeSize == sizeof(char)) {
				anArray = vectorUChar(0, npoints - 1) ;
				ret = H5Aread(attr, attributeType, anArray) ;
				setVectorUCharForKeyIn(pList, anArray, npoints, aKey) ;
			}
			if(typeSize == sizeof(short)) {
				anArray = vectorShort(0, npoints - 1) ;
				ret = H5Aread(attr, attributeType, anArray) ;
				if(bytesMustBeSwapped) {
					for(i = 0; i < npoints; i++)
						swapInt(anArray + i * sizeof(short)) ;
				}
				setVectorShortForKeyIn(pList, anArray, npoints, aKey) ;
			}
			if(typeSize == sizeof(int)) {
				anArray = vectorInt(0, npoints - 1) ;
				ret = H5Aread(attr, attributeType, anArray) ;
				if(bytesMustBeSwapped) {
					for(i = 0; i < npoints; i++)
						swapInt(anArray + i * sizeof(int)) ;
				}
				setVectorIntForKeyIn(pList, anArray, npoints, aKey) ;
			}
			break;
			
		case H5T_FLOAT:
			if(typeSize == sizeof(float)) {
				anArray = vectorFloat(0, npoints - 1) ;
				ret = H5Aread(attr, attributeType, anArray) ;
				if(bytesMustBeSwapped) {
					for(i = 0; i < npoints; i++)
						swapFloat(anArray + i * sizeof(int)) ;
				}
				setVectorFloatForKeyIn(pList, anArray, npoints, aKey) ;
			}
			if(typeSize == sizeof(double)) {
				anArray = vectorDouble(0, npoints - 1) ;
				ret = H5Aread(attr, attributeType, anArray) ;
				if(bytesMustBeSwapped) {
					for(i = 0; i < npoints; i++)
						swapDouble(anArray + i * sizeof(int)) ;
				}
				setVectorDoubleForKeyIn(pList, anArray, npoints, aKey) ;
			}
			break;
			
		case H5T_STRING:
			aString = allocStringOfLength(typeSize) ;
			ret = H5Aread(attr, attributeType, aString) ;
			setStringValForKeyIn(pList, aString, aKey) ;
			free(aString) ;
			break;
			
		default:
			break;
	}
	free(aKey) ;
	
    /* Release all identifiers */
    H5Tclose(attributeType);
    H5Sclose(attributeSpace);
    H5Aclose(attr);
	
    return 25;
}


static herr_t visitObjectsIteratively(hid_t parentObject, const char *childObjectName, const H5O_info_t *childObjectInfo, void *globalPListAdress) 
{
	char *aPath, aKey[128], *aString ;
    int datasetIndex, rank ;
    herr_t ret ;
	keyValue *pList, *formerKeyValuePair, *pListAll ;
	hsize_t	datasetDim[4], maxDims[4] ;
	hid_t file, currentObject, currentDataset, currentDataspace, currentDataType ;
    H5T_class_t currentDataTypeIdentifier ;
    size_t currentDataTypeSize ;
    H5T_order_t currentDataTypeOrder ;

    /* Some initialization to silent Valgrind */
    rank = 0 ;
    datasetDim[0] = datasetDim[1] = datasetDim[2] = datasetDim[3] = 0 ;
	
    /* Get the starting point of keyValues */
	pListAll = *(keyValue **)globalPListAdress ;
    
    /* Alloc starting point of keyValues for this object */
	pList = allocAKeyValuePair() ;
    
	printf ("/") ;               /* Print root group in object path */
	
    /* Check if the current object is the root group, and if not print the full path name and type */
    if (childObjectName[0] == '.') {
        printf ("%s :  (Root Group)\n", childObjectName);
	}
    else {
        switch (childObjectInfo->type) {
            case H5O_TYPE_GROUP:
                printf ("%s  (Group)\n", childObjectName);
                
                break;
            case H5O_TYPE_DATASET:
                /* Open the file */
                file = H5Fopen(getStringValForKeyIn(pListAll, "HDF5 input"), H5F_ACC_RDONLY, H5P_DEFAULT);
                /* Open dataset in HDF5 file */
                currentDataset = H5Dopen2(file, childObjectName, H5P_DEFAULT);

                /* Get dataset dataspace */
                currentDataspace = H5Dget_space(currentDataset) ;
                
                /* Get dataset rank  */
                rank = H5Sget_simple_extent_ndims(currentDataspace) ;

                /* for rank > 0, (we are only interested in vectors and matrices) */
                if (rank) {
                    /* Get data type description */
                    currentDataType = H5Dget_type(currentDataset) ;
                    currentDataTypeIdentifier = H5Tget_class(currentDataType) ;
                    currentDataTypeSize = H5Tget_size(currentDataType) ;
                    currentDataTypeOrder = H5Tget_order(currentDataType) ;

                    printf ("%s  (Dataset)\n", childObjectName);
                    datasetIndex = getIntValForKeyIn(pListAll, "Number of datasets") ;
                    datasetIndex++ ;
                    setIntValForKeyIn(pListAll, datasetIndex, "Number of datasets") ;
                    sprintf(aKey, "Dataset %d name", datasetIndex) ;
                    aPath = allocStringOfLength(strlen(childObjectName) + 1) ;
                    sprintf(aPath, "%s", childObjectName) ;
                    setStringValForKeyIn(pList, aPath, aKey) ;
                    free(aPath) ;

                    /* Get dataset full size */
                    ret = H5Sget_simple_extent_dims(currentDataspace, datasetDim, maxDims) ;
                    
                    /* Add info to pList */
                    sprintf(aKey, "Dataset %d X size [columns]", datasetIndex) ;
                    setLongValForKeyIn(pList, datasetDim[1], aKey) ;
                    sprintf(aKey, "Dataset %d Y size [rows]", datasetIndex) ;
                    setLongValForKeyIn(pList, datasetDim[0], aKey) ;
                    sprintf(aKey, "Dataset %d data type identifier", datasetIndex) ;
                    aString = getHD5DataTypeIdentifier(currentDataTypeIdentifier) ;
                    setStringValForKeyIn(pList, aString, aKey) ;
                    free(aString) ;
                    sprintf(aKey, "Dataset %d data type size [bytes]", datasetIndex) ;
                    setLongValForKeyIn(pList, currentDataTypeSize, aKey) ;
                    sprintf(aKey, "Dataset %d data type byte order", datasetIndex) ;
                    aString = getHD5DataTypeByteOrder(currentDataTypeOrder) ;
                    setStringValForKeyIn(pList, aString, aKey) ;
                    free(aString) ;
                }
                H5Fclose(file) ;
                H5Dclose(currentDataset) ;

                break;
            case H5O_TYPE_NAMED_DATATYPE:
                printf ("%s  (Datatype)\n", childObjectName);
                break;
            default:
                printf ("%s  (Unknown)\n", childObjectName);
        }
	}
    
	currentObject = H5Oopen(parentObject, childObjectName, H5P_DEFAULT);
    if (rank) {
        formerKeyValuePair = NULL ;
        while(pListAll->nextOne != NULL) {
            formerKeyValuePair = pListAll ;
            pListAll = pListAll->nextOne ;
        }
        
        if(formerKeyValuePair != NULL) {
            formerKeyValuePair->nextOne = pList ;
        }
        else {
            *(keyValue **)globalPListAdress = pList ;
            freeKeyValuePair(pListAll) ;
        }
    }
    else {
        freeKeyValuePair(pList) ;
    }
    H5Oclose(currentObject) ;

    
    return 0;
}



static herr_t getAllRank0Data(hid_t parentObject, const char *childObjectName, const H5O_info_t *childObjectInfo, void *rank0pList) 
{
	char aKey[128] ;
    char *utf8_r = NULL ;
    int rank = 0 ;
    int storage_size ;
    herr_t ret ;
	keyValue *pList ;
	hid_t file, currentDataset, currentDataspace, currentDataType, outputDataspace, memtype ;
    H5T_class_t currentDataTypeIdentifier ;
    size_t currentDataTypeSize ;
    H5T_order_t currentDataTypeOrder ;
    H5T_cset_t stringType ;
    void *rank0Data ;

 
    rank0Data = calloc(512, 1) ;
//	setlocale(LC_CTYPE, "en_US.UTF-8");

    /* Get the starting point of keyValues */
	pList = *(keyValue **)rank0pList ;

    /* Check if the current object is the root group, and if not print the full path name and type */
    if  (childObjectInfo->type == H5O_TYPE_DATASET) {
        /* Open the file */
        file = H5Fopen(getStringValForKeyIn(pList, "HDF5 input"), H5F_ACC_RDONLY, H5P_DEFAULT);
   
        /* Open dataset in HDF5 file */
        currentDataset = H5Dopen2(file, childObjectName, H5P_DEFAULT);

        /* Get dataset dataspace */
        currentDataspace = H5Dget_space(currentDataset) ;
        storage_size = H5Dget_storage_size(currentDataset);
        
        /* Get dataset rank  */
        rank = H5Sget_simple_extent_ndims(currentDataspace) ;

        if (!rank) {
            /* Get data type description */
            currentDataType = H5Dget_type(currentDataset) ;
            currentDataTypeIdentifier = H5Tget_class(currentDataType) ;
            currentDataTypeSize = H5Tget_size(currentDataType) ;
            currentDataTypeOrder = H5Tget_order(currentDataType) ;
            outputDataspace = H5Dget_space (currentDataset);

//            outputDataspace = H5Screate(H5S_SCALAR) ;
            ret = H5Dread(currentDataset, currentDataType, outputDataspace, currentDataspace, H5P_DEFAULT, rank0Data) ;
            sprintf(aKey, "%s", childObjectName) ;
            replaceNSubStringInString(aKey, "/", " ") ;
            stripWhiteCharsAtStartOfString(aKey) ;
            switch (currentDataTypeIdentifier) {
                case H5T_INTEGER:
                    if (currentDataTypeSize == 4) {
                        setIntValForKeyIn(pList, *(int *)rank0Data, aKey) ;
                    }
                    else {
                        setLongValForKeyIn(pList, *(long *)rank0Data, aKey) ;
                    }
                    break;
                    
                case H5T_FLOAT:
                    if (currentDataTypeSize == 4) {
                        setFloatValForKeyIn(pList, *(float *)rank0Data, aKey) ;
                    }
                    else {
                        setDoubleValForKeyIn(pList, *(double *)rank0Data, aKey) ;
                    }
                    break;
                    
                case H5T_STRING:

                    stringType = H5Tget_cset(currentDataType) ;
                    switch (stringType) {
                    case H5T_CSET_UTF8: 
                    /* Create the memory datatype. */
                        memtype = H5Tcopy (H5T_C_S1);
                        ret = H5Tset_size (memtype, H5T_VARIABLE);
                        ret = H5Tset_cset(memtype, H5T_CSET_UTF8);
                        ret = H5Dread(currentDataset, memtype, H5S_ALL, H5S_ALL, H5P_DEFAULT, &utf8_r) ;
                        setStringValForKeyIn(pList, utf8_r, aKey) ;
                        H5Tclose(memtype) ;
                        free(utf8_r) ;                        
                        break;
                    
                    case H5T_CSET_ASCII: 
                    /* This is a crasy trick to try to cope with HDF5 */
                        if (currentDataTypeSize == sizeof(char *)) {
                        /* Create the memory datatype. */
                            memtype = H5Tcopy (H5T_C_S1);
                            ret = H5Tset_size (memtype, H5T_VARIABLE);
                            ret = H5Tset_cset(memtype, H5T_CSET_ASCII);
                            ret = H5Dread(currentDataset, memtype, H5S_ALL, H5S_ALL, H5P_DEFAULT, &utf8_r) ;
                            setStringValForKeyIn(pList, utf8_r, aKey) ;

                        }
                        else {
                           setStringValForKeyIn(pList, (char *)rank0Data, aKey) ;
                        }
                        break;

                    default:
                        setStringValForKeyIn(pList, (char *)rank0Data, aKey) ;
                        break;
                    }
                break;


                default:
                    break;
            }
            H5Sclose (outputDataspace) ;
        }                
        H5Fclose(file) ;
        H5Dclose(currentDataset) ;
    }
    free(rank0Data) ;
    return 0;
}


char *getH5SpaceTypeIdentifier(H5T_class_t dataTypeIdentifier)
{
    char *aString ;
    
    switch (dataTypeIdentifier) {
        case H5S_NULL:
            aString = initStringWithString("H5T_NULL") ;
            break;
            
        case H5S_SCALAR:
            aString = initStringWithString("H5T_SCALAR") ;
            break;
            
        case H5S_SIMPLE:
            aString = initStringWithString("H5T_SIMPLE") ;
            break;
                 
        default:
            aString = initStringWithString("H5S_NO_CLASS?") ;
            break;
    }
    
    return(aString) ;
}
   


char *getHD5DataTypeIdentifier(H5T_class_t dataTypeIdentifier)
{
    char *aString ;
    
    switch (dataTypeIdentifier) {
        case H5T_INTEGER:
            aString = initStringWithString("H5T_INTEGER") ;
            break;
            
        case H5T_FLOAT:
            aString = initStringWithString("H5T_FLOAT") ;
            break;
            
        case H5T_STRING:
            aString = initStringWithString("H5T_STRING") ;
            break;
            
        case H5T_COMPOUND:
            aString = initStringWithString("H5T_COMPOUND") ;
            break;
            
        default:
            aString = initStringWithString("H5T_?") ;
            break;
    }
    
    return(aString) ;
}


char *getHD5DataTypeByteOrder(H5T_order_t dataTypeOrder)
{
    char *aString ;
    
    switch (dataTypeOrder) {
        case H5T_ORDER_LE:
            aString = initStringWithString("H5T_ORDER_LE") ;
            break;
            
        case H5T_ORDER_BE:
            aString = initStringWithString("H5T_ORDER_BE") ;
            break;
            
        default:
            aString = initStringWithString("H5T_?") ;
            break;
    }
    
    return(aString) ;
}


void readIQComponents(keyValue *header)
{
    char *aPath, *polMode, *textFilePath, *inputPath ;
    short *iShortInt, *qShortInt ;
    hsize_t iY, i ;
    complexFloat *aLine = NULL ;
	hid_t   HDF5File ;               /* HDF5 file root dataset identifier */
	hid_t   iDataset, qDataset ;     /* File and dataset identifiers */
    void *iBuffer, *qBuffer ;
    rawFileDescriptor *outputDataFile ;
    CSLImage *thisImage ;
    progressCounter *aCounter ;
    keyValue *savedDataCharacteristics ;
    struct hdf5DatasetDescriptor *datasetDesc ;

	/* Open the file */
    inputPath = getStringValForKeyIn(header, "HDF5 inputfilepath") ;
	if((HDF5File = H5Fopen(inputPath, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0) {
        ase("Failed to open HDF5 file") ;
    }

    /* Open dataset in HDF5 file */
    iDataset = H5Dopen2(HDF5File, "s_i", H5P_DEFAULT);
    qDataset = H5Dopen2(HDF5File, "s_q", H5P_DEFAULT);
    
    /* Get required dataset parameters for data reading */
    datasetDesc = getHDF5DatasetParams(iDataset) ;
    setLongValForKeyIn(header, datasetDesc->datasetDim[1], "SLC range dimension") ;
    setLongValForKeyIn(header, datasetDesc->datasetDim[0], "SLC azimuth dimension") ;

    /* Create output file */
    thisImage = getCSLImageStructureAtPath(getStringValForKeyIn(header, "CSL image directory")) ;
    polMode = getStringValForKeyIn(header, "polarization") ;
    aPath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", polMode) ;
    textFilePath = initStringWith4Strings(thisImage->infoDirectoryPath, "/", getFileNameFromPath(aPath), ".txt") ;
    outputDataFile = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;
    
    /* Alloc buffer */
    iBuffer = malloc(datasetDesc->bufferDim * datasetDesc->dataTypeSize) ;
    qBuffer = malloc(datasetDesc->bufferDim * datasetDesc->dataTypeSize) ;
    iShortInt = (short *)iBuffer ;
    qShortInt = (short *)qBuffer ;
    aLine = vectorComplexFloat(0, datasetDesc->bufferDim - 1) ;
    aCounter = initProgressCounterWithMinMaxValue(0, (int)datasetDesc->datasetDim[0]) ;
    printf("\n\n Reading I/Q components of slc image\n") ;
    
    for (iY = 0; iY < datasetDesc->datasetDim[0]; iY++) {
        datasetDesc->blockOffset[0] = iY ;
        H5Sselect_hyperslab(datasetDesc->dataSpace, H5S_SELECT_SET, datasetDesc->blockOffset, NULL, datasetDesc->blockCount, datasetDesc->blockDim) ;
        H5Dread(iDataset, datasetDesc->dataType, datasetDesc->perLineOutput, datasetDesc->dataSpace, H5P_DEFAULT, iBuffer) ;
        H5Dread(qDataset, datasetDesc->dataType, datasetDesc->perLineOutput, datasetDesc->dataSpace, H5P_DEFAULT, qBuffer) ;
        H5Sselect_none(datasetDesc->dataSpace) ;
        for (i = 0; i < datasetDesc->blockDim[1]; i++) {
            if (datasetDesc->bytesMustBeSwapped) {
                swapByteStructOfType(iBuffer + i * datasetDesc->dataTypeSize, datasetDesc->dataTypeSize) ;
                swapByteStructOfType(qBuffer + i * datasetDesc->dataTypeSize, datasetDesc->dataTypeSize) ;
            }
            aLine[i].r = (float)iShortInt[i] ;
            aLine[i].i = (float)qShortInt[i] ;
        }
        if (fwrite(aLine, sizeof(complexFloat), (size_t)datasetDesc->blockDim[1], outputDataFile->f) != (size_t)datasetDesc->blockDim[1]) {
            ase("\t-/-> Failed to write SLCData") ;
        }
        
        fflush(outputDataFile->f) ;
        updateProgressCounterForIndex(aCounter, iY );
    }
    updateProgressCounterForIndex(aCounter, iY );

    savedDataCharacteristics = allocAKeyValuePair() ;
    setStringValForKeyIn(savedDataCharacteristics, "SLC data structure", "") ;
    setStringValForKeyIn(savedDataCharacteristics, "******************", "") ;
    setStringValForKeyIn(savedDataCharacteristics, "complex", "Data type") ;
    setStringValForKeyIn(savedDataCharacteristics, "float - float", "Data structure") ;
    if (isArchBigEndian()) {
        setStringValForKeyIn(savedDataCharacteristics, "Big endian", "Data byte order") ;
    }
    else {
        setStringValForKeyIn(savedDataCharacteristics, "Low endian", "Data byte order") ;
    }
    setLongValForKeyIn(savedDataCharacteristics, datasetDesc->blockDim[1], "Number of columns") ;
    setLongValForKeyIn(savedDataCharacteristics, datasetDesc->datasetDim[0], "Number of raws") ;
    writeParameterFileAtPath(savedDataCharacteristics, textFilePath) ;
    freeKeyValueList(savedDataCharacteristics) ;
    
    freeRawFileDescriptor(outputDataFile) ;
    freeProgressCounter(aCounter) ;
    free(iBuffer) ;
    free(qBuffer) ;
    freeVectorComplexFloat(aLine, 0) ;

    freeHdf5DatasetDescriptor(datasetDesc) ;
    H5Dclose(iDataset);
    H5Dclose(qDataset);
    H5Fclose(HDF5File) ;
}

void readHDF5FloatMatrixDataset(char *datasetName, keyValue *header)
{
    char *aPath, *inputPath ;
    float *aFloat ;
    double *aDouble ;
    hsize_t iY, i ;
	hid_t   HDF5File ;               /* HDF5 file root dataset identifier */
	hid_t   theDataset ;     /* File and dataset identifiers */
    void *buffer ;
    rawFileDescriptor *outputDataFile ;
    CSLImage *thisImage ;
    struct hdf5DatasetDescriptor *datasetDesc ;

	/* Open the file */
    inputPath = getStringValForKeyIn(header, "HDF5 inputfilepath") ;
	if((HDF5File = H5Fopen(inputPath, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0) {
        ase("Failed to open HDF5 file") ;
    }

    /* Open dataset in HDF5 file */
    theDataset = H5Dopen2(HDF5File, datasetName, H5P_DEFAULT);
    
    /* Get required dataset parameters for data reading */
    datasetDesc = getHDF5DatasetParams(theDataset) ;

    /* Create output file */
    thisImage = getCSLImageStructureAtPath(getStringValForKeyIn(header, "CSL image directory")) ;
    aPath = initStringWith4Strings(thisImage->headersDirectoryPath, "/", datasetName, ".txt") ;
    outputDataFile = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;
    
    /* Alloc buffer */
    buffer = malloc(datasetDesc->bufferDim * datasetDesc->dataTypeSize) ;
    aFloat = (float *)buffer ;
    aDouble = (double *)buffer ;
    printf("\t--->Reading %s dataset\n", datasetName) ;
    
    for (iY = 0; iY < datasetDesc->datasetDim[0]; iY++) {
        datasetDesc->blockOffset[0] = iY ;
        H5Sselect_hyperslab(datasetDesc->dataSpace, H5S_SELECT_SET, datasetDesc->blockOffset, NULL, datasetDesc->blockCount, datasetDesc->blockDim) ;
        H5Dread(theDataset, datasetDesc->dataType, datasetDesc->perLineOutput, datasetDesc->dataSpace, H5P_DEFAULT, buffer) ;
        H5Sselect_none(datasetDesc->dataSpace) ;
        for (i = 0; i < datasetDesc->blockDim[1]; i++) {
            if (datasetDesc->bytesMustBeSwapped) {
                swapByteStructOfType(buffer + i * datasetDesc->dataTypeSize, datasetDesc->dataTypeSize) ;
            }
            switch (datasetDesc->dataTypeSize) {
            case 4:
                fprintf(outputDataFile->f, "%f\t", aFloat[i]) ;
                break;
            
            case 8:
                fprintf(outputDataFile->f, "%f\t", aDouble[i]) ;
                break;
            
            default:
                break;
            }
        }
        fprintf(outputDataFile->f, "\n") ;        
        fflush(outputDataFile->f) ;
    }

    freeRawFileDescriptor(outputDataFile) ;
    free(buffer) ;

    freeHdf5DatasetDescriptor(datasetDesc) ;
    H5Dclose(theDataset);
    H5Fclose(HDF5File) ;
}


void readHDF5FloatVectorDataset(char *datasetName, keyValue *header)
{
    char *inputPath ;
    hsize_t i ;
	hid_t   HDF5File ;               /* HDF5 file root dataset identifier */
	hid_t   theDataset ;     /* File and dataset identifiers */
    void *buffer ;
    struct hdf5DatasetDescriptor *datasetDesc ;

	/* Open the file */
    inputPath = getStringValForKeyIn(header, "HDF5 inputfilepath") ;
	if((HDF5File = H5Fopen(inputPath, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0) {
        ase("Failed to open HDF5 file") ;
    }

    /* Open dataset in HDF5 file */
    if (!(theDataset = H5Dopen2(HDF5File, datasetName, H5P_DEFAULT))) {
        return ;
    }
        
    /* Get required dataset parameters for data reading */
    datasetDesc = getHDF5DatasetParams(theDataset) ;
    
    /* Alloc buffer */
    /* This time, we will read the whole vector, since we know we deal with rank = 1 dataset */
    datasetDesc->blockDim[0] =datasetDesc->datasetDim[0] ;
    buffer = malloc(datasetDesc->blockDim[0] * datasetDesc->dataTypeSize) ;
    printf("\t---> Reading %s dataset\n", datasetName) ;
    
    datasetDesc->blockOffset[0] = 0 ;
    H5Sselect_hyperslab(datasetDesc->dataSpace, H5S_SELECT_SET, datasetDesc->blockOffset, NULL, datasetDesc->blockCount, datasetDesc->blockDim) ;
    H5Dread(theDataset, datasetDesc->dataType, datasetDesc->outputDataSpace, datasetDesc->dataSpace, H5P_DEFAULT, buffer) ;
    H5Sselect_none(datasetDesc->dataSpace) ;
    for (i = 0; i < datasetDesc->datasetDim[0]; i++) {
        if (datasetDesc->bytesMustBeSwapped) {
            swapByteStructOfType(buffer + i * datasetDesc->dataTypeSize, datasetDesc->dataTypeSize) ;
        }
    }

    /* Store vector as keyvalue */
    switch (datasetDesc->dataTypeSize)
    {
    case 4 :
        setVectorFloatForKeyIn(header, (float *)buffer, (int)datasetDesc->datasetDim[0], datasetName) ;
        break;
    
    case 8 :
        setVectorDoubleForKeyIn(header, (double *)buffer, (int)datasetDesc->datasetDim[0], datasetName) ;
        break;
    
    default:
        break;
    }
    
    freeHdf5DatasetDescriptor(datasetDesc) ;
    H5Dclose(theDataset);
    H5Fclose(HDF5File) ;
}


CSVStruct *readHDF5StringVectorDataset(char *datasetName, keyValue *header)
{
    char *inputPath ;
    hsize_t iY ;
	hid_t   HDF5File ;               /* HDF5 file root dataset identifier */
	hid_t   theDataset ;     /* File and dataset identifiers */
    void *buffer ;
    struct hdf5DatasetDescriptor *datasetDesc ;
    CSVStruct *csv = NULL ;

	/* Open the file */
    inputPath = getStringValForKeyIn(header, "HDF5 inputfilepath") ;
	if((HDF5File = H5Fopen(inputPath, H5F_ACC_RDONLY, H5P_DEFAULT)) < 0) {
        ase("Failed to open HDF5 file") ;
    }

    /* Open dataset in HDF5 file */
    if (!(theDataset = H5Dopen2(HDF5File, datasetName, H5P_DEFAULT))) {
        return (NULL) ;
    }
        
    /* Get required dataset parameters for data reading */
    datasetDesc = getHDF5DatasetParams(theDataset) ;
    
    /* Alloc buffer */
    /* This time, we will read the whole vector, since we know we deal with rank = 1 dataset */
    buffer = malloc(datasetDesc->blockDim[0] * datasetDesc->dataTypeSize) ;
    printf("\n\n Reading %s dataset\n", datasetName) ;
    
    for (iY = 0; iY < datasetDesc->datasetDim[0]; iY++)
    {
        datasetDesc->blockOffset[0] = iY ;
        H5Sselect_hyperslab(datasetDesc->dataSpace, H5S_SELECT_SET, datasetDesc->blockOffset, NULL, datasetDesc->blockCount, datasetDesc->blockDim) ;
        H5Dread(theDataset, datasetDesc->dataType, datasetDesc->perLineOutput, datasetDesc->dataSpace, H5P_DEFAULT, buffer) ;
        H5Sselect_none(datasetDesc->dataSpace) ;
        csv = addStringValInCSVStruct((char *)buffer, csv) ;
    }
        
    freeHdf5DatasetDescriptor(datasetDesc) ;
    H5Dclose(theDataset);
    H5Fclose(HDF5File) ;

    return (csv) ;
}



/* Get hdf5 dataset parameters */
struct hdf5DatasetDescriptor * getHDF5DatasetParams(hid_t dataset)
{
    int i; 
    hid_t dataSpace ;
    struct hdf5DatasetDescriptor *hdf5Struct ;

    hdf5Struct = malloc(sizeof(hdf5Struct[0])) ;

    /* Get dataset dataspace */
    dataSpace = hdf5Struct->dataSpace = H5Dget_space(dataset) ;

    /* Get dataset rank  */
    hdf5Struct->rank = H5Sget_simple_extent_ndims(dataSpace) ;
    if(hdf5Struct->rank && hdf5Struct->rank < 4) {
        /* Get data type description */
        hdf5Struct->dataType = H5Dget_type(dataset) ;
        hdf5Struct->dataTypeIdentifier = H5Tget_class(hdf5Struct->dataType) ;
        hdf5Struct->dataTypeSize = H5Tget_size(hdf5Struct->dataType) ;
        hdf5Struct->dataTypeOrder = H5Tget_order(hdf5Struct->dataType) ;
        hdf5Struct->bytesMustBeSwapped = !(isArchBigEndian() ^ (hdf5Struct->dataTypeOrder == H5T_ORDER_LE)) ;
        
        /* Allocate dimension vectors */
        hdf5Struct->datasetDim = malloc(hdf5Struct->rank * sizeof(hsize_t)) ;
        hdf5Struct->maxDims = malloc(hdf5Struct->rank * sizeof(hsize_t)) ;
        
        /* Get dataset full size */
        H5Sget_simple_extent_dims(dataSpace, hdf5Struct->datasetDim, hdf5Struct->maxDims) ;
        H5Sselect_none(dataSpace) ;
        hdf5Struct->selectionType = H5Sget_select_type(dataSpace) ;
                    
        /* Set block dimension and offset */
        hdf5Struct->blockDim = malloc(hdf5Struct->rank * sizeof(hsize_t)) ;
        hdf5Struct->blockOffset = malloc(hdf5Struct->rank * sizeof(hsize_t)) ;
        hdf5Struct->blockCount = malloc(hdf5Struct->rank * sizeof(hsize_t)) ;
        
        hdf5Struct->bufferDim = 1 ;
        for (i = 0; i < hdf5Struct->rank; i++) {
            hdf5Struct->blockCount[i] = 1 ;
            hdf5Struct->blockDim[i] = hdf5Struct->datasetDim[i] ;
            hdf5Struct->blockOffset[i] = 0 ;
            if(i) hdf5Struct->bufferDim *= hdf5Struct->blockDim[i] ;
        }
        hdf5Struct->outputDataSpace = H5Screate_simple(hdf5Struct->rank, hdf5Struct->blockDim, hdf5Struct->maxDims) ;
        hdf5Struct->blockDim[0] = 1 ;
        hdf5Struct->perLineOutput = H5Screate_simple(hdf5Struct->rank, hdf5Struct->blockDim, hdf5Struct->maxDims) ;
    }

    return (hdf5Struct) ;
}


void freeHdf5DatasetDescriptor (struct hdf5DatasetDescriptor *hdf5DatasetParams)
{
    H5Tclose(hdf5DatasetParams->dataType) ;
    free(hdf5DatasetParams->datasetDim) ;
    free(hdf5DatasetParams->maxDims) ;
    free(hdf5DatasetParams->blockDim) ;
    free(hdf5DatasetParams->blockOffset) ;
    H5Sclose(hdf5DatasetParams->dataSpace) ;

    free(hdf5DatasetParams) ;
}
