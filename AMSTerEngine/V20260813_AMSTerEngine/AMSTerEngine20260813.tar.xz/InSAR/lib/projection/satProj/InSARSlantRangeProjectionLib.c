
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  InSARSlantRangeProjectionLib.c
//  slantRangeDEM
//
//  Created by Dominique Derauw on 25/10/18.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "InSARSlantRangeProjectionLib.h"



void generateExternalSlantRangeDEM(InSARParametersStruct *pInSAR)
{
    int i, j, dimXOut, dimYOut ;
    int coa, cor, squareSpiralSize ;
    float       *externalSlantRangeDEM ;
    double     rangePosition, azimuthPosition ;
    gridMap *slantRangeDEMGrid ;
    CSLImage *referenceImage ;

    coa = (pInSAR->coh).coa ;
    cor = (pInSAR->coh).cor ;
    squareSpiralSize = (pInSAR->coh).spi ;
    dimYOut = ((pInSAR->aoi->P[2].y - pInSAR->aoi->P[0].y - squareSpiralSize + 2) - (pInSAR->coh).coa + 1) / (pInSAR->red).Faz ;
    dimXOut = ((pInSAR->aoi->P[2].x - pInSAR->aoi->P[0].x - squareSpiralSize + 2) - (pInSAR->coh).cor + 1) / (pInSAR->red).Fra ;

    /* If an external slant range DEM is available, recompute it at the same location and with the same size than the InSAR products */
    if ((referenceImage = getReferenceCSLImage(pInSAR))) {
        if((slantRangeDEMGrid = allocAndInitExternalFileGridForImage(referenceImage, "externalSlantRangeDEM")) == NULL) {
            ase("No external slant range DEM available. Please run slantRangeDEM first\n") ;
        }
        externalSlantRangeDEM = vectorFloat(0, dimXOut-1) ;

        if(!openExternalSlantRangeDEMFile(pInSAR)) {
            ase("Failed to create external slant range DEM file for writing") ;
        }

        pInSAR->externalSlantRangeDEMFile->xDim = dimXOut ;
        pInSAR->externalSlantRangeDEMFile->yDim = dimYOut ;

        azimuthPosition = (double)(pInSAR->aoi->P[0].y + squareSpiralSize / 2 + coa / 2 + pInSAR->yShift) ;
        for (i = 0; i < dimYOut; i++, azimuthPosition += (pInSAR->red).Faz) {
            rangePosition = pInSAR->aoi->P[0].x + squareSpiralSize / 2 + cor / 2 ;
            for (j = 0; j < dimXOut; j++, rangePosition += (pInSAR->red).Fra) {
                externalSlantRangeDEM[j] = (float)interpolFloatGridForImageCoordinate(slantRangeDEMGrid, rangePosition, azimuthPosition) ;
            }
            fwrite((float *)externalSlantRangeDEM, sizeof(float), dimXOut, pInSAR->externalSlantRangeDEMFile->f) ;
        }
        closeRawFile(pInSAR->externalSlantRangeDEMFile) ;
    }
}
