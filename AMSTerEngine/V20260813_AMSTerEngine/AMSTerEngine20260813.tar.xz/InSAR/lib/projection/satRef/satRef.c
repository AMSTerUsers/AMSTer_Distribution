
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  satRef.c
 *  ground2SlantProj
 *
 *  Created by Dominique Derauw on 8/09/08.
 *  Copyright 2008 Dominique Derauw. All rights reserved.
 *
 */

#include "satRef.h"

/* satRef structure allocation */
satRef *allocSatRef()
{
	satRef *p ;

	if((p = malloc(sizeof(satRef))) == NULL) {
		ase("Failed to allocate geoRef structure") ;
        exit(-1) ;
	}

	if((p->gR = malloc(sizeof(geoRef))) == NULL) {
		ase("Failed to allocate geoRef structure") ;
        exit(-1) ;
	}

	if((p->params = malloc(sizeof(satRefPar))) == NULL) {
		ase("Failed to allocate geoRef structure") ;
        exit(-1) ;
	}
	p->gR->params = p->params ;

	if((p->files = malloc(sizeof(satRefFiles))) == NULL) {
		ase("Failed to allocate geoRef structure") ;
        exit(-1) ;
	}
	p->gR->files = p->files ;

	if((p->frame = malloc(sizeof(geoRefFrame))) == NULL) {
		ase("Failed to allocate geoRef structure") ;
        exit(-1) ;
	}
	p->frame->xMin = p->frame->xMax = p->frame->yMin = p->frame->yMax = 0 ;
	p->gR->frame = p->frame ;

	p->solving = p->gR->solving = allocGeoRefSolvingStructure() ;

	p->geo2SRApproxTransform = matrixDouble(0, 1, 0, 2) ;

	return(p) ;
}

void freeSatRef(satRef *sR)
{
    freeGeoRef(sR->gR) ;
    sR->gR = NULL ;
    freeMatrixDouble(sR->geo2SRApproxTransform, 0, 0) ;
    free(sR) ;
}

satRef *allocAndInitSatRefWithGeoRefStructure(geoRef *gR)
{
	satRef *sR ;

	if((sR = malloc(sizeof(satRef))) == NULL) {
		ase("Failed to allocate geoRef structure") ;
        exit(-1) ;
	}

	sR->gR = gR ;
	sR->params = sR->gR->params ;
	sR->files = sR->gR->files ;
	sR->frame = sR->gR->frame ;
	sR->solving = sR->gR->solving ;
	sR->isGeo2SRApproxTransformComputed = 0 ;
	sR->geo2SRApproxTransform = matrixDouble(0, 1, 0, 2) ;

	return(sR) ;
}

/* This fuction will return a matrix double (2 X 3) containing the coefficients of an affine transform approximating the (lon, lat, H=0) to (range, azimuth) coordinate transform */
/* The transform is saved within the satRef Structure */
/* The satRef structure sent to the function must be fully initialized using a valid geoRef structure */
double **geo2SlantRangeAzimuthApproximateTransform(satRef *sR)
{
	int		i, j, *index, N ;
    double	**M, signe ;
    double	dx, dz ;
    double	range, azimuth, *sol, *xyz, *llh ;
    double	azimuthMin, azimuthMax, rangeMin, rangeMax ;
    double	*cLon, *cLat ;
	double *VLon, *VLat ;
    double	det ;

	/* Referencing vectors containing the transform cefficients */
    cLon = sR->geo2SRApproxTransform[0] - 1 ;
    cLat = sR->geo2SRApproxTransform[1] - 1 ;

	/* Allocating coordinate vectors */
	llh = vectorDouble(0, 2) ;
	sol = vectorDouble(0, 2) ;

	/* Image frame and altitude range on which is calculate the transform */
    azimuthMin = 0. ;
    azimuthMax = (double)sR->params->info->azimuthDimension - 1. ;
    rangeMin = 0. ;
    rangeMax = (double)sR->params->info->rangeDimension - 1. ;

	/* Allocation of a vector that will contain the on-ground coordinate of a given point */
//    Pg = vectorDouble(0, 2) ;

	/* Allocation of a matrix to solve the system */
    M = matrixDouble(1, 3, 1, 3) ;
    index = vectorInt(1, 3) ;

	/* Initialization */
    for(i = 1; i <= 3; i++) {
        cLon[i] = cLat[i] = 0. ;
        for(j = 1; j <= 3; j++)
            M[i][j] = 0. ;
    }

	/* The image frame and the altitude range are sampled on a 5x5x5 network */
	/* For each point of this net, the geographic coordinate will be calculated and the transform will be evaluated by least square calculation */
    N = 5 ;
    dx = (azimuthMax - azimuthMin)/(N - 1) ;
    dz = (rangeMax - rangeMin)/(N - 1) ;
    for(i = 0; i < N; i++) {										/* Loop on azimuth coordinate */
        azimuth = azimuthMin + i * dx ;								/* Azimuth coordinate of the considered point of the network */
		calcStateVect(sR->solving->S, azimuth, sR->params->info) ;	/* Calculation of the correspnding state vector */
		initOnSphereSolving(sR->solving) ;							/* georeferencing initialization for this azimuth position*/

        for(j = 0; j < N; j++) {									/* Loop on range Coordinate */
            range = rangeMin + j * dz ;
			sR->solving->Rt = earthRadiusAtPoint(range, azimuth, sR->gR->params->info->sceneAverageHeight, sR->gR) ;
            xyz = onSphereSolvingForPoint(range, azimuth, sR->gR->params->info->sceneAverageHeight, sR->gR)  ;
            onEllipsoidProjection(sol, xyz, sR->solving) ;
            XYZ2LonLatH(sol, llh, sR->solving) ;

            M[1][1] += range * range ;
            M[1][2] += azimuth * range ;
            M[1][3] += range ;
            M[2][2] += azimuth * azimuth ;
            M[2][3] += azimuth ;
            M[3][3] ++ ;

            cLon[1] += range * llh[0] ;
            cLon[2] += azimuth * llh[0] ;
            cLon[3] += llh[0] ;
            cLat[1] += range * llh[1] ;
            cLat[2] += azimuth * llh[1] ;
            cLat[3] += llh[1] ;
        }
    }
    M[2][1] = M[1][2] ;
    M[3][1] = M[1][3] ;
    M[3][2] = M[2][3] ;

    ludcmp(M, 3, index, &signe) ;
    lubksb(M, 3, index, cLon) ;
    lubksb(M, 3, index, cLat) ;

    freeVectorDouble(sol, 0) ;
    freeVectorDouble(llh, 0) ;
    freeMatrixDouble(M, 1, 1) ;
    freeVectorInt(index, 1) ;

	/* The resulting transforms gives the approximate geolocation of a given slant range - azimuth point */
	/* the obtained transform must still be inversed */
    VLon = vectorDouble(1, 3) ;
    VLat = vectorDouble(1, 3) ;
	for(i = 1; i <= 3; i++) {
		VLon[i] = cLon[i] ;
		VLat[i] = cLat[i] ;
	}

    det = VLon[1] * VLat[2] - VLat[1] * VLon[2] ;

    cLon[1] = VLat[2] / det ;
    cLon[2] = -VLon[2] / det ;
    cLon[3] = (VLon[2] * VLat[3] - VLat[2] * VLon[3])/det ;

    cLat[1] = -VLat[1] / det ;
    cLat[2] = VLon[1] / det ;
    cLat[3] = (VLat[1] * VLon[3] - VLon[1] * VLat[3])/det ;

	freeVectorDouble(VLon, 1) ;
	freeVectorDouble(VLat, 1) ;

    sR->isGeo2SRApproxTransformComputed = 1 ;

	return(sR->geo2SRApproxTransform) ;
}


/* Compute approximate azilmuth for given longitude - latitude coordinate using established affine transform */
double	approxAz(double lon, double lat, double *C)
{
    return C[0] * lon + C[1] * lat + C[2] ;
}

/* Compute approximate range for given longitude - latitude coordinate using established affine transform */
double	approxRa(double lon, double lat, double *C)
{
    return C[0] * lon + C[1] * lat + C[2] ;
}

/* Compute approximate range - azilmuth coordinate for given longitude - latitude coordinate using established affine transform */
void	approximateRangeAzimuthForLonLat(double *lonLatH, double *approxRangeAzimuth, satRef *sR)
{
    approxRangeAzimuth[1] = approxAz(lonLatH[0], lonLatH[1], sR->geo2SRApproxTransform[1]) ;
    approxRangeAzimuth[0] = approxRa(lonLatH[0], lonLatH[1], sR->geo2SRApproxTransform[0]) ;
}


/* This function locates the range and azimuth coordinate of point given in (lon, lat, H) coordinate */
void rangeAzimuthReferencingOfpoint(double *lonLatH, double *xy, satRef *sR )
{
	double d, dY ;
	double V, r, *Pg ;

	if(!sR->isGeo2SRApproxTransformComputed)
		geo2SlantRangeAzimuthApproximateTransform(sR) ;

    /* Locate point into cartesion coordinates */
	Pg = vectorDouble(0, 2) ;
	lonLatH2XYZ(lonLatH, Pg, sR->params->ellRef) ;

    /* Initiate iteration process */
    approximateRangeAzimuthForLonLat(lonLatH, xy, sR) ;
    calcStateVect(sR->solving->S, xy[1], sR->params->info) ;
    initOnSphereSolving(sR->solving) ;
	do {
//		earthRadiusAtPoint(xy[0], xy[1], lonLatH[2], sR->gR) ;

        /* Calculation of the norm of the normal to the Doppler plane */
		V = vectorNorm(sR->solving->eq1) ;

		/* Calculation of the distance to the Doppler plane at origin */
		r = sR->solving->eq1[3] / V ;

		/* calculation of the distance between the Doppler plane and the consdered point */
		d = scalarProduct(sR->solving->eq1, Pg) / V - r ;

#if !defined (REFERENTIEL_TOURNANT)
		/* Projection of the latter distance onto the orbit direction */
		d *= V * vectorNorm(sR->solving->S->V) / scalarProduct(sR->solving->S->V, sR->solving->eq1) ;
#endif

        /* azimuth shift is converted in pixels */
		dY = d / sR->params->info->azimuthResolutionCell ;

        /* Shift is applied */
		xy[1] += dY ;

        /* We update the state vector and the geoprojection for the corrected azimuth position */
		calcStateVect(sR->solving->S, xy[1], sR->params->info) ;
		initOnSphereSolving(sR->solving) ;
	} while(fabs(dY) >.01) ;			/* --> requested precision is 1/100 pixel */

    /* Now we compute the corrected range position */
    vectorDiff(sR->solving->V3, sR->solving->S->P, Pg) ;
    xy[0] = (vectorNorm(sR->solving->V3) - sR->params->info->slantRange[0]) / sR->params->info->rangeResolutionCell ;

    freeVectorDouble(Pg, 0) ;
}


/* This function locates the range and azimuth coordinate of point given in (lon, lat, H) coordinate using a specific Doppler plane given in input */
void rangeAzimuthReferencingOfpointUsingDopplerPlane(double *lonLatH, double *xy, satRef *sR, double *eq1)
{
	double d, dY ;
	double V, r, *Pg ;

	if(!sR->isGeo2SRApproxTransformComputed)
		geo2SlantRangeAzimuthApproximateTransform(sR) ;

	Pg = vectorDouble(0, 2) ;
	approximateRangeAzimuthForLonLat(lonLatH, xy, sR) ;
	lonLatH2XYZ(lonLatH, Pg, sR->params->ellRef) ;

    calcStateVect(sR->solving->S, xy[1], sR->params->info) ;
    initOnSphereSolving(sR->solving) ;
	do {
		if(!earthRadiusAtPoint(xy[0], xy[1], lonLatH[2], sR->gR)) {
            xy[0] = xy[1] = 0. ;
            break ;
        }
		V = vectorNorm(eq1) ;

		/* Calculation of the distance to the  given Doppler plane at origin */
		r = scalarProduct(eq1, sR->solving->S->P) / V ;

		/* calculation of the distance between the Doppler plane and the consdered point */
		d = scalarProduct(eq1, Pg) / V - r ;

#if !defined (REFERENTIEL_TOURNANT)
		/* Projection of the latter distance onto the orbit direction */
		d *= V * vectorNorm(sR->solving->S->V) / scalarProduct(sR->solving->S->V, eq1) ;
#endif

		dY = d / sR->params->info->azimuthResolutionCell ;
		xy[1] += dY / 2. ;                  /* Don't go too fast to avoid diverging oscillations that may appear using ALOS2 orbits... */

        /* We update the state vector and the geoprojection for the corrected azimuth position */
		calcStateVect(sR->solving->S, xy[1], sR->params->info) ;
		initOnSphereSolving(sR->solving) ;

        /* Now we compute the corrected range position */
		vectorDiff(sR->solving->V3, sR->solving->S->P, Pg) ;
		xy[0] = (vectorNorm(sR->solving->V3) - sR->params->info->slantRange[0]) / sR->params->info->rangeResolutionCell ;
	} while(fabs(dY) >.001) ;			/* --> requested precision is 1/100 pixel */

    freeVectorDouble(Pg, 0) ;
}

/* The lon-lat aoi polygon given in input is converted into slant range azimuth coordinate */
/* The area of interest is limited to the frame of the image under concern */
polygon *convertAoIFromDeg2SRA(polygon *aoi, SLCImageInfo *info, double *H)
{
    int i ;
    double *xy, *llh, x, y ;
    geoRef  *geo ;
    satRef  *sat ;
    

    /* Initialize georeferencing */
    orbitInterpolation(info) ;                                                                                    /* Interpolat orbit if required */
    geo = allocAndInitGeorefStructureForTargetEllipsoid(info, info->ellRef) ;
    info->EarthRadiusAtSceneCenter = earthRadiusAtPoint(info->rangeDimension / 2., info->azimuthDimension / 2., info->sceneAverageHeight, geo) ;                   /* Compute RT at centre of area */
    llh = vectorDouble(0, 2) ;
    xy = vectorDouble(0, 1) ;
    sat = allocAndInitSatRefWithGeoRefStructure(geo) ;

    llh[2] = sat->params->info->sceneAverageHeight ;                    /* We initialize local height with average height of the scene */
    convertAoIFromDeg2Rad(aoi) ;

    for (i = 0; i < aoi->N; i++) {
        llh[0] = aoi->P[i].x ;
        llh[1] = aoi->P[i].y ;
        llh[2] = (H)? H[i] : sat->params->info->sceneAverageHeight ;
        rangeAzimuthReferencingOfpoint(llh, xy, sat) ;
        x = round(xy[0]) ;
        y = round(xy[1]) ;

        x = (x < 0)? 0 : (x > info->rangeDimension - 1)? info->rangeDimension - 1 : x ;
        y = (y < 0)? 0 : (y > info->azimuthDimension - 1)? info->azimuthDimension - 1 : y ;

        aoi->P[i].x = x ;
        aoi->P[i].y = y ;
    }
    
    freeVectorDouble(xy, 0) ;
    freeVectorDouble(llh, 0) ;
    freeSatRef(sat) ;

    return (aoi) ;
}


polygon *convertAoIFromDeg2SRAForHeight(quadrilateral *aoi, SLCImageInfo *info, double height)
{
    int i ;
    double *H ;

    H = vectorDouble(0, aoi->N - 1) ;
    for (i = 0; i < aoi->N; i++) {
        H[i] = height ;
    }
    aoi = convertAoIFromDeg2SRA(aoi, info, H) ;
    freeVectorDouble(H, 0) ;

    return (aoi) ;
}



