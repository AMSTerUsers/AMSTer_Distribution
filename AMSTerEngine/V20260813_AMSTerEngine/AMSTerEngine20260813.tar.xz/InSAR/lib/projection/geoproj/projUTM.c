
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  projUTM.c
 *  dephiProj
 *
 *  Created by Dominique Derauw on Mon Mar 25 2002.
 *  Copyright (c) 2001 Dominique Derauw All rights reserved.
 *
 */

#include "projUTM.h"

/* Calcul de la zone UTM à laquelle appartient l'image */
/* La localisation se base sur le point central de l'image */
void updateUTMZoneForSLCImage(geoRef *aGeoRefStructure, UTMZoneStruct *UTMZone)
{
    char	zoneLatUTM[25] ;
    double	*onEllipsoidPoint, *onSpherePoint, latitude, longitude ;
	double azimuthPosition, rangePosition ;
 	geoRefSolving *gRSolving ;
   
    sprintf(zoneLatUTM, "ABCDEFGHJKLMNPQRSTUVWXYZ") ;
    onEllipsoidPoint = vectorDouble(0, 2) ;
    azimuthPosition = aGeoRefStructure->params->info->azimuthDimension / 2. ;
    rangePosition = aGeoRefStructure->params->info->rangeDimension / 2. ;
	
	gRSolving = aGeoRefStructure->solving ;
	calcStateVect(gRSolving->S, azimuthPosition, aGeoRefStructure->params->info) ;
	initOnSphereSolving(gRSolving) ;
	earthRadiusAtPoint(rangePosition, azimuthPosition, 0., aGeoRefStructure) ;
	
	onSpherePoint = onSphereSolvingForPoint(rangePosition, azimuthPosition, 0., aGeoRefStructure) ;
	onEllipsoidProjection(onEllipsoidPoint, onSpherePoint, gRSolving) ;
	XYZ2LonLat(&longitude, &latitude, onEllipsoidPoint, gRSolving) ;

    updateUTMZoneForReferencePoint(longitude, latitude, UTMZone) ;

    freeVectorDouble(onEllipsoidPoint, 0) ;
}



/* Update UTM zone with respect to a reference point */
/* Reference longitude - latitude point is given in radian */
void updateUTMZoneForReferencePoint(double longitude, double latitude, UTMZoneStruct *UTMZone)
{
    char	zoneLatUTM[25] ;
   
    longitude *= 180. / PI ;
    latitude *= 180. / PI ;

    sprintf(zoneLatUTM, "ABCDEFGHJKLMNPQRSTUVWXYZ") ;
	
    UTMZone->indiceZoneLonUTM = (int)(longitude + 186) / 6 ;
    UTMZone->lambdaC = PI / 180. * (UTMZone->indiceZoneLonUTM * 6. - 183.) ;
    if(latitude > -80. && latitude < 72.) UTMZone->indiceZoneLatUTM = (int)(latitude + 80) / 8 + 2 ;
    else {
        if(latitude >= 72.) {
            if(latitude < 84.) UTMZone->indiceZoneLatUTM = 21 ;
            else {
                UTMZone->lambdaC = 0. ;
                UTMZone->indiceZoneLonUTM = 0 ;
                UTMZone->indiceZoneLatUTM = (longitude< 0)? 22 : 23 ;
            }
        }
        else {
                UTMZone->lambdaC = 0. ;
                UTMZone->indiceZoneLonUTM = 0 ;
                UTMZone->indiceZoneLatUTM = (longitude < 0)? 0 : 1 ;
        }
    }
	UTMZone->y0 = (UTMZone->indiceZoneLatUTM < 12)? 10000000. : 0. ;
 
    sprintf(UTMZone->zoneLatUTM, "%c", zoneLatUTM[UTMZone->indiceZoneLatUTM]) ;
    UTMZone->zoneLatUTM[1] = '\0' ;
//    printf("UTM Zone %2d %c\n", UTMZone->indiceZoneLonUTM, zoneLatUTM[UTMZone->indiceZoneLatUTM]) ;
}


/* Update UTM zone structure with respect to given UTM zone string */
int updateUTMZone(char *zone, UTMZoneStruct *UTMZone)
{
    char zoneCode[2], zoneLatUTM[25] ;
    int zoneIndex ;

    sprintf(zoneLatUTM, "ABCDEFGHJKLMNPQRSTUVWXYZ") ;
    if (zone) {
        if (strlen(zone) == 3){
            sscanf(zone, "%2d%1s", &zoneIndex, zoneCode) ;
            zoneCode[1] = '\0' ;
            if (locateSubStringInString(zoneLatUTM, zoneCode) == SUBSTRINGNOTFOUND) {
                sscanf(zone, "%1s%2d", zoneCode, &zoneIndex) ;
            }
            
            convertStringToUppercase(zoneCode) ;
            if (zoneCode[0] > 65 && zoneCode[0] < 90) {
                UTMZone->indiceZoneLonUTM = zoneIndex ;
                UTMZone->indiceZoneLatUTM = locateSubStringInString(zoneLatUTM, zoneCode) ;
                sprintf(UTMZone->zoneLatUTM, "%1s", zoneCode) ;
                UTMZone->lambdaC = PI / 180. * (UTMZone->indiceZoneLonUTM * 6. - 183.) ;
                UTMZone->y0 = (UTMZone->indiceZoneLatUTM < 12)? 10000000. : 0. ;
                if (UTMZone->indiceZoneLatUTM >= 21 || !UTMZone->indiceZoneLatUTM) {
                        UTMZone->lambdaC = 0. ;
                        UTMZone->indiceZoneLonUTM = 0 ;
                }
                return (1) ;
            }
            else {
                printf("\t-/-> Unable to update UTM zone. Wrong string given in input: %s\n", zone) ;
                return(0) ;
            }
        }
    }
    return(0) ;
}