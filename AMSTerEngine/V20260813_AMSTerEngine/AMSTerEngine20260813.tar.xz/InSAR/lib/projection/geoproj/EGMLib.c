/* 
*  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version. 
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 * 
 *  You should have received a copy of the GNU Affero General Public License 
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**************************************************
 * File name : EGMLib.c
 * Author : Dominique Derauw
 * Date : 2026-02-03
 * Copyright 2026 Dominique Derauw
 * Description : 
 **************************************************/


#include <stdio.h>
#include "EGMLib.h"

/* Get EGM heights over covered aoi */
gridMap *getEGMGrid(polygon *aoi, int xDimAoI, int yDimAoI, char *EGMID) 
{
    char *EGMRootDir, *EGMDirPath, *EGMFilePath ;
    char header[1024] ;
    short *EGMLine ;
    short unsigned aUShort ;
    int NXGrid, NYGrid, dNXGrid, dNYGrid ;
    int dimXEGM, dimYEGM ;
    int iX, iY, xIndex, yIndex ;
    int isPGMFile, EGMSamplesPerDegree ;
    size_t seekVal0, seekVal ;
    double EGMSampling, xDEMSampling, yDEMSampling ; 
    double xDEMWidth, yDEMWidth ;
    double offset, scale ;
    rawFileDescriptor *aFile ;
    gridMap *EGMHeight = NULL ; 

    /* Look for available EGM */
    if ((EGMRootDir = getenv("EARTH_GRAVITATIONAL_MODELS_DIR")) == NULL) {
        ase("\t-/-> EARTH_GRAVITATIONAL_MODELS_DIR environment variable not set. EGM not found\n") ;
    }

    EGMFilePath = NULL ;
    EGMDirPath = initStringWith3Strings(EGMRootDir, "/", EGMID) ;
    if (!isDir(EGMDirPath)) {
        printf("\t-/-> Requested EGM directory not found: %s\n", EGMDirPath) ;
        free(EGMDirPath) ;
        return NULL ;
    }
    
    /* If EGM2008 is requested ...*/
    isPGMFile = 1 ;
    if (!strcmp(EGMID, "EGM2008")) {
        EGMFilePath = initStringWith2Strings(EGMDirPath, "/egm2008-1.pgm") ; 
        if (!fileExistsAtPath(EGMFilePath)) {
            free(EGMFilePath) ;
            EGMFilePath = initStringWith2Strings(EGMDirPath, "/egm2008-2_5.pgm") ; 
            if (!fileExistsAtPath(EGMFilePath)) {
                free(EGMFilePath) ;
                EGMFilePath = initStringWith2Strings(EGMDirPath, "/egm2008-5.pgm") ; 
                if (!fileExistsAtPath(EGMFilePath)) {
                    free(EGMFilePath) ;
                    free(EGMDirPath) ;
                    EGMDirPath = EGMFilePath = NULL ;
                    printf("\t-/-> EGM2008 directory exists but do not contain any valid EGM2008 .pgm files\n") ; 
                    printf("\t-/-> Expected files are egm2008-1.pgm, egm2008-2_5.pgm or egm2008-5.pgm\n") ; 
                }
            }
        }
    }
    
    if (!strcmp(EGMID, "EGM96")) {
        EGMFilePath = initStringWith2Strings(EGMDirPath, "/egm96-5.pgm") ; 
        if (!fileExistsAtPath(EGMFilePath)) {
            free(EGMFilePath) ;
            EGMFilePath = initStringWith2Strings(EGMDirPath, "/egm96-15.pgm") ; 
            if (!fileExistsAtPath(EGMFilePath)) {
                free(EGMFilePath) ;
                EGMFilePath = initStringWith2Strings(EGMDirPath, "/WW15MGH.DAC") ; 
                isPGMFile = 0 ;
                offset = 0 ;
                scale = 0.01 ;
                if (!fileExistsAtPath(EGMFilePath)) {
                    free(EGMFilePath) ;
                    free(EGMDirPath) ;
                    EGMDirPath = EGMFilePath = NULL ;
                    printf("\t-/-> EGM96 directory exists but do not contain any valid EGM96 files\n") ; 
                    printf("\t-/-> Expected files are egm96-5.pgm, egm96-15.pgm or WW15MGH.DAC\n") ; 
                }
            }
        }
    }
    
    if (!EGMFilePath) {
        printf("\t-/-> Cannot find requested Earth Gravitational Model.\nEGM's can be downloaded from https://geographiclib.sourceforge.io/C++/doc/geoid.html\n") ; 
        return NULL ;
    }
    

    /* Open EGM file */
    if ((aFile = openRawFileForReadingAtPath(EGMFilePath)) == NULL) {
        ase("Failed to open EGM file for reading\n") ;
    }
    seekVal = seekVal0 = 0 ;

    if (isPGMFile) {
        fgets(header, 1024, aFile->f) ;
        if (strncmp(header, "P5", 2)) {
            ase("\t-/-> EGM file is not in a .pgm file\n") ;
        }
        
        printf("\n") ;
        do{
            fgets(header, 1024, aFile->f) ;
            if (header[0] == '#'){
                printf("%s", header) ;
                if (isSubStringPresentInString(header, "Offset")){
                    sscanf(header + 8, "%lf", &offset) ;
                }
                if (isSubStringPresentInString(header, "Scale")){
                    sscanf(header + 7, "%lf", &scale) ;
                }            }
        } while (header[0] == '#');
        sscanf(header, "%d %d ", &dimXEGM, &dimYEGM) ;
        fgets(header, 1024, aFile->f) ;
        seekVal0 = aFile->fileLength - (dimXEGM * dimYEGM * 2) ;
    }
    else {
        dimXEGM = 1440 ;
        dimYEGM = 721 ;
    }
    
    /* Determine sampling of used EGM */
    EGMSampling = 360. / dimXEGM ;
    EGMSamplesPerDegree = dimXEGM / 360 ;

    /* Compute grid values */
    xDEMWidth = aoi->P[2].x - aoi->P[0].x ;
    yDEMWidth = aoi->P[2].y - aoi->P[0].y ;
    xDEMSampling = xDEMWidth / (xDimAoI - 1) ;
    yDEMSampling = yDEMWidth / (yDimAoI - 1) ;
    dNXGrid = (int)rint(EGMSampling / xDEMSampling) ;
    dNYGrid = (int)rint(EGMSampling / yDEMSampling) ;
    NXGrid = ceil(xDEMWidth / EGMSampling) + 1 ;
    NYGrid = ceil(yDEMWidth / EGMSampling) + 1 ;

    EGMLine = vectorShort(0, NXGrid - 1) ;

    printf("\nUsed EGM : %s \n\tdimXEGM = %d\t dimYEGM = %d\n", getPointerToFileNameInPath(EGMFilePath), dimXEGM, dimYEGM) ;
    printf("\nExternal DEM : \n\txDEMWidth = %3.0f\t yDEMWidth = %3.0f [deg]\n", xDEMWidth, yDEMWidth) ;
    printf("\txDEMSampling = %f\t yDEMSampling = %f\n", xDEMSampling, yDEMSampling) ;
    printf("\nEGM extracted grid : \n\txGridSize = %d\t yGridSize = %d\n\n", NXGrid, NYGrid) ;
    
    /* Create EGM grid with DEM grid laying on it */
    if (!(EGMHeight = createFloatGridOfSize(NXGrid, NYGrid, dNXGrid, dNYGrid))) {
        ase("Failed to allocate EGM96 grid") ; ;
    }

    /* Read EGM patch in mathematical order */
    for (iY = 0; iY < NYGrid ; iY++) {
        yIndex = (90 - (int)(aoi->P[0].y)) * EGMSamplesPerDegree - iY ;
        xIndex = (((360 + (int)aoi->P[0].x)) * EGMSamplesPerDegree) % dimXEGM ;

        seekVal = seekVal0 + 2 * (yIndex * dimXEGM + xIndex) ;
        fseek(aFile->f, seekVal, SEEK_SET) ;
        if ((NXGrid) != (int)fread(EGMLine, 2, NXGrid, aFile->f)) {
            ase("Failed to read EGM file\n") ;
        }
        
        for (iX = 0; iX < NXGrid; iX++) {
            if (!isArchBigEndian()){
                swapShort(EGMLine + iX) ;
            }
            if (!isPGMFile) {
                EGMHeight->floatVal[iX][iY] = (float)(EGMLine[iX]) ;
            }
            else {
                aUShort = EGMLine[iX] ;
                EGMHeight->floatVal[iX][iY] = (float)(aUShort) ;
            }
            EGMHeight->floatVal[iX][iY] = offset + scale * EGMHeight->floatVal[iX][iY] ;
        }
    }
    freeRawFileDescriptor(aFile) ;

    freeVectorShort(EGMLine, 0) ;
    free(EGMDirPath) ;

    return (EGMHeight) ;
}

/* returns a string with ID of used EGM */
char *addEGMToExistingDEM(keyValue *DEMHeader, char *requestedEGM)
{
    char *DEMFilePath, *EGMID ;
    int xDim, yDim ; 
    int iX, iY ;
    off_t seekVal ;
    float *aLine, floatVal ;
    double xSampling, ySampling ;
    quadrilateral *aoi ;
    gridMap *EGMHeight ;
    rawFileDescriptor *DEMFile ;
    keyValue *aKeyVal ;
    
    /* Read existing DEM header */
    if ((aKeyVal = isKeyValPresent(DEMHeader, "Height type"))) {
        printf("\t---> DEM apparently already corrected :\n") ;
        printf(" DEM description is mentionning %s\n", aKeyVal->stringVal) ;
        exit(0) ;
    }
    
    DEMFilePath = initStringWithString(getStringValForKeyIn(DEMHeader, "Georeferenced DEM file path")) ;
    printf("\t---> Managing existing external DEM at path:\n\t%s\n\n", DEMFilePath) ;
    printf("\t---> Converting ellipsoidal heights in geoidal ones\n") ;

    if (!requestedEGM) {
        if ((isSubStringPresentInString(DEMHeader->stringVal, "SRTM DEM"))) {
            EGMID = initStringWithString("EGM96") ;
            printf("\t---> Dealing with an SRTM DEM. EGM96 will be considered\n") ;
        }
        if ((isSubStringPresentInString(DEMHeader->stringVal, "COPERNICUS DEM"))) {
            EGMID = initStringWithString("EGM2008") ;
            printf("\t---> Dealing with a COPERNICUS DEM. EGM2008 will be considered\n") ;
        }
        if (!EGMID) {
            ase("\t-/-> Input file is not a COPERNICUS nor a SRTM DEM. \n\n") ;
        }
    }
    else {
        EGMID = initStringWithString(requestedEGM) ;
        printf("\t---> Earth Geoidal Model requested for correction : %s\n", EGMID) ;
    }
    
    xDim = getIntValForKeyIn(DEMHeader, "X") ;
    yDim = getIntValForKeyIn(DEMHeader, "Y") ;
    aoi = allocQuadrilateral() ;
    aoi->P[0].x = aoi->P[3].x = getDoubleValForKeyIn(DEMHeader, "Lower left corner longitude") ;
    aoi->P[0].y = aoi->P[1].y = getDoubleValForKeyIn(DEMHeader, "Lower left corner latitude") ;

    xSampling = getDoubleValForKeyIn(DEMHeader, "Longitude sampling") ;
    if (xSampling <= 0) {
        ase("\t-/-> Longitude sampling of you DEM is negative. Please check.\n") ;
        ase("\t-/-> If required, flip your DEM and give a positive sampling\n") ;
    }
    ySampling = getDoubleValForKeyIn(DEMHeader, "Latitude sampling") ;
    if (ySampling <= 0) {
        ase("\t-/-> Latitude sampling of you DEM is negative. Please check.\n") ;
        ase("\t-/-> If required, flip your DEM and give a positive sampling\n") ;
    }
    
    aoi->P[1].x = aoi->P[2].x = aoi->P[0].x + (xDim - 1) * xSampling ;
    aoi->P[3].y = aoi->P[2].y = aoi->P[0].y + (yDim - 1) * ySampling ;

    /* Read EGM grid */
    printf("\t---> Reading EGM area corresponding to DEM\n") ;
    EGMHeight = getEGMGrid(aoi, xDim,  yDim, EGMID) ;
    if (!EGMHeight) {
        ase("\t-/-> Failed to read Eart Gravity Model EGM\n") ;
    }
    freePolygon(aoi) ;

    /* Manage existing DEM file */
    aLine = vectorFloat(0, xDim - 1) ;
    DEMFile = openRawFileForReadingAndWritingAtPath(DEMFilePath) ;
    if (!DEMFile) {
        ase("\t-/-> Failed to open existing DEM file\n") ;
    }
    
    free(DEMFilePath) ;

    /* Convert geoidal heights to ellipsoidal ones */
    seekVal = 0 ;
//    for (iY = yDim - 1; iY >= 0; iY--) {
    for (iY = 0; iY < yDim; iY++) {
        if(fseek(DEMFile->f, seekVal, SEEK_SET)) {
            ase("Failed to seek into external DEM file") ;
        }
        if (xDim != (int)fread(aLine, sizeof(float), xDim, DEMFile->f)) {
            ase("\t-/-> Failed to read line in external DEM file") ;
        }
        
        for (iX = 0; iX < xDim; iX++) {
            floatVal = weightedExtrapolationOfGridForImageCoordinate(EGMHeight, iX, iY) ;
            aLine[iX] += floatVal ;
//            aLine[iX] = floatVal ;
        }
        
        if(fseek(DEMFile->f, seekVal, SEEK_SET)) {
            ase("Failed to seek into external DEM file") ;
        }
        if(xDim != (int)fwrite(aLine, sizeof(float), xDim, DEMFile->f)) {
//        if(xDim != (int)fwrite(aLine, sizeof(float), xDim, EGM->f)) {
            ase("Failed to write into External DEM file") ;
        }
        seekVal += xDim * sizeof(float) ;
    }

    freeRawFileDescriptor(DEMFile) ;
    freeGridMap(EGMHeight) ;
    freeVectorFloat(aLine, 0) ;

    return (EGMID) ;
}