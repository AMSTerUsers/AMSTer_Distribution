
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  georef.c
 *  georef
 *
 *  Created by Dominique Derauw on Thu Feb 21 2002.
 *  Copyright (c) 2001 Dominique Derauw All rights reserved.
 *
 */

#include "geoRef.h"

/* geoRef structure allocation */
geoRef *allocGeoRef()
{
	geoRef *p ;
	
	if((p = malloc(sizeof(geoRef))) == NULL) {
		ase("Failed to allocate geoRef structure") ;
	}
	
	if((p->params = malloc(sizeof(geoRefPar))) == NULL) {
		ase("Failed to allocate geoRef structure") ;
	}
    if((p->params->ellRef = malloc(sizeof(ellipsoid))) == NULL) {
        perror("Failed to allocate reference ellipsoid in geoRef Structure") ;
        exit(-1) ;
    }
    if((p->params->ellProj = malloc(sizeof(ellipsoid))) == NULL) {
        perror("Failed to allocate projection ellipsoid in geoRef Structure") ;
        exit(-1) ;
    }
	
	if((p->files = malloc(sizeof(geoRefFiles))) == NULL) {
		ase("Failed to allocate geoRef structure") ;
	}
    p->files->input = NULL ;
    p->files->xRef = NULL ;
    p->files->yRef = NULL ;
    p->files->xRadius = NULL ;
    p->files->yRadius = NULL ;
    p->files->DEM = NULL ;
    p->files->mask = NULL ;
	
	if((p->frame = malloc(sizeof(geoRefFrame))) == NULL) {
		ase("Failed to allocate geoRef structure") ;
	}
	p->frame->xMin = p->frame->xMax = p->frame->yMin = p->frame->yMax = 0. ;
	
	p->solving = allocGeoRefSolvingStructure() ;
    p->params->UTMZone = NULL ;
    p->params->atDopplerZero = 1 ;
    	
	return(p) ;
}

/* Allocation of a structure containing all required constants and variable for georeferencing */
geoRefSolving *allocGeoRefSolvingStructure()
{
    geoRefSolving	*p ;
    
    if((p = (geoRefSolving *)malloc(sizeof(geoRefSolving))) == NULL)
        ase("Failed to allocate geoRefSolving structure\n") ;
    
    p->eq1 = vectorDouble(0, 4) ;
    p->eq2 = vectorDouble(0, 3) ;
    p->M = matrixDouble(0, 1, 0, 1) ;
    p->V = vectorDouble(0, 1) ;
    p->Vc = vectorDouble(0, 1) ;
    p->Vl = vectorDouble(0, 1) ;
    p->C2 = vectorDouble(0, 2) ;
    p->C4 = vectorDouble(0, 4) ;
    p->S = (struct stateVect *)malloc(sizeof(struct stateVect)) ;
    p->S->P = vectorDouble(0, 2) ;
    p->S->V = vectorDouble(0, 2) ;
	p->S->azimuthPosition = -1 ;  /* This ensure that state vector position will be computed and that onSphereSolving will be initialize when caling any georeferencing function for the first time */
    p->sol1 = vectorDouble(0, 2) ;
    p->sol2 = vectorDouble(0, 2) ;
    p->V3 = vectorDouble(0, 2) ;
    p->Pg = vectorDouble(0, 2) ;
    p->rangePosition = -1. ;
    if ((p->ellProj = malloc(sizeof(ellipsoid))) == NULL) {
        ase("Failed to allocate projection ellipsoid in geoRefSolving Structure\n") ;
    }
	
    return p ;
}


void freeGeoRef(geoRef *p)
{
    if (p != NULL) {
        if(p->params != NULL) {
            //		if(p->params->info != NULL) freeInfoImage(p->params->info) ;
            if((p->params->ellProj != NULL)) {
                if (p->params->ellProj != p->params->ellRef) {
                    free(p->params->ellProj) ;
                    p->params->ellProj = NULL ;
                }
            }
            if (p->params->ellRef != NULL) {
                free(p->params->ellRef) ;
                p->params->ellRef = NULL ;
            }
            if (p->params->DEMGrid != NULL) {
                freeGridMap(p->params->DEMGrid) ;
            }
            if (p->params->UTMZone) {
                freeUTMZone(p->params->UTMZone) ;
                p->params->UTMZone = NULL ;
            }
            free(p->params) ;
            p->params = NULL ;
        }
        
        if(p->files != NULL) {
            if(p->files->input != NULL) {
                freeRawFileDescriptor(p->files->input) ;
                p->files->input = NULL ;
            }
            if(p->files->DEM != NULL) {
                freeRawFileDescriptor(p->files->DEM) ;
                p->files->DEM = NULL ;
            }
            if(p->files->xRef != NULL) {
                freeRawFileDescriptor(p->files->xRef) ;
                p->files->xRef = NULL ;
            }
            if(p->files->yRef != NULL) {
                freeRawFileDescriptor(p->files->yRef) ;
                p->files->yRef = NULL ;
            }
            if(p->files->xRadius != NULL) {
                freeRawFileDescriptor(p->files->xRadius) ;
                p->files->xRadius = NULL ;
            }
            if(p->files->yRadius != NULL) {
                freeRawFileDescriptor(p->files->yRadius) ;
                p->files->yRadius = NULL ;
            }
            if(p->files->mask != NULL) {
                freeRawFileDescriptor(p->files->mask) ;
                p->files->mask = NULL ;
            }
            
            free(p->files) ;
            p->files = NULL ;
        }
        
        if(p->solving != NULL) {
            freeGeoRefSolvingStructure(p->solving) ;
            free(p->solving) ;
            p->solving = NULL ;
        }
        
        if(p->frame != NULL) {
            free(p->frame) ;
            p->frame = NULL ;
        }
        
        free(p) ;
    }
}

geoRef *allocAndInitGeorefStructureForTargetEllipsoid(struct infoImage *info, ellipsoid *ellProj)
{
	geoRef *p ;
	
	p = allocGeoRef() ;
	p->params->info = info ;
    memcpy(p->params->ellRef, info->ellRef, sizeof(ellipsoid)) ;
    memcpy(p->params->ellProj, ellProj, sizeof(ellipsoid)) ;
	p->files->input = p->files->DEM = p->files->xRef = p->files->yRef = NULL ;
    initGeoRefSolvingOnEllipsoid(p->solving, ellProj) ;
    p->solving->lookDirection = info->lookDirection ;
    
    /* We initialize parameters with values found in the SLCInfo structure */
    p->params->xDimInputData = info->rangeDimension ;
    p->params->yDimInputData = info->azimuthDimension ;
    p->params->x0 = p->params->y0 = 0 ;
    p->params->xMaxSampling = p->params->yMaxSampling = 0 ;
    p->params->xAverageSampling = p->params->yAverageSampling = 0 ;
    p->params->xReductionFactor = p->params->yReductionFactor = 1. ;
    p->params->xSampling = info->rangeResolutionCell ;
    p->params->ySampling = info->azimuthResolutionCell ;
    p->params->holeFillingFactor = _DEFAULT_HOLE_FILLING_FACTOR_ ;
    
    /* Frame initialization */
    p->frame->xMin = p->frame->yMin = 0. ;
    p->frame->xMax = info->rangeDimension - 1 ;
    p->frame->yMax = info->azimuthDimension - 1 ;
    
    p->params->UTMZone = NULL ;
    p->params->DEMGrid = NULL ; /* DEM grid initialized to NULL */
	
	return(p) ;
}


/* Libération d'une structure geoRefSolving */
void freeGeoRefSolvingStructure(geoRefSolving *p)
{    
    freeVectorDouble(p->eq1, 0) ;
    freeVectorDouble(p->eq2, 0) ;
    freeMatrixDouble(p->M, 0, 0) ;
    freeVectorDouble(p->V, 0) ;
    freeVectorDouble(p->Vc, 0) ;
    freeVectorDouble(p->Vl, 0) ;
    freeVectorDouble(p->C2, 0) ;
    freeVectorDouble(p->C4, 0) ;
    freeVectorDouble(p->S->P, 0) ;
    freeVectorDouble(p->S->V, 0) ;
    free(p->S) ;
    freeVectorDouble(p->sol1, 0) ;
    freeVectorDouble(p->sol2, 0) ;
    freeVectorDouble(p->V3, 0) ;
    freeVectorDouble(p->Pg, 0) ;
    free(p->ellProj) ;
}


void initGeoRefSolvingOnEllipsoid(geoRefSolving *p, ellipsoid *ellProj) 
{
    double		baRatio ;
    
/* Ellipsoid and constants definitions */
    memcpy(p->ellProj, ellProj, sizeof(ellipsoid)) ;
    baRatio = ellProj->b / ellProj->a ;
    p->b2a2Ratio = pow(baRatio, 2.) ;
    p->a2b2Ratio = 1. / p->b2a2Ratio ;
    p->ellProj->f_1 = 1. / (1. - baRatio) ;
    p->ellProj->e2 = 1. - p->b2a2Ratio ;
    p->ellProj->ep2 = p->a2b2Ratio - 1. ;
    p->a4b4Ratio = pow(p->a2b2Ratio, 2.) ;
    p->b4a4Ratio = pow(p->b2a2Ratio, 2.) ;
    p->a2 = pow(p->ellProj->a, 2.) ;
    p->b2 = pow(p->ellProj->b, 2.) ;
    p->e4 = pow(p->ellProj->e2, 2.) ;
    p->R = .9996 * p->ellProj->a ;				/* Cylinder radius sequent to Earth for TM referencing */
    p->R2 = pow(p->R, 2.) ;
    p->w = 2. * PI / 86164.094702 ;
}


geoRefSolving *allocAndInitGeorefSolvingOnEllipsoid(ellipsoid *ellProj)
{
	geoRefSolving *geo ;
	
	geo = allocGeoRefSolvingStructure() ;
	initGeoRefSolvingOnEllipsoid(geo, ellProj) ;
	
	return(geo) ;
}


/* Initialization of an equations system corresponding to the intersection of two planes and a sphere */
void	initOnSphereSolving(geoRefSolving *p)
{
    eqDopplerCentroid(p->eq1, p) ;

    p->M[0][0] = p->eq1[1] ;
    p->M[0][1] = p->eq1[2] ;
    p->M[1][0] = p->eq2[1] = p->S->P[1] ;
    p->M[1][1] = p->eq2[2] = p->S->P[2] ;
    inversionMatrice2X2(p->M) ;                 // M contient alors la matrice inverse
    p->V[0] = - p->eq1[0] ;
    p->V[1] = p->eq2[0] = - p->S->P[0] ;
    multMatVect2X2(p->Vl, p->M, p->V) ;
}

/* Projection orthogonale d'un point *Ps sur un ellipsoïde */
void	onEllipsoidProjection(double *sol, double *Ps, geoRefSolving *p)
{
    double	xp2, xp2plusyp2, zp2, x0, xn ;
//    double Pg[3] ;
//    double normalToEllipsoid[3] ;

    xp2 = pow(Ps[0], 2.) ;
    xp2plusyp2 = xp2 + pow(Ps[1], 2.) ;
    zp2 = pow(Ps[2], 2.) ;
    p->C4[0] = - p->a2 * pow(Ps[0], 4.) ;
    p->C4[1] = 2. * p->a2 * p->ellProj->e2 * pow(Ps[0], 3.) ;
    p->C4[2] = xp2 * (xp2plusyp2 + p->b2a2Ratio * zp2 - p->a2 * p->e4) ;
    p->C4[3] = -2. * p->ellProj->e2 * Ps[0] * xp2plusyp2 ;
    p->C4[4] = p->e4 * xp2plusyp2 ;
    x0 = Ps[0] / sqrt(xp2plusyp2 / p->a2 + zp2 / p->b2) ;
    xn = Newton(p->C4, x0, 4, .001) ;                                                                       // Calcul de la racine du polynome
    sol[1] = Ps[1] / Ps[0] * xn ;                                                                   // à partir de l'estimation de x, on peut déterminer y et z.
    sol[2] = Ps[2] * p->b2a2Ratio * xn / (Ps[0] - xn * p->ellProj->e2) ;
	sol[0] = xn ;
/*
    Pg[0] = sol[0] ;
    Pg[1] = sol[1] ;
    Pg[2] = sol[2] ;
    normalToEllipsoid[0] = 2. * Pg[0] / p->a2 ;
    normalToEllipsoid[1] = 2. * Pg[1] / p->a2 ;
    normalToEllipsoid[2] = 2. * Pg[2] / p->b2 ;
    normalizeVector(normalToEllipsoid) ;
    normalizeVector(Pg) ;
    
    p->geodeticAngleCosine = scalarProduct(Pg, normalToEllipsoid) ;
*/
}


/* Calcul de la position d'un point intersection d'un plan et de deux sphères */
/* Le premier plan est défini par l'équation du Doppler Centroïde */
/* La première sphère est centrée sur la position du satellite et de rayon égale au range */
/* La seconde sphère est centrée sur le centre de l'ellipsoïde de projection et de rayon égale au rayon terrestre local augmenté de l'altitude du point */
/* x et r sont les coordonnées azimut et range du point de consideré dans l'image SAR. Ils sont donnés en pixel */
/* Alpha - at est l'angle d'élévation sous lequel est observé le point consideré */
double	*onSphereSolvingForPoint(double rangePosition, double azimuthPosition, double h, geoRef *gR)
{   
    double	K = 0, *sol, R, solutionSelector ;
	geoRefSolving *p ;
	struct infoImage *ima ;
    
	if(azimuthPosition != gR->solving->S->azimuthPosition) {
		calcStateVect(gR->solving->S, azimuthPosition, gR->params->info) ;
		initOnSphereSolving(gR->solving) ;
	}
	
	p = gR->solving ;
	ima = gR->params->info ;
	R = p->Rt + h ;
    p->solSelector = 0 ;
	
	
//#if !defined(FOCALISATION_AU_DOPPLER_ZERO)
    if (!gR->params->atDopplerZero) {
        K = DCEquationConstantTerm(gR->params->info, rangePosition) ;
    }
//#endif
    p->eq1[3] = -K + p->eq1[4] ;
    p->eq2[3] = (scalarProduct(p->S->P, p->S->P) + pow(R, 2.) - pow(ima->slantRange[0] + rangePosition * ima->rangeResolutionCell, 2.)) / 2. ;
    
    p->V[0] = p->eq1[3] ;
    p->V[1] = p->eq2[3] ;
    multMatVect2X2(p->Vc, p->M, p->V) ;

    p->C2[0] = pow(p->Vc[0], 2.) + pow(p->Vc[1], 2.) - pow(R, 2.) ;
    p->C2[1] = 2. * (p->Vl[0] * p->Vc[0] + p->Vl[1] * p->Vc[1]) ;
    p->C2[2] = 1. + pow(p->Vl[0], 2.) + pow(p->Vl[1], 2.) ;
    secondOrderEquationSolving(p->V, p->C2) ;
    if (errno) {
        sol = NULL ;
    }
    else {
        p->sol1[0] = p->V[0] ;
        p->sol2[0] = p->V[1] ;
        p->sol1[1] = p->Vl[0] * p->sol1[0] + p->Vc[0] ;
        p->sol2[1] = p->Vl[0] * p->sol2[0] + p->Vc[0] ;
        p->sol1[2] = p->Vl[1] * p->sol1[0] + p->Vc[1] ;
        p->sol2[2] = p->Vl[1] * p->sol2[0] + p->Vc[1] ;
        
        vectorialProduct(p->V3, p->S->P, p->sol1) ;
        solutionSelector = p->lookDirection * scalarProduct(p->S->V, p->V3) ;
        if(solutionSelector > 0) {
            sol = p->sol1 ;
            p->solSelector = 1 ;
        }
        else
            sol = p->sol2 ;

	}
	return(sol) ;
}

/* Generation of coefficients of the Doppler Centroid plane */
/* We calculate here only the linear coefficients and the fixed part of the constant coefficient */
/* The variable part of the constant term will be update when required */
void	eqDopplerCentroid(double *eq1, geoRefSolving *p)
{

#ifdef REFERENTIEL_TOURNANT
    eq1[0] = p->S->V[0] ;               // V = vecteur vitesse du satellite
    eq1[1] = p->S->V[1] ;               // P = vecteur position du satellite
    eq1[2] = p->S->V[2] ;
#else
    eq1[0] = p->S->V[0] + p->w * p->S->P[1] ;       // w = vitesse angulaire d'un point sur le géoide
    eq1[1] = p->S->V[1] - p->w * p->S->P[0] ;
    eq1[2] = p->S->V[2] ;
#endif

//    eq1[3] = eq1[4] = p->S->V[0] * p->S->P[0] + p->S->V[1] * p->S->P[1] + p->S->V[2] * p->S->P[2] ;
    eq1[3] = eq1[4] = scalarProduct(eq1, p->S->P) ;
}


double	DCEquationConstantTerm(struct infoImage *ima, double rangePosition)
{
    double	K, tr ;
	
    tr = 2. * rangePosition * ima->rangeResolutionCell /c0 ;
	K = ima->fdc[0] + tr * ima->fdc[1] ;

    tr  = rangePosition * ima->rangeResolutionCell + ima->slantRange[0] ; 
    K *= - c0 / 2. / ima->radarCarrierFrequency * tr ;

    return K ;
}



/* Conversion en longitude et latitude de la position cartésienne d'un point sur un ellipsoïde */
void	XYZ2LonLat(double *lon, double *lat, double *Pg, geoRefSolving *p)
{
	double	a, b ;
    
    a = Pg[0] ;
    b = Pg[1] ;
	if(a!=0) {
		*lon = atan(b/a) ;
		if(a<0) {
			if(b>0)	*lon += (double)PI ;
			else	*lon -= (double)PI ;
		}
	}
	else {
		if(b>0) *lon =  (double)HALFPI ;
		else 	*lon = -(double)HALFPI ;
	}
	
    a = sqrt(pow(Pg[0], 2.) + pow(Pg[1], 2.)) ;
    b = p->a2b2Ratio * Pg[2] ;
    *lat = atan(b/a) ;                                                                                      // asin ??
}


void	lonLatH2XYZ(double *lonLatH, double *xyz, ellipsoid *aGeoid)
{
    double	nu ;
    
    nu = aGeoid->a / sqrt(1. - aGeoid->e2 * pow(sin(lonLatH[1]), 2.)) ;
    xyz[0] = (nu + lonLatH[2]) * cos(lonLatH[1]) ;
    xyz[1] = xyz[0] * sin(lonLatH[0]) ;
    xyz[0] *= cos(lonLatH[0]) ;
    xyz[2] = (nu * (1. - aGeoid->e2) + lonLatH[2]) * sin(lonLatH[1]) ;
}


void	XYZ2LonLatH(double *xyz, double *lonLatH, geoRefSolving *p)
{
	double	*Pg, s ;
	
	Pg = vectorDouble(0, 2) ;
	onEllipsoidProjection(Pg, xyz, p) ;
	XYZ2LonLat(&lonLatH[0], &lonLatH[1], Pg, p) ;
	s = (vectorNorm(Pg) > vectorNorm(xyz))? -1. : 1 ;
	vectorDiffInPlace(Pg, xyz) ;
	lonLatH[2] = s * vectorNorm(Pg) ;
		
	freeVectorDouble(Pg, 0) ;
}

/* Earth radius calculation at point (azimuthPosition ; rangePosition ; H) */
/* H is the geocentric height */
/* Earth angle at and on ellipsoid projection Pg are also saved into the solving structure */
double	earthRadiusAtPoint(double rangePosition, double azimuthPosition, double H, geoRef *gR)
{
	int i ;
    double 		satDistance, *sol, *Pg, delta ;
	geoRefSolving *p ;
    
	p = gR->solving ;
	Pg = vectorDouble(0, 2) ;
    
	if(azimuthPosition != gR->solving->S->azimuthPosition) {
		calcStateVect(p->S, (double)azimuthPosition, gR->params->info) ;
		initOnSphereSolving(p) ;
	}
    satDistance = p->S->satDistance ;
    
    gR->solving->Rt = gR->params->info->EarthRadiusAtSceneCenter ;    
	if((sol = onSphereSolvingForPoint(rangePosition, azimuthPosition, H, gR)) == NULL)
        return(0) ;
	onEllipsoidProjection(p->Pg, sol, p) ;
	gR->solving->Rt = vectorNorm(p->Pg) ;
    do {
		for(i = 0; i < 3; i++) {
            Pg[i] = p->Pg[i] ;
        }
        if((sol = onSphereSolvingForPoint(rangePosition, azimuthPosition, H, gR)) == NULL)
            return(0) ;
            /* Absence of solution may occure if H is zero or lower than the real value. Mainly in case of airborn systems */
        onEllipsoidProjection(p->Pg, sol, p) ;
        gR->solving->Rt = vectorNorm(p->Pg) ;
        vectorDiffInPlace(Pg, p->Pg) ;
        delta = vectorNorm(Pg) ;
    } while(delta > 0.1) ; /* We request a localization of the point on the geoid with a metric precision, wich leads to a centimetric precision on the Earth radius */
    
    gR->solving->at = acos(scalarProduct(p->Pg, p->S->P) / satDistance / sqrt(scalarProduct(p->Pg, p->Pg))) ;
    gR->solving->alpha = localIncidenceAngle(p->S->P, sol) ;
	gR->solving->alpha_at = localElevationAngle(p->S->P, sol) ;
    /* As such, the elevation angle is computed as positive */
    /* We will sign it with respect to the look direction */
        gR->solving->alpha_at *= gR->solving->lookDirection ;
    
	freeVectorDouble(Pg, 0) ;
    
	return(gR->solving->Rt) ;
}

float localRange(double *PSat, double *Pg)
{
	return(sqrt(pow(PSat[0] - Pg[0], 2.) + pow(PSat[1] - Pg[1], 2.) + pow(PSat[2] - Pg[2], 2.))) ;
}

double	localIncidenceAngleAtPoint(double rangePosition, double azimuthPosition, double H, geoRef *gR)
{
    double	*sol, incidenceAngle ;
	geoRefSolving *p ;
    
	p = gR->solving ;
    gR->solving->Rt = gR->params->info->EarthRadiusAtSceneCenter ;
	if(azimuthPosition != gR->solving->S->azimuthPosition) {
		calcStateVect(p->S, (double)azimuthPosition, gR->params->info) ;
		initOnSphereSolving(p) ;
	}
	sol = onSphereSolvingForPoint(rangePosition, azimuthPosition, H, gR) ;
	onEllipsoidProjection(p->Pg, sol, p) ;
    
	incidenceAngle = localIncidenceAngle(p->S->P, p->Pg) ;
	
	return(incidenceAngle) ;
}

double localIncidenceAngle(double *PSat, double *Pg)
{
	int i ;
	double *range, alpha ;
	
	range = vectorDouble(0, 2) ;
	for(i = 0; i < 3; i++) {
        range[i] = PSat[i] - Pg[i] ;
    }
	alpha = acos(scalarProduct(range, Pg) / vectorNorm(range) / vectorNorm(Pg)) ;
	
	freeVectorDouble(range, 0) ;
	return(alpha) ;
}

double localElevationAngle(double *PSat, double *Pg)
{
	int i ;
	double *range, alpha ;
	
	range = vectorDouble(0, 2) ;
	for(i = 0; i < 3; i++) {
        range[i] = PSat[i] - Pg[i] ;
    }
	alpha = acos(scalarProduct(range, PSat) / vectorNorm(range) / vectorNorm(PSat)) ;
	
	freeVectorDouble(range, 0) ;
	return(alpha) ;
}

double localHeadingAngle(double *Vd, double *Pg)
{
    /* Vd is the direction vector of the reference plane with respect to which is computed the heading (in our case, the Doppler plane) */
    /* Pg is the on ground point for which the meridian plane direction vector Vm will be computed */
    
    double heading ;
    double *Vm ;
    
    /* We compute the meridian plane corresponding to the given point */
    Vm = vectorDouble(0, 2) ;
    Vm[0] = -Pg[1] ;
    Vm[1] = Pg[0] ;
    
    heading = acos(scalarProduct(Vd, Vm) / vectorNorm(Vd) / vectorNorm(Vm)) ;
    
    freeVectorDouble(Vm, 0) ;
    
    return (heading) ;
}

/* inversion d'une matrice 2X2 */
void	inversionMatrice2X2(double **M)
{
    double	norme, tempDouble ;
    
    norme = 1. / (M[0][0] * M[1][1] - M[1][0] * M[0][1]) ;
    tempDouble = M[1][1] ;
    M[1][1] = M[0][0] * norme ;
    M[0][0] = tempDouble * norme ;
    M[1][0] *= -norme ;
    M[0][1] *= -norme ;
}


/* Multiplication d'un vecteur 2X1 par une matrice 2X2 */
void	multMatVect2X2(double *V2, double **M, double *V1)
{
    V2[0] = M[0][0] * V1[0] + M[0][1] * V1[1] ;
    V2[1] = M[1][0] * V1[0] + M[1][1] * V1[1] ;
}


/* résolution d'une équation du second degré */
/* *coef est un vecteur contenant les coefficients u polynome */
/* la solution est stockée dans le vecteur pointé par *sol */
void	secondOrderEquationSolving(double *sol, double *coef)
{
    double	determinant ;
    
    errno = 0 ;
    
    if((determinant = pow(coef[1], 2.) - 4. * coef[0] * coef[2]) < 0) {
        errno = 1 ;
        return ;
    }
    determinant = sqrt(determinant) ;
    sol[0] = (-coef[1] + determinant) / (2. * coef[2]) ;
    sol[1] = (-coef[1] - determinant) / (2. * coef[2]) ;
}

/* Calcul itératif d'une racine d'une équation polynome d'ordre N par la méthode de Newton */
/* *a = Coefficients du polynome */
/* x0 = terme initial de l'itération */
/* précision demandée */
double	Newton(double *a, double x0, int N, double precision)
{
    int	i ;
    double	x, denominateur, numerateur, diff, diff1, diff2, td1 ;
    
    diff = precision + 1 ;
	/* First iteration */
	numerateur = a[0] + a[1] * x0 + a[N] * pow(x0, (double)N) ;
	denominateur = a[1] + a[2] * x0 ;
	for(i = 2; i < N; i++) {
		td1 = pow(x0, (double)(i)) ;
		numerateur   += a[i] * td1 ;
		denominateur += a[i + 1] * td1 ;
	}
	x = x0 - numerateur / denominateur ;
	diff1 = x - x0 ;
	diff = fabs(diff) ;
	x0 = x ;
	
    while(precision < diff) {
        numerateur = a[0] + a[1] * x0 + a[N] * pow(x0, (double)N) ;
        denominateur = a[1] + a[2] * x0 ;
        for(i = 2; i < N; i++) {
            td1 = pow(x0, (double)(i)) ;
            numerateur   += a[i] * td1 ;
            denominateur += a[i + 1] * td1 ;
        }
        x = x0 - numerateur / denominateur ;
		
		diff2 = x - x0 ;
		if(diff1 * diff2 < 0.)
			x = x0 + diff2 / 2. ;
			
        diff = fabs(x - x0) ;
		diff1 = diff2 ;
        x0 = x ;
    }
    return x0 ;                                                                                                     // x0 contient l'estimation de la racine recherchée
}


 void geolocateSceneOnEllipsoid(struct infoImage *info, ellipsoid *ellProj)                                         // Géoréférencement d'une scène sur un ellipsoide => On situe les quatre coins de la scène sur l'ellipsoide et on recherche les coordonnées latitude-longitude
 {
	double *xyz, *llh, *sol, headingVal ;
    double range, azimuth ;
    point2D *aPoint ;
	geoRef	*geo ;
	UTMZoneStruct *UTMZone ;
 
    orbitInterpolation(info) ;                                                                                     // Interpolation de l'orbite de l'image
    geo = allocAndInitGeorefStructureForTargetEllipsoid(info, ellProj) ;
    UTMZone = geo->params->UTMZone = initUTMReferencingOnEllipsoid(ellProj) ;
    
    llh = vectorDouble(0, 2) ;
    sol = vectorDouble(0, 2) ;
    aPoint = (point2D *)llh ;

    info->EarthRadiusAtSceneCenter = earthRadiusAtPoint(info->rangeDimension / 2., info->azimuthDimension / 2., info->sceneAverageHeight, geo) ;                   // On calcule le rayon terrestre au centre de la scène, càd à rangeDimension/2 et azimutDimension/2
    
    /* Tant qu'on y est, on calcule aussi la valeur du heading */
    /* We initialize the direction vector of the plane passing by the central point of the scene and the North pole */
    range = info->rangeDimension / 2. ;
    azimuth = info->azimuthDimension / 2. ;
    xyz = onSphereSolvingForPoint(range, azimuth, info->sceneAverageHeight, geo)  ;
    onEllipsoidProjection(sol, xyz, geo->solving) ;
    llh[0] = -sol[1] ;
    llh[1] = sol[0] ;
    llh[2] = info->sceneAverageHeight ;
    headingVal = 180 / PI * acos(scalarProduct(llh, geo->solving->eq1) / vectorNorm(geo->solving->eq1) / vectorNorm(llh)) ;
    
    /* Compute UTM zone for central point */
    XYZ2LonLatH(sol, llh, geo->solving) ;                                                                          // Conversion des coordonnées cartésiennes vers coordonnées longitude-latitude
    UTMZoneForLonLatPoint(aPoint, geo->params->UTMZone) ;
    sprintf(info->UTMZone, "%2d%s", geo->params->UTMZone->indiceZoneLonUTM, geo->params->UTMZone->zoneLatUTM) ;
    
    range = 0.0 ;
    azimuth = 0.0 ;
    geo->solving->Rt = earthRadiusAtPoint(range, azimuth, info->sceneAverageHeight, geo) ;                               // Calcul du rayon terrestre au point (0,0)
    xyz = onSphereSolvingForPoint(range, azimuth, info->sceneAverageHeight, geo)  ;                                        // Détermination de la position du point range = 0, azimut = 0 sur une sphère ?
    onEllipsoidProjection(sol, xyz, geo->solving) ;                                                                // Projection de xyz sur l'ellipsoide
    XYZ2LonLatH(sol, llh, geo->solving) ;                                                                          // Conversion des coordonnées cartésiennes vers coordonnées longitude-latitude
    info->loc->P[0].x = llh[0] ;                                                                                   // Enregistrement des coordonnées latitude-longitude du point 0
    info->loc->P[0].y = llh[1] ;
    lonLat2UTMOnEllipsoid(llh, llh + 1, UTMZone) ;
    info->locUTM->P[0].x = llh[0] ;                                                                                   // Enregistrement des coordonnées latitude-longitude du point 0
    info->locUTM->P[0].y = llh[1] ;
    
    range = 0.0 ;
    azimuth = (double)info->azimuthDimension ;
    geo->solving->Rt = earthRadiusAtPoint(range, azimuth, info->sceneAverageHeight, geo) ;                               // Calcul du rayon terrestre au point (0,maxAz)
    xyz = onSphereSolvingForPoint(range, azimuth, info->sceneAverageHeight, geo)  ;                                        // Détermination de la position du point range = 0, azimut = 0 sur une sphère ?
    onEllipsoidProjection(sol, xyz, geo->solving) ;                                                                // Projection de ce point sur l'ellipsoide
    XYZ2LonLatH(sol, llh, geo->solving) ;                                                                          // Conversion des coordonnées cartésiennes en coordonnées longitude-latitude
    info->loc->P[3].x = llh[0] ;                                                                                   // Enregistrement des coordonnées latitude-longitude du point 2
    info->loc->P[3].y = llh[1] ;
    lonLat2UTMOnEllipsoid(llh, llh + 1, UTMZone) ;
    info->locUTM->P[3].x = llh[0] ;                                                                                   // Enregistrement des coordonnées latitude-longitude du point 0
    info->locUTM->P[3].y = llh[1] ;
    
    range = (double)info->rangeDimension ;
    azimuth = 0.0 ;
    geo->solving->Rt = earthRadiusAtPoint(range, azimuth, info->sceneAverageHeight, geo) ;                               // Calcul du rayon terrestre au point (maxRange,0)
    xyz = onSphereSolvingForPoint(range, azimuth, info->sceneAverageHeight, geo)  ;                                        // Détermination de la position du point range = 0, azimut = 0 sur une sphère ?
    onEllipsoidProjection(sol, xyz, geo->solving) ;                                                                // Projection de ce point sur l'ellipsoide
    XYZ2LonLatH(sol, llh, geo->solving) ;                                                                          // Conversion des coordonnées cartésiennes en coordonnées longitude-latitude
    info->loc->P[1].x = llh[0] ;                                                                                   // Enregistrement des coordonnées latitude-longitude du point 1
    info->loc->P[1].y = llh[1] ;
    lonLat2UTMOnEllipsoid(llh, llh + 1, UTMZone) ;
    info->locUTM->P[1].x = llh[0] ;                                                                                   // Enregistrement des coordonnées latitude-longitude du point 0
    info->locUTM->P[1].y = llh[1] ;
    
    range = (double)info->rangeDimension ;
    azimuth = (double)info->azimuthDimension ;
    geo->solving->Rt = earthRadiusAtPoint(range, azimuth, info->sceneAverageHeight, geo) ;                               // Calcul du rayon terrestre au point (maxRange, maxAz)
    xyz = onSphereSolvingForPoint(range, azimuth, info->sceneAverageHeight, geo)  ;                                        // Détermination de la position du point range = 0, azimut = 0 sur une sphère ?
    onEllipsoidProjection(sol, xyz, geo->solving) ;                                                                                            // Projection de ce point sur l'ellipsoide
    XYZ2LonLatH(sol, llh, geo->solving) ;                                                                                                      // Conversion des coordonnées cartésiennes en coordonnées longitude-latitude
    info->loc->P[2].x = llh[0] ;                                                                                                               // Enregistrement des coordonnées latitude-longitude du point 3
    info->loc->P[2].y= llh[1] ;
    lonLat2UTMOnEllipsoid(llh, llh + 1, UTMZone) ;
    info->locUTM->P[2].x = llh[0] ;                                                                                   // Enregistrement des coordonnées latitude-longitude du point 0
    info->locUTM->P[2].y = llh[1] ;
    
    info->incidenceAngle[0] = 180. / PI * localIncidenceAngleAtPoint(0.0, (double)info->azimuthDimension / 2., info->sceneAverageHeight, geo) ;                                // 180/PI conversion radians -> degrés. Calcul de l'angle d'incidence local au range = 0, et milieu de la scène en azimut
    info->incidenceAngle[1] = 180. / PI * localIncidenceAngleAtPoint((double)info->rangeDimension / 2., (double)info->azimuthDimension / 2., info->sceneAverageHeight, geo) ;  // Calcul de l'angle d'incidence au centre de la scène
    info->incidenceAngle[2] = 180. / PI * localIncidenceAngleAtPoint((double)info->rangeDimension, (double)info->azimuthDimension / 2., info->sceneAverageHeight, geo) ;       // Calcul de l'angle d'incidence local au range = rangeDimension, azimut = azimuthDimension/2
    
    if (info->heading) { 
        free(info->heading) ;   
    }
    if (info->loc->P[0].y < info->loc->P[3].y) {
        info->heading = initStringWithString("Ascending pass") ;
        info->headingVal = headingVal ;
    }
    else {
        info->heading = initStringWithString("Descending pass") ;
        info->headingVal = 360 - headingVal ;
    }

    freeVectorDouble(llh, 0) ;
    freeVectorDouble(sol, 0) ;
    freeGeoRef(geo) ;
 }
 
