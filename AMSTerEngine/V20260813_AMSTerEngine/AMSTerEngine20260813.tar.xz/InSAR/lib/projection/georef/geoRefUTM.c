
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  geoRefUTM.c
//  geoProjection
//
//  Created by Dominique Derauw on 12/07/16.
//
//

#include "geoRefUTM.h"

void UTMZoneForLonLatPoint(point2D *aPoint, UTMZoneStruct *UTMZone)
{
    char	zoneLatUTM[25] ;
    double	latitude, longitude ;
    
    sprintf(zoneLatUTM, "ABCDEFGHJKLMNPQRSTUVWXYZ") ;
    longitude = 180. / PI * aPoint->p.x ;
    latitude = 180. / PI * aPoint->p.y ;

    if (!UTMZone->indiceZoneLonUTM) {
        UTMZone->indiceZoneLonUTM = (int)floor((longitude + 180) / 6) + 1 ;
    }
    
    UTMZone->lambdaC = PI / 180. * (UTMZone->indiceZoneLonUTM * 6. - 183.) ;
    if(latitude > -80. && latitude < 72.) UTMZone->indiceZoneLatUTM = (int)(latitude + 80) / 8 + 2 ;
    else {
        if(latitude >= 72.) {
            if(latitude < 84.) UTMZone->indiceZoneLatUTM = 21 ;
            else {
                UTMZone->lambdaC = 0. ;
                UTMZone->indiceZoneLonUTM = 0 ;
                UTMZone->indiceZoneLatUTM = (longitude< 0)? 22 : 23 ;
            }
        }
        else {
            UTMZone->lambdaC = 0. ;
            UTMZone->indiceZoneLonUTM = 0 ;
            UTMZone->indiceZoneLatUTM = (longitude < 0)? 0 : 1 ;
        }
    }
    UTMZone->y0 = (UTMZone->indiceZoneLatUTM < 12)? 10000000. : 0. ;
    
    sprintf(UTMZone->zoneLatUTM, "%c", zoneLatUTM[UTMZone->indiceZoneLatUTM]) ; UTMZone->zoneLatUTM[1] = '\0' ;
}

/* Alloc UTMZoneStruct */
UTMZoneStruct *allocUTMZone()
{
    UTMZoneStruct *UTMZone ;
    
    if((UTMZone = calloc(1, sizeof(UTMZoneStruct))) ==NULL) {
        ase("Failed to allocate UTM referencing structure\n") ;
    }
    
    if((UTMZone->ellProj = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL) {
        ase("Failed to allocate projection ellipsoid pointer in UTM structure\n") ;
    }

    return(UTMZone) ;
}

/* Free UTMZoneStruct */
void freeUTMZone(UTMZoneStruct *UTMZone)
{
    free(UTMZone->ellProj) ;
    free(UTMZone) ;
}


/* initialisation des paramètres nécessaires au calcul de la projection UTM */
UTMZoneStruct *initUTMReferencingOnEllipsoid(ellipsoid *ellProj)
{
    double	ep2, e2, an, an2, an3, an4, an5, ae2, ap2 ;
    UTMZoneStruct *UTMZone ;
    
    UTMZone = allocUTMZone() ;
    memcpy(UTMZone->ellProj, ellProj, sizeof(ellipsoid)) ;
    
    ae2 = pow(UTMZone->ellProj->a, 2.) ;
    ap2 = pow(UTMZone->ellProj->b, 2.) ;
    UTMZone->ellProj->ep2 = ep2 = (ae2 - ap2)/ap2 ;
    UTMZone->ellProj->e2 = e2 = (ae2 - ap2)/ae2 ;
    an = (UTMZone->ellProj->a - UTMZone->ellProj->b)/(UTMZone->ellProj->a + UTMZone->ellProj->b) ;
    an2 = an*an ;
    an3 = an2*an ;
    an4 = an2*an2 ;
    an5 = an2*an3 ;
    UTMZone->a = ellProj->a * (1 - an + 5/4.*(an2 - an3) + 81/64.*(an4 - an5)) ;
    UTMZone->b = 3/2. * ellProj->a*(an - an2 + 7/8.*(an3 - an4) + 55/64.*an5) ;
    UTMZone->c = 15/16. * ellProj->a*(an2 - an3 + 3/4.*(an4 - an5)) ;
    UTMZone->d = 35/48. * ellProj->a*(an3 - an4 + 11/16.*an5) ;
    UTMZone->e = 315/512. * ellProj->a*(an4 - an5) ;
    UTMZone->zkphi =.9996 ;
    UTMZone->x0 = 500000. ;
    
    return(UTMZone) ;
}

/* Conversion de coordonnées longitude - latitude en coordonnées UTM */
/* La fonction retourne le easting à la place de la longitude et le northiong à la place de la latitude */
void	lonLat2UTMOnEllipsoid(double *lon, double *lat, UTMZoneStruct *UTMZone)
{
    double	x, y, t2, t4, s, c4, c5, t1, ve, sv, sa, sb, sr, st, su, df, delta, c1, c2, c3, alat, s1, s2 ;
    ellipsoid *ellProj ;

	ellProj = UTMZone->ellProj ;

    df = UTMZone->lambdaC - *lon ;
    delta = fabs(df) ;
    alat = fabs(*lat) ;
    s1 = sin(alat) ;
    s2 = s1*s1 ;
    c1 = cos(alat) ;
    c2 = c1*c1 ;
    c3 = c2*c1 ;
    c4 = c2*c2 ;
    c5 = c2*c3 ;
    t1 = tan(alat) ;
    t2 = t1*t1 ;
    t4 = t2*t2 ;
    
    s = UTMZone->zkphi * (UTMZone->a * alat - UTMZone->b * sin(2 * alat) + UTMZone->c * sin(4 * alat) - UTMZone->d * sin(6 * alat) + UTMZone->e * sin(8 * alat)) ;
    ve = ellProj->a/sqrt(1. - ellProj->e2 * s2) ;
    sr = ve/2. * s1 * c1 * UTMZone->zkphi ;
    st = ve * s1 * c3 * (5. - t2 + 9 * ellProj->ep2 * c2 + 4 * ellProj->ep2 * ellProj->ep2 * c4) * UTMZone->zkphi/24. ;
    su = ve * c1 * UTMZone->zkphi ;
    sv = ve/6 * c3 * (1. - t2 + ellProj->ep2 * c2) * UTMZone->zkphi ;
    sa = pow(delta, 6.)/720 * ve * s1 * c5 * (61. - 58 * t2 + t4 + 270 * ellProj->ep2 * c2 - 330 * ellProj->ep2 * s2) * UTMZone->zkphi ;
    sb = pow(delta, 5.)/120*ve*c5*(5. - 18*t2*t4 + 14*ellProj->ep2*c2 - 58*ellProj->ep2*s2)*UTMZone->zkphi ;
    
    x = su * delta + sv * pow(delta, 3.) + sb ;
    if (df > 0.) x = -x ;
    x = x + UTMZone->x0 ;
    
    y = s + sr * pow(delta, 2.) + st * pow(delta, 4.) + sa ;
    if(*lat < 0.) y = -y ;
    y = y + UTMZone->y0 ;
    
    *lon = x ;
    *lat = y ;
}


