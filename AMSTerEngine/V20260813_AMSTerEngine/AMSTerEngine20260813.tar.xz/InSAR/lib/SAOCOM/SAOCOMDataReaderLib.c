
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  SAOCOMDataReaderLib.c
//  SAOCOMDataReader
//
//  Created by Dominique Derauw on 19/06/2020.
//  Copyright (c) 2020 Dominique Derauw. All rights reserved.
//

#include "SAOCOMDataReaderLib.h"



CSVStruct *SAOCOMDataReader(CSVStruct *csv)
{
    char *polarization = NULL ;
    int unsigned flag, AoICoordinateSystem ;
    keyValue *parametersList ;
    time_t startTime, endTime ;
    CSVStruct *savedCSLImages = NULL, *tempCSV = NULL ;    
    
    time(&startTime) ;
    if(csv->numberOfEntries == 1)
        SAOCOMDataReaderHelp() ;
    if(isArgumentPresentInCSV(csv, "help")|| isArgumentPresentInCSV(csv, "-h"))
        SAOCOMDataReaderHelp() ;
    
    if(isArgumentPresentInCSV(csv, "-create"))
        createSAOCOMDataReaderParameterFileAtPath(csv->stringVal[1]) ;
    
    /* Define default AoI coordinate system */
    AoICoordinateSystem = _AOI_GEO_COORDINATE_SYSTEM_DEG_ ;   
    flag = AoICoordinateSystem ;
    flag |= (isFlagPresentInCSV(csv, "r"))? _READ_OVERWRITE_ : flag ;
    flag |= (isFlagPresentInCSV(csv, "o"))? _ORDER_DATA_ : flag ;
    flag |= (isFlagPresentInCSV(csv, "I"))? _AOI_FULLY_INCLUDED_ : flag ;
    
    /* If parameter 1 is a directory, we will consider it contains one or more S1 files to be read. Consequently, bulk processing must be considered */
    if (isDir(csv->stringVal[1])) {
        flag |= _BULK_READING_ ;
        savedCSLImages = SAOCOMBulkReaderLoop(csv, flag) ;
    }
    else {
        parametersList = readParameterFileAtPath(csv->stringVal[1]) ;

        tempCSV = addStringValInCSVStruct("SAOCOMDataReader", tempCSV) ;
        addStringValInCSVStruct(getStringValForKeyIn(parametersList, "SAOCOM data directory"), tempCSV) ;
        addStringValInCSVStruct(getStringValForKeyIn(parametersList, "Path to output image in CSL format"), tempCSV) ;
        addStringValInCSVStruct(getStringValForKeyIn(parametersList, "kml"), tempCSV) ;
        polarization = initStringWith2Strings("P=", getStringValForKeyIn(parametersList, "Polarization")) ;
        if (!isSubStringPresentInString(polarization, "ALL") && strlen(polarization) == 4) {
            addStringValInCSVStruct(polarization, tempCSV) ;
        }
        
        savedCSLImages = SAOCOMBulkReaderLoop(tempCSV, flag) ;

        freeCSVStruct(tempCSV) ;
        freeKeyValueList(parametersList) ;
        free(polarization) ;
    }
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    
    return(savedCSLImages) ;
}

CSVStruct *SAOCOMBulkReaderLoop(CSVStruct *csv, int unsigned flag)
{
    char *SARImageName, *xemtFilePath, pathRow[16] ;
    char *outputDir = NULL, *aPath ;
    char subdir[40], sat[2][8], headingDir[2][16], headingDirShort[2][4], polScheme[5][4], *polDir ;
    char *SAOCOMDataDirectory = NULL, *zipFilePath ;
    char *logFilePath ;
    char *inputPath, *outputPath = NULL, *aFileName ;
    char *polarization = NULL ;
    char *commandLine ;
    char skipReading ;
    int iAD, iAB, ci, cj, ii, ij, ik, imageCount ;
    quadrilateral *aoi = NULL ;
    CSVStruct *SAOCOMFilePath, *savedCSLImages = NULL, *tempCSV = NULL ;
    CSVStruct *fileList1, *fileList2, *pol ;
    SLCImageInfo *info, **infoList, *existingInfo ;
    CSLImage *thisImage ;
    coord2D *caoi, *c1, *c2 ;
    
    /* Select polarization if requested */
    if ((ci = isArgumentPresentInCSV(csv, "P="))) {
        if (strlen(csv->stringVal[ci]) == 4) {
            polarization = initStringWithString(csv->stringVal[ci] + 2) ;
        }
    }
    
    /* Read area of interest if present in command line parameters */
    for (ci = 0; ci < csv->numberOfEntries; ci++) {
        if (!aoi) {
            aoi = getPolygonalAoIFromKMLFile(csv->stringVal[ci]) ;
        }
    }
    if (!aoi) {
        flag &= ~_AOI_FULLY_INCLUDED_ ;
    }
    
    
    /* Select output directory as the second directory given as parameter*/    
    for (ci = 2; ci < csv->numberOfEntries; ci++) {
        if (isDir(csv->stringVal[ci]) && !outputDir) {
            outputDir = initStringWithString(csv->stringVal[ci]) ;
        }
    }
    
    /* List all available SAOCOM scene within input directory */
    /* First, list all .xemt files */
    printf("---> Listing SAOCOM data within given directory. \n") ;
    fileList1 = recursiveSearchOfFilesWithExtensionInDir(".xemt", csv->stringVal[1]) ;
    /* Extract SAOCOM L1A file listing */
    fileList2 = getCSVWithStringInCSV("_OPER_SAR_EOSSP", fileList1) ;
    freeCSVStruct(fileList1) ;
    SAOCOMFilePath = getCSVWithStringInCSV("_L1A_", fileList2) ;
    freeCSVStruct(fileList2) ;

    /* If no SAOCOM directories found in recursive search, verify that the input directory is itself an SAOCOM directory */
    if (SAOCOMFilePath == NULL) {
        ase("\t---> No SAOCOM SLC file found.") ;
    }
    /* If output directory still not set, select it as the directory that contains the images to be read */
    if (!outputDir) {
        outputDir = initStringWithString(csv->stringVal[1]) ;
    }
    
    /* If log file exists, remove it */
    logFilePath = initStringWith2Strings(outputDir, "/SAO1DataReaderLog.txt") ;
    if (fileExistsAtPath(logFilePath)) {
        unlink(logFilePath) ;
    }
    free(logFilePath) ;
    
    /* If aoi is given, we will check for duplicates based on date, frame and path before reading */
    /* If several acquisitions are available for a given date, the one having its center closest to aoi center will be selected */
    /* Others will be removed from the list */

    /* Generate infoImage for each candidate */
    infoList = malloc(SAOCOMFilePath->numberOfEntries * sizeof(infoList[0])) ;
    for (ci = 0; ci < SAOCOMFilePath->numberOfEntries; ci++) {
        xemtFilePath = SAOCOMFilePath->stringVal[ci] ;
        infoList[ci] = allocAndInitSLCImageInfoFromSAOCOMxemtFile(xemtFilePath) ;
    }

    printf("\t---> %d available SAOCOM data frames. \n", SAOCOMFilePath->numberOfEntries) ;
    if (aoi) {
        printf("\t---> Restricting data list to frames encompassing given AoI. \n") ;
            /* First, eliminates frames having no intersection with AoI */
        convertAoIFromDeg2Rad(aoi) ;
        for (ii = 0; ii < SAOCOMFilePath->numberOfEntries; ii++) {
            if (!polygonesIntersects(aoi, infoList[ii]->loc)) {
                printf("\t\tRemoving image %s from listing\n\t\tImage has no intersection with selected aoi.\n\n", SAOCOMFilePath->stringVal[ii]) ;
                removeStringValAtIndexInCSVStruct(ii, SAOCOMFilePath) ;
                freeInfoImage(infoList[ii]) ;
                for ( ij = ii; ij < SAOCOMFilePath->numberOfEntries; ij++) {
                    infoList[ij] = infoList[ij + 1] ;
                }
                ii-- ;
            }
            else {
                if (flag & _AOI_FULLY_INCLUDED_) {
                    ci = 0 ;
                    for (ij = 0; ij < aoi->N; ij++) {
                        ci += isPointIncludedInPolygon(&aoi->P[ij], infoList[ii]->loc) ;
                    }
                    if (ci != aoi->N) {
                        printf("\t\tRemoving image %s from listing\n\t\tSelected aoi is not fully included within image frame.\n\n", SAOCOMFilePath->stringVal[ii]) ;
                        removeStringValAtIndexInCSVStruct(ii, SAOCOMFilePath) ;
                        freeInfoImage(infoList[ii]) ;
                        for ( ij = ii; ij < SAOCOMFilePath->numberOfEntries; ij++) {
                            infoList[ij] = infoList[ij + 1] ;
                        }
                        ii-- ;
                    }
                }
            }
        }

        /* Then select best frame with respect to input kml */
        caoi = getCentreOfPolygon(aoi) ;
        for (ii = 0; ii < SAOCOMFilePath->numberOfEntries - 1; ii++) {
            c1 = getCentreOfPolygon(infoList[ii]->loc) ;
            for ( ij = ii + 1; ij < SAOCOMFilePath->numberOfEntries; ij++) {
                if (!strcmp(infoList[ii]->acquisitionDate, infoList[ij]->acquisitionDate) 
                    && infoList[ii]->beamNumber == infoList[ij]->beamNumber 
                    && infoList[ii]->relativeOrbitNumber == infoList[ij]->relativeOrbitNumber
                    && infoList[ii]->relativeFrameNumber == infoList[ij]->relativeFrameNumber) {
                    c2 = getCentreOfPolygon(infoList[ij]->loc) ;
                    if (EuclidianDistanceBetween2DPoints(caoi, c1) < EuclidianDistanceBetween2DPoints(caoi, c2)) {
                        printf("\t\tRemoving image %s from listing.\n\t\tReplaced by image %s.\n", SAOCOMFilePath->stringVal[ii], SAOCOMFilePath->stringVal[ij]) ;
                        removeStringValAtIndexInCSVStruct(ii, SAOCOMFilePath) ;
                        freeInfoImage(infoList[ii]) ;
                        for ( ik = ii; ik < SAOCOMFilePath->numberOfEntries; ik++) {
                            infoList[ik] = infoList[ik + 1] ;
                        }
                        ii-- ;
                    }
                    else {
                        printf("\t\tRemoving image %s from listing.\n\t\tReplaced by image %s.\n", SAOCOMFilePath->stringVal[ij], SAOCOMFilePath->stringVal[ii]) ;
                        removeStringValAtIndexInCSVStruct(ij, SAOCOMFilePath) ;
                        freeInfoImage(infoList[ij]) ;
                        for ( ik = ij; ik < SAOCOMFilePath->numberOfEntries; ik++) {
                            infoList[ik] = infoList[ik + 1] ;
                        }
                        ij-- ;
                    }
                    printf("\t\tThis latter one is better centerd on selected aoi.\n\n") ;
                    free(c2) ;
                }
            }
            free(c1) ;
        }
        free(caoi) ;
    }

    /* Select most recent processed image for given date, orbit and frame */
    for (ii = 0; ii < SAOCOMFilePath->numberOfEntries - 1; ii++) {
        for ( ij = ii + 1; ij < SAOCOMFilePath->numberOfEntries; ij++) {
            if (!strcmp(infoList[ii]->acquisitionDate, infoList[ij]->acquisitionDate) 
                && infoList[ii]->relativeOrbitNumber == infoList[ij]->relativeOrbitNumber
                && infoList[ii]->relativeFrameNumber == infoList[ij]->relativeFrameNumber) {
                if (strcmp(infoList[ii]->productionTime, infoList[ij]->productionTime) < 0) {
                    printf("\t\tRemoving image %s from listing\n\t\tA more recent image is available.\n", SAOCOMFilePath->stringVal[ii]) ;
                    printf("\t\tOld production date: %s\n\t\tNew production date: %s\n\n", infoList[ii]->productionTime, infoList[ij]->productionTime) ;
                    removeStringValAtIndexInCSVStruct(ii, SAOCOMFilePath) ;
                    freeInfoImage(infoList[ii]) ;
                    for ( ij = ii; ij < SAOCOMFilePath->numberOfEntries; ij++) {
                        infoList[ij] = infoList[ij + 1] ;
                    }
                    ii-- ;
                }
            }
        }
    }
    for ( ii = 0; ii < SAOCOMFilePath->numberOfEntries; ii++) {
        freeInfoImage(infoList[ii]) ;
    }
    free(infoList) ;

    /* Prepare naming substrings */
    sprintf(sat[0], "SAO1A_") ;
    sprintf(sat[1], "SAO1B_") ;
    sprintf(headingDir[0], "Ascending") ;
    sprintf(headingDir[1], "Descending") ;
    sprintf(headingDirShort[0], "_A") ;
    sprintf(headingDirShort[1], "_D") ;
    sprintf(polScheme[0], "SPH") ;
    sprintf(polScheme[1], "SPV") ;
    sprintf(polScheme[2], "DPH") ;
    sprintf(polScheme[3], "DPV") ;
    sprintf(polScheme[4], "QP") ;

    /* Process each input for reading */
    printf("\nNumber of SAOCOM image frames to read: %d\n", SAOCOMFilePath->numberOfEntries) ;
    printf("---------------------------------\n") ;
    imageCount = 0 ;
    for (ci = 0; ci < SAOCOMFilePath->numberOfEntries; ci++) {
        printf("\nFrame %d\n", ci + 1) ;
        xemtFilePath = SAOCOMFilePath->stringVal[ci] ;
        info = allocAndInitSLCImageInfoFromSAOCOMxemtFile(xemtFilePath) ;
        if (info) {
            if (flag & _BULK_READING_) {
                iAB = isSubStringPresentInString(info->platformName, "1A")? 0 : 1 ;
                iAD = isSubStringPresentInString(info->heading, "Ascending")? 0 : 1 ;
                if (flag & _ORDER_DATA_) {
                    pol = readCSVInString(info->polMode) ;
                    switch (pol->numberOfEntries) {
                    case 1:
                        polDir = (strncmp(pol->stringVal[0], "H", 1))? polScheme[1] : polScheme[0] ;
                        break;
                    case 2:
                        polDir = (strncmp(pol->stringVal[0], "H", 1))? polScheme[3] : polScheme[2] ;
                        break;
                    
                    case 4:
                        polDir = polScheme[4] ;
                        break;
                    }
                    sprintf(subdir, "/%s/S%.1d/Track%.3d/Frame%.3d/%s/", headingDir[iAD], info->beamNumber, info->relativeOrbitNumber, info->relativeFrameNumber, polDir) ;
                    SARImageName = initStringWith3Strings(sat[iAB], info->acquisitionDate, headingDirShort[iAD]) ;
                    outputPath = initStringWith4Strings(outputDir, subdir, SARImageName, ".csl") ;
                    aPath = getDirectoryPathFromPath(outputPath) ;
                    makeDirRecursively(aPath) ;
                    freeCSVStruct(pol) ;
                }
                else {
                    sprintf(pathRow, "_%.3d_%.3d", info->relativeOrbitNumber, info->relativeFrameNumber) ;
                    SARImageName = initStringWith4Strings(sat[iAB], info->acquisitionDate, pathRow, headingDirShort[iAD]) ;
                    outputPath = initStringWith4Strings(outputDir, "/", SARImageName, ".csl") ;
                }

                free(SARImageName) ;
            }
            else{
                outputPath = initStringWithString(outputDir) ;
            }
            
            
            /* Verify if image container already exists and trash it if requested */
            skipReading = 0 ;
            if (isCSLImageAtPath(outputPath)) {
                if ((flag & _READ_OVERWRITE_)) {
                    removeDirectoryAtPath(outputPath) ;
                }
                else {
                    existingInfo = readInfoImageInCSLImageAtPath(outputPath) ;
                    if (info->relativeFrameNumber == existingInfo->relativeFrameNumber) {
                        if (strcmp(info->productionTime, existingInfo->productionTime) < 0) {
                            printf("\t---> Frame already existing at destination path but processed formerly. \n") ;
                            printf("\t\t---> %s\n", outputPath) ;
                            printf("\t\t---> Former production time  : %s \n", info->productionTime) ;
                            printf("\t\t---> Current production time : %s \n", existingInfo->productionTime) ;
                            printf("\t\t---> Replacing existing one by most recently processed one. \n") ;
                            removeDirectoryAtPath(outputPath) ;
                        }
                        else {
                            skipReading = 1 ;
                            printf("\t---> Skip reading\n\t---> Frame already existing at destination path:\n\t---> %s\n\n", outputPath) ;
                            free(outputPath) ;
                        }
                        freeInfoImage(existingInfo) ;
                    }
                }
            }

            if (!skipReading) {
                thisImage = createCSLDirectoryStructureAtPath(outputPath, __SAOCOM1A__) ;
                free(outputPath) ;

                saveInfoImageInCSLImage(info, thisImage) ;

                /* Test if data was already unzipped */
                stripExtensionAtEndOfPath(xemtFilePath) ;
                if (isDir(xemtFilePath)) {
                    /* Copy headers into CSL image */
                    /* Create Data directry into header directory  to cope with SAOCOM header structure */
                    outputPath = initStringWith2Strings(thisImage->headersDirectoryPath, "/Data") ;
                    if(mkdir((const char *)outputPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
                        sprintf(ertex, "Failed to create data header directory at path %s\n", outputPath) ;
                        ase(ertex) ;
                    }
                    free(outputPath) ;

                    SAOCOMDataDirectory = initStringWith2Strings(xemtFilePath, "/Data") ;
                    fileList1 = recursiveSearchOfFilesWithExtensionInDir("xml", SAOCOMDataDirectory) ;
                    for (cj = 0; cj < fileList1->numberOfEntries; cj++) {
                        aFileName = getPointerToFileNameInPath(fileList1->stringVal[cj]) ;

                        inputPath = initStringWith3Strings(SAOCOMDataDirectory, "/", aFileName) ;
                        outputPath = initStringWith3Strings(thisImage->headersDirectoryPath, "/Data/", aFileName) ;
                        copyFileAtPathToPath(inputPath, outputPath) ;
                        free(inputPath) ;
                        free(outputPath) ;
                    }
                    
                    inputPath = initStringWith2Strings(xemtFilePath, "/Config") ;
                    outputPath = initStringWith2Strings(thisImage->headersDirectoryPath, "/Config") ;
                    copyDirAtPathToPath(inputPath, outputPath) ;
                    free(inputPath) ;
                    free(outputPath) ;
                }
                else {
                    /* Unzip in CSL image header directory */
                    zipFilePath = initStringWith2Strings(xemtFilePath, ".zip") ;
                    if (!fileExistsAtPath(zipFilePath)) {
                        printf("\t---> %s\n", xemtFilePath) ;
                        printf("\t---> Skip reading. SAOCOM file does not contain CUSS data to be uncompresses\n\n") ;
                        flag |= _SKIP_READING_ ;
                    }
                    else {
                        printf("\t---> Decompressing %s\n", zipFilePath) ;
                        tempCSV = addStringValInCSVStruct("unzip ", NULL) ;
                        addStringValInCSVStruct(zipFilePath, tempCSV) ;
                        addStringValInCSVStruct(" -d ", tempCSV) ;
                        addStringValInCSVStruct(thisImage->headersDirectoryPath, tempCSV) ;
                        addStringValInCSVStruct(" > /dev/null", tempCSV) ;
                        commandLine = getStringFromCSV(tempCSV) ;
                        if (system(commandLine) == 0)
                        {
                            inputPath = initStringWith2Strings(thisImage->headersDirectoryPath, "/Images") ;
                            removeDirectoryAtPath(inputPath) ;
                            free(inputPath) ;
                            inputPath = initStringWith2Strings(thisImage->headersDirectoryPath, "/Quality") ;
                            removeDirectoryAtPath(inputPath) ;
                            free(inputPath) ;
                        }
                        else {
                            printf("\t-/-> Something went wrong while decompressing %s\n\tSkipping image.\n\n", getPointerToFileNameInPath(zipFilePath)) ;
                            removeDirectoryAtPath(thisImage->imageDirectoryPath) ;
                            freeCSLImageStructure(thisImage) ;                
                            skipReading = 1 ;
                        }
                        
                        free(commandLine) ;
                        freeCSVStruct(tempCSV) ;
                        tempCSV = NULL ;
                    }
                    free(zipFilePath) ;
                    SAOCOMDataDirectory = NULL ;
                }
                
            
                /* Read SAOCOM data */
                if (!skipReading && readSAOCOMData(SAOCOMDataDirectory, thisImage, aoi, polarization, flag)) {
                    savedCSLImages = addStringValInCSVStruct(thisImage->imageDirectoryPath, savedCSLImages) ;
                    freeCSLImageStructure(thisImage) ;                
                    imageCount++ ;
                }
                
                if (SAOCOMDataDirectory) {
                    free(SAOCOMDataDirectory) ;
                }
            }
        }
        freeInfoImage(info) ;
    }
    printf("\n\n--->Number of read and saved frames: %d\n\n", imageCount) ;
    freeCSVStruct(SAOCOMFilePath) ;
    free(outputDir) ;
    if (polarization) {  
       free(polarization) ;
    }
    if (aoi) {
        freePolygon(aoi) ;
    }
    
    return (savedCSLImages) ;
}

void createSAOCOMDataReaderParameterFileAtPath(char *aPath)
{
    keyValue *parameters ;    
    
    parameters = allocAKeyValuePair() ;
    setStringValForKeyIn(parameters, "SAOCOMDataReader parameter file", "") ;
    setStringValForKeyIn(parameters, "*******************************", "") ;
    setStringValForKeyIn(parameters, "PathToS1Directory", "SAOCOM data directory path (directory containing the .xemt file).") ;
    setStringValForKeyIn(parameters, "outputFilePath", "Path to output image in CSL format") ;
    setStringValForKeyIn(parameters, "ALL", "Polarization to read (HH, VV, VH, HV or ALL)") ;
    setStringValForKeyIn(parameters, "", "") ;
    setStringValForKeyIn(parameters, "Area of interest", "") ;
    setStringValForKeyIn(parameters, "pathToKMLFile", "kml file path (.kml polygon saved from Google Earth)") ;
    setStringValForKeyIn(parameters, "", "") ;
    setStringValForKeyIn(parameters, "", "") ;

/*    
    if ((SAOCOMPrecisesOrbitsDir = getenv("SAOCOM_PRECISES_ORBITS_DIR")) == NULL) {
        setStringValForKeyIn(parameters, "SAOCOM_Precises_Orbits_DirectoryPath", "SAOCOM precises orbits directory") ;
    }
    else {
        setStringValForKeyIn(parameters, SAOCOMPrecisesOrbitsDir, "SAOCOM precises orbits directory") ;
    }
*/

    writeParameterFileAtPath(parameters, aPath) ;
    
    exit(0) ;
}



void SAOCOMDataReaderHelp()
{
    printf("\nSAOCOMDataReader:") ;
    printf("\n\tThis routine will read SLC SAOCOM Level 1A data and save it in CSL format.\n");
    printf("Up to now, it reads only stripmap data....\n") ;
    printf("\nUsage:") ;
    printf("\n-1-\tSAOCOMDataReader /pathToParameterFile [-create] [-ro]\n") ;
    printf("\tPer file data reading: A parameter file must be given as parameter\n") ;
    printf("\tAn example parameter file can be created using the -create keyword\n") ;
    printf("\n-2-\tSAOCOMDataReader inputDir [outputDir] [kmlFile] [-ro]\n") ;
    printf("\tBulk data reading.\n") ;
    printf("\t If no output dir is provided, read data are saved within input directory.\n") ;
    printf("\tA kml file delimiting the area of interest can be given as parameter, \n") ;
    printf("\tin which case, bulk reading is limited to frames of interest within available images.\n") ;
    printf("\nOptions:\n") ;
    printf("-r : Overwrite data if already existing without prompting.\n") ;
    printf("-o : Order data by subdirectroies with respect to heading, beam, frame and track.\n") ;
    printf("-I : Keep only images that fully encompass the given aoi.\n") ;
    
    exit(0) ;
}


int readSAOCOMData(char *inputDataDirectory, CSLImage *thisImage, polygon *aoi, char *pol, unsigned int flag)
{
    char *dataDirectory, *aString, *inputFilePath ;
    int anIndex, i ;
    CSVStruct *SLCDataList, *dataList ;
    struct SAOCOMDataFileStruct *fileStruct ;
    polygon *maxAoI ;
    struct infoImage *info ;

    if (flag & _SKIP_READING_) {
        return (0) ;
    }

    if (!(dataDirectory = inputDataDirectory)) {
        dataDirectory = initStringWith2Strings(thisImage->headersDirectoryPath, "/Data") ;
    }

    /* We manage requested pol removing non-requested ones */
    convertStringToLowercase(pol) ;
    dataList = recursiveSearchOfFilesWithExtensionInDir("xml", dataDirectory) ;
    SLCDataList = getCSVWithStringInCSV("slc-acq", dataList) ;
    freeCSVStruct(dataList) ;
    if (pol) {
        aString = initStringWith3Strings("-",pol, ".xml") ;
        for (anIndex = 0; anIndex < SLCDataList->numberOfEntries; anIndex++) {
            if (!isSubStringPresentInString(SLCDataList->stringVal[anIndex], aString)) {
                if (!inputDataDirectory) {
                    inputFilePath = initStringWithString(SLCDataList->stringVal[anIndex]) ;
                    unlink(inputFilePath) ;
                    stripExtensionAtEndOfPath(inputFilePath) ;
                    unlink(inputFilePath) ;
                    free(inputFilePath) ;
                }
                
                removeStringValAtIndexInCSVStruct(anIndex, SLCDataList) ;
            }
        }
        free(aString) ;
    }
         
    printf("\t---> Reading SAOCOM data into %s\n", thisImage->imageDirectoryPath) ;
    /* We read first available mode first to then select aoi */
    inputFilePath = initStringWithString(SLCDataList->stringVal[0]) ;
    fileStruct = getSAOCOMDataFileStruct(inputFilePath) ;

    stripExtensionAtEndOfPath(inputFilePath) ;
    readSAOCOMModeIntoCSLImage(inputFilePath, thisImage, fileStruct) ;
    free(inputFilePath) ;

    /* We look now for the max imum area of interest in slant range - azimuth, cutting out black borders */
    maxAoI = getMaxAoiOfCSLImage(thisImage) ;

    /* If requested, we reverify aoi is fully included in image frame */
    if (flag & _AOI_FULLY_INCLUDED_) {
        info = adaptInfoImageOfCSLImageToAoi(thisImage, maxAoI, 0) ;
        anIndex = 0 ;
        for (i = 0; i < aoi->N; i++) {
            anIndex += isPointIncludedInPolygon(&aoi->P[i], info->loc) ;
        }
        if (anIndex != aoi->N) {
            printf("\t-/-> Read image does not fully encompass requested aoi.\n\t\tRemoving it.\n") ;
            removeDirectoryAtPath(thisImage->imageDirectoryPath) ;
            freeCSLImageStructure(thisImage) ;
            return (0) ;
        }
        freeInfoImage(info) ;
    }

    addaptSAOCOMFileStructToAoI(fileStruct, maxAoI) ;
    cropCSLImageToAoi(thisImage, maxAoI) ;
    freePolygon(maxAoI) ;

    /* Now we read remaining modes restricting them to the same aoi */
    for (anIndex = 1; anIndex < SLCDataList->numberOfEntries; anIndex++) {
        inputFilePath = initStringWithString(SLCDataList->stringVal[anIndex]) ;
        stripExtensionAtEndOfPath(inputFilePath) ;
        readSAOCOMModeIntoCSLImage(inputFilePath, thisImage, fileStruct) ;
        free(inputFilePath) ;
    }
    free(fileStruct) ;

    if (!inputDataDirectory) {
        free(dataDirectory) ;
    }

    freeCSVStruct(SLCDataList) ;
    return (1) ;
}

struct SAOCOMDataFileStruct *getSAOCOMDataFileStruct (char *inputFilePath)
{
    char swapBytes ;
    CSVStruct *csv ;
 	xmlDocPtr xmlDocFile ;
    struct SAOCOMDataFileStruct *fileStruct ;


    if ((fileStruct = malloc(sizeof(fileStruct[0]))) == NULL) {
        ase("Failed to get SAOCOM file structure\n") ;
    }
    xmlDocFile = getdoc(inputFilePath) ;

    /* Read number of lines */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//RasterInfo/Lines", xmlDocFile)) == NULL) {
        ase("Failed to read number of rows in xml file") ;
    }
    sscanf(csv->stringVal[0], "%ld", &(fileStruct->numberOfRows)) ;
    freeCSVStruct(csv) ;

    /* Read line length */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//RasterInfo/Samples", xmlDocFile)) == NULL) {
        ase("Failed to read line length in xml file") ;
    }
    sscanf(csv->stringVal[0], "%ld", &(fileStruct->lineLength)) ;
    freeCSVStruct(csv) ;

    /* Read file header length */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//RasterInfo/HeaderOffsetBytes", xmlDocFile)) == NULL) {
        ase("Failed to read line length in xml file") ;
    }
    sscanf(csv->stringVal[0], "%ld", &(fileStruct->fileHeaderLength)) ;
    freeCSVStruct(csv) ;

    /* Read line header length */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//RasterInfo/RowPrefixBytes", xmlDocFile)) == NULL) {
        ase("Failed to read line length in xml file") ;
    }
    sscanf(csv->stringVal[0], "%ld", &(fileStruct->rowHeaderLength)) ;
    freeCSVStruct(csv) ;

    /* Read endness */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//RasterInfo/ByteOrder", xmlDocFile)) == NULL) {
        ase("Failed to read byte order description in xml file") ;
    }
    swapBytes = (!strncmp(csv->stringVal[0], "BIG", 3) ^ isArchBigEndian()) ;
    swapBytes = (!strncmp(csv->stringVal[0], "LIT", 3) ^ !isArchBigEndian()) ;
    freeCSVStruct(csv) ;

    fileStruct->swapBytes = swapBytes ;
    fileStruct->iXMin = fileStruct->iYMin = 0 ;
    fileStruct->iXMax = fileStruct->lineLength - 1 ;
    fileStruct->iYMax = fileStruct->numberOfRows - 1 ;

    xmlFreeDoc(xmlDocFile) ;

    return(fileStruct) ;
}


void readSAOCOMModeIntoCSLImage(char *inputFilePath, CSLImage *thisImage, struct SAOCOMDataFileStruct *fileStruct)
{
    char *currentPol, *outputFilePath, *aFilePath ;
    size_t iX, iY, lineLength, seekVal ;
    complexFloat *aLine ;
    rawFileDescriptor *inputFile, *outputFile ;

    inputFile = openRawFileForReadingAtPath(inputFilePath) ;
    currentPol = initStringWithString(inputFile->fileName + strlen(inputFile->fileName) - 2) ;
    convertStringToUppercase(currentPol) ;
    outputFilePath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", currentPol) ;
    outputFile = openRawFileForWritingAtPath(outputFilePath) ;
    free(outputFilePath) ;
    free(currentPol) ;

    /* Let's go */
    printf("\t---> %s\n", getPointerToFileNameInPath(inputFile->fileName)) ;
    lineLength = (size_t)(fileStruct->iXMax - fileStruct->iXMin) + 1 ;
    aLine = vectorComplexFloat(0, lineLength - 1) ;
    seekVal = fileStruct->fileHeaderLength + fileStruct->iYMin * (fileStruct->lineLength * COMPLEX_FLOAT_SIZE + fileStruct->rowHeaderLength) + fileStruct->iXMin * COMPLEX_FLOAT_SIZE ;
    fseek(inputFile->f, seekVal, SEEK_SET) ;
    for (iY = fileStruct->iYMin; iY <= fileStruct->iYMax; iY++, seekVal += fileStruct->lineLength * COMPLEX_FLOAT_SIZE) {
        if (fseek(inputFile->f, seekVal, SEEK_SET)) {
            ase("Failed to seek into SAOCOM data file") ;
        }
        
        if ((fread(aLine, sizeof(complexFloat), lineLength, inputFile->f) != lineLength)) {
            ase("Failed to read into SAOCOM data file") ;
        }
        
        if (fileStruct->swapBytes) {
            for (iX = 0; iX < lineLength; iX++) {
                swapComplexFloat(aLine + iX) ;
            }
        }

        if ((fwrite(aLine, sizeof(complexFloat), lineLength, outputFile->f) != lineLength)) {
            ase("Failed to write into SAOCOM data file") ;
        }
    }

    aFilePath = initStringWith3Strings(thisImage->headersDirectoryPath, "/Data/", inputFile->fileName) ;
    if (fileExistsAtPath(aFilePath)) {
        closeRawFile(inputFile) ;
        unlink(inputFile->accessPath) ;
    }
    freeRawFileDescriptor(inputFile) ;
    freeRawFileDescriptor(outputFile) ;
    freeVectorComplexFloat(aLine, 0) ;
    free(aFilePath) ; 
}


void addaptSAOCOMFileStructToAoI(struct SAOCOMDataFileStruct *fileStruct, polygon *aoi) 
{
    if ((aoi)) {
        fileStruct->iXMin = (size_t)ceil(aoi->P[0].x) ;
        fileStruct->iXMax = (size_t)floor(aoi->P[2].x) ;
        fileStruct->iYMin = (size_t)ceil(aoi->P[0].y) ;
        fileStruct->iYMax = (size_t)floor(aoi->P[2].y) ;
    }
    else {
        fileStruct->iXMin = 0 ;
        fileStruct->iXMax = fileStruct->lineLength - 1 ;
        fileStruct->iYMin = 0 ;
        fileStruct->iYMax = fileStruct->numberOfRows - 1 ;
    }
}
