
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  TDXCoregistrationManagement.c
//  SBInSAR
//
//  Created by Dominique Derauw on 20/12/16.
//  Copyright © 2016 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "TDXRegistration.h"


gridMap *TDXSpecificCase(InSARParametersStruct *pInSAR, keyValue *p)
{
    char isTDX ;
    gridMap *rangeCoregistrationGrid ;
    
    /* Now, we will handle the specific case of Tandem-X pairs, already coregistered and for which, we need the applied range shifts in place of an affine transform */
    isTDX = isTDXInSARPair(pInSAR) ;
    rangeCoregistrationGrid = NULL ;
    
    if (isTDX) {
        /* Since it is a TSX - TDX pair, we will use a coregistration grid, if provided */
        rangeCoregistrationGrid = TDXCoregistrationManagement(p) ;
    }
    
    return(rangeCoregistrationGrid) ;
}

char isTDXInSARPair(InSARParametersStruct *pInSAR)
{
    char isTDX ;

    /* We verify if the considered pair is a TSX-TDX or TDX-TSX pair */
    isTDX  = (isSubStringPresentInString(pInSAR->masterInfo->platformName, "TSX") && isSubStringPresentInString(pInSAR->slaveInfo->platformName, "TDX")) ;
    isTDX += (isSubStringPresentInString(pInSAR->masterInfo->platformName, "TDX") && isSubStringPresentInString(pInSAR->slaveInfo->platformName, "TSX")) ;

    return(isTDX) ;
}

gridMap *TDXCoregistrationManagement(keyValue *p)
{
    char *rangeShiftsFilePath ;
    int i, j ;
    float *aLineOfData ;
    rawFileDescriptor *rangeShiftsFile ;
    fltHeader fileHeader ;
    gridMap *rangeCoregistrationGrid ;
    
    /* Now, we will handle the specific case of Tandem-X bistatic pairs, already coregistered and for which, we need the applied range shifts in place of an affine transform */
    rangeCoregistrationGrid = NULL ;
    /* We suppose the given infoFile corresponds to the one of a slave image for which the coregistration file is given in parameters */
    
    rangeShiftsFilePath = getStringValForKeyIn(p, "Coregistration file") ;
    if ((rangeShiftsFile = openRawFileForReadingAtPath(rangeShiftsFilePath)) != NULL) {        
        /* Now, we will read the slave_range_shift.flt file*/
        fread(&fileHeader, sizeof(fltHeader), 1, rangeShiftsFile->f) ;
        
        /* Apparently, the header values are saved in big-endian while the data values are saved in low-endian */
        if (!isArchBigEndian()) {
            swap4bytesStruct(&fileHeader.xDim) ;
            swap4bytesStruct(&fileHeader.yDim) ;
            swap4bytesStruct(&fileHeader.headerSize) ;
            swap4bytesStruct(&fileHeader.dataSize) ;
            if ((fileHeader.xDim * fileHeader.yDim * sizeof(float)) != fileHeader.dataSize) {
                sprintf(ertex, "Something wrong in the header of range_shift_flt file\nRead dimensions are %d x %d\nExpected data size is %d\nExpected file size is %d\nEffective file size is %zd\n", fileHeader.xDim, fileHeader.yDim, fileHeader.dataSize, fileHeader.dataSize + fileHeader.headerSize, rangeShiftsFile->fileLength) ;
                ase(ertex) ;
            }
        }
        rangeCoregistrationGrid = createFloatGridOfSize(fileHeader.xDim, fileHeader.yDim, 64, 64) ;
        rangeCoregistrationGrid->x0 = rangeCoregistrationGrid->y0 = 0 ;
        fseek(rangeShiftsFile->f, SEEK_SET, fileHeader.headerSize) ;
        
        aLineOfData = vectorFloat(0, fileHeader.xDim) ;
        for (j = 0; j < rangeCoregistrationGrid->Ny; j++) {
            fread(aLineOfData, sizeof(float), rangeCoregistrationGrid->Nx, rangeShiftsFile->f) ;
            for (i = 0; i < rangeCoregistrationGrid->Nx; i++) {
                rangeCoregistrationGrid->floatVal[i][j] = aLineOfData[i] ;
                if (isArchBigEndian()) {
                    swapFloat(rangeCoregistrationGrid->floatVal[i] + j) ;
                }
            }
        }
        freeRawFileDescriptor(rangeShiftsFile) ;
        freeVectorFloat(aLineOfData, 0) ;
    }
    return(rangeCoregistrationGrid) ;
}



