
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  TSXDataReaderLib.c
//  TSXDataReader
//
//  Created by Dominique Derauw on 10/01/2020.
//  Copyright © 2020 Dominique Derauw. All rights reserved.
//

#include "TSXDataReaderLib.h"


CSVStruct *TSXDataReader(CSVStruct *csv)
{
    char *aPath ;
    char isHalfPrecisionFloat, forceReading ;
    char *inputFileName, *outputFileName, *XMLFileName, *outputDir, *outputPath, *TDXDir ;
    char *auxPath ;
    char tandemMode[2][3], masterOrSlave[2][7] ;
    int i, j ;
    int isPM, isMaster ;
    int frameIndex = 0 ;
    keyValue *parametersList ;
    CSLImage *thisImage, *existingImage ;
    SLCImageInfo *info, *existingInfo ;
    CSVStruct *TSXDirList, *TDXDirList, *XMLFilePath ;
    CSVStruct *savedCSLImages = NULL ;
    
    if(csv->numberOfEntries == 1 || isArgumentPresentInCSV(csv, "help") || isArgumentPresentInCSV(csv, "-h")) {
        TSXDataReaderHelp() ;
    }
    if(isArgumentPresentInCSV(csv, "-create")) {
        createTSXDataReaderParameterFileAtPath(csv->stringVal[1]) ;
    }
    
    forceReading = !isArgumentPresentInCSV(csv, "keepExisting") ;

    /* If parameter 1 is a directory, we will consider it contains one or more TSX files to be read */
    if (isDir(csv->stringVal[1])) {
        /* Bulk processing must be considered */
        outputDir = csv->stringVal[1] ;
        if (csv->numberOfEntries >= 3) {
            if (isDir(csv->stringVal[2])) {
                outputDir = csv->stringVal[2] ;
            }
        }
        
        
        /* First we deal with classical monostatic acquisitions */
        if (!(TSXDirList = recursiveSearchOfDirInDir("1_SAR__SSC", csv->stringVal[1]))) {
            if (isSubStringPresentInString(csv->stringVal[1], "1_SAR__SSC")) {
                TSXDirList = addStringValInCSVStruct(csv->stringVal[1], TSXDirList) ;
            }
        }
        if (TSXDirList) {
            isHalfPrecisionFloat = 0 ;
            for (i = TSXDirList->numberOfEntries - 1; i >= 0; i--) {
                if (isSubStringPresentInString(TSXDirList->stringVal[i], "TDM1_SAR")) {
                    removeStringValAtIndexInCSVStruct(i, TSXDirList) ;
                }
                else {
                    frameIndex = 0 ;
                    inputFileName = getPointerToFileNameInPath(TSXDirList->stringVal[i]) ;
                    outputFileName = allocStringOfLength(32) ;
                    sprintf(outputFileName, "%.8s_%.4s", inputFileName + 28, inputFileName) ;
                    outputPath = initStringWith3Strings(outputDir, "/", outputFileName) ;
                    
                    XMLFileName = initStringWith2Strings(inputFileName, ".xml") ;
                    if((XMLFilePath = recursiveSearchOfFileInDir(XMLFileName, TSXDirList->stringVal[i])) != NULL) {
                        info = createSLCImageInfoFromTSXXMLFile(XMLFilePath->stringVal[0]) ;
                        while (isCSLImageAtPath(outputPath)) {
                            existingImage = getCSLImageStructureAtPath(outputPath) ;
                            existingInfo = readInfoImageInCSLImage(existingImage) ;
                            if (!strcmp(info->platformName, existingInfo->platformName) && forceReading) {
                                removeDirectoryAtPath(outputPath) ;
                            }
                            else {
                                frameIndex++ ;
                                sprintf(outputPath, "%s/%s_%1d", outputDir, outputFileName, frameIndex) ;
                            }
                            freeInfoImage(existingInfo) ;
                            freeCSLImageStructure(existingImage) ;
                        }
                        
                        thisImage = createCSLDirectoryStructureAtPath(outputPath, __TSX__) ;
                        aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
                        saveInfoImage(info, aPath) ;
                        free(aPath) ;
                        isHalfPrecisionFloat = (info->flag & _SHORT_FLOAT_) ;
                        
                        printf("\nReading TSX data %s into CSL image %s\n", inputFileName, outputFileName) ;
                        readTSXDataLayersInto(thisImage, info, XMLFilePath->stringVal[0], isHalfPrecisionFloat) ;
                        
                        savedCSLImages = addStringValInCSVStruct(outputPath, savedCSLImages) ;
                        freeCSLImageStructure(thisImage) ;
                        freeCSVStruct(XMLFilePath) ;
                        freeInfoImage(info) ;
                    }
                    free(outputPath) ;
                    free(outputFileName) ;
                }
            }
            freeCSVStruct(TSXDirList) ;
        }
        
        /* Now we deal with bi-static or pursuite mode acquisitions */
        if (!(TDXDirList = recursiveSearchOfDirInDir("TDM1_SAR", csv->stringVal[1]))) {
            if (isSubStringPresentInString(csv->stringVal[1], "TDM1_SAR")) {
                TDXDirList = addStringValInCSVStruct(csv->stringVal[1], TDXDirList) ;
            }
        }
        if (TDXDirList) {
            isHalfPrecisionFloat = 1 ;
            sprintf(tandemMode[0], "BS") ;
            sprintf(tandemMode[1], "PM") ;
            sprintf(masterOrSlave[0], "slave") ;
            sprintf(masterOrSlave[1], "master") ;
            for (i = TDXDirList->numberOfEntries - 1; i >= 0; i--) {
                /* Detect if we deal with Pursuite Mode or Bi-static mode */
                isPM = isSubStringPresentInString(TDXDirList->stringVal[i], "MONO") ;
                TSXDirList = recursiveSearchOfDirInDir("1_SAR__SSC", TDXDirList->stringVal[i]) ;
                
                inputFileName = getPointerToFileNameInPath(TDXDirList->stringVal[i]) ;
                TDXDir = allocStringOfLength(strlen(outputDir) + 32) ;
                sprintf(TDXDir, "%s/%.8s_TDM_%s", outputDir, inputFileName + 28, tandemMode[isPM]) ;
                if (forceReading) {
                    removeDirectoryAtPath(TDXDir) ;
                }
                
                if (!isDir(TDXDir)) {
                    if(mkdir((const char *)TDXDir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
                        sprintf(ertex, "Failed to create image directory at path %s\n", TDXDir) ;
                        ase(ertex) ;
                    }
                
                    for (j = 0; j < 2; j++) {
                        inputFileName = getPointerToFileNameInPath(TSXDirList->stringVal[j]) ;
                        isMaster = (strncmp(inputFileName + 17, "1", 1))? 0 : 1 ;
                        outputFileName = allocStringOfLength(32) ;
                        sprintf(outputFileName, "/%.8s_%.4s.%s", inputFileName + 28, inputFileName, masterOrSlave[isMaster]) ;
                        outputPath = initStringWith2Strings(TDXDir, outputFileName) ;
                        
                        XMLFileName = initStringWith2Strings(inputFileName, ".xml") ;
                        if((XMLFilePath = recursiveSearchOfFileInDir(XMLFileName, TDXDirList->stringVal[i])) != NULL) {
                            info = createSLCImageInfoFromTSXXMLFile(XMLFilePath->stringVal[0]) ;
                            thisImage = createCSLDirectoryStructureAtPath(outputPath, __TSX__) ;
                            savedCSLImages = addStringValInCSVStruct(thisImage->imageDirectoryPath, savedCSLImages) ;
                            aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
                            saveInfoImage(info, aPath) ;
                            free(aPath) ;
                            
                            printf("\nReading TDX data %s into CSL image %s\n", inputFileName, outputFileName) ;
                            readTSXDataLayersInto(thisImage, info, XMLFilePath->stringVal[0], isHalfPrecisionFloat) ;

                            if (!isMaster) {
                                auxPath = initStringWith2Strings(TDXDirList->stringVal[i], "/COMMON_AUXRASTER/slave_shift_rg.flt") ;
                                aPath = initStringWith3Strings(thisImage->headersDirectoryPath, "/", getPointerToFileNameInPath(auxPath)) ;
                                copyFileAtPathToPath(auxPath, aPath) ;
                                free(aPath) ;
                                free(auxPath) ;
                            }
                            
                            freeCSLImageStructure(thisImage) ;
                            freeInfoImage(info) ;
                            freeCSVStruct(XMLFilePath) ;
                        }
                        free(outputPath) ;
                        free(outputFileName) ;
                    }
                }
                else {
                    savedCSLImages = recursiveSearchOfDirInDir(".csl", TDXDir) ;
                }
                free(TDXDir) ;
            }
        }
    }
    else {
        parametersList = readParameterFileAtPath(csv->stringVal[1]) ;
        
        aPath = getStringValForKeyIn(parametersList, "TSX data directory") ;
        outputPath = initStringWithString(getStringValForKeyIn(parametersList, "Path to output image")) ;
        XMLFileName = initStringWith2Strings(getPointerToFileNameInPath(aPath), ".xml") ;
        if((XMLFilePath = recursiveSearchOfFileInDir(XMLFileName, aPath)) != NULL) {
            savedCSLImages = addStringValInCSVStruct(outputPath, savedCSLImages) ;
            if (!isArgumentPresentInCSV(csv, "keepExisting")) {
                info = createSLCImageInfoFromTSXXMLFile(XMLFilePath->stringVal[0]) ;
                
                thisImage = createCSLDirectoryStructureAtPath(outputPath, __TSX__) ;
                aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
                saveInfoImage(info, aPath) ;
                free(aPath) ;
                
                if((isHalfPrecisionFloat = (info->flag & _SHORT_FLOAT_))) {
                    printf("\nReading TanDEM-X data %s into CSL image %s\n", aPath, thisImage->imageDirectoryPath) ;
                }
                else {
                    printf("\nReading TSX data %s into CSL image %s\n", aPath, thisImage->imageDirectoryPath) ;
                }
                readTSXDataLayersInto(thisImage, info, XMLFilePath->stringVal[0], isHalfPrecisionFloat) ;

                freeCSLImageStructure(thisImage) ;
                freeInfoImage(info) ;
            }
        }
        freeKeyValueList(parametersList) ;
        free(outputPath) ;
    }
    
    return(savedCSLImages) ;
}

void TSXDataReaderHelp()
{
    printf("\nUsage:") ;
    printf("\n-1-\tTSXDataReader /pathToParameterFile [-create]\n") ;
    printf("\n-2-\tTSXDataReader /inputPath [/outputPath]\n") ;
    printf("\n\tThis routine will read TSX data and save it in CSL format.\n");
    printf("\n\tIf adding \"-create\" command line parameter, \n\tan example parameter file will be created at indicated path.\n") ;
    exit(0) ;
}

void createTSXDataReaderParameterFileAtPath(char *aPath)
{
    keyValue *parameters ;
    
    parameters = allocAKeyValuePair() ;
    setStringValForKeyIn(parameters, "TSXDataReader parameter file", "") ;
    setStringValForKeyIn(parameters, "****************************", "") ;
    setStringValForKeyIn(parameters, "PathToTSXDir", "TSX data directory path") ;
    setStringValForKeyIn(parameters, "outputFilePath", "Path to output image in CSL format") ;
    
    writeParameterFileAtPath(parameters, aPath) ;
    
    exit(0) ;
}

void readTSXDataLayersInto(CSLImage *thisImage, struct infoImage *info, char *XMLPath, char isHalfPrecisionFloat)
{
    char    *aString, *dataFilePath, *aPath, *outputDataPath, *textFilePath ;
    char    isBigEndian, isSLC ;
    int     layerIndex, i, numberOfAzimuthLines, j, numberOfRangeSamples, x0, y0, xDim, yDim ;
    long    offset, fileHeader, lineHeader ;
    complexShort *anInputLine ;
    complexFloat *anOutputLine ;
    rawFileDescriptor *input, *output ;
    progressCounter *counter ;
    CSVStruct *polMode, *path, *filename ;
    time_t startTime, endTime ;
    xmlDocPtr doc ;
    keyValue *savedDataCharacteristics ;
    
    time(&startTime) ;
    
    yDim = numberOfAzimuthLines = info->azimuthDimension ;
    xDim = numberOfRangeSamples = info->rangeDimension ;
    x0 = y0 = 0 ;
    counter = initProgressCounterWithMinMaxValue(0, yDim) ;
    anInputLine = vectorComplexShort(0, numberOfRangeSamples - 1) ;
    anOutputLine = vectorComplexFloat(0, numberOfRangeSamples - 1) ;
    isBigEndian = 1 ;
    
    doc = getdoc(XMLPath);
    polMode = readCSVInXMLFileForXPath((xmlChar*)"//productComponents/imageData/polLayer", doc) ;
    path = readCSVInXMLFileForXPath((xmlChar*)"//productComponents/imageData/file/location/path", doc) ;
    filename = readCSVInXMLFileForXPath((xmlChar*)"//productComponents/imageData/file/location/filename", doc) ;
    
    for (layerIndex = 0; layerIndex < polMode->numberOfEntries; layerIndex++) {
        printf("\nReading TSX Data layer %d\n", layerIndex + 1) ;
        
        /* Determine input data file path */
        aPath = getDirectoryPathFromPath(XMLPath) ;
        aString = initStringWith4Strings(aPath, "/", path->stringVal[layerIndex], "/") ;
        free(aPath) ;
        dataFilePath = initStringWith2Strings(aString, filename->stringVal[layerIndex]) ;
        free(aString) ;
        
        /* Determine if TSX data is SLC */
        if((isSLC = isSubStringPresentInString(info->productID, "SSC"))) {
            /* If isSLC, we change the output name to SLCData and set the headers to correct values */
            outputDataPath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", polMode->stringVal[layerIndex]) ;
            lineHeader = 2 * sizeof(complexShort) ;
            fileHeader = 4 * (numberOfRangeSamples * sizeof(complexShort) + lineHeader) ;
        }
        else {
            /* if not SLC, we save data layer as is */
            outputDataPath = initStringWith3Strings(thisImage->dataDirectoryPath, "/", filename->stringVal[layerIndex]) ;
            lineHeader = fileHeader = 0 ;
        }
        textFilePath = initStringWith4Strings(thisImage->infoDirectoryPath, "/", getFileNameFromPath(outputDataPath), ".txt") ;
        
        /* Open input file for current layer */
        if((input = openRawFileForReadingAtPath(dataFilePath)) == NULL)
            ase("Failed to open input file") ;
        free(dataFilePath) ;
        
        /* Open output data file */
        if((output = openRawFileForWritingAtPath(outputDataPath)) == NULL)
            ase("Failed to create output file") ;;
        free(outputDataPath) ;
        
        /* Determine offset */
        /* x0, y0, xDim and yDim might be set to extract only a rectangular subset of data */
        offset = fileHeader + y0 * (numberOfRangeSamples * sizeof(complexShort) + lineHeader) + lineHeader + x0 * sizeof(complexShort) ;
        if(fseek(input->f, offset, SEEK_SET))
            ase("Failed to fseek") ;
        offset = ((numberOfRangeSamples - xDim) * sizeof(complexShort) + lineHeader) ;
        
        for(i = 0; i < yDim; i++) {
            if(xDim != (int)fread(anInputLine, sizeof(complexShort), xDim, input->f))
                ase("Failed to read input file") ;
            
            /* If runing on low endian processors and if input data is big endian then swap bytes */
            if(!isArchBigEndian() && isBigEndian) {
                for(j = 0; j < xDim; j++) {
                    swapShort(&anInputLine[j].r) ;
                    swapShort(&anInputLine[j].i) ;
                }
            }
            
            for(j = 0; j < xDim; j++) {
                if (isHalfPrecisionFloat) {
                    anOutputLine[j].r = half2SinglePrecision(&anInputLine[j].r) ;
                    anOutputLine[j].i = half2SinglePrecision(&anInputLine[j].i) ;
                }
                else {
                    anOutputLine[j].r = (float)anInputLine[j].r ;
                    anOutputLine[j].i = (float)anInputLine[j].i ;
                }
            }
            
            if(xDim != (int)fwrite(anOutputLine, sizeof(complexFloat), xDim, output->f))
                ase("Failed to write output file") ;
            
            if(i < yDim - 1) {
                if(fseek(input->f, offset, SEEK_CUR))
                    ase("Failed to fseek") ;
            }
            updateProgressCounterForIndex(counter, i) ;
        }
        updateProgressCounterForIndex(counter, i) ;
        printf("\n") ;
        
        savedDataCharacteristics = allocAKeyValuePair() ;
        setStringValForKeyIn(savedDataCharacteristics, "SLC data structure", "") ;
        setStringValForKeyIn(savedDataCharacteristics, "******************", "") ;
        setStringValForKeyIn(savedDataCharacteristics, "complex", "Data type") ;
        setStringValForKeyIn(savedDataCharacteristics, "float - float", "Data structure") ;
        if (isArchBigEndian()) {
            setStringValForKeyIn(savedDataCharacteristics, "Big endian", "Data byte order") ;
        }
        else
            setStringValForKeyIn(savedDataCharacteristics, "Low endian", "Data byte order") ;
        setIntValForKeyIn(savedDataCharacteristics, numberOfRangeSamples, "Number of columns") ;
        setIntValForKeyIn(savedDataCharacteristics, numberOfAzimuthLines, "Number of raws") ;
        writeParameterFileAtPath(savedDataCharacteristics, textFilePath) ;
        freeKeyValueList(savedDataCharacteristics) ;
        
        freeRawFileDescriptor(output) ;
    }
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    
    xmlFreeDoc(doc);
    xmlCleanupParser();
}
