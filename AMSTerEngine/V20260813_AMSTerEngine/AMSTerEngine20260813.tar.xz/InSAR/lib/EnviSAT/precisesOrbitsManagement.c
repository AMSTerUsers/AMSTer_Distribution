
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  precisesOrbitsManagement.c
//  EnvisatDataReader
//
//  Created by Dominique Derauw on 21/05/15.
//  Copyright (c) 2015 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "EnvisatPrecisesOrbits.h"

char *getDORISDirectory(keyValue *parametersList, int argc, const char *argv[])
{
    char *DORISDir ;
    
    if ((DORISDir = getenv("ENVISAT_PRECISES_ORBITS_DIR")) != NULL) {
        setStringValForKeyIn(parametersList, DORISDir, "EnviSAT precises orbits directory") ;
    }
    if ((DORISDir = getNextArgument(argc, argv, "-o")) != NULL) {
        setStringValForKeyIn(parametersList, DORISDir, "EnviSAT precises orbits directory") ;
    }
    DORISDir = getStringValForKeyIn(parametersList, "EnviSAT precises orbits directory") ;
    
    return (DORISDir) ;
}

void managePrecisesOrbitsFor(CSLImage *thisImage, char *auxiliaryDataDirectoryFilePath) {
    
    char *infoImageFilePath, *auxiliaryDataFilePath, *aPath  ;
    struct infoImage *info ;
    rawFileDescriptor *orbit ;
    
    /* Read infoImage text file for the image under concern */
    infoImageFilePath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
    info = readInfoImageFromTextFile(infoImageFilePath) ;
       
    /* Get orbit file path */
    if (info->sensorID == __ENVISAT__) {
        if((auxiliaryDataFilePath = findOrbitFilePath(info, auxiliaryDataDirectoryFilePath)) != NULL) {
            /* Reading of precise orbit state vectors and interpolation for temporal resampling these vectors */
            if ((orbit = openRawFileForReadingAtPath(auxiliaryDataFilePath)) == NULL) {
                ase("Failed to open precise orbit file for reading") ;
            }
            readPreciseOrbitStateVectors(orbit->f, info) ;
            
            /* The interpolated precise orbit state vectors are saved in a new infoImage file */
            aPath = initStringWith2Strings(infoImageFilePath, ".old") ;
            copyFileAtPathToPath(infoImageFilePath, aPath) ;
            free(aPath) ;
            
            /* We recompute the scene geolocation before saving */
            geolocateSceneOnEllipsoid(info, info->ellRef) ;
            
            freeRawFileDescriptor(orbit ) ;
            free(auxiliaryDataFilePath) ;
        }
    }
    saveInfoImage(info, infoImageFilePath) ;
    free(saveInfoKmlInDir(info, thisImage->infoDirectoryPath)) ;
    
    free(infoImageFilePath) ;
    freeInfoImage(info) ;
    
    return ;
}


void readPreciseOrbitStateVectors(FILE *f1, struct infoImage *info)
{
    MDSR_DORIS_PRECISE_ORBIT_STATE_VECTOR DORIS_StateVect ;
    int numberOfRecords, recordSize, centralRecordIndex, j ;
    double sensingStartTime, hh, mm, ss ;
    double h, m, s ;
    
    MAIN_PRODUCT_HEADER MPH ;
    auxSPH SPH ;
    DSD_TYPE DSD ;
    
    /* The precise orbit state vectors from DORIS are found in the DOR_VOR_AX auxiliary files */
    /* The reading of the file only starts after the Main Product Header, the Specific Product Header and the Data Set Descriptor record (1625 bytes) */
    fread(&MPH, 1, sizeof(MPH), f1) ;
    fread(&SPH, 1, sizeof(SPH), f1) ;
    fread(&DSD, 1, sizeof(DSD), f1) ;

    sscanf(DSD.Number_DSR, "%d", &numberOfRecords) ;
    sscanf(DSD.DSR_Size_Value, "%d", &recordSize) ;
    
    /* Sensing start time */
    sscanf(MPH.UTC_Start_Time, "%*12s%lf:%lf:%lf", &hh, &mm, &ss) ;
    sensingStartTime = 3600 * hh + 60 * mm + ss - 86400 ;
    
    /* Sensing stop time */
    sscanf(MPH.UTC_Stop_Time, "%*12s%lf:%lf:%lf", &hh, &mm, &ss) ;
    
    /* Central record index */
    centralRecordIndex = (int) roundf(((info->LPAT + info->FPAT) / 2. - sensingStartTime) / 60) ;
    if (centralRecordIndex < info->nVect / 2 || centralRecordIndex > numberOfRecords - info->nVect / 2 - 1) {
        ase("Not the correct DORIS file.\n") ;
    }
    
    /* Position file pointer to first required record */
    /* There is only one precise orbit state vector per minute while we want 5 vectors corresponding to the acquisition (which only last 15-16s) */
    /* Therefore, the vector at the time of the acquisition, the 2 vectors before and the 2 vectors after are taken and interpolated to determine 5 new state vectors */
    fseek(f1, recordSize * (centralRecordIndex - 2), SEEK_CUR) ;
    for (j = 0 ; j < info->nVect ; j++) {
        if(fread(&DORIS_StateVect, 1, sizeof(DORIS_StateVect), f1) != sizeof(DORIS_StateVect)) {
            ase("Failed to read precise Orbit State Vector \n") ;
        }
        
        sscanf(DORIS_StateVect.UTC_Orbit_State_Vector, "%*11s %lf:%lf:%lf.%*f", &h, &m, &s) ;
        info->S[j].t = h * 3600 + m * 60 + s ;
        
        sscanf(DORIS_StateVect.X_Position, "%lf", info->S[j].P) ;
        sscanf(DORIS_StateVect.Y_Position, "%lf", info->S[j].P + 1) ;
        sscanf(DORIS_StateVect.Z_Position, "%lf", info->S[j].P + 2) ;
        sscanf(DORIS_StateVect.X_Velocity, "%lf", info->S[j].V) ;
        sscanf(DORIS_StateVect.Y_Velocity, "%lf", info->S[j].V + 1) ;
        sscanf(DORIS_StateVect.Z_Velocity, "%lf", info->S[j].V + 2) ;
    }
}

void computeInterpolatedStateVectors(SLCImageInfo *info)
{
    int i ;
    double deltaAzimuth, azimuth0, azimuthPosition ;
    
    /* We recompute de state vectors on an azimuth interval 10% bigger than the azimuth data size */
    deltaAzimuth = 1 * info->azimuthDimension ;
    azimuth0 = (info->azimuthDimension - deltaAzimuth) / 2 ;
    deltaAzimuth /= (info->nVect - 1) ;
    for (i = 0; i < info->nVect; i++) {
        azimuthPosition = azimuth0 + i * deltaAzimuth ;
        calcStateVect(info->S + i, azimuthPosition, info) ;
        info->S[i].t = info->FPAT + info->lineTimeInterval * azimuthPosition ;
    }
    info->FVT = info->S[0].t ;
}

/* Compute day index of a given date, taking into accound leaps years, starting from 2002 */
int dayIndex(int YYYY, int MM, int DD)
{
    int dayIndex ;
    int i, daysPerMonth[13] ;
    
    daysPerMonth[1] = daysPerMonth[3] = daysPerMonth[5] = daysPerMonth[7] = daysPerMonth[8] = daysPerMonth[10] = daysPerMonth[12] = 31 ;
    daysPerMonth[4] = daysPerMonth[6] = daysPerMonth[9] = daysPerMonth[11] = 30 ;
    daysPerMonth[2] = (YYYY == 2004 || YYYY == 2008 || YYYY == 2012)? 29 : 28 ;

    dayIndex = 365 * (YYYY - 2002) ;
    dayIndex += (YYYY > 2004)? 1 : 0 ;
    dayIndex += (YYYY > 2008)? 1 : 0 ;
    
    for (i = 1; i < MM; i++) {
        dayIndex += daysPerMonth[i] ;
    }
    
    dayIndex += DD ;
    
    return (dayIndex) ;
}


char *findOrbitFilePath(SLCImageInfo *info, char *DORISDir)
{
    char *subDirectoryPath, **subDirectoryContent, **directoryContent, *orbitDir, *orbitFile = NULL ;
    int i, isFileFound, numberOfEntries ;
    int DD, MM, YYYY, numberOfDirectoryEntries ;
    int minDayIndex, maxDayIndex, currentDayIndex ;

    
    /* If the path to DORIS Files directory is given  */
    if (isDir(DORISDir)) {
        /* Verify that the given directory is either a /vor_gdr subdirectory or the upper level DORIS one */
        if (strstr(DORISDir, "vor_gdr") == NULL) {
            directoryContent = getDirectoryContentAtPath(DORISDir, &numberOfDirectoryEntries) ;
            /* Look for /vod_gdr_d subdirectory */
            for (i = 0; i < numberOfDirectoryEntries; i++) {
                if (!strncmp(directoryContent[i], "vor_gdr_d", 9)) {
                    break ;
                }
            }
            /* if not found, look for vod_gdr_c subdirectory */
            if (i == numberOfDirectoryEntries) {
                for (i = 0; i < numberOfDirectoryEntries; i++) {
                    if (!strncmp(directoryContent[i], "vor_gdr_c", 9)) {
                        break ;
                    }
                }
            }
            /* if none are found, return */
            if (i == numberOfDirectoryEntries) {
                printf("DORIS directory not found\nPrecise orbit not considered\n") ;
                return (NULL) ;
            }
            
            /* if found, append subdirectory name to get full path to precises orbits directory */
            orbitDir = initStringWith3Strings(DORISDir, "/", directoryContent[i]) ;
            
            /* Free directory entries */
            for (i = 0; i < numberOfDirectoryEntries; i++) {
                free(directoryContent[i]) ;
            }
            free(directoryContent) ;
        }
        else {
            orbitDir = initStringWithString(DORISDir) ;
        }
        
        /* Determine DORIS precise orbit directory name corresponding to acquisition date */
        /* Required file should be in the YYYYMM subdirectory, except for the last day of the month wich is in the next subdirectory */
        subDirectoryPath = allocStringOfLength(strlen(orbitDir) + 8) ;
        sscanf(info->acquisitionDate, "%4d%2d%2d", &YYYY, &MM, &DD) ;
        currentDayIndex = dayIndex(YYYY, MM, DD) ;
        switch (MM) {
            case 1:
                if (DD == 31) {
                    MM++ ;
                }
                break;
                
            case 2:
                if (YYYY == 2004 ||YYYY == 2008 || YYYY == 2012) {
                    if (DD == 29) {
                        MM++ ;
                    }
                }
                else {
                    if (DD == 28) {
                        MM++ ;
                    }
                }
                break;

            case 3:
                if (DD == 31) {
                    MM++ ;
                }
                break;
                
            case 4:
                if (DD == 30) {
                    MM++ ;
                }
                break;
                
            case 5:
                if (DD == 31) {
                    MM++ ;
                }
                break;
                
            case 6:
                if (DD == 30) {
                    MM++ ;
                }
                break;
                
            case 7:
                if (DD == 31) {
                    MM++ ;
                }
                break;
                
            case 8:
                if (DD == 31) {
                    MM++ ;
                }
                break;
                
            case 9:
                if (DD == 30) {
                    MM++ ;
                }
                break;
                
            case 10:
                if (DD == 31) {
                    MM++ ;
                }
                break;
                
            case 11:
                if (DD == 30) {
                    MM++ ;
                }
                break;
                
            case 12:
                if (DD == 31) {
                    MM = 1 ;
                    YYYY ++ ;
                }
                break;
                
            default:
                break;
        }
        sprintf(subDirectoryPath, "%s/%4d%02d", orbitDir, YYYY, MM) ;
        
        /* Verify the required directory exists */
        if(!isDir(subDirectoryPath)) {
            sprintf(ertex, "Required DORIS subdirectory does not exists:\n%s\n", subDirectoryPath) ;
            printf("%s", ertex) ;
            return (NULL) ;
        }
        
        /* If there is at least one entry in the subdirectory, we look at the content */
        if(!(numberOfEntries = getNumberOfDirectoryEntriesAtPath(subDirectoryPath))) {
            printf("No precise orbit available in given DORIS directory") ;
            return (NULL) ;
        }
        subDirectoryContent = getDirectoryEntriesAtPath(subDirectoryPath) ;
        
        isFileFound = 0 ;
        i = 0;
        
        while(!(isFileFound) && i < numberOfEntries) {
            sscanf(subDirectoryContent[i], "%*30s%4d%2d%2d", &YYYY, &MM, &DD) ;
            minDayIndex = dayIndex(YYYY, MM, DD) ;
            sscanf(subDirectoryContent[i], "%*46s%4d%2d%2d", &YYYY, &MM, &DD) ;
            maxDayIndex = dayIndex(YYYY, MM, DD) ;
            if (currentDayIndex > minDayIndex && currentDayIndex < maxDayIndex) {
                isFileFound = 1 ;
                orbitFile = initStringWith3Strings(subDirectoryPath, "/", subDirectoryContent[i]) ;
            }
            i++ ;
        }
        
        /* Free subdirectory entries */
        for (i = 0; i < numberOfEntries; i++) {
            free(subDirectoryContent[i]) ;
        }
        free(subDirectoryContent) ;
        
        if(!isFileFound)
            ase("Failed to find the corresponding DORIS file") ;
        
        free(subDirectoryPath) ;
        free(orbitDir) ;
    }
    
    return (orbitFile) ;

}
