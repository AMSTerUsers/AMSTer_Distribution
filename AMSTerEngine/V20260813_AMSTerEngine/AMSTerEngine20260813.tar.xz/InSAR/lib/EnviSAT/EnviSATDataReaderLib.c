
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  EnviSATDataReaderLib.c
//  EnviSATDataReader
//
//  Created by Dominique Derauw on 30/06/16.
//
//

#include "EnviSATDataReaderLib.h"

void readROI_PACData(keyValue *parametersList, int argc, const char * argv[])
{
    char aPath[_MAX_PATH_LENGTH_] ;
    char *DORISDir, **directoryContent, *ROIPACDataDirectory ;
    char *inputFilePath, *outputFilePath;
    int numberOfEntries, i  ;
    SLCImageInfo *info ;
    CSLImage *thisImage ;
    
    /* Create CSL directory structure at indicated path */
    thisImage = createCSLDirectoryStructureAtPath(getStringValForKeyIn(parametersList, "Path to output image in CSL format"), __ENVISAT__) ;
    
    ROIPACDataDirectory = getStringValForKeyIn(parametersList, "ROIPAC data directory") ;
    info = createInfoImageFromROI_PAC_RSCFile(ROIPACDataDirectory) ;
    sprintf(aPath, "%s/SLCImageInfo.txt", thisImage->infoDirectoryPath) ;
    saveInfoImage(info, aPath) ;
    freeInfoImage(info) ;
    
    if ((DORISDir = getDORISDirectory(parametersList, argc, argv)) != NULL) {
        managePrecisesOrbitsFor(thisImage, DORISDir) ;
    }
    else {
        printf("No precise orbit available for correct ROI_PAC EnviSAT data reading\n Take care! No state vectors available\n") ;
    }
    
    /* Get ROI_PAC directory path */
    inputFilePath = getStringValForKeyIn(parametersList, "Path to EnviSAT data file") ;
    
    directoryContent = getDirectoryContentAtPath(inputFilePath, &numberOfEntries) ;
    for (i = 0; i < numberOfEntries; i++) {
        if (!strncmp(getPointerToLastFileExtensionInPath(directoryContent[i]), "slc", 3)) {
            break ;
        }
    }
    if (i == numberOfEntries) {
        ase("SLC file not found in ROI_PAC directory") ;
    }
    
    /* Simple copy */
    inputFilePath = initStringWith3Strings(inputFilePath, "/", directoryContent[i]) ;
    outputFilePath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", info->polMode) ;
    
    copyFileAtPathToPath(inputFilePath, outputFilePath) ;
    
    freeInfoImage(info) ;
}

void copyEnviSATHeadersToHeadersDirectory(char *inputPath, CSLImage *thisImage, ENVISAT_HEADER *header)
{
    char *buffer ;
    char destinationPath[_MAX_PATH_LENGTH_] ;
    long headerLength ;
    rawFileDescriptor *inputHeader, *outputHeader ;
    
    thisImage->numberOfHeaderFiles = 1 ;
    thisImage->headerFileNames = (char **)malloc(sizeof(char *) * thisImage->numberOfHeaderFiles) ;
    thisImage->headerFileNames[0] = allocStringOfLength(15) ;
    sprintf(thisImage->headerFileNames[0], "%s", "EnviSAT_Headers") ;
    
    /* Read and write EnviSAT header */
    sscanf(header->Specific_Product.DSD[10].DS_Offset_Value, "%ld", &headerLength) ;
    inputHeader = openRawFileForReadingAtPath(inputPath) ;
    sprintf(destinationPath, "%s/%s", thisImage->headersDirectoryPath, thisImage->headerFileNames[0]) ;
    outputHeader = openRawFileForWritingAtPath(destinationPath) ;
    buffer = malloc(headerLength) ;
    fread(buffer, headerLength, 1, inputHeader->f) ;
    fwrite(buffer, headerLength, 1, outputHeader->f) ;
    
    free(buffer) ;
    freeRawFileDescriptor(inputHeader) ;
    freeRawFileDescriptor(outputHeader) ;
}


void createInfoTextFileFromHeaderFor(CSLImage *thisImage, ENVISAT_HEADER *header)
{
    char aPath[_MAX_PATH_LENGTH_] ;
    SLCImageInfo *info ;
    
    info  = readInfoImageFromEnvisatHeader(header) ;
    sprintf(aPath, "%s/SLCImageInfo.txt", thisImage->infoDirectoryPath) ;
    saveInfoImage(info, aPath) ;
}


void readAndConvertEnviSATSLCDataInto(CSLImage *thisImage, ENVISAT_HEADER *header, char *EnviSATFilePAth, int imageIndex)
{
    char *aPath, *textFilePath, polString[3] ;
    int i, j, numberOfDataRecords, numberOfSamplesPerLine ;
    long dataRecordLength, dataRecordHeaderLength, fileOffset ;
    rawFileDescriptor *inputFile, *outputFile ;
    complexShort	*cs ;
    complexFloat	*cf ;
    progressCounter *aCounter ;
    keyValue *savedDataCharacteristics ;
    
    dataRecordHeaderLength = sizeof(MDS_HEADER_CHAR) ;
    
    sscanf(header->Specific_Product.DSD[10 + imageIndex].Number_DSR, "%d", &numberOfDataRecords) ;
    sscanf(header->Specific_Product.DSD[10 + imageIndex].DS_Offset_Value, "%ld", &fileOffset) ;
    sscanf(header->Specific_Product.DSD[10 + imageIndex].DSR_Size_Value, "%ld", &dataRecordLength) ;
    numberOfSamplesPerLine = (int)(dataRecordLength - dataRecordHeaderLength) / 4 ;
    
    inputFile = openRawFileForReadingAtPath(EnviSATFilePAth) ;
    fseek(inputFile->f, fileOffset, SEEK_SET) ;
    
    if(imageIndex)
        sprintf(polString, "%.1s%.1s", &header->Specific_Product.Polarization_MD2[0], &header->Specific_Product.Polarization_MD2[2]) ;
    else
        sprintf(polString, "%.1s%.1s", &header->Specific_Product.Polarization_MD1[0], &header->Specific_Product.Polarization_MD1[2]) ;
    
    aPath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", polString) ;
    textFilePath = initStringWith4Strings(thisImage->infoDirectoryPath, "/", getFileNameFromPath(aPath), ".txt") ;
    outputFile = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;
    
    cs = vectorComplexShort(0, numberOfSamplesPerLine - 1) ;
    cf = vectorComplexFloat(0, numberOfSamplesPerLine - 1) ;
    aCounter = initProgressCounterWithMinMaxValue(0, numberOfDataRecords - 1) ;
    for(i = 0 ; i < numberOfDataRecords ; i++) {
        fseek(inputFile->f, dataRecordHeaderLength, SEEK_CUR) ;
        fread ((complexShort *)cs, sizeof(complexShort), numberOfSamplesPerLine, inputFile->f) ;
        
        for(j = 0; j < numberOfSamplesPerLine ; j++) {
            if(!isArchBigEndian()) {
                swapComplexShort(&cs[j]) ;
            }
            cf[j].r = (float)cs[j].r ;
            cf[j].i = (float)cs[j].i ;
        }
        
        fwrite((complexFloat *)cf, sizeof(complexFloat), numberOfSamplesPerLine, outputFile->f) ;
        updateProgressCounterForIndex(aCounter, i) ;
    }
    
    freeVectorComplexShort(cs, 0) ;
    freeVectorComplexFloat(cf, 0) ;
    freeRawFileDescriptor(inputFile) ;
    freeRawFileDescriptor(outputFile) ;
    freeProgressCounter(aCounter) ;
    
    savedDataCharacteristics = allocAKeyValuePair() ;
    setStringValForKeyIn(savedDataCharacteristics, "SLC data structure", "") ;
    setStringValForKeyIn(savedDataCharacteristics, "******************", "") ;
    setStringValForKeyIn(savedDataCharacteristics, "complex", "Data type") ;
    setStringValForKeyIn(savedDataCharacteristics, "float - float", "Data structure") ;
    if (isArchBigEndian()) {
        setStringValForKeyIn(savedDataCharacteristics, "Big endian", "Data byte order") ;
    }
    else
        setStringValForKeyIn(savedDataCharacteristics, "Low endian", "Data byte order") ;
    setIntValForKeyIn(savedDataCharacteristics, numberOfSamplesPerLine, "Number of columns") ;
    setIntValForKeyIn(savedDataCharacteristics, numberOfDataRecords, "Number of raws") ;
    writeParameterFileAtPath(savedDataCharacteristics, textFilePath) ;
    freeKeyValueList(savedDataCharacteristics) ;
}

