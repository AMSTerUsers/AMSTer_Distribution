
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include "exCal.h"
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) 2005 Dominique Derauw. All rights reserved.
 *
 */

/*
int main (int argc, const char * argv[]) {
    char	fileAcces[256] ;
    int		i ;
    struct exCal	*exCal ;
    
    float	alpha, alphaRef ;
    
    exCal = allocExternalCalibrationObject() ;
    
    sprintf(fileAcces, "/Users/dd/Documents/Saocom/ENVISAT/ASAR_ADF_3Mar03/ASA_XCA_AXVIEC20021217_150852_2") ;
    readExternalCalibrationFile(exCal, fileAcces) ;
    
    for(i=0; i<=200; i++) printf("%d\t%f\n", i, exCal->gads->twoWayAntElPatGainIS[1][0][i]) ;
    
    alphaRef = exCal->gads->refElevationAngleIS[1] ;
    alpha = alphaRef - 3.1 ;
    printf("Approx : \nalpha = %f\tgain = %f\n", alpha, approxAntennaGainForElevationAngle(alpha, exCal->gads->twoWayAntElPatGainIS[1][0], alphaRef)) ;
    alpha = alphaRef + 2.71 ;
    printf("Approx : \nalpha = %f\tgain = %f\n", alpha, approxAntennaGainForElevationAngle(alpha, exCal->gads->twoWayAntElPatGainIS[1][0], alphaRef)) ;
    
    return 0;
}
*/

/* Approx linéaire du diagramme d'antenne pour un angle d'élévation donné */
float approxAntennaGainForElevationAngle(float elevationAngle, float *antennaPattern, float refAngle) 
{
    int	i0 ;
    float	a, gain ;
    
    a = (elevationAngle - refAngle + 5.) / .05 ;
    i0 = floor(a) ;
    a -= i0 ;
    gain = antennaPattern[i0] + (antennaPattern[i0 + 1] - antennaPattern[i0]) * a ;
    
    return gain ;
}

/* Allocation d'un objet "exCal" contenant les données de calibration externe ainsi que toutes les fonctions afférentes */
struct exCal *allocExternalCalibrationObject()
{
    struct exCal	*exCal ;
    
    if((exCal = malloc(sizeof(struct exCal))) == NULL) {
        perror("Erreur d'allocation d'un objet Calibration Externe") ;
        exit(-1) ;
    }
    
    if((exCal->mph = malloc(sizeof(MAIN_PRODUCT_HEADER))) == NULL) {
        perror("Erreur d'allocation du MAIN_PRODUCT_HEADER") ;
        exit(-1) ;
    }

    if((exCal->sph = malloc(sizeof(sphXCA))) == NULL) {
        perror("Erreur d'allocation du SPECIFIC_PRODUCT_HEARDER") ;
        exit(-1) ;
    }

    if((exCal->gads = malloc(sizeof(gadsXCA))) == NULL) {
        perror("Erreur d'allocation du Global Annotation Data Set") ;
        exit(-1) ;
    }

    return exCal ;
}

/* Lecture du fichier de donnée de calibration externe */
void readExternalCalibrationFile(struct exCal *exCal, char *fileLocation)
{
    FILE	*fIn ;
    
    if((fIn = fopen(fileLocation, "r")) == NULL) {
        perror("Erreur d'ouverture du fichier de calibration externe") ;
        exit(-1) ;
    }
        
    fread(exCal->mph, sizeof(MAIN_PRODUCT_HEADER), 1, fIn) ;
    fread(exCal->sph, sizeof(sphXCA), 1, fIn) ;
    if(sizeof(gadsXCA_Char) == sizeof(gadsXCA))
        fread(exCal->gads, sizeof(gadsXCA), 1, fIn) ;
    else
        readFromCharStructure(exCal, fIn) ;
    
    fclose(fIn) ;
}

/* Lecture du Global Annotation Data Set sur base de la structure CHAR */
/* Nécessaire si l'alignement des bytes sur la plateforme utilisée gén√®re une structure non continue en mémoire */
void readFromCharStructure(struct exCal *exCal, FILE *fIn) 
{
    int 		i, iFaisceau, iPol ;
    gadsXCA_Char	*gadsChar ;

    if((gadsChar = malloc(sizeof(gadsXCA_Char))) == NULL) {
        perror("Erreur d'allocation du gadsXCA_Char") ;
        exit(-1) ;
    }
    
    fread(gadsChar, sizeof(gadsXCA_Char), 1, fIn) ;
    memcpy(&exCal->gads->timeOfCreation.days, &gadsChar->timeOfCreation[0], 4) ;
    memcpy(&exCal->gads->timeOfCreation.seconds, &gadsChar->timeOfCreation[4], 4) ;
    memcpy(&exCal->gads->timeOfCreation.microseconds, &gadsChar->timeOfCreation[8], 4) ;
    memcpy(&exCal->gads->DSRLength, &gadsChar->DSRLength[0], 4) ;
    for(i=0; i<7; i++) {
        memcpy(&exCal->gads->XCalScalingFactor_IM_SLC_HH[i], &gadsChar->XCalScalingFactor_IM_SLC_HH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_IM_SLC_VV[i], &gadsChar->XCalScalingFactor_IM_SLC_VV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_IM_PRI_HH[i], &gadsChar->XCalScalingFactor_IM_PRI_HH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_IM_PRI_VV[i], &gadsChar->XCalScalingFactor_IM_PRI_VV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_IM_GEC_HH[i], &gadsChar->XCalScalingFactor_IM_GEC_HH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_IM_GEC_VV[i], &gadsChar->XCalScalingFactor_IM_GEC_VV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_IM_MED_HH[i], &gadsChar->XCalScalingFactor_IM_MED_HH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_IM_MED_VV[i], &gadsChar->XCalScalingFactor_IM_MED_VV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_SLC_HH[i], &gadsChar->XCalScalingFactor_AP_SLC_HH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_SLC_VV[i], &gadsChar->XCalScalingFactor_AP_SLC_VV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_SLC_HV[i], &gadsChar->XCalScalingFactor_AP_SLC_HV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_SLC_VH[i], &gadsChar->XCalScalingFactor_AP_SLC_VH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_PRI_HH[i], &gadsChar->XCalScalingFactor_AP_PRI_HH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_PRI_VV[i], &gadsChar->XCalScalingFactor_AP_PRI_VV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_PRI_HV[i], &gadsChar->XCalScalingFactor_AP_PRI_HV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_PRI_VH[i], &gadsChar->XCalScalingFactor_AP_PRI_VH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_GEC_HH[i], &gadsChar->XCalScalingFactor_AP_GEC_HH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_GEC_VV[i], &gadsChar->XCalScalingFactor_AP_GEC_VV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_GEC_HV[i], &gadsChar->XCalScalingFactor_AP_GEC_HV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_GEC_VH[i], &gadsChar->XCalScalingFactor_AP_GEC_VH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_MED_HH[i], &gadsChar->XCalScalingFactor_AP_MED_HH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_MED_VV[i], &gadsChar->XCalScalingFactor_AP_MED_VV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_MED_HV[i], &gadsChar->XCalScalingFactor_AP_MED_HV[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_AP_MED_VH[i], &gadsChar->XCalScalingFactor_AP_MED_VH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_WM_HH[i], &gadsChar->XCalScalingFactor_WM_HH[i][0], 4) ;
        memcpy(&exCal->gads->XCalScalingFactor_WM_VV[i], &gadsChar->XCalScalingFactor_WM_VV[i][0], 4) ;
    }
    memcpy(&exCal->gads->XCalScalingFactor_WS_HH, &gadsChar->XCalScalingFactor_WS_HH[0], 4) ;
    memcpy(&exCal->gads->XCalScalingFactor_WS_VV, &gadsChar->XCalScalingFactor_WS_VV[0], 4) ;
    memcpy(&exCal->gads->XCalScalingFactor_GM_HH, &gadsChar->XCalScalingFactor_GM_HH[0], 4) ;
    memcpy(&exCal->gads->XCalScalingFactor_GM_VV, &gadsChar->XCalScalingFactor_GM_VV[0], 4) ;
    
    for(iFaisceau = 0; iFaisceau < 4; iFaisceau++)
        memcpy(&exCal->gads->refElevationAngleIS[iFaisceau], &gadsChar->refElevationAngleIS[iFaisceau][0], 4) ;
    memcpy(&exCal->gads->refElevationAngleSS1, &gadsChar->refElevationAngleSS1[0], 4) ;
    
    for(iFaisceau = 0; iFaisceau < 7; iFaisceau++) {
        for(iPol = 0; iPol < 4; iPol++) {
            for(i=0; i<201; i++)
                memcpy(&exCal->gads->twoWayAntElPatGainIS[iFaisceau][iPol][i], &gadsChar->twoWayAntElPatGainIS[iFaisceau][iPol][i][0], 4) ;
        }
    }
    for(i=0; i<201; i++) {
        memcpy(&exCal->gads->twoWayAntElPatGainSS1HH[i], &gadsChar->twoWayAntElPatGainSS1HH[i][0], 4) ;
        memcpy(&exCal->gads->twoWayAntElPatGainSS1VV[i], &gadsChar->twoWayAntElPatGainSS1VV[i][0], 4) ;
        memcpy(&exCal->gads->twoWayAntElPatGainSS1HV[i], &gadsChar->twoWayAntElPatGainSS1HV[i][0], 4) ;
        memcpy(&exCal->gads->twoWayAntElPatGainSS1VH[i], &gadsChar->twoWayAntElPatGainSS1VH[i][0], 4) ;
    }

    memcpy(&exCal->gads->spare1[0], &gadsChar->spare1[0], 32) ;
    free(gadsChar) ;
}
