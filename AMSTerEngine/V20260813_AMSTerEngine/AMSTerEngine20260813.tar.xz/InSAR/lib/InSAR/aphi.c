
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* aphi.c *//* approximation locale de phase topographique *//* *  Created by Dominique Derauw a long time ago. *  Copyright (c) 1995 Dominique Derauw. All rights reserved. * */#include "aphi.h"/* ----------------- Approximation du plan local de phase ----------------- */float	aphi(float **Mphi, int *N, int *y, int *x){	int	k, l, m, s, indx, indy, x0, y0 ;	float	phi1, phi2 ;	double	phim, dphi, phi1d, phi2d ;	x0 = *x + *N /2 ;	y0 = *y + *N /2 ;	indx = indy = 0 ;	s = -1 ;	phi1 = Mphi[y0][x0] ;	phim = phi1d = (double)Mphi[y0][x0] ;	for(k=0; k< *N - 1; k++)	{		s*=-1 ;		for(l=0; l<2; l++)		{			for(m=0; m<k+1; m++)			{				indy += (1-l)*s ;				indx += l*s ;				phi2 = Mphi[y0 + indy][x0 + indx] ;				dphi = dephi(&phi2, &phi1) ;				phi2d = phi1d + dphi ;				phim += phi2d ;				phi1 = phi2 ;				phi1d = phi2d ;			}		}	}	s *= -1 ;	for(k=0; k< *N - 1; k++)	{		indy += s ;		phi2 = Mphi[y0 + indy][x0 + indx] ;		dphi = dephi(&phi2, &phi1) ;		phi2d = phi1d + dphi ;		phim += phi2d ;		phi1 = phi2 ;		phi1d = phi2d ;	}	phim /= (double)(*N * *N) ;   	return((float)phim) ;}/* Same function than above, slightly revisited */float squareSpiralPhaseUnwrapping(float **M, int N, int y0, int x0){    int	k, l, m, s, dX, dY, x1, y1 ;	float	unwrappedPhase, averagePhase ;    	x1 = x0 ;    y1 = y0 ;	s = -1 ;	unwrappedPhase = averagePhase = M[y0][x0] ;	for(k = 0; k <  N - 1; k++) {		s *= -1 ;		for(l = 0; l < 2; l++) {            dX = l * s ;            dY = (1 - l) * s ;			for(m = 0; m < k + 1; m++) {				x1 += dX ;				y1 += dY ;                unwrappedPhase += unwrappedPhaseGap(M[y1][x1], M[y0][x0]) ;                averagePhase += unwrappedPhase ;                x0 = x1 ;                y0 = y1 ;			}		}	}	s *= -1 ;	for(k = 0; k < N - 1; k++) {		y1 += s ;        unwrappedPhase += unwrappedPhaseGap(M[y1][x1], M[y0][x0]) ;        averagePhase += unwrappedPhase ;        y0 = y1 ;	}	averagePhase /= (N * N) ;    	return(averagePhase) ;}