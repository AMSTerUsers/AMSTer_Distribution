
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  snaphuManagement.c
//  phaseUnwrapping
//
//  Created by Dominique Derauw on 21/02/17.
//
//

#include "snaphuManagement.h"

int snaphuManagement(CSVStruct *csv, InSARParametersStruct *pInSAR)
{
    char *confFilePath, *snaphuZoneMap, *snaphuMask = NULL ;
    char *workingDirectory ;
    char *commandLine ;
    char *interfPath, *maskedCohPath, *maskPath = NULL ;
    char *fullFilePath ;
    char *detPhUnPhaseComponent ;
    int maxSnaphuRuns = 2 ;
    rawFileDescriptor *interfFile ;
    CSVStruct *commandComponents ;
    
    defoOrTopo(pInSAR) ;

    interfFile = selectInterferogram(pInSAR) ;
    interfPath = initStringWithString(interfFile->accessPath) ;
    if (isArgumentPresentInCSV(csv, "-init")) {
        printf("Creating snaphu configuration file\n") ;
        createSnaphuConfFile(pInSAR, interfPath) ;
        exit(0) ;
    }

    confFilePath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/snaphu.conf") ;
    if (!fileExistsAtPath(confFilePath)) {
        createSnaphuConfFile(pInSAR, interfPath) ;
    }
    else {
        fullFilePath = expandEnvironmentVariablesInPath(interfPath) ;
        updateSnaphuConfFile(confFilePath, "INFILE", fullFilePath) ;
        free(fullFilePath) ;
        fullFilePath = expandEnvironmentVariablesInPath((pInSAR->dephi).filePath) ;
        updateSnaphuConfFile(confFilePath, "OUTFILE", fullFilePath) ;
        free(fullFilePath) ;
        fullFilePath = expandEnvironmentVariablesInPath(pInSAR->coh.filePath) ;
        updateSnaphuConfFile(confFilePath, "CORRFILE", fullFilePath) ;
        free(fullFilePath) ;
    }
    
    if (pInSAR->flag & _WITH_MASKING_) {
    printf("\t---> thresholdedSlantRangeMask is considered\n") ;
    /* Mask management */
        maskedCohPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/maskedCoherence") ;
        maskFloatFileWithValue(pInSAR->coh.filePath, pInSAR->thresholdedSlantRangeMask, maskedCohPath, 0, 0b00000001) ;
        updateSnaphuConfFile(confFilePath, "CORRFILE", maskedCohPath) ;
    }

    workingDirectory = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts") ;
    chdir(workingDirectory) ;

    commandComponents = addStringValInCSVStruct("snaphu -f ", NULL) ;
    commandComponents = addStringValInCSVStruct(confFilePath, commandComponents) ;
    
    if (pInSAR->flag & _SAVE_SNAPHU_ZONEMAP_) {
        snaphuZoneMap = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/snaphuZoneMap") ;
        commandComponents = addStringValInCSVStruct(" -g ", commandComponents) ;
        commandComponents = addStringValInCSVStruct(snaphuZoneMap, commandComponents) ;
        free(snaphuZoneMap) ;
    }
    if (pInSAR->flag & _WITH_MASKING_) {
        snaphuMask = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/snaphuMask") ;
        invertBinaryMask(pInSAR->thresholdedSlantRangeMask, snaphuMask) ;
        commandComponents = addStringValInCSVStruct(" -M ", commandComponents) ;
        commandComponents = addStringValInCSVStruct(snaphuMask, commandComponents) ;
    }
    commandLine = getStringFromCSV(commandComponents) ;
    
    
    /* As observed on ASUS systems running Linux Mint, snaphu may crash. */
    /* Either without notice (SIGSEGV) or aborting with the following error : ((Maximum flow) * NSHORTCYCLE) too large.
 */
    /* Therefore, this is a trick to relaunch snaphu expecting it will work next time... */
    /* Since I am not sure aborting will lead to a -1 return of system(), i prefer testing the existence of the unwrapped file */
//    if (maxSnaphuRuns-- && (system(commandLine) == -1)) {
    system(commandLine) ;
    while (--maxSnaphuRuns && !fileExistsAtPath((pInSAR->dephi).filePath)) {
        printf("!!! !!!!!!!!!!!!!!!!!!!!! !!!\n") ;
        printf("!!! snaphu crash detected !!!\n") ;
        printf("!!! !!!!!!!!!!!!!!!!!!!!! !!!\n") ;
        printf("\t--->Relaunching snaphu.......\n\n") ;
        system(commandLine) ;
    }
    
    if (pInSAR->flag & _WITH_MASKING_) {
        free(maskPath) ;
        unlink(snaphuMask) ;
        unlink(maskedCohPath) ;
        free(snaphuMask) ;
        free(maskedCohPath) ;
    }
    free(confFilePath) ;
    free(commandLine) ;
    
    if (maxSnaphuRuns) {
        (pInSAR->dephi).lena = (pInSAR->srDEM).lena = (pInSAR->interf).lena ;
        (pInSAR->dephi).lenr = (pInSAR->srDEM).lenr = (pInSAR->interf).lenr ;
        (pInSAR->cohder).lenr = (pInSAR->cohder).lena = 0 ;
        
        /* If detPhUn preprocessing, add the two phase components */
        if (pInSAR->flag & _DETPHUN_) {
            detPhUnPhaseComponent = initStringWith2Strings(pInSAR->dephi.filePath, ".detPhUn") ;
            floatFilesArithmetics(pInSAR->dephi.filePath, "+", 0, detPhUnPhaseComponent, NULL) ;
            
            /* Unlink detphun phase component */
            unlink(detPhUnPhaseComponent) ;
            free(detPhUnPhaseComponent) ;
            
            /* Unlink intermediate phase residue */
            closeRawFile(interfFile) ;
            unlink(interfPath) ;
        }
        free(interfPath) ;
        return(1) ;
    }
    else {
        free(interfPath) ;
        return(0) ;
    }
}


void createSnaphuConfFile(InSARParametersStruct *pInSAR, char *interfPath)
{
    char *outputPath ;
    char *fullFilePath ;
    rawFileDescriptor *conf ;
    
    outputPath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/snaphu.conf") ;
    conf = openRawFileForWritingAtPath(outputPath) ;
    
    fprintf(conf->f, "# ######################### #\n") ;
    fprintf(conf->f, "# snaphu configuration file #\n") ;
    fprintf(conf->f, "# ######################### #\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "#############################################\n") ;
    fprintf(conf->f, "# File input and output and runtime options #\n") ;
    fprintf(conf->f, "#############################################\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Input file name\n") ;
    fprintf(conf->f, "INFILE\t%s\n", interfPath) ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Input file line length\n") ;
    fprintf(conf->f, "LINELENGTH\t%d\n", pInSAR->interf.lenr) ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Output file name\n") ;
    fullFilePath = expandEnvironmentVariablesInPath(pInSAR->dephi.filePath) ;
    fprintf(conf->f, "OUTFILE\t%s\n", fullFilePath) ;
    free(fullFilePath) ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Amplitude file name(s)\n") ;
    fullFilePath = expandEnvironmentVariablesInPath(pInSAR->mod1.filePath) ;
    fprintf(conf->f, "AMPFILE\t%s\n", fullFilePath) ;
    free(fullFilePath) ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Correlation file name\n") ;
    fullFilePath = expandEnvironmentVariablesInPath(pInSAR->coh.filePath) ;
    fprintf(conf->f, "CORRFILE\t%s\n", fullFilePath) ;
    free(fullFilePath) ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Statistical-cost mode (TOPO, DEFO, SMOOTH, or NOSTATCOSTS)\n") ;
    if (pInSAR->flag & _TOPO_) {
        fprintf(conf->f, "STATCOSTMODE\tTOPO\n") ;
    }
    else {
        fprintf(conf->f, "STATCOSTMODE\tDEFO\n") ;
    }
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Initialize-only mode (TRUE or FALSE)\n") ;
    fprintf(conf->f, "INITONLY\tFALSE\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Algorithm used for initialization of wrapped phase values [MST] [MCF]. \n") ;
    fprintf(conf->f, "INITMETHOD\tMCF\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "#Verbose-output mode (TRUE or FALSE)\n") ;
    fprintf(conf->f, "VERBOSE\tTRUE\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "################\n") ;
    fprintf(conf->f, "# File formats #\n") ;
    fprintf(conf->f, "################\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Input file format\n") ;
    fprintf(conf->f, "INFILEFORMAT\tFLOAT_DATA\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Output file format\n") ;
    fprintf(conf->f, "OUTFILEFORMAT\tFLOAT_DATA\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Amplitude or power file format\n") ;
    fprintf(conf->f, "AMPFILEFORMAT\tFLOAT_DATA\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "# Correlation file format\n") ;
    fprintf(conf->f, "CORRFILEFORMAT\tFLOAT_DATA\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "###############################\n") ;
    fprintf(conf->f, "# SAR and geometry parameters #\n") ;
    fprintf(conf->f, "###############################\n") ;
    updateOrbitalParametersForPoint((pInSAR->sup.Sdra - pInSAR->sup.Sgra)/2, (pInSAR->sup.Shaz - pInSAR->sup.Sbaz)/2, pInSAR) ;
    fprintf(conf->f, "ORBITRADIUS\t%lf\n", pInSAR->S1.S) ;
    fprintf(conf->f, "EARTHRADIUS\t%lf\n", pInSAR->masterInfo->EarthRadiusAtSceneCenter) ;
    fprintf(conf->f, "BASELINE\t%lf\n", pInSAR->B.B) ;
    fprintf(conf->f, "BASELINEANGLE_RAD\t%lf\n", pInSAR->B.theta) ;
    if (pInSAR->isBistaticPair) {
        fprintf(conf->f, "TRANSMITMODE\tSINGLEANTENNATRANSMIT\n") ;
    }
    else {
        fprintf(conf->f, "TRANSMITMODE\tREPEATPASS\n") ;
    }
    fprintf(conf->f, "NEARRANGE\t%lf\n", pInSAR->ima1.z0) ;
    fprintf(conf->f, "DR\t%lf\n", pInSAR->rad.rangeResolutionCell * pInSAR->red.Fra) ;
    fprintf(conf->f, "DA\t%lf\n", pInSAR->rad.azimuthResolutionCell * pInSAR->red.Faz) ;
    fprintf(conf->f, "RANGERES\t%lf\n", 0.638 * c0 / 2. / pInSAR->masterInfo->rangeBandwidth) ;
    fprintf(conf->f, "AZRES\t%lf\n", pInSAR->masterInfo->azimuthResolutionCell * pInSAR->masterInfo->prf / pInSAR->masterInfo->azimuthBandwidth) ;
    fprintf(conf->f, "LAMBDA\t%lf\n", pInSAR->masterInfo->wavelength) ;
    fprintf(conf->f, "NLOOKSRANGE\t%d\n", pInSAR->red.Fra) ;
    fprintf(conf->f, "NLOOKSAZ\t%d\n", pInSAR->red.Faz) ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "###############################\n") ;
    fprintf(conf->f, "# Scattering model parameters #\n") ;
    fprintf(conf->f, "###############################\n") ;
    fprintf(conf->f, "LAYMINEI\t1.25\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "##################################\n") ;
    fprintf(conf->f, "# Decorrelation model parameters #\n") ;
    fprintf(conf->f, "##################################\n") ;
    fprintf(conf->f, "DEFAULTCORR\t0.01\n") ;
    fprintf(conf->f, "RHOMINFACTOR\t1.3\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "########################\n") ;
    fprintf(conf->f, "# PDF model parameters #\n") ;
    fprintf(conf->f, "########################\n") ;
    fprintf(conf->f, "AZDZFACTOR\t0.99\n") ;
    fprintf(conf->f, "LAYCONST\t0.9\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "###############################\n") ;
    fprintf(conf->f, "# Deformation mode parameters #\n") ;
    fprintf(conf->f, "###############################\n") ;
    fprintf(conf->f, "DEFOAZDZFACTOR\t1.0\n") ;
    fprintf(conf->f, "DEFOTHRESHFACTOR\t1.2\n") ;
    fprintf(conf->f, "DEFOMAX_CYCLE\t1.2\n") ;
    fprintf(conf->f, "DEFOCONST\t0.9\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "\n") ;
    fprintf(conf->f, "########################\n") ;
    fprintf(conf->f, "# Algorithm parameters #\n") ;
    fprintf(conf->f, "########################\n") ;
    fprintf(conf->f, "MAXFLOW\t4\n") ;
    fprintf(conf->f, "COSTSCALE\t100\n") ;
    fprintf(conf->f, "\n") ;
    if (pInSAR->flag & _SAVE_SNAPHU_ZONEMAP_) {
        fprintf(conf->f, "###############################\n") ;
        fprintf(conf->f, "# Connected component control #\n") ;
        fprintf(conf->f, "###############################\n") ;
        fprintf(conf->f, "# Zone Map name\n") ;
        fprintf(conf->f, "CONNCOMPFILE\tsnaphuZoneMap\n") ;
        fprintf(conf->f, "# Grow connected components (i.e.e zones) mask from unwrapped input then exit if TRUE.\n") ;
        fprintf(conf->f, "# Output is written to the file specified by CONNCOMPFILE.\n") ;
        fprintf(conf->f, "REGROWCONNCOMPS\tFALSE\n") ;
        fprintf(conf->f, "# Minimum size of zone, as a fraction of the total number of pixels\n") ;
        fprintf(conf->f, "MINCONNCOMPFRAC\t0.00001\n") ;
        fprintf(conf->f, "# Cost threshold for connected components (zones). Higher threshold will give smaller connected zones.\n") ;
        fprintf(conf->f, "CONNCOMPTHRESH\t300\n") ;
        fprintf(conf->f, "# Maximum number of zones.\n") ;
        fprintf(conf->f, "MAXNCOMPS\t50\n") ;
        fprintf(conf->f, "\n") ;
    }
    
    fprintf(conf->f, "# End of snaphu configuration file\n") ;

    freeRawFileDescriptor(conf) ;
}


void updateSnaphuConfFile(char *confFilePath, char *key, char *stringVal)
{
    char *tempFilePath, *dir ;
    int lineCount, anIndex ;
    rawFileDescriptor *conf, *tempConf ;
    
    /* Create a temporary copy of configuration file */
    dir = getDirectoryPathFromPath(confFilePath) ;
    tempFilePath = initStringWith2Strings(dir, "/tempConf") ;
    copyFileAtPathToPath(confFilePath, tempFilePath) ;
    tempConf = openRawFileForReadingAtPath(tempFilePath) ;
    free(dir) ;

    /* Find interferogram file path within snaphu configuration file */
    lineCount = 0 ;
    do {
        if(fgets(aTextLine, TEXT_LINE_MAX_LENGTH, tempConf->f) == NULL)
            return ;
        lineCount ++ ;
    } while (!isSubStringPresentInString(aTextLine, key));

    /* Create new configuration file with new INFILE path */
    conf = openRawFileForWritingAtPath(confFilePath) ;
    anIndex = 0 ;
    rewind(tempConf->f) ;
    while (fgets(aTextLine, TEXT_LINE_MAX_LENGTH, tempConf->f) != NULL) {
        anIndex++ ;
        if (anIndex == lineCount) {
            fprintf(conf->f, "%s\t%s\n", key, stringVal) ;
        }
        else
            fprintf(conf->f, "%s", aTextLine) ;
    }
    
    freeRawFileDescriptor(tempConf) ;
    freeRawFileDescriptor(conf) ;
    if(unlink(tempFilePath))
        perror("Failed to remove temporary conf file\n") ;
    
    free(tempFilePath) ;
}


