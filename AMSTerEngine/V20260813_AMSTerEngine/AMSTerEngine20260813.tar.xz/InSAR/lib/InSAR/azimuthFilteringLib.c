
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  azimuthFilteringLib.c
 *
 *  Created by Dominique Derauw om January 6, 2021.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
 */

#include "azimuthFilteringLib.h"

/* azimuthFiltering is mainly dedicated to ERS2 zero-gyro mode to filter master and slave images in azimuth, conserving common azimuth frequencies only */
int azimuthFiltering(CSVStruct *clCSV)
{
    char *InSARParametersPath = NULL ;
    char InSARParametersFileFound ;
    int currentDirectoryFdesc, i ;
    InSARParametersStruct *pInSAR ;
    time_t startTime ;
    
    if(isArgumentPresentInCSV(clCSV, "help")|| isArgumentPresentInCSV(clCSV, "-h")) {
        azimuthFilteringHelp() ;
    }
    
    /* Change working directory to current directory */
    currentDirectoryFdesc = open(".", O_RDONLY) ;
    fchdir(currentDirectoryFdesc) ;
    
    InSARParametersFileFound = 0 ;
    i = 1 ;
    /* We first check each command line parameter to verify if it is the path of en existing file */
    /* If yes, this file is supposed to be an InSAR parameter file */
    while (i < clCSV->numberOfEntries) {
        InSARParametersPath = initStringWithString(clCSV->stringVal[i]) ;
        if(fileExistsAtPath(InSARParametersPath)) {
            InSARParametersFileFound = 1 ;
            break ;
        }
        i++ ;
        free(InSARParametersPath) ;
    }
    
    /* If no parameter points to an existing file, check in working directory */
    if(!InSARParametersFileFound) {
        InSARParametersPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
        if(!fileExistsAtPath(InSARParametersPath)){
            free(InSARParametersPath) ;
            InSARParametersPath = initStringWithString("./InSARParameters.txt") ;
            printf("Tested InSAR parameters path: %s\n", InSARParametersPath) ;
            if(!fileExistsAtPath(InSARParametersPath)) {
                printf("Fourt !\n") ;
                azimuthFilteringHelp() ;
            }
        }
        InSARParametersFileFound = 1 ;
    }
    
    time(&startTime) ;
    pInSAR = readInSARParametersFileAtPath(InSARParametersPath) ;

    printf("Azimuth filtering of master image: \n") ;
    azimuthFilteringCore(pInSAR, _MASTER_AZIMUTH_FILTERING_) ;
    printf("Azimuth filtering of slave image: \n") ;
    azimuthFilteringCore(pInSAR, _SLAVE_AZIMUTH_FILTERING_) ;

    saveInSARParametersFileAtPath(pInSAR, InSARParametersPath) ;

    freeInSARParametersStruct(pInSAR) ;

    return (0) ;
}


void azimuthFilteringHelp()
{
    printf("\nUsage:") ;
    printf("\n\tazimouthFiltering [pathTo/InSARParremeterFile.txt]\n") ;
    printf("\n\tThis routine will filter master and slave images to their common azimuth spectra.\n") ;
    printf("Master and slave image will first be copied into the destination before being filteres, leaving source images untouched\n") ;
    printf("\nOption:\n") ;
    printf("A dedicated InSARParameters.txt file can be given in input.\n") ;
    printf("If not given, the one found within the working directory tree will be used\n") ;
    exit(0) ;
}


void azimuthFilteringCore(InSARParametersStruct *pInSAR, int flag)
{
    char *aFileName, *aFilePath ;
    char *inputFilePath, *outputFilePath ;
    int i, iC, iR ;
    int dcIndexDeHamming, dcIndexReHamming ;
    int xTileSize, yTileSize ;
    int xTileBorder, yTileBorder ;
    size_t iX, iY ;
    float scale ;
    float *deHammingFilter, *reHammingFilter ;
    CSLImage *inputCSLImage, **inputCSLImageHandle, *outputCSLImage ;
    SLCImageInfo *imageInfo ;
    tileTool *inTile ;
    rawFileDescriptor *inFile, *outFile ;
    CSVStruct *polMode ;
    fftwf_complex *fftIn, **M ;
    fftwf_plan forwardPlan, backwardPlan ;
    complexFloat **MC, *VC ;
    xPolynomial *fdc ;
    progressCounter *aCounter ;

    xTileSize = _XTILESIZE_ ;
    yTileSize = _YTILESIZE_ ;
    xTileBorder = _XTILEBORDER_ ;
    yTileBorder = _YTILEBORDER_ ;
    scale = 1. / yTileSize ;

    switch (flag) {
    case _MASTER_AZIMUTH_FILTERING_:
        inputCSLImage = pInSAR->masterImage ;
        inputCSLImageHandle = &pInSAR->masterImage ;
        imageInfo = pInSAR->masterInfo ;        
        break ;
    
    case _SLAVE_AZIMUTH_FILTERING_:
        inputCSLImage = pInSAR->slaveImage ;
        inputCSLImageHandle = &pInSAR->slaveImage ;
        imageInfo = pInSAR->slaveInfo ;        
        break ;
    
    default:
        return ;
        break ;
    }
    polMode = readCSVInString(imageInfo->polMode) ;

    /* Copy slave image structure within InSAR processing directory */
    aFileName = getPointerToFileNameInPath(inputCSLImage->imageDirectoryPath) ;
    aFilePath = initStringWith3Strings(pInSAR->whereAmI,"InSARProducts/", aFileName) ;
    copyCSLImage(inputCSLImage->imageDirectoryPath, aFilePath, _CSLIMAGE_INFO_ | _CSLIMAGE_HEADERS_ | _CSLIMAGE_OVERWRITE_) ;
    outputCSLImage = getCSLImageStructureAtPath(aFilePath) ;
    free(aFilePath) ;

    /* Init fftwf */
    fftIn = fftwf_alloc_complex(yTileSize) ;
    forwardPlan = fftwf_plan_dft_1d(yTileSize, fftIn, fftIn, FFTW_FORWARD, FFTW_MEASURE) ;
    backwardPlan = fftwf_plan_dft_1d(yTileSize, fftIn, fftIn, FFTW_BACKWARD, FFTW_MEASURE) ;
    VC = (complexFloat *)fftIn ;

    /* Init filters */
    deHammingFilter = deHammingFilter_azimuthFilteringLib(imageInfo, yTileSize) ;
    reHammingFilter = vectorFloat(0, 2 * yTileSize) ;    
    
    /* Init fdc polynomial */
    fdc = allocXPolynomialOfOrder(2) ;
    fdc->coefs[0] = (imageInfo->fdc[0] > 0)? imageInfo->fdc[0] : imageInfo->fdc[0] + imageInfo->prf ;
    fdc->coefs[1] = imageInfo->fdc[1] * 2 * imageInfo->rangeResolutionCell / c0 ;
    fdc->coefs[2] = imageInfo->fdc[2] * pow(2 * imageInfo->rangeResolutionCell / c0, 2) ;

    for ( i = 0; i < polMode->numberOfEntries; i++) {
        inputFilePath = initStringWith3Strings(inputCSLImage->dataDirectoryPath, "/SLCData.", polMode->stringVal[i]) ;
        inFile = openRawFileForReadingAtPath(inputFilePath) ;
        outputFilePath = initStringWith3Strings(outputCSLImage->dataDirectoryPath, "/SLCData.", polMode->stringVal[i]) ;
        outFile = openRawFileForWritingAtPath(outputFilePath) ;
        inFile->xDim = imageInfo->rangeDimension ;
        inFile->yDim = imageInfo->azimuthDimension ;
        inFile->typeSize = sizeof(complexFloat) ;
        inTile = allocTileToolForFilesOfType(inFile, outFile, "complexFloat") ;
        initTileToolWithSizes(inTile, xTileSize, yTileSize, xTileBorder, yTileBorder) ;
        M = (fftwf_complex **)inTile->tile ;
        MC = (complexFloat **)M ;


        aCounter = initProgressCounterWithMinMaxValue(0, inTile->xTileNumber * inTile->yTileNumber - 1) ;
        for (iY = 0; iY < inTile->yTileNumber; iY++) {
            for (iX = 0; iX < inTile->xTileNumber; iX++) {
                readTileAtIndexes(inTile, iX, iY) ;
                for (iC = 0; iC < xTileSize; iC++) {
                    /* Determine initial position in deHamming and rehamming filters */
                    dcIndexDeHamming = yTileSize - (int)round(yTileSize * yValForPolynomial(fdc, (double)(inTile->x0In + iC)) / imageInfo->prf) ;
                    dcIndexReHamming = updateReHammingFilter_azimuthFilteringLib(reHammingFilter, yTileSize, inTile->x0In + iC, pInSAR) ;

                    for (iR = 0; iR < yTileSize; iR++) {
                        fftIn[iR] = M[iR][iC] ;
                    }
                    fftwf_execute(forwardPlan) ;
                    for (iR = 0; iR < yTileSize; iR++) {
                        VC[iR] = mRC(VC[iR], deHammingFilter[dcIndexDeHamming + iR]) ;
                        VC[iR] = mRC(VC[iR], reHammingFilter[dcIndexReHamming + iR]) ;
                    }

                    fftwf_execute(backwardPlan) ;

                    for (iR = 0; iR < yTileSize; iR++) {
                        M[iR][iC] = fftIn[iR] ;
                        MC[iR][iC] = mRC(MC[iR][iC], scale) ;
//                        MC[iR][iC].r = MC[iR][iC].i = reHammingFilter[dcIndexReHamming + iR] ;
                    }

                }
                updatePointProgressCounterForIndex(aCounter, iY * inTile->xTileNumber + iX) ;
                writeTile(inTile) ;
            }
        }
//        updatePointProgressCounterForIndex(aCounter, iY * inTile->xTileNumber + iX) ;
        printf("\n") ;
        

        free(inputFilePath) ;
        free(outputFilePath) ;
        freeTileTool(inTile) ;
        freeProgressCounter(aCounter) ;
    }

    fftwf_destroy_plan(forwardPlan);
    fftwf_destroy_plan(backwardPlan);
    fftw_free(fftIn); 

    freeVectorFloat(deHammingFilter, 0) ;
    freeVectorFloat(reHammingFilter, 0) ;
    freeXPolynomial(fdc) ;

    /* Update InSARParameters */
    *inputCSLImageHandle = getCSLImageStructureAtPath(outputCSLImage->imageDirectoryPath) ;
    freeCSLImageStructure(inputCSLImage) ;
    freeCSLImageStructure(outputCSLImage) ;

}


/* Generate deHamming filter */
float *deHammingFilter_azimuthFilteringLib(struct infoImage *info, int windowSize)
{
    int i, anIndex, filterWidth ; 
    float alpha, arg ;
    float *deHammingFilter ;
    
    deHammingFilter = vectorFloat(0, 2 * windowSize) ;

    alpha = (info->rangeApodizationCoefficient)? info->rangeApodizationCoefficient : 0.625 ;
    filterWidth = (int)round(info->azimuthBandwidth / info->prf * windowSize) ;
    arg = TWOPI / filterWidth ;
    deHammingFilter[0] = deHammingFilter[windowSize] = 1. ;
    for (i = 1; i < filterWidth / 2; i++) {
        deHammingFilter[i] = deHammingFilter[i + windowSize] = 1. / (alpha + (1 - alpha) * cosf(i * arg)) ;
        deHammingFilter[windowSize - i] = deHammingFilter[2 * windowSize - i] = deHammingFilter[i] ;
    }
    anIndex = i - 1 ;
    for (; i < windowSize / 2 + 1; i++) {
        deHammingFilter[i] = deHammingFilter[i + windowSize] = deHammingFilter[anIndex] ;
        deHammingFilter[windowSize - i] = deHammingFilter[2 * windowSize - i] = deHammingFilter[anIndex] ;
    }

    return (deHammingFilter) ;
}


/* Update reHamming filter */
/* Returns the filter dc index */
/* ReHamming filter must already be allocated and released by caller */
int updateReHammingFilter_azimuthFilteringLib(float *filter, int windowSize, int rangeIndex, InSARParametersStruct *pInSAR)
{
    int i, filterWidth, dcIndex ; 
    float alpha, arg ;
    double fdc10, fdc20, t_fdc ;
    struct infoImage *masterInfo, *slaveInfo ;
    xPolynomial *fdc1, *fdc2 ;

    /* Init fdc polynomial */
    masterInfo = pInSAR->masterInfo ;
    fdc1 = allocXPolynomialOfOrder(2) ;
    fdc1->coefs[0] = masterInfo->fdc[0] ;
    fdc1->coefs[1] = masterInfo->fdc[1] ;
    fdc1->coefs[2] = masterInfo->fdc[2] ;
    slaveInfo = pInSAR->slaveInfo ;
    fdc2 = allocXPolynomialOfOrder(2) ;
    fdc2->coefs[0] = slaveInfo->fdc[0] ;
    fdc2->coefs[1] = slaveInfo->fdc[1] ;
    fdc2->coefs[2] = slaveInfo->fdc[2] ;

    if (!filter) {
        filter = vectorFloat(0, 2 * windowSize - 1) ;
    }
    
    t_fdc = rangeIndex * 2 * masterInfo->rangeResolutionCell / c0 ;
    fdc10 = yValForPolynomial(fdc1, t_fdc) ;
    fdc20 = yValForPolynomial(fdc2, t_fdc) ;
    dcIndex = windowSize - (int)round(windowSize * (fdc10 + fdc20) / 2. / masterInfo->prf) ;
    filterWidth = (int)round(windowSize * (masterInfo->azimuthBandwidth - fabs(fdc10 - fdc20)) / masterInfo->prf) ;
    filterWidth = (int)round((MIN(fdc10, fdc20) - MAX(fdc10, fdc20) + masterInfo->azimuthBandwidth) * windowSize / masterInfo->prf) ;

    alpha = (masterInfo->rangeApodizationCoefficient)? masterInfo->rangeApodizationCoefficient : 0.625 ;
    arg = TWOPI / filterWidth ;
    filter[0] = filter[windowSize] = 1. ;
    for (i = 1; i < filterWidth / 2; i++) {
        filter[i] = filter[i + windowSize] = (alpha + (1 - alpha) * cosf(i * arg)) ;
        filter[windowSize - i] = filter[2 * windowSize - i] = filter[i] ;
    }
    for (; i < windowSize / 2 + 1; i++) {
        filter[i] = filter[i + windowSize] = 0 ;
        filter[windowSize - i] = filter[2 * windowSize - i] = 0 ;
    }



    freeXPolynomial(fdc1) ;
    freeXPolynomial(fdc2) ;

    return(dcIndex) ;
}