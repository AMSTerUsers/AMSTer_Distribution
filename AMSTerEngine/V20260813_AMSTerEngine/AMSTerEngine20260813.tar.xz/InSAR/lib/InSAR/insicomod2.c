
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  insicomod2.c
 *
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
 */
/*
Calcul des images en modules de l'interféro et mesure de coherence avec retrait de la composante due à la sphère terrestre.
La cohérence mesurée est celle associée à l'interférogramme non filtré. Celui-ci est recalculé sur base des deux fichier images donnés en paramètres.
*/

#include "incomod.h"

/* main programm start */
void insicohmod(InSARParametersStruct *pInSAR)
{
	/* local variables declaration */
	char *aFilePath, *aString, isExternalSlantRangeDEMPresent, isMaskPresent = '\0', isEventMaskPresent = '\0' ;
    char verbose ;
    char unsigned *slantRangeMask = NULL ;
	int i, is, j, k, l, lenr, lena, cor, coa, squareSpiralSize ;
    int iX, iY ;
	int Dresa, Dresr, Sbaz, Shaz, Sdra, Sgra ;
    int rangeIndex, azimuthIndex ;
	int azimuthReductionFactor, rangeReductionFactor, columnIndex, columnIndex0, IndiceLigneBI ;
	float Norme, Norme2, aPhase ;
	float *Coherence ;
	float *Interfero ;
	float *InterferoF ;
	float *EcartType ;
	float *Module1 ;
	float *Module2 ;
    float **ETADPhaseCorrectionLayer = NULL ;
	float *MInterfFiltre0, **MInterfFiltre, *tMInterfFiltre ;
	float *MInterfc0, **MInterfc, *tMInterfc ;
	float *MI10, *MI20, **MI1, **MI2, *tMI1, *tMI2 ;
    
	float tempFloat, tempFloat2 ;
    float sec2phase ;
    float *externalSlantRangeDEM, *topographicPhase, *residualPhase ;
    float *correctionPhase = NULL, *correctionPhaseMaster, *correctionPhaseSlave ;
    float effectiveRangeResolutionCell ;
    float *localIncidenceAngle = NULL, *geoidalIncidenceAngle = NULL ;
    double *alpha = NULL ;
    double *alpha_at = NULL ;
    double localAltitude ;
    double slope ;             /* Local slope */
    double *sinAlpha = NULL ;          /* Alpha is the local incidence angle of the elementary slope between two points */
    double deltaH ;            /* deltaH is the height variation between two successive points */
    double Bperp ;             /* Local perpendicular baseline component */
    double range ;             /* Local range in meters */
    double maxCoh ;            /* Estimated max coherence due to geometrical decorrelation */
    double weight, max ;
    double *sd1, *sd2, *coherenceNumerator ;
	double *scd1, *scd2, sn1, sld1, sld2 ;
    coord2D *currentPosition, *effectivePosition ;
	complexDouble		*PhaseComplexe, *PhaseComplexeF ;
	complexFloat		*MphiF0, **MphiF, *tMphiF ;
	complexFloat		*Mphi0, **Mphi, *tMphi ;
	complexFloat		*Mphic0, **Mphic, *tMphic ;
	complexFloat		tempComplexFloat, *standardDeviation ;
    complexDouble        tempComplexDouble, tempComplexDouble2 ;
	complexDouble		*scn, sln, *scET, slET, *scnI, slnI, *scnIF, slnIF ;
    complexDouble *weightedPhase ;
	struct BlocInSAR	BI ;
	progressCounter *aCounter ;
    rawFileDescriptor *localIncidenceAngleFile = NULL ;
    rawFileDescriptor *geoidalIncidenceAngleFile = NULL ;
    rawFileDescriptor *slantRangeMaskFile = NULL ;
    rawFileDescriptor *sigmaNoughtMaster, *sigmaNoughtSlave ;
    rawFileDescriptor *normalizedCoh = NULL ;
    rawFileDescriptor *ETADTroposphericPhaseCorrection = NULL ;
    rawFileDescriptor *ETADIonosphericPhaseCorrection = NULL ;
    rawFileDescriptor *ETADGeodeticPhaseCorrection = NULL ;
    gridMap *maskGrid = NULL, *aGrid ;
    CSLImage *referenceImage ;
    CSVStruct *eventMaskpath ;

/*----------------------------------  INITIALISATION  -----------------------------------*/

    verbose = (pInSAR->flag & _VERBOSE_)? 1 : 0 ;
    sec2phase = (float)(TWOPI / pInSAR->masterInfo->wavelength * c0) ;

    /* Alloc current and effective positions */
    currentPosition = allocPoint() ;
    effectivePosition = allocPoint() ;

    /* Open master and slave image */
    openMasterImageForReading(pInSAR) ;
    openSlaveImageForReading(pInSAR) ;
    if (verbose) {
        printf("\tMaster image%s\n", pInSAR->masterImageFile->accessPath) ;
        printf("\tSlave image%s\n", pInSAR->slaveImageFile->accessPath) ;
    }

    if (pInSAR->flag & _NORMALIZED_COH_) {
        aFilePath = initStringWith2Strings(pInSAR->coh.filePath, ".normalized") ;
        normalizedCoh = openRawFileForWritingAtPath(aFilePath) ;
        free(aFilePath) ;

    }

    /* Initialize computation parameters */
    Sbaz = pInSAR->aoi->P[0].y ;
    Sgra = pInSAR->aoi->P[0].x ;
    Shaz = pInSAR->aoi->P[2].y ;
    Sdra = pInSAR->aoi->P[2].x ;

	coa = (pInSAR->coh).coa ;
	cor = (pInSAR->coh).cor ;
	squareSpiralSize = (pInSAR->coh).spi ;
	azimuthReductionFactor = (pInSAR->red).Faz ;
	rangeReductionFactor = (pInSAR->red).Fra ;
    effectiveRangeResolutionCell = rangeReductionFactor * pInSAR->masterInfo->rangeResolutionCell ;

	squareSpiralSize = 2 * (squareSpiralSize / 2) + 1 ;
    (pInSAR->coh).spi = squareSpiralSize ;
	lenr = Sdra - Sgra - squareSpiralSize + 2 ;
	lena = Shaz - Sbaz - squareSpiralSize + 2 ;
	Norme = (float)(azimuthReductionFactor * rangeReductionFactor) ;
	Norme2 = (float)(coa * cor) ;
    pInSAR->ambiguityAltitude = ambiguityAltitudeAtPoint(pInSAR->ima1.lenr / 2., pInSAR->ima1.lena / 2., 0, pInSAR) ;
    
    /* Compute dimension of issued products */
	(pInSAR->interf).lena = (pInSAR->mod1).lena = (pInSAR->mod2).lena = (pInSAR->coh).lena = Dresa = (lena - coa + 1) / azimuthReductionFactor ;
	(pInSAR->interf).lenr = (pInSAR->mod1).lenr = (pInSAR->mod2).lenr = (pInSAR->coh).lenr = Dresr = (lenr - cor + 1) / rangeReductionFactor ;
    if (verbose) {
        printf("\n\tUsed reduction factors (range x azimuth): %d X %d\n", rangeReductionFactor, azimuthReductionFactor) ;
        printf("\t\tEstimator window size: %-d X %-d\n", cor, coa) ;
        printf("\t\tSize of interferometric product images: %-d X %-d\n", Dresr, Dresa) ;
    }


    /* Open InSAR products files */
    if (fileExistsAtPath(pInSAR->coh.filePath)) {
        unlink(pInSAR->coh.filePath) ;
    }

    if((pInSAR->coherenceFile = openCoherenceFile(pInSAR)) == NULL) {
		ase("Failed to open/create coherence image file\n") ;
    }

    if (fileExistsAtPath(pInSAR->interf.filePath)) {
        unlink(pInSAR->interf.filePath) ;
    }
	if((pInSAR->interferogramFile = openInterferogramFile(pInSAR)) == NULL) {
		ase("Failed to open/create interferogram image file\n") ;
    }

    if(pInSAR->flag & WITH_FILTERING) {
        if((pInSAR->filteredInterferogramFile = openRawFileForWritingAtPath((pInSAR->filter).filePath)) == NULL)
            ase("Failed to open/create filtered interferogram image file\n") ;
    }

	if((pInSAR->masterAmplitudeImageFile = openRawFileForWritingAtPath((pInSAR->mod1).filePath)) == NULL) {
		ase("Failed to open master amplitude image file\n") ;
    }

	if((pInSAR->slaveAmplitudeImageFile = openRawFileForWritingAtPath((pInSAR->mod2).filePath)) == NULL) {
		ase("Failed to open slave amplitude image file\n") ;
    }

	if(pInSAR->flag & COMPUTE_STADARD_DEVIATION) {
		aFilePath = initStringWith2Strings((pInSAR->coherenceFile)->directoryPath, "sigmaPhi") ;
		if((pInSAR->phaseStandardDeviationImageFile = openRawFileForWritingAtPath(aFilePath)) == NULL)
			ase("Failed to open phase standard deviation image file\n") ;
		free(aFilePath) ;

		aFilePath = initStringWith2Strings((pInSAR->coherenceFile)->directoryPath, "sigmaH") ;
		if((pInSAR->heightStandardDeviationImageFile = openRawFileForWritingAtPath(aFilePath)) == NULL)
			ase("Failed to open height standard deviation image file\n") ;
		free(aFilePath) ;
	}


	/* We will work on memory blocks of 128Mb max when considering complexFloat blocks of data (8 bytes per pixels ==> 128 = 16 x 8) */
	BI.Dima = (pInSAR->ima1.lenr  > pInSAR->ima2.lenr)? 16 * 1024 * 1024 / pInSAR->ima1.lenr : 16 * 1024 * 1024 / pInSAR->ima2.lenr ;

	/* We limit azimuth size of blocks to 2400 lines for filtering reasons (Filtering of 5 successive blocs of 512 lignes with 2x32 pixels borders) */
	BI.Dima = (BI.Dima > 2400)? 2400 : BI.Dima ;
	BI.IndiceLigne = Sbaz ;

    /* If working on small areas, we adapt azimuth window */
    if (BI.Dima > Shaz - Sbaz + 1) {
        BI.Dima = Shaz - Sbaz + 1 ;
    }
	/* ------------------------------- allocation de mémoire --------------------------------------*/

	AllocBlocInSAR(&BI, pInSAR) ;

    /* if ETAD correction is requested, create output file */
    if (pInSAR->flag & _ETAD_CORRECTION_) {
        if (!pInSAR->thirdPhaseComponent.filePath) {
            pInSAR->thirdPhaseComponent.filePath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/correctionPhase") ;
        }
        pInSAR->thirdPhaseComponentFile = openRawFileForWritingAtPath(pInSAR->thirdPhaseComponent.filePath) ;
        if (pInSAR->flag & _SAVE_ETAD_LAYERS_) {
            ETADPhaseCorrectionLayer = matrixFloat(0, 2, 0, Dresr - 1) ;
            if (pInSAR->flag2 & _ETAD_TROPOSPHERIC_CORRECTION_RG_) {
                aFilePath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/ETADTroposphericPhaseCorrection") ;
                ETADTroposphericPhaseCorrection = openRawFileForReadingAndWritingAtPath(aFilePath) ;
                free(aFilePath) ;
            }
            if (pInSAR->flag2 & _ETAD_GEODETIC_CORRECTION_RG_) {
                aFilePath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/ETADGeodeticPhaseCorrection") ;
                ETADGeodeticPhaseCorrection = openRawFileForReadingAndWritingAtPath(aFilePath) ;
                free(aFilePath) ;
            }
            if (pInSAR->flag2 & _ETAD_IONOSPHERIC_CORRECTION_RG_) {
                aFilePath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/ETADIonosphericPhaseCorrection") ;
                ETADIonosphericPhaseCorrection = openRawFileForReadingAndWritingAtPath(aFilePath) ;
                free(aFilePath) ;
            }
        }
    }
    

    /* If an external slant range DEM is available, create DEM grid */
    externalSlantRangeDEM = topographicPhase = residualPhase = NULL ;
    isExternalSlantRangeDEMPresent = (referenceImage = getReferenceCSLImage(pInSAR))? 1 : 0 ;
    isExternalSlantRangeDEMPresent = (pInSAR->flag & _ETAD_CORRECTION_)? 1 : isExternalSlantRangeDEMPresent ;
    if (isExternalSlantRangeDEMPresent) {
        /* If requested, initialize correction phase layer */
        if (pInSAR->flag & _ETAD_CORRECTION_) {
            correctionPhase = vectorFloat(0, Dresr-1) ;
            correctionPhaseMaster = vectorFloat(0, Dresr-1) ;
            correctionPhaseSlave = vectorFloat(0, Dresr-1) ;
        }
        if (referenceImage) {
            BI.slantRangeDEMGrid = allocAndInitExternalFileGridForImage(referenceImage, "externalSlantRangeDEM") ;
        }
    
        externalSlantRangeDEM = vectorFloat(0, Dresr-1) ;
        topographicPhase = vectorFloat(0, Dresr-1) ;
        residualPhase = vectorFloat(0, Dresr-1) ;

        if (fileExistsAtPath(pInSAR->externalSlantRangeDEMFile->accessPath)) {
            unlink(pInSAR->externalSlantRangeDEMFile->accessPath) ;
        }

        if (fileExistsAtPath(pInSAR->firstPhaseComponent.filePath)) {
            unlink(pInSAR->firstPhaseComponent.filePath) ;
        }
        
        if (fileExistsAtPath(pInSAR->residualPhase.filePath)) {
            unlink(pInSAR->residualPhase.filePath) ;
        }
        
        if(!openExternalSlantRangeDEMFile(pInSAR)) {
            ase("Failed to create external slant range DEM file for writing") ;
        }
        if(!openFirstPhaseComponentFile(pInSAR)) {
            ase("Failed to open first phase component file for writing") ;
        }
        if(!openResidualInterferogramFile(pInSAR)) {
            ase("Failed to open residual interferogram file for writing") ;
        } 

        pInSAR->externalSlantRangeDEMFile->xDim = Dresr ;
        pInSAR->externalSlantRangeDEMFile->yDim = Dresa ;
    }

    /* Detect if a slant range mask is also present */
    maskGrid = NULL ;
    isMaskPresent = (referenceImage)? isFilePresentInCSLImage(referenceImage, "slantRangeMask") : 0 ;
    if (isMaskPresent) {
        maskGrid = allocAndInitExternalFileGridForImage(referenceImage, "slantRangeMask") ;
        if (!maskGrid) {
            printf("\t-/-> Failed to init grid for slant range mask\nContinuing though...\n") ;
            isMaskPresent = 0 ;
        }
    }

    /* Detect if slant range event masks are present and combine them */
    isEventMaskPresent = ((eventMaskpath = selectEventMasks(pInSAR)))? 1 : 0 ;
    if (isEventMaskPresent) {
        if (!isMaskPresent) {
            maskGrid = allocAndInitExternalFileGridForImage(referenceImage, eventMaskpath->stringVal[0]) ;
            is = 1 ;
            isMaskPresent = 1 ;
        }
        else {
            is = 0 ;
        }
        for (i = is; i < eventMaskpath->numberOfEntries; i++) {
            aGrid = allocAndInitExternalFileGridForImage(referenceImage, eventMaskpath->stringVal[i]) ;
            for ( k = 0; k < maskGrid->Nx - 1; k++) {
                for ( l = 0; l < maskGrid->Ny - 1; l++) {
                    maskGrid->charVal[k][l] |= (aGrid->charVal[k][l])? 0b00000100 : 0 ;
                }
            }
            freeGridMap(aGrid) ;
        }
    }
    if (isMaskPresent) {
        slantRangeMask = vectorUChar(0, Dresr - 1) ;
        aFilePath = initStringWith2Strings(pInSAR->externalSlantRangeDEMFile->directoryPath, "/slantRangeMask") ;
        slantRangeMaskFile = openRawFileForWritingAtPath(aFilePath) ;
        slantRangeMaskFile->typeSize = 1 ;
        free(aFilePath) ;
    }
    


    /* If requested, initialize local incidence angle computation */
    if(pInSAR->flag & COMPUTE_LOCAL_INCIDENCE_ANGLE) {
		aFilePath = initStringWith2Strings((pInSAR->coherenceFile)->directoryPath, "localIncidenceAngle") ;
		if((localIncidenceAngleFile = openRawFileForWritingAtPath(aFilePath)) == NULL) {
			ase("Failed to open local incidence angle image file\n") ;
        }
		free(aFilePath) ;

		aFilePath = initStringWith2Strings((pInSAR->coherenceFile)->directoryPath, "geoidalIncidenceAngle") ;
		if((geoidalIncidenceAngleFile = openRawFileForWritingAtPath(aFilePath)) == NULL) {
			ase("Failed to open local incidence angle image file\n") ;
        }
		free(aFilePath) ;
    }
    if (isExternalSlantRangeDEMPresent || (pInSAR->flag & COMPUTE_LOCAL_INCIDENCE_ANGLE) || (pInSAR->flag & _CALIBRATE_IN_SIGMA0_) || (pInSAR->flag & _NORMALIZED_COH_)) {
        localIncidenceAngle = vectorFloat(0, Dresr-1) ;
        geoidalIncidenceAngle = vectorFloat(0, Dresr-1) ;
        alpha = vectorDouble(0, Dresr-1) ;
        alpha_at = vectorDouble(0, Dresr-1) ;
        sinAlpha = vectorDouble(0, Dresr-1) ;
    }

    

    /* If requested, initialize output files for sigma nought */
    sigmaNoughtMaster = sigmaNoughtSlave = NULL ;
    if (pInSAR->flag & _CALIBRATE_IN_SIGMA0_) {
        aString = initStringWithString(pInSAR->masterAmplitudeImageFile->accessPath) ;
        stripExtensionAtEndOfPath(aString) ;
        aFilePath = initStringWith2Strings(aString, ".sigma0") ;
        sigmaNoughtMaster = openRawFileForWritingAtPath(aFilePath) ;
        free(aFilePath) ;
        free(aString) ;

        aString = initStringWithString(pInSAR->slaveAmplitudeImageFile->accessPath) ;
        stripExtensionAtEndOfPath(aString) ;
        aFilePath = initStringWith2Strings(aString, ".sigma0") ;
        sigmaNoughtSlave = openRawFileForWritingAtPath(aFilePath) ;
        free(aFilePath) ;
        free(aString) ;
    }


    /* Initialize filtering if required */
    if(pInSAR->flag & WITH_FILTERING) {
        initFiltering(&BI, pInSAR) ;
    }

	/* ------------------- Initialisation ------------------- */
	BI.f1 = pInSAR->masterImageFile->f ;
	BI.f2 = pInSAR->slaveImageFile->f ;
	Interfero = vectorFloat(0, Dresr-1) ;
	InterferoF = vectorFloat(0, Dresr-1) ;
	EcartType = vectorFloat(0, Dresr-1) ;
	Coherence = vectorFloat(0, Dresr-1) ;
	Module1 = vectorFloat(0, Dresr-1) ;
	Module2 = vectorFloat(0, Dresr-1) ;
	scd1 = vectorDouble(0, lenr-1) ;
	scd2 = vectorDouble(0, lenr-1) ;
	scn = vectorComplexDouble(0, lenr-1) ;
	scET = vectorComplexDouble(0, lenr-1) ;
	scnI = vectorComplexDouble(0, lenr-1) ;
	scnIF = vectorComplexDouble(0, lenr-1) ;
	PhaseComplexe = vectorComplexDouble(0, Dresr-1) ;
	PhaseComplexeF = vectorComplexDouble(0, Dresr-1) ;
    weightedPhase = vectorComplexDouble(0, Dresr-1) ;
    standardDeviation = vectorComplexFloat(0, Dresr-1) ;
    sd1 = vectorDouble(0, Dresr-1) ;
    sd2 = vectorDouble(0, Dresr-1) ;
    coherenceNumerator = vectorDouble(0, Dresr-1) ;

	MI1 = matrixFloat(-1, coa-1, 0, lenr-1) ;
	MI10 = MI1[-1] ;
	MI2 = matrixFloat(-1, coa-1, 0, lenr-1) ;
	MI20 = MI2[-1] ;
	Mphi = matrixComplexFloat(-1, coa-1, 0, lenr-1) ;
	Mphi0 = Mphi[-1] ;
	MphiF = matrixComplexFloat(-1, coa-1, 0, lenr-1) ;
	MphiF0 = MphiF[-1] ;
	Mphic = matrixComplexFloat(-1, coa-1, 0, lenr-1) ;
	Mphic0 = Mphic[-1] ;
	MInterfc = matrixFloat(-1, coa-1, 0, lenr-1) ;
	MInterfc0 = MInterfc[-1] ;
    MInterfFiltre  = matrixFloat(0, coa + squareSpiralSize - 2, 0, lenr + squareSpiralSize - 2) ;
    MInterfFiltre0 = MInterfFiltre[0] ;

	for(i=0; i<lenr; i++) {
		scnI[i].r = scnI[i].i = scnIF[i].r = scnIF[i].i = scET[i].r = scET[i].i = scn[i].r = scn[i].i = scd1[i] = scd2[i] = 0.0 ;
		Mphi[-1][i].r = Mphi[-1][i].i  = Mphic[-1][i].r = Mphic[-1][i].i =  MphiF[-1][i].r = MphiF[-1][i].i = MInterfc[-1][i]
		= MI1[-1][i] = MI2[-1][i] = 0.0 ;
	}

	GenPhi(&BI, pInSAR) ;
	IndiceLigneBI = 0 ;
	for(i = 0; i < coa + squareSpiralSize - 2; i++) {
		TransfertInterfFiltre(MInterfFiltre[i], &BI, IndiceLigneBI, 0) ;
		IndiceLigneBI++ ;
	}

    IndiceLigneBI = 0 ;
	for(i=0; i<coa-1; i++) {
		TransfertPhi(Mphi[i], &BI, IndiceLigneBI, squareSpiralSize / 2) ;

        if(pInSAR->flag & WITH_FILTERING) {
            TransfertPhiFiltre(MphiF[i], &BI, IndiceLigneBI, squareSpiralSize / 2) ;
        }

		TransfertMod(MI1[i], MI2[i], &BI, IndiceLigneBI, squareSpiralSize / 2) ;
		IndiceLigneBI++ ;
#pragma omp parallel num_threads(maxThreads)
#pragma omp for schedule(auto) private(iX, iY, tempFloat, tempComplexFloat)
		for(j=0; j<lenr; j++) {

            /* Phase correction using spiral phase unwrapping */
            if (squareSpiralSize > 1) {
                iX = j + squareSpiralSize / 2 ;
                iY = i + squareSpiralSize / 2 ;
                tempFloat = squareSpiralPhaseUnwrapping(MInterfFiltre, squareSpiralSize, iY, iX) ;
                /* Normally, the following should be useless since no NaN should be present in any of the used files except if some unexpected values are given in input in the used SLC images */
                tempFloat = (isnan(tempFloat))? 0 : tempFloat ;
                tempComplexFloat.r = cosf(tempFloat) ;
                tempComplexFloat.i = sinf(tempFloat) ;
                Mphic[i][j] = mC(Mphi[i][j], cC(tempComplexFloat)) ;
            }
            else {
                Mphic[i][j] = Mphi[i][j] ;
            }

			scnI[j].r += Mphi[i][j].r ;
			scnI[j].i += Mphi[i][j].i ;

            if(pInSAR->flag & WITH_FILTERING) {
                scnIF[j].r += MphiF[i][j].r ;
                scnIF[j].i += MphiF[i][j].i ;
            }
			scn[j].r += Mphic[i][j].r ;
			scn[j].i += Mphic[i][j].i ;
			scd1[j] += MI1[i][j] ;
			scd2[j] += MI2[i][j] ;

			tempComplexFloat.r = (float)Mphic[i][j].r ;
			tempComplexFloat.i = (float)Mphic[i][j].i ;
			MInterfc[i][j] = phi(&tempComplexFloat) ;
            if(pInSAR->flag & COMPUTE_STADARD_DEVIATION) {
				scET[j].r += MInterfc[i][j] ;
				scET[j].i += (double)pow(MInterfc[i][j], 2.) ;
			}
		}
	}

	/* ------------------- Calcul de la cohérence ------------------- */

	is = coa - 1 ;
	aCounter = initProgressCounterWithMinMaxValue(0, Dresa - 1) ;
	for(i = 0; i < Dresa; i++) {
        azimuthIndex = i * azimuthReductionFactor + pInSAR->aoi->P[0].y + squareSpiralSize / 2 + coa / 2 + pInSAR->yShift ;
        currentPosition->y = (double)azimuthIndex ;
		for(j = 0; j < Dresr; j++) {
			Coherence[j] = EcartType[j] = Interfero[j] = InterferoF[j] = Module1[j] = Module2[j] = PhaseComplexe[j].r = PhaseComplexe[j].i = PhaseComplexeF[j].r = PhaseComplexeF[j].i = 0.0 ;
			standardDeviation[j].r = standardDeviation[j].i = 0. ;
            sd1[j] = sd2[j] = coherenceNumerator[j] = 0. ;
            weightedPhase[j].r = weightedPhase[j].i = 0. ;
		}

		for(l = 0; l < azimuthReductionFactor; l++) {
			if(IndiceLigneBI == BI.Dima - squareSpiralSize + 1) {
				GenPhi(&BI, pInSAR) ;
				IndiceLigneBI = 0 ;
			}
			TransfertInterfFiltre(MInterfFiltre[is + squareSpiralSize - 1], &BI, IndiceLigneBI, squareSpiralSize - 1) ;
			TransfertPhi(Mphi[is], &BI, IndiceLigneBI, squareSpiralSize/2) ;

            if(pInSAR->flag & WITH_FILTERING) {
                TransfertPhiFiltre(MphiF[is], &BI, IndiceLigneBI, squareSpiralSize/2) ;
            }

			TransfertMod(MI1[is], MI2[is], &BI, IndiceLigneBI, squareSpiralSize/2) ;
			IndiceLigneBI++ ;

			for(j = 0; j < lenr; j++) {
                rangeIndex = j + pInSAR->aoi->P[0].x + squareSpiralSize / 2 + coa / 2 ;
                
                /* Phase correction using spiral phase unwrapping  or external DEM */
                tempFloat = 0 ;
                if (squareSpiralSize > 1) {
                    iX = j + squareSpiralSize / 2 ;
                    iY = is + squareSpiralSize / 2 ;
                    tempFloat = (double)squareSpiralPhaseUnwrapping(MInterfFiltre, squareSpiralSize, iY, iX) ;
                    /* Normally, the following should be useless since no NaN should be present in any of the used files except if some unexpected values are given in input in the used SLC images */
                    tempFloat = (isnan(tempFloat))? 0 : tempFloat ;
                }
                else if (isExternalSlantRangeDEMPresent) {
                    currentPosition->x = (double)rangeIndex ;
                    computeEffectiveRangeAzimuthCoordinatesOfPoint(currentPosition, effectivePosition, pInSAR) ;
                    if (referenceImage) {
                       localAltitude = interpolFloatGridForImageCoordinate(BI.slantRangeDEMGrid, currentPosition->x, currentPosition->y) ;
                    }
                    else {
                        localAltitude = ETADHeightAtPoint(effectivePosition->x, effectivePosition->y, pInSAR->masterInfo) ;
                    }
                    
                    tempFloat = topographicalPhaseAtPoint(effectivePosition->x, effectivePosition->y, localAltitude, pInSAR) ;
                    tempFloat = (isnan(tempFloat))? 0 : tempFloat ;

                    if (pInSAR->flag & _ETAD_CORRECTION_) {
                        tempFloat2 = (float)ETADPhaseDelayAtPoint(effectivePosition->x, effectivePosition->y, pInSAR->masterInfo, NULL) ;
                        tempFloat2 -= (float)ETADPhaseDelayAtPoint(effectivePosition->x, effectivePosition->y, pInSAR->masterInfo, pInSAR->slaveInfo) ;
                        tempFloat2 *= sec2phase ;
                        tempFloat -= tempFloat2 ;
                    }
                }
                if (tempFloat) {
                    tempComplexFloat.r = cosf(tempFloat) ;
                    tempComplexFloat.i = sinf(tempFloat) ;
                    Mphic[is][j] = mC(Mphi[is][j], cC(tempComplexFloat)) ;
                }
                else {
                    Mphic[is][j] = Mphi[is][j] ;
                }

				scnI[j].r += (double)Mphi[is][j].r - (double)Mphi[-1][j].r ;
				scnI[j].i += (double)Mphi[is][j].i - (double)Mphi[-1][j].i ;

                if(pInSAR->flag & WITH_FILTERING) {
                    scnIF[j].r += (double)MphiF[is][j].r - (double)MphiF[-1][j].r ;
                    scnIF[j].i += (double)MphiF[is][j].i - (double)MphiF[-1][j].i ;
                }

				scn[j].r += (double)Mphic[is][j].r - (double)Mphic[-1][j].r ;
				scn[j].i += (double)Mphic[is][j].i - (double)Mphic[-1][j].i ;
				scd1[j] += (double)MI1[is][j] - (double)MI1[-1][j] ;
				scd2[j] += (double)MI2[is][j] - (double)MI2[-1][j] ;
//				tempc.r = (float)Mphic[is][j].r ;
//				tempc.i = (float)Mphic[is][j].i ;
//				MInterfc[is][j] = phi(&tempc) ;
                MInterfc[is][j] = phi(Mphic[is] + j) ;
                if(pInSAR->flag & COMPUTE_STADARD_DEVIATION) {
					scET[j].r += MInterfc[is][j] - MInterfc[-1][j] ;
					scET[j].i += pow(MInterfc[is][j], 2.) - pow(MInterfc[-1][j], 2.) ;
				}
			}

            /* Range moving average and bloc avaraging initialization along range */
			slnI.r = slnI.i = slnIF.r = slnIF.i = sln.r = sln.i = slET.r = slET.i = sld1 = sld2 = 0.0 ;
			for(j = 0; j < cor - 1; j++) {
				slnI.r += scnI[j].r ;
				slnI.i += scnI[j].i ;

                if(pInSAR->flag & WITH_FILTERING) {
                    slnIF.r += scnIF[j].r ;
                    slnIF.i += scnIF[j].i ;
                }

				sln.r += scn[j].r ;
				sln.i += scn[j].i ;
				sld1 += scd1[j] ;
				sld2 += scd2[j] ;
                if(pInSAR->flag & COMPUTE_STADARD_DEVIATION) {
					slET.r += scET[j].r ;
					slET.i += scET[j].i ;
				}
			}

            /* Range moving average and bloc avaraging along range */
			for(j = 0; j < Dresr; j++) {
				for(k = 0; k < rangeReductionFactor; k++) {
					columnIndex = j * rangeReductionFactor + k + cor - 1 ;
                    columnIndex0 = j * rangeReductionFactor + k ;

					slnI.r += scnI[columnIndex].r ;
					slnI.i += scnI[columnIndex].i ;
					sln.r += scn[columnIndex].r ;
					sln.i += scn[columnIndex].i ;
					sld1 += scd1[columnIndex] ;
					sld2 += scd2[columnIndex] ;
					slET.r += scET[columnIndex].r ;
					slET.i += scET[columnIndex].i ;

//					Coherence[j] += (sn1 > Chouillat)? (float)(sqrt((sln.r * sln.r + sln.i * sln.i)/sn1)) : 0 ;

                    if(pInSAR->flag & COMPUTE_STADARD_DEVIATION) {
						EcartType[j] += (float)(sqrt(fabs(slET.i /Norme2 - pow(slET.r /Norme2, 2.)))) ;
                    }

                    /* Weight calculation */
                    weight = 1. ;
                    if (pInSAR->flag & _WITH_WEIGHTING_) {
                        max = MAX(sld1, sld2) ;
                        weight = (max)? modComplexDouble(sln) * sqrt(sld1 *sld2) : 0 ;
/*                        sum = weight = 0. ;
                        if (max) {
                            sum = pow((sqrt(sld1) + sqrt(sld2))/ 2., 2.) / (Norme * Norme2)  ;
                            weight = (sum)? (1. - 1. / (1. + sum/gamma2)) : 0 ;
                            weight = (sum)? (1. / (1 + pow((sld1 - sld2)/max, 2.) / gamma1)) * (1. - 1. / (1. + sum/gamma2)) : 0 ;
                        weight = 1. / (1 + powf((sld1 - sld2)/max, 2.) / gamma1) ;
                        }
*/                    }

                    PhaseComplexe[j].r += (float)(weight * slnI.r) ;
					PhaseComplexe[j].i += (float)(weight * slnI.i) ;

                    weightedPhase[j].r += weight * sln.r ;
                    weightedPhase[j].i += weight * sln.i ;
                    sd1[j] += sld1 * weight ;
                    sd2[j] += sld2 * weight ;

                    Module1[j] += (float)fabs(sld1) ;
                    Module2[j] += (float)fabs(sld2) ;

                    /* Filterd interferogram */
                    if(pInSAR->flag & WITH_FILTERING) {
                        slnIF.r += scnIF[columnIndex].r ;
                        slnIF.i += scnIF[columnIndex].i ;
                        PhaseComplexeF[j].r += (float)(weight * slnIF.r) ;
                        PhaseComplexeF[j].i += (float)(weight * slnIF.i) ;
                        slnIF.r -= scnIF[columnIndex0].r ;
                        slnIF.i -= scnIF[columnIndex0].i ;
                    }

					slnI.r -= scnI[columnIndex0].r ;
					slnI.i -= scnI[columnIndex0].i ;
					sln.r -= scn[columnIndex0].r ;
					sln.i -= scn[columnIndex0].i ;
					sld1 -= scd1[columnIndex0] ;
					sld2 -= scd2[columnIndex0] ;
                    if(pInSAR->flag & COMPUTE_STADARD_DEVIATION) {
                        tempComplexDouble.r = sln.r ;
                        tempComplexDouble.i = sln.i ;
                        aPhase = (float)phaseOfComplexDouble(&tempComplexDouble) ;
                        standardDeviation[j].r += aPhase ;
                        standardDeviation[j].i += powf(aPhase, 2.) ;
						slET.r -= scET[columnIndex0].r ;
						slET.i -= scET[columnIndex0].i ;
					}
				}
			}

			tMphi = Mphi[-1] ; tMphiF = MphiF[-1] ; tMphic = Mphic[-1] ; tMInterfc = MInterfc[-1] ; tMI1 = MI1[-1] ; tMI2= MI2[-1] ;
			for(j = -1; j < is; j++)
			{
				Mphi[j] = Mphi[j+1] ;
				MphiF[j] = MphiF[j+1] ;
				Mphic[j] = Mphic[j+1] ;
				MInterfc[j] = MInterfc[j+1] ;
				MI1[j] = MI1[j+1] ;
				MI2[j] = MI2[j+1] ;
			}
			Mphi[is] = tMphi ; MphiF[is] = tMphiF ; Mphic[is] = tMphic ; MInterfc[is] = tMInterfc ; MI1[is] = tMI1 ; MI2[is] = tMI2 ;

			tMInterfFiltre = MInterfFiltre[0] ;
			for(j = 0; j < coa + squareSpiralSize - 2; j++) MInterfFiltre[j] = MInterfFiltre[j + 1] ;
			MInterfFiltre[coa + squareSpiralSize - 2] = tMInterfFiltre ;
		}

        /* Normalization and float phase computation */
		for(j = 0; j < Dresr; j++) {
            sn1 = sd1[j] * sd2[j] ;
            Coherence[j] = (sn1 > Chouillat)? modComplexDouble(weightedPhase[j]) / sqrt(sn1) : 0 ;

            if(pInSAR->flag & COMPUTE_STADARD_DEVIATION) {
				EcartType[j] /= Norme ;
				EcartType[j] = (float)(sqrt(fabs(standardDeviation[j].i /Norme - pow(standardDeviation[j].r /Norme, 2.)))) ;
			}
            Module1[j] = sqrtf(Module1[j] / Norme / Norme2) ;
            Module2[j] = sqrtf(Module2[j] / Norme / Norme2) ;
            Interfero[j] = (float)phaseOfComplexDouble(PhaseComplexe + j) ;

            if(pInSAR->flag & WITH_FILTERING) {
                InterferoF[j] = (float)phaseOfComplexDouble(PhaseComplexeF + j) ;
            }
		}

        if(pInSAR->flag & COMPUTE_STADARD_DEVIATION) {
            if (fwrite((float *)EcartType, sizeof(float), (size_t)(Dresr), pInSAR->phaseStandardDeviationImageFile->f) != (size_t)(Dresr))
                ase("\t-/-> Failed to save phase standard deviation") ;

			SigmaPhiToSigmaH(EcartType, pInSAR, i) ;
            if (fwrite((float *)EcartType, sizeof(float), (size_t)(Dresr), pInSAR->heightStandardDeviationImageFile->f) != (size_t)(Dresr))
                ase("\t-/-> Failed to save height standard deviation") ;
		}

        /* Save interferogram line */
        if (fwrite((float *)Interfero, sizeof(float), (size_t)(Dresr), pInSAR->interferogramFile->f) != (size_t)(Dresr))
            ase("\t-/-> Failed to save interferogram") ;

        /* Save filtered interferogram line */
        if(pInSAR->flag & WITH_FILTERING) {
            if (fwrite((float *)InterferoF, sizeof(float), (size_t)(Dresr), pInSAR->filteredInterferogramFile->f) != (size_t)(Dresr))
                ase("\t-/-> Failed to save filtered interferogram") ;
        }

        /* Save coherence line */
        if (fwrite((float *)Coherence, sizeof(float), (size_t)(Dresr), pInSAR->coherenceFile->f) != (size_t)(Dresr))
            ase("\t-/-> Failed to save local incidence") ;

        /* Save master amplitude line */
        if (fwrite((float *)Module1, sizeof(float), (size_t)(Dresr), pInSAR->masterAmplitudeImageFile->f) != (size_t)(Dresr))
            ase("\t-/-> Failed to save master amplitude") ;

        /* Save slave amplitude line */
        if (fwrite((float *)Module2, sizeof(float), (size_t)(Dresr), pInSAR->slaveAmplitudeImageFile->f) != (size_t)(Dresr))
            ase("\t-/-> Failed to save slave amplitude") ;

        /* If phase correction is requested, proceed. */
        if (pInSAR->flag & _ETAD_CORRECTION_) {
            rangeIndex = pInSAR->aoi->P[0].x + squareSpiralSize / 2 + cor / 2 ;
            for (j = 0; j < Dresr; j++, rangeIndex += rangeReductionFactor) {
                /* Compute local parameters at given position */
                currentPosition->x = (double)rangeIndex ;
                computeEffectiveRangeAzimuthCoordinatesOfPoint(currentPosition, effectivePosition, pInSAR) ;
                correctionPhaseMaster[j] = -sec2phase * ETADPhaseDelayAtPoint(effectivePosition->x, effectivePosition->y, pInSAR->masterInfo, NULL) ;
                correctionPhaseSlave[j] = -sec2phase * ETADPhaseDelayAtPoint(effectivePosition->x, effectivePosition->y, pInSAR->masterInfo, pInSAR->slaveInfo) ;
                correctionPhase[j] = correctionPhaseMaster[j] - correctionPhaseSlave[j] ;
                if (pInSAR->flag & _SAVE_ETAD_LAYERS_) {
                    ETADPhaseCorrectionLayer[0][j] =-sec2phase * (pInSAR->masterInfo->ETADPhaseDelays[0] - pInSAR->slaveInfo->ETADPhaseDelays[0]) ;
                    ETADPhaseCorrectionLayer[1][j] =-sec2phase * (pInSAR->masterInfo->ETADPhaseDelays[1] - pInSAR->slaveInfo->ETADPhaseDelays[1]) ;
                    ETADPhaseCorrectionLayer[2][j] =-sec2phase * (pInSAR->masterInfo->ETADPhaseDelays[2] - pInSAR->slaveInfo->ETADPhaseDelays[2]) ;
//                    ETADPhaseCorrectionLayer[0][j] = (pInSAR->masterInfo->ETADPhaseDelays[0] - pInSAR->slaveInfo->ETADPhaseDelays[0]) / pInSAR->masterInfo->lineTimeInterval ;
                }
            }
            fwrite((float *)correctionPhase, sizeof(float), Dresr, pInSAR->thirdPhaseComponentFile->f) ;
            if (pInSAR->flag & _SAVE_ETAD_LAYERS_) {
                if (ETADTroposphericPhaseCorrection) {
                    fwrite(ETADPhaseCorrectionLayer[2], sizeof(float), Dresr, ETADTroposphericPhaseCorrection->f) ;
                }
                if (ETADGeodeticPhaseCorrection) {
                    fwrite(ETADPhaseCorrectionLayer[1], sizeof(float), Dresr, ETADGeodeticPhaseCorrection->f) ;
                }
                if (ETADIonosphericPhaseCorrection) {
                    fwrite(ETADPhaseCorrectionLayer[0], sizeof(float), Dresr, ETADIonosphericPhaseCorrection->f) ;
                }
            }
            
//            fwrite((float *)correctionPhaseMaster, sizeof(float), Dresr, corr1->f) ;
//            fwrite((float *)correctionPhaseSlave, sizeof(float), Dresr, corr2->f) ;
        }
        
        
        /* If an external slant range DEM is available, recompute it at the same location and with the same size than the InSAR products */
        if (isExternalSlantRangeDEMPresent) {
            rangeIndex = pInSAR->aoi->P[0].x + squareSpiralSize / 2 + cor / 2 ;
            for (j = 0; j < Dresr; j++, rangeIndex += rangeReductionFactor) {
                if (squareSpiralSize > 1) {
                    /* Compute local parameters at given position */
                    currentPosition->x = (double)rangeIndex ;
                    computeEffectiveRangeAzimuthCoordinatesOfPoint(currentPosition, effectivePosition, pInSAR) ;
                    if (referenceImage) {
                        externalSlantRangeDEM[j] = (float)interpolFloatGridForImageCoordinate(BI.slantRangeDEMGrid, currentPosition->x, currentPosition->y) ;
                    }     
                    else {
                        externalSlantRangeDEM[j] = (float)ETADHeightAtPoint(effectivePosition->x, effectivePosition->y, pInSAR->masterInfo) ;
                    }
    
                    if(!areFloatValsEquals(externalSlantRangeDEM[j], floatNaN)) {
                        topographicPhase[j] = topographicalPhaseAtPoint(effectivePosition->x, effectivePosition->y, externalSlantRangeDEM[j], pInSAR) ;
                        tempComplexDouble.r = cos(topographicPhase[j]) ;
                        tempComplexDouble.i = sin(topographicPhase[j]) ;
                        tempComplexDouble = multComplexDouble(PhaseComplexe[j], cCComplexDouble(tempComplexDouble)) ;
                        
                        if (pInSAR->flag & _ETAD_CORRECTION_) {
                            tempComplexDouble2.r = cos(correctionPhase[j]) ;
                            tempComplexDouble2.i = sin(correctionPhase[j]) ;
                            tempComplexDouble = multComplexDouble(tempComplexDouble, cCComplexDouble(tempComplexDouble2)) ;
                        }
                        residualPhase[j] = (float)phaseOfComplexDouble(&tempComplexDouble) ;
                    }
                    else {
                       topographicPhase[j] = pInSAR->DEMExcludingValue ;
                       residualPhase[j] = (float)aRandomNumberBetweenValues(-PI, PI) ;
                    }
                    
                }
                else {
                    residualPhase[j] = (float)phaseOfComplexDouble(weightedPhase + j) ;
                }
                

                /* If required, compute local incidence angle */
                if ((pInSAR->flag & _CALIBRATE_IN_SIGMA0_) || (pInSAR->flag & _NORMALIZED_COH_) || pInSAR->flag & COMPUTE_LOCAL_INCIDENCE_ANGLE) {
                    /* If global master is defined, georeferencing must be performed with respect to global master */
                    if (pInSAR->SM2MpInSAR) {
                        earthRadiusAtPoint(currentPosition->x, currentPosition->y, externalSlantRangeDEM[j], pInSAR->SM2MpInSAR->geo) ;
                    }
                    /* Else georeferencing must be performed with respect to master */
                    else {
                        earthRadiusAtPoint(currentPosition->x, currentPosition->y, externalSlantRangeDEM[j], pInSAR->geo) ;
                    }

                    alpha[j] = pInSAR->geo->solving->alpha ;
                    alpha_at[j] = pInSAR->geo->solving->alpha_at ;
                    
                    deltaH = externalSlantRangeDEM[j] - externalSlantRangeDEM[(j)? j - 1 : 0] ;
                    deltaH = isnan(deltaH)? 0 : deltaH ;
                    slope = (deltaH * sin(alpha[j]) / (effectiveRangeResolutionCell + deltaH * cos(alpha[j]))) ;
                    
                    localIncidenceAngle[j] = alpha[j] - atan(slope) ;
                    geoidalIncidenceAngle[j] = (float)(180/PI * pInSAR->geo->solving->alpha) ;

                    sinAlpha[j] = sin(localIncidenceAngle[j]) ;
                    sinAlpha[j] = fabs(sinAlpha[j]) ;
                }
                
            }

            fwrite((float *)topographicPhase, sizeof(float), (size_t)(Dresr), pInSAR->firstPhaseComponentFile->f) ;
            fwrite((float *)residualPhase, sizeof(float), (size_t)(Dresr), pInSAR->residualPhaseFile->f) ;
            fwrite((float *)externalSlantRangeDEM, sizeof(float), (size_t)(Dresr), pInSAR->externalSlantRangeDEMFile->f) ;
            if (pInSAR->flag & COMPUTE_LOCAL_INCIDENCE_ANGLE) {
                fwrite((float *)localIncidenceAngle, sizeof(float), (size_t)(Dresr), localIncidenceAngleFile->f) ;
                fwrite((float *)geoidalIncidenceAngle, sizeof(float), (size_t)(Dresr), geoidalIncidenceAngleFile->f) ;
            }
        }

        if (pInSAR->flag & _CALIBRATE_IN_SIGMA0_) {
            for (j = 0; j < Dresr; j++) {
                Module1[j] = (sinAlpha[j])? 10 * (2 * log10f(Module1[j]) - 2 * log10f(pInSAR->averageBeta0CalibrationConstant) + log10f((float)sinAlpha[j])) : floatNaN ;
                Module1[j] = (Module1[j] < -30)? floatNaN : Module1[j] ;
                Module2[j] = (sinAlpha[j])? 10 * (2 * log10f(Module2[j]) - 2 * log10f(pInSAR->averageBeta0CalibrationConstant) + log10f((float)sinAlpha[j])) : floatNaN ;
                Module2[j] = (Module2[j] < -30)? floatNaN : Module2[j] ;
            }
            
            fwrite((float *)Module1, sizeof(float), (size_t)(Dresr), sigmaNoughtMaster->f) ;
            fwrite((float *)Module2, sizeof(float), (size_t)(Dresr), sigmaNoughtSlave->f) ;
        }
        
        /* If additionnally, geometrical decorrelation normalization is requested, do it */
        if (pInSAR->flag & _NORMALIZED_COH_) {
            for (j = 0; j < Dresr; j++) {
                range = pInSAR->ima1.z0 + effectivePosition->x * pInSAR->rad.rangeResolutionCell ;
                Bperp = fabs(pInSAR->B.Bx * cos(alpha_at[j]) + pInSAR->B.By * sin(alpha_at[j])) ;
                maxCoh = 1 - pInSAR->masterInfo->radarCarrierFrequency / pInSAR->masterInfo->rangeBandwidth * Bperp / range / tan(asin(sinAlpha[j])) ;
                
                if (Coherence[j] < maxCoh) {
                    Coherence[j] *= 1. / maxCoh ;
                }
            }
            fwrite((float *)Coherence, sizeof(float), (size_t)(Dresr), normalizedCoh->f) ;
        }
        
        
        if (isMaskPresent) {
            rangeIndex = pInSAR->aoi->P[0].x + squareSpiralSize / 2 + cor / 2 ;
            for (j = 0; j < Dresr; j++, rangeIndex += rangeReductionFactor) {
                currentPosition->x = (double)rangeIndex ;
                nearestNeighbourInterpolationOfGridForImageCoordinate(maskGrid, currentPosition->x, currentPosition->y) ;
                slantRangeMask[j] = maskGrid->charOutput ;
            }
            fwrite((char unsigned *)slantRangeMask, 1, (size_t)(Dresr), slantRangeMaskFile->f) ;
        }

        if (verbose) {
            updateProgressCounterForIndex(aCounter, i) ;
        }

	}
    printf("\n") ;

    /* If coherence median filtering is requested, proceed */
    if (pInSAR->coh.medianFilterSize) {
        medianFilterOfFloatFile(pInSAR->coherenceFile, pInSAR->coh.medianFilterSize, pInSAR->coh.medianFilterSize, NULL) ;
    }
    

    /* Before closing files, we apply the mask if present and if requested */
    if (isMaskPresent && pInSAR->flag & _WITH_MASKING_) {
        fflush(slantRangeMaskFile->f) ;
        fflush(pInSAR->interferogramFile->f) ;
        fflush(pInSAR->coherenceFile->f) ;
        printf("\nMasking interferogram file\n") ;
        maskFloatFileWithValue(pInSAR->interferogramFile->accessPath, slantRangeMaskFile->accessPath, NULL, 0, 0b00000001) ;
        printf("Masking Coherence file\n") ;
        maskFloatFileWithValue(pInSAR->coherenceFile->accessPath, slantRangeMaskFile->accessPath, NULL, 0, 0b00000001) ;
        if (isExternalSlantRangeDEMPresent) {
            fflush(pInSAR->residualPhaseFile->f) ;
            printf("Masking residual interferogram file\n") ;
            maskFloatFileWithValue(pInSAR->residualPhaseFile->accessPath, slantRangeMaskFile->accessPath, NULL, 0, 0b00000001) ;
        }
/*
        if (pInSAR->flag & WITH_FILTERING) {
            fflush(pInSAR->filteredInterferogramFile->f) ;
            printf("Masking filtered interferogram file\n") ;
            maskFloatFileWithValue(pInSAR->filteredInterferogramFile->accessPath, slantRangeMaskFile->accessPath, NULL, 0, 0b00000001) ;
        }
*/
    }

    /* We remove the filtered interferogram which at this level is only a side product reqired to improve coherence estimation */
    if(pInSAR->flag & WITH_FILTERING) {
        unlink((pInSAR->filter).filePath) ;
        freeRawFileDescriptor(pInSAR->filteredInterferogramFile) ;
        pInSAR->filteredInterferogramFile = NULL ;
    }

	freeRawFileDescriptor(pInSAR->masterImageFile) ;
	pInSAR->masterImageFile = NULL ;
	freeRawFileDescriptor(pInSAR->slaveImageFile) ;
	pInSAR->slaveImageFile = NULL ;
	freeRawFileDescriptor(pInSAR->coherenceFile) ;
	pInSAR->coherenceFile = NULL ;
	freeRawFileDescriptor(pInSAR->interferogramFile) ;
	pInSAR->interferogramFile = NULL ;
	freeRawFileDescriptor(pInSAR->masterAmplitudeImageFile) ;
	pInSAR->masterAmplitudeImageFile = NULL ;
	freeRawFileDescriptor(pInSAR->slaveAmplitudeImageFile) ;
	pInSAR->slaveAmplitudeImageFile = NULL ;
	if(pInSAR->flag & COMPUTE_STADARD_DEVIATION) {
		freeRawFileDescriptor(pInSAR->phaseStandardDeviationImageFile) ;
		pInSAR->phaseStandardDeviationImageFile = NULL ;
		freeRawFileDescriptor(pInSAR->heightStandardDeviationImageFile) ;
		pInSAR->heightStandardDeviationImageFile = NULL ;
	}
    if (pInSAR->flag & _CALIBRATE_IN_SIGMA0_) {
        freeRawFileDescriptor(sigmaNoughtMaster) ;
        freeRawFileDescriptor(sigmaNoughtSlave) ;
    }

	freeVectorFloat(Interfero, 0) ;
	freeVectorFloat(InterferoF, 0) ;
	freeVectorFloat(Coherence, 0) ;
	freeVectorFloat(EcartType, 0) ;
	freeVectorComplexFloat(standardDeviation, 0) ;
	freeVectorFloat(Module1, 0) ;
	freeVectorFloat(Module2, 0) ;
	freeVectorComplexDouble(scn, 0) ;
	freeVectorComplexDouble(scET, 0) ;
	freeVectorComplexDouble(scnI, 0) ;
	freeVectorComplexDouble(scnIF, 0) ;
	freeVectorDouble(scd1, 0) ;
	freeVectorDouble(scd2, 0) ;

	free(MInterfFiltre0) ;
	free(MInterfFiltre) ;
	free(MInterfc0) ;
	free(--MInterfc) ;
	free(Mphi0) ;
	free(--Mphi) ;
	free(MphiF0) ;
	free(--MphiF) ;
	free(Mphic0) ;
	free(--Mphic) ;
	free(MI10) ;
	free(--MI1) ;
	free(MI20) ;
	free(--MI2) ;

    if (localIncidenceAngle) {
        freeVectorFloat(localIncidenceAngle, 0) ;
        freeVectorFloat(geoidalIncidenceAngle, 0) ;
        freeVectorDouble(alpha, 0) ;
        freeVectorDouble(alpha_at, 0) ;
        freeVectorDouble(sinAlpha, 0) ;
    }
    if (pInSAR->flag & COMPUTE_LOCAL_INCIDENCE_ANGLE) {
        freeRawFileDescriptor(localIncidenceAngleFile) ;
        freeRawFileDescriptor(geoidalIncidenceAngleFile) ;
    }

	if (isExternalSlantRangeDEMPresent) {
        freeVectorFloat(externalSlantRangeDEM, 0) ;
        freeVectorFloat(topographicPhase, 0) ;
        freeVectorFloat(residualPhase, 0) ;
        freeRawFileDescriptor(pInSAR->firstPhaseComponentFile) ;
        pInSAR->firstPhaseComponentFile = NULL ;
        freeRawFileDescriptor(pInSAR->residualPhaseFile) ;
        pInSAR->residualPhaseFile = NULL ;
    }

    if (isMaskPresent) {
        freeVectorUChar(slantRangeMask, 0) ;
        freeRawFileDescriptor(slantRangeMaskFile) ;
        freeGridMap(maskGrid) ;
    }

	freeVectorComplexDouble(PhaseComplexe, 0) ;
    freeVectorComplexDouble(PhaseComplexeF, 0) ;
    freeVectorComplexDouble(weightedPhase, 0) ;
    freeVectorDouble(sd1, 0) ;
    freeVectorDouble(sd2, 0) ;
    freeVectorDouble(coherenceNumerator, 0) ;

    if (ETADPhaseCorrectionLayer) {
        freeMatrixFloat(ETADPhaseCorrectionLayer, 0, 0) ;
        if (ETADTroposphericPhaseCorrection) {
            freeRawFileDescriptor(ETADTroposphericPhaseCorrection) ;
        }
        if (ETADGeodeticPhaseCorrection) {
            freeRawFileDescriptor(ETADGeodeticPhaseCorrection) ;
        }
        if (ETADIonosphericPhaseCorrection) {
            freeRawFileDescriptor(ETADIonosphericPhaseCorrection) ;
        }
    }
    
    if(pInSAR->flag & WITH_FILTERING) {
//        LibFiltre(&blocFilter) ;
    }
	LibBlocInSAR(&BI) ;
	freeProgressCounter(aCounter) ;
    free(currentPosition) ;
    free(effectivePosition) ;
}

/*============================     FONCTIONS     ====================================================*/


/* ----------------- Conversion de l'erreur de phase en erreur altimétrique ----------------- */

void	SigmaPhiToSigmaH(float *EcartType, InSARParametersStruct *pInSAR, int azimuthIndex)
{
	int	j ;
    double range, azimuth ;

    range = pInSAR->aoi->P[0].x + (pInSAR->coh).spi / 2 + (pInSAR->coh).cor / 2 ;
	azimuth = azimuthIndex * (pInSAR->red).Fra + pInSAR->aoi->P[0].y + (pInSAR->coh).spi / 2 + (pInSAR->coh).cor / 2 ;

	for(j = 0; j < pInSAR->interf.lenr; j++, range += pInSAR->red.Fra) {
		EcartType[j] *= ambiguityAltitudeAtPoint(range, azimuth, 0, pInSAR) / TWOPI ;
	}
}


void resampleFloatFiles(InSARParametersStruct *pInSAR) 
{
    char *fileName, *outputFilePath ;
    int iFile, iX, iY ;
    int rangeIndex, azimuthIndex, rangeIndex0, azimuthIndex0 ;
	int azimuthReductionFactor, rangeReductionFactor ;
    float *aLine ; 
    coord2D *currentPosition, *effectivePosition ;
    CSLImage *referenceImage ;
    CSVStruct *floatFilesList ;
    gridMap *fileGrid ;
    rawFileDescriptor *outputFile ;

    /* Check external slant range DEM is present in reference image */
    if (!(referenceImage = getReferenceCSLImage(pInSAR))) {
        return ;
    }
    if ((floatFilesList = listFilesWithExtensionInDir("slantRange", referenceImage->dataDirectoryPath)) == NULL) {
        printf("\t-/-> No .slantRange files found in reference image. Nothing to resample.") ;
        return ;
    }
    
    printf("\n\t---> Resampling of external float files.\n") ;
    /* Init some values */
	azimuthReductionFactor = (pInSAR->red).Faz ;
	rangeReductionFactor = (pInSAR->red).Fra ;
    azimuthIndex0 = pInSAR->aoi->P[0].y + pInSAR->coh.spi / 2 + pInSAR->coh.coa / 2 + pInSAR->yShift ;
    rangeIndex0 = pInSAR->aoi->P[0].x + pInSAR->coh.spi / 2 + pInSAR->coh.cor / 2 + pInSAR->yShift ;

    /* Alloc current and effective positions */
    currentPosition = allocPoint() ;
    effectivePosition = allocPoint() ;
    
    /* Alloc resampled line */
    aLine = vectorFloat(0, pInSAR->externalSlantRangeDEMFile->xDim - 1) ;
    
    for ( iFile = 0; iFile < floatFilesList->numberOfEntries; iFile++) {
        fileName = getPointerToFileNameInPath(floatFilesList->stringVal[iFile]) ;
        fileGrid = allocAndInitExternalFileGridForImage(referenceImage, fileName) ;
        if (fileGrid) {
            printf("\t---> %s\n", fileName) ;
            outputFilePath = initStringWith3Strings(pInSAR->whereAmI, "/InSARProducts/", fileName) ;
            outputFile = openRawFileForWritingAtPath(outputFilePath) ;
            for ( iY = 0; iY < pInSAR->externalSlantRangeDEMFile->yDim; iY++) {
                azimuthIndex = azimuthIndex0 + iY * azimuthReductionFactor ;
                currentPosition->y = (double)azimuthIndex ;
                for ( iX = 0; iX < pInSAR->externalSlantRangeDEMFile->xDim; iX++) {
                    rangeIndex = rangeIndex0 + iX * rangeReductionFactor ;
                    currentPosition->x = (double)rangeIndex ;
                    computeEffectiveRangeAzimuthCoordinatesOfPoint(currentPosition, effectivePosition, pInSAR) ;
                    aLine[iX] = (float)interpolFloatGridForImageCoordinate(fileGrid, currentPosition->x, currentPosition->y) ;
                }
                fwrite(aLine, sizeof(float), (size_t)(pInSAR->externalSlantRangeDEMFile->xDim), outputFile->f) ;
            }
            free(outputFilePath) ;
            freeRawFileDescriptor(outputFile) ;
            freeGridMap(fileGrid) ;
        }
    }
    free(currentPosition) ;
    free(effectivePosition) ;
    
    freeVectorFloat(aLine, 0) ;
}