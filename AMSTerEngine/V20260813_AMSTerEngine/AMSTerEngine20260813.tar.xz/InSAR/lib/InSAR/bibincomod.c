
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* bibincomod.c */
/* Bibliothèque des fonctions utilisées par les routines incomod */
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
 */

#include "incomod.h"


/* ----------------- Allocation d'un bloc interferométrique ----------------- */
void AllocBlocInSAR(struct BlocInSAR *BI, InSARParametersStruct *pInSAR)
{
    BI->lenr = pInSAR->aoi->P[2].x - pInSAR->aoi->P[0].x + 1;
    
    BI->masterImage = matrixComplexFloat(0, BI->Dima - 1, 0, pInSAR->masterImageFile->xDim - 1) ;
    BI->slaveImage = matrixComplexFloat(0, BI->Dima - 1, 0, pInSAR->slaveImageFile->xDim - 1) ;
    
	BI->intensity1 = matrixDouble(0, BI->Dima - 1, 0, BI->lenr - 1) ;
	BI->intensity2 = matrixDouble(0, BI->Dima - 1, 0, BI->lenr - 1) ;
    BI->Interf  = matrixComplexFloat(0, BI->Dima - 1, 0, BI->lenr - 1) ;
    BI->InterfF = NULL ;
    BI->withFiltering = 0 ;
    BI->filterTileTool = NULL ;
    BI->secondFilterTileTool = NULL ;
    if(pInSAR->flag & WITH_FILTERING) {
        BI->InterfF = matrixComplexFloat(0, BI->Dima - 1, 0, BI->lenr - 1) ;
        BI->withFiltering = 1 ;
    }
	BI->PhiOrb = matrixComplexFloat(0, BI->Dima - 1, 0, BI->lenr - 1) ;
//	BI->PhiGeom = matrixComplexFloat(0, BI->Dima - 1, 0, BI->lenr - 1) ;
//	BI->PhiTopo = matrixComplexFloat(0, BI->Dima - 1, 0, BI->lenr - 1) ;
    BI->slantRangeDEMGrid = NULL ;
}

/* ----------------- Allocation d'un bloc interferométrique ----------------- */
void LibBlocInSAR(struct BlocInSAR *BI)
{
    freeMatrixComplexFloat(BI->masterImage, 0, 0) ;
    freeMatrixComplexFloat(BI->slaveImage, 0, 0) ;
    freeMatrixDouble(BI->intensity1, 0, 0) ;
    freeMatrixDouble(BI->intensity2, 0, 0) ;
    if (BI->InterfF != NULL) {
        freeMatrixComplexFloat(BI->InterfF, 0, 0) ;
    }
    freeMatrixComplexFloat(BI->Interf, 0, 0) ;
    freeMatrixComplexFloat(BI->PhiOrb, 0, 0) ;
//    freeMatrixComplexFloat(BI->PhiGeom, 0, 0) ;
//    freeMatrixComplexFloat(BI->PhiTopo, 0, 0) ;
    if(BI->filterTileTool != NULL) {
        freeTileTool(BI->complexPhaseTileTool) ;
        freeTileTool(BI->filterTileTool) ;
    }
    if(BI->secondFilterTileTool != NULL) {
        freeTileTool(BI->secondFilterTileTool) ;
    }
    if (BI->withFiltering) {
        freeFFT(BI->xFFT) ;
        freeFFT(BI->yFFT) ;
    }

    if (BI->slantRangeDEMGrid) {
        freeGridMap(BI->slantRangeDEMGrid) ;
    }
    
}

/* ----------------- Lecture d'un bloc de données ----------------- */

void	LectureBlocInSAR(FILE *f, complexFloat *imageDataBloc, int NumberOfLinesToRead, int xDimInputImage, off_t startIndex)
{
    int iY ;    
    
    if (fseeko(f, startIndex, 0)) {
        ase ("incomodLib.c : Failed to fseek into input file") ;
    }
    for (iY = 0; iY < NumberOfLinesToRead; iY++) {
        if(fread((complexFloat *)(imageDataBloc + iY * xDimInputImage), sizeof(complexFloat), xDimInputImage, f) != (size_t)xDimInputImage) {
            printf("\nLdec = %ld\n", startIndex) ;
            ase("Failed to read input file\n") ;
        }
    }
}

/* ----------------- Génération de l'interfero, de l'interfero filtré et des modules ----------------- */

void GenPhi(struct BlocInSAR *BI, InSARParametersStruct *pInSAR)
{
	int	i, j, Ind1, Ind2 ;
	off_t	Ldec ;

	BI->DecLignes = 0 ;
	if(BI->IndiceLigne + BI->Dima > pInSAR->aoi->P[2].y + 1) {
//        printf("\nyIndex = %d\tDima = %d\ttop = %lf\top = %d\n", BI->IndiceLigne, BI->Dima, pInSAR->aoi->P[2].y, pInSAR->sup.Shaz) ;
		BI->DecLignes = BI->IndiceLigne + BI->Dima - pInSAR->aoi->P[2].y - 1 ;
		BI->IndiceLigne -= BI->DecLignes ;
        if (BI->IndiceLigne < 0) {
            BI->IndiceLigne = BI->DecLignes = 0 ;
        }
//        printf("DecLigne = %d\tyIndex = %d\n", BI->DecLignes, BI->IndiceLigne) ;
//        Ldec = (off_t)(BI->IndiceLigne * pInSAR->masterImageFile->xDim) * sizeof(complexFloat) ;
//        printf("LdecMaster = %lld\n", Ldec) ;
//        Ldec = (off_t)(BI->IndiceLigne * pInSAR->slaveImageFile->xDim) * sizeof(complexFloat) ;
//        printf("LdecSlave = %lld\n", Ldec) ;
	}

    Ldec = (off_t)(BI->IndiceLigne * pInSAR->masterImageFile->xDim) * sizeof(complexFloat) ;
	LectureBlocInSAR(BI->f1, BI->masterImage[0], BI->Dima, pInSAR->masterImageFile->xDim , Ldec) ;
	Ldec = (off_t)(BI->IndiceLigne * pInSAR->slaveImageFile->xDim) * sizeof(complexFloat) ;
	LectureBlocInSAR(BI->f2, BI->slaveImage[0], BI->Dima, pInSAR->slaveImageFile->xDim , Ldec) ;
    

    if (pInSAR->flag & FLAT_EARTH_PHASE_REMOVAL) {
        GenPhiOrb(BI, pInSAR) ;
    }
    /*
    if (BI->slantRangeDEMGrid != NULL) {
        GenPhiTopo(BI, p) ;
    }
     */
    
	for(i=0; i<BI->Dima; i++) {
        Ind1 = Ind2 = pInSAR->aoi->P[0].x ;
		for(j=0; j<BI->lenr; j++, Ind1++, Ind2++) {
            (BI->intensity1)[i][j] = sqmC((BI->masterImage)[i][Ind1]) ;
            (BI->intensity2)[i][j] = sqmC((BI->slaveImage)[i][Ind2]) ;
            
            (BI->Interf)[i][j] = mC((BI->masterImage)[i][Ind1], cC((BI->slaveImage)[i][Ind2])) ;
            if (pInSAR->flag & FLAT_EARTH_PHASE_REMOVAL) {
                (BI->Interf)[i][j] = mC((BI->Interf)[i][j], cC((BI->PhiOrb)[i][j])) ;
            }
		}
		BI->IndiceLigne ++ ;
	}
    
	BI->IndiceLigne -= (pInSAR->coh).spi - 1 ;

    if(pInSAR->flag & WITH_FILTERING)
        tileByTileFiltering(BI) ;
}

/* Interferometric phase generation with double filtering */
/* First filter aimed at reducing phase noise as expected */
/* Second filtering aimed at generating a strongly filtered version of the interferogram to estimate roughly the topographic phase */
/* This estimated topographic phase will be retrieved from the filtererd interferogram to better estimate the coherence linked to the FILTERED interferogram */
void	GenPhiWithDoubleFiltering(struct BlocInSAR *BI, InSARParametersStruct *pInSAR)
{
	int	i, j, Ind1, Ind2 ;
	off_t	Ldec ;
    complexFloat **tempPointer ;
	
	BI->DecLignes = 0 ;
	if(BI->IndiceLigne + BI->Dima > pInSAR->aoi->P[2].y + 1) {
		BI->DecLignes = BI->IndiceLigne + BI->Dima - pInSAR->aoi->P[2].y - 1 ;
		BI->IndiceLigne -= BI->DecLignes ;
        if (BI->IndiceLigne < 0) {
            BI->IndiceLigne = BI->DecLignes = 0 ;
        }
	}
    
	Ldec = (off_t)(BI->IndiceLigne * pInSAR->masterImageFile->xDim) * sizeof(complexFloat) ;
	LectureBlocInSAR(BI->f1, BI->masterImage[0], BI->Dima, pInSAR->masterImageFile->xDim , Ldec) ;
	Ldec = (off_t)(BI->IndiceLigne * pInSAR->slaveImageFile->xDim) * sizeof(complexFloat) ;
	LectureBlocInSAR(BI->f2, BI->slaveImage[0], BI->Dima, pInSAR->slaveImageFile->xDim , Ldec) ;
    
	for(i=0; i<BI->Dima; i++) {
		//		GenPhiOrb(BI, p, BI->IndiceLigne) ;
        Ind1 = Ind2 = pInSAR->aoi->P[0].x ;
		for(j=0; j<BI->lenr; j++, Ind1++, Ind2++) {
			(BI->Interf)[i][j] = mC((BI->masterImage)[i][Ind1], cC((BI->slaveImage)[i][Ind2])) ;
			(BI->intensity1)[i][j] = sqmC((BI->masterImage)[i][Ind1]) ;
			(BI->intensity2)[i][j] = sqmC((BI->slaveImage)[i][Ind2]) ;
		}
		BI->IndiceLigne ++ ;
	}
    
	BI->IndiceLigne -= (pInSAR->coh).spi - 1 ;
    
    tileByTileFiltering(BI) ;
    
//	blocFilteringInFourierSpace(BI->InterfF, BI->Interf, firstFilter) ;
	
	/* This is a trick to keep artificially a unitary filter in case of too sharp gaussian filtering */
/*	for(i = 0; i < BI->Dima; i++) {
		for(j = 0; j < BI->lenr; j++) {
			norm = (modC((BI->Interf)[i][j]) < Chouillat)? 1 : modC((BI->InterfF)[i][j]) / modC((BI->Interf)[i][j]) ;
			(BI->Interf)[i][j] = mRC((BI->Interf)[i][j], norm) ;
		}
	}
 */
    /* Swap interf and interfF */
    tempPointer = BI->Interf ;
    BI->Interf = BI->InterfF ;
    BI->InterfF = tempPointer ;
    
    secondFilter(BI) ;
    
    /* Swap interf and interfF */
    tempPointer = BI->Interf ;
    BI->Interf = BI->InterfF ;
    BI->InterfF = tempPointer ;

//	blocFilteringInFourierSpace(BI->Interf, BI->InterfF, secondFilter) ;
}



/* ----------------- Transfert de l'interfero filtre ----------------- */
void TransfertInterfFiltre(float *Ligne, struct BlocInSAR *BI, int IndiceLigne, int Dec)
{
	int	i ;

	IndiceLigne += Dec + BI->DecLignes ;
    for(i=0; i<BI->lenr; i++) {
        if (BI->withFiltering) {
            Ligne[i] = (float)phi(&((BI->InterfF)[IndiceLigne][i])) ;
        }
        else {
            Ligne[i] = (float)phi(&((BI->Interf)[IndiceLigne][i])) ;
        }
    }
}


/* ----------------- Transfert de la phase interferométrique ----------------- */
void TransfertPhi(complexFloat *Phi, struct BlocInSAR *BI, int IndiceLigne, int Dec)
{
	int	i ;

	IndiceLigne += Dec + BI->DecLignes ;
	for(i=0; i< BI->lenr - 2 * Dec; i++) {
		Phi[i].r = (double)(BI->Interf)[IndiceLigne][i + Dec].r ;
		Phi[i].i = (double)(BI->Interf)[IndiceLigne][i + Dec].i ;
	}
}


/* ----------------- Transfert de la phase interferométrique filtrée ----------------- */
void TransfertPhiFiltre(complexFloat *Phi, struct BlocInSAR *BI, int IndiceLigne, int Dec)
{
	int	i ;

	IndiceLigne += Dec + BI->DecLignes ;
	for(i=0; i< BI->lenr - 2 * Dec; i++) {
		Phi[i].r = (double)(BI->InterfF)[IndiceLigne][i + Dec].r ;
		Phi[i].i = (double)(BI->InterfF)[IndiceLigne][i + Dec].i ;
	}
}


/* ----------------- Transfert des modules ----------------- */
void TransfertMod(float *Mod1, float *Mod2, struct BlocInSAR *BI, int IndiceLigne, int Dec)
{
	int	i ;

	IndiceLigne += Dec + BI->DecLignes ;
	for(i=0; i< BI->lenr - 2 * Dec; i++) {
		Mod1[i] = (BI->intensity1)[IndiceLigne][i + Dec] ;
		Mod2[i] = (BI->intensity2)[IndiceLigne][i + Dec] ;
	}
}



/* ----------------- Initialisation du Filtre ----------------- */

void initFiltering(struct BlocInSAR *BI, InSARParametersStruct *pInSAR)
{
    int yDim, xDim ;
    int unsigned xTileSize, yTileSize, xTileBorderSize, yTileBorderSize ;
    float sigmaY, sigmaX ;
    
    /* Initialize tile tools parameters */
    yDim = BI->Dima ;
    xDim = BI->lenr ;

    sigmaX = ((pInSAR->filter).sigmar < (float)(pInSAR->red).Fra)? (float)(pInSAR->red).Fra : (pInSAR->filter).sigmar ;
    sigmaY = ((pInSAR->filter).sigmaz < (float)(pInSAR->red).Faz)? (float)(pInSAR->red).Faz : (pInSAR->filter).sigmaz ;

    xTileSize = ceil2ofIntVal(_XCTILESIZE_) ;
    xTileBorderSize = _XCTILEBORDERSIZE_ ;
    if (_XCTILESIZE_ > xDim) {
        xTileSize = ceil2ofIntVal(xDim) / 2 ;
        xTileBorderSize = xTileSize / 16 ;
    }
    
    yTileSize = ceil2ofIntVal(_YCTILESIZE_) ;
    yTileBorderSize = _YCTILEBORDERSIZE_ ;
    if (_YCTILESIZE_ > yDim) {
        yTileSize = ceil2ofIntVal(yDim) / 2 ;
        yTileBorderSize = yTileSize / 16 ;
    }
    
    
    /* Initialize complex phase tile tool */
    BI->complexPhaseTileTool = allocTileToolForDataOfType((void **)BI->Interf, (void **)BI->InterfF, BI->lenr, BI->Dima, "complexFloat") ;
    initTileToolWithSizes(BI->complexPhaseTileTool, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    setMirroringForTileTool(BI->complexPhaseTileTool) ;
    
    /* Initialize filter tile tool */
    BI->filterTileTool = allocTileToolForDataOfType(NULL, NULL, BI->lenr, BI->Dima, "float") ;
    initTileToolWithSizes(BI->filterTileTool, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    initFilterTileTool(BI->filterTileTool, sigmaX, sigmaY) ;
    
    /* Initialize FFT's */
    BI->xFFT = initFFT(xTileSize, yTileSize, ALONGX) ;
    BI->yFFT = initFFT(xTileSize, yTileSize, ALONGY) ;
}

void initSecondFilter(struct BlocInSAR *BI, InSARParametersStruct *pInSAR)
{
    int yDim, xDim ;
    int unsigned xTileSize, yTileSize, xTileBorderSize, yTileBorderSize ;
    float sigmaY, sigmaX ;
    
    /* Initialize tile tools parameters */
    yDim = BI->Dima ;
    xDim = BI->lenr ;
    sigmaY = (pInSAR->filter).sigmaz ;
    sigmaX = (pInSAR->filter).sigmar ;
    
    xTileSize = ceil2ofIntVal(_XCTILESIZE_) ;
    xTileBorderSize = _XCTILEBORDERSIZE_ ;
    if (_XCTILESIZE_ > xDim) {
        xTileSize = ceil2ofIntVal(xDim) / 2 ;
        xTileBorderSize = xTileSize / 16 ;
    }
    
    yTileSize = ceil2ofIntVal(_YCTILESIZE_) ;
    yTileBorderSize = _YCTILEBORDERSIZE_ ;
    if (_YCTILESIZE_ > yDim) {
        yTileSize = ceil2ofIntVal(yDim) / 2 ;
        yTileBorderSize = yTileSize / 16 ;
    }
    
    /* Initialize second filter tile tool */
    BI->secondFilterTileTool = allocTileToolForDataOfType(NULL, NULL, BI->lenr, BI->Dima, "float") ;
    initTileToolWithSizes(BI->secondFilterTileTool, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    initFilterTileTool(BI->secondFilterTileTool, sigmaX, sigmaY) ;
}

/* ----------------- Filtrage de l'interfero ----------------- */

void tileByTileFiltering(struct BlocInSAR *BI)
{
    size_t xTileIndex, yTileIndex ;
    complexFloat **complexPhaseTile ;
    
    complexPhaseTile = (complexFloat **)BI->complexPhaseTileTool->tile ;
    for(yTileIndex = 0; yTileIndex < BI->complexPhaseTileTool->yTileNumber; yTileIndex++) {
        for(xTileIndex = 0; xTileIndex < BI->complexPhaseTileTool->xTileNumber; xTileIndex++) {
            copyTileAtIndexes(BI->complexPhaseTileTool, xTileIndex, yTileIndex) ;
            
            fftX(FORWARD_FFT, complexPhaseTile[0], BI->xFFT) ;
            fftY(FORWARD_FFT, complexPhaseTile[0], BI->yFFT) ;
            
            tileFiltering(BI->complexPhaseTileTool, BI->filterTileTool) ;
            
            fftX(INVERSE_FFT, complexPhaseTile[0], BI->xFFT) ;
            fftY(INVERSE_FFT, complexPhaseTile[0], BI->yFFT) ;
            
            saveTile(BI->complexPhaseTileTool) ;
        }
    }
}


/* Second filter: The filtered interferogram is filtered once again with a second filter and saved back in place of the initial interferogram */
void secondFilter(struct BlocInSAR *BI)
{
    tileTool *aTileTool ;
    
//    swapInAndOutInTileTool(BI->filterTileTool) ;
    
    aTileTool = BI->filterTileTool ;
    BI->filterTileTool = BI->secondFilterTileTool ;
    BI->secondFilterTileTool = aTileTool ;
    
    tileByTileFiltering(BI) ;

    aTileTool = BI->filterTileTool ;
    BI->filterTileTool = BI->secondFilterTileTool ;
    BI->secondFilterTileTool = aTileTool ;
    
}

/* Orbital phase computation */
void GenPhiOrb(struct BlocInSAR *BI, InSARParametersStruct *pInSAR)
{
    int	i, j, rangeIndex, azimuthIndex ;
    coord2D currentPosition[1], effectivePosition[1];

    azimuthIndex = BI->IndiceLigne + pInSAR->yShift ;
	for(i = 0; i < BI->Dima; i++, azimuthIndex++) {
        rangeIndex = pInSAR->aoi->P[0].x ;
        for(j = 0; j < BI->lenr; j++, rangeIndex++) {
            currentPosition->x = (double)rangeIndex ;
            currentPosition->y = (double)azimuthIndex ;
            computeEffectiveRangeAzimuthCoordinatesOfPoint(currentPosition, effectivePosition, pInSAR) ;
            (BI->PhiOrb)[i][j] = complexOrbitalPhaseAtPoint(effectivePosition->x, effectivePosition->y, pInSAR) ;
        }
    }
}


/* Geometrical phase computation */
void GenPhiGeom(struct BlocInSAR *BI, InSARParametersStruct *pInSAR)
{
	int	i, j, rangeIndex, azimuthIndex ;
    coord2D currentPosition[1], effectivePosition[1];
    double H ;
    
    azimuthIndex = BI->IndiceLigne + pInSAR->yShift ;
	for(i = 0; i < BI->Dima; i++, azimuthIndex++) {
        rangeIndex = pInSAR->aoi->P[0].x ;
        for(j = 0; j < BI->lenr; j++, rangeIndex++) {
            currentPosition->x = (double)rangeIndex ;
            currentPosition->y = (double)azimuthIndex ;
            computeEffectiveRangeAzimuthCoordinatesOfPoint(currentPosition, effectivePosition, pInSAR) ;
            H = (float)interpolFloatGridForImageCoordinate(BI->slantRangeDEMGrid, effectivePosition->x, effectivePosition->y) ;
            
            (BI->PhiGeom)[i][j] = complexGeometricalPhaseAtPoint(effectivePosition->x, effectivePosition->y, H, pInSAR) ;
        }
    }
}


/* Topographical phase computation */
void GenPhiTopo(struct BlocInSAR *BI, InSARParametersStruct *pInSAR)
{
    int    i, j, rangeIndex, azimuthIndex ;
    coord2D currentPosition[1], effectivePosition[1];
    double H ;
    
    azimuthIndex = BI->IndiceLigne + pInSAR->yShift ;
	for(i = 0; i < BI->Dima; i++, azimuthIndex++) {
        rangeIndex = pInSAR->aoi->P[0].x ;
         for(j = 0; j < BI->lenr; j++, rangeIndex++) {
            currentPosition->x = (double)rangeIndex ;
            currentPosition->y = (double)azimuthIndex ;
            computeEffectiveRangeAzimuthCoordinatesOfPoint(currentPosition, effectivePosition, pInSAR) ;
            H = (float)interpolFloatGridForImageCoordinate(BI->slantRangeDEMGrid, effectivePosition->x, effectivePosition->y) ;

            (BI->PhiTopo)[i][j] = complexTopographicalPhaseAtPoint(effectivePosition->x, effectivePosition->y, H, pInSAR) ;
        }
    }
}


