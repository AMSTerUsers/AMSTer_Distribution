
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  phaseUnwrappingLib.c
//  phaseUnwrapping
//
//  Created by Dominique Derauw on 25/04/2017.
//  Copyright © 2017 Dominique Derauw. All rights reserved.
//

#include "phaseUnwrappingLib.h"



int phaseUnwrapping(CSVStruct *csv)
{
	char *InSARParametersFilePath = NULL ;
    char *maskPath ;
    char skipUnwrapping = 0, InSARParametersFileFound ;
	int	currentDirectoryFdesc, i ;
    int phaseUnwrappingOK = 1 ;
	InSARParametersStruct	*pInSAR ;
	time_t startTime, endTime ;

	InSARParametersFileFound = 0 ;
	currentDirectoryFdesc = open(".", O_RDONLY) ;
	fchdir(currentDirectoryFdesc) ;

	if(isArgumentPresentInCSV(csv, "help") || isFlagPresentInCSV(csv, "h"))
		phaseUnwrappingUsage() ;

	i = 1 ;
	while (i < csv->numberOfEntries) {
		InSARParametersFilePath = initStringWithString((char *)csv->stringVal[i]) ;
		if(fileExistsAtPath(InSARParametersFilePath)) {
			InSARParametersFileFound = 1 ;
			break ;
		}
		i++ ;
		free(InSARParametersFilePath) ;
	}
	if(!InSARParametersFileFound) {
		InSARParametersFilePath = initStringWithString("./TextFiles/InSARParameters.txt") ;
		if(!fileExistsAtPath(InSARParametersFilePath)){
			free(InSARParametersFilePath) ;
			InSARParametersFilePath = initStringWithString("./InSARParameters.txt") ;
			if(!fileExistsAtPath(InSARParametersFilePath))
				phaseUnwrappingUsage() ;
		}
		InSARParametersFileFound = 1 ;
	}
	time(&startTime) ;

	pInSAR = readInSARParametersFileAtPath(InSARParametersFilePath) ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "F"))? _CONSIDER_FILTERED_INTERF_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "-r"))? RESIDUAL_PHASE_ONLY : pInSAR->flag ;
    pInSAR->flag |= (!isFlagPresentInCSV(csv, "-p"))? _PHASE_TO_MEASUREMENT_CONVERSION_ : pInSAR->flag ;
    pInSAR->flag |= (fileExistsAtPath(pInSAR->firstPhaseComponent.filePath))? FIRST_PHASE_COMPONENT_EXISTS : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "-f"))? FLATTENING_CORRECTION : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "-g"))? _SAVE_SNAPHU_ZONEMAP_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "-t"))? _COHERENCE_THRESHOLD_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "-n"))? _NO_PHASE_NORMALIZATION_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "N"))? _NO_NAN_FILL_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "-z"))? _ZERO_FLATTENING_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "-m"))? _WITH_MASKING_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "-2"))? _DETPHUN2_ : pInSAR->flag ;
    if (pInSAR->flag & _ZERO_FLATTENING_) {
        pInSAR->flag |= FLATTENING_CORRECTION ;
    }
   
    /* Select method */
    pInSAR->flag |= (isArgumentPresentInCSV(csv, "--detPhUn"))? _DETPHUN_ : pInSAR->flag ;
    pInSAR->flag |= (isArgumentPresentInCSV(csv, "--snaphu"))? _SNAPHU_ : pInSAR->flag ;
    pInSAR->flag |= (pInSAR->flag & _DETPHUN_ || pInSAR->flag & _SNAPHU_)? pInSAR->flag : _BRANCH_CUT_ ;
    if (!(pInSAR->flag & _SNAPHU_)) {
      pInSAR->flag |= (isArgumentPresentInCSV(csv, "--branchCut"))? _BRANCH_CUT_ : pInSAR->flag ;
    }

    skipUnwrapping = (isArgumentPresentInCSV(csv, "--convertOnly")) ;
    
    if (!skipUnwrapping) {
        /* Verify masking flag */
        if (pInSAR->flag & _WITH_MASKING_ || pInSAR->flag & _COHERENCE_THRESHOLD_) {
            printf("\t---> Masking is requested \n") ;
            maskPath = initStringWith2Strings(pInSAR->whereAmI, "InSARProducts/slantRangeMask") ;
            if (!fileExistsAtPath(maskPath)) {
                printf("\t-/-> But slant range mask not found at path %s.\n", maskPath) ;
                if (!(pInSAR->flag & _COHERENCE_THRESHOLD_)) {
                    pInSAR->flag &= _WITH_MASKING_ ^ 0xFFFFFFFF ;
                }
            }

            /* Mask management */
            pInSAR->thresholdedSlantRangeMask = maskThresholdingByFile(maskPath, pInSAR->coh.filePath, pInSAR->conex.seuilnet, (pInSAR->flag & _COHERENCE_THRESHOLD_)) ;
            free(maskPath) ;
        }

        if (pInSAR->flag & _DETPHUN_) {
            pInSAR->flag = pInSAR->flag & ~FLATTENING_CORRECTION ;
            pInSAR->flag |= (isFlagPresentInCSV(csv, "-f"))? _DETPHUN_WITH_FILTERING_ : pInSAR->flag ;
            detPhUnManagement(csv, pInSAR) ;
        }

        if (pInSAR->flag & _SNAPHU_) {
            phaseUnwrappingOK = snaphuManagement(csv, pInSAR) ;
            if (!phaseUnwrappingOK) {
                printf("\t-/-> snaphu failed... So, lets try home made branch cut...\n") ;
                pInSAR->flag &= _SNAPHU_ ^ 0xFFFFFFFF ;
                pInSAR->flag &= _SAVE_SNAPHU_ZONEMAP_ ^ 0xFFFFFFFF ;
                pInSAR->flag |= _BRANCH_CUT_ ;
            }
            
            fchdir(currentDirectoryFdesc) ;
        }

        /* If not snaphu nor detphun, then use branch cut algorithm */
        if (pInSAR->flag & _BRANCH_CUT_) {
            /* Create connexion file */
            residuesSearch(pInSAR) ;
            saveInSARParametersFileAtPath(pInSAR, InSARParametersFilePath) ;
            printf("\n\n") ;
            biasedCoherenceEstimation(pInSAR) ;
            saveInSARParametersFileAtPath(pInSAR, InSARParametersFilePath) ;
            printf("\n\n") ;
            residuesConnexion(pInSAR) ;
            saveInSARParametersFileAtPath(pInSAR, InSARParametersFilePath) ;

            /* Unwrapp phase using connexions */
            phaseUnwrappingOK = branchCutPhaseUnwrapping(pInSAR) ;
        }

//        unlink(pInSAR->thresholdedSlantRangeMask) ;
//        pInSAR->thresholdedSlantRangeMask == NULL ;
    }

    if (skipUnwrapping && !fileExistsAtPath(pInSAR->dephi.filePath)) {
        ase("Proceed to phase unwrapping before willing to convert phase to measurement\n") ; 
    }
    

    /* If there is a first phase component we add it to the unwrapped phase taking into account the excluding value */
    if ((pInSAR->flag & FIRST_PHASE_COMPONENT_EXISTS) && !(pInSAR->flag & RESIDUAL_PHASE_ONLY) && phaseUnwrappingOK) {
        addFirstPhaseComponentToUnWrappedPhase(pInSAR) ;
    }

    /* Convert phase to height if required */
    if(pInSAR->flag & _PHASE_TO_MEASUREMENT_CONVERSION_  && phaseUnwrappingOK) {
        printf("\nPhase to height conversion\n");
        phaseToMeasurementConversion(pInSAR) ;
    }

	saveInSARParametersFileAtPath(pInSAR, InSARParametersFilePath) ;
    freeInSARParametersStruct(pInSAR) ;
    free(InSARParametersFilePath) ;

	time(&endTime) ;
	duration(startTime, endTime) ;
	return(phaseUnwrappingOK) ;
}


void phaseUnwrappingUsage()
{
	printf("\nUsage:\nphaseUnwrapping [/pathTo/InSARParameters.txt] [-cpftrnFNm] [--detPhUn] [--branchCut] [--snaphu [init]]\n\n") ;
    printf("The phaseUnwrapping routine will perform the phase unwrapping of the \ninterferogram given in the InSAR parameter file\n") ;
    printf("The default method is a coherence-guided branch-cut algorithm using established residues connexions.\n\n") ;

    printf("By default, the phase is unwrapped and converted to local heigths.\n") ;
    printf("Options:\n") ;
    printf("-p :\tIssues only the unwrapped phase in radian.\n") ;
    printf("-r :\tThe unwrapped residual phase is issued without adding the first phase component.\n") ;
    printf("\t  Therefore, deformation measurement is considered. Unwrapped phase will be\n\tconverted in meter and saved with name deformationMap.\n") ;
    printf("-t :\tCleaning threshold is used to generate a mask thqat can then be used in geoprojection process.\n") ;
    printf("-f :\tIf an external DEM is present and if a first phase component was computed,\n\tthe -f option force removal of the best phase plane computed on the biggest zone.\n") ;
    printf("-n :\tNo phase normalization performed\n") ;
    printf("-F :\tThe filtered interferogram will be unwrapped \n\t(use of -F option is thus also required for both residuesSearch and biasedCoherence processes)\n") ;
    printf("-N :\tNo NaN fill: phase of isolated points is kept in place of replacing it by NaN\n") ;
    printf("-m : biased coherence used to guide branch cut is masked using the thresholded slantRangeMask (see below)\n") ;

    printf("\nSnaphu support:\n") ;
    printf("\tCall to snaphu is also provided. In this case, only flags m, F, r, t and p are considered.\n") ;
    printf("\tIf present within the ./TextFile directory, a snaphu.conf file will be used\n") ;
    printf("\tIf not present, it will be created with defaut parameters and directly sent to snaphu\n") ;
    printf("\tIf using the init keyword, a snaphu.conf file will be created with default parameters\n\tfor further modification by the user (no call to snaphu)\n") ;
    printf("-m :\tIf present, a binary mask necessarily named \"slantRangeMask\" and coded in CHAR is applied to the coherence before snaphu phase unwrapping\n") ;
    printf("\tInput mask is a three-level mask.\n\tIf mask == 0, no masking is considered. \n") ;
    printf("\tIf mask == 1, masking is preserved whatever the coherence level (e.g. water bodies).\n") ;
    printf("\tIf mask == 2, masking is set if coherence is lower than threshold and unset if higher.\n") ;
    printf("-t : Force coherence masking if below threshold.\n") ;
    printf("\n") ;
    printf("-g : snaphu zone map is saved along with InSAR products\n") ;
    printf("A coherence threshold below which mask is applied can be set through the /* Coherence cleaning threshold */ keyValue in InSARParameters.txt file.\n") ;

    printf("\nDetPhUn support:\n") ;
    printf("DetPhUn may be used alone or as preprocessing to snaphu or to branch cut\n") ;
    printf("Specific options:\n") ;
    printf("N=k where k is the number of iterations. Defult is 1.\n") ;
    printf("A coherence threshold below which phase will be set to zero can be set through the /* Coherence cleaning threshold */ keyValue in InSARParameters.txt file.\n") ;
    printf("If willing to use detPhun as preprocessing use --snaphu or --branchCut as additional options\n") ;
    printf("\n") ;

	printf("\nIf used with no parameters, the routine will look for an \"InSARparameters.txt\".\n") ;
	printf("file within the working directory or within the ./TextFiles subdirectory.\n") ;
	printf("Any other path to a text file containing InSAR parameters can be given as\nfirst parameter.\n\n") ;
	exit(0) ;
}




/* Test if we deal with deformation or topographic measurement */
int unsigned defoOrTopo(InSARParametersStruct *pInSAR)
{
    char *aPath ;

    /* If deformation measurement is considered ...*/
    if (pInSAR->flag & RESIDUAL_PHASE_ONLY) {
        pInSAR->flag &= _TOPO_ ^ 0xFFFFFFFF ;
        pInSAR->flag |= _DEFO_ ;
        if(pInSAR->srDEM.filePath != NULL) {
            aPath = initStringWithString(getDirectoryPathFromPath(pInSAR->srDEM.filePath)) ;
            free(pInSAR->srDEM.filePath) ;
        }
        else
            aPath = initStringWithString(getDirectoryPathFromPath(pInSAR->interf.filePath)) ;

        (pInSAR->srDEM).filePath = initStringWith2Strings(aPath, "deformationMap") ;
        free(aPath) ;
    }
    else {
        pInSAR->flag &= _DEFO_ ^ 0xFFFFFFFF ;
        pInSAR->flag |= _TOPO_ ;
        if(pInSAR->srDEM.filePath != NULL) {
            aPath = initStringWithString(getDirectoryPathFromPath(pInSAR->srDEM.filePath)) ;
            free(pInSAR->srDEM.filePath) ;
        }
        else {
            aPath = initStringWithString(getDirectoryPathFromPath(pInSAR->interf.filePath)) ;
        }

        if (getPointerToFileExtensionInPath(pInSAR->dephi.filePath)) {
            (pInSAR->srDEM).filePath = initStringWith3Strings(aPath, "slantRangeDEM.", getPointerToFileExtensionInPath(pInSAR->dephi.filePath)) ;
        }
        else {
            (pInSAR->srDEM).filePath = initStringWith2Strings(aPath, "slantRangeDEM.") ;
        }
        
        free(aPath) ;
    }

    return(pInSAR->flag) ;
}


/* Re-add first phase component */
void addFirstPhaseComponentToUnWrappedPhase(InSARParametersStruct *pInSAR)
{
    size_t Da, Dr, i, j ;
    float *firstPhaseComponent, *unwrappedResidualPhase ;
    long seekVal1, seekVal2 ;

    if (openFirstPhaseComponentFile(pInSAR) && openUnwrappedPhaseFile(pInSAR)) {
        Da = ((pInSAR->interf).lena - (pInSAR->dephi).lena)/2 ;
        Dr = ((pInSAR->interf).lenr - (pInSAR->dephi).lenr)/2 ;
        firstPhaseComponent = vectorFloat(0, pInSAR->interf.lenr - 1) ;
        unwrappedResidualPhase = vectorFloat(0, pInSAR->dephi.lenr - 1) ;

        seekVal1 = (Da * pInSAR->firstPhaseComponentFile->xDim) * sizeof(float) ;
        seekVal2 = 0 ;
        for(i = 0; i < pInSAR->unwrappedPhaseFile->yDim; i++) {
            if(fseek(pInSAR->firstPhaseComponentFile->f, seekVal1, SEEK_SET))
                ase("Faild to seek into first phase component file") ;

            if((pInSAR->firstPhaseComponentFile->xDim != fread((float *)firstPhaseComponent, sizeof(float), pInSAR->firstPhaseComponentFile->xDim, pInSAR->firstPhaseComponentFile->f)))
                ase("Failed to read line into first phase component file") ;


            if(fseek(pInSAR->unwrappedPhaseFile->f, seekVal2, SEEK_SET))
                ase("Failed to seek into unwrapped phase file") ;

            if((pInSAR->unwrappedPhaseFile->xDim != fread((float *)unwrappedResidualPhase, sizeof(float), pInSAR->unwrappedPhaseFile->xDim, pInSAR->unwrappedPhaseFile->f)))
                ase("Failed to read line into unwrapped phase file") ;


            for (j = 0; j < pInSAR->unwrappedPhaseFile->xDim; j++) {
               if (!areFloatValsEquals(firstPhaseComponent[Dr + j], pInSAR->DEMExcludingValue)) {
                    unwrappedResidualPhase[j] += firstPhaseComponent[Dr + j] ;
                }
                else {
                    unwrappedResidualPhase[j] = pInSAR->DEMExcludingValue ;
                }
            }

            if(fseek(pInSAR->unwrappedPhaseFile->f, seekVal2, SEEK_SET))
                ase("Failed to seek into unwrapped phase file") ;

            if((pInSAR->unwrappedPhaseFile->xDim != fwrite (unwrappedResidualPhase, sizeof(float), pInSAR->unwrappedPhaseFile->xDim, pInSAR->unwrappedPhaseFile->f)))
                ase("Failed to write into unwrapped phase file") ;


            seekVal1 += pInSAR->firstPhaseComponentFile->xDim * sizeof(float) ;
            seekVal2 += pInSAR->unwrappedPhaseFile->xDim * sizeof(float) ;
        }
        freeVectorFloat(firstPhaseComponent, 0) ;
    }
}

/* ________________ Slant range DEM computation ________________ */

void phaseToMeasurementConversion(InSARParametersStruct *pInSAR)
{
    int		iY, iX, iX0, iY0 ;
    float *measurement ;
    double rangePosition, azimuthPosition, *P1, *P2 ;
    progressCounter *aCounter ;

    P1 = vectorDouble(0, 1) ;
    P2 = vectorDouble(0, 1) ;
    measurement = vectorFloat(0, (pInSAR->dephi).lenr) ;

    /* Lower left coordinate of the wrapped interferogram */
    iX0 = (pInSAR->sup).Sgra + (pInSAR->coh).spi / 2 + (pInSAR->coh).cor / 2 ; // + (pInSAR->red).Fra / 2 ;
    iY0 = (pInSAR->sup).Sbaz + (pInSAR->coh).spi / 2 + (pInSAR->coh).coa / 2 ; // + (pInSAR->red).Faz / 2 ;
    /* Lower left coordinate of the unwrapped interferogram */
    iX0 -= (pInSAR->interf.lenr - pInSAR->dephi.lenr) / 2 ;
    iY0 -= (pInSAR->interf.lena - pInSAR->dephi.lena) / 2 ;
    
    /* Measurement will have same dimensions than the unwrapped phase file */
    pInSAR->srDEM.lenr = pInSAR->dephi.lenr ;
    pInSAR->srDEM.lena = pInSAR->dephi.lena ;

    /* Open input and output files */
    if (fileExistsAtPath(pInSAR->srDEM.filePath)) {
        unlink(pInSAR->srDEM.filePath) ;
    }  
    openUnwrappedPhaseFile(pInSAR) ;
    openMeasurementFile(pInSAR) ;

    /* Initialize values at image center */
    updateOrbitalParametersForPoint((pInSAR->sup.Sdra - pInSAR->sup.Sgra)/2, (pInSAR->sup.Shaz - pInSAR->sup.Sbaz)/2, pInSAR) ;


    /* ------------------ Phase to height conversion ------------------ */

    aCounter = initProgressCounterWithMinMaxValue(0, (pInSAR->dephi).lena - 1) ;
    azimuthPosition = iY0 ;
    for(iY = 0; iY < (pInSAR->dephi).lena; iY++, azimuthPosition += (pInSAR->red).Faz) {
        if((pInSAR->unwrappedPhaseFile->xDim != fread(measurement, sizeof(float), pInSAR->unwrappedPhaseFile->xDim, pInSAR->unwrappedPhaseFile->f)))
            ase("Phase to measurement conversion: Failed to read line into unwrapped phase file") ;

        rangePosition = iX0 ;
        for(iX = 0 ; iX < (pInSAR->dephi).lenr; iX++, rangePosition += (pInSAR->red).Fra) {
            if (!areFloatValsEquals(measurement[iX], pInSAR->DEMExcludingValue)) {
                if (pInSAR->flag & _DEFO_) {
                    measurement[iX] /= -1. * pInSAR->kz0 ;
                }
                else {
                    measurement[iX] = phase2HeightConversionAtPoint(rangePosition, azimuthPosition, measurement[iX], pInSAR) ;
                }
            }
        }

        if((pInSAR->measurementFile->xDim != fwrite(measurement, sizeof(float), pInSAR->measurementFile->xDim, pInSAR->measurementFile->f)))
            ase("Phase to height conversion: Failed to write result into measurement file") ;
        updateProgressCounterForIndex(aCounter, iY) ;
    }
    freeProgressCounter(aCounter) ;
    freeVectorDouble(P1, 0) ;
    freeVectorDouble(P2, 0) ;
    freeVectorFloat(measurement, 0) ;
}


