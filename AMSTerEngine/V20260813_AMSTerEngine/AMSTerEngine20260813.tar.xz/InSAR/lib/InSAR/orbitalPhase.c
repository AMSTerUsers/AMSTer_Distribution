
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  orbitalPhase.c
 *  fineCoregistration
 *
 *  Created by Dominique Derauw on 9/11/11.
 *  Copyright 2011 Dominique Derauw. All rights reserved.
 *
 */

#include "orbitalPhase.h"

double orbitalPhaseAtPoint(double rangePosition, double azimuthPosition, InSARParametersStruct *pInSAR)
{
	double range, phiOrb ;
	
	updateOrbitalParametersForPoint(rangePosition, azimuthPosition, pInSAR) ;
	
	range = (pInSAR->ima1).z0 + rangePosition * (pInSAR->rad).rangeResolutionCell ;
	earthRadiusAtPoint(rangePosition, azimuthPosition, 0.0, pInSAR->geo) ;
    phiOrb = pInSAR->kz0 * (sqrt(pow(range, 2.) + pow(pInSAR->B.B, 2.) + 2. * range * pInSAR->B.B * sin(pInSAR->B.theta - pInSAR->geo->solving->alpha_at)) - range) ;
    
	return(phiOrb) ;
}

complexFloat complexOrbitalPhaseAtPoint(double rangePosition, double azimuthPosition, InSARParametersStruct *pInSAR)
{
	double orbitalPhase ;
	complexFloat complexPhase ;
	
	orbitalPhase = orbitalPhaseAtPoint(rangePosition, azimuthPosition, pInSAR) ;
	complexPhase.r = (float)cos(orbitalPhase) ;
	complexPhase.i = (float)sin(orbitalPhase) ;
	
	return(complexPhase) ;
}


/* We call geometrical phase, the phase that is dependent on geometrical parameters. It is to say it includes both the topographic and the orbital phase */

double geometricalPhaseAtPoint(double rangePosition, double azimuthPosition, double H, InSARParametersStruct *pInSAR)
{
	double range, geometricalPhase ;
	
	updateOrbitalParametersForPoint(rangePosition, azimuthPosition, pInSAR) ;
	
	range = (pInSAR->ima1).z0 + rangePosition * (pInSAR->rad).rangeResolutionCell ;
	earthRadiusAtPoint(rangePosition, azimuthPosition, H, pInSAR->geo) ;
    geometricalPhase = pInSAR->kz0 * (sqrt(pow(range, 2.) + pow(pInSAR->B.B, 2.) + 2. * range * pInSAR->B.B * sin(pInSAR->B.theta - pInSAR->geo->solving->alpha_at)) - range) ;
    
	return(geometricalPhase) ;
}

complexFloat complexGeometricalPhaseAtPoint(double rangePosition, double azimuthPosition, double H, InSARParametersStruct *pInSAR)
{
	double geometricalPhase ;
	complexFloat complexPhase ;
	
	geometricalPhase = geometricalPhaseAtPoint(rangePosition, azimuthPosition, H, pInSAR) ;
	complexPhase.r = (float)cos(geometricalPhase) ;
	complexPhase.i = (float)sin(geometricalPhase) ;
	
	return(complexPhase) ;
}

double topographicalPhaseAtPoint(double rangePosition, double azimuthPosition, double H, InSARParametersStruct *pInSAR)
{
	double topographicPhase, orbitalPhase, geometricalPhase ;
	
	updateOrbitalParametersForPoint(rangePosition, azimuthPosition, pInSAR) ;
	
    if (pInSAR->flag & FIRST_ORDER_TPOGRAPHIC_PHASE_APPROXIMATION) {
        topographicPhase = TWOPI / ambiguityAltitudeAtPoint(rangePosition, azimuthPosition, H, pInSAR) * H ;
    }
    else {
        geometricalPhase = geometricalPhaseAtPoint(rangePosition, azimuthPosition, H, pInSAR) ;
        orbitalPhase = orbitalPhaseAtPoint(rangePosition, azimuthPosition, pInSAR) ;
        
        topographicPhase = geometricalPhase - orbitalPhase ;
    }
    
	return(topographicPhase) ;
}

complexFloat complexTopographicalPhaseAtPoint(double rangePosition, double azimuthPosition, double H, InSARParametersStruct *pInSAR)
{
	double topographical ;
	complexFloat complexPhase ;
	
	topographical = topographicalPhaseAtPoint(rangePosition, azimuthPosition, H, pInSAR) ;
	complexPhase.r = (float)cos(topographical) ;
	complexPhase.i = (float)sin(topographical) ;
	
	return(complexPhase) ;
}

double ambiguityAltitudeAtPoint(double rangePosition, double azimuthPosition, double localAltitude, InSARParametersStruct *pInSAR)
{
	double range, ha ;
		
    updateOrbitalParametersForPoint(rangePosition, azimuthPosition, pInSAR) ;
	range = pInSAR->ima1.z0 + rangePosition * pInSAR->rad.rangeResolutionCell ;
	earthRadiusAtPoint(rangePosition, azimuthPosition, localAltitude, pInSAR->geo) ;
	ha = -TWOPI/pInSAR->kz0 * range/(pInSAR->B).B * sin(pInSAR->geo->solving->alpha)/cos((pInSAR->B).theta - pInSAR->geo->solving->alpha_at) ;
	
	return(ha) ;
}

void updateOrbitalParametersForPoint(double rangePosition, double azimuthPosition, InSARParametersStruct *pInSAR)
{
	coord2D *baseline ;
	complexFloat aComplex ;
	geoRefSolving *gRSolving ;
	

    gRSolving = pInSAR->geo->solving ;
    if ((rangePosition != gRSolving->rangePosition) || (azimuthPosition != gRSolving->S->azimuthPosition)) {
        if(azimuthPosition != gRSolving->S->azimuthPosition) {
            calcStateVect(gRSolving->S, azimuthPosition, pInSAR->geo->params->info) ;
            initOnSphereSolving(gRSolving) ;
            (pInSAR->S1).S = pInSAR->geo->solving->S->satDistance ;
        }
        
        if (gRSolving->rangePosition != rangePosition) {
            gRSolving->rangePosition = rangePosition ;
            
            baseline = allocPoint() ;
            baseline->x = rangePosition ;
            baseline->y = azimuthPosition ;
            planeAffineTransformOfCoord2D(baseline, NULL, pInSAR->B.T) ;
            (pInSAR->B).Bx = baseline->x ;
            (pInSAR->B).By = baseline->y ;
            aComplex.r = (float)baseline->x ;
            aComplex.i = (float)baseline->y ;
            (pInSAR->B).B = (double)modC(aComplex) ;
            (pInSAR->B).theta = (double)phiC(aComplex) ;
            
            free(baseline) ;
        }
    }
}

float phase2HeightConversionAtPoint(double rangePosition, double azimuthPosition, float phaseValue, InSARParametersStruct *pInSAR)
{
 	double z1, dz, RT, phiOrb, sign, gamma, h, h0 ;
    
    updateOrbitalParametersForPoint(rangePosition, azimuthPosition, pInSAR) ;
    z1 = (pInSAR->ima1).z0 + rangePosition * (pInSAR->rad).rangeResolutionCell ;
    
    /* Approximate computation: We compute the height considering the ambiguity altitude on flat ground */
    //			h = *ptr_dephi / TWOPI * ambiguityAltitudeAtPoint(P2[0], P2[1],0., pInSAR) ;
    
    /* "Exact" computation */
    RT = earthRadiusAtPoint(rangePosition, azimuthPosition, 0., pInSAR->geo) ;

    /* We re-add the removed orbital phase, whatever it is */
    phiOrb = orbitalPhaseAtPoint(rangePosition, azimuthPosition, pInSAR) ;
    phaseValue += phiOrb ;
    
    /* We compute the optical path difference */
    dz = phaseValue / pInSAR->kz0 ;
    
    /* We determine the sign of the angle gamma in triangle z1_B_z2 */
    sign = (fabs(pInSAR->B.theta - pInSAR->geo->solving->alpha_at) < HALFPI)? 1. : -1. ;
    /* And we compute the angle z1Bz2 */
    gamma = sign * (HALFPI + asin((1. + dz / (2 * z1)) * dz / pInSAR->B.B - pInSAR->B.B / (2 * z1))) ;
    
    /* Then we compute the local height from triangle S_z1_(RT+h) */
    h = sqrt(pow(pInSAR->S1.S, 2.) + pow(z1, 2.) - 2. * z1 * pInSAR->S1.S * sin(gamma - pInSAR->B.theta)) - RT ;
    do {
        h0 = h ;
        RT = earthRadiusAtPoint(rangePosition, azimuthPosition, h0, pInSAR->geo) ;
        h = sqrt(pow(pInSAR->S1.S, 2.) + pow(z1, 2.) - 2. * z1 * pInSAR->S1.S * sin(gamma - pInSAR->B.theta)) - RT ;
    } while (fabs(h - h0) > .1)  ;
    
    
    return (h) ;
}


