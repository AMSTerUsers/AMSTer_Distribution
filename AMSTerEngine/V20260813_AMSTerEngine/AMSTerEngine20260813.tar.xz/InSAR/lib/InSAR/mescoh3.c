
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* 345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678 */
/* Program mescoh.c                       */
/* Author : DERAUW D. , Centre Spatial de Liege              */

#include "biasedCoh.h"

/* main programm start */
void biasedCoherenceEstimation(InSARParametersStruct *pInSAR)
{
	/* local variables declaration */
    char unsigned *mask ;
    char *aPath, *initialFilterdInterferogramFilePath ;
	int		i, is, j, lenr, lena, cor, coa, squareSpiralSize, dX, dY ;
    int iX, iY ;
	int		Dresa, Dresr ;
	int		lenr2, lena2 ;
	long	Ldec, Ldec2 ;
	size_t lenrL, lenr2L ;
    float	*bCoh ;
    float   *bCoh_1, tempFloat ;
	float	**Mphi, **Mphic, **MA1, **MA2, *tMphic, *tMA1, *tMA2 ;
	float	*Mphi0, *Mphic0, *MA10, *MA20 ;
    float approximatedLocalPhase ;
	double	*tcos_Mphic, *tsin_Mphic, **cos_Mphic, **sin_Mphic, *scd1, *scd2, sn1, sld1, sld2 ;
	double	*cos_Mphic0, *sin_Mphic0 ;
	double	td1, td2 ;
	complexFloat	*scn, sln ;
	progressCounter *aCounter ;
    rawFileDescriptor *interferogramFile ;
    rawFileDescriptor *unwrappingMask ;
    tileTool *aTileTool ;

/*----------------------------------  INITIALISATION  -----------------------------------*/
    if (pInSAR->flag & _MEDIAN_FILTER_OF_COHERENCE_) {
        printf("Computing median filter of coherence in place of biased coherence...\n") ;
        printf("Spiral size set to 1...\n") ;
        pInSAR->cohder.spi = 1 ;
	}

    lena2 = (pInSAR->interf).lena ;
    lenr2 = (pInSAR->interf).lenr ;
    coa = (pInSAR->cohder).coa ;
    cor = (pInSAR->cohder).cor ;
    squareSpiralSize = (pInSAR->cohder).spi ;

    squareSpiralSize = 2 * (squareSpiralSize / 2) + 1 ;
    lenr = lenr2 - squareSpiralSize + 1 ;
    lena = lena2 - squareSpiralSize + 1 ;
	lenrL = (size_t)lenr ;
	lenr2L = (size_t)lenr2 ;
    (pInSAR->cohder).lena = Dresa = lena - coa + 1 ;
    (pInSAR->cohder).lenr = Dresr = lenr - cor + 1 ;

    if((pInSAR->biasedCoherenceFile = openRawFileForReadingAndWritingAtPath((pInSAR->cohder).filePath)) == NULL)
		ase("Failed to create biased coherence image file\n") ;

    if (pInSAR->flag & _MEDIAN_FILTER_OF_COHERENCE_) {
       	printf("Biased Coherence image size: %-d X %-d\n", Dresr, Dresa) ;
        printf("median filter window size: %-d X %-d\n", cor, coa) ;

        pInSAR->coherenceFile = openRawFileForReadingAtPath(pInSAR->coh.filePath) ;
        pInSAR->coherenceFile->xDim = pInSAR->coh.lenr ;
        pInSAR->coherenceFile->yDim = pInSAR->coh.lena ;

        aTileTool = allocTileToolForFilesOfType(pInSAR->coherenceFile, pInSAR->biasedCoherenceFile, "float") ;
        aTileTool->aoi = allocQuadrilateral() ;
        dX = pInSAR->cohder.cor / 2 ;
        dY = pInSAR->cohder.coa / 2 ;

        aTileTool->aoi->P[0].x = aTileTool->aoi->P[3].x = dX ;
        aTileTool->aoi->P[0].y = aTileTool->aoi->P[1].y = dY ;
        aTileTool->aoi->P[1].x = aTileTool->aoi->P[2].x = pInSAR->coherenceFile->xDim - dX - 1;
        aTileTool->aoi->P[2].y = aTileTool->aoi->P[3].y = pInSAR->coherenceFile->yDim - dY - 1 ;

        medianFilter(aTileTool, pInSAR->cohder.cor, pInSAR->cohder.coa) ;

        freeRawFileDescriptor(pInSAR->coherenceFile) ;
        pInSAR->coherenceFile = NULL ;

        return ;
    }

    if (!(pInSAR->flag & _WITHOUT_AMPLITUDE_)) {
		if((pInSAR->masterAmplitudeImageFile = openRawFileForReadingAtPath((pInSAR->mod1).filePath)) == NULL)
			ase("Failed to open master amplitude image file\n") ;
		if((pInSAR->slaveAmplitudeImageFile = openRawFileForReadingAtPath((pInSAR->mod2).filePath)) == NULL)
			ase("Failed to open slave amplitude image file\n") ;
	}
	else {
        pInSAR->masterAmplitudeImageFile = NULL ;
        pInSAR->slaveAmplitudeImageFile = NULL ;
	}

    /* Select requested interferogram */
    interferogramFile = selectInterferogram(pInSAR) ;

    /* Open filtered interferogram */
    /* If there is no filtered interferogram, the interferogram itself is used */
	if (pInSAR->flag & _DETPHUN_) {
		initialFilterdInterferogramFilePath = (pInSAR->filter).filePath ;
		(pInSAR->filter).filePath = interferogramFile->accessPath ;
	}
	if((pInSAR->filteredInterferogramFile = openRawFileForReadingAtPath((pInSAR->filter).filePath)) == NULL) {
		pInSAR->filteredInterferogramFile = interferogramFile ;
	}

	printf("Biased coherence estimation:\n") ;
	printf("****************************\n") ;
    if (pInSAR->flag & _WITHOUT_AMPLITUDE_) {
		printf("Master and slave amplitudes set to 1.\n");
	}
	else {
		printf("Master amplitude image: %s\n", pInSAR->masterAmplitudeImageFile->accessPath) ;
		printf("Slave amplitude image: %s\n", pInSAR->slaveAmplitudeImageFile->accessPath) ;
	}
	printf("Interférogramme: %s\n", interferogramFile->accessPath) ;
	printf("Filtered interférogram: %s\n", pInSAR->filteredInterferogramFile->accessPath) ;
	printf("Biased coherence image: %s\n", pInSAR->biasedCoherenceFile->accessPath) ;
	printf("Biased Coherence image size: %-d X %-d\n", Dresr, Dresa) ;
	printf("Estimator window size: %-d X %-d\n", cor, coa) ;

	/* ------------------------------- memory allocation --------------------------------------*/
	bCoh = vectorFloat(0, Dresr - 1) ;

	/* ------------------- Initialisation ------------------- */
	is = coa - 1 ;
	scn = vectorComplexFloat(0, lenr-1) ;
	scd1 = vectorDouble(0, lenr-1) ;
	scd2 = vectorDouble(0, lenr-1) ;
	Mphi = matrixFloat(0, coa + squareSpiralSize - 2, 0, lenr2 - 1) ;
	Mphi0 = Mphi[0] ;
	Mphic = matrixFloat(-1, is, 0, lenr-1) ;
	Mphic0 = Mphic[-1] ;
	MA1 = matrixFloat(-1, is, 0, lenr-1) ;
	MA10 = MA1[-1] ;
	MA2 = matrixFloat(-1, is, 0, lenr-1) ;
	MA20 = MA2[-1] ;
	cos_Mphic = matrixDouble(-1,  is, 0, lenr-1) ;
	cos_Mphic0 = cos_Mphic[-1] ;
	sin_Mphic = matrixDouble(-1,  is, 0, lenr-1) ;
	sin_Mphic0 = sin_Mphic[-1] ;

	for(i = 0; i < lenr; i++)
		scn[i].r = scn[i].i = scd1[i] = scd2[i] = Mphic[-1][i] = MA1[-1][i] = MA2[-1][i] = cos_Mphic[-1][i] = sin_Mphic[-1][i] = 0.0 ;
	for(i = 0; i < coa + squareSpiralSize - 2; i++) {
		Ldec = (long)i * lenr2 * sizeof(float) ;
		fseek(pInSAR->filteredInterferogramFile->f, Ldec, 0) ;
		fread((float *)Mphi[i], sizeof(float), lenr2, pInSAR->filteredInterferogramFile->f) ;
	}

	for(i = 0; i < is; i++) {
		Ldec = ((long)(i + squareSpiralSize / 2) * lenr2 + squareSpiralSize / 2)*sizeof(float) ;
        if (!(pInSAR->flag & _WITHOUT_AMPLITUDE_)) {
			fseek(pInSAR->masterAmplitudeImageFile->f, Ldec, 0) ;
			fread ((float *)MA1[i], sizeof(float), lenr, pInSAR->masterAmplitudeImageFile->f) ;
			fseek(pInSAR->slaveAmplitudeImageFile->f, Ldec, 0) ;
			fread ((float *)MA2[i], sizeof(float), lenr, pInSAR->slaveAmplitudeImageFile->f) ;
		}
		fseek(interferogramFile->f, Ldec, 0) ;
		fread ((float *)Mphic[i], sizeof(float), lenr, interferogramFile->f) ;

		for(j = 0; j < lenr; j++) {
            if (pInSAR->flag & _WITHOUT_AMPLITUDE_) {
				MA1[i][j] = 1.0 ;
				MA2[i][j] = 1.0 ;
			}
			else {
				MA1[i][j] *= MA1[i][j] ;
				MA2[i][j] *= MA2[i][j] ;
			}

            /* Normally, the following should be useless since no nan should be present in any of the used files except if some unexpected values are given in input in the used SLC images */
            iX = j + squareSpiralSize / 2 ;
            iY = is + squareSpiralSize / 2 ;
            approximatedLocalPhase = (squareSpiralSize > 1)? squareSpiralPhaseUnwrapping(Mphi, squareSpiralSize, iY, iX) : 0 ;
            approximatedLocalPhase = (isnan(approximatedLocalPhase))? 0 : approximatedLocalPhase ;

			Mphic[i][j] -= approximatedLocalPhase ;
			cos_Mphic[i][j] = cos(Mphic[i][j]) ;
			sin_Mphic[i][j] = sin(Mphic[i][j]) ;
			td2 = sqrt(MA1[i][j]*MA2[i][j]) ;
			scn[j].r += (td2 * cos_Mphic[i][j]) ;
			scn[j].i += (td2 * sin_Mphic[i][j]) ;
			scd1[j] += (double)MA1[i][j] ;
			scd2[j] += (double)MA2[i][j] ;
		}
	}

	/* ------------------- Calcul de la cohérence ------------------- */

	aCounter = initProgressCounterWithMinMaxValue(0, Dresa - 1) ;
	for(i = 0; i < Dresa; i++) {
		Ldec = ((long)(i + is + squareSpiralSize / 2) * lenr2L + squareSpiralSize / 2) * sizeof(float) ;
        if (!(pInSAR->flag & _WITHOUT_AMPLITUDE_)) {
			fseek(pInSAR->masterAmplitudeImageFile->f, Ldec, 0) ;
			fread ((float *)MA1[is], sizeof(float), lenrL, pInSAR->masterAmplitudeImageFile->f) ;
			fseek(pInSAR->slaveAmplitudeImageFile->f, Ldec, 0) ;
			fread ((float *)MA2[is], sizeof(float), lenrL, pInSAR->slaveAmplitudeImageFile->f) ;
		}

        if (fseek(interferogramFile->f, Ldec, 0)) {
            ase("Failed to fseek into interferogram file") ;
        }

        if (fread ((float *)Mphic[is], sizeof(float), lenrL, interferogramFile->f) != lenrL) {
            ase("Failed to read interferogram file") ;
        }

        Ldec = (long)(i + is + squareSpiralSize - 1) * lenr2L * sizeof(float) ;
        if (fseek(pInSAR->filteredInterferogramFile->f, Ldec, 0)) {
            ase("Failed to fseek into interferogram file") ;
        }

        if (fread ((float *)Mphi[is + squareSpiralSize - 1], sizeof(float), lenr2L, pInSAR->filteredInterferogramFile->f) != lenr2L) {
            ase("Failed to read interferogram file") ;
        }


		for(j = 0; j < lenr; j++) {
            if (pInSAR->flag & _WITHOUT_AMPLITUDE_) {
				MA1[is][j] = 1.0 ;
				MA2[is][j] = 1.0 ;
			}
			else {
				MA1[is][j] *= MA1[is][j] ;
				MA2[is][j] *= MA2[is][j] ;
			}

            /* Normally, the following should be useless since no nan should be present in any of the used files except if some unexpected values are given in input in the used SLC images */
            iX = j + squareSpiralSize / 2 ;
            iY = is + squareSpiralSize / 2 ;
            approximatedLocalPhase = (squareSpiralSize > 1)? squareSpiralPhaseUnwrapping(Mphi, squareSpiralSize, iY, iX) : 0 ;
            approximatedLocalPhase = (isnan(approximatedLocalPhase))? 0 : approximatedLocalPhase ;

            Mphic[is][j] -= approximatedLocalPhase ;
			cos_Mphic[is][j] = cos(Mphic[is][j]) ;
			sin_Mphic[is][j] = sin(Mphic[is][j]) ;
			td1 = sqrt(MA1[-1][j] * MA2[-1][j]) ;
			td2 = sqrt(MA1[is][j] * MA2[is][j]) ;
			scn[j].r += (td2 * cos_Mphic[is][j] - td1 * cos_Mphic[-1][j]) ;
			scn[j].i += (td2 * sin_Mphic[is][j] - td1 * sin_Mphic[-1][j]) ;
			scd1[j] += (double)MA1[is][j] - (double)MA1[-1][j] ;
			scd2[j] += (double)MA2[is][j] - (double)MA2[-1][j] ;
		}

		sln.r = sln.i = sld1 = sld2 = 0.0 ;
		for(j = 0; j < cor - 1; j++) {
			sln.r += scn[j].r ;
			sln.i += scn[j].i ;
			sld1 += scd1[j] ;
			sld2 += scd2[j] ;
		}
		for(j = 0; j < Dresr; j++) {
			sln.r += scn[j + cor - 1].r ;
			sln.i += scn[j + cor - 1].i ;
			sld1 += scd1[j + cor - 1] ;
			sld2 += scd2[j + cor - 1] ;
			sn1 = sld1*sld2 ;

			bCoh[j] = (sn1 > Chouillat)? (float)(sqrt((sln.r * sln.r + sln.i * sln.i)/sn1)) : 0 ;
            bCoh[j] = (bCoh[j] > 1.)? 1 : bCoh[j] ;

            sln.r -= scn[j].r ;
			sln.i -= scn[j].i ;
			sld1 -= scd1[j] ;
			sld2 -= scd2[j] ;
		}

		tMphic = Mphic[-1] ; tMA1 = MA1[-1] ; tMA2= MA2[-1] ;
		tcos_Mphic = cos_Mphic[-1] ;
		tsin_Mphic = sin_Mphic[-1] ;
		for(j = -1; j < is; j++) {
			Mphic[j] = Mphic[j + 1] ;
			cos_Mphic[j] = cos_Mphic[j + 1] ;
			sin_Mphic[j] = sin_Mphic[j + 1] ;
			MA1[j] = MA1[j + 1] ;
			MA2[j] = MA2[j + 1] ;
		}
		Mphic[ is] = tMphic ; MA1[ is] = tMA1 ; MA2[is] = tMA2 ;
		cos_Mphic[is] = tcos_Mphic ;
		sin_Mphic[is] = tsin_Mphic ;
		tMphic = Mphi[0] ;
		for(j = 0; j < coa + squareSpiralSize - 2; j++)
			Mphi[j] = Mphi[j+1] ;
		Mphi[coa + squareSpiralSize - 2] = tMphic ;

		fwrite(bCoh, sizeof(float), Dresr, pInSAR->biasedCoherenceFile->f) ;
		updateProgressCounterForIndex(aCounter, i) ;
	}
	printf("\n") ;

    if (pInSAR->flag & _GEN_PHASE_UNWRAPPING_MASK_) {
        rewind(pInSAR->biasedCoherenceFile->f) ;
        aPath = initStringWith2Strings(pInSAR->biasedCoherenceFile->directoryPath, "/unwrappingMask") ;
        unwrappingMask = openRawFileForWritingAtPath(aPath) ;
        mask = vectorUChar(0, Dresr - 2) ;
        bCoh_1 = vectorFloat(0, Dresr - 1) ;
        if((fread(bCoh_1, sizeof(float), Dresr, pInSAR->biasedCoherenceFile->f)) != (size_t)Dresr) {
        	ase("Failed to reread biased coherence file") ;
		}
        for (i = 1; i < Dresa; i++) {
            fread(bCoh, sizeof(float), Dresr, pInSAR->biasedCoherenceFile->f) ;
            for (j = 0; j < Dresr - 1; j++) {
                tempFloat = (bCoh_1[j] + bCoh_1[j + 1] + bCoh[j] + bCoh[j + 1]) / 4. ;
                mask[j] = (tempFloat > pInSAR->conex.seuilnet)? 255 : 0 ;
            }
            fwrite(mask, 1, Dresr - 1, unwrappingMask->f) ;
            tMA1 = bCoh_1 ;
            bCoh_1 = bCoh ;
            bCoh = tMA1 ;
        }
        freeRawFileDescriptor(unwrappingMask) ;
        freeVectorUChar(mask, 0) ;
        freeVectorFloat(bCoh_1, 0 ) ;
    }

	if (pInSAR->flag & _WITH_MASKING_) {
        rewind(pInSAR->biasedCoherenceFile->f) ;
        unwrappingMask = openRawFileForReadingAtPath(pInSAR->thresholdedSlantRangeMask) ;
        mask = vectorUChar(0, Dresr - 2) ;
		dX = cor / 2 + squareSpiralSize / 2 ;
		dY = coa / 2 + squareSpiralSize / 2 ;
		Ldec = (long)(dY * lenr2 + dX) ;
		Ldec2 = 0 ;
        for (i = 0; i < Dresa; i++, Ldec += lenr2, Ldec2 += Dresr * sizeof(float)) {
			if (fseek(pInSAR->biasedCoherenceFile->f, Ldec2, SEEK_SET) == -1) {
				ase("Failed to seek biased coherence file.") ;
			}
            fread(bCoh, sizeof(float), Dresr, pInSAR->biasedCoherenceFile->f) ;

			if (fseek(unwrappingMask->f, Ldec, SEEK_SET) == -1) {
				ase("Failed to seek mask file.") ;
			}
            fread(mask, 1, Dresr, unwrappingMask->f) ;

            for (j = 0; j < Dresr; j++) {
                bCoh[j] = (!mask[j])? bCoh[j] : 0 ;
            }

			if (fseek(pInSAR->biasedCoherenceFile->f, Ldec2, SEEK_SET) == -1) {
				ase("Failed to seek biased coherence file.") ;
			}
            fwrite(bCoh, sizeof(float), Dresr, pInSAR->biasedCoherenceFile->f) ;
        }
        freeRawFileDescriptor(unwrappingMask) ;
        freeVectorUChar(mask, 0) ;
        freeVectorFloat(bCoh, 0) ;	
	}
	

	if (pInSAR->flag & _DETPHUN_) {
		(pInSAR->filter).filePath = initialFilterdInterferogramFilePath ;
	}
	if (pInSAR->filteredInterferogramFile == interferogramFile) {
		pInSAR->filteredInterferogramFile = NULL ;
	}
	

	freeVectorComplexFloat(scn, 0) ;
	freeVectorDouble(scd1, 0) ;
	freeVectorDouble(scd2, 0) ;
	free(Mphi0) ;
	free(Mphi) ;
	free(Mphic0) ;
	free(--Mphic) ;
	free(MA10) ;
	free(--MA1) ;
	free(MA20) ;
	free(--MA2) ;
	free(cos_Mphic0) ;
	free(--cos_Mphic) ;
	free(sin_Mphic0) ;
	free(--sin_Mphic) ;

	return ;
}

