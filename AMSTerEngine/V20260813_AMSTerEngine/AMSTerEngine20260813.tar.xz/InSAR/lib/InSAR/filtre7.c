
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  filtre6.c
 *
 *  Created by Dominique Derauw a long long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
 */

/* Ce programme filtre un interférogramme en retournant à l'expression complexe de celui-ci
et en filtrant par une gaussienne partie réelle et imaginaire indépendement l'une de l'autre. Après filtrage, on re-génère un interférogramme.
Le calcul se fait par bloc et un fichier intermédiaire de taille double au résultat attendu est généré.
*/

#include "interferogramFilteringLib.h"


int interferogramFiltering(CSVStruct *csv_CL)
{
	char *aPath = NULL ;
	int	currentDirectoryFdesc, i ;
    int unsigned squareWindowSize ;
    double powerArg ;
    InSARParametersStruct	*pInSAR = NULL ;
    keyValue *parameters = NULL ;
	time_t startTime, endTime ;
	
	currentDirectoryFdesc = open(".", O_RDONLY) ;
	fchdir(currentDirectoryFdesc) ;
	
	if(isArgumentPresentInCSV(csv_CL, "help") || isFlagPresentInCSV(csv_CL, "h"))
		interferogramFilteringHelp() ;
    
    if (isArgumentPresentInCSV(csv_CL, "-create")) {
        createInteferogramFilteringParameterFileAtPath(csv_CL->stringVal[1]) ;
    }
	
	i = 1 ;
	while (i < csv_CL->numberOfEntries) {
		if((pInSAR = readInSARParametersFileAtPath(csv_CL->stringVal[i]))) {
            aPath = initStringWithString(csv_CL->stringVal[i]) ;
			break ;
		}
		i++ ;
	}
	if(!pInSAR) {
		aPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
		if(!fileExistsAtPath(aPath)){
			free(aPath) ;
			aPath = initStringWithString("./InSARParameters.txt") ;
            if(!fileExistsAtPath(aPath)) {
				interferogramFilteringHelp() ;
            }
		}
        pInSAR = readInSARParametersFileAtPath(aPath) ;
	}
    if (!pInSAR){
        printf("\t-/-> InSAR parameters file not found\n") ;
        ase("Stopping here\n\n") ;
    }
    
    time(&startTime) ;
    
    pInSAR->flag |= _BLAH_BLAH_ ;
    pInSAR->flag |= (isFlagPresentInCSV(csv_CL, "-i"))? INTERF_FIlTERING : pInSAR->flag ;
    
    pInSAR->flag |= _CLASSIC_FILTER_ ;
    if (isFlagPresentInCSV(csv_CL, "-c")) {
        pInSAR->flag |= _COMPLEX_FILTER_ ;
    }
    else { 
        if (pInSAR->filter.adaptativeFilterSmoothingFactor) {
            pInSAR->flag|= _ADAPTATIVE_FILTER_ ;
            if (isFlagPresentInCSV(csv_CL, "-d")) {
                pInSAR->flag |= _COMBINED_FILTERING_ ;
            }
            else {
                pInSAR->flag &= ~_CLASSIC_FILTER_ ;
            }
        }
    }
    
    
    
    /* Transfer parameters to structure */
    pInSAR->additionalParameters = allocAKeyValuePair() ;
    parameters = pInSAR->additionalParameters ;
    
    /* Select input and output files */
    if (fileExistsAtPath(pInSAR->residualPhase.filePath) && !(pInSAR->flag & INTERF_FIlTERING)) {
        setStringValForKeyIn(parameters, pInSAR->residualPhase.filePath, "Input file") ;
        free((pInSAR->filter).filePath) ;
        (pInSAR->filter).filePath = initStringWith2Strings(pInSAR->residualPhase.filePath, ".f") ;
    }
    else {
        setStringValForKeyIn(parameters, pInSAR->interf.filePath, "Input file") ;
        free((pInSAR->filter).filePath) ;
        (pInSAR->filter).filePath = initStringWith2Strings(pInSAR->interf.filePath, ".f") ;
    }
    
    setStringValForKeyIn(parameters, (pInSAR->filter).filePath, "Output file") ;
    setStringValForKeyIn(parameters, pInSAR->coh.filePath, "Coherence file") ;
    setIntValForKeyIn(parameters, (pInSAR->interf).lenr, "xDim") ;
    setIntValForKeyIn(parameters, (pInSAR->interf).lena, "yDim") ;
    setDoubleValForKeyIn(parameters, pInSAR->filter.sigmar, "Sigma X") ;
    setDoubleValForKeyIn(parameters, pInSAR->filter.sigmaz, "Sigma Y") ;
    setDoubleValForKeyIn(parameters, pInSAR->filter.adaptativeFilterSmoothingFactor, "Smoothing factor") ;
    setIntValForKeyIn(parameters, pInSAR->flag, "Flags") ;
    setDoubleValForKeyIn(parameters, 0, "Power argument") ;
    if ((i = isArgumentPresentInCSV(csv_CL, "-p="))) {
        sscanf(csv_CL->stringVal[i], "-p=%lf", &powerArg) ;
        printf("Coherence will be raised to power %lf\n", powerArg) ;
        setDoubleValForKeyIn(parameters, powerArg, "Power argument") ;
    }
    squareWindowSize = 0 ;
    if ((i = isArgumentPresentInCSV(csv_CL, "-w="))) {
        sscanf(csv_CL->stringVal[i], "-w=%d", &squareWindowSize) ;
    }
    setDoubleValForKeyIn(parameters, squareWindowSize, "squareWindowSize") ;

    /* Initializing multi thread */
    maxThreads = numberOfThreads() ;
//    maxThreads = 2 ;

    /* Filtering */
    interferogramFilteringCore(parameters) ;
    
    saveInSARParametersFileAtPath(pInSAR, aPath) ;
    freeInSARParametersStruct(pInSAR) ;
    free(aPath) ;


	time(&endTime) ;
	duration(startTime, endTime) ;
	return(0) ;
}


/* main programm start */
void interferogramFilteringCore(keyValue *parameters)
{
	/* local variables declaration */
    char *aPath ;
	int yDim, xDim ;
    int unsigned xInputIndex, yInputIndex, flag ;
    int unsigned xTileSize, yTileSize, xTileBorderSize, yTileBorderSize, xTileIndex, yTileIndex ;
    int unsigned iOMP ;
	float sigmaY, sigmaX, alpha = 0.0, smoothingFactor ;
    float **floatPhaseInput;
    double powerArg ;
    complexFloat **complexPhaseInput, **complexPhaseOutput ;
    complexFloat ***complexPhaseTile, ***smoothedPhaseTile ;
	rawFileDescriptor *inputFile = NULL, *outputFile = NULL, *coherenceFile, *outputCohFile = NULL ;
    tileTool *dataInputTileTool, *complexDataInputTileTool, *complexDataOutputTileTool ;
    tileTool *coherenceInputTileTool ;
    tileTool **filterTileTool = NULL, **baseFilterTileTool = NULL ;
    tileTool **complexPhaseTileTool, **smoothedSpectrumOfComplexPhase, **coherenceTileTool ;
    StructFFT *xFFT, *yFFT ;

/*----------------------------------  INITIALISATION  -----------------------------------*/

    /* Open input and output files */
    inputFile = openRawFileForReadingAtPath(getStringValForKeyIn(parameters, "Input")) ;
    outputFile = openRawFileForWritingAtPath(getStringValForKeyIn(parameters, "Output")) ;
    coherenceFile = openRawFileForReadingAtPath(getStringValForKeyIn(parameters, "Coherence")) ;
    xDim = getIntValForKeyIn(parameters, "xDim") ;
    yDim = getIntValForKeyIn(parameters, "yDim") ;
    setRawFileDimensions(inputFile, xDim, yDim) ;
    setRawFileDimensions(outputFile, xDim, yDim) ;
    setRawFileDimensions(coherenceFile, xDim, yDim) ;
    sigmaX = getFloatValForKeyIn(parameters, "Sigma X") ;
    sigmaY = getFloatValForKeyIn(parameters, "Sigma Y") ;
    smoothingFactor = getFloatValForKeyIn(parameters, "Smoothing") ;
    powerArg = getDoubleValForKeyIn(parameters, "Power argument") ;
    flag = (int unsigned)getIntValForKeyIn(parameters, "Flags") ;
    setRawFileDimensions(inputFile, xDim, yDim) ;
    setRawFileDimensions(outputFile, xDim, yDim) ;
    setRawFileDimensions(coherenceFile, xDim, yDim) ;

    
    /* Initialize tile tools parameters */
    if (flag & _ADAPTATIVE_FILTER_) {
        powerArg = (powerArg)? powerArg : smoothingFactor ;
        xTileSize = getIntValForKeyIn(parameters, "squareWindowSize") ;
        if (xTileSize) {
            xTileSize = yTileSize = ceil2ofIntVal(xTileSize) ;
            xTileBorderSize = yTileBorderSize = xTileSize / 2 - 1 ;
            printf("\t-->\tFiltering window size set to %d\n", xTileSize) ;
        }
        else {
            xTileSize = _XATILESIZE_ ;
            xTileBorderSize = _XATILEBORDERSIZE_ ;
            yTileSize = _YATILESIZE_ ;
            yTileBorderSize = _YATILEBORDERSIZE_ ;
        }
    }
    else {
        if(sigmaX * sigmaY == 0)
        return ;
        xTileSize = 64 ;
        xTileBorderSize = 16 ;
        yTileSize = 64 ;
        yTileBorderSize = 16 ;
    }
    
    if (flag & _COMPLEX_FILTER_) {
        aPath = initStringWith2Strings(getStringValForKeyIn(parameters, "Coherence"), ".f") ;
        outputCohFile = openRawFileForWritingAtPath(aPath) ;
        free(aPath) ;
    }

    /* Initialize input tile tool for sequential reading */
    dataInputTileTool = allocTileToolForFilesOfType(inputFile, outputFile, "float") ;
    floatPhaseInput = (float **)initTileToolWithSizes(dataInputTileTool, xDim, yDim, 0, 0) ;

    /* Initialize coherence tile tool for sequential reading */
    coherenceInputTileTool = allocTileToolForFilesOfType(coherenceFile, outputCohFile, "float") ;
    initTileToolWithSizes(coherenceInputTileTool, xDim, yDim, 0, 0) ;

    /* Initialize complex phase input tile tool */
    complexDataInputTileTool = allocTileToolForFilesOfType(inputFile, outputFile, "complexFloat") ;
    complexPhaseInput = (complexFloat **)initTileToolWithSizes(complexDataInputTileTool, xDim, yDim, 0, 0) ;

    /* Initialize complex phase output tile tool */
    complexDataOutputTileTool = allocTileToolForFilesOfType(inputFile, outputFile, "complexFloat") ;
    complexPhaseOutput = (complexFloat **)initTileToolWithSizes(complexDataOutputTileTool, xDim, yDim, 0, 0) ;

    /* Initialize complex phase subwindow tile tool */
    complexPhaseTileTool = malloc(maxThreads * sizeof(complexPhaseTileTool[0])) ;
    complexPhaseTile = malloc(maxThreads * sizeof(complexPhaseTile[0])) ;
    for (iOMP = 0; iOMP < maxThreads; iOMP++) {
        complexPhaseTileTool[iOMP] = allocTileToolForDataOfType((void **)complexPhaseInput, (void **)complexPhaseOutput, xDim, yDim, "complexFloat") ;
        complexPhaseTile[iOMP] = (complexFloat **)initTileToolWithSizes(complexPhaseTileTool[iOMP], xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    }
    

    /* Initialize smoothed complex phase subwindow tile tool */
    smoothedSpectrumOfComplexPhase = malloc(maxThreads * sizeof(smoothedSpectrumOfComplexPhase[0])) ;
    smoothedPhaseTile = malloc(maxThreads * sizeof(smoothedPhaseTile[0])) ;
    for (iOMP = 0; iOMP < maxThreads; iOMP++) {
        smoothedSpectrumOfComplexPhase[iOMP] = allocTileToolForDataOfType((void **)complexPhaseInput, NULL, xDim, yDim, "complexFloat") ;
        smoothedPhaseTile[iOMP] = (complexFloat **)initTileToolWithSizes(smoothedSpectrumOfComplexPhase[iOMP], xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    }

    /* Initialize coherence subwindow tile tool */
    coherenceTileTool = malloc(maxThreads * sizeof(coherenceTileTool[0])) ;
    for (iOMP = 0; iOMP < maxThreads; iOMP++) {
        coherenceTileTool[iOMP] = allocTileToolForDataOfType(coherenceInputTileTool->tile, NULL, xDim, yDim, "float") ;
        initTileToolWithSizes(coherenceTileTool[iOMP], xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    }

    /* Initialize base filter tile tool */
    if (flag & _CLASSIC_FILTER_) {
        baseFilterTileTool = malloc(maxThreads * sizeof(baseFilterTileTool[0])) ;
        for (iOMP = 0; iOMP < maxThreads; iOMP++) {
            baseFilterTileTool[iOMP] = allocTileToolForFilesOfType(inputFile, outputFile, "float") ;
            initTileToolWithSizes(baseFilterTileTool[iOMP], xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
            initFilterTileTool(baseFilterTileTool[iOMP], sigmaX, sigmaY) ;
        }
    }

    /* Initialize smoothing filter for averaging power spectrum */
    if (flag & _ADAPTATIVE_FILTER_) {
        filterTileTool = malloc(maxThreads * sizeof(filterTileTool[0])) ;
        for (iOMP = 0; iOMP < maxThreads; iOMP++) {
            filterTileTool[iOMP] = allocTileToolForFilesOfType(inputFile, outputFile, "float") ;
            initTileToolWithSizes(filterTileTool[iOMP], xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
            initFilterTileTool(filterTileTool[iOMP], smoothingFactor, smoothingFactor) ;
        }
    }

    /* Initialize FFT's */
    xFFT = initFFT(xTileSize, yTileSize, ALONGX) ;
    yFFT = initFFT(xTileSize, yTileSize, ALONGY) ;

    /* Blahblah... */
    if ((flag & _BLAH_BLAH_)) {
        if (flag & _ADAPTATIVE_FILTER_) {
            printf("\nAdaptative interferogram filtering :\n") ;
            printf("****************************************\n\n") ;
            printf("Input interferogram : %s\n", inputFile->accessPath) ;
            printf("Output interferogram : %s\n", outputFile->accessPath) ;
            printf("Power spectrum smoothing factor =  %f\n", smoothingFactor ) ;
            if (flag & _CLASSIC_FILTER_) {
                printf("Adaptative filter will be applied to classically filtered interferogram\n") ;
                printf("Non-adaptative interferogram filtering characteristics\n") ;
                printf("Range filter Full Width at Half Maximum = %f\n", sigmaX) ;
                printf("Azimuth filter Full Width at Half Maximum = %f\n", sigmaY) ;
            }
        }
        else {
            printf("\nNon-adaptative interferogram filtering\n") ;
            printf("**************************************\n") ;
            printf("Range filter Full Width at Half Maximum = %f\n", sigmaX) ;
            printf("Azimuth filter Full Width at Half Maximum = %f\n", sigmaY) ;
        }
    }

    /* Start filtering tile by tile */
    for(yInputIndex = 0; yInputIndex < dataInputTileTool->yTileNumber; yInputIndex++) {
        for(xInputIndex = 0; xInputIndex < dataInputTileTool->xTileNumber; xInputIndex++) {
            /* Sequential reading of input phase */
            readTileAtIndexes(dataInputTileTool, xInputIndex, yInputIndex) ;
            /* Conversion of input phase into complex */
            convertFloatPhaseTileToComplex(dataInputTileTool, complexDataInputTileTool) ;
            /* Sequential reading of coherence */
            readTileAtIndexes(coherenceInputTileTool, xInputIndex, yInputIndex) ;           

#pragma omp parallel num_threads(maxThreads)
#pragma omp for schedule(auto) private(alpha, iOMP) collapse (2)
            for (yTileIndex = 0; yTileIndex < complexPhaseTileTool[0]->yTileNumber; yTileIndex ++) {
                for (xTileIndex = 0; xTileIndex < complexPhaseTileTool[0]->xTileNumber; xTileIndex++) {
                    alpha = 0 ;
#ifdef _USE_OPENMP_
                    iOMP = omp_get_thread_num() ;
#else
                    iOMP = 0 ;
#endif

                    /* Read required data */
                    copyTileAtIndexes(complexPhaseTileTool[iOMP], xTileIndex, yTileIndex) ;
                    copyTileAtIndexes(smoothedSpectrumOfComplexPhase[iOMP], xTileIndex, yTileIndex) ;
                    copyTileAtIndexes(coherenceTileTool[iOMP], xTileIndex, yTileIndex) ;

                    if (flag & _COMPLEX_FILTER_) {
                        multiplyTileTools(complexPhaseTileTool[iOMP], coherenceTileTool[iOMP], NULL) ;
                    }

                    fftX(FORWARD_FFT, complexPhaseTile[iOMP][0], xFFT) ;
                    fftY(FORWARD_FFT, complexPhaseTile[iOMP][0], yFFT) ;

                    if (flag & _CLASSIC_FILTER_) {
                        tileFiltering(complexPhaseTileTool[iOMP], baseFilterTileTool[iOMP]) ;
                    }

                    /* Generating smoothed spectrum of complex phase tile */
                    if (flag & _ADAPTATIVE_FILTER_) {
                        /* Compute Goldstein alpha factor */
                        alpha = 1. - pow(localAverageOfFloatTile(coherenceTileTool[iOMP]), powerArg) ;
                        if (alpha > Chouillat) {
                            tileFiltering(smoothedSpectrumOfComplexPhase[iOMP], filterTileTool[iOMP]) ;
                            fftX(FORWARD_FFT, smoothedSpectrumOfComplexPhase[iOMP]->tile[0], xFFT) ;
                            fftY(FORWARD_FFT, smoothedSpectrumOfComplexPhase[iOMP]->tile[0], yFFT) ;
                        }    
                        else {
                            alpha = 0 ;
                        }    
                    }    

                    if (alpha) {
                        adaptativeFilteringOfTile(complexPhaseTileTool[iOMP], smoothedSpectrumOfComplexPhase[iOMP], alpha) ;
                    }    
                    
                    fftX(INVERSE_FFT, complexPhaseTile[iOMP][0], xFFT) ;
                    fftY(INVERSE_FFT, complexPhaseTile[iOMP][0], yFFT) ;
                    
                    saveTile(complexPhaseTileTool[iOMP]) ;
                }
            }

            convertComplexPhaseTileToFloat(dataInputTileTool, complexDataOutputTileTool) ;
            writeTile(dataInputTileTool) ;

            if (flag & _COMPLEX_FILTER_) {
                getAmplitudeOfComplexTileTools(complexDataOutputTileTool, coherenceInputTileTool) ;
                writeTile(coherenceInputTileTool) ;
            }

        }
    }

    freeTileTool(dataInputTileTool) ;
    freeTileTool(coherenceInputTileTool) ;
    freeTileTool(complexDataInputTileTool) ;
    freeTileTool(complexDataOutputTileTool) ;
    for( iOMP = 0; iOMP < maxThreads; iOMP++) {
        freeTileTool(complexPhaseTileTool[iOMP]) ;
        freeTileTool(smoothedSpectrumOfComplexPhase[iOMP]) ;
        freeTileTool(coherenceTileTool[iOMP]) ;
        if (flag & _CLASSIC_FILTER_) {
            freeTileTool(baseFilterTileTool[iOMP]) ;
        }
        if (flag & _ADAPTATIVE_FILTER_) {
            freeTileTool(filterTileTool[iOMP]) ;
        }
    }
    free(complexPhaseTileTool) ;
    free(complexPhaseTile) ;
    free(smoothedSpectrumOfComplexPhase) ;
    free(smoothedPhaseTile) ;
    free(coherenceTileTool) ;
    if (flag & _CLASSIC_FILTER_) {
        free(baseFilterTileTool) ;
    }
    if (flag & _ADAPTATIVE_FILTER_) {
        free(filterTileTool) ;
    }
    freeFFT(xFFT) ;
    freeFFT(yFFT) ;

    freeRawFileDescriptor(inputFile) ;
    freeRawFileDescriptor(outputFile) ;
    freeRawFileDescriptor(coherenceFile) ;
}





void interferogramFilteringHelp(void)
{
	printf("\nUsage:\ninterferogramFiltering [/pathTo/InSARParameters.txt] [-i] [-d] [-c] \n") ;
	printf("The interferogramFiltering routine will perform the filtering of the\n already computed interferogram\n") ;
    printf("\nIf a residual interferogram is present, it is this latter one that will be filtered.\n") ;
    printf("In which case, name of the filtered interferogram will be addapted, \nappending \".f\" to the name of the residual interferogram ") ;
    printf("By default, a Goldstein-like adaptative filtering is performed\n") ;
    printf("If the power spectrum filtering factor is set to 0 in the parameter file, classical filtering is performed\n") ;
    printf("-d : Combined filtering. The interferogram will be filtered classically before adaptative filtering (take care...)\n") ;
    printf("-i : To force filtering of the interferogram, use the -i option\n") ;
    printf("-c : Adaptative filtering is deactivated and classic filtering is applied to both coherence and interferogram.\n") ;
	printf("\nIf used with no parameters, the routine will look for an \"InSARparameters.txt\".\n") ;
	printf("file within the working directory or within the ./TextFiles subdirectory.\n") ;
	printf("Any other path to a text file containing InSAR parameters can be given as\nfirst parameter.\n\n") ;
	exit(0) ;
}

void createInteferogramFilteringParameterFileAtPath(char* aPath)
{
    keyValue *parameters ;
    
    if (isWriteAccessGrantedAtPath(aPath)) {
        parameters = allocAKeyValuePair() ;
        setStringValForKeyIn(parameters, "Interferogram filtering parameters", "") ;
        setStringValForKeyIn(parameters, "**********************************", "") ;
        setStringValForKeyIn(parameters, "/pathToInterferogramFile", "Input file") ;
        setStringValForKeyIn(parameters, "/pathToFilteredInterferogramFile", "Output file") ;
        setStringValForKeyIn(parameters, "/pathToCoherenceFile", "Coherence file") ;
        setIntValForKeyIn(parameters, 1234, "xDim") ;
        setIntValForKeyIn(parameters, 1234, "yDim") ;
        setDoubleValForKeyIn(parameters, 1.0, "Sigma X") ;
        setDoubleValForKeyIn(parameters, 1.0, "Sigma Y") ;
        setDoubleValForKeyIn(parameters, 1.0, "Smoothing factor") ;

        writeParameterFileAtPath(parameters, aPath) ;
    }
    exit(0) ;
}
