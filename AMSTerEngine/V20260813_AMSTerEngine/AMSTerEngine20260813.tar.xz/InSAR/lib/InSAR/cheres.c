
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678*/
/* Program cheres2.c ( files version )                       */
/* Author : DERAUW D. , Centre Spatial de Liege              */

/*Recherche des résidus contenus dans l'interférogramme.*/

#include "pourtous.h"
#include "paramInSAR.h"
#include "counters.h"
#include "phaseUnwrappingLib.h"

/* main programm start */
void	residuesSearch(InSARParametersStruct *pInSAR)
{
	/* local variables declaration */
	unsigned char	*residue ;
	unsigned char	resplus, resmoin, rien ;
	int		i, j, lena, lenr, borda, bordr, Dimr, coa, cor, Ncote, Nr ;
	long	Ldec ;
	float	**interfero ;
	double	dphi ;
	rawFileDescriptor *interferogramFile, *residuesFile ;
	progressCounter *aCounter ;

/*----------------------------------  INITIALISATION  -----------------------------------*/
    /* Open requested interferogram */
    interferogramFile = selectInterferogram(pInSAR) ;

    /* Create residues file */
 	residuesFile = openRawFileForWritingAtPath((pInSAR->res).filePath) ;

	lena = (pInSAR->interf).lena ;
	lenr = (pInSAR->interf).lenr ;
	coa = (pInSAR->cohder).coa ;
	cor = (pInSAR->cohder).cor ;
	Ncote = (pInSAR->cohder).spi ;

	Dimr = lenr ;
	lena = lena - coa - Ncote + 2 ;
	lenr = lenr - cor - Ncote + 2 ;
	borda = coa/2 + Ncote/2 ;
	bordr = cor/2 + Ncote/2 ;

	(pInSAR->res).lena = lena - 1 ;
	(pInSAR->res).lenr = lenr - 1 ;

	printf("Residues search\n") ;
	printf("**************\n") ;
	printf("Interferometric phase: %s\n", interferogramFile->accessPath) ;
	printf("Residue image file : %s\n", residuesFile->accessPath) ;
	printf("Result file dimensions: %d X %d\n", (pInSAR->res).lenr, (pInSAR->res).lena) ;

	/* ------------------------------- memory allocation --------------------------------------*/
	interfero = matrixFloat(0, 1, 0, lenr - 1) ;
	residue = vectorUChar(0, (pInSAR->res).lenr - 1) ;

	/* ------------------- Recherche de residus ------------------- */

	rien = (unsigned char)1 ;
	resplus = (unsigned char)2 ;
	resmoin = (unsigned char)0 ;
	Nr = 0 ;
	aCounter = initProgressCounterWithMinMaxValue(0, (pInSAR->res).lena - 1) ;
	for(i = 0; i < (pInSAR->res).lena; i++) {
		Ldec = (long)((borda + i) * Dimr + bordr) * sizeof(float) ;
		fseek(interferogramFile->f, Ldec, 0) ;
		fread (interfero[0], sizeof(float), lenr, interferogramFile->f) ;
		Ldec = (long)((borda + i + 1)*Dimr + bordr) * sizeof(float) ;
		fseek(interferogramFile->f, Ldec, 0) ;
		fread (interfero[1], sizeof(float), lenr, interferogramFile->f) ;
		for(j = 0; j < lenr - 1; j++) {
			dphi = unwrappedPhaseGap(interfero[0][j + 1], interfero[0][j])
			     + unwrappedPhaseGap(interfero[1][j + 1], interfero[0][j + 1])
			     + unwrappedPhaseGap(interfero[1][j], interfero[1][j + 1])
			     + unwrappedPhaseGap(interfero[0][j], interfero[1][j]) ;
			if(!dphi) residue[j] = rien ;
			else {
				Nr++ ;
				if(dphi > 0.)
					residue[j] = resplus ;
				else
					residue[j] = resmoin ;
			}
		}
		fwrite(residue, 1, (pInSAR->res).lenr, residuesFile->f) ;
		updateProgressCounterForIndex(aCounter, i) ;
	}
	printf("Nombre of found residues: %d\n",Nr) ;

//    freeSelectedInterferogram(pInSAR) ;

	freeRawFileDescriptor(residuesFile) ;
	freeMatrixFloat(interfero, 0, 0) ;
	freeVectorUChar(residue, 0) ;
}

