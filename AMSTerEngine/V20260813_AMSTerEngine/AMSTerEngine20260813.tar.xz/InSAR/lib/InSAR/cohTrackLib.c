
/*
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/*
 *  cohTrackLib.c
 *  Coherence Tracking Products Generation
 *
 *  Created by Dominique Derauw on 29/07/2025.
 *  Copyright 2029 Dominique Derauw SAREOS. All rights reserved.
 *
 */

#include "cohTrackLib.h"

int cohTrackMain(CSVStruct *csv)
{
    InSARParametersStruct *pInSAR = NULL;
    time_t startTime, endTime;
    cohTrackStruct *pCohTrack;

    if (isFlagPresentInCSV(csv, "h")) {
        cohTrackHelp() ;
    }

    time(&startTime) ;

    printf("\n\t---> Coherence tracking process started...\n") ;

    setNumberOfAllowedOpenendFilesToMax() ;

    /* Get coherence tracking parameters */
    pCohTrack = getCohTrackParameters(csv) ;
    pInSAR = pCohTrack->pInSAR;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "A")) ? _ALL_POLARIZATIONS_ : pInSAR->flag ;

    /* Generate cohTrack directories */
    printf("\n\t---> Initiating sequential InSAR processing.\n");
    initCohTrackDirs(pCohTrack);

    if (!(pCohTrack->flag & __COHTRACK_ONLY__)) {
        /* First deal with reference registration */
        cohTrackReferenceRegistration(pCohTrack);

        /* If dealing with Sentinel1, reference coregistration of slave image must be copied at destination */
        if (pInSAR->masterInfo->sensorID == __SENTINEL1__) {
            copyRefCorToCohTrackDirs(pCohTrack);
        }
    }

    /* Initialize shift transforms */
    printf("\n\t---> Initializing shift transforms\n");
    initShiftTransforms(pCohTrack);

    if (!(pCohTrack->flag & __COHTRACK_ONLY__) || (pCohTrack->flag & __FORCE_INSAR__)) {
        /* Sequential interpolation applying requested shifts */
        cohTrackShiftInterpolation(pCohTrack);

        /* Perform sequential InSAR processing */
        cohTrackSequentialInSARProcessing(pCohTrack);
    }

    initCohTrackTileTools(pCohTrack);
    initOutputFiles(pCohTrack) ;

    /* Saving tracked coherence as stacks if requested */
    if (isFlagPresentInCSV(pCohTrack->csv, "s")) {
        saveCohTrackStacks(pCohTrack);
    }

    /* Perform cohTrack stack processing */
    printf("\n\t---> Coherence stack analysis\n");
    cohTrackStackProcessing(pCohTrack);

    freeCohTrackParams(pCohTrack);

    time(&endTime);
    duration(startTime, endTime);

    return (0);
}

/* Registration/interpolation of reference slave image */
/* In case of S1, burst reramping is not performed */
void cohTrackReferenceRegistration(cohTrackStruct *pCohTrack)
{
    char *aPath;
    CSVStruct *csv;
    InSARParametersStruct *pInSAR = NULL;

    pInSAR = pCohTrack->pInSAR;
    /* In case dealing with Sentine1, slave and master specific info must be recreated */
    if (pInSAR->masterInfo->sensorID == __SENTINEL1__) {
        /* Re-create S1Specific info for master and slave images */
        freeInfoImage(pInSAR->masterInfo);
        pInSAR->masterInfo = mergeFrameInfo(pInSAR->masterImage, pCohTrack->selectedPol);
        freeInfoImage(pInSAR->slaveInfo);
        pInSAR->slaveInfo = mergeFrameInfo(pInSAR->slaveImage, pCohTrack->selectedPol);
        initInSAR_GEO(pInSAR, _KEEPAOI_);
    }    

    if (!(pInSAR->flag & __INTERPOL_DONE__)) {
        printf("\n\t---> Performing reference interpolation.\n");
        if (pInSAR->masterInfo->sensorID != __SENTINEL1__) {
            /* If not dealing with Sentinel data, perform a main classical interpolation applying computed biinear transform */
            aPath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/InSARParameters.txt");
            csv = addStringValInCSVStruct(aPath, NULL);
            interpolation(csv);
            freeCSVStruct(csv);
            free(aPath);
        }    
        else {
            /* Start main Sentinel1 coregistration and interpolation without reramping */
            /* If dealing with SENTINEL1 images, initialize sensor specific info */
            /* Select polarization if requested */
            if (!(pInSAR->flag & _ALL_POLARIZATIONS_)) {
                sprintf(pInSAR->masterInfo->polMode, "%s", pInSAR->masterPolarizationChannel);
                sprintf(pInSAR->slaveInfo->polMode, "%s", pInSAR->slavePolarizationChannel);
                pInSAR->masterInfo->numberOfLayers = pInSAR->slaveInfo->numberOfLayers = 1;
                pCohTrack->selectedPol = initStringWithString(pInSAR->masterPolarizationChannel);
            }    

            /* Determine common burst selection and copy new instance of master if burst selection differs from initial one */
            if (InSARBurstSelection(pInSAR)) {
                copyMasterImageToDestination(pInSAR);
                pInSAR->flag |= _S1_MASTER_IMAGE_COPIED_;
            }

            /* Copy slave image to its destination */
            /* *********************************** */
            copySlaveImageToDestination(pInSAR);

            /* Initialize S1 coregistration */
            /* **************************** */
            printf("\t--> Init per-burst transforms\n");
            initPerBurstTransforms(pInSAR);

            /* Slave image per burst interpolation */
            burstsDeramping(pInSAR->interpolatedSlaveInfo, NULL);
            burstsInterpolation(pInSAR);
        }
    }
}


/* If dealing with Sentinel1, reference coregistration of slave image must be copied at destination */
void copyRefCorToCohTrackDirs(cohTrackStruct *pCohTrack)
{
    char *aPath, testVal;
    int iX, iY;
    InSARParametersStruct *pInSAR = NULL, ***ppInSAR;

    /* copy reference coregistration within cohTrack directories */
    pInSAR = pCohTrack->pInSAR;
    ppInSAR = pCohTrack->ppInSAR;
    testVal = 1;
    for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
        for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
            if (ppInSAR[iY][iX] && !(ppInSAR[iY][iX]->flag & __INTERPOL_DONE__)) {
                /* Copy reference registration in cohTrack working sub directories */
                if (iX || iY) {
                    if (testVal) {
                        printf("\n\t---> Copying reference coregistration into working directories for sequential processing.\n");
                        testVal = 0;
                    }

                    printf("\t---> Copying into %s\n", ppInSAR[iY][iX]->whereAmI) ;
                    copyDirAtPathToPath(pInSAR->interpolatedSlave->imageDirectoryPath, ppInSAR[iY][iX]->interpolatedSlave->imageDirectoryPath);
                    if (pInSAR->flag & _S1_MASTER_IMAGE_COPIED_) {
                        /* If master image was copied into InSAR processing directory of reference registration processing due to common burst selection in slave and master images, */
                        /* copied master should serve as the master image for all registration shifts. So we linked it in each processing directory  */
                        aPath = initStringWith3Strings(ppInSAR[iY][iX]->whereAmI, "InSARProducts/", getPointerToFileNameInPath(pInSAR->masterImage->imageDirectoryPath)) ;
                        symlink(pInSAR->masterImage->imageDirectoryPath, aPath) ;
                        /* We then free refernces to former master */
                        freeCSLImageStructure(ppInSAR[iY][iX]->masterImage) ;
                        freeS1Specific(ppInSAR[iY][iX]->masterInfo->sensorSpecificInfo, _S1_TRASH_BURSTS_) ;
                        freeInfoImage(ppInSAR[iY][iX]->masterInfo) ;
                        /* And reinitialize the newly copied master image */
                        ppInSAR[iY][iX]->masterImage = getCSLImageStructureAtPath(aPath) ;
//                        ppInSAR[iY][iX]->masterInfo = mergeFrameInfo(ppInSAR[iY][iX]->masterImage, pCohTrack->selectedPol);
                        ppInSAR[iY][iX]->masterInfo = pInSAR->masterInfo ;
                        free(aPath);
                    }
                }
            }
        }
    }
}

void cohTrackShiftInterpolation(cohTrackStruct *pCohTrack)
{
    char *aPath;
    int iX, iY;
    CSVStruct *csv;
    InSARParametersStruct *pInSAR = NULL, ***ppInSAR;
    polygon *aoi ;

    pInSAR = pCohTrack->pInSAR;
    ppInSAR = pCohTrack->ppInSAR;

    /* Interpol applying requested shifts */
    if (!(pCohTrack->flag & __INTERPOL_ALL_DONE__)) {
        printf("\t---> Performing iterative interpolation shifts of slave image:\n");
        for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
            for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
                if (ppInSAR[iY][iX] && !(ppInSAR[iY][iX]->flag & __INTERPOL_DONE__)) {
                    printf("\n\t\t---> Working directory: %s\n", ppInSAR[iY][iX]->whereAmI);
                    aPath = initStringWith2Strings(ppInSAR[iY][iX]->whereAmI, "/TextFiles/InSARParameters.txt");
                    csv = addStringValInCSVStruct("interpolation", NULL);
                    csv = addStringValInCSVStruct(aPath, csv);
                    if (pInSAR->masterInfo->sensorID != __SENTINEL1__) {
                        /* If not dealing with Sentinel data, perform a classical interpolation applying requested additional shifts */
                        interpolation(csv);
                    }
                    else {
                        /* Continue with Sentinel 1 coregistration processing */
                        if (iX || iY) {
                            /* Re-create S1Specific info for master and slave images */
                            freeInfoImage(ppInSAR[iY][iX]->masterInfo);
                            ppInSAR[iY][iX]->masterInfo = mergeFrameInfo(ppInSAR[iY][iX]->masterImage, pCohTrack->selectedPol);
                            freeInfoImage(ppInSAR[iY][iX]->slaveInfo);
                            ppInSAR[iY][iX]->slaveInfo = mergeFrameInfo(ppInSAR[iY][iX]->slaveImage, pCohTrack->selectedPol);
                            initInSAR_GEO(ppInSAR[iY][iX], _KEEPAOI_);
                            initPerBurstShiftTransforms(ppInSAR[iY][iX]);
                            if (!(ppInSAR[iY][iX]->flag & __INTERPOL_DONE__)) {
                                printf("\t\t---> Shifting slave bursts\n");
                                burstsInterpolation(ppInSAR[iY][iX]);
                            }
                        }

                        /* Reramping must be done taking into account full reference transform */
                        /* Azimuth shift if any must be reset to zero to avoit introducing a phase ramp due to azimuth misregistration */
                        ppInSAR[iY][iX]->yShift = 0;
                        initPerBurstTransforms(ppInSAR[iY][iX]);

                        burstsReramping(ppInSAR[iY][iX]->interpolatedSlaveInfo, ppInSAR[iY][iX]->masterInfo);
                        alignSlaveImage(ppInSAR[iY][iX]);

                        /* Images stitching */
                        /* Proceed with slave image stitching */
                        printf("\t\t--->Assembling slave bursts in slave image...\n");
                        concatenateBurstsIntoWideSwathImage(ppInSAR[iY][iX]->interpolatedSlave, ppInSAR[iY][iX]->interpolatedSlaveInfo, _S1_KEEP_BURSTS_);
                        if (!isArgumentPresentInCSV(pCohTrack->csv, "-keepBursts")) {
                            trashSelectedBursts(ppInSAR[iY][iX]->interpolatedSlaveInfo);
                        }

                        /* Proceed with image stitching provided master image is not present due to previous processing on other area */
                        if (!isSLCDataFilePresentInCSLImage(ppInSAR[iY][iX]->masterImage, ppInSAR[iY][iX]->masterInfo)) {
                            printf("\t\t---> Assembling master bursts in master image...\n");
                            concatenateBurstsIntoWideSwathImage(ppInSAR[iY][iX]->masterImage, ppInSAR[iY][iX]->masterInfo, _S1_KEEP_BURSTS_);

                            if (pInSAR->flag & _S1_MASTER_IMAGE_COPIED_ && !isArgumentPresentInCSV(pCohTrack->csv, "-keepBursts")) {
                                trashSelectedBursts(ppInSAR[iY][iX]->masterInfo);
                            }
                        }
                        saveInSARParametersFileAtPath(ppInSAR[iY][iX], aPath);
                    }

                    free(aPath);
                    freeCSVStruct(csv);
                }
            }
        }
    }

    /* Check all parameters files share the same common area of interest */
    if (pInSAR->masterInfo->sensorID != __SENTINEL1__) {
        aoi = getCopyOfPolygon(pInSAR->aoi) ;
        for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
            for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
                if (ppInSAR[iY][iX] && (iX || iY)) {
                    aPath = initStringWith2Strings(ppInSAR[iY][iX]->whereAmI, "/TextFiles/InSARParameters.txt") ;
                    pInSAR = readInSARParametersFileAtPath(aPath) ;
                    free(aPath) ;
                    aoi->P[0].x = (aoi->P[0].x > pInSAR->aoi->P[0].x)? aoi->P[0].x : pInSAR->aoi->P[0].x ;
                    aoi->P[0].y = (aoi->P[0].y > pInSAR->aoi->P[0].y)? aoi->P[0].y : pInSAR->aoi->P[0].y ;
                    aoi->P[2].x = (aoi->P[2].x < pInSAR->aoi->P[2].x)? aoi->P[2].x : pInSAR->aoi->P[2].x ;
                    aoi->P[2].y = (aoi->P[2].y < pInSAR->aoi->P[2].y)? aoi->P[2].y : pInSAR->aoi->P[2].y ;
                    freeInSARParametersStruct(pInSAR) ;
                }
            }
        }
        for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
            for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
                if (ppInSAR[iY][iX]) {
                    aPath = initStringWith2Strings(ppInSAR[iY][iX]->whereAmI, "/TextFiles/InSARParameters.txt") ;
                    pInSAR = readInSARParametersFileAtPath(aPath) ;
                    pInSAR->aoi->P[0].x = aoi->P[0].x ;
                    pInSAR->aoi->P[0].y = aoi->P[0].y ;                    
                    pInSAR->aoi->P[2].x = aoi->P[2].x ;
                    pInSAR->aoi->P[2].y = aoi->P[2].y ;
                    saveInSARParametersFileAtPath(pInSAR, aPath) ;
                    freeInSARParametersStruct(pInSAR) ;
                    free(aPath) ;
                }
            }
        }
    }

}

void cohTrackSequentialInSARProcessing(cohTrackStruct *pCohTrack)
{
    char *aPath ;
    int iX, iY ;
    CSVStruct *csv ;
    InSARParametersStruct *ppInSAR ;

    /* Now that everything is ready, perform InSAR processing */
    
    /* Start with reference processing */
    printf("\nInterferometric processing of reference coregistration\n") ;
    csv = addStringValInCSVStruct("InSARProductsGeneration", NULL) ;
    csv = addStringValInCSVStruct("-i", csv) ;
    aPath = initStringWith2Strings(pCohTrack->pInSAR->whereAmI, "/TextFiles/InSARParameters.txt") ;
    csv = addStringValInCSVStruct(aPath, csv) ;
    InSARProductsGeneration(csv) ;
    free(aPath) ;
    freeCSVStruct(csv) ;
    
    printf("\n\t---> Performing sequential InSAR processing\n") ;
    for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
        for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
            ppInSAR = pCohTrack->ppInSAR[iY][iX] ;
            if (ppInSAR && (iX || iY)) {
                csv = addStringValInCSVStruct("InSARProductsGeneration", NULL) ;
                printf("---> Working directory: %s\n", ppInSAR->whereAmI);
                aPath = initStringWith2Strings(ppInSAR->whereAmI, "/TextFiles/InSARParameters.txt") ;
                csv = addStringValInCSVStruct(aPath, csv) ;
                InSARProductsGeneration(csv) ;
                free(aPath) ;
                freeCSVStruct(csv) ;
            }
        }
    }
}

void cohTrackStackProcessing(cohTrackStruct *pCohTrack)
{
    int iX, iY, xTileIndex, yTileIndex, iXTile, iYTile ;
    int iXMax, iYMax ;
    InSARParametersStruct ***ppInSAR ;
    tileTool *cohRefTileTool ;
    float **cohMat, **floatTileOut, **floatTileIn ;
    cohMax *locMax ;

    ppInSAR = pCohTrack->ppInSAR ;
    cohMat = pCohTrack->cohMat ;
    locMax = pCohTrack->locMax ;
    cohRefTileTool = pCohTrack->ppCohTiles[0][0] ;

    /* Coherence stack processing by tiles */
    for (yTileIndex = 0; yTileIndex < pCohTrack->nTilesY; yTileIndex++) {
        for (xTileIndex = 0; xTileIndex < pCohTrack->nTilesX; xTileIndex++) {
            /* Load local incidence tile if available */
            if (pCohTrack->incidenceAngle) {
                readTileAtIndexes(pCohTrack->incidenceAngle, xTileIndex, yTileIndex) ;
            }
            
            /* Load InSAR products stacks for each tile */
            for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
                for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
                    if (ppInSAR[iY][iX]) {
                        readTileAtIndexes(pCohTrack->ppCohTiles[iY][iX], xTileIndex, yTileIndex) ;
                        readTileAtIndexes(pCohTrack->ppInterfTiles[iY][iX], xTileIndex, yTileIndex) ;
                        readTileAtIndexes(pCohTrack->ppMod2Tiles[iY][iX], xTileIndex, yTileIndex) ;
                        if (pCohTrack->interfDiffMat) {
                            readTileAtIndexes(pCohTrack->ppInterfDiffTiles[iY][iX], xTileIndex, yTileIndex) ;
                        }
                    }
                }
            }

            /* For each point within each tile... */
            for (iYTile = 0; iYTile < cohRefTileTool->yTileSize; iYTile++) {
                for (iXTile = 0; iXTile < (int)(cohRefTileTool->xTileSize); iXTile++) {
                    /* Extract local coherence mapping from coherence stack */
/*
                    if (yTileIndex * 256 + iYTile == 758 && xTileIndex * 256 + iXTile == 544)
                    {
                        printf("ici\n") ;
                    }
*/                   
                    for (iY = pCohTrack->iYMin; iY <= (int)(pCohTrack->iYMax); iY++) {
                        for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
                            if (ppInSAR[iY][iX]) {
                                floatTileIn = (float **)pCohTrack->ppCohTiles[iY][iX]->tile;
                                cohMat[iY][iX] = floatTileIn[iYTile][iXTile] ;
                                floatTileIn = (float **)pCohTrack->ppInterfTiles[iY][iX]->tile;
                                pCohTrack->interfMat[iY][iX] = floatTileIn[iYTile][iXTile] ;
                                if (pCohTrack->interfDiffMat) {
                                    floatTileIn = (float **)pCohTrack->ppInterfDiffTiles[iY][iX]->tile;
                                    pCohTrack->interfDiffMat[iY][iX] = floatTileIn[iYTile][iXTile] ;
                                }
                                
                            }
                            else {
                                cohMat[iY][iX] = 0 ;
                                pCohTrack->interfMat[iY][iX] = 0 ;
                                if (pCohTrack->interfDiffMat) {
                                    pCohTrack->interfDiffMat[iY][iX] = 0 ;
                                }
                            }
                        }
                    }

                    /* Locate coherence maximum */
                    locateCohMax(pCohTrack);
                    iXMax = locMax->iXMax ;
                    iYMax = locMax->iYMax ;

                    /* convert tracked shifts in metric values */
                    if (!(pCohTrack->flag & __PIX_MEASUREMENT__)) {
                        locMax->fineXMax *= pCohTrack->pInSAR->masterInfo->rangeResolutionCell ;
                        if (pCohTrack->incidenceAngle) {
                            floatTileOut = (float **)pCohTrack->incidenceAngle->tile ;
                            locMax->fineXMax /=  sinf(floatTileOut[iYTile][iXTile]) ;
                        }
                        
                        locMax->fineYMax *= pCohTrack->pInSAR->masterInfo->azimuthResolutionCell ;
                    }
                    

                    /* Transfer results to output tiles */
                    floatTileOut = (float **)pCohTrack->trackedCoh->tile ;
                    floatTileOut[iYTile][iXTile] = locMax->maxCoh ;

                    floatTileOut = (float **)pCohTrack->trackedRangeShifts->tile ;
                    floatTileOut[iYTile][iXTile] = locMax->fineXMax ;
                    floatTileOut = (float **)pCohTrack->trackedAzimuthShifts->tile ;
                    floatTileOut[iYTile][iXTile] = locMax->fineYMax ;

                    /* Tracked interferogram */
//                    floatTileIn = (float **)pCohTrack->ppInterfTiles[iYMax][iXMax]->tile ;
                    floatTileOut = (float **)pCohTrack->trackedInt->tile ;
                    floatTileOut[iYTile][iXTile] = locMax->optPhase ;
//                    floatTileOut[iYTile][iXTile] = floatTileIn[iYTile][iXTile] ;

                    /* Tracked differential interferogram */
                    if (pCohTrack->interfDiffMat) {
                        floatTileOut = (float **)pCohTrack->trackedDiffInt->tile ;
                        floatTileOut[iYTile][iXTile] = locMax->optDiffPhase ;
                    }
                    

                    /* Tracked slave amplitude */
                    floatTileIn = (float **)pCohTrack->ppMod2Tiles[iYMax][iXMax]->tile ;
                    floatTileOut = (float **)pCohTrack->trackedMod2->tile ;
                    floatTileOut[iYTile][iXTile] = floatTileIn[iYTile][iXTile] ;
                }
            }
            
            updateTileToolForIndexes(pCohTrack->trackedCoh, xTileIndex, yTileIndex) ;
            writeTileToOutputFile(pCohTrack->trackedCoh, pCohTrack->trackedCoherenceFile) ;
            updateTileToolForIndexes(pCohTrack->trackedInt, xTileIndex, yTileIndex) ;
            writeTileToOutputFile(pCohTrack->trackedInt, pCohTrack->trackedInterfFile) ;
            if (pCohTrack->interfDiffMat) {
                updateTileToolForIndexes(pCohTrack->trackedDiffInt, xTileIndex, yTileIndex) ;
                writeTileToOutputFile(pCohTrack->trackedDiffInt, pCohTrack->trackedResidualPhaseFile) ;
            }
            
            updateTileToolForIndexes(pCohTrack->trackedMod2, xTileIndex, yTileIndex) ;
            writeTileToOutputFile(pCohTrack->trackedMod2, pCohTrack->trackedMod2File) ;
            updateTileToolForIndexes(pCohTrack->trackedRangeShifts, xTileIndex, yTileIndex) ;
            writeTileToOutputFile(pCohTrack->trackedRangeShifts, pCohTrack->trackedRangeShiftFile) ;
            updateTileToolForIndexes(pCohTrack->trackedAzimuthShifts, xTileIndex, yTileIndex) ;
            writeTileToOutputFile(pCohTrack->trackedAzimuthShifts, pCohTrack->trackedAzimuthShiftFile) ;
        }
    }
}

void locateCohMax(cohTrackStruct *pCohTrack)
{
    int iXMaxCoh = 0, iYMaxCoh = 0 ;
    int i1, i2, i3, testVal ;
    float maxCohX, maxCohY ;
    float optPhaseX, optPhaseY ;
    float coherenceThreshold ;
    cohMax *locMax ;

    coherenceThreshold = pCohTrack->coherenceThreshold ;
    locMax = pCohTrack->locMax ;

    cohTrackStats(pCohTrack) ;

    /* If tracking on max value is requested */
    if (pCohTrack->flag & __MAX_LOC__) {
        if (locMax->maxCoh > pCohTrack->coherenceThreshold){
            iXMaxCoh = locMax->iXMax ;
            iYMaxCoh = locMax->iYMax ;
            locMax->fineXMax = iXMaxCoh * pCohTrack->dXStep ;
            locMax->fineYMax = iYMaxCoh * pCohTrack->dYStep ;
        }
        else {
            locMax->fineXMax = locMax->fineYMax = (pCohTrack->flag & __NAN_EXCLUSION__)? floatNaN : 0. ;
        }
        locMax->optPhase = pCohTrack->interfMat[iYMaxCoh][iXMaxCoh] ;
        locMax->optDiffPhase = (pCohTrack->interfDiffMat)? pCohTrack->interfDiffMat[iYMaxCoh][iXMaxCoh] : 0 ;
        
        return ;
    }

    /* If centroidization is requested */
    if (pCohTrack->flag & __CENTROIDIZATION__) {
        if (pCohTrack->flag & __CROSS_MAPPING__) {
            locMax->iXMax = locMax->iYMax = 0 ;
        }
        
        if (locMax->cohCMAvg > pCohTrack->coherenceThreshold) {
            /* Optimum coherence estimation */
            optCohX(pCohTrack) ;
            optCohY(pCohTrack) ;
            locMax->fineXMax = locMax->xC ;
            locMax->fineYMax = locMax->yC ;
            
            /* Optimum phase estimation */
            optXPhaseCalc(pCohTrack) ;
            optYPhaseCalc(pCohTrack) ;
            
            if ((locMax->maxCohX > locMax->maxCohY)) {
                locMax->maxCoh = locMax->maxCohX ;
                locMax->optPhase = locMax->optPhaseX ;
                locMax->optDiffPhase = locMax->optDiffPhaseX ;
            }
            else {
                locMax->maxCoh = locMax->maxCohY ;
                locMax->optPhase = locMax->optPhaseY ;
                locMax->optDiffPhase = locMax->optDiffPhaseY ;
            }
            locMax->fineXMax *= pCohTrack->dXStep ;
            locMax->fineYMax *= pCohTrack->dYStep ;
            
        }
        else {
            locMax->fineXMax = locMax->fineYMax = (pCohTrack->flag & __NAN_EXCLUSION__)? floatNaN : 0. ;
            locMax->maxCoh = pCohTrack->cohMat[0][0] ;
            locMax->optPhase = pCohTrack->interfMat[0][0] ;
            locMax->optDiffPhase = (pCohTrack->interfDiffMat)? pCohTrack->interfDiffMat[0][0] : 0 ;
        }

        return ;
    }
    

    iYMaxCoh = locMax->iYMax ;
    iXMaxCoh = locMax->iXMax ;
    /* Line localisation */
    /* We first determine if along X located maximum is well surounded by second and third higher coherence values */
    i1 = pCohTrack->xIndex[iYMaxCoh][pCohTrack->iYMax] ;
    i2 = pCohTrack->xIndex[iYMaxCoh][pCohTrack->iYMax - 1] ;
    i3 = pCohTrack->xIndex[iYMaxCoh][pCohTrack->iYMax - 2] ;
    testVal = i1 + i2 + i3 ;
    testVal = (testVal == 3 * i1)? 1 : 0 ;
    /* if not, we just check it is not a border value */
    if (!testVal){
        testVal = (i1 > pCohTrack->iXMin && i1 < pCohTrack->iXMax)? 1 : 0 ;
    }

    /* We additionally test if slope and range are above requested thresholds */
    if (pCohTrack->meanCohX[iYMaxCoh] > coherenceThreshold && pCohTrack->rangeX[iYMaxCoh] > pCohTrack->rangeThreshold && testVal) {
        /* Optimum coherence estimation */
        maxCohX = optCohX(pCohTrack) ;

        /* Optimum phase estimation */
        optPhaseX = optXPhaseCalc(pCohTrack) ;
    }
    else {
        locMax->iXMax = 0 ;
        locMax->fineXMax = (pCohTrack->flag & __NAN_EXCLUSION__)? floatNaN : 0. ;
        maxCohX = pCohTrack->cohMat[0][0] ;
        optPhaseX = pCohTrack->interfMat[0][0] ;
        pCohTrack->locMax->optDiffPhaseX = (pCohTrack->interfDiffMat)? pCohTrack->interfDiffMat[0][0] : 0 ;
    }
    
    /* column localisation */
    /* We first determine if along Y located maximum is well surounded by second and third higher coherence values */
    i1 = pCohTrack->yIndex[iXMaxCoh][pCohTrack->iXMax] ;
    i2 = pCohTrack->yIndex[iXMaxCoh][pCohTrack->iXMax - 1] ;
    i3 = pCohTrack->yIndex[iXMaxCoh][pCohTrack->iXMax - 2] ;
    testVal = i1 + i2 + i3 ;
    testVal = (testVal == 3 * i1)? 1 : 0 ;
    /* if not, we just check it is not a border value */
    if (!testVal){
        testVal = (i1 > pCohTrack->iYMin && i1 < pCohTrack->iYMax)? 1 : 0 ;
    }

    /* We additionally test if slope and range are above requested thresholds */
    if (pCohTrack->meanCohY[iXMaxCoh] > coherenceThreshold && pCohTrack->rangeY[iXMaxCoh] > pCohTrack->rangeThreshold && testVal) {
        /* Optimum coherence estimation */
        maxCohY = optCohY(pCohTrack) ;

        /* Optimum phase estimation */
        optPhaseY = optYPhaseCalc(pCohTrack) ;
    }
    else {
        locMax->iYMax = 0 ;
        locMax->fineYMax = (pCohTrack->flag & __NAN_EXCLUSION__)? floatNaN : 0. ;
        maxCohY = pCohTrack->cohMat[0][0] ;
        optPhaseY = pCohTrack->interfMat[0][0] ;
        pCohTrack->locMax->optDiffPhaseY = (pCohTrack->interfDiffMat)? pCohTrack->interfDiffMat[0][0] : 0 ;
    }

    /* Coherence maximum */
    locMax->maxCoh = (maxCohX > maxCohY)? maxCohX :  maxCohY ;
    locMax->optPhase = (maxCohX > maxCohY)? optPhaseX : optPhaseY ;
    locMax->optDiffPhase = (maxCohX > maxCohY)? pCohTrack->locMax->optDiffPhaseX : pCohTrack->locMax->optDiffPhaseY ;
    locMax->fineXMax *= pCohTrack->dXStep ;
    locMax->fineYMax *= pCohTrack->dYStep ;

    /* In case of tracking limited to cross mapping, select integer localisation of maximum within the cross */
    if (pCohTrack->flag & __CROSS_MAPPING__) {
        if (maxCohX > maxCohY) {
            locMax->iYMax = 0 ;
        }
        else {
            locMax->iXMax = 0 ;
        }
    }
}

void saveCohTrackStacks(cohTrackStruct *pCohTrack)
{
    char *aPath ;
    int iX, iY, xTileIndex, yTileIndex ;
    InSARParametersStruct *pInSAR = NULL, ***ppInSAR ;
    rawFileDescriptor *outputFile ;

    pInSAR = pCohTrack->pInSAR ;
    ppInSAR = pCohTrack->ppInSAR ;

    /* Saving cohTrack data cube */

    aPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/xCohStack") ;
    outputFile = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;
    iY = 0 ;
    for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
        for (xTileIndex = 0; xTileIndex < pCohTrack->nTilesX; xTileIndex++) {
            for (yTileIndex = 0; yTileIndex < pCohTrack->nTilesY; yTileIndex++) {
                if (ppInSAR[iY][iX]) {
                    readTileAtIndexes(pCohTrack->ppCohTiles[iY][iX], xTileIndex, yTileIndex) ;
                    writeTileToOutputFileInLayer(pCohTrack->ppCohTiles[iY][iX], outputFile, iX - pCohTrack->iXMin) ;
                }
            }
        }
    }
    freeRawFileDescriptor(outputFile) ;

    aPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/yCohStack") ;
    outputFile = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;
    iX = 0 ;
    for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
        for (xTileIndex = 0; xTileIndex < pCohTrack->nTilesX; xTileIndex++) {
            for (yTileIndex = 0; yTileIndex < pCohTrack->nTilesY; yTileIndex++) {
                if (ppInSAR[iY][iX]) {
                    readTileAtIndexes(pCohTrack->ppCohTiles[iY][iX], xTileIndex, yTileIndex);
                    writeTileToOutputFileInLayer(pCohTrack->ppCohTiles[iY][iX], outputFile, iY - pCohTrack->iYMin) ;
                }
            }
        }
    }
    freeRawFileDescriptor(outputFile) ;

    aPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/iXStack") ;
    outputFile = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;
    iY = 0 ;
    for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
        for (xTileIndex = 0; xTileIndex < pCohTrack->nTilesX; xTileIndex++) {
            for (yTileIndex = 0; yTileIndex < pCohTrack->nTilesY; yTileIndex++) {
                if (ppInSAR[iY][iX]) {
                    readTileAtIndexes(pCohTrack->ppInterfTiles[iY][iX], xTileIndex, yTileIndex) ;
                    writeTileToOutputFileInLayer(pCohTrack->ppInterfTiles[iY][iX], outputFile, iX - pCohTrack->iXMin) ;
                }
            }
        }
    }
    freeRawFileDescriptor(outputFile) ;

    aPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/iYStack") ;
    outputFile = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;
    iX = 0 ;
    for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
        for (xTileIndex = 0; xTileIndex < pCohTrack->nTilesX; xTileIndex++) {
            for (yTileIndex = 0; yTileIndex < pCohTrack->nTilesY; yTileIndex++) {
                if (ppInSAR[iY][iX]) {
                    readTileAtIndexes(pCohTrack->ppInterfTiles[iY][iX], xTileIndex, yTileIndex) ;
                    writeTileToOutputFileInLayer(pCohTrack->ppInterfTiles[iY][iX], outputFile, iY - pCohTrack->iYMin) ;
                }
            }
        }
    }
    freeRawFileDescriptor(outputFile);
}

cohTrackStruct *getCohTrackParameters(CSVStruct *csv)
{
    char *aPath, *xProcessingScheme, *yProcessingScheme, *aString ;
    int i, j, nStepsX, nStepsY;
    int   currentDirectoryFdesc, workingDirectoryFileDesscriptor ;
    float dXMin, dXMax, dXStep, dYMin, dYMax, dYStep, *dX, *dY ;
    struct divrf divMod ;
    keyValue *cohTrackParams ;
    CSVStruct *aCSV ;
    cohTrackStruct *pCohTrack ;
    InSARParametersStruct *pInSAR = NULL ;

    pCohTrack = calloc(1, sizeof(pCohTrack[0])) ;
    pCohTrack->csv = csv ;

    /* Checking if InSAR parameter file is given as input parameter */
    i = 1 ;
    while (i < csv->numberOfEntries && !pInSAR) {
        pInSAR = readInSARParametersFileAtPath(csv->stringVal[i]) ;
        i++ ;
    }
    /* if not, consider working directory as an InSAR directory */
    if (!pInSAR) {
        aPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
        pInSAR = readInSARParametersFileAtPath(aPath) ;
        if (!pInSAR) {
            printf("\t-/-> InSAR parameter file not found\n\n") ;
            cohTrackHelp() ;
        }

        free(aPath) ;
    }
    pCohTrack->workingDirectory = initStringWith2Strings(pInSAR->whereAmI, "Cohtrack/") ;
//    pCohTrack->sequentialProcessDirectory = initStringWith2Strings(pCohTrack->workingDirectory, "Processes/") ;
    pCohTrack->sequentialProcessDirectory = initStringWithString(pCohTrack->workingDirectory) ;
//    pCohTrack->resultsDirectory = initStringWith2Strings(pCohTrack->workingDirectory, "Results/") ;
    pCohTrack->resultsDirectory = initStringWith2Strings(pInSAR->whereAmI, "InSARProducts/") ;
    pCohTrack->pInSAR = pInSAR ;
    printf("\t---> Main working directory: %s\n", pCohTrack->pInSAR->whereAmI) ;
    currentDirectoryFdesc = open(".", O_RDONLY) ;
    workingDirectoryFileDesscriptor = open(pInSAR->whereAmI, O_DIRECTORY) ;
    fchdir(workingDirectoryFileDesscriptor) ;

    /* Check if processing parameters schemes are given as command line parameters */
    aCSV = NULL ;
    xProcessingScheme = yProcessingScheme = NULL ;
    for (i = 0; i < csv->numberOfEntries; i++) {
        if (strncmp(csv->stringVal[i], "[", 1) == 0) {
            j = i;
            do {
                aCSV = addStringValInCSVStruct(csv->stringVal[j], aCSV) ; 
                if (strncmp(csv->stringVal[j] + strlen(csv->stringVal[j]) - 1, "]", 1) == 0) {
                    if (!xProcessingScheme) {
                        xProcessingScheme = getStringFromCSV(aCSV) ;
                    }
                    else {
                        yProcessingScheme = getStringFromCSV(aCSV) ;
                    }
                    freeCSVStruct(aCSV) ;
                    aCSV = NULL ;
                }
                j++;
            } while (j < csv->numberOfEntries && !yProcessingScheme) ;
            i = j ;
        }
    }

    /* Check if interpolation must be forced in case of already done */
    pCohTrack->flag = 0 ;
    if (isArgumentPresentInCSV(csv, "--all")) {
        printf("\t---> Forcing re-interpolation and recalculation of the whole interferometric stack.\n");
        pCohTrack->flag |= __FORCE_INTERPOL__ ;
    }
    if (isArgumentPresentInCSV(csv, "--InSAR")) {
        printf("\t---> Forcing recalculation of the whole interferometric stack stack.\n");
        pCohTrack->flag |= __FORCE_INSAR__ ;
    }
    pCohTrack->flag |= (isFlagPresentInCSV(csv, "c")) ? __CROSS_MAPPING__ : pCohTrack->flag ;
    pCohTrack->flag |= (isArgumentPresentInCSV(csv, "--opt")) ? __COHTRACK_ONLY__ : pCohTrack->flag ;
    pCohTrack->flag |= (isFlagPresentInCSV(csv, "W")) ? __WEIGHTED_AVG__ : pCohTrack->flag ;
    pCohTrack->flag |= (isFlagPresentInCSV(csv, "C")) ? __CENTROIDIZATION__ : pCohTrack->flag ;
    pCohTrack->flag |= (isFlagPresentInCSV(csv, "M")) ? __MAX_LOC__ : pCohTrack->flag ;
    pCohTrack->flag |= (isFlagPresentInCSV(csv, "S")) ? __SLOPE_CORRECTION__ : pCohTrack->flag ;
    pCohTrack->flag |= (isFlagPresentInCSV(csv, "P")) ? __PIX_MEASUREMENT__ : pCohTrack->flag ;

    aPath = initStringWith2Strings(pCohTrack->pInSAR->whereAmI, "/TextFiles/cohTrackParameters.txt");
    /* Get cohTrack parameter file */
    /* If not existing, create it */
    if (!fileExistsAtPath(aPath)) {
        createCohTrackParameterFile(pCohTrack->pInSAR) ;
    }
    pCohTrack->cohTrackParams = cohTrackParams = readParameterFileAtPath(aPath);

    /* Get processing parameters schemes updating parameter file if these parameters are given through command line */
    dXMin = dXMax = dXStep = dYMin = dYMax = dYStep = 0 ;
    if (xProcessingScheme) {
        sscanf(xProcessingScheme, "[ %f : %f : %f]", &dXMin, &dXStep, &dXMax) ;
        setStringValForKeyIn(cohTrackParams, xProcessingScheme, "xSampling") ;
        if (yProcessingScheme) {
            sscanf(yProcessingScheme, "[ %f : %f : %f]", &dYMin, &dYStep, &dYMax) ;
            setStringValForKeyIn(cohTrackParams, yProcessingScheme, "ySampling") ;
            free(yProcessingScheme) ;
        }
        writeParameterFileAtPath(cohTrackParams, aPath);
        free(xProcessingScheme) ;
    }
    else {
        aString = getStringValForKeyIn(cohTrackParams, "xSampling") ;
        stripWhiteCharsAtStartOfString(aString) ;
        if (strncmp(aString, "[", 1)) {
            sscanf(aString, "%f : %f : %f", &dXMin, &dXStep, &dXMax) ;
        }
        else {
            sscanf(aString, "[ %f : %f : %f", &dXMin, &dXStep, &dXMax) ;
        }
        
        aString = getStringValForKeyIn(cohTrackParams, "ySampling") ;
        stripWhiteCharsAtStartOfString(aString) ;
        if (strncmp(aString, "[", 1)) {
            sscanf(aString, "%f : %f : %f", &dYMin, &dYStep, &dYMax) ;
        }
        else {
            sscanf(aString, "[ %f : %f : %f", &dYMin, &dYStep, &dYMax) ;
        }
    }

    free(aPath) ;

    pCohTrack->coherenceThreshold = getFloatValForKeyIn(cohTrackParams, "Coherence threshold") ;
    pCohTrack->rangeThreshold = getFloatValForKeyIn(cohTrackParams, "Visibility") ;
//    pCohTrack->slopeThreshold = getFloatValForKeyIn(cohTrackParams, "Slope") ;
    pCohTrack->sigmaX = getFloatValForKeyIn(cohTrackParams, "Sigma of range Gaussian filtering") ;
    pCohTrack->sigmaY = getFloatValForKeyIn(cohTrackParams, "Sigma of azimuth Gaussian filtering") ;
    pCohTrack->flag |= (!strcmp(getStringValForKeyIn(cohTrackParams, "NaN"), "YES"))? __NAN_EXCLUSION__ : pCohTrack->flag ;
    

    /* Basic check of parameters */
    dXStep = fabs(dXStep) ;
    dYStep = fabs(dYStep) ;
    if (dXMax < dXMin || (dXStep && fabs(dXMax - dXMin) < 2 * dXStep) ||
        dYMax < dYMin || (dYStep && fabs(dYMax - dYMin) < 2 * dYStep) ||
        dXMin > 0 || dYMin > 0 || dXMax < 0 || dYMax < 0)
    {
        ase("\t-/-> Given processing parameters are not valid\n\n");
    }
    /* Round min and max values to multiple of step and compute corresponding indexes */
    divMod = divrf(dXMin, dXStep) ;
    pCohTrack->dXMin = divMod.q * dXStep ;
    pCohTrack->iXMin = divMod.q ;
    
    divMod = divrf(dYMin, dYStep) ;
    pCohTrack->dYMin = divMod.q * dYStep ;
    pCohTrack->iYMin = divMod.q ;
    
    divMod = divrf(dXMax, dXStep) ;
    pCohTrack->dXMax = divMod.q * dXStep ;
    pCohTrack->iXMax = divMod.q ;
    
    divMod = divrf(dYMax, dYStep) ;
    pCohTrack->dYMax = divMod.q * dYStep ;
    pCohTrack->iYMax = divMod.q ;
    

    pCohTrack->dXStep = dXStep ;
    pCohTrack->dYStep = dYStep ;
    pCohTrack->nStepsX = nStepsX = pCohTrack->iXMax - pCohTrack->iXMin + 1 ;
    pCohTrack->nStepsY = nStepsY = pCohTrack->iYMax - pCohTrack->iYMin + 1 ;
    
    /* Compute shifts vectors */
    pCohTrack->dX = dX = vectorFloat(pCohTrack->iXMin, pCohTrack->iXMax) ;
    for (i = pCohTrack->iXMin; i <= pCohTrack->iXMax; i++) {
        dX[i] = i * dXStep ;
    }

    pCohTrack->dY = dY = vectorFloat(pCohTrack->iYMin, pCohTrack->iYMax) ;
    for (i = pCohTrack->iYMin; i <= pCohTrack->iYMax; i++) {
        dY[i] = i * dYStep ;
    }


    /* Allocating matrix of *pInSAR InSAR parameters struct */
    /* Indexing is such that ppInSAR[0][0] is the reference registration */
    pCohTrack->ppInSAR = calloc(nStepsY, sizeof(pCohTrack->ppInSAR[0])) ;
    for (i = 0; i < nStepsY; i++) {
        pCohTrack->ppInSAR[i] = calloc(nStepsX, sizeof(pCohTrack->ppInSAR[i][0])) ;
        pCohTrack->ppInSAR[i] -= pCohTrack->iXMin ;
    }
    pCohTrack->ppInSAR -= pCohTrack->iYMin ;

    /* Allocating matrices of tileTools for coherence, interferogram and amplitude images stacks */
    /* Indexing is such that tileTools[0][0] is the reference registration */
    pCohTrack->ppCohTiles = calloc(nStepsY, sizeof(pCohTrack->ppCohTiles[0])) ;
    pCohTrack->ppInterfTiles = calloc(nStepsY, sizeof(pCohTrack->ppInterfTiles[0])) ;
    if (fileExistsAtPath(pCohTrack->pInSAR->residualPhase.filePath)) {
        pCohTrack->ppInterfDiffTiles = calloc(nStepsY, sizeof(pCohTrack->ppInterfDiffTiles[0])) ;
    }
    pCohTrack->ppMod2Tiles = calloc(nStepsY, sizeof(pCohTrack->ppMod2Tiles[0])) ;
    for (i = 0; i < nStepsY; i++) {
        pCohTrack->ppCohTiles[i] = calloc(nStepsX, sizeof(pCohTrack->ppCohTiles[i][0])) ;
        pCohTrack->ppCohTiles[i] -= pCohTrack->iXMin ;
        pCohTrack->ppInterfTiles[i] = calloc(nStepsX, sizeof(pCohTrack->ppInterfTiles[i][0])) ;
        pCohTrack->ppInterfTiles[i] -= pCohTrack->iXMin ;
        if (pCohTrack->ppInterfDiffTiles) {
            pCohTrack->ppInterfDiffTiles[i] = calloc(nStepsX, sizeof(pCohTrack->ppInterfDiffTiles[i][0])) ;
            pCohTrack->ppInterfDiffTiles[i] -= pCohTrack->iXMin ;
        }
        pCohTrack->ppMod2Tiles[i] = calloc(nStepsX, sizeof(pCohTrack->ppMod2Tiles[i][0])) ;
        pCohTrack->ppMod2Tiles[i] -= pCohTrack->iXMin ;
    }
    pCohTrack->ppCohTiles -= pCohTrack->iYMin ;
    pCohTrack->ppInterfTiles -= pCohTrack->iYMin ;
    if (pCohTrack->ppInterfDiffTiles) {
        pCohTrack->ppInterfDiffTiles -= pCohTrack->iYMin ;
    }
    pCohTrack->ppMod2Tiles -= pCohTrack->iYMin ;


    pCohTrack->cohMat = matrixFloat(pCohTrack->iYMin, pCohTrack->iYMax, pCohTrack->iXMin, pCohTrack->iXMax) ;
    pCohTrack->smoothedCohMat = matrixFloat(pCohTrack->iYMin, pCohTrack->iYMax, pCohTrack->iXMin, pCohTrack->iXMax) ;
    pCohTrack->interfMat = matrixFloat(pCohTrack->iYMin, pCohTrack->iYMax, pCohTrack->iXMin, pCohTrack->iXMax) ;
    pCohTrack->interfDiffMat = NULL ;
    if (pCohTrack->ppInterfDiffTiles) {
        pCohTrack->interfDiffMat = matrixFloat(pCohTrack->iYMin, pCohTrack->iYMax, pCohTrack->iXMin, pCohTrack->iXMax) ;
    }
    

    pCohTrack->locMax = calloc(1, sizeof(pCohTrack->locMax[0])) ;

    /* Alloc stats */
    pCohTrack->xIndex = matrixInt(pCohTrack->iYMin, pCohTrack->iYMax, pCohTrack->iXMin, pCohTrack->iXMax) ;
    pCohTrack->yIndex = matrixInt( pCohTrack->iXMin, pCohTrack->iXMax, pCohTrack->iYMin, pCohTrack->iYMax) ;
    pCohTrack->meanCohX = vectorFloat(pCohTrack->iYMin, pCohTrack->iYMax) ;
    pCohTrack->meanCohY = vectorFloat(pCohTrack->iXMin, pCohTrack->iXMax) ;
    pCohTrack->minCohX = vectorFloat(pCohTrack->iYMin, pCohTrack->iYMax) ;
    pCohTrack->minCohY = vectorFloat(pCohTrack->iXMin, pCohTrack->iXMax) ;
    pCohTrack->maxCohX = vectorFloat(pCohTrack->iYMin, pCohTrack->iYMax) ;
    pCohTrack->maxCohY = vectorFloat(pCohTrack->iXMin, pCohTrack->iXMax) ;
    pCohTrack->rangeX = vectorFloat(pCohTrack->iYMin, pCohTrack->iYMax) ;
    pCohTrack->rangeY = vectorFloat(pCohTrack->iXMin, pCohTrack->iXMax) ;
    pCohTrack->slopeX = vectorFloat(pCohTrack->iYMin, pCohTrack->iYMax) ;
    pCohTrack->slopeY = vectorFloat(pCohTrack->iXMin, pCohTrack->iXMax) ;
    pCohTrack->p33X = vectorFloat(pCohTrack->iYMin, pCohTrack->iYMax) ;
    pCohTrack->p33Y = vectorFloat(pCohTrack->iXMin, pCohTrack->iXMax) ;
    pCohTrack->skX = vectorFloat(pCohTrack->iYMin, pCohTrack->iYMax) ;
    pCohTrack->skY = vectorFloat(pCohTrack->iXMin, pCohTrack->iXMax) ;
    pCohTrack->bsX = vectorFloat(pCohTrack->iYMin, pCohTrack->iYMax) ;
    pCohTrack->bsY = vectorFloat(pCohTrack->iXMin, pCohTrack->iXMax) ;

    fchdir(currentDirectoryFdesc) ;

    return (pCohTrack);
}

void freeCohTrackParams(cohTrackStruct *pCohTrack)
{
    int i, j ;
    InSARParametersStruct *ppInSAR ;

    freeVectorFloat(pCohTrack->dX, pCohTrack->iXMin) ;
    freeVectorFloat(pCohTrack->dY, pCohTrack->iYMin) ;

    for (i = pCohTrack->iYMin; i <= pCohTrack->iYMax; i++) {
        for (j = pCohTrack->iXMin; j <= pCohTrack->iXMax; j++) {
            ppInSAR = pCohTrack->ppInSAR[i][j] ;
            if (ppInSAR) {
                if (ppInSAR->masterInfo->sensorID == __SENTINEL1__) {
                    freeS1Specific(ppInSAR->masterInfo->sensorSpecificInfo, _S1_FREE_BURSTS_) ;
                    freeS1Specific(ppInSAR->slaveInfo->sensorSpecificInfo, _S1_FREE_BURSTS_) ;
                    if (ppInSAR->interpolatedSlaveInfo) {
                        freeS1Specific(ppInSAR->interpolatedSlaveInfo->sensorSpecificInfo, _S1_FREE_BURSTS_) ;
                    }
                }
                freeTileTool(pCohTrack->ppCohTiles[i][j]) ;
                freeTileTool(pCohTrack->ppInterfTiles[i][j]) ;
                freeTileTool(pCohTrack->ppMod2Tiles[i][j]) ;
                if (pCohTrack->interfDiffMat) {
                    freeTileTool(pCohTrack->ppInterfDiffTiles[i][j]) ;
                }
                freeInSARParametersStruct(ppInSAR) ;
            }
        }
    }

    pCohTrack->ppInSAR += pCohTrack->iYMin ;
    pCohTrack->ppCohTiles += pCohTrack->iYMin ;
    pCohTrack->ppInterfTiles += pCohTrack->iYMin ;
    pCohTrack->ppMod2Tiles += pCohTrack->iYMin ;
    if (pCohTrack->interfDiffMat) {
        pCohTrack->ppInterfDiffTiles += pCohTrack->iYMin ;
    }
    for (i = 0; i < pCohTrack->nStepsY; i++) {
        pCohTrack->ppInSAR[i] += pCohTrack->iXMin ;
        pCohTrack->ppCohTiles[i] += pCohTrack->iXMin ;
        pCohTrack->ppInterfTiles[i] += pCohTrack->iXMin ;
        pCohTrack->ppMod2Tiles[i] += pCohTrack->iXMin ;

        free(pCohTrack->ppInSAR[i]) ;
        free(pCohTrack->ppCohTiles[i]) ;
        free(pCohTrack->ppInterfTiles[i]) ;
        free(pCohTrack->ppMod2Tiles[i]) ;
        if (pCohTrack->interfDiffMat) {
            pCohTrack->ppInterfDiffTiles[i] += pCohTrack->iXMin ;
            free(pCohTrack->ppInterfDiffTiles[i]) ;
        }
    }
    free(pCohTrack->ppInSAR) ;
    free(pCohTrack->ppCohTiles) ;
    free(pCohTrack->ppInterfTiles) ;
    if (pCohTrack->interfDiffMat) {
        free(pCohTrack->ppInterfDiffTiles) ;
        freeTileTool(pCohTrack->trackedDiffInt) ;
    }
    free(pCohTrack->ppMod2Tiles) ;

    if (pCohTrack->incidenceAngle) {
        freeRawFileDescriptor(pCohTrack->incidenceAngle->input) ;
        freeTileTool(pCohTrack->incidenceAngle) ;
    }
    

    freeTileTool(pCohTrack->trackedCoh) ;
    freeTileTool(pCohTrack->trackedInt) ;
    freeTileTool(pCohTrack->trackedMod2) ;
    freeTileTool(pCohTrack->trackedRangeShifts) ;
    freeTileTool(pCohTrack->trackedAzimuthShifts) ; 

    if (pCohTrack->trackedCoherenceFile) {
        freeRawFileDescriptor(pCohTrack->trackedCoherenceFile) ;
    }

    if (pCohTrack->trackedInterfFile) {
        freeRawFileDescriptor(pCohTrack->trackedInterfFile) ;
    }

    if (pCohTrack->trackedResidualPhaseFile) {
        freeRawFileDescriptor(pCohTrack->trackedResidualPhaseFile) ;
    }

    if (pCohTrack->trackedMod2File) {
        freeRawFileDescriptor(pCohTrack->trackedMod2File) ;
    }

    if (pCohTrack->trackedRangeShiftFile) {
        freeRawFileDescriptor(pCohTrack->trackedRangeShiftFile) ;
    }

    if (pCohTrack->trackedAzimuthShiftFile) {
        freeRawFileDescriptor(pCohTrack->trackedAzimuthShiftFile) ;
    }

    if (pCohTrack->selectedPol) {
        free(pCohTrack->selectedPol) ;
    }

    freeKeyValueList(pCohTrack->cohTrackParams) ;

    freeMatrixFloat(pCohTrack->cohMat, pCohTrack->iYMin, pCohTrack->iXMin) ;
    freeMatrixFloat(pCohTrack->smoothedCohMat, pCohTrack->iYMin, pCohTrack->iXMin) ;
    freeMatrixFloat(pCohTrack->interfMat, pCohTrack->iYMin, pCohTrack->iXMin) ;
    if (pCohTrack->interfDiffMat) {
        freeMatrixFloat(pCohTrack->interfDiffMat, pCohTrack->iYMin, pCohTrack->iXMin) ;
    }


    free(pCohTrack->locMax) ;

    freeMatrixInt(pCohTrack->xIndex, pCohTrack->iYMin, pCohTrack->iXMin) ;
    freeMatrixInt(pCohTrack->yIndex, pCohTrack->iXMin, pCohTrack->iYMin) ;
    freeVectorFloat(pCohTrack->meanCohX, pCohTrack->iYMin) ;
    freeVectorFloat(pCohTrack->meanCohY, pCohTrack->iXMin) ;
    freeVectorFloat(pCohTrack->minCohX, pCohTrack->iYMin) ;
    freeVectorFloat(pCohTrack->minCohY, pCohTrack->iXMin) ;
    freeVectorFloat(pCohTrack->maxCohX, pCohTrack->iYMin) ;
    freeVectorFloat(pCohTrack->maxCohY, pCohTrack->iXMin) ;
    freeVectorFloat(pCohTrack->rangeX, pCohTrack->iYMin) ;
    freeVectorFloat(pCohTrack->rangeY, pCohTrack->iXMin) ;
    freeVectorFloat(pCohTrack->slopeX, pCohTrack->iYMin) ;
    freeVectorFloat(pCohTrack->slopeY, pCohTrack->iXMin) ;
    freeVectorFloat(pCohTrack->p33X, pCohTrack->iYMin) ;
    freeVectorFloat(pCohTrack->p33Y, pCohTrack->iXMin) ;
    freeVectorFloat(pCohTrack->skX, pCohTrack->iYMin) ;
    freeVectorFloat(pCohTrack->skY, pCohTrack->iXMin) ;
    freeVectorFloat(pCohTrack->bsX, pCohTrack->iYMin) ;
    freeVectorFloat(pCohTrack->bsY, pCohTrack->iXMin) ;

    free(pCohTrack->workingDirectory) ;
    free(pCohTrack->sequentialProcessDirectory) ;
    free(pCohTrack->resultsDirectory) ;

    free(pCohTrack);
}

/* Generating coherence tracking subdirectories */
void initCohTrackDirs(cohTrackStruct *pCohTrack)
{
    char *cohTrackDir, *InSARDirName, *InSARDir, *aPath, *anOtherPath ; 
    char refRegistration ;
    int iX, iY ;
    CSVStruct *aCSV ;
    InSARParametersStruct *pInSAR, *ppInSAR ;

    /* Create InSAR working directories */
    pInSAR = pCohTrack->pInSAR ;
    cohTrackDir = pCohTrack->sequentialProcessDirectory ;
    if (!isDir(cohTrackDir)) {
        makeDirRecursively(cohTrackDir) ;
    }
    /* Init flag */
    pCohTrack->flag |= (pCohTrack->flag & __FORCE_INTERPOL__)? pCohTrack->flag : __INTERPOL_DONE__ ;
    pCohTrack->flag |= (pCohTrack->flag & __FORCE_INTERPOL__)? pCohTrack->flag : __INTERPOL_ALL_DONE__ ;

    /* Reference coregistration is already initialized */
    pCohTrack->ppInSAR[0][0] = pCohTrack->pInSAR;
    
    
    /* X an y shifts processing initialization except reference one */
    refRegistration = 1 ;
    InSARDirName = allocStringOfLength(MAXPATHLEN);
    for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
        for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
            if ((iX || iY) && (((pCohTrack->flag & __CROSS_MAPPING__) && (!iX || !iY)) || !(pCohTrack->flag & __CROSS_MAPPING__))) {
                sprintf(InSARDirName, "i%s_%s_dx=%-4.2f_dy=%-4.2f", pInSAR->masterInfo->acquisitionDate, pInSAR->slaveInfo->acquisitionDate, pCohTrack->dX[iX], pCohTrack->dY[iY]) ;
                InSARDir = initStringWith2Strings(cohTrackDir, InSARDirName) ;
                
                if (isDir(InSARDir)) {
                    aPath = initStringWith2Strings(InSARDir, "/TextFiles/InSARParameters.txt") ;
                    pCohTrack->ppInSAR[iY][iX] = readInSARParametersFileAtPath(aPath) ;
                    free(aPath) ;
                    pCohTrack->ppInSAR[iY][iX]->flag |= __INTERPOL_DONE__ ;
                    anOtherPath = initStringWith3Strings(pCohTrack->ppInSAR[iY][iX]->interpolatedSlave->dataDirectoryPath, "/SLCData.", pCohTrack->ppInSAR[iY][iX]->slavePolarizationChannel) ;
                    if (!fileExistsAtPath(anOtherPath) || (pCohTrack->flag & __FORCE_INTERPOL__)) {
                        pCohTrack->ppInSAR[iY][iX]->flag &= ~__INTERPOL_DONE__ ;
                        pCohTrack->flag &= ~__INTERPOL_ALL_DONE__ ;
                        refRegistration = 0 ;
                    }
                    free(anOtherPath) ;
                }
                else {
                    pCohTrack->flag &= ~__INTERPOL_ALL_DONE__ ;
                    refRegistration = 0 ;
                    aCSV = addStringValInCSVStruct("cohTrack", NULL);
                    aCSV = addStringValInCSVStruct(pInSAR->masterImage->imageDirectoryPath, aCSV) ;
                    aCSV = addStringValInCSVStruct(pInSAR->slaveImage->imageDirectoryPath, aCSV) ;
                    aCSV = addStringValInCSVStruct(InSARDir, aCSV) ;
                    if (isDir(pInSAR->SM2MPath)) {
                        aCSV = addStringValInCSVStruct(pInSAR->SM2MPath, aCSV) ;
                    }
                    if (pInSAR->aoiKml) {
                        aCSV = addStringValInCSVStruct(pInSAR->aoiKml, aCSV) ;
                    }
                    
                    pCohTrack->ppInSAR[iY][iX] = initInSAR(aCSV) ;
                    pCohTrack->ppInSAR[iY][iX]->flag &= ~__INTERPOL_DONE__ ;
                    
                    freeCSVStruct(aCSV) ;
                }

                /* Transfer processing parameters */
                ppInSAR = pCohTrack->ppInSAR[iY][iX] ;
                (ppInSAR->sup).Sbaz = ppInSAR->aoi->P[0].y = ppInSAR->aoi->P[1].y = pInSAR->aoi->P[0].y ;
                (ppInSAR->sup).Sgra = ppInSAR->aoi->P[0].x = ppInSAR->aoi->P[3].x = pInSAR->aoi->P[0].x ;
                (ppInSAR->sup).Shaz = ppInSAR->aoi->P[3].y = ppInSAR->aoi->P[2].y = pInSAR->aoi->P[2].y ;
                (ppInSAR->sup).Sdra = ppInSAR->aoi->P[1].x = ppInSAR->aoi->P[2].x = pInSAR->aoi->P[2].x ;
                free(ppInSAR->aoiKml) ;
                ppInSAR->aoiKml = initStringWithString(pInSAR->aoiKml) ;
                free(ppInSAR->externalReferenceDEM) ;
                ppInSAR->externalReferenceDEM = initStringWithString(pInSAR->externalReferenceDEM) ;
                ppInSAR->red.Fra = pInSAR->red.Fra ;
                ppInSAR->red.Faz = pInSAR->red.Faz ;
                ppInSAR->coh.cor = pInSAR->coh.cor ;
                ppInSAR->coh.coa = pInSAR->coh.coa ;
                ppInSAR->coh.spi = pInSAR->coh.spi ;
                ppInSAR->coh.medianFilterSize = pInSAR->coh.medianFilterSize ;
                free(InSARDir) ;
            }
        }
    }

    /* Check if reference registration must be done or rebuilt */
    aPath = initStringWith3Strings(pCohTrack->pInSAR->interpolatedSlave->dataDirectoryPath, "/SLCData.", pCohTrack->pInSAR->slavePolarizationChannel) ;
    pCohTrack->pInSAR->flag |= __INTERPOL_DONE__ ;
    if (!fileExistsAtPath(aPath) || (pCohTrack->pInSAR->flag & __FORCE_INTERPOL__) || (pInSAR->masterInfo->sensorID == __SENTINEL1__ && !refRegistration)) {
        pCohTrack->pInSAR->flag &= ~__INTERPOL_DONE__ ;
        pCohTrack->flag &= ~__INTERPOL_ALL_DONE__ ;
    }
    free(aPath) ;

    for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
        for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
            ppInSAR = pCohTrack->ppInSAR[iY][iX] ;
            if (ppInSAR && (iX || iY)) {
                /* Update InSAR parameters with ones of the reference pair */
                free(ppInSAR->masterPolarizationChannel) ;
                ppInSAR->masterPolarizationChannel = initStringWithString(pInSAR->masterPolarizationChannel) ;
                free(ppInSAR->slavePolarizationChannel) ;
                ppInSAR->slavePolarizationChannel = initStringWithString(pInSAR->slavePolarizationChannel) ;
                free(ppInSAR->aoiKml) ;
                ppInSAR->aoiKml = initStringWithString(pInSAR->aoiKml) ;
                freePolygon(ppInSAR->aoi) ;
                ppInSAR->aoi = getCopyOfPolygon(pInSAR->aoi) ;
                ppInSAR->red.Faz = pInSAR->red.Faz ;
                ppInSAR->red.Fra = pInSAR->red.Fra ;
                ppInSAR->filter.adaptativeFilterSmoothingFactor = pInSAR->filter.adaptativeFilterSmoothingFactor ;
                ppInSAR->filter.sigmar = pInSAR->filter.sigmar ;
                ppInSAR->filter.sigmaz = pInSAR->filter.sigmaz ;
                ppInSAR->coh.coa = pInSAR->coh.coa ;
                ppInSAR->coh.cor = pInSAR->coh.cor ;
                ppInSAR->coh.spi = pInSAR->coh.spi ;
                memcpy(ppInSAR->slaveAffineTransform[0], pInSAR->slaveAffineTransform[0], 6 * sizeof(double)) ;
                if (pInSAR->masterAffineTransform) {
                    memcpy(ppInSAR->masterAffineTransform[0], pInSAR->masterAffineTransform[0], 6 * sizeof(double)) ;
                }
                
                aPath = initStringWith2Strings(ppInSAR->whereAmI, "/TextFiles/InSARParameters.txt") ;
                saveInSARParametersFileAtPath(ppInSAR, aPath) ;
                free(aPath) ;

                if (!(pInSAR->flag & _ALL_POLARIZATIONS_)) {
                    sprintf(ppInSAR->masterInfo->polMode, "%s", ppInSAR->masterPolarizationChannel) ;
                    sprintf(ppInSAR->slaveInfo->polMode, "%s", ppInSAR->slavePolarizationChannel) ;
                    ppInSAR->masterInfo->numberOfLayers = ppInSAR->slaveInfo->numberOfLayers = 1 ;
                }
            }
        }
    }

    free(InSARDirName) ;
}

void initCohTrackTileTools(cohTrackStruct *pCohTrack)
{
    char *aPath;
    int iX, iY;
    int currentDirectoryFdesc, workingDirectoryFileDesscriptor ;
    InSARParametersStruct *pInSAR, *ppInSAR ;
    rawFileDescriptor *incidenceFile ;

    /* Re-read reference InSARParameters.txt file to get input output dimensions as issued by InSAR processing */
    pInSAR = pCohTrack->pInSAR ;
    aPath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/InSARParameters.txt") ;
    freeInSARParametersStruct(pInSAR) ;
    pInSAR = readInSARParametersFileAtPath(aPath) ;
    free(aPath) ;
    pCohTrack->ppInSAR[0][0] = pCohTrack->pInSAR = pInSAR ;

    /*Tile tools initialization */
    for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
        for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
            ppInSAR = pCohTrack->ppInSAR[iY][iX] ;
            if (ppInSAR) {
                currentDirectoryFdesc = open(".", O_RDONLY) ;
                workingDirectoryFileDesscriptor = open(pInSAR->whereAmI, O_DIRECTORY) ;
                fchdir(workingDirectoryFileDesscriptor) ;

                aPath = (ppInSAR->coh.medianFilterSize)? initStringWith2Strings(ppInSAR->coh.filePath, ".mf") : initStringWithString(ppInSAR->coh.filePath) ;
                ppInSAR->coherenceFile = openRawFileForReadingAtPath(aPath) ;
                ppInSAR->coherenceFile->xDim = pInSAR->coh.lenr ;
                ppInSAR->coherenceFile->yDim = pInSAR->coh.lena ;
                free(aPath) ;
                pCohTrack->ppCohTiles[iY][iX] = allocTileToolForFilesOfType(ppInSAR->coherenceFile, pCohTrack->trackedCoherenceFile, "float") ;
                initTileToolWithSizes(pCohTrack->ppCohTiles[iY][iX], 256, 256, 0, 0) ;

                if (!fileExistsAtPath(ppInSAR->interf.filePath)) {
                    printf("No interferogram found in processing directory:\n%s\n", pInSAR->whereAmI) ;
                    ase("Stopping here\n") ;
                }
                openInterferogramFile(ppInSAR) ;               
                ppInSAR->interferogramFile->xDim = pInSAR->interf.lenr ;
                ppInSAR->interferogramFile->yDim = pInSAR->interf.lena ;
                if (ppInSAR->interferogramFile->fileLength != ppInSAR->interferogramFile->xDim * ppInSAR->interferogramFile->yDim * sizeof(float)) {
                    ase("\t-/-> Interferogram file has wrong dimensions") ;
                }
                
                pCohTrack->ppInterfTiles[iY][iX] = allocTileToolForFilesOfType(ppInSAR->interferogramFile, pCohTrack->trackedInterfFile, "float") ;
                initTileToolWithSizes(pCohTrack->ppInterfTiles[iY][iX], 256, 256, 0, 0) ;

                if (fileExistsAtPath(ppInSAR->residualPhase.filePath)) {
                    openResidualInterferogramFile(ppInSAR) ;
                    ppInSAR->residualPhaseFile->xDim = pInSAR->interf.lenr ;
                    ppInSAR->residualPhaseFile->yDim = pInSAR->interf.lena ;
                    pCohTrack->ppInterfDiffTiles[iY][iX] = allocTileToolForFilesOfType(ppInSAR->residualPhaseFile, pCohTrack->trackedResidualPhaseFile, "float") ;
                    initTileToolWithSizes(pCohTrack->ppInterfDiffTiles[iY][iX], 256, 256, 0, 0) ;
                }

                ppInSAR->slaveAmplitudeImageFile = openRawFileForReadingAtPath(ppInSAR->mod2.filePath) ;
                ppInSAR->slaveAmplitudeImageFile->xDim = pInSAR->mod2.lenr ;
                ppInSAR->slaveAmplitudeImageFile->yDim = pInSAR->mod2.lena ;
                pCohTrack->ppMod2Tiles[iY][iX] = allocTileToolForFilesOfType(ppInSAR->slaveAmplitudeImageFile, pCohTrack->trackedMod2File, "float") ;
                initTileToolWithSizes(pCohTrack->ppMod2Tiles[iY][iX], 256, 256, 0, 0) ;

                fchdir(currentDirectoryFdesc) ;
            }
        }
    }
    pCohTrack->incidenceAngle = NULL ;
    if (pCohTrack->flag & __SLOPE_CORRECTION__) {
        aPath = initStringWith2Strings(pInSAR->coherenceFile->directoryPath, "incidence") ;
        if((incidenceFile = openRawFileForReadingAtPath(aPath))) {
            incidenceFile->xDim = pInSAR->coh.lenr ;
            incidenceFile->yDim = pInSAR->coh.lena ;
            pCohTrack->incidenceAngle = allocTileToolForFilesOfType(incidenceFile, NULL, "float") ;
            initTileToolWithSizes(pCohTrack->incidenceAngle, 256, 256, 0, 0) ;
        }
        else {
            printf("\t-/-> local incidence file not found. Range pixel shifts will not be projected on local slopes\n") ;
        }
        free(aPath) ;
    }

    pCohTrack->trackedCoh = allocTileToolForDataOfType(NULL, NULL, pInSAR->coh.lenr, pInSAR->coh.lena, "float") ;
    initTileToolWithSizes(pCohTrack->trackedCoh, 256, 256, 0, 0) ;
    pCohTrack->trackedInt = allocTileToolForDataOfType(NULL, NULL, pInSAR->coh.lenr, pInSAR->coh.lena, "float") ;
    initTileToolWithSizes(pCohTrack->trackedInt, 256, 256, 0, 0) ;
    if (pInSAR->residualPhaseFile) {
        pCohTrack->trackedDiffInt = allocTileToolForDataOfType(NULL, NULL, pInSAR->coh.lenr, pInSAR->coh.lena, "float") ;
        initTileToolWithSizes(pCohTrack->trackedDiffInt, 256, 256, 0, 0) ;
    }
    
    pCohTrack->trackedMod2 = allocTileToolForDataOfType(NULL, NULL, pInSAR->coh.lenr, pInSAR->coh.lena, "float") ;
    initTileToolWithSizes(pCohTrack->trackedMod2, 256, 256, 0, 0) ;
    pCohTrack->trackedRangeShifts = allocTileToolForDataOfType(NULL, NULL, pInSAR->coh.lenr, pInSAR->coh.lena, "float") ;
    initTileToolWithSizes(pCohTrack->trackedRangeShifts, 256, 256, 0, 0) ;
    pCohTrack->trackedAzimuthShifts = allocTileToolForDataOfType(NULL, NULL, pInSAR->coh.lenr, pInSAR->coh.lena, "float") ;
    initTileToolWithSizes(pCohTrack->trackedAzimuthShifts, 256, 256, 0, 0) ;

    pCohTrack->nTilesX = pCohTrack->ppCohTiles[0][0]->xTileNumber ;
    pCohTrack->nTilesY = pCohTrack->ppCohTiles[0][0]->yTileNumber ;
}

void initOutputFiles(cohTrackStruct *pCohTrack) 
{
    char *aPath ;
    InSARParametersStruct *pInSAR ;

    /* Output files initialization */
    pInSAR = pCohTrack->pInSAR ;
    aPath = initStringWith2Strings(pCohTrack->resultsDirectory, getStringValForKeyIn(pCohTrack->cohTrackParams, "Tracked coh")) ;
    pCohTrack->trackedCoherenceFile = openRawFileForReadingAndWritingAtPath(aPath) ;
    free(aPath) ;
    aPath = initStringWith2Strings(pCohTrack->resultsDirectory, getStringValForKeyIn(pCohTrack->cohTrackParams, "Tracked int")) ;
    pCohTrack->trackedInterfFile = openRawFileForReadingAndWritingAtPath(aPath) ;
    free(aPath) ;
    if (pInSAR->residualPhaseFile) {
        aPath = initStringWith3Strings(pCohTrack->resultsDirectory, getPointerToFileNameInPath(pInSAR->residualPhaseFile->fileName), ".tracked") ;
        pCohTrack->trackedResidualPhaseFile = openRawFileForReadingAndWritingAtPath(aPath) ;
        free(aPath) ;
    }
    aPath = initStringWith2Strings(pCohTrack->resultsDirectory, getStringValForKeyIn(pCohTrack->cohTrackParams, "Tracked slave")) ;
    pCohTrack->trackedMod2File = openRawFileForReadingAndWritingAtPath(aPath) ;
    free(aPath) ;
    aPath = initStringWith2Strings(pCohTrack->resultsDirectory, getStringValForKeyIn(pCohTrack->cohTrackParams, "Tracked range")) ;
    pCohTrack->trackedRangeShiftFile = openRawFileForReadingAndWritingAtPath(aPath) ;
    free(aPath) ;
    aPath = initStringWith2Strings(pCohTrack->resultsDirectory, getStringValForKeyIn(pCohTrack->cohTrackParams, "Tracked azimuth")) ;
    pCohTrack->trackedAzimuthShiftFile = openRawFileForReadingAndWritingAtPath(aPath) ;
    free(aPath) ;

}

/* Initializing coherence tracking shift transforms */
void initShiftTransforms(cohTrackStruct *pCohTrack)
{
    char *aPath ;
    int iX, iY ;
    InSARParametersStruct *ppInSAR ;
    
    /* Re-initialize interpolation transform with required shifts */
    for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
        for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
            ppInSAR = pCohTrack->ppInSAR[iY][iX];
            if (ppInSAR) {
//                ppInSAR->flag &= ~_VERBOSE_;
                ppInSAR->xShift = pCohTrack->dX[iX] ;
                ppInSAR->yShift = pCohTrack->dY[iY] ;
                ppInSAR->slaveAffineTransform[0][2] += pCohTrack->dX[iX] ;
                ppInSAR->slaveAffineTransform[1][2] += pCohTrack->dY[iY] ;
                aPath = initStringWith2Strings(ppInSAR->whereAmI, "/TextFiles/InSARParameters.txt") ;
                saveInSARParametersFileAtPath(ppInSAR, aPath) ;
                free(aPath) ;
                if (ppInSAR->masterInfo->sensorID == __SENTINEL1__) {
                    /* Initialize interpolated slave info */
                    if (iX || iY) {
                        freeInfoImage(ppInSAR->interpolatedSlaveInfo);
                        ppInSAR->interpolatedSlaveInfo = mergeFrameInfo(ppInSAR->interpolatedSlave, ppInSAR->masterInfo->polMode);
                        allocAndInitDerampingForBursts(ppInSAR->interpolatedSlaveInfo);
                    }
                }
            }
        }
    }
}


/* Coherence stats calculation for a given tracked pixel */
/* Smoothing of transfered values within pCohTrack->cohMat, ->cohVectX and ->cohVectY */
/* Matrix smoothing weights are (1 5 1) */
/*                              (5 9 5) */
/*                              (1 5 1) */
void cohTrackStats(cohTrackStruct *pCohTrack) 
{
    int det, iX, iY, iX0, iY0, i, j, i33 ;
    int iXMin, iXMax, iYMin, iYMax ;
    int *xIndex, *yIndex ;
    div_t iP ;
    float a, b, Sx, Sxy, Sy, Sx2 ;
    float **cohMat, **smoothedCohMat ;
    float *p33X, *p33Y, *p33 ;
    float nSteps, nSteps2, norm, weight ;
    float weightCM, varCM,  normCM, centroidizationThreshold ;
    float maxSlope, maxRange, maxRangeMean, backgroundCoh ;
    InSARParametersStruct ***ppInSAR;
    cohMax *locMax ;

    ppInSAR = pCohTrack->ppInSAR ;
    cohMat = pCohTrack->cohMat ;
    smoothedCohMat = pCohTrack->smoothedCohMat ;
    locMax = pCohTrack->locMax ;
    
    /* Smoothing  */
    nSteps = nSteps2 = 0 ;
    backgroundCoh = 0 ;
    locMax->iXMax = locMax->iYMax = 0 ;
    locMax->iXMin = locMax->iYMin = 0 ;
    locMax->xC = locMax->yC = 0 ;
    locMax->maxCoh = 0 ;
    locMax->minCoh = 1 ;
    locMax->cohCMAvg = weightCM = normCM = varCM = 0 ;
    locMax->xTrend = locMax->yTrend = 0 ;
    centroidizationThreshold = pCohTrack->coherenceThreshold ;
    for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
        for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
            /* Coherence tracking smoothing */
            iXMin = (iX == pCohTrack->iXMin)? iX : iX - 1 ;
            iXMax = (iX == pCohTrack->iXMax)? iX : iX + 1 ;
            iYMin = (iY == pCohTrack->iXMin)? iY : iY - 1 ;
            iYMax = (iY == pCohTrack->iXMax)? iY : iY + 1 ;
            smoothedCohMat[iY][iX] = 0.0f ;
            if (ppInSAR[iY][iX]) {
                nSteps++ ;
                if (pCohTrack->sigmaX || pCohTrack->sigmaY) {
                    norm = 0 ;     
                    for (j = iYMin; j <= iYMax; j++) {
                        for (i = iXMin; i <= iXMax; i++) {
                            if (cohMat[j][i]) {
                                weight = (pCohTrack->sigmaX)? expf(- .5 *powf(fabsf((float)(i - iX)) / pCohTrack->sigmaX, 2.)) : 1 ; 
                                weight *= (pCohTrack->sigmaY)? expf(- .5 *powf(fabsf((float)(j - iY)) / pCohTrack->sigmaY, 2.)) : 1 ;
//                                weight = 9. - 4 * (fabs(i - iX) + fabs(j - iY)) ;
                                smoothedCohMat[iY][iX] += weight * cohMat[j][i] ;
                                norm += weight ;                            
                            }
                        }
                    }
                    smoothedCohMat[iY][iX] /= (norm)? norm : 1 ;
                }
                else {
                    smoothedCohMat[iY][iX] = cohMat[iY][iX] ;
                }

                if(locMax->maxCoh < smoothedCohMat[iY][iX]) {
                    locMax->maxCoh = smoothedCohMat[iY][iX] ;
                    locMax->iXMax = iX ;
                    locMax->iYMax = iY ;
                }
                
                if(locMax->minCoh > smoothedCohMat[iY][iX]) {
                    locMax->minCoh = smoothedCohMat[iY][iX] ;
                    locMax->iXMin = iX ;
                    locMax->iYMin = iY ;
                }
                
                pCohTrack->meanCoh += smoothedCohMat[iY][iX] ;
                if (iX == pCohTrack->iXMin || iX == pCohTrack->iXMax || iY == pCohTrack->iYMin || iY == pCohTrack->iYMax) {
                    backgroundCoh += smoothedCohMat[iY][iX] ;
                    nSteps2++ ;
                }
                
                /* Centroidization */
                if (smoothedCohMat[iY][iX] > centroidizationThreshold) {
                    locMax->xC += iX * smoothedCohMat[iY][iX] ;
                    locMax->yC += iY * smoothedCohMat[iY][iX] ;
                    weightCM += smoothedCohMat[iY][iX] ;
                    varCM += powf(smoothedCohMat[iY][iX], 2) ;
                    normCM++ ;
                }

                /* Trend calc */
                if (!iY) {
                    locMax->xTrend += iX * smoothedCohMat[iY][iX] ;
                }
                if (!iX) {
                    locMax->yTrend += iY * smoothedCohMat[iY][iX] ;
                }
            }
        }
    }
    
    pCohTrack->meanCoh /= nSteps ;
    backgroundCoh /= nSteps2 ;
    locMax->meanCoh = pCohTrack->meanCoh ;
    
    /* If tracking is simply based on max valuer, return */
    if (pCohTrack->flag & __MAX_LOC__) {
        return ;
    }
    
    /* If centroidization is requested compute row and column index from centroid location */
    if (pCohTrack->flag & __CENTROIDIZATION__) {
        if (normCM) {
            locMax->xC /= weightCM ;
            locMax->yC /= weightCM ;
            locMax->iXMax = (int)roundf(locMax->xC) ;
            locMax->iYMax = (int)roundf(locMax->yC) ;
            locMax->cohCMAvg = weightCM / normCM  ;
            locMax->sigmaCM = sqrtf(varCM / normCM -pow(locMax->cohCMAvg, 2)) ;
        }
        else {
            locMax->iXMax = locMax->iYMax = 0 ;
            locMax->xC = locMax->yC = 0 ;
            locMax->cohCMAvg = locMax->sigmaCM = 0 ;
            locMax->maxCoh = locMax->minCoh = 0 ;
        }
        
        /* If on border, which is highly unlikely, exclude the point */
        if (locMax->iXMax == pCohTrack->iXMin || locMax->iXMax == pCohTrack->iXMax || locMax->iYMax == pCohTrack->iYMin || locMax->iYMax == pCohTrack->iYMax) {
            locMax->iXMax = locMax->iYMax = 0 ;
            locMax->xC = locMax->yC = 0 ;
            locMax->cohCMAvg = 0 ;
        }
        
        return ;
    }
    
    
    /* compute per line percentile 1/3, average, min, max and slope */
    p33 = vectorFloat(pCohTrack->iXMin, pCohTrack->iXMax) ;
    p33X = pCohTrack->p33X ;
    p33Y = pCohTrack->p33Y ;
    iP = div(pCohTrack->nStepsX, 3) ;
    i33 = iP.quot + pCohTrack->iXMin ;
    iX0 = pCohTrack->iXMin ;
    maxSlope = maxRange = maxRangeMean = 0 ;
    for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
        if (ppInSAR[iY][iX0]) {
            /* Init index vector */
            xIndex = pCohTrack->xIndex[iY] ;
            for (i = iX0; i <= pCohTrack->iXMax; i++) {
                xIndex[i] = i ;
            }

            /* Copy and order line of smoothed coherence values */
            memcpy(p33 + iX0, smoothedCohMat[iY] + iX0, pCohTrack->nStepsX * __SIZEOF_FLOAT__) ;
            sortFloatVector(p33 + iX0, xIndex + iX0, pCohTrack->nStepsX, _ASCENDING_SORT_) ;

            /* Compute linear regression on ordered smoothed coherence values */
            Sx = Sxy = Sy = Sx2 = 0 ;
            Sx = (pCohTrack->iXMax * (pCohTrack->iXMax + 1) - pCohTrack->iXMax * (pCohTrack->iXMax - 1)) / 2 ;
            for (i = iX0; i <= pCohTrack->iXMax; i++) {
                Sxy += i * p33[i] ;
                Sy += p33[i] ;
                Sx2 += i * i ;
            }
            det = pCohTrack->nStepsX * Sx2 - Sx * Sx ;
            a = (pCohTrack->nStepsX * Sxy - Sx * Sy) / det ;
            a *= (pCohTrack->nStepsX - 1) ;
            b = (Sx2 * Sy -Sx * Sxy)/ det ;

            /* Percentile 1/3, average, min, max and slope extraction */
            p33X[iY] = p33[i33] + iP.rem / 3.0f * (p33[i33 + 1] - p33[i33]) ;
            pCohTrack->slopeX[iY] = a ;
            pCohTrack->meanCohX[iY] = b ;
            pCohTrack->maxCohX[iY] = p33[pCohTrack->iXMax] ;
            pCohTrack->minCohX[iY] = p33[-pCohTrack->iXMax] ;
            pCohTrack->rangeX[iY] = pCohTrack->maxCohX[iY] - backgroundCoh ;
            if (maxRangeMean < b * pCohTrack->rangeX[iY]) {
                maxRangeMean = b  * pCohTrack->rangeX[iY] ;
                maxRange = pCohTrack->rangeX[iY] ;
                locMax->iYMax = iY ;
            }
        }
    }
    freeVectorFloat(p33, pCohTrack->iXMin) ;

   
    /* Compute per column percentile 1/3, average, min, max and slope */
    p33 = vectorFloat(pCohTrack->iYMin, pCohTrack->iYMax) ;
    iP = div(pCohTrack->nStepsY, 3) ;
    i33 = iP.quot + pCohTrack->iYMin ;
    iY0 = pCohTrack->iYMin ;
    maxSlope = maxRange = maxRangeMean = 0 ;
    for (iX = pCohTrack->iXMin; iX <= pCohTrack->iXMax; iX++) {
        if (ppInSAR[iY0][iX]) {
            /* Copy and order column of smoothed coherence values */
            yIndex = pCohTrack->yIndex[iX] ;
            for (iY = pCohTrack->iYMin; iY <= pCohTrack->iYMax; iY++) {
                yIndex[iY] = iY ;
                p33[iY] = smoothedCohMat[iY][iX] ;
            }
            sortFloatVector(p33 + iY0, yIndex + iY0, pCohTrack->nStepsY, _ASCENDING_SORT_) ;

            /* Compute linear regression on ordered smoothed coherence values */
            Sx = Sxy = Sy = Sx2 = 0 ;
            Sx = (pCohTrack->iYMax * (pCohTrack->iYMax + 1) - pCohTrack->iYMax * (pCohTrack->iYMax - 1)) / 2 ;
            for (i = pCohTrack->iYMin; i <= pCohTrack->iYMax; i++) {
                Sxy += i * p33[i] ;
                Sy += p33[i] ;
                Sx2 += i * i ;
            }
            det = pCohTrack->nStepsY * Sx2 - Sx * Sx ;
            a = (pCohTrack->nStepsY * Sxy - Sx * Sy) / det ;
            a *= (pCohTrack->nStepsY - 1) ;
            b = (Sx2 * Sy -Sx * Sxy)/ det ;

            /* Percentile 1/3, average, min and max extraction */
            p33Y[iX] = p33[i33] + iP.rem / 3.0f * (p33[i33 + 1] - p33[i33]) ;
            pCohTrack->slopeY[iX] = a ;
            pCohTrack->meanCohY[iX] = b ;
            pCohTrack->maxCohY[iX] = p33[pCohTrack->iYMax] ;
            pCohTrack->minCohY[iX] = p33[-pCohTrack->iYMax] ;
            pCohTrack->rangeY[iX] = pCohTrack->maxCohY[iX] - backgroundCoh ;
            if (maxRangeMean < b * pCohTrack->rangeY[iX]) {
                maxRangeMean = b * pCohTrack->rangeY[iX] ;
                maxRange = pCohTrack->rangeY[iX] ;
                locMax->iXMax = iX ;
            }  
        }
    }   
    
    freeVectorFloat(p33, pCohTrack->iYMin) ;
}


void cohTrackHelp()
{
    printf("Usage:\n");
    printf("cohTrack [/pathTo/InSARParametersFile.txt] [-fcz] [ [dXMin : dXStep : dXMax] [ [dYMin : dYStep : dYMax] ] ] \n");
    printf("\ncohTrack performs successive slave image interpolations with requested shifts \nwith respect to computed coregistration transform. \n");
    printf("If not done, the reference interpolation is first conducted. \n");
    printf("It then compute stacked interferometric products to compute range and azimuth \nshifts leading to optimum coherence on a pixel-by-pixel basis.\n");
    printf("\ncohTrack is to be launched within an InSAR working directory \nor giving it the path to an InSAR parameter file.\n");
    printf("In which case, the cohTrack parameter file located in the same directory will be used.\n");
    printf("If cohTrackParameters.txt file does not exist a default one will be created \nand used with default parameters [-1 : 0.2 : -1] in both dimensions.\n");
    printf("\n");
    printf("Optional processing parameters can be given in the form [dXMin : dXStep : dXMax] (with brackets)\nto superseeds those founds in cohTrack paremeter file.\n");
    printf("If only one set of parameters is given, it will be used for both range and azimuth coregistration shifts\n") ;
    printf("If a set of parameters has a step of value 0, no shifts will be applied in the corresponding dimension. \n") ;
    printf("\n(col ; raw) location of coherence maximum is found if average value in that col (raw) is above given coherence threshold \n") ;
    printf("and if max value in that col (raw) minus background value is greater than the given visibility value.\n") ;
    printf("background value is computed as the average coherence on border values of the mapping.\n") ;
    printf("By default, fine shifts values are determined by simple quadratic interpolation using the two neighbour values of the found coherence value at col (raw) position.\n") ;
    printf("Fine position values are converted in meters. \n") ;
    printf("If an external DEM was available at reference InSAR processing time, an \"incidence\" file was created (InSARProductsGeneration -i).\n") ;
    printf("In which case, fine range shits values are projected on the local DEM slope\n\n") ;
    printf("Options are:\n") ;
    printf("--all: Force re-processing the whole stack from scratch.\n");
    printf("       Reference and shift interpolations will be reprocessed followed by sequential InSAR processing\n") ;
    printf("--InSAR: Re-process InSAR products on an existing stack of shifted slave images.\n") ;
    printf("--opt: Performs the coherence tracking on existing processing, avoiding to reprocess the whole interferometric stack.\n\n") ;
    printf("-c: Limit coherence tracking processing performing a cross mapping in place of a full mapping on defined interval.\n") ;
    printf("-s: Issue along range and along azimuth coherence and interferogram sequences.\n") ;
    printf("-W: Locate max coh by weighted average on surrounding values in place of finding it by quadratic interpolation.\n") ;
    printf("-C: Locate max coh by centroidization on the whole coherence mapping.\n") ;
    printf("-M: Locate max coh by simply selecting max coherence value.\n") ;
    printf("-P: Disable metric conversion to keep fine shifts in pixels. \n") ;

    exit(0);
}

/* Quadratic estimation of optimum coherence at optimom along X location */
float optCohX(cohTrackStruct *pCohTrack)
{
    int i1, iYMax ;
    float c1, c2, c3 ;
    float A, B, C ;
    float **smoothedCohMat ;
    cohMax *locMax ;

    smoothedCohMat = pCohTrack->smoothedCohMat ;
    locMax = pCohTrack->locMax ;
    iYMax = locMax->iYMax ;
    i1 = pCohTrack->xIndex[iYMax][pCohTrack->iXMax] ;
    
    c1 = smoothedCohMat[iYMax][i1] ;
    c2 = smoothedCohMat[iYMax][i1 - 1] ;
    c3 = smoothedCohMat[iYMax][i1 + 1] ;
    if (pCohTrack->flag & __WEIGHTED_AVG__) {
        locMax->fineXMax = i1 + (c3 - c2) / (c1 + c2 + c3);
        locMax->maxCohX = (c1 * c1 + c2 * c2 + c3 * c3) / (c1 + c2 + c3) ;
    }
    else {
        /* We make a quadratic fit through the three highest coherence values */
        A = (c2 + c3 - 2 * c1) / 2 ;
        B = (c3 - c2) / 2 ;
        C = c1 ;
        locMax->fineXMax = i1 - B / (2 * A) ;
        locMax->maxCohX = C - B * B / (4 * A) ;
    }

    locMax->maxCohX = (locMax->maxCohX < 0 || locMax->maxCohX > 1)? c1 : locMax->maxCohX ;

    return (locMax->maxCohX) ;
}

/* Quadratic estimation of optimum coherence at optimom along Y location */
float optCohY(cohTrackStruct *pCohTrack)
{
    int i1, iXMax ;
    float c1, c2, c3 ;
    float A, B, C ;
    float **smoothedCohMat ;
    cohMax *locMax ;

    smoothedCohMat = pCohTrack->smoothedCohMat ;
    locMax = pCohTrack->locMax ;
    iXMax = locMax->iXMax ;
    i1 = pCohTrack->yIndex[iXMax][pCohTrack->iYMax] ;
    c1 = smoothedCohMat[i1][iXMax] ;
    c2 = smoothedCohMat[i1 - 1][iXMax] ;
    c3 = smoothedCohMat[i1 + 1][iXMax] ;
    if (pCohTrack->flag & __WEIGHTED_AVG__) {
        locMax->fineYMax = i1 + (c3 - c2) / (c1 + c2 + c3);
        locMax->maxCohY = (c1 * c1 + c2 * c2 + c3 * c3) / (c1 + c2 + c3) ;
    }
    else {
        A = (c2 + c3 - 2 * c1) / 2 ;
        B = (c3 - c2) / 2 ;
        C = c1 ;
        locMax->fineYMax = i1 - B / (2 * A) ;
        locMax->maxCohY = C - B * B / (4 * A) ;
    }
    locMax->maxCohY = (locMax->maxCohY < 0 || locMax->maxCohY > 1)? c1 : locMax->maxCohY ;

    return (locMax->maxCohY) ;
}


/* Quadratic estimation of optimum phase at optimum along X location */
float optXPhaseCalc(cohTrackStruct *pCohTrack)
{
    int i1, iYMax ;
    float c1, c2, c3 ;
    float s1, s2, s3 ;
    float A, B, C ;
    float x ;
    complexFloat complexPhase ;
    cohMax *locMax ;

    locMax = pCohTrack->locMax ;
    x = locMax->fineXMax ;
    iYMax = locMax->iYMax ;

    i1 = pCohTrack->xIndex[iYMax][pCohTrack->iXMax] ;

    c1 = cosf(pCohTrack->interfMat[iYMax][i1]) ;
    c2 = cosf(pCohTrack->interfMat[iYMax][i1 - 1]) ;
    c3 = cosf(pCohTrack->interfMat[iYMax][i1 + 1]) ;
    A = (c2 + c3 - 2 * c1) / 2 ;
    B = (c3 - c2) / 2 ;
    C = c1 ;
    complexPhase.r = A * x * x + B * x + C ;

    s1 = sinf(pCohTrack->interfMat[iYMax][i1]) ;
    s2 = sinf(pCohTrack->interfMat[iYMax][i1 - 1]) ;
    s3 = sinf(pCohTrack->interfMat[iYMax][i1 + 1]) ;
    A = (s2 + s3 - 2 * s1) / 2 ;
    B = (s3 - s2) / 2 ;
    C = s1 ;
    complexPhase.i = A * x * x + B * x + C ;

    locMax->optPhaseX = phi(&complexPhase) ;

    if (pCohTrack->interfDiffMat) {
        c1 = cosf(pCohTrack->interfDiffMat[iYMax][i1]) ;
        c2 = cosf(pCohTrack->interfDiffMat[iYMax][i1 - 1]) ;
        c3 = cosf(pCohTrack->interfDiffMat[iYMax][i1 + 1]) ;
        A = (c2 + c3 - 2 * c1) / 2 ;
        B = (c3 - c2) / 2 ;
        C = c1 ;
        complexPhase.r = A * x * x + B * x + C ;
    
        s1 = sinf(pCohTrack->interfDiffMat[iYMax][i1]) ;
        s2 = sinf(pCohTrack->interfDiffMat[iYMax][i1 - 1]) ;
        s3 = sinf(pCohTrack->interfDiffMat[iYMax][i1 + 1]) ;
        A = (s2 + s3 - 2 * s1) / 2 ;
        B = (s3 - s2) / 2 ;
        C = s1 ;
        complexPhase.i = A * x * x + B * x + C ;

        locMax->optDiffPhaseX = phi(&complexPhase) ;
    }

    return(locMax->optPhaseX) ;
}

/* Quadratic estimation of optimum phase at optimum along Y location */
float optYPhaseCalc(cohTrackStruct *pCohTrack)
{
    int i1, iXMax ;
    float c1, c2, c3 ;
    float s1, s2, s3 ;
    float A, B, C ;
    float x ;
    complexFloat complexPhase ;
    cohMax *locMax ;

    locMax = pCohTrack->locMax ;
    x = locMax->fineYMax ;
    iXMax = locMax->iXMax ;
    i1 = pCohTrack->yIndex[iXMax][pCohTrack->iYMax] ;

    c1 = cosf(pCohTrack->interfMat[i1][iXMax]) ;
    c2 = cosf(pCohTrack->interfMat[i1 - 1][iXMax]) ;
    c3 = cosf(pCohTrack->interfMat[i1 + 1][iXMax]) ;
    A = (c2 + c3 - 2 * c1) / 2 ;
    B = (c3 - c2) / 2 ;
    C = c1 ;
    complexPhase.r = A * x * x + B * x + C ;

    s1 = sinf(pCohTrack->interfMat[i1][iXMax]) ;
    s2 = sinf(pCohTrack->interfMat[i1 - 1][iXMax]) ;
    s3 = sinf(pCohTrack->interfMat[i1 + 1][iXMax]) ;
    A = (s2 + s3 - 2 * s1) / 2 ;
    B = (s3 - s2) / 2 ;
    C = s1 ;
    complexPhase.i = A * x * x + B * x + C ;

    locMax->optPhaseY = phi(&complexPhase) ;

    if (pCohTrack->interfDiffMat) {
        c1 = cosf(pCohTrack->interfDiffMat[i1][iXMax]) ;
        c2 = cosf(pCohTrack->interfDiffMat[i1 - 1][iXMax]) ;
        c3 = cosf(pCohTrack->interfDiffMat[i1 + 1][iXMax]) ;
        A = (c2 + c3 - 2 * c1) / 2 ;
        B = (c3 - c2) / 2 ;
        C = c1 ;
        complexPhase.r = A * x * x + B * x + C ;

        s1 = sinf(pCohTrack->interfDiffMat[i1][iXMax]) ;
        s2 = sinf(pCohTrack->interfDiffMat[i1 - 1][iXMax]) ;
        s3 = sinf(pCohTrack->interfDiffMat[i1 + 1][iXMax]) ;
        A = (s2 + s3 - 2 * s1) / 2 ;
        B = (s3 - s2) / 2 ;
        C = s1 ;
        complexPhase.i = A * x * x + B * x + C ;

        locMax->optDiffPhaseY = phi(&complexPhase) ;
    }

    return(locMax->optPhaseY) ;
}