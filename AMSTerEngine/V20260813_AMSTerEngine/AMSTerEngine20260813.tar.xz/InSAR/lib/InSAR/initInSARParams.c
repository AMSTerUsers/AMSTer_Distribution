
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  initInSARParams.c
 *  initInSARParams
 *
 *  Created by Dominique Derauw on 20/10/11.
 *  Copyright 2011 Dominique Derauw All rights reserved.
 *
 */


#include "initInSARParams.h"

/* Init all required structures for geolocalization */
/* Computes baseline and if requested, computes  common superposition of images */
InSARParametersStruct *initInSAR_GEO(InSARParametersStruct *pInSAR, int keepOrComputeAoI)
{
	if (pInSAR->geo) {
        freeGeoRef(pInSAR->geo) ;
    }
    
    pInSAR->geo = allocAndInitGeorefStructureForTargetEllipsoid(pInSAR->masterInfo, pInSAR->masterInfo->ellRef) ;
	orbitInterpolation(pInSAR->masterInfo) ;
	orbitInterpolation(pInSAR->slaveInfo) ;
//	approxRt(pInSAR->masterInfo) ;
    geolocateSceneOnEllipsoid(pInSAR->masterInfo, pInSAR->masterInfo->ellRef) ;
    geolocateSceneOnEllipsoid(pInSAR->slaveInfo, pInSAR->slaveInfo->ellRef) ;

	computeEarthCentreToSensorDistance(pInSAR) ;
	computeBaseLine(pInSAR) ;
	computeTemporalBaseline(pInSAR) ;
    if (keepOrComputeAoI == _COMPUTEAOI_) {
        computeCommonSuperpositionOfImages(pInSAR) ;
    }
    

	return(pInSAR) ;
}

void computeEarthCentreToSensorDistance(InSARParametersStruct *pInSAR)
{
	int	i, N ;
	double Sx, Sx2, Sxy, Sy, EarthCentreToSensorDistance, azimuthPosition, det ;
	struct stateVect *stateVector ;

	/* Earth centre to sensor distance */
	stateVector = allocStateVector() ;

	orbitInterpolation(pInSAR->masterInfo) ;
	Sx2 = Sx = Sxy = Sy = 0. ;
	N = 10 ;
	for(i = 0 ; i < N ; i++)
	{
		azimuthPosition = (double)(i * (pInSAR->ima1).lena) / (double)(N - 1) ;
		calcStateVect(stateVector, azimuthPosition, pInSAR->masterInfo) ;
		EarthCentreToSensorDistance = sqrt(scalarProduct(stateVector->P, stateVector->P)) ;
		Sy += EarthCentreToSensorDistance ;
		Sxy += azimuthPosition * EarthCentreToSensorDistance ;
		Sx += azimuthPosition ;
		Sx2 += pow(azimuthPosition, 2.) ;
	}
	det = 1/(N*Sx2 - Sx*Sx) ;
	pInSAR->S1.aS = det*(N*Sxy - Sx*Sy) ;
	pInSAR->S1.bS = det*(Sx2*Sy - Sx*Sxy) ;

	freeStateVector(stateVector) ;
}

void computeBaseLine(InSARParametersStruct *pInSAR)
{
    char orbitsNearlyParallels ;
    int i, j, k, N, *index ;
    double *llh, *sol, *xy, H ;
    double *cBh, *cBv, *baselineVector, Bh, Bv ;
    double *rangeTransform, *azimuthTransform ;
    double *normalVector, *horizontalVector, *aVector ;
    double **M, sign ;
    double range, azimuth, deltaRange, deltaAzimuth ;
    double azimuthMin, azimuthMax, rangeMin, rangeMax ;
    coord2D *effectivePosition ;
    geoRef *geoRefMaster, *geoRefSlave ;
    satRef *satRefMaster, *satRefSlave ;
    gridMap *slantRangeDEMGrid = NULL ;

    /* Initialize back and forth referencing for master image */
    orbitInterpolation(pInSAR->masterInfo) ;
    geoRefMaster = allocAndInitGeorefStructureForTargetEllipsoid(pInSAR->masterInfo, pInSAR->masterInfo->ellRef) ;
    satRefMaster = allocAndInitSatRefWithGeoRefStructure(geoRefMaster) ;

    /* Initialize back and forth referencing for slave image with the same ellipsoid */
    orbitInterpolation(pInSAR->slaveInfo) ;
    geoRefSlave = allocAndInitGeorefStructureForTargetEllipsoid(pInSAR->slaveInfo, pInSAR->masterInfo->ellRef) ;
    satRefSlave = allocAndInitSatRefWithGeoRefStructure(geoRefSlave) ;

    cBh = vectorDouble(1, 3) ;					/* We allocate vectors for the baseline coefficients to be computed */
    cBv = vectorDouble(1, 3) ;
    baselineVector = vectorDouble(0, 2) ;		/* As also for the baseline vector itself */
    llh = vectorDouble(0, 2) ;					/* This is a Lon-Lat-H vector */
    sol = vectorDouble(0, 2) ;					/* This vector will contain the xyz position of a point projected on the given ellipsoid */
    normalVector = vectorDouble(0, 2) ;			/* This vector is the normal to the local horizontal */
    horizontalVector = vectorDouble(0, 2) ;		/* And this is a vector in the local horizontal plane */
    aVector = vectorDouble(0, 2) ;				/* This is a temporary vector used for intermediate computation */
    xy = vectorDouble(0, 1) ;					/* This is a 2D vector for rang-azimuth localization of a point */
    rangeTransform = vectorDouble(1, 3) ;		/* We will compute an approximate transform from slave to master image at the same time */
    azimuthTransform = vectorDouble(1, 3) ;
    effectivePosition = allocPoint() ;          /* We allocate a point to compute effective range-azimuth coordinates taking into account master transform, if applicable */

    /* Image frame range on which is calculate the baseline */
    azimuthMin = pInSAR->aoi->P[0].y ;
    azimuthMax = pInSAR->aoi->P[2].y ;
    rangeMin = pInSAR->aoi->P[0].x ;
    rangeMax = pInSAR->aoi->P[2].x ;

    /* Allocation of a matrix to solve the system */
    M = matrixDouble(1, 3, 1, 3) ;
    index = vectorInt(1, 3) ;

    /* Initialization */
    for(i = 1; i <= 3; i++) {
        cBh[i] = cBv[i] = 0. ;
        for(j = 1; j <= 3; j++)
            M[i][j] = 0. ;
    }

    /* Manage external DEM if present */
    if (isFilePresentInCSLImage(pInSAR->masterImage, "externalSlantRangeDEM.txt")) {
        if ((slantRangeDEMGrid = allocAndInitExternalFileGridForImage(pInSAR->masterImage, "externalSlantRangeDEM")) == NULL) {
            ase("No external slant range DEM available while a DEM description text file is present\n Strange...\n. Please run slantRangeDEM first\n") ;
        }
    }


    /* The image frame is sampled on a 15x15 network */
    /* For each point of this net in the master image, the corresponding coordinate in the slave image will be computed */
    /* For the corresponding azimuth in both master and slave, the state vector difference will give a baseline vector */
    /* Baseline affine approximation will be obtained by mean square calculation */
    N = 100 ;
    orbitsNearlyParallels = (pInSAR->flag & _NON_PARALLEL_ORBITS_)? 0 : 1 ;
    deltaAzimuth = (azimuthMax - azimuthMin)/(N - 1) ;
    deltaRange = (rangeMax - rangeMin)/(N - 1) ;
    H = geoRefMaster->params->info->sceneAverageHeight ;

    /* Baseline computation */
    /* Baseline is found intersecting the master doppler plane with the slave orbit */
    for(i = 0; i < N; i++) {															/* Loop on azimuth coordinate */
        azimuth = azimuthMin + i * deltaAzimuth ;                                       /* Azimuth coordinate of the considered point of the network */
        for(j = 0; j < N; j++) {                                                        /* Loop on range Coordinate */
            range = rangeMin + j * deltaRange ;
/*
            effectivePosition->y = azimuth ;
            effectivePosition->x = range ;
            computeEffectiveRangeAzimuthCoordinatesOfPoint(effectivePosition, pInSAR);
            range = effectivePosition->x ;
            azimuth = effectivePosition->y ;
*/
            calcStateVect(satRefMaster->solving->S, azimuth, satRefMaster->params->info) ;    /* Calculation of the corresponding state vector */
            initOnSphereSolving(satRefMaster->solving) ;                                      /* georeferencing initialization for this azimuth position*/

            for(k = 0; k < 3; k++)                                                            /* We compute the normal vector to the local horizontal plane */
                normalVector[k] = satRefMaster->solving->S->P[k] ;
            normalizeVector(normalVector) ;

            if (slantRangeDEMGrid) {
                H = interpolFloatGridForImageCoordinate(slantRangeDEMGrid, range, azimuth) ;
                if (areFloatValsEquals(H, slantRangeDEMGrid->noVal)) {
                    H = pInSAR->masterInfo->sceneAverageHeight ;
                }
            }
            geoRefMaster->solving->Rt = earthRadiusAtPoint(range, azimuth, H, geoRefMaster) ; /* We compute the local Earth radius and locate the point on the master reference ellipsoid */

            /* The following is done within function earthRadiusAtPoint: */
//            xyz = onSphereSolvingForPoint(range, azimuth, geoRefMaster->params->info->sceneAverageHeight, geoRefMaster)  ;
//            onEllipsoidProjection(sol, xyz, geoRefMaster->solving) ;					/* We locate the point in the master image on the master reference ellipsoid */
//            XYZ2LonLatH(xyz, llh, geoRefMaster->solving) ;							/* We compute the corresponding longitude and latitude */

            XYZ2LonLatH(geoRefMaster->solving->Pg, llh, geoRefMaster->solving) ;		/* We compute the corresponding longitude and latitude */
            llh[2] = H ;

            /* We initialize local height with local height or average height of the scene */
            /* We reference this point in the slave image and included in the Doppler plane of the master */
            /* This is correct for baseline computation */
            if (orbitsNearlyParallels) {
                rangeAzimuthReferencingOfpointUsingDopplerPlane(llh, xy, satRefSlave, satRefMaster->solving->eq1) ;
            }
            else
                rangeAzimuthReferencingOfpoint(llh, xy, satRefSlave) ;
/*
            if(!(xy[0] * xy[1])) {
                orbitsNearlyParallels = 0 ;
                rangeAzimuthReferencingOfpoint(llh, xy, satRefSlave) ;
            }
*/
            if(xy[0] && xy[1]) {
                calcStateVect(satRefSlave->solving->S, xy[1], satRefSlave->params->info) ;	/* Calculation of the  state vector corresponding to found azimuth position */
                vectorDiff(baselineVector, satRefSlave->solving->S->P, satRefMaster->solving->S->P) ; /* This is the baseline vector */

                Bv = scalarProduct(baselineVector, normalVector) ;                              /* The scalar product of the baseline vector with the normal to the horizontal plane is the vertical baseline component */

                vectorialProduct(horizontalVector, satRefMaster->solving->eq1, normalVector) ;  /* We compute a local horizontal vector, coplanar with the baseline vector */
                normalizeVector(horizontalVector) ;
                Bh = scalarProduct(baselineVector, horizontalVector) ;
                sign = (Bh > 0)? 1. : -1. ;

                for(k = 0; k < 3; k++)															/* We compute the vectorial vertical component of the baseline */
                    aVector[k] = normalVector[k] * Bv ;
                vectorDiff(horizontalVector, baselineVector, aVector) ;                         /* We compute the vectorial horizontal component of the baseline */
                Bh = sign * vectorNorm(horizontalVector) ;

                M[1][1] += range * range ;
                M[1][2] += azimuth * range ;
                M[1][3] += range ;
                M[2][2] += azimuth * azimuth ;
                M[2][3] += azimuth ;
                M[3][3] ++ ;

                cBh[1] += range * Bh ;
                cBh[2] += azimuth * Bh ;
                cBh[3] += Bh ;
                cBv[1] += range * Bv ;
                cBv[2] += azimuth * Bv ;
                cBv[3] += Bv ;
            }
        }
    }
    M[2][1] = M[1][2] ;
    M[3][1] = M[1][3] ;
    M[3][2] = M[2][3] ;

    /* Matrix inversion and coefficients computation */
    ludcmp(M, 3, index, &sign) ;
    lubksb(M, 3, index, cBh) ;
    lubksb(M, 3, index, cBv) ;

    /* Baseline horizontal and vertical coefficients */
    for(i = 0; i < 3; i++) {
        pInSAR->B.T[0][i] = cBh[i + 1] ;
        pInSAR->B.T[1][i] = cBv[i + 1] ;
    }



    /* Transform computation */
    /* This one id found intersecting the slave doppler plane with the slave orbit */
    /* Initialization */
    for(i = 1; i <= 3; i++) {
        cBh[i] = cBv[i] = 0. ;
        for(j = 1; j <= 3; j++)
            M[i][j] = 0. ;
    }

    for(i = 0; i < N; i++) {															/* Loop on azimuth coordinate */
        azimuth = azimuthMin + i * deltaAzimuth ;										/* Azimuth coordinate of the considered point of the network */
        for(j = 0; j < N; j++) {														/* Loop on range Coordinate */
            range = rangeMin + j * deltaRange ;
/*
            effectivePosition->y = azimuth ;
            effectivePosition->x = range ;
            computeEffectiveRangeAzimuthCoordinatesOfPoint(effectivePosition, pInSAR);
            range = effectivePosition->x ;
            azimuth = effectivePosition->y ;
*/
            calcStateVect(satRefMaster->solving->S, azimuth, satRefMaster->params->info) ;    /* Calculation of the corresponding state vector */
            initOnSphereSolving(satRefMaster->solving) ;                                      /* georeferencing initialization for this azimuth position*/

            for(k = 0; k < 3; k++)                                                            /* We compute the normal vector to the local horizontal plane */
                normalVector[k] = satRefMaster->solving->S->P[k] ;
            normalizeVector(normalVector) ;


            if (slantRangeDEMGrid) {
                H = interpolFloatGridForImageCoordinate(slantRangeDEMGrid, range, azimuth) ;
                if (areFloatValsEquals(H, slantRangeDEMGrid->noVal)) {
                    H = pInSAR->masterInfo->sceneAverageHeight ;
                }
            }
            geoRefMaster->solving->Rt = earthRadiusAtPoint(range, azimuth, H, geoRefMaster) ;   /* We compute the local Earth radius and locate the point on the master reference ellipsoid */
            XYZ2LonLatH(geoRefMaster->solving->Pg, llh, geoRefMaster->solving) ;		        /* We compute the corresponding longitude and latitude */
            llh[2] = H ;

            rangeAzimuthReferencingOfpoint(llh, xy, satRefSlave) ;

            if(xy[0] && xy[1]) {
                M[1][1] += range * range ;
                M[1][2] += azimuth * range ;
                M[1][3] += range ;
                M[2][2] += azimuth * azimuth ;
                M[2][3] += azimuth ;
                M[3][3] ++ ;

                rangeTransform[1] += range * xy[0] ;
                rangeTransform[2] += azimuth * xy[0] ;
                rangeTransform[3] += xy[0] ;
                azimuthTransform[1] += range * xy[1] ;
                azimuthTransform[2] += azimuth * xy[1] ;
                azimuthTransform[3] += xy[1] ;
            }
        }
    }
    M[2][1] = M[1][2] ;
    M[3][1] = M[1][3] ;
    M[3][2] = M[2][3] ;

    /* Matrix inversion and coefficients computation */
    ludcmp(M, 3, index, &sign) ;
    lubksb(M, 3, index, rangeTransform) ;
    lubksb(M, 3, index, azimuthTransform) ;

    /* Compute Bperp and Bpara at image centre */
    effectivePosition->y = (double)(azimuthMax + azimuthMin) / 2. ;
    effectivePosition->x = (double)(rangeMax + rangeMin) / 2. ;
//    computeEffectiveRangeAzimuthCoordinatesOfPoint(effectivePosition, pInSAR);
    updateOrbitalParametersForPoint(effectivePosition->x, effectivePosition->y, pInSAR) ;
    earthRadiusAtPoint(effectivePosition->x, effectivePosition->y, 0., pInSAR->geo) ;
    pInSAR->B.Bperp = pInSAR->B.B * cos(pInSAR->B.theta - pInSAR->geo->solving->alpha_at) ;
    pInSAR->B.Bpara = pInSAR->B.B * sin(pInSAR->B.theta - pInSAR->geo->solving->alpha_at) ;


    /* Affine transform coefficients */
    for(i = 0; i < 3; i++) {
        pInSAR->slaveAffineTransform[0][i] = rangeTransform[i + 1] ;
        pInSAR->slaveAffineTransform[1][i] = azimuthTransform[i + 1] ;
    }
    inversePlaneAffineTransform(pInSAR->slaveAffineTransform, pInSAR->inverseSlaveAffineTransform) ;

    range = rangeMin + N/2 * deltaRange ;
    azimuth = azimuthMin + N/2 * deltaAzimuth ;
    pInSAR->ambiguityAltitude = ambiguityAltitudeAtPoint(range, azimuth, pInSAR->masterInfo->sceneAverageHeight, pInSAR) ;

    freeVectorDouble(xy, 0) ;
    freeMatrixDouble(M, 1, 1) ;
    freeVectorInt(index, 1) ;
    freeSatRef(satRefMaster) ;
    freeSatRef(satRefSlave) ;
    freeVectorDouble(cBh, 1) ;
    freeVectorDouble(cBv, 1) ;
    freeVectorDouble(baselineVector, 0) ;
    freeVectorDouble(llh, 0) ;
    freeVectorDouble(sol, 0) ;
    freeVectorDouble(normalVector, 0) ;
    freeVectorDouble(horizontalVector, 0) ;
    freeVectorDouble(aVector, 0) ;
    freeVectorDouble(rangeTransform, 1) ;
    freeVectorDouble(azimuthTransform, 1) ;
    if (slantRangeDEMGrid) {
        freeGridMap(slantRangeDEMGrid) ;
    }
    free(effectivePosition) ;
}

void computeTemporalBaseline(InSARParametersStruct *pInSAR)
{
    /* Compute temporal baseline */
    genAcquisitionTimeFromDate(pInSAR->masterInfo) ;
    genAcquisitionTimeFromDate(pInSAR->slaveInfo) ;
    pInSAR->B.deltaDays = (int)round(difftime(pInSAR->slaveInfo->acquisitionTime, pInSAR->masterInfo->acquisitionTime) / 86400) ;
/*
    if (fabs(pInSAR->B.deltaDays) > 1000) {
        printf("Delta T quite big...\tBt = %d\n", pInSAR->B.deltaDays) ;
        printf("Master acquisition date = %s\n", pInSAR->masterInfo->acquisitionDate) ;
        printf("Master acquisition time info (YY - MM -DD): %2d - %2d - %2d\n", pInSAR->masterInfo->acquisitionTime_tm->tm_year, pInSAR->masterInfo->acquisitionTime_tm->tm_mon, pInSAR->masterInfo->acquisitionTime_tm->tm_mday) ;
        printf("Slave acquisition date = %s\n", pInSAR->slaveInfo->acquisitionDate) ;
        printf("Slave acquisition time info (YY - MM -DD): %2d - %2d - %2d\n", pInSAR->slaveInfo->acquisitionTime_tm->tm_year, pInSAR->slaveInfo->acquisitionTime_tm->tm_mon, pInSAR->slaveInfo->acquisitionTime_tm->tm_mday) ;
    }
*/
}


void computeBaseLineFromAffineTransform(InSARParametersStruct *pInSAR)
{
    int i, j, k, N, *index ;
    double *cBh, *cBv, *baselineVector, Bh, Bv ;
    double ** baselineTransform ;
    double *rangeTransform, *azimuthTransform ;
    double *normalVector, *horizontalVector, *aVector ;
    double **M, sign ;
    double masterRange, masterAzimuth, deltaRange, deltaAzimuth ;
    double azimuthMin, azimuthMax, rangeMin, rangeMax ;
    coord2D master, slave ;
    struct stateVect *masterStateVector, *slaveStateVector ;

    cBh = vectorDouble(1, 3) ;					/* We allocate vectors for the baseline coefficients to be computed */
    cBv = vectorDouble(1, 3) ;
    baselineVector = vectorDouble(0, 2) ;		/* As also for the baseline vector itself */
    normalVector = vectorDouble(0, 2) ;			/* This vector is the normal to the local horizontal */
    horizontalVector = vectorDouble(0, 2) ;		/* And this is a vector in the local horizontal plane */
    aVector = vectorDouble(0, 2) ;				/* This is a temporaty vector used for intermediate computation */
    rangeTransform = vectorDouble(1, 3) ;		/* We will compute an approximate transfrom from slave to master image at the same time */
    azimuthTransform = vectorDouble(1, 3) ;
    masterStateVector = allocStateVector() ;
    slaveStateVector = allocStateVector() ;
    baselineTransform = matrixDouble(0, 1, 0, 2) ;

    orbitInterpolation(pInSAR->masterInfo) ;
    orbitInterpolation(pInSAR->slaveInfo) ;

    /* Image frame range on which is calculate the baseline */
    azimuthMin = 0. ;
    azimuthMax = (double)pInSAR->masterInfo->azimuthDimension - 1 ;
    rangeMin = 0. ;
    rangeMax = (double)pInSAR->masterInfo->rangeDimension - 1. ;
    /* Allocation of a matrix to solve the system */
    M = matrixDouble(1, 3, 1, 3) ;
    index = vectorInt(1, 3) ;

    /* Initialization */
    for(i = 1; i <= 3; i++) {
        cBh[i] = cBv[i] = 0. ;
        for(j = 1; j <= 3; j++)
            M[i][j] = 0. ;
    }

    /* The image frame is sampled on a 5x5 network */
    /* For each point of this net in the master image, the corresponding coordinate in the slave image will be computed */
    /* For the corresponding azimuth in both master and slave, the state vector difference will give a baseline vector */
    /* Baseline affine approximation will be obtained by mean square calculation */
    N = 100 ;
    deltaAzimuth = (azimuthMax - azimuthMin)/(N - 1) ;
    deltaRange = (rangeMax - rangeMin)/(N - 1) ;
    for(i = 0; i < N; i++) {															/* Loop on azimuth coordinate */
        master.y = masterAzimuth = azimuthMin + i * deltaAzimuth ;													/* Azimuth coordinate of the considered point of the network */
        calcStateVect(masterStateVector, masterAzimuth, pInSAR->masterInfo) ;	/* Calculation of the corresponding state vector */

        for(k = 0; k < 3; k++)															/* We compute the normal vector to the local horizontal plane */
            normalVector[k] = masterStateVector->P[k] ;
        normalizeVector(normalVector) ;

        for(j = 0; j < N; j++) {														/* Loop on range Coordinate */
            master.x = masterRange = rangeMin + j * deltaRange ;

            planeAffineTransformOfCoord2D(&master, &slave, pInSAR->slaveAffineTransform) ;

            calcStateVect(slaveStateVector, slave.y, pInSAR->slaveInfo) ;	/* Calculation of the  state vector corresponding to found azimuth position */
            vectorDiff(baselineVector, slaveStateVector->P, masterStateVector->P) ; /* This is the baseline vector */

            Bv = scalarProduct(baselineVector, normalVector) ;                              /* The scalar product of the baseline vector with the normal to the horizontal plane is the vertical baseline component */

            vectorialProduct(horizontalVector, masterStateVector->V, normalVector) ;  /* We compute a local horizontal vector, coplanar with the baseline vector */
            normalizeVector(horizontalVector) ;
            Bh = scalarProduct(baselineVector, horizontalVector) ;
            sign = (Bh > 0)? 1. : -1. ;

            for(k = 0; k < 3; k++)															/* We compute the vectorial vertical component of the baseline */
                aVector[k] = normalVector[k] * Bv ;
            vectorDiff(horizontalVector, baselineVector, aVector) ;                         /* We compute the vectorial horizontal component of the baseline */
            Bh = sign * vectorNorm(horizontalVector) ;

            M[1][1] += masterRange * masterRange ;
            M[1][2] += masterAzimuth * masterRange ;
            M[1][3] += masterRange ;
            M[2][2] += masterAzimuth * masterAzimuth ;
            M[2][3] += masterAzimuth ;
            M[3][3] ++ ;

            cBh[1] += masterRange * Bh ;
            cBh[2] += masterAzimuth * Bh ;
            cBh[3] += Bh ;
            cBv[1] += masterRange * Bv ;
            cBv[2] += masterAzimuth * Bv ;
            cBv[3] += Bv ;
            rangeTransform[1] += masterRange * slave.x ;
            rangeTransform[2] += masterAzimuth * slave.x ;
            rangeTransform[3] += slave.x ;
            azimuthTransform[1] += masterRange * slave.y ;
            azimuthTransform[2] += masterAzimuth * slave.y ;
            azimuthTransform[3] += slave.y ;
        }
    }
    M[2][1] = M[1][2] ;
    M[3][1] = M[1][3] ;
    M[3][2] = M[2][3] ;

    /* Matrix inversion and coefficients computation */
    ludcmp(M, 3, index, &sign) ;
    lubksb(M, 3, index, cBh) ;
    lubksb(M, 3, index, cBv) ;
    lubksb(M, 3, index, rangeTransform) ;
    lubksb(M, 3, index, azimuthTransform) ;

    /* Copy current baseline transform */
    memcpy(baselineTransform[0], pInSAR->B.T[0], 6 * sizeof(double)) ;

    /* Transfer estimated baseline transform */
    memcpy(pInSAR->B.T[0], cBh + 1, 3 * sizeof(double)) ;
    memcpy(pInSAR->B.T[1], cBv + 1, 3 * sizeof(double)) ;

    /* Display estimated baseline */
    masterRange = rangeMin + N/2 * deltaRange ;
    masterAzimuth = azimuthMin + N/2 * deltaAzimuth ;

    Bv = ambiguityAltitudeAtPoint(masterRange, masterAzimuth, pInSAR->masterInfo->sceneAverageHeight, pInSAR) ;
    printf("\n\nBaseline computed from coregistration results: \n") ;
    printf("Bx = %.16g + %.16g X + %.16g Y\n", cBh[3], cBh[1], cBh[2]) ;
    printf("By = %.16g + %.16g X + %.16g Y\n", cBv[3], cBv[1], cBv[2]) ;
    printf("Ambiguity altitude = %g\n", Bv) ;

    /* Restore baseline transform */
    memcpy(pInSAR->B.T[0], baselineTransform[0], 6 * sizeof(double)) ;


    freeVectorDouble(cBh, 1) ;
    freeVectorDouble(cBv, 1) ;
    freeVectorDouble(baselineVector, 0) ;
    freeVectorDouble(normalVector, 0) ;
    freeVectorDouble(horizontalVector, 0) ;
    freeVectorDouble(aVector, 0) ;
    freeVectorDouble(rangeTransform, 1) ;
    freeVectorDouble(azimuthTransform, 1) ;
    freeStateVector(masterStateVector) ;
    freeStateVector(slaveStateVector) ;
    freeMatrixDouble(baselineTransform, 0, 0) ;
}

void computeCommonSuperpositionOfImages(InSARParametersStruct *pInSAR)
{
    int i, xMin, yMin, xMax, yMax ;
    double *H ;
    polygon *slaveAoI = NULL ;
    polygon *kmlAoI ;
    polygon *rectangularAoI ;

    /* First, we compute max superposition area taking into account master to slave transfrom */
    xMin = yMin = 0 ;
    xMax = MIN(pInSAR->masterInfo->rangeDimension , pInSAR->slaveInfo->rangeDimension) - 1 ;
    yMax = MIN(pInSAR->masterInfo->azimuthDimension, pInSAR->slaveInfo->azimuthDimension) - 1 ;
    
    slaveAoI = allocQuadrilateral() ;
    slaveAoI->P[0].x = slaveAoI->P[0].y = slaveAoI->P[3].x = slaveAoI->P[1].y = 0. ;
    slaveAoI->P[1].x = slaveAoI->P[2].x = pInSAR->slaveInfo->rangeDimension - 1 ;
    slaveAoI->P[2].y = slaveAoI->P[3].y = pInSAR->slaveInfo->azimuthDimension - 1 ;
    planeAffineTransformOfPolygon(slaveAoI, pInSAR->aoi, pInSAR->inverseSlaveAffineTransform) ;

    (pInSAR->sup).Sgra = pInSAR->aoi->P[0].x = pInSAR->aoi->P[3].x = (pInSAR->aoi->P[0].x > xMin)? (int)ceil(pInSAR->aoi->P[0].x) : xMin ;
    (pInSAR->sup).Sbaz = pInSAR->aoi->P[0].y = pInSAR->aoi->P[1].y = (pInSAR->aoi->P[0].y > yMin)? (int)ceil(pInSAR->aoi->P[0].y) : yMin ;
    (pInSAR->sup).Sdra = pInSAR->aoi->P[1].x = pInSAR->aoi->P[2].x = (pInSAR->aoi->P[2].x < xMax)? (int)floor(pInSAR->aoi->P[2].x) : xMax ;
    (pInSAR->sup).Shaz = pInSAR->aoi->P[2].y = pInSAR->aoi->P[3].y = (pInSAR->aoi->P[2].y < yMax)? (int)floor(pInSAR->aoi->P[2].y) : yMax ;
    
    /* If a kml is provided, we read and convert it in slant range coordinates. */
    /* Then, we limit it to fit within maximal superposition area */
    if ((kmlAoI = getPolygonalAoIFromKMLFile(pInSAR->aoiKml))) {
        if (pInSAR->externalReferenceDEM) {
            H = getLocalHeightsOfAoISummits(pInSAR->aoiKml, pInSAR->externalReferenceDEM, pInSAR->masterInfo->sceneAverageHeight) ;
        }
        else {
            H = vectorDouble(0, pInSAR->aoi->N - 1) ;
            for (i = 0; i < pInSAR->aoi->N; i++) {
                H[i] = pInSAR->masterInfo->sceneAverageHeight ;
            }
        }
        convertAoIFromDeg2SRA(kmlAoI, pInSAR->masterInfo, H) ;
        rectangularAoI = circumscribedRectangleOfPolygon(kmlAoI) ;
        
        xMin = rectangularAoI->P[0].x ;
        yMin = rectangularAoI->P[0].y ;
        xMax = rectangularAoI->P[2].x ;
        yMax = rectangularAoI->P[2].y ;
        
        (pInSAR->sup).Sgra = pInSAR->aoi->P[0].x = pInSAR->aoi->P[3].x = (pInSAR->aoi->P[0].x > xMin)? (int)ceil(pInSAR->aoi->P[0].x) : xMin ;
        (pInSAR->sup).Sbaz = pInSAR->aoi->P[0].y = pInSAR->aoi->P[1].y = (pInSAR->aoi->P[0].y > yMin)? (int)ceil(pInSAR->aoi->P[0].y) : yMin ;
        (pInSAR->sup).Sdra = pInSAR->aoi->P[1].x = pInSAR->aoi->P[2].x = (pInSAR->aoi->P[2].x < xMax)? (int)floor(pInSAR->aoi->P[2].x) : xMax ;
        (pInSAR->sup).Shaz = pInSAR->aoi->P[2].y = pInSAR->aoi->P[3].y = (pInSAR->aoi->P[2].y < yMax)? (int)floor(pInSAR->aoi->P[2].y) : yMax ;
    
        freeVectorDouble(H, 0) ;
        freePolygon(rectangularAoI) ;
        freePolygon(kmlAoI) ;
    }

    /* if interpolation was performed with respect to a super master, adapt area of interest correspondingly */
    if (isCSLImageAtPath(pInSAR->interpolatedSlave->imageDirectoryPath)) {
        projectAoIOnSuperMaster(pInSAR) ;
    }

    freePolygon(slaveAoI) ;
}


void projectAoIOnSuperMaster(InSARParametersStruct *pInSAR)
{
    int xMin, yMin ;
    int xMax, yMax ;
    double *H = NULL ;
    polygon *superMasterAoI = NULL ;
    polygon *kmlAoI, *rectangularAoI ;
    
    if (pInSAR->SM2MpInSAR) {
        /* First, we compute max superposition area taking into account suoer master to master transfrom */
        xMin = yMin = 0 ;
        xMax = MIN(pInSAR->masterInfo->rangeDimension, pInSAR->slaveInfo->rangeDimension) - 1 ;
        yMax = MIN(pInSAR->masterInfo->azimuthDimension, pInSAR->slaveInfo->azimuthDimension) - 1 ;
        xMax = MIN(pInSAR->SM2MpInSAR->masterInfo->rangeDimension - 1, xMax) ;
        yMax = MIN(pInSAR->SM2MpInSAR->masterInfo->azimuthDimension - 1, yMax) ;

        superMasterAoI = allocQuadrilateral() ;
        planeAffineTransformOfPolygon(pInSAR->aoi, superMasterAoI, pInSAR->SM2MpInSAR->inverseSlaveAffineTransform) ;

        (pInSAR->sup).Sgra = pInSAR->aoi->P[0].x = pInSAR->aoi->P[3].x = (superMasterAoI->P[0].x > xMin)? (int)ceil(superMasterAoI->P[0].x) : xMin ;
        (pInSAR->sup).Sbaz = pInSAR->aoi->P[0].y = pInSAR->aoi->P[1].y = (superMasterAoI->P[0].y > yMin)? (int)ceil(superMasterAoI->P[0].y) : yMin ;
        (pInSAR->sup).Sdra = pInSAR->aoi->P[1].x = pInSAR->aoi->P[2].x = (superMasterAoI->P[2].x < xMax)? (int)floor(superMasterAoI->P[2].x) : xMax ;
        (pInSAR->sup).Shaz = pInSAR->aoi->P[2].y = pInSAR->aoi->P[3].y = (superMasterAoI->P[2].y < yMax)? (int)floor(superMasterAoI->P[2].y) : yMax ;
        
        /* If a kml is provided with the super master, we read and convert it in slant range coordinates. */
        /* Then, we limit it to fit within maximal superposition area */
        if ((kmlAoI = getRectangularAoIFromKMLFile(pInSAR->SM2MpInSAR->aoiKml))) {
            if((H = getLocalHeightsOfAoISummits(pInSAR->SM2MpInSAR->aoiKml, pInSAR->externalReferenceDEM, pInSAR->masterInfo->sceneAverageHeight))) {
                convertAoIFromDeg2SRA(kmlAoI, pInSAR->SM2MpInSAR->masterInfo, H) ;
                rectangularAoI = circumscribedRectangleOfPolygon(kmlAoI) ;

                xMin = rectangularAoI->P[0].x ;
                yMin = rectangularAoI->P[0].y ;
                xMax = rectangularAoI->P[2].x ;
                yMax = rectangularAoI->P[2].y ;
                
                (pInSAR->sup).Sgra = pInSAR->aoi->P[0].x = pInSAR->aoi->P[3].x = (pInSAR->aoi->P[0].x > xMin)? (int)ceil(pInSAR->aoi->P[0].x) : xMin ;
                (pInSAR->sup).Sbaz = pInSAR->aoi->P[0].y = pInSAR->aoi->P[1].y = (pInSAR->aoi->P[0].y > yMin)? (int)ceil(pInSAR->aoi->P[0].y) : yMin ;
                (pInSAR->sup).Sdra = pInSAR->aoi->P[1].x = pInSAR->aoi->P[2].x = (pInSAR->aoi->P[2].x < xMax)? (int)floor(pInSAR->aoi->P[2].x) : xMax ;
                (pInSAR->sup).Shaz = pInSAR->aoi->P[2].y = pInSAR->aoi->P[3].y = (pInSAR->aoi->P[2].y < yMax)? (int)floor(pInSAR->aoi->P[2].y) : yMax ;
                
                freePolygon(rectangularAoI) ;
                freeVectorDouble(H, 0) ;
            }
            freePolygon(kmlAoI) ;
        }
        freePolygon(superMasterAoI) ;
    }
    
}


void updateBaseLineUsingRegistrationTransform(InSARParametersStruct *pInSAR)
{
	int i, j, k, N, *index ;
	double *masterPoint, *slavePoint ;
	double *cBh, *cBv, *baselineVector, Bh, Bv ;
	double *normalVector, *horizontalVector, *aVector ;
	double **M, signe ;
    double range, azimuth, deltaRange, deltaAzimuth ;
    double azimuthMin, azimuthMax, rangeMin, rangeMax ;
	geoRef *geoRefMaster, *geoRefSlave ;

	/* Initialize back and forth referencing for master image */
	orbitInterpolation(pInSAR->masterInfo) ;
	geoRefMaster = allocAndInitGeorefStructureForTargetEllipsoid(pInSAR->masterInfo, pInSAR->masterInfo->ellRef) ;

	/* Initialize back and forth referencing for slave image with the same ellipsoid */
	orbitInterpolation(pInSAR->slaveInfo) ;
	geoRefSlave = allocAndInitGeorefStructureForTargetEllipsoid(pInSAR->slaveInfo, pInSAR->masterInfo->ellRef) ;

	cBh = vectorDouble(1, 3) ;					/* We allocate vectors for the baseline coefficients to be computed */
	cBv = vectorDouble(1, 3) ;
	baselineVector = vectorDouble(0, 2) ;		/* As also for the baseline vector itself */
	normalVector = vectorDouble(0, 2) ;			/* This vector is the normal to the local horizontal */
	horizontalVector = vectorDouble(0, 2) ;		/* And this is a vector in the local horizontal plane */
	aVector = vectorDouble(0, 2) ;				/* This is a vector used in intermediate computation */
	masterPoint= vectorDouble(0, 1) ;					/* This is a 2D vector for rang-azimuth localization of a point */
	slavePoint = vectorDouble(0, 1) ;					/* This is a 2D vector for rang-azimuth localization of a point */


	/* Image frame range on which is calculate the baseline */
    azimuthMin = 0. ;
    azimuthMax = (double)geoRefMaster->params->info->azimuthDimension - 1. ;
    rangeMin = 0. ;
    rangeMax = (double)geoRefMaster->params->info->rangeDimension - 1. ;
	/* Allocation of a matrix to solve the system */
    M = matrixDouble(1, 3, 1, 3) ;
    index = vectorInt(1, 3) ;

	/* Initialization */
    for(i = 1; i <= 3; i++) {
        cBh[i] = cBv[i] = 0. ;
        for(j = 1; j <= 3; j++)
            M[i][j] = 0. ;
    }

	/* The image frame is sampled on a 5x5 network */
	/* For each point of this net in the master image, the corresponding coordinate in the slave image will be computed */
	/* For the corresponding azimuth in both master and slave, the stat vector difference will give a baseline vector */
	/* Baseline affine approximation will be obtained by mean square calculation */
    N = 15 ;

    deltaAzimuth = (azimuthMax - azimuthMin)/(N - 1) ;
    deltaRange = (rangeMax - rangeMin)/(N - 1) ;
    for(i = 0; i < N; i++) {															/* Loop on azimuth coordinate */
        azimuth = azimuthMin + i * deltaAzimuth ;													/* Azimuth coordinate of the considered point of the network */
		calcStateVect(geoRefMaster->solving->S, azimuth, geoRefMaster->params->info) ;	/* Calculation of the corresponding state vector */

		masterPoint[1] = (double)azimuth ;
		for(k = 0; k < 3; k++)															/* We compute the normal vector to the local horizontal plane */
			normalVector[k] = geoRefMaster->solving->S->P[k] ;
		normalizeVector(normalVector) ;

        for(j = 0; j < N; j++) {														/* Loop on range Coordinate */
            range = rangeMin + j * deltaRange ;
			masterPoint[0] = (double)range ;
			planeAffineTransformOfPoint(masterPoint, slavePoint, pInSAR->slaveAffineTransform) ;

			calcStateVect(geoRefSlave->solving->S, slavePoint[1], geoRefSlave->params->info) ;	/* Calculation of the correspnding state vector */
			vectorDiff(baselineVector, geoRefSlave->solving->S->P, geoRefMaster->solving->S->P) ; /* This is the baseline vector */

			Bv = scalarProduct(baselineVector, normalVector) ;							/* The scalar product of the baseline vector with the normal to the horizontal plane is the vertical baseline component */

			vectorialProduct(aVector, normalVector, baselineVector) ;
			vectorialProduct(horizontalVector, aVector, normalVector) ;					/* We compute the local horizontal vector, coplanar with the baseline vector */
			normalizeVector(horizontalVector) ;

			Bh = scalarProduct(baselineVector, horizontalVector) ;

			M[1][1] += range * range ;
			M[1][2] += azimuth * range ;
			M[1][3] += range ;
			M[2][2] += azimuth * azimuth ;
			M[2][3] += azimuth ;
			M[3][3] ++ ;

			cBh[1] += range * Bh ;
			cBh[2] += azimuth * Bh ;
			cBh[3] += Bh ;
			cBv[1] += range * Bv ;
			cBv[2] += azimuth * Bv ;
			cBv[3] += Bv ;
        }
    }
    M[2][1] = M[1][2] ;
    M[3][1] = M[1][3] ;
    M[3][2] = M[2][3] ;

	/* Matrix inversion and coefficients computation */
    ludcmp(M, 3, index, &signe) ;
    lubksb(M, 3, index, cBh) ;
    lubksb(M, 3, index, cBv) ;

	/* Baseline horizontal and vertical coefficients */
	for(i = 0; i < 3; i++) {
		pInSAR->B.T[0][i] = cBh[i + 1] ;
		pInSAR->B.T[1][i] = cBv[i + 1] ;
	}


	freeGeoRef(geoRefMaster) ;
	freeGeoRef(geoRefSlave) ;
	freeVectorDouble(cBh, 1) ;
	freeVectorDouble(cBv, 1) ;
	freeVectorDouble(baselineVector, 0) ;
	freeVectorDouble(aVector, 0) ;
	freeVectorDouble(masterPoint, 0) ;
	freeVectorDouble(slavePoint, 0) ;
	freeVectorDouble(normalVector, 0) ;
	freeVectorDouble(horizontalVector, 0) ;
}



/* Get height vector corresponding to aoi summits given as kml, provided a reference DEM is available */
/* If an aoi summit is outside of given DEM, NaN is returned as corresponding height */
double *getLocalHeightsOfAoISummits(char *kmlPath, char *DEMPath, double defaultValue)
{
    double *H = NULL ;
    polygon *kmlAoI ;
    if (kmlPath) {
        kmlAoI = getPolygonalAoIFromKMLFile(kmlPath) ;
        H = getLocalHeightsOfPolygon(kmlAoI, DEMPath, defaultValue) ;
        freePolygon(kmlAoI) ;
    }

    return H ;
}

/* Get height vector corresponding to aoi summits given as a polygon, provided a reference DEM is available */
/* If an aoi summit is outside of given DEM, NaN is returned as corresponding height */
double *getLocalHeightsOfPolygon(polygon *WGS84AoI, char *DEMPath, double defaultValue)
{
    int xDimDEM, yDimDEM, i, iX, iY ;
    int typeSize ;
    short aShort ;
    size_t seekVal ;
    float aFloat ;
    double *H = NULL ;
    double X0, Y0, xSampling, ySampling ;
    polygon *aoi ;
    externalDEMStruct *externalDEM ;

    genFloatNaN() ;

    if (WGS84AoI && DEMPath) {
        aoi = getCopyOfPolygon(WGS84AoI) ;
        
        if ((externalDEM = openExternalDEMFile(DEMPath, NULL))) {
            convertAoIFromDeg2Rad(aoi) ;
            H = vectorDouble(0, aoi->N - 1) ;
            X0 = externalDEM->dataFile->x0 ;
            Y0 = externalDEM->dataFile->y0 ;
            xSampling = externalDEM->dataFile->xSampling ;
            ySampling = externalDEM->dataFile->ySampling ;
            xDimDEM = externalDEM->dataFile->xDim ;
            yDimDEM = externalDEM->dataFile->yDim ;
            typeSize = externalDEM->dataFile->typeSize ;
            for (i = 0; i < aoi->N; i++) {
                iX = (int)rint((aoi->P[i].x - X0) / xSampling) ; 
                iY = (int)rint((aoi->P[i].y - Y0) / ySampling) ; 
                if (externalDEM->flag & _FLIP_DEM_) {
                    iY = yDimDEM - 1 -iY ; 
                }
                
                if (iX >= 0 && iY >= 0 && iX < xDimDEM && iY < yDimDEM) {
                    seekVal = (iY * xDimDEM + iX) * typeSize ; 
                    fseek(externalDEM->dataFile->f, seekVal, SEEK_SET) ;
                    if (typeSize == 2) {
                        fread(&aShort, typeSize, 1, externalDEM->dataFile->f) ;
                        if (externalDEM->dataFile->byteOrder != isArchBigEndian()) {
                            swapByteStructOfType(&aShort, typeSize) ;
                        }
                        H[i] = (double)(aShort) ;
                    }
                    else {
                        fread(&aFloat, typeSize, 1, externalDEM->dataFile->f) ;
                        if (externalDEM->dataFile->byteOrder != isArchBigEndian()) {
                            swapByteStructOfType(&aFloat, typeSize) ;
                        }
                        if (areFloatValsEquals(aFloat, floatNaN)) {
                            aFloat = defaultValue ;
                        }
                    }
                    H[i] = (double)(aFloat) ;
                }
                else {
                    H[i] = defaultValue ;
                }
            }
            freeExternalDEMStruct(externalDEM) ;
        }
    }
   
    return (H) ;
}