
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


#include <stdio.h>
#include "initInSARLib.h"

InSARParametersStruct *initInSAR (CSVStruct *csv) {
    char test ;
	char *InSARPath = NULL, *aPath, isBistatic = 0 ;
    char *preferredPolarization = NULL ;
    char *aoiKml = NULL ;
    char *textFilesDir ;
    char *externalDEMFilePath = NULL, *ENVIFilePath = NULL ;
    int i ;
    double **T1, **T2 = NULL ;
    double *H = NULL ;
	keyValue *parametersList = NULL, *aKeyValList = NULL ;
	CSLImage *masterImage = NULL, *slaveImage = NULL ;
    CSLImage *superMasterImage = NULL ;
    InSARParametersStruct *pInSAR, *SM2MpInSAR = NULL, *SM2SpInSAR = NULL ;
    polygon *aoi = NULL ;
	
	
	if(csv->numberOfEntries == 1 || isArgumentPresentInCSV(csv, "help") || isArgumentPresentInCSV(csv, "-h")) {
		initInSARHelp() ;
    }
	
	if(isArgumentPresentInCSV(csv, "-create")) {
		createInitInSARParameterFileAtPath(csv->stringVal[1]) ;
		exit(0) ;
	}

	
    /* Read parameters list */
    if (fileExistsAtPath(csv->stringVal[1]) && !isCSLImageAtPath(csv->stringVal[1])) {
        parametersList = readParameterFileAtPath(csv->stringVal[1]) ;
        
        /* Create InSAR directory structure at indicated path */
        InSARPath = getStringValForKeyIn(parametersList, "Target") ;
        
        /* Get master and slave image structures */
        masterImage = getCSLImageStructureAtPath(getStringValForKeyIn(parametersList, "Master")) ;
        slaveImage = getCSLImageStructureAtPath(getStringValForKeyIn(parametersList, "Slave")) ;
        
        /* Read global master to master InSAR parameters */
        aPath = getStringValForKeyIn(parametersList, "Global master to master InSAR directory path") ;
        if (isInSARDirectoryStructureAtPath(aPath)) {
            aPath = initStringWith2Strings(aPath, "/TextFiles/InSARParameters.txt") ;
            SM2MpInSAR = readInSARParametersFileAtPath(aPath) ;
            free(aPath) ;
        }
        
        /* Initialize InSAR parameters */
        isBistatic = 0 ;
        if (isKeyValPresent(parametersList, "Bistatic")) {
            isBistatic = !strncmp(getStringValForKeyIn(parametersList, "Bistatic"), "YES", 3) ;
        }
        
        preferredPolarization = initStringWithString(getStringValForKeyIn(parametersList, "Polarization")) ;
        
        /* Get area of interest */
        if ((aoiKml = getStringValForKeyIn(parametersList, "kml"))) {
            aoi = getPolygonalAoIFromKMLFile(aoiKml) ;
        }
    }
    else {
        for (i = 1; i < csv->numberOfEntries; i++) {
            if (isCSLImageAtPath(csv->stringVal[i])) {
                if (masterImage) {
                    if (slaveImage) {
                        superMasterImage = getCSLImageStructureAtPath(csv->stringVal[i]) ;
                    }
                    else {
                        slaveImage = getCSLImageStructureAtPath(csv->stringVal[i]) ;
                    }
                }
                else {
                    masterImage = getCSLImageStructureAtPath(csv->stringVal[i]) ;
                }
            }
        }
        
        if (!masterImage || !slaveImage) {
            if (masterImage) {
                freeCSLImageStructure(masterImage) ;
                ase("No slave image given in input") ;
            }
            else {
                ase("No master image given in input") ;
            }
        }        
        for (i = 1; i < csv->numberOfEntries; i++) {

            if (!isCSLImageAtPath(csv->stringVal[i])) {
                if (isInSARDirectoryStructureAtPath(csv->stringVal[i])) {
                    aPath = initStringWith2Strings(csv->stringVal[i], "/TextFiles/InSARParameters.txt") ;
                    if (!SM2MpInSAR) {
                        SM2MpInSAR = readInSARParametersFileAtPath(aPath) ;
                        if (!strcmp(SM2MpInSAR->masterImage->imageDirectoryPath, masterImage->imageDirectoryPath) && !strcmp(SM2MpInSAR->slaveImage->imageDirectoryPath, slaveImage->imageDirectoryPath)) {
                            InSARPath = (InSARPath)? InSARPath : initStringWithString(csv->stringVal[i]) ;
                            freeInSARParametersStruct(SM2MpInSAR) ;
                            SM2MpInSAR = NULL ;
                        }
                    }
                    else {
                        SM2SpInSAR = readInSARParametersFileAtPath(aPath) ;
                        if (!strcmp(SM2SpInSAR->masterImage->imageDirectoryPath, masterImage->imageDirectoryPath) && !strcmp(SM2SpInSAR->slaveImage->imageDirectoryPath, slaveImage->imageDirectoryPath)) {
                            freeInSARParametersStruct(SM2SpInSAR) ;
                            SM2SpInSAR = NULL ;
                            InSARPath = (InSARPath)? InSARPath : initStringWithString(csv->stringVal[i]) ;
                        }
                    }
                    free(aPath) ;
                }
                else {
                    if (isDir(csv->stringVal[i])) {
                        InSARPath = (InSARPath)? InSARPath : (isWriteAccessGrantedAtPath(csv->stringVal[i]))? initStringWith2Strings(csv->stringVal[i], ", i12") : NULL ;
                    }
                    else {
                        test = 0 ;
                        if (!aoi) {
                            if ((aoi = getPolygonalAoIFromKMLFile(csv->stringVal[i]))) {
                                aoiKml = csv->stringVal[i] ;
                                test = 1 ;
                            }
                        }
                        if ((ENVIFilePath = getGeoreferencedDataFilePath(csv->stringVal[i]))) {
                            test = 1 ;
                            if (!externalDEMFilePath) {
                                externalDEMFilePath = initStringWithString(ENVIFilePath) ;
                            }
                            free(ENVIFilePath) ;
                        }
                        else {
                            if (!test) {
                                InSARPath = (InSARPath)? InSARPath : (isWriteAccessGrantedAtPath(csv->stringVal[i]))? initStringWithString(csv->stringVal[i]) : NULL ;
                            }
                        }
                    }
                }
            }
        }
    }
    
    if (SM2MpInSAR) {
        if (strcmp(masterImage->imageDirectoryPath, SM2MpInSAR->slaveImage->imageDirectoryPath)) {
            freeInSARParametersStruct(SM2MpInSAR) ;
            SM2MpInSAR = NULL ;
            printf("Given reference InSAR processing is not valid...\n") ;
        }
    }
    
    /* In case of Mass processing, both master and slave image may already be coregistered with respect to a global master one */
    /* In which case, master to slave transform may directly be computed from both coregistration transforms */
    if (SM2SpInSAR) {
        if (strcmp(slaveImage->imageDirectoryPath, SM2SpInSAR->slaveImage->imageDirectoryPath) || strcmp(SM2MpInSAR->masterImage->imageDirectoryPath, SM2SpInSAR->masterImage->imageDirectoryPath)) {
            freeInSARParametersStruct(SM2MpInSAR) ;
            SM2SpInSAR = NULL ;
        }
        else {
            T1 = combinedAffineTransform(SM2MpInSAR->slaveAffineTransform, SM2SpInSAR->inverseSlaveAffineTransform) ;
            T2 = inversePlaneAffineTransform(T1, NULL) ;
            freeMatrixDouble(T1, 0, 0) ;
        }
    }
    
    isBistatic |= isFlagPresentInCSV(csv, "b") ;
    
    if (!preferredPolarization && (i = isArgumentPresentInCSV(csv, "P="))) {
        if (strlen(csv->stringVal[i]) == 4) {
            preferredPolarization = initStringWithString(csv->stringVal[i] + 2) ;
        }
    }
    
    printf("\n\nInSAR initialization\n") ;
    pInSAR = allocAndinitInSARParametersStructAtPathForImages(InSARPath, masterImage, slaveImage, SM2MpInSAR, isBistatic, preferredPolarization) ;

    pInSAR->flag |= (isArgumentPresentInCSV(csv, "-o"))? _NON_PARALLEL_ORBITS_ : pInSAR->flag ;

    /* Register kml path if any */
    if (aoi) {
        pInSAR->aoiKml = initStringWithString(aoiKml) ;
        freePolygon(aoi) ;
    }
        /* Register external DEM */
    if (externalDEMFilePath) {
        pInSAR->externalReferenceDEM = initStringWithString(externalDEMFilePath) ;
        free(externalDEMFilePath) ;
    }
    else {
        aPath = initStringWith2Strings(masterImage->infoDirectoryPath, "/externalSlantRangeDEM.txt") ;
        if (fileExistsAtPath(aPath)) {
            if((aKeyValList = readParameterFileAtPath(aPath))) {
                pInSAR->externalReferenceDEM = initStringWithString(getStringValForKeyIn(aKeyValList, "Georeferenced DEM file path")) ;
                freeKeyValueList(aKeyValList) ;
            }
            free(aPath) ;
        }
    }

    /* Register slantRangeMask if present */
    aPath = initStringWith2Strings(masterImage->dataDirectoryPath, "/slantRangeMask") ;
    if (fileExistsAtPath(aPath)) {
        pInSAR->slantRangeMask = initStringWithString(aPath) ;
    }
    free(aPath) ;
    
    initInSAR_GEO(pInSAR, _COMPUTEAOI_) ;
   
    if (SM2SpInSAR) {
        freeMatrixDouble(pInSAR->slaveAffineTransform, 0, 0) ;
        pInSAR->slaveAffineTransform = T2 ;
        inversePlaneAffineTransform(pInSAR->slaveAffineTransform, pInSAR->inverseSlaveAffineTransform) ;
        freeInSARParametersStruct(SM2SpInSAR) ;
    }
    
    /* Save parameters file at required location */
    if (!isArgumentPresentInCSV(csv, "keepExisting") || !isDir(pInSAR->whereAmI)) {
        printf("InSAR inititalisation at path %s\nConsidered image pair %s - %s\n", pInSAR->whereAmI, getPointerToFileNameInPath(pInSAR->masterImage->imageDirectoryPath), getPointerToFileNameInPath(pInSAR->slaveImage->imageDirectoryPath)) ;

        createInSARDirectoryStructureAtPath(pInSAR->whereAmI) ;
        textFilesDir = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/") ;
        aPath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/masterSLCImageInfo.txt") ;
        saveInfoImage(pInSAR->masterInfo, aPath) ;
        free(saveInfoKmlInDir(pInSAR->masterInfo, textFilesDir)) ;
        free(aPath) ;
        aPath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/slaveSLCImageInfo.txt") ;
        saveInfoImage(pInSAR->slaveInfo, aPath) ;
        free(saveInfoKmlInDir(pInSAR->slaveInfo, textFilesDir)) ;
        free(aPath) ;
        aPath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/InSARParameters.txt") ;
        saveInSARParametersFileAtPath(pInSAR, aPath) ;
        free(aPath) ;
        free(textFilesDir) ;
        
        /* Create and save geolocation parameter file */
        createGeoProjectionParametersFileAtPath(pInSAR->whereAmI) ;
        
        /* Create and save SBInSAR parameter file */
        pInSAR->flag |= (isArgumentPresentInCSV(csv, "-iono"))? _NSB2_ : pInSAR->flag ;
        createSBInSARParameterFileAtPath(pInSAR) ;

        /* Create and save coherence tracking parameter file */
        createCohTrackParameterFile(pInSAR) ;
    }

	freeKeyValueList(parametersList) ;
    
    if (preferredPolarization) {
        free(preferredPolarization) ;
    }
    
	return (pInSAR) ;
}

void initInSARHelp()
{
	printf("\nUsage:\n-1- initInSAR /pathTo/parameterFile [-create] [-b] [P=XX]\n");
	printf("\nThis routine will initialize InSAR processing for an image pair given in CSL format");
	printf("\nInitialization consist in creating a directory structure and \na parameter file that will be used for further processing steps.\n");
	printf("\nIf adding \"-create\" as command line parameter, an example parameter file will be created at indicated path\n") ;
    printf("\n-2- initInSAR /masterDir /slaveDir [/destDir] [kmlFilePath] [masterToSuperMasterProcessingDir [slaveToSuperMasterProcessingDir]] [-b P=XX]\n") ;
    printf("\nIf desDir doesn't exists, InSAR directoy structure will be created at given path") ;
    printf("\n\nIf destDir exists, and is already the required InSAR directory structure, it is replaced/reinitialized.\n") ;
    printf("If destDir exists, and is not an InSAR directory structure, InSAR directory structure will be created\n\twithing given directory with the name i[masterDate]_[slaveDate]\n") ;
    printf("\nOPtions:\t-b\t: Initialization considering bistatic pair.") ;
    printf("\n\t\tP=XX\t: Initialization considering XX polarisaton. (XX == {HH, HV, VH, VV})\n") ;
	exit(0) ;
}

void createInitInSARParameterFileAtPath(char *aPath)
{
	keyValue *parameterList ;
	
	parameterList = allocAKeyValuePair() ;
	setStringValForKeyIn(parameterList, "InSAR Initialization parameter file", "") ;
	setStringValForKeyIn(parameterList, "***********************************", "") ;
	setStringValForKeyIn(parameterList, "masterImagePath", "Master: Path to master image file in CSL format") ;
    setStringValForKeyIn(parameterList, "slaveImagePath", "Slave: Path to slave image file in CSL format") ;
    setStringValForKeyIn(parameterList, "SM2MPath", "Global master to master InSAR directory path") ;
	setStringValForKeyIn(parameterList, "NO", "Bistatic interferometric pair [YES/NO]") ;
    setStringValForKeyIn(parameterList, "pathToInSAR_results", "Target directory: Path to directory for InSAR processing results") ;
    setStringValForKeyIn(parameterList, "VV", "Polarization") ;
    setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, "Area of interest (if all zeros, the whole input image is considered)", "") ;
    setStringValForKeyIn(parameterList, "GEO", "Coordinate system [SRA / GEO]") ;
    setStringValForKeyIn(parameterList, "0", "X0 = lower left corner X coordinate") ;
    setStringValForKeyIn(parameterList, "0", "Y0 = lower left corner Y coordinate") ;
    setStringValForKeyIn(parameterList, "0", "X2 = upper right corner X coordinate") ;
    setStringValForKeyIn(parameterList, "0", "Y2 = upper right corner Y coordinate") ;
    setStringValForKeyIn(parameterList, "pathToKMLFile", "kml file path (.kml polygon saved from Google Earth). This file prevails.") ;


	writeParameterFileAtPath(parameterList, aPath) ;
}

