
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  detPhUnLib.c
//  detPhUn
//
//  Created by Dominique Derauw on 30/08/12.
//  Copyright (c) 2012 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "detPhUnLib.h"

void detPhUnManagement(CSVStruct *csv, InSARParametersStruct *pInSAR)
{
    char *interfPath, *aPath = NULL ;
    int i ;
    int xTileSize, yTileSize, xTileBorderSize, yTileBorderSize, numberOfIterations ;
    float originalSmoothingFactor ;
    rawFileDescriptor *interfFile ;
    
    defoOrTopo(pInSAR) ;
    
    interfFile = selectInterferogram(pInSAR) ;
    interfPath = interfFile->accessPath ;
    
    numberOfIterations = 1 ;
    if ((i = isArgumentPresentInCSV(csv, "N"))) {
        sscanf(csv->stringVal[i], "N=%d", &numberOfIterations) ;
    }
    
    xTileBorderSize = 0 ;
    if ((i = isArgumentPresentInCSV(csv, "xTileSize"))) {
        sscanf(csv->stringVal[i], "xTileSize=%d", &xTileSize) ;
        if ((i = isArgumentPresentInCSV(csv, "xTileBorderSize"))) {
            sscanf(csv->stringVal[i], "xTileBorderSize=%d", &xTileBorderSize) ;
        }
    }
    else {
        xTileSize = pInSAR->interf.lenr ;
    }
    
    yTileBorderSize = 0 ;
    if ((i = isArgumentPresentInCSV(csv, "yTileSize"))) {
        sscanf(csv->stringVal[i], "yTileSize=%d", &yTileSize) ;
        if ((i = isArgumentPresentInCSV(csv, "yTileBorderSize"))) {
            sscanf(csv->stringVal[i], "yTileBorderSize=%d", &yTileBorderSize) ;
        }
    }
    else {
        yTileSize = pInSAR->interf.lena ;
    }
    
    originalSmoothingFactor = pInSAR->filter.adaptativeFilterSmoothingFactor ;
    if ((i = isArgumentPresentInCSV(csv, "f="))) {
        pInSAR->flag |= _DETPHUN_WITH_FILTERING_ ;
        sscanf(csv->stringVal[i] + 2, "%f", &(pInSAR->filter.adaptativeFilterSmoothingFactor)) ;
    }
    
    /* If detPhUn is followed by snaphu, change unwrapped phase file name */
    if (pInSAR->flag & _SNAPHU_ || pInSAR->flag & _BRANCH_CUT_) {
        aPath = initStringWithString(pInSAR->dephi.filePath) ;
        free(pInSAR->dephi.filePath) ;
        pInSAR->dephi.filePath = initStringWith2Strings(aPath, ".detPhUn") ;
    }
    
    deterministicPhaseUnwrapping(pInSAR, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize, numberOfIterations) ;
    
    /* If detPhUn is followed by snaphu, restore unwrapped phase file name and change interferogram file name to unwrapp detPhUn phase residue */
    if (pInSAR->flag & _SNAPHU_ || pInSAR->flag & _BRANCH_CUT_) {
        free(pInSAR->dephi.filePath) ;
        pInSAR->dephi.filePath = initStringWithString(aPath) ;
        free(aPath) ;
 
        aPath = initStringWith2Strings(interfPath, ".phaseResidue") ;
        closeRawFile(interfFile) ;
        setRawFilePath(interfFile, aPath) ;
        openRawFileForReading(interfFile) ;
    }
    
    pInSAR->filter.adaptativeFilterSmoothingFactor = originalSmoothingFactor ;
}

void deterministicPhaseUnwrapping(InSARParametersStruct *pInSAR, int xTileSize, int yTileSize, int xTileBorderSize, int yTileBorderSize, int numberOfIterations)
{
    char *aFilePath, *aNewFilePath, *filteredPhaseResidue ; ;
    int i ;
    size_t xTileIndex = 0, yTileIndex ;
    double normalizationFactor ;
    rawFileDescriptor *interferogramFile, *phaseResidue, *lastPhaseResidue = NULL ;
    tileTool *interfTileTool, *currentPhaseTileTool, *residualPhaseTileTool, *unwrappedPhaseTileTool, *coherenceTileTool ;
    detphun *gP ;
    progressCounter *aCounter ;
    keyValue *params = NULL ;
    
    
    /* Open requested interferogram */
    interferogramFile = selectInterferogram(pInSAR) ;
    printf("Considered interferogram: %s\n", interferogramFile->accessPath) ;
    
    /* Create phase residue file */
    aFilePath = initStringWith2Strings(interferogramFile->accessPath, ".phaseResidue") ;
    phaseResidue = openRawFileForReadingAndWritingAtPath(aFilePath) ;
    phaseResidue->xDim = interferogramFile->xDim ;
    phaseResidue->yDim = interferogramFile->yDim ;
    free(aFilePath) ;
    
    /* Create temp file for iterative processing */
    if (numberOfIterations > 1) {
        aFilePath = initStringWith2Strings(interferogramFile->accessPath, ".lastPhaseResidue") ;
        lastPhaseResidue = openRawFileForReadingAndWritingAtPath(aFilePath) ;
        lastPhaseResidue->xDim = interferogramFile->xDim ;
        lastPhaseResidue->yDim = interferogramFile->yDim ;
        free(aFilePath) ;
    }
    
    /* Test if deformation measurement is considered ...*/
    defoOrTopo(pInSAR) ;
    
    /* Create unwrapped phase file for output */
    openUnwrappedPhaseFile(pInSAR) ;
    pInSAR->unwrappedPhaseFile->xDim = pInSAR->dephi.lenr = interferogramFile->xDim ;
    pInSAR->unwrappedPhaseFile->yDim = pInSAR->dephi.lena = interferogramFile->yDim ;
    
    
    /* Alloc tile tool for input interferogram */
    interfTileTool = allocTileToolForFilesOfType(interferogramFile, pInSAR->unwrappedPhaseFile, "float") ;
    initTileToolWithSizes(interfTileTool, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    
    currentPhaseTileTool = allocTileToolForFilesOfType(interferogramFile, pInSAR->unwrappedPhaseFile, "float") ;
    initTileToolWithSizes(currentPhaseTileTool, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    
    /* Alloc tile tool for coherence management */
    openCoherenceFile(pInSAR) ;
    coherenceTileTool = allocTileToolForFilesOfType(pInSAR->coherenceFile, NULL, "float") ;
    initTileToolWithSizes(coherenceTileTool, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;

    /* Alloc tile tool for iterative unwrapping */
    residualPhaseTileTool = allocTileToolForFilesOfType(phaseResidue, phaseResidue, "float") ;
    initTileToolWithSizes(residualPhaseTileTool, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    
    unwrappedPhaseTileTool = allocTileToolForFilesOfType(pInSAR->unwrappedPhaseFile, pInSAR->unwrappedPhaseFile, "float") ;
    initTileToolWithSizes(unwrappedPhaseTileTool, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    
    /* Filtering initialization */
    if (pInSAR->flag & _DETPHUN_WITH_FILTERING_) {
        pInSAR->flag |= _CLASSIC_FILTER_ ;
        pInSAR->flag |= _ADAPTATIVE_FILTER_ ;
        params = allocAKeyValuePair() ;
        filteredPhaseResidue = initStringWith2Strings(interfTileTool->input->directoryPath, "tempFile") ;
        setStringValForKeyIn(params, interfTileTool->input->accessPath, "Input file") ;
        setStringValForKeyIn(params, phaseResidue->accessPath, "Output file") ;
        setStringValForKeyIn(params, coherenceTileTool->input->accessPath, "Coherence file") ;
        setIntValForKeyIn(params, (pInSAR->interf).lenr, "xDim") ;
        setIntValForKeyIn(params, (pInSAR->interf).lena, "yDim") ;
        setDoubleValForKeyIn(params, pInSAR->filter.sigmar, "Sigma X") ;
        setDoubleValForKeyIn(params, pInSAR->filter.sigmaz, "Sigma Y") ;
        setDoubleValForKeyIn(params, pInSAR->filter.adaptativeFilterSmoothingFactor, "Smoothing factor") ;
        setIntValForKeyIn(params, pInSAR->flag, "Flags") ;
        setDoubleValForKeyIn(params, 1, "Power argument") ;
/*
        currentPhaseTileTool->input = phaseResidue ;
        interferogramFilteringCore(params) ;
*/
        setStringValForKeyIn(params, filteredPhaseResidue, "Output file") ;
    }
    
    /* Deterministic phase unwrapping initialization */
    gP = allocAndInitDetphunWithWindowSize(xTileSize, yTileSize, pInSAR->flag) ;
    gP->initialPhase = (float **)interfTileTool->tile ;
    gP->currentPhase = (float **)currentPhaseTileTool->tile ;
    gP->dephi = (float **)unwrappedPhaseTileTool->tile ;
    gP->coh = (float **)coherenceTileTool->tile ;
    gP->iterationNumber = numberOfIterations ;
    gP->coherenceThreshold =  pInSAR->conex.seuilnet ;

    for(i = 0; i < gP->iterationNumber; i++) {
        if (gP->iterationNumber > 1) {
            printf("\nIteration %d\n", i + 1) ;
        }
        if (i > 0) {
            if (pInSAR->flag & _DETPHUN_WITH_FILTERING_ ) {
                printf("Phase filtering\n") ;
                setStringValForKeyIn(params, phaseResidue->accessPath, "Input file") ;
                interferogramFilteringCore(params) ;
                
                closeRawFile(phaseResidue) ;
                unlink(phaseResidue->accessPath) ;
                rename(getStringValForKeyIn(params, "Output file"), phaseResidue->accessPath) ;
                openRawFileForReadingAndWriting(phaseResidue) ;
            }
            currentPhaseTileTool->input = phaseResidue ;
            phaseResidue = lastPhaseResidue ;
        }
        aCounter = initProgressCounterWithMinMaxValue(0, interfTileTool->xTileNumber * interfTileTool->yTileNumber) ;
        printf("Deterministic phase unwrapping\n") ;
        
        for(yTileIndex = 0; yTileIndex < interfTileTool->yTileNumber; yTileIndex++) {
            for(xTileIndex = 0; xTileIndex < interfTileTool->xTileNumber; xTileIndex++) {
                resetDetphun(gP) ;
                readTileAtIndexes(interfTileTool, xTileIndex, yTileIndex) ;
                readTileAtIndexes(currentPhaseTileTool, xTileIndex, yTileIndex) ;
                readTileAtIndexes(coherenceTileTool, xTileIndex, yTileIndex) ;
                if (i) {
                    readTileAtIndexes(unwrappedPhaseTileTool, xTileIndex, yTileIndex) ;
                }
                transferDataToZ(gP) ;
                
                if (gP->mode == 1) {
                    evaluateXGradient(gP) ;
                    evaluateYGradient(gP) ;
                    
                    fftw_execute(gP->FFTPlanZ1) ;
                    fftw_execute(gP->FFTPlanZ2) ;
                    
                    /* Half pixel shift */
                    multZ1PIQx(gP) ;
                    multZ2PIQy(gP) ;
                    
                    multZ1Qx(gP) ;
                    multZ2Qy(gP) ;
                    
                    addZ1Z2(gP) ;
                    divZ1Q2(gP) ;
                    
                    fftw_execute(gP->IFFTPlanZ1) ;
                    
                    scalarMultiplyZ1(gP, 1. /((float)TWOPI)/gP->xDim/gP->yDim) ;
                }
                else {
                    normalizationFactor = pow(1. / (double)gP->xDim2 / (double)gP->yDim2 / 4, 2.);
                    memcpy(gP->input[0], gP->sinPhi[0], gP->xDim2 * gP->yDim2 * sizeof(double)) ;
                    fftw_execute(gP->FFTPlan) ;

                    multOutPQ2(gP) ;
                    
                    fftw_execute(gP->IFFTPlan) ;
                    multOutCosPhi(gP) ;
                    
                    fftw_execute(gP->FFTPlan) ;
                    divOutPQ2(gP) ;
                    
                    fftw_execute(gP->IFFTPlan) ;
                    multOutCst(gP, normalizationFactor) ;

                    memcpy(gP->temp1[0], gP->output[0], gP->xDim2 * gP->yDim2 * sizeof(double)) ;

                    memcpy(gP->input[0], gP->cosPhi[0], gP->xDim2 * gP->yDim2 * sizeof(double)) ;
                    fftw_execute(gP->FFTPlan) ;
                    multOutPQ2(gP) ;
                    
                    fftw_execute(gP->IFFTPlan) ;
                    multOutSinPhi(gP) ;
                    
                    fftw_execute(gP->FFTPlan) ;
                    divOutPQ2(gP) ;
                    
                    fftw_execute(gP->IFFTPlan) ;
                    multOutCst(gP, normalizationFactor) ;
                    memcpy(gP->temp2[0], gP->output[0], gP->xDim2 * gP->yDim2 * sizeof(double)) ;
                    
                    diffTemp(gP) ;
                }

                addZ1iToDephi(gP) ;
                if (i == gP->iterationNumber - 1) {
//                    roundIt(gP) ;
                }
                diffInterfDephi(gP) ;
                
                updateTileToolForIndexes(unwrappedPhaseTileTool, xTileIndex, yTileIndex) ;
                writeTile(unwrappedPhaseTileTool) ;
                writeTileToOutputFile(currentPhaseTileTool, phaseResidue) ;
                updateProgressCounterForIndex(aCounter, xTileIndex * yTileIndex) ;
 
            }
        }
        

        updateProgressCounterForIndex(aCounter, xTileIndex * yTileIndex) ;
        freeProgressCounter(aCounter) ;
        if (i > 0) {
            lastPhaseResidue = currentPhaseTileTool->input ;
        }
    }
    
    if (i > 1) {
        unlink(lastPhaseResidue->accessPath) ;
        freeRawFileDescriptor(lastPhaseResidue) ;
    }
    aFilePath = initStringWithString(phaseResidue->accessPath) ;
    stripExtensionAtEndOfPath(aFilePath) ;
    aNewFilePath = initStringWith2Strings(aFilePath, ".phaseResidue") ;
    rename(phaseResidue->accessPath, aNewFilePath) ;
    free(aFilePath) ;
    free(aNewFilePath) ;
    freeTileTool(currentPhaseTileTool) ;
    freeTileTool(unwrappedPhaseTileTool) ;
    freeTileTool(interfTileTool) ;
    freeTileTool(residualPhaseTileTool) ;
    freeTileTool(coherenceTileTool) ;
    freeRawFileDescriptor(phaseResidue) ;
    freeRawFileDescriptor(pInSAR->unwrappedPhaseFile) ;
    pInSAR->unwrappedPhaseFile = NULL ;


//    unlink(dXFile->accessPath) ;
//    unlink(dYFile->accessPath) ;
    freeDetPhun(gP) ;
}


void diffInterfDephi(detphun *gP)
{
    int    iX, iY ;
    float residualPhase, unwrappedPhase, wrappedPhase ;
    complexFloat c2, c1 ;
    
    for(iY = 0; iY < gP->yDim; iY++) {
        for(iX = 0; iX < gP->xDim; iX++) {
            wrappedPhase = gP->initialPhase[iY][iX] ;
            unwrappedPhase = gP->dephi[iY][iX] ;
            c1.r = cosf(unwrappedPhase) ;
            c1.i = sinf(unwrappedPhase) ;
            c2.r = cosf(wrappedPhase) ;
            c2.i = sinf(wrappedPhase) ;
            c2 = mC(c2, cC(c1)) ;
            residualPhase = (float)phi(&c2) ;
            gP->currentPhase[iY][iX] = residualPhase ;
        }
    }
}


void roundIt(detphun *gP)
{
    int iX, iY, k ;
    
    for (k = 0; k < 5; k++) {
        for(iY = 0; iY < gP->yDim; iY++) {
            for(iX = 0; iX < gP->xDim; iX++) {
                gP->dephi[iY][iX] = gP->initialPhase[iY][iX] + TWOPI * roundf((gP->dephi[iY][iX] - gP->initialPhase[iY][iX]) / TWOPI) ;
            }
        }
    }
}

void addZ1iToDephi(detphun *gP)
{
    int iX, iY ;
    
    for(iY = 0; iY < gP->yDim; iY++) {
        for(iX = 0; iX < gP->xDim; iX++) {
            gP->dephi[iY][iX] += (gP->mode == 1)? (float)gP->Z1[iY][iX].i : (float)(gP->temp1[iY][iX]) ;
            
        }
    }
    removePhasePlane(gP) ;
}


void diffTemp(detphun *gP)
{
    int iX, iY ;
    
    for(iY = 0; iY < gP->yDim2; iY++) {
        for(iX = 0; iX < gP->xDim2; iX++) {
            gP->temp1[iY][iX] -= gP->temp2[iY][iX] ;
        }
    }
}


void scalarMultiplyZ1(detphun *gP, float aFloat)
{
    int    iX, iY ;
    
    for(iY = 0; iY < gP->yDim; iY++) {
        for(iX = 0; iX < gP->xDim; iX++) {
            gP->Z1[iY][iX] = mRComplexDouble(gP->Z1[iY][iX], aFloat) ;
        }
    }
}


void divZ1Q2(detphun *gP)
{
    int    iX, iY ;
    float inverseOfQ2, q2 ;
    
    for(iY = 0; iY < gP->yDim; iY++) {
        for(iX = 0; iX < gP->xDim; iX++) {
            q2 = gP->qx2[iX] + gP->qy2[iY] ;
            inverseOfQ2 = (q2)? 1. / q2 : 1 ;
            gP->Z1[iY][iX] = mRComplexDouble(gP->Z1[iY][iX], inverseOfQ2) ;
        }
    }
}



void addZ1Z2(detphun *gP)
{
    int    iX, iY ;
    
    for(iY = 0; iY < gP->yDim; iY++) {
        for(iX = 0; iX < gP->xDim; iX++) {
            gP->Z1[iY][iX] = sumComplexDouble(gP->Z1[iY][iX], gP->Z2[iY][iX]) ;
        }
    }
}


void multZ1PIQx(detphun *gP)
{
    int    iX, iY ;
    
    for(iY = 0; iY < gP->yDim; iY++) {
        for(iX = 0; iX < gP->xDim; iX++) {
            gP->Z1[iY][iX] = multComplexDouble(gP->Z1[iY][iX], gP->xPhaseShift[iX]) ;
        }
    }
}


void multZ2PIQy(detphun *gP)
{
    int    iX, iY ;
    
    for(iY = 0; iY < gP->yDim; iY++) {
        for(iX = 0; iX < gP->xDim; iX++) {
            gP->Z2[iY][iX] = multComplexDouble(gP->Z2[iY][iX], gP->yPhaseShift[iY]) ;
        }
    }
}


void multZ1Qx(detphun *gP)
{
    int    iX, iY ;
    
    for(iY = 0; iY < gP->yDim; iY++) {
        for(iX = 0; iX < gP->xDim; iX++) {
            gP->Z1[iY][iX] = mRComplexDouble(gP->Z1[iY][iX], gP->qx[iX]) ;
        }
    }
}


void multZ2Qy(detphun *gP)
{
    int    iX, iY ;
    
    for(iY = 0; iY < gP->yDim; iY++) {
        for(iX = 0; iX < gP->xDim; iX++) {
            gP->Z2[iY][iX] = mRComplexDouble(gP->Z2[iY][iX], gP->qy[iY]) ;
        }
    }
}

void multOutPQ2(detphun *gP)
{
    int    iX, iY ;
    
    for(iY = 0; iY < gP->yDim2; iY++) {
        for(iX = 0; iX < gP->xDim2; iX++) {
            gP->output[iY][iX] *= gP->pq2[iY][iX] ;
        }
    }
}


void divOutPQ2(detphun *gP)
{
    int    iX, iY ;
    
    for(iY = 0; iY < gP->yDim2; iY++) {
        for(iX = 0; iX < gP->xDim2; iX++) {
            gP->output[iY][iX] /= (gP->pq2[iY][iX])? gP->pq2[iY][iX] : 1. ;
        }
    }
}


void multOutCosPhi(detphun *gP)
{
    int    iX, iY ;
    
    for(iY = 0; iY < gP->yDim2; iY++) {
        for(iX = 0; iX < gP->xDim2; iX++) {
            gP->output[iY][iX] *= gP->cosPhi[iY][iX] ;
        }
    }
}


void multOutSinPhi(detphun *gP)
{
    int    iX, iY ;
    
    for(iY = 0; iY < gP->yDim2; iY++) {
        for(iX = 0; iX < gP->xDim2; iX++) {
            gP->output[iY][iX] *= gP->sinPhi[iY][iX] ;
        }
    }
}

void multOutCst(detphun *gP, double factor)
{
    int    iX, iY ;
    
    for(iY = 0; iY < gP->yDim2; iY++) {
        for(iX = 0; iX < gP->xDim2; iX++) {
            gP->output[iY][iX] *= factor ;
        }
    }
}


void evaluateXGradient(detphun *gP)
{
    int iX, iY ;
    float coh ;
    complexDouble *Z ;
    
    Z = vectorComplexDouble(0, gP->xDim - 1) ;
    for(iY = 0; iY < gP->yDim; iY++) {
        for(iX = 0; iX < gP->xDim - 1; iX++) {
            coh = (gP->coh[iY][iX] + gP->coh[iY][iX + 1]) / 2. ;

            /* X derivative of wrapped phase 1 */
            Z[iX].r = (unwrappedPhaseGap((float)gP->Z1[iY][iX + 1].r, (float)gP->Z1[iY][iX].r)) ;
            Z[iX].i = 0. ;
            Z[iX].r = (coh  > gP->coherenceThreshold)? Z[iX].r : 0 ;
        }
        Z[iX].r = Z[iX - 1].r ;

        memcpy(gP->Z1[iY], Z, gP->xDim * sizeof(complexDouble)) ;
    }
    freeVectorComplexDouble(Z, 0) ;
}

void evaluateYGradient(detphun *gP)
{
    int iX, iY ;
    float coh ;
    complexDouble *Z ;

    Z = vectorComplexDouble(0, gP->yDim - 1) ;
    for(iX = 0; iX < gP->xDim; iX++) {
        for(iY = 0; iY < gP->yDim - 1; iY++) {
            coh = (gP->coh[iY][iX] + gP->coh[iY + 1][iX]) / 2. ;

            /* Y derivative of wrapped phase */
            Z[iY].r = (unwrappedPhaseGap((float)gP->Z2[iY + 1][iX].r, (float)gP->Z2[iY][iX].r)) ;
            Z[iY].i = 0. ;
            Z[iY].r = (coh  > gP->coherenceThreshold)? Z[iY].r : 0 ;

        }
        Z[iY].r = Z[iY - 1].r ;
        
        for(iY = 0; iY < gP->yDim; iY++) {
            gP->Z2[iY][iX].r = Z[iY].r ;
        }
    }
    freeVectorComplexDouble(Z, 0) ;
}


void transferDataToZ(detphun *gP)
{
    int iX, iY ;
    double *zeros ;
    
    if (gP->mode == 1) {
        for(iY = 0; iY < gP->yDim; iY++) {
            for(iX = 0; iX < gP->xDim; iX++) {
                gP->Z1[iY][iX].r = gP->Z2[iY][iX].r = (double)gP->currentPhase[iY][iX] ;
                //            gP->Z1[iY][iX].r = gP->Z2[iY][iX].r = exp(-(pow((iX - gP->xDim/2.)/10., 2.) + pow((iY - gP->yDim/2.)/5., 2.))) ;
                gP->Z1[iY][iX].i = gP->Z2[iY][iX].i = 0. ;
            }
        }
    }
    
    /* FFTW */
    if (gP->mode == 2) {
        zeros = vectorDouble(0, gP->xDim2 - 1) ;
        for(iY = 0; iY < gP->yDim; iY++) {
            memcpy(gP->sinPhi[iY], zeros, gP->xDim2 * sizeof(double)) ;
            memcpy(gP->cosPhi[iY], zeros, gP->xDim2 * sizeof(double)) ;
            for(iX = 0; iX < gP->xDim; iX++) {
                if (gP->coh[iY][iX] > gP->coherenceThreshold) {
                    gP->sinPhi[iY][iX] = sin(gP->currentPhase[iY][iX]) ;
                    gP->cosPhi[iY][iX] = cos(gP->currentPhase[iY][iX]) ;
                }
                else {
                    gP->cosPhi[iY][iX] = gP->sinPhi[iY][iX] = 0 ;
                }
            }
        }
        for(; iY < gP->yDim2; iY++) {
            memcpy(gP->sinPhi[iY], zeros, gP->xDim2 * sizeof(double)) ;
            memcpy(gP->cosPhi[iY], zeros, gP->xDim2 * sizeof(double)) ;
        }
        freeVectorDouble(zeros, 0) ;
    }

    /* Mirroring */
/*
    for(iY = decY; iY < gP->yDim + decY; iY++) {
        for(iX = 0; iX < decX; iX++) {
            gP->Z1[iY][decX - iX - 1] = gP->Z2[iY][decX - iX - 1] = gP->Z1[iY][decX + iX] ;
            gP->Z1[iY][decX + gP->xDim + iX] = gP->Z2[iY][decX + gP->xDim + iX] = gP->Z1[iY][decX + gP->xDim - iX - 1] ;
        }
    }
    for(iY = 0; iY < decY; iY++) {
        memcpy(gP->Z1[decY - iY - 1], gP->Z1[decY + iY], gP->xDim2 * sizeof(complexFloat)) ;
        memcpy(gP->Z1[decY + gP->yDim + iY], gP->Z1[decY + gP->yDim - iY - 1], gP->xDim2 * sizeof(complexFloat)) ;
        memcpy(gP->Z2[decY - iY - 1], gP->Z2[decY + iY], gP->xDim2 * sizeof(complexFloat)) ;
        memcpy(gP->Z2[decY + gP->yDim + iY], gP->Z2[decY + gP->yDim - iY - 1], gP->xDim2 * sizeof(complexFloat)) ;
    }
*/
    
    /* Circularization */
/*
     for(iY = decY; iY < gP->yDim + decY; iY++) {
         for(iX = 0; iX < decX; iX++) {
             gP->Z1[iY][decX + gP->xDim + iX] = gP->Z2[iY][decX + gP->xDim + iX] = gP->Z1[iY][decX + iX] ;
             gP->Z1[iY][iX] = gP->Z2[iY][iX] = gP->Z1[iY][gP->xDim + iX] ;
         }
     }
     for(iY = 0; iY < decY; iY++) {
         memcpy(gP->Z1[decY + gP->yDim + iY], gP->Z1[decY + iY], gP->xDim2 * sizeof(complexFloat)) ;
         memcpy(gP->Z1[iY], gP->Z1[gP->yDim + iY], gP->xDim2 * sizeof(complexFloat)) ;
         memcpy(gP->Z2[decY + gP->yDim + iY], gP->Z2[decY + iY], gP->xDim2 * sizeof(complexFloat)) ;
         memcpy(gP->Z2[iY], gP->Z2[gP->yDim + iY], gP->xDim2 * sizeof(complexFloat)) ;
     }
*/
    
    /* Zeros */
/*
     xPhase.r = xPhase.i = 0. ;
     for(iY = decY; iY < gP->yDim + decY; iY++) {
         for(iX = 0; iX < decX; iX++) {
             gP->Z1[iY][iX] = gP->Z2[iY][iX] = xPhase ;
             gP->Z1[iY][decX + gP->xDim + iX] = gP->Z2[iY][decX + gP->xDim + iX] = xPhase ;
         }
     }
     aNullLine = vectorComplexFloat(0, gP->xDim2) ;
     for(iX = 0; iX < gP->xDim; iX++)
         aNullLine[iX] = xPhase ;
     
     for(iY = 0; iY < decY; iY++) {
         memcpy(gP->Z1[iY], aNullLine, gP->xDim2 * sizeof(complexFloat)) ;
         memcpy(gP->Z1[decY + gP->yDim + iY], aNullLine, gP->xDim2 * sizeof(complexFloat)) ;
         memcpy(gP->Z2[iY], aNullLine, gP->xDim2 * sizeof(complexFloat)) ;
         memcpy(gP->Z2[decY + gP->yDim + iY], aNullLine, gP->xDim2 * sizeof(complexFloat)) ;
     }
     freeVectorComplexFloat(aNullLine, 0) ;
*/
}


detphun *allocAndInitDetphunWithWindowSize(int xDim, int yDim, int unsigned flag)
{
    int        i, iX, iY ;
    detphun    *gP ;
    float dphix, dphiy ;
    double q2 ;
    
    if((gP = (detphun *)malloc(sizeof(detphun))) == NULL) {
        ase("Fail to allocate detPhUn global pointer") ;
    }
    
    gP->mode = (flag & _DETPHUN2_)? 2 : 1 ;
    gP->xDim = xDim ;
    gP->yDim = yDim ;
    gP->xDim2 = ceil2ofIntVal(xDim) ;
    gP->yDim2 = ceil2ofIntVal(yDim) ;
    gP->xDim2 = xDim ;
    gP->yDim2 = yDim ;
    gP->iterationNumber = 1 ;
    dphix = dphiy = 0. ;
    
    if (gP->mode == 1) {
        gP->Z1 = matrixComplexDouble(0, gP->yDim - 1, 0, gP->xDim - 1) ;
        printf("Init FFTW complex forward plan\n") ;
        gP->FFTPlanZ1 = fftw_plan_dft_2d(gP->yDim, gP->xDim, (fftw_complex *)gP->Z1[0], (fftw_complex *)gP->Z1[0], FFTW_FORWARD, FFTW_MEASURE) ;
        printf("Init FFTW complex backward plan\n") ;
        gP->IFFTPlanZ1 = fftw_plan_dft_2d(gP->yDim, gP->xDim, (fftw_complex *)gP->Z1[0], (fftw_complex *)gP->Z1[0], FFTW_BACKWARD, FFTW_MEASURE) ;
        gP->Z2 = matrixComplexDouble(0, gP->yDim - 1, 0, gP->xDim - 1) ;
        printf("Init FFTW second complex forward plan\n") ;
        gP->FFTPlanZ2 = fftw_plan_dft_2d(gP->yDim, gP->xDim, (fftw_complex *)gP->Z2[0], (fftw_complex *)gP->Z2[0], FFTW_FORWARD, FFTW_MEASURE) ;
        printf("Init FFTW secondcomplex backward plan\n") ;
        gP->IFFTPlanZ2 = fftw_plan_dft_2d(gP->yDim, gP->xDim, (fftw_complex *)gP->Z2[0], (fftw_complex *)gP->Z2[0], FFTW_BACKWARD, FFTW_MEASURE) ;
        
        gP->xPhaseShift = vectorComplexDouble(0, gP->xDim - 1) ;
        gP->qx = vectorDouble(0, gP->xDim - 1) ;
        gP->qx2 = vectorDouble(0, gP->xDim - 1) ;
        
        for(i = 0; i < gP->xDim / 2; i++) gP->qx[i] = (float)i / (float)gP->xDim + dphix ;
        for(; i < gP->xDim; i++) gP->qx[i] = (float)(i - gP->xDim) / (float)gP->xDim - dphix ;
        for(i = 0; i < gP->xDim; i++) {
            //        gP->qx[i] += dphix ;
            gP->xPhaseShift[i].r =  cos(PI * gP->qx[i]) ;
            gP->xPhaseShift[i].i = -sin(PI * gP->qx[i]) ;
            gP->qx2[i] = pow(gP->qx[i], 2.) ;
        }
        
        gP->yPhaseShift = vectorComplexDouble(0, gP->yDim - 1) ;
        gP->qy = vectorDouble(0, gP->yDim - 1) ;
        gP->qy2 = vectorDouble(0, gP->yDim - 1) ;
        
        for(i = 0; i < gP->yDim / 2; i++) gP->qy[i] = (float)i / (float)gP->yDim + dphiy ;
        for(; i < gP->yDim; i++) gP->qy[i] = (float)(i - gP->yDim) / (float)gP->yDim - dphiy ;
        for(i = 0; i < gP->yDim; i++) {
            //        gP->qy[i] += dphiy ;
            gP->yPhaseShift[i].r =  cos(PI * gP->qy[i]) ;
            gP->yPhaseShift[i].i = -sin(PI * gP->qy[i]) ;
            gP->qy2[i] = pow(gP->qy[i], 2.) ;
        }
    }
    else {
        gP->sinPhi = matrixDouble(0, gP->yDim2 - 1, 0, gP->xDim2  - 1) ;
        gP->cosPhi = matrixDouble(0, gP->yDim2 - 1, 0, gP->xDim2  - 1) ;
        gP->temp1 = matrixDouble(0, gP->yDim2 - 1, 0, gP->xDim2  - 1) ;
        gP->temp2 = matrixDouble(0, gP->yDim2 - 1, 0, gP->xDim2  - 1) ;
        gP->pq2 = matrixDouble(0, gP->yDim2 - 1, 0, gP->xDim2  - 1) ;
        gP->input = matrixDouble(0, gP->yDim2 - 1, 0, gP->xDim2  - 1) ;
        gP->output = gP->input ;
        printf("Init FFTW real forward plan\n") ;
        gP->FFTPlan = fftw_plan_r2r_2d(gP->yDim2, gP->xDim2, gP->input[0], gP->input[0], FFTW_REDFT00, FFTW_REDFT00, FFTW_MEASURE) ;
        printf("Init FFTW real backward plan\n") ;
        gP->IFFTPlan = fftw_plan_r2r_2d(gP->yDim2, gP->xDim2, gP->input[0], gP->input[0], FFTW_REDFT00, FFTW_REDFT00, FFTW_MEASURE) ;

        for(iY = 0; iY < gP->yDim2; iY++) {
            q2 = pow((double)iY / (double)gP->yDim2, 2) ;
            for(iX = 0; iX < gP->xDim2; iX++) {
                gP->pq2[iY][iX] = pow((double)iX / (double)gP->xDim2, 2) + q2 ;
            }
        }
    }

    
    return gP ;
}


void freeDetPhun(detphun *gP)
{
    if (gP->mode == 1) {
        freeVectorDouble(gP->qx, 0) ;
        freeVectorDouble(gP->qy, 0) ;
        freeVectorDouble(gP->qx2, 0) ;
        freeVectorDouble(gP->qy2, 0) ;
        freeVectorComplexDouble(gP->xPhaseShift, 0) ;
        freeVectorComplexDouble(gP->yPhaseShift, 0) ;
        freeMatrixComplexDouble(gP->Z1, 0, 0) ;
        freeMatrixComplexDouble(gP->Z2, 0, 0) ;
    }
    else {
        freeMatrixDouble(gP->cosPhi, 0, 0) ;
        freeMatrixDouble(gP->sinPhi, 0, 0) ;
        freeMatrixDouble(gP->input, 0, 0) ;
//        freeMatrixDouble(gP->output, 0, 0) ;
        fftw_destroy_plan(gP->FFTPlan) ;
        
    }
}

void resetDetphun(detphun *gP)
{
    int i ;
    float *zero ;
    
    if (gP->mode == 1) {
        resetZ(gP) ;
    }
    zero = vectorFloat(0, gP->xDim - 1) ;
    for(i = 0; i < gP->xDim; i++)
        zero[i] = 0. ;
    
    for(i = 0; i < gP->yDim; i++) {
        memcpy(gP->dephi[i], zero, gP->xDim * sizeof(float)) ;
        //        memcpy(gP->data[i], zero, gP->xDim) ;
    }
    
    freeVectorFloat(zero, 0) ;
}

void resetZ(detphun *gP)
{
    int i ;
    complexDouble *zero ;
    
    zero = vectorComplexDouble(0, gP->xDim - 1) ;
    for(i = 0; i < gP->xDim; i++)
        zero[i].r = zero[i].i = 0. ;
    for(i = 0; i < gP->yDim; i++) {
        memcpy(gP->Z1[i], zero, gP->xDim * sizeof(complexFloat)) ;
        memcpy(gP->Z2[i], zero, gP->xDim * sizeof(complexFloat)) ;
    }
    freeVectorComplexDouble(zero, 0) ;
}


void removePhasePlane(detphun *gP)
{
    int    xDim, yDim, xDimCoh, yDimCoh, iX0, iY0 ;
    int xDimBloc, yDimBloc, deltaX, deltaY, nBlocX, nBlocY ;
    int i, j, k, l, iX, iY ;
    int    *index ;
    float **DEM, **coh, zVal ;
    float norm ;
    float excludingValue ;
    double **M, *V, signe ;
    
    xDim = xDimCoh = gP->xDim ;
    yDim = yDimCoh = gP->yDim ;
    genFloatNaN() ;
    excludingValue = floatNaN ;
    
    DEM = gP->dephi ;
    coh = gP->coh ;

    index = vectorInt(1, 3) ;
    M = matrixDouble(1, 3, 1, 3) ;
    V = vectorDouble(1, 3) ;
    
    for(i = 1; i <= 3; i++) {
        for(j = 1; j <= 3; j++) {
            M[i][j] = 0.0 ;
        }
        V[i] = 0.0 ;
    }
    
    xDimBloc = yDimBloc = 41 ;
    do {
        xDimBloc = xDimBloc / 2 + 1 ;
        nBlocX = xDim / xDimBloc ;
    } while(nBlocX <= 1) ;
    
    do {
        yDimBloc = yDimBloc / 2 + 1 ;
        nBlocY = yDim / yDimBloc ;
    } while(nBlocY <= 1) ;
    
    deltaX = (xDim - nBlocX * xDimBloc)/(nBlocX - 1) ;
    deltaY = (yDim - nBlocY * yDimBloc)/(nBlocY - 1) ;
    iX0 = (deltaX)? 0 : (xDim - nBlocX * xDimBloc) / 2 ;
    iY0 = (deltaY)? 0 : (yDim - nBlocY * yDimBloc) / 2 ;
    
    for(i = 0; i < nBlocY; i++) {
        iY = i * (yDimBloc + deltaY) + yDimBloc/2 + iY0 ;
        for(j = 0; j < nBlocX; j++) {
            iX = j * (xDimBloc + deltaX) + xDimBloc/2 + iX0 ;
            zVal = norm = 0. ;
            for(k = -yDimBloc/2; k <= yDimBloc/2; k++) {
                for(l = -xDimBloc/2; l <= xDimBloc/2; l++) {
                    if (!areFloatValsEquals(DEM[iY + k][iX + l], excludingValue)) {
                        if (coh[iY + k][iX + l] > gP->coherenceThreshold) {
                            zVal += DEM[iY + k][iX + l] ;
                            norm++ ;
                        }
                    }
                }
            }
            if (norm) {
                zVal /= norm ;
                
                M[1][1] += pow((double)iX, 2.) ;
                M[1][2] += iX * iY ;
                M[1][3] += iX ;
                M[2][2] += pow((double)iY, 2.) ;
                M[2][3] += iY ;
                M[3][3]++ ;
                
                V[1] += iX * zVal ;
                V[2] += iY * zVal ;
                V[3] += zVal ;
            }
        }
    }
    for(i = 1; i <= 3; i++) {
        for(j = i + 1; j <= 3; j++) {
            M[j][i] = M[i][j] ;
        }
    }
    ludcmp(M, 3, index, &signe) ;
    lubksb(M, 3, index, V) ;
    
    printf("Removed plane: %9.5f X + %9.5f Y + %9.5f\n", V[1], V[2], V[3]);
    for(iY = 0; iY < yDim; iY++) {
        for(iX = 0; iX < xDim; iX++) {
            DEM[iY][iX] -= (float)(V[1] * iX + V[2] * iY + V[3]) ;
        }
    }
    
    freeMatrixDouble(M, 1, 1) ;
    freeVectorDouble(V, 1) ;
}
