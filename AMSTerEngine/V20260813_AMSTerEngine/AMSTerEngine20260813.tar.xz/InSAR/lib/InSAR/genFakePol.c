
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 * @file : genFakePol
 * @project genFakePol
 * @author Created by Dominique Derauw
 * @copyright ©2025 Dominique Derauw - SAREOS
 * @date : 2025-10-22
 * Description : ...
 */

#include "genFakePol.h"

int main(int argc, char *argv[])
{
    char *parametersFilePath = NULL, *aString, *aPath, missingPol[3] ;
    char *masterCrossPolLinkPath = NULL, *slaveCrossPolLinkPath = NULL ;
    char *masterInfoFilePath = NULL, *slaveInfoFilePath = NULL ;
    char *masterCoPolFilePath, *masterCrossPolFilePath, *masterMissingPolFilePath ;
    char *slaveCoPolFilePath, *slaveCrossPolFilePath, *slaveMissingPolFilePath ;
    char *RVoGTextFilePath, aFileName[5], *genericFileName, *extension ;
    int i, j, iX, iY, polComb = 0, polCombIndex, polComIndexMin, polComIndexMax ;
    int *sortIndex, NFiles ;
    int flag = 0 ;
    float **cohLines, **interfLines, Re, Im ;
    InSARParametersStruct    *pInSAR = NULL ;
    struct infoImage *slaveInfo = NULL, *masterInfo = NULL ;
    CSVStruct *csv = NULL, *availableMasterPol, *availableSlavePol ;
    CSVStruct *prods, *cohFileList = NULL, *interfFileList = NULL ;
    time_t startTime, endTime ;
    rawFileDescriptor *RVoGTextFile, **coh, **interf ;


    for (i = 0; i < argc; i++) {
        csv = addStringValInCSVStruct((char *)argv[i], csv) ;
    }
    
    if(isArgumentPresentInCSV(csv, "help") || isArgumentPresentInCSV(csv, "-h")) {
        genFakePolHelp() ;
    }

    i = 1 ;
    while (i < csv->numberOfEntries){
        if ((pInSAR = readInSARParametersFileAtPath(csv->stringVal[i]))) {
            parametersFilePath = initStringWithString(csv->stringVal[i]) ;
            break ;
        }
        i++ ;
    }
    if(!pInSAR) {
        parametersFilePath = initStringWithString("./TextFiles/InSARParameters.txt") ;
        if(!fileExistsAtPath(parametersFilePath)){
            free(parametersFilePath) ;
            genFakePolHelp() ;
        }
    }
    pInSAR = readInSARParametersFileAtPath(parametersFilePath) ;

    i = 1 ;
    while (i < csv->numberOfEntries){
        sscanf(csv->stringVal[i], "%d", &polComb) ;
        i++ ;
    }
    flag |= (isFlagPresentInCSV(csv, "-f"))? _ALL_COMB_ : flag ;


    if (!polComb && !(flag & _ALL_COMB_)) {
        genFakePolHelp() ;
    }
    
    time(&startTime) ;

    /* Check both master and slave images have the same polarization scheme */
    availableSlavePol = readCSVInString(pInSAR->slaveInfo->polMode) ;
    availableMasterPol = readCSVInString(pInSAR->masterInfo->polMode) ;
/*
    if (availableMasterPol->numberOfEntries != 2) {
        printf("\t-/-> Input images are not dual pol\n") ;
        genFakePolHelp() ;
    }
*/
    /* Order pol ending with cross pol scheme to be sure */
    if (strncmp(availableMasterPol->stringVal[0], availableMasterPol->stringVal[0] + 1, 1)) {
        aString = availableMasterPol->stringVal[0] ;
        availableMasterPol->stringVal[0] = availableMasterPol->stringVal[1] ;
        availableMasterPol->stringVal[1] = aString ;
    }
    if (strncmp(availableSlavePol->stringVal[0], availableSlavePol->stringVal[0] + 1, 1)) {
        aString = availableSlavePol->stringVal[0] ;
        availableSlavePol->stringVal[0] = availableSlavePol->stringVal[1] ;
        availableSlavePol->stringVal[1] = aString ;
    }
    if (strncmp(availableMasterPol->stringVal[0], availableSlavePol->stringVal[0], 2) || strncmp(availableMasterPol->stringVal[1], availableSlavePol->stringVal[1], 2)) {
        printf("\t-/-> Master and slave image do not have the same polarization scheme\n") ;
        genFakePolHelp() ;
    }
    
    if (strncmp(availableMasterPol->stringVal[0], "V", 1)) {
        sprintf(missingPol, "VV") ;
    }
    else {
        sprintf(missingPol, "HH") ;
    }

    masterCoPolFilePath = initStringWith3Strings(pInSAR->masterImage->dataDirectoryPath, "/SLCData.", availableMasterPol->stringVal[0]) ;
    masterCrossPolFilePath = initStringWith3Strings(pInSAR->masterImage->dataDirectoryPath, "/SLCData.", availableMasterPol->stringVal[1]) ;
    masterMissingPolFilePath = initStringWith3Strings(pInSAR->masterImage->dataDirectoryPath, "/SLCData.", missingPol) ;
    slaveCoPolFilePath = initStringWith3Strings(pInSAR->interpolatedSlave->dataDirectoryPath, "/SLCData.", availableSlavePol->stringVal[0]) ;
    slaveCrossPolFilePath = initStringWith3Strings(pInSAR->interpolatedSlave->dataDirectoryPath, "/SLCData.", availableSlavePol->stringVal[1]) ;
    slaveMissingPolFilePath = initStringWith3Strings(pInSAR->interpolatedSlave->dataDirectoryPath, "/SLCData.", missingPol) ;
    
    printf("Available polarisations: %s\n", pInSAR->masterInfo->polMode) ;
    printf("Polarization linear combination: \n") ;
    polComIndexMax = polComIndexMin = polComb ;
    if (flag & _ALL_COMB_) {
        polComIndexMin = 1 ;
        polComIndexMax = 3 ;
    }
/*
    for (polCombIndex = polComIndexMin; polCombIndex <= polComIndexMax; polCombIndex++) {
        printf("Master image fake pol generation\n") ;
        switch (polCombIndex) {
            case 1:
            printf("%s = (%s + %s) / 2\n", missingPol, availableMasterPol->stringVal[0], availableMasterPol->stringVal[1]) ;
            rawFilesArithmetics(.5, masterCoPolFilePath, "+", .5, masterCrossPolFilePath, masterMissingPolFilePath, _CPLX32_ID_) ;
            printf("Slave image fake pol generation\n") ;
            rawFilesArithmetics(.5, slaveCoPolFilePath, "+", .5, slaveCrossPolFilePath, slaveMissingPolFilePath, _CPLX32_ID_) ;
            break;
            
            case 2:
            printf("%s = %s + 2%s\n", missingPol, availableMasterPol->stringVal[0], availableMasterPol->stringVal[1]) ;
            rawFilesArithmetics(1, masterCoPolFilePath, "+", 2, masterCrossPolFilePath, masterMissingPolFilePath, _CPLX32_ID_) ;
            printf("Slave image fake pol generation\n") ;
            rawFilesArithmetics(1, slaveCoPolFilePath, "+", 2, slaveCrossPolFilePath, slaveMissingPolFilePath, _CPLX32_ID_) ;
            break;
            
            case 3:
            printf("%s = sqrt(2) %s\n", missingPol, availableMasterPol->stringVal[1]) ;
            rawFilesArithmetics(sqrtf(2), masterCrossPolFilePath, "+", 0, NULL, masterMissingPolFilePath, _CPLX32_ID_) ;
            printf("Slave image fake pol generation\n") ;
            rawFilesArithmetics(sqrtf(2), slaveCrossPolFilePath, "+", 0, NULL, slaveMissingPolFilePath, _CPLX32_ID_) ;
            break;
            
            default:
            genFakePolHelp() ;
            break;
        }
        
        /* Link cross pol to SLCData.XX to allow coherence optimization */
/*
        masterCrossPolLinkPath = initStringWith2Strings(pInSAR->masterImage->dataDirectoryPath, "/SLCData.XX") ;
        symlink(masterCrossPolFilePath, masterCrossPolLinkPath) ;
        slaveCrossPolLinkPath = initStringWith2Strings(pInSAR->interpolatedSlave->dataDirectoryPath, "/SLCData.XX") ;
        symlink(slaveCrossPolFilePath, slaveCrossPolLinkPath) ;
*/        
        
        /* Add fake pol to available polarization schemes */
/*        addStringValInCSVStruct(missingPol, availableMasterPol) ;
        masterInfoFilePath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/masterSLCImageInfo.txt") ;
        masterInfo = readInfoImageFromTextFile(masterInfoFilePath) ;
        sprintf(masterInfo->polMode, "%.2s, %.2s, %.2s", availableMasterPol->stringVal[0], availableMasterPol->stringVal[1], missingPol) ;
        saveInfoImage(masterInfo, masterInfoFilePath) ;
        addStringValInCSVStruct(missingPol, availableSlavePol) ;
        slaveInfoFilePath = initStringWith2Strings(pInSAR->whereAmI, "/TextFiles/slaveSLCImageInfo.txt") ;
        slaveInfo = readInfoImageFromTextFile(slaveInfoFilePath) ;
        sprintf(slaveInfo->polMode, "%.2s, %.2s, %.2s", availableSlavePol->stringVal[0], availableSlavePol->stringVal[1], missingPol) ;
        saveInfoImage(slaveInfo, slaveInfoFilePath) ;
*/        
        /* Compute interferometric combinations */
/*        addStringValInCSVStruct("-a", csv) ;
        InSARProductsGeneration(csv) ;
*/        
        /* Re read pInSAR to get correct file dimensions */
/*        freeInSARParametersStruct(pInSAR) ;
        pInSAR = readInSARParametersFileAtPath(parametersFilePath) ;
*/        
        /* Rename interferometric combination with respect to pol scheme */
/*        aPath = initStringWith2Strings(pInSAR->whereAmI, "InSARProducts") ;
        genericFileName = initStringWithString(getPointerToFileNameInPath(pInSAR->coh.filePath)) ;
        stripExtensionAtEndOfPath(genericFileName) ;
        prods = listFilesWithNameInDir(genericFileName, aPath) ;
        for (i = 0; i < prods->numberOfEntries; i++) {
            extension = getPointerToFileExtensionInPath(prods->stringVal[i]) ;
            if (strncmp(extension, missingPol, 2)) {
                sprintf(accessPath, "%s/InSARProducts/c0.%.2s", pInSAR->whereAmI, extension) ;
            }
            else {
                sprintf(accessPath, "%s/InSARProducts/c0.XX%.1d", pInSAR->whereAmI, polCombIndex) ;
            }
            rename(prods->stringVal[i], accessPath) ;
        }
        freeCSVStruct(prods) ;
        free(genericFileName) ;
        
        genericFileName = initStringWithString(getPointerToFileNameInPath(pInSAR->interf.filePath)) ;
        stripExtensionAtEndOfPath(genericFileName) ;
        prods = listFilesWithNameInDir(genericFileName, aPath) ;
        for (i = 0; i < prods->numberOfEntries; i++) {
            extension = getPointerToFileExtensionInPath(prods->stringVal[i]) ;
            if (strncmp(extension, missingPol, 2)) {
                sprintf(accessPath, "%s/InSARProducts/i0.%.2s", pInSAR->whereAmI, extension) ;
            }
            else {
                sprintf(accessPath, "%s/InSARProducts/i0.XX%.1d", pInSAR->whereAmI, polCombIndex) ;
            }
            rename(prods->stringVal[i], accessPath) ;
        }
        freeCSVStruct(prods) ;
        free(genericFileName) ;
        free(aPath) ;
*/        
        
        /* Perform coherence optimization */
//        PolInSARProductsGeneration(csv) ;
        
        /* Rename optimized coherence and interferograms with respect to fake pol scheme */
/*        aPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/optimizedCoherence.c1") ;
        sprintf(accessPath, "%s/InSARProducts/c1.XX%.1d", pInSAR->whereAmI, polCombIndex) ;
        rename(aPath, accessPath) ;
        free(aPath) ;
        aPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/optimizedCoherence.c2") ;
        sprintf(accessPath, "%s/InSARProducts/c2.XX%.1d", pInSAR->whereAmI, polCombIndex) ;
        rename(aPath, accessPath) ;
        free(aPath) ;
        aPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/optimizedCoherence.c3") ;
        sprintf(accessPath, "%s/InSARProducts/c3.XX%.1d", pInSAR->whereAmI, polCombIndex) ;
        rename(aPath, accessPath) ;
        free(aPath) ;
        
        aPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/optimizedInterferogram.i1") ;
        sprintf(accessPath, "%s/InSARProducts/i1.XX%.1d", pInSAR->whereAmI, polCombIndex) ;
        rename(aPath, accessPath) ;
        free(aPath) ;
        aPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/optimizedInterferogram.i2") ;
        sprintf(accessPath, "%s/InSARProducts/i2.XX%.1d", pInSAR->whereAmI, polCombIndex) ;
        rename(aPath, accessPath) ;
        free(aPath) ;
        aPath = initStringWith2Strings(pInSAR->whereAmI, "/InSARProducts/optimizedInterferogram.i3") ;
        sprintf(accessPath, "%s/InSARProducts/i3.XX%.1d", pInSAR->whereAmI, polCombIndex) ;
        rename(aPath, accessPath) ;
        free(aPath) ;
*/        
        /* Restore initial info image text files */
/*        sprintf(masterInfo->polMode, "%.2s, %.2s", availableMasterPol->stringVal[0], availableMasterPol->stringVal[1]) ;
        saveInfoImage(masterInfo, masterInfoFilePath) ;
        sprintf(slaveInfo->polMode, "%.2s, %.2s", availableSlavePol->stringVal[0], availableSlavePol->stringVal[1]) ;
        saveInfoImage(slaveInfo, slaveInfoFilePath) ;
    }
*/
    /* List coherence and interferometric files */
    aPath = initStringWith2Strings(pInSAR->whereAmI, "InSARProducts") ;
    for ( j = 0; j < 4; j++) {
        /* List coherence and interf files */
        sprintf(aFileName, "c%.1d.", j) ;
        prods = listFilesWithNameInDir(aFileName, aPath) ;
        cohFileList = concatenateCSVStructs(prods, cohFileList) ;
        freeCSVStruct(prods) ;
        
        sprintf(aFileName, "i%.1d.", j) ;
        prods = listFilesWithNameInDir(aFileName, aPath) ;
        interfFileList = concatenateCSVStructs(prods, interfFileList) ;
        freeCSVStruct(prods) ;
    }
    
    /* Sort file list in ascending order */
    NFiles = cohFileList->numberOfEntries ;
    sortIndex = vectorInt(0, NFiles - 1) ;
    sortStringVect(cohFileList->stringVal, sortIndex, NFiles, _ASCENDING_SORT_) ;
    sortStringVect(interfFileList->stringVal, sortIndex, NFiles, _ASCENDING_SORT_) ;

    /* Filter complex phase */
    if (fileExistsAtPath(pInSAR->coh.filePath)) {
        unlink(pInSAR->coh.filePath) ;    
    }
    if (fileExistsAtPath(pInSAR->interf.filePath)) {
        unlink(pInSAR->interf.filePath) ;    
    }
    addStringValInCSVStruct("-i", csv) ;
    addStringValInCSVStruct("-c", csv) ;

    for ( i = 0; i < NFiles; i++) {
        if (i == 2)
        {
            removeStringValAtIndexInCSVStruct(csv->numberOfEntries - 1, csv) ;
        }
        
        symlink(interfFileList->stringVal[i], pInSAR->interf.filePath) ;
        symlink(cohFileList->stringVal[i], pInSAR->coh.filePath) ;

        interferogramFiltering(csv) ;
        unlink(interfFileList->stringVal[i]) ;
        rename(pInSAR->filter.filePath, interfFileList->stringVal[i]) ;
        unlink(pInSAR->interf.filePath) ;
        if (i < 2) {
            unlink(cohFileList->stringVal[i]) ;
            aPath = initStringWith2Strings(pInSAR->coh.filePath, ".f") ;
            rename(aPath, cohFileList->stringVal[i]) ;
            free(aPath) ;
        }
        unlink(pInSAR->coh.filePath) ;
    }
    unlink(pInSAR->coh.filePath) ;    
    unlink(pInSAR->interf.filePath) ;    

    
    /* Generate RVoG text file */
    RVoGTextFilePath = initStringWith2Strings(pInSAR->whereAmI, "TextFiles/RVoG.txt") ;
    RVoGTextFile = openRawFileForReadingAndWritingAtPath(RVoGTextFilePath) ;

    /* Open coherence files */
    coh = malloc(NFiles * sizeof(coh[0])) ;
    for ( i = 0; i < NFiles; i++) {
        coh[i] = openRawFileForReadingAndWritingAtPath(cohFileList->stringVal[i]) ;
    }

    /* Open interf files */
    interf = malloc(NFiles * sizeof(interf[0])) ;
    for ( i = 0; i < NFiles; i++) {
        interf[i] = openRawFileForReadingAndWritingAtPath(interfFileList->stringVal[i]) ;
    }

    /* Alloc coherence and interf rows */
    cohLines = matrixFloat(0, NFiles, 0, pInSAR->coh.lenr - 1) ;
    interfLines = matrixFloat(0, NFiles, 0, pInSAR->coh.lenr - 1) ;

    /* Generate RVoG text file */
    sprintf(aComment, "  X\t  Y") ;
    for (i = 0; i < NFiles; i++) {
        sprintf(aComment, "%s\t%s\t%s", aComment, getPointerToFileNameInPath(cohFileList->stringVal[i]), getPointerToFileNameInPath(interfFileList->stringVal[i])) ;
    }
    fprintf(RVoGTextFile->f, "%s\n", aComment) ;

    for (iY = 0; iY < pInSAR->coh.lena; iY++) {
        for (i = 0; i < NFiles; i++) {
            fread(cohLines[i], pInSAR->coh.lenr, sizeof(float), coh[i]->f) ;
            fread(interfLines[i], pInSAR->coh.lenr, sizeof(float), interf[i]->f) ;
        }
            
        for (iX = 0; iX < pInSAR->coh.lenr; iX++) {
            sprintf(aComment, "%d\t%d", iX, iY) ;
            for (i = 0; i < NFiles; i++) {
                sprintf(aComment, "%s\t%5.3f\t%5.3f", aComment, cohLines[i][iX], interfLines[i][iX]) ;
            }
            fprintf(RVoGTextFile->f, "%s\n", aComment) ;
        }
    }

    /* Free what must be freed */
    freeMatrixFloat(cohLines, 0, 0) ;
    freeMatrixFloat(interfLines, 0, 0) ;
    for ( i = 0; i < NFiles; i++) {
        freeRawFileDescriptor(coh[i]) ;
        freeRawFileDescriptor(interf[i]) ;
    }
    free(coh) ;
    free(interf) ;
    
    freeCSVStruct(cohFileList) ;
    freeCSVStruct(interfFileList) ;

    free(RVoGTextFilePath) ;
    freeRawFileDescriptor(RVoGTextFile) ;

    /* remove links and fake pol files */
    if (masterCrossPolLinkPath) {
	unlink(masterCrossPolLinkPath) ; 
    }
    unlink(masterMissingPolFilePath) ;
    if (slaveCrossPolLinkPath) {
	unlink(slaveCrossPolLinkPath) ; 
    }    unlink(slaveMissingPolFilePath) ;

    free(masterCoPolFilePath) ;
    free(masterCrossPolFilePath) ;
    free(masterMissingPolFilePath) ;
    free(slaveCoPolFilePath) ;
    free(slaveCrossPolFilePath) ;
    free(slaveMissingPolFilePath) ;

    free(masterInfoFilePath) ;
    free(slaveInfoFilePath) ;
    free(masterCrossPolLinkPath) ;
    free(slaveCrossPolLinkPath) ;

    freeInfoImage(masterInfo) ;
    freeInfoImage(slaveInfo) ;

    freeCSVStruct(csv) ;
    freeCSVStruct(availableMasterPol) ;
    freeCSVStruct(availableSlavePol) ;

    freeVectorInt(sortIndex, 0) ;

    free(parametersFilePath) ;

    return 0 ;
}

void genFakePolHelp()
{
    printf("\ngenFakePol N\nUsage:\n") ;
    printf("genFakePol is meant at generating a third fake polarisation scheme from dual pol images to then generate all possible interferograms and corresponding coherence images\n") ;
    printf("Three linear combinations are proposed:\n") ;
    printf("Considering e.g. available pols are VV, VH\n") ;
    printf("N = 1: (VV + VH)/2 ---> HH = XX1\n") ;
    printf("N = 2:  VV + 2VH)  ---> HH = XX2\n") ;
    printf("N = 3: sqrt(2)VH   ---> HH = XX3\n") ;
    printf("XXi will be used as code to rename optimized coherence and interferograms\n") ;
    printf("\n") ;
    exit (0) ;
}
