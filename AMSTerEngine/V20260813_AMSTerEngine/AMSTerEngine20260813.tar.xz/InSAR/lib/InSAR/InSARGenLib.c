
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  InSARGenLib.c
//  InSARProductsGeneration
//
//  Created by Dominique Derauw on 1/09/15.
//  Copyright (c) 2015 Dominique Derauw. All rights reserved.
//

#include "InSARGenLib.h"


/* main programm start */
int InSARProductsGeneration(CSVStruct *csv)
{
    char *parametersFilePath = NULL, InSARParametersFileFound ;
    char *imageFileName ;
    int   currentDirectoryFdesc, workingDirectoryFileDesscriptor, i, j ;
    int ETADFlags ;
    div_t qr ;
    InSARParametersStruct    *pInSAR ;
    time_t startTime, endTime ;
    CSVStruct *pol1, *pol2 ;
    polygon *aoi ;
    
    InSARParametersFileFound = 0 ;
    currentDirectoryFdesc = open(".", O_RDONLY) ;
    
    if(isArgumentPresentInCSV(csv, "help") || isArgumentPresentInCSV(csv, "-h")) {
        InSARGenHelp() ;
    }
    
    i = 1 ;
    while (i < csv->numberOfEntries) {
        parametersFilePath = initStringWithString(csv->stringVal[i]) ;
        if(fileExistsAtPath(parametersFilePath)) {
            InSARParametersFileFound = 1 ;
            break ;
        }
        i++ ;
        free(parametersFilePath) ;
    }
    if(!InSARParametersFileFound) {
        parametersFilePath = initStringWithString("./TextFiles/InSARParameters.txt") ;
        if(!fileExistsAtPath(parametersFilePath)){
            free(parametersFilePath) ;
            parametersFilePath = initStringWithString("./InSARParameters.txt") ;
            if(!fileExistsAtPath(parametersFilePath)) {
                InSARGenHelp() ;
            }
        }
        InSARParametersFileFound = 1 ;
    }
    pInSAR = readInSARParametersFileAtPath(parametersFilePath) ;
    time(&startTime) ;

    workingDirectoryFileDesscriptor = open(pInSAR->whereAmI, O_DIRECTORY) ;
    fchdir(workingDirectoryFileDesscriptor) ;
        
    /* Initializing multi thread */
    maxThreads = numberOfThreads() ;

    
    pInSAR->flag |= (isFlagPresentInCSV(csv, "H"))? FIRST_ORDER_TPOGRAPHIC_PHASE_APPROXIMATION : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "s"))? COMPUTE_STADARD_DEVIATION : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "N"))? pInSAR->flag : FLAT_EARTH_PHASE_REMOVAL ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "i"))? COMPUTE_LOCAL_INCIDENCE_ANGLE : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "n"))? pInSAR->flag : WITH_FILTERING ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "m"))? _WITH_MASKING_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "w"))? _WITH_WEIGHTING_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "c"))? _NORMALIZED_COH_ : pInSAR->flag ;
    pInSAR->flag |= (isArgumentPresentInCSV(csv, "+ETAD"))? _SAVE_ETAD_LAYERS_ : pInSAR->flag ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "r"))? _RESAMPLE_FLOAT_FILES_ : pInSAR->flag ;

    /* Check first if float file resampling with respect to existing process is requested */
    if (pInSAR->flag & _RESAMPLE_FLOAT_FILES_) {
        printf("\n\t---> resampling of slant range float files on existing InSAR processing is requested\n") ;
        resampleFloatFiles(pInSAR) ;
        return (0) ;
    }
    

    /* We recompute the area of interest */
    /* Recomputing it allows performing processing with a different kml than the one use at initialisation if any */
    if (fileExistsAtPath(pInSAR->aoiKml)) {
        computeCommonSuperpositionOfImages(pInSAR) ;
    }
    

    printf("\nInterferometric products computation:\n") ;
    i = (i = isArgumentPresentInCSV(csv, "-ETAD"))? i : isArgumentPresentInCSV(csv, "+ETAD") ;
    if (i && pInSAR->masterInfo->sensorID == __SENTINEL1__) {
        if (isETADPresentInCSLImage(pInSAR->masterImage) && isETADPresentInCSLImage(pInSAR->slaveImage)) {
            aoi = getCopyOfPolygon(pInSAR->aoi) ;
            j = 0 ;
            sscanf(csv->stringVal[i] + 5, "%d", &j) ;
            if (strlen(csv->stringVal[i]) > 5) {   
                qr = div(j, 10) ;
                ETADFlags = (qr.rem)? _ETAD_TROPOSPHERIC_CORRECTION_RG_ : 0 ;
                qr = div(qr.quot, 10) ;
                ETADFlags |= (qr.rem)? _ETAD_GEODETIC_CORRECTION_RG_ : 0 ;
                qr = div(qr.quot, 10) ;
                ETADFlags |= (qr.rem)? _ETAD_IONOSPHERIC_CORRECTION_RG_ : 0 ;
            }
            else {
                ETADFlags = _ETAD_TROPOSPHERIC_CORRECTION_RG_ | _ETAD_GEODETIC_CORRECTION_RG_ | _ETAD_IONOSPHERIC_CORRECTION_RG_ ;
//                ETADFlags = _ETAD_TROPOSPHERIC_CORRECTION_RG_ | _ETAD_GEODETIC_CORRECTION_RG_ | _ETAD_IONOSPHERIC_CORRECTION_RG_ | _ETAD_SUM_OF_CORRECTIONS_AZ_;
            }

            printf("\t---> Loading requested ETAD layers\n") ;
            free(pInSAR->masterInfo) ;
            pInSAR->masterInfo = mergeFrameInfo(pInSAR->masterImage, NULL) ;
            free(pInSAR->slaveInfo) ;
            pInSAR->slaveInfo = mergeFrameInfo(pInSAR->slaveImage, NULL) ;
            initInSAR_GEO(pInSAR, _KEEPAOI_) ;
            InSARBurstSelection(pInSAR) ;
            pInSAR->interpolatedSlaveInfo = pInSAR->slaveInfo ;
            initPerBurstTransforms(pInSAR) ;
            
            loadETADLayersIntoBursts(pInSAR->masterInfo, ETADFlags | _ETAD_HEIGHT_) ;
            loadETADLayersIntoBursts(pInSAR->interpolatedSlaveInfo, ETADFlags | _ETAD_HEIGHT_) ;
            pInSAR->flag |= _ETAD_CORRECTION_ ;
            pInSAR->flag2 = ETADFlags ;
            printf("\n") ;

            /* Restore requested aoi */
            freePolygon(pInSAR->aoi) ;
            pInSAR->aoi = aoi ;
        }
    }
    
    pInSAR->averageBeta0CalibrationConstant = 237 ;
    pInSAR->flag |= (isFlagPresentInCSV(csv, "C"))? _CALIBRATE_IN_SIGMA0_ : pInSAR->flag ;
    if ((i = isArgumentPresentInCSV(csv, "C="))) {
        sscanf(csv->stringVal[i] + 2, "%lf", &pInSAR->averageBeta0CalibrationConstant) ;
        pInSAR->flag |= _CALIBRATE_IN_SIGMA0_ ;
    }
    if ((i = isArgumentPresentInCSV(csv, "P="))) {
        sscanf(csv->stringVal[i] + 2, "%2s", pInSAR->masterPolarizationChannel) ;
        sscanf(csv->stringVal[i] + 2, "%2s", pInSAR->slavePolarizationChannel) ;
        modifyFileExtensionsWithRespectToSelectedPolarization(pInSAR) ;
    }
    pInSAR->flag |= _VERBOSE_ ;
    
    /* If adaptation of area of interest with respect to super master is requested, proceed */
    if (isFlagPresentInCSV(csv, "o") && pInSAR->SM2MpInSAR) {
        freePolygon(pInSAR->aoi) ;
        pInSAR->aoi = getCopyOfPolygon(pInSAR->SM2MpInSAR->aoi) ;
        if (pInSAR->aoi->P[2].x >= MIN(pInSAR->masterInfo->rangeDimension, pInSAR->slaveInfo->rangeDimension)) {
            pInSAR->aoi->P[2].x = pInSAR->aoi->P[1].x = MIN(pInSAR->masterInfo->rangeDimension, pInSAR->slaveInfo->rangeDimension) - 1 ;
        }
        if (pInSAR->aoi->P[2].y >= MIN(pInSAR->masterInfo->azimuthDimension, pInSAR->slaveInfo->azimuthDimension)) {
            pInSAR->aoi->P[2].y = pInSAR->aoi->P[3].y = MIN(pInSAR->masterInfo->azimuthDimension, pInSAR->slaveInfo->azimuthDimension) -1 ;
        }
    }
    saveInSARParametersFileAtPath(pInSAR, parametersFilePath) ;
   
    /* If requesting for InSAR processing of all layers, do so */
    if (isFlagPresentInCSV(csv, "a")) {
        pol1 = readCSVInString(pInSAR->masterInfo->polMode) ;
        pol2 = readCSVInString(pInSAR->slaveInfo->polMode) ;
        for (i = 0; i < pol1->numberOfEntries; i++) {
            for (j = 0; j < pol2->numberOfEntries; j++) {
                /* select common pols only */
                if (!strncmp(pol1->stringVal[i], pol2->stringVal[j], 2)) {
                    /* Verify both images are available */
                    imageFileName = initStringWith2Strings("SLCData.", pol1->stringVal[i]) ;
                    if (isFilePresentInCSLImage(pInSAR->masterImage, imageFileName) && isFilePresentInCSLImage(pInSAR->interpolatedSlave, imageFileName)) {
                        free(pInSAR->masterPolarizationChannel) ;
                        free(pInSAR->slavePolarizationChannel) ;
                        pInSAR->masterPolarizationChannel = initStringWithString(pol1->stringVal[i]) ;
                        pInSAR->slavePolarizationChannel = initStringWithString(pol2->stringVal[i]) ;
                        modifyFileExtensionsWithRespectToSelectedPolarization(pInSAR) ;
                        insicohmod(pInSAR) ;
                    }
                    free(imageFileName) ;
                }
            }
        }
        /* Restore initial pol scheme */
        pInSAR->masterPolarizationChannel = initStringWithString(pol1->stringVal[0]) ;
        pInSAR->slavePolarizationChannel = initStringWithString(pol2->stringVal[0]) ;
        modifyFileExtensionsWithRespectToSelectedPolarization(pInSAR) ;
        freeCSVStruct(pol1) ;
        freeCSVStruct(pol2) ;
    }
    else {
        insicohmod(pInSAR) ;
//        computeInSARProducts(pInSAR) ;
    }
    /* Resample slant range float files with respect to just performed INSAR process */
    resampleFloatFiles(pInSAR) ;

    saveInSARParametersFileAtPath(pInSAR, parametersFilePath) ;

    if (pInSAR->masterInfo->sensorSpecificInfo) {
        freeS1Specific(pInSAR->masterInfo->sensorSpecificInfo, _S1_FREE_BURSTS_) ;
        freeS1Specific(pInSAR->slaveInfo->sensorSpecificInfo, _S1_FREE_BURSTS_) ;
        pInSAR->interpolatedSlaveInfo = NULL ;
    }
    free(parametersFilePath) ;
    freeInSARParametersStruct(pInSAR) ;
    time(&endTime) ;
    duration(startTime, endTime) ;
    fchdir(currentDirectoryFdesc) ;
    
    return(0) ;
}


void InSARGenHelp()
{
    printf("\nUsage:\nInSARProductGeneration [/pathTo/InSARParameters.txt] [-nsNima] [-ETAD] [-ETADiii]\n") ;
    printf("\nThe InSARProductGeneration routine will compute all interferometric products:\n") ;
    printf("Amplitude images, interfergram, filtered interferogram and coherence image.\n");
    printf("Options:\n") ;
    printf("\t-n: Filtered version of the interferogram is not generated (Filtering applied to full resolution interferogram before box averaging).\n") ;
    printf("\t-s: Computation of phase and height estimated standard deviations\n") ;
    printf("\t-o: If master to super master processing is considered, area of interest is copied from this processing.\n") ;
    printf("\t-N: No flat Earth phase removal\n") ;
    printf("\t-i: Computation of local and geoidal incidence angles. Local incidence angle map is given in radian while geoidal one is given in degrees.\n") ;
    printf("\t-m: If a slant range mask is present, coherence and intrferogram will be masked correspondingly\n") ;
    printf("\tP=XX: XX polarisation scheme is considered (with XX being one of [VV, HH, VH, HV].\n") ;
    printf("\t-a: All available polarisation scheme are considered.\n") ;
    printf("\t-C: Approximate amplitude image calibration in terms of sigma0 in case of Sentinel1 InSAR. \n\tIf external DEM present within master image, calibration will take it into account.\n") ;
    printf("\t-ETAD: If dealing with Sentinel1 data and if ETAD data is present within both master and slave images, ETAD-corrected phase is computed considering all required layers.\n") ;    
    printf("\t-ETADiii: If willing to select used layers, use binary notation with iii = _ETAD_IONOSPHERIC_CORRECTION_RG_ | _ETAD_GEODETIC_CORRECTION_RG_ | _ETAD_TROPOSPHERIC_CORRECTION_RG_.\n") ;   
    printf("\t eg -ETAD001 for tropospheric correction only.\n") ; 
    printf("\nIf used with no parameters, the routine will look for an \"InSARparameters.txt\".\n") ;
    printf("file within the working directory or within the ./TextFiles subdirectory.\n") ;
    printf("Any other path to a text file containing InSAR parameters can be given as\nfirst parameter.\n\n") ;
    exit(0) ;
}


void computeInSARProducts(InSARParametersStruct *pInSAR)
{
    int rangeReductionFactor, azimuthReductionFactor, squareSpiralSize ;
    size_t xWindowSize, yWindowSize ;
    size_t xTileIndex, yTileIndex ;
    size_t xTileSize, yTileSize, xTileBorderSize, yTileBorderSize ;
    size_t reducedXTileSize, reducedYTileSize, reducedProductsXSize, reducedProductsYSize ;
    tileTool *master, *slave ;
    tileTool *interfero, *reducedInterfero ;
    progressCounter *aCounter ;
        
    
    /* Open master image */
    openMasterImageForReading(pInSAR) ;
    
    /* Open slave image */
    openSlaveImageForReading(pInSAR) ;

    /* Moving and box average dimensions */
    yWindowSize = (pInSAR->coh).coa ;
    xWindowSize = (pInSAR->coh).cor ;
    squareSpiralSize = (pInSAR->coh).spi ;
    azimuthReductionFactor = (pInSAR->red).Faz ;
    rangeReductionFactor = (pInSAR->red).Fra ;

    
    /* Create output files */
    squareSpiralSize = 0 ;
    reducedProductsXSize = ((pInSAR->aoi->P[2].x - pInSAR->aoi->P[0].x + 1) - (squareSpiralSize - 1) - (xWindowSize - 1)) / rangeReductionFactor ;
    reducedProductsYSize = ((pInSAR->aoi->P[2].y - pInSAR->aoi->P[0].y + 1) - (squareSpiralSize - 1) - (yWindowSize - 1)) / azimuthReductionFactor ;
    
    if((pInSAR->coherenceFile = openRawFileForWritingAtPath((pInSAR->coh).filePath)) == NULL) {
        ase("Failed to open/create coherence image file\n") ;
    }
    
    if((pInSAR->interferogramFile = openRawFileForWritingAtPath((pInSAR->interf).filePath)) == NULL) {
        ase("Failed to open/create interferogram image file\n") ;
    }
    pInSAR->interferogramFile->xDim = reducedProductsXSize ;
    pInSAR->interferogramFile->yDim = reducedProductsYSize ;
    
    if((pInSAR->filteredInterferogramFile = openRawFileForWritingAtPath((pInSAR->filter).filePath)) == NULL) {
        ase("Failed to open/create filtered interferogram image file\n") ;
    }

    if((pInSAR->masterAmplitudeImageFile = openRawFileForWritingAtPath((pInSAR->mod1).filePath)) == NULL) {
        ase("Failed to open master amplitude image file\n") ;
    }
    
    if((pInSAR->slaveAmplitudeImageFile = openRawFileForWritingAtPath((pInSAR->mod2).filePath)) == NULL) {
        ase("Failed to open slave amplitude image file\n") ;
    }
    

    /* Default tile dimensions */
    xTileSize = yTileSize = 512 ;
    xTileBorderSize = yTileBorderSize = 16 ;
    
    /* Border size must almost be biger than half the moving window size */
    xTileBorderSize = (xTileBorderSize < (xWindowSize + squareSpiralSize) / 2)? xWindowSize : xTileBorderSize ;
    yTileBorderSize = (yTileBorderSize < (yWindowSize + squareSpiralSize) / 2)? yWindowSize : yTileBorderSize ;
    
    /* We recompute tile borders so that the effective area is always a multiple of the reduction factors */
    reducedXTileSize = 2 * ((xTileSize - 2 * xTileBorderSize) / rangeReductionFactor / 2) ;
    reducedYTileSize = 2 * ((yTileSize - 2 * yTileBorderSize) / azimuthReductionFactor / 2) ;
    xTileBorderSize = (xTileSize - rangeReductionFactor * reducedXTileSize) / 2 ;
    yTileBorderSize = (yTileSize - azimuthReductionFactor * reducedYTileSize) / 2 ;
    
    /* Alloc and init master tile tool */
    master = allocTileToolForFilesOfType(pInSAR->masterImageFile, NULL, "complexFloat") ;
    initTileToolWithSizes(master, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    setMirroringForTileTool(master) ;
    
    /* Alloc and init slave tile tool */
    slave = allocTileToolForFilesOfType(pInSAR->slaveImageFile, NULL, "complexFloat") ;
    initTileToolWithSizes(slave, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    setMirroringForTileTool(slave) ;
    
    /* Alloc and init interferogram tile tool */
    interfero = allocTileToolForFilesOfType(pInSAR->masterImageFile, pInSAR->coherenceFile, "complexFloat") ;
    initTileToolWithSizes(interfero, xTileSize, yTileSize, xTileBorderSize, yTileBorderSize) ;
    reducedInterfero = allocTileToolForFilesOfType(NULL, pInSAR->interferogramFile, "float") ;
    initTileToolWithSizes(reducedInterfero, reducedXTileSize, reducedYTileSize, 0, 0) ;

    /* Loop on tiles */
    aCounter = initProgressCounterWithMinMaxValue(0, master->yTileNumber * master->xTileNumber - 1) ;
    for (yTileIndex = 0; yTileIndex < master->yTileNumber; yTileIndex++) {
        for (xTileIndex = 0; xTileIndex < master->xTileNumber; xTileIndex++) {
            readTileAtIndexes(master, xTileIndex, yTileIndex) ;
            readTileAtIndexes(slave, xTileIndex, yTileIndex) ;
            
            computeInterferogramTile(interfero, master, slave, pInSAR) ;
            boxAveragingOfInterferogramTile(interfero, reducedInterfero, rangeReductionFactor, azimuthReductionFactor) ;
            
            updateTileToolForIndexes(reducedInterfero, xTileIndex, yTileIndex) ;
            writeTile(reducedInterfero) ;

            updateProgressCounterForIndex(aCounter, yTileIndex * master->xTileNumber + xTileIndex) ;
        }
    }
    updateProgressCounterForIndex(aCounter, yTileIndex * master->xTileNumber + xTileIndex) ;

}



void computeInterferogramTile(tileTool *interf, tileTool *master, tileTool *slave, InSARParametersStruct *pInSAR)
{
    int iX0, iY0 ;
    size_t iX, iY ;
    double rangePosition, azimuthPosition ;
    complexFloat *interfLine, **masterTile, **slaveTile, **interfTile, complexOrbitalPhase ;
    mAvObject *mAvInterf ;
    
    mAvInterf = allocMovingAverageObject() ;
    initMovingAverageObject("complexFloat", pInSAR->coh.cor, pInSAR->coh.coa, master->xTileSize, master->yTileSize, mAvInterf) ;
    interfLine = vectorComplexFloat(0, master->xTileSize) ;
    masterTile = (complexFloat **)master->tile ;
    slaveTile = (complexFloat **)slave->tile ;
    interfTile = (complexFloat **)interf->tile ;
    
    iX0 = pInSAR->coh.cor / 2 ;
    iY0 = pInSAR->coh.coa / 2 ;
    for (iY = 0; iY < master->yTileSize; iY++) {
        azimuthPosition = (double)(master->y0In - master->y0Tile + iY) ;
        for (iX = 0; iX < master->xTileSize; iX++) {
            rangePosition = (double)(master->x0In - master->x0Tile + iX) ;
            complexOrbitalPhase = complexOrbitalPhaseAtPoint(rangePosition, azimuthPosition, pInSAR) ;
            interfLine[iX] = mC(masterTile[iY][iX], cC(slaveTile[iY][iX])) ;
            interfLine[iX] = mC(interfLine[iX], cC(complexOrbitalPhase)) ;
        }
        addNextLineInMovingAverage(interfLine, mAvInterf) ;
        if (iY > (size_t)(pInSAR->coh.coa - 1)) {
            memcpy(&interfTile[iY0++][iX0], getMovingAverage(mAvInterf), mAvInterf->outputRect.dimX * mAvInterf->sizeOfType) ;
        }
    }
    
    freeMovingAverageObject(mAvInterf) ;
}

void boxAveragingOfInterferogramTile(tileTool *complexInterferogramTileTool, tileTool *reducedInterferogramTileTool, int xReductionFactor, int yReductionFactor)
{
    int k, l ;
    size_t iX, iY, xIndex, yIndex ;
    float **reducedInterf ;
    complexFloat **complexInterf, complexPhase ;
    
    complexInterf = (complexFloat **)complexInterferogramTileTool->tile ;
    reducedInterf = (float **)reducedInterferogramTileTool->tile ;
    
    for (iY = 0; iY < reducedInterferogramTileTool->yTileSize; iY++) {
        for (iX = 0; iX < reducedInterferogramTileTool->xTileSize; iX++) {
            complexPhase.r = complexPhase.i = 0. ;
            yIndex = iY * yReductionFactor ;
            for (k = 0; k < yReductionFactor; k++) {
                xIndex = iX * xReductionFactor ;
                for (l = 0; l < xReductionFactor; l++) {
                    complexPhase.r += complexInterf[yIndex][xIndex].r ;
                    complexPhase.i += complexInterf[yIndex][xIndex++].i ;
                }
                yIndex++ ;
            }
            reducedInterf[iY][iX] = phiC(complexPhase) ;
        }
    }
}



