
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678*/
/* Program conex20.c                        */
/* Author : DERAUW D. , Centre Spatial de Liege              */

/*
Conexion des résidus en commençant par le résidus de plus haute cohérence. On en recherche le seuil de cohérence permettant de trouver une chaine de résidus complète. La conexion des résidus au sein d'une meme chaine se fait dans l'ordre de détection.
*/

#include "conex28.h"

/* global variables declaration */
    int dimY, dimX ;
    unsigned char *firstPtrRes ;
    integrationPathStartingPoint *integrationStartingPoint ;

    int Npdd0 = 1000, ajok ;
    unsigned char resplus=2, resmoin=0, rien=1, conex0=3, conexb=4 ;
    unsigned short *coherenceScale, seuilmin, maxshort ;
    struct chaine *ptr_dchaine ;
    connexionStartingPoint    *ptr_first_pdd ;

/* main programm start */
void residuesConnexion(InSARParametersStruct *pInSAR)
{
	/* local variables declaration */
    char *maskPath ;
	unsigned char	ok, dok, test1, s, ts ;
	unsigned char	**residue, **mask ;
    unsigned short	seuil, test2 = 0 ;
	unsigned short **coherence ;
	int	i0, j0, i, j, bord, charge, stop, ra, rr, dra, drr, ramin=1, rrmin=1 ;
	long	Npdd, Nres, Nrest, Ldec ;
	float	tf1, seuil_f, seuilsuiv ;
	float	**floatCoh ;
	struct	chaine	*ptr_chaine,*ptr_schaine, *ptr_ichaine, *ptr_ochaine ;
	connexionStartingPoint	*ptr_pdd ;
    rawFileDescriptor *maskFile ;

	dimY = (pInSAR->cohder).lena ;
	dimX = (pInSAR->cohder).lenr ;
	seuil_f = (pInSAR->conex).seuilnet ;
	dra = (pInSAR->conex).dra ;
	drr = (pInSAR->conex).drr ;
	ramin = (pInSAR->conex).ramin ;
	rrmin = (pInSAR->conex).rrmin ;
	maxshort = ((unsigned short)(pInSAR->conex).ech < 65534)? (unsigned short)(pInSAR->conex).ech : 10000 ;
	ts = (unsigned char)(pInSAR->conex).ts ;
	seuilsuiv = (pInSAR->conex).seuilsuiv ;
	(pInSAR->conex).lena = dimY - 1 ;
	(pInSAR->conex).lenr = dimX - 1 ;

	/* ------------------------------- memory allocation --------------------------------------*/
	floatCoh = matrixFloat(0, 1, 0, dimX - 1) ;
	coherence = matrixShortUnsigned(0, (pInSAR->conex).lena - 1, 0, (pInSAR->conex).lenr - 1) ;
	residue = matrixUChar(0, (pInSAR->res).lena - 1, 0, (pInSAR->res).lenr - 1) ;

	if ((ptr_first_pdd = (connexionStartingPoint *)calloc (2 * Npdd0 + 2, sizeof(connexionStartingPoint))) == NULL) {
		ase("Failed to allocate starting points") ;
	}

	/* ------------------- Read coherence image and convert it in short values ------------------- */
    if(!pInSAR->biasedCoherenceFile) {
        if((pInSAR->biasedCoherenceFile = openRawFileForReadingAtPath((pInSAR->cohder).filePath)) ==NULL)
            ase("Failed to open biased coherence image file for reading\n") ;
    }
	for(i = 0; i < dimY - 1; i++) {
		Ldec = (long)(i * dimX) * sizeof(float) ;
		fseek(pInSAR->biasedCoherenceFile->f, Ldec, 0) ;
		fread (floatCoh[0], sizeof(float), 2 * dimX, pInSAR->biasedCoherenceFile->f) ;
		for(j = 0; j < dimX - 1; j++) {
			tf1 = (floatCoh[0][j] + floatCoh[0][j + 1] + floatCoh[1][j] + floatCoh[1][j + 1]) / 4. ;
			coherence[i][j] = (unsigned short)((float)maxshort*tf1) ;
		}
	}
	freeMatrixFloat(floatCoh, 0, 0) ;
	coherenceScale = coherence[0] ;

	/* ------------------- Read residue image ------------------- */
	dimY = dimY - 1 ;
	dimX = dimX - 1 ;
    if(!pInSAR->residuesFile) {
        if((pInSAR->residuesFile = openRawFileForReadingAtPath((pInSAR->res).filePath)) ==NULL)
            ase("Failed to open residue image file\n") ;
    }
	fread(residue[0], sizeof(unsigned char), dimY * dimX, pInSAR->residuesFile->f) ;
	firstPtrRes = residue[0] ;

	/* Open connexion image file */
    if(!pInSAR->connexionsFile) {
        if((pInSAR->connexionsFile = openRawFileForWritingAtPath((pInSAR->conex).filePath)) ==NULL)
            ase("Failed to create connexions image file\n") ;
    }

	/* Move residues up to the closest and smallest coherence position */
	mincohres() ;

	/* ------------------- Allocation de mémoire du debut de la pile ------------------- */

	if ((integrationStartingPoint = (integrationPathStartingPoint *)calloc (1, sizeof(integrationPathStartingPoint))) == NULL)
	{
		sprintf (ertex, "Erreur d'allocation sur ptr_pile") ;
		ase (ertex) ;
	}
	integrationStartingPoint->suiv = (integrationPathStartingPoint *)NULL ;

	/* ------------------- Allocation de mémoire du debut de la chaine ------------------- */

	if ((ptr_dchaine = (struct chaine *)calloc (1, sizeof(struct chaine))) == NULL)
	{
		sprintf (ertex, "Erreur d'allocation sur ptr_chaine") ;
		ase (ertex) ;
	}
	ptr_dchaine->suiv = (struct chaine *)NULL ;
	ptr_schaine = ptr_dchaine ;

	printf("Residues connexion\n") ;
	printf("******************\n") ;
	printf("Biased coherence file%s\n", pInSAR->biasedCoherenceFile->accessPath) ;
	printf("Residues file%s\n", pInSAR->residuesFile->accessPath) ;
	printf("Cleaning coherence threshold: %f\n", seuil_f) ;
	printf("False residues coherence threshold: %f\n", seuilsuiv) ;
	printf("Coherence scale: 0 --> %d\n", maxshort) ;
	freeRawFileDescriptor(pInSAR->biasedCoherenceFile) ;
	pInSAR->biasedCoherenceFile = NULL ;
	freeRawFileDescriptor(pInSAR->residuesFile) ;
	pInSAR->residuesFile = NULL ;

	Npdd = Npdd0 ;

	seuilmin = (unsigned short)(maxshort*seuil_f) ;
	bordcoh(&seuilmin) ;

    if (pInSAR->additionalParameters != NULL) {
        maskPath = getStringValForKeyIn(pInSAR->additionalParameters, "Mask") ;
        if (maskPath != NULL) {
            if ((maskFile = openRawFileForReadingAtPath(maskPath)) != NULL) {
                printf("\nResidue masking. Used mask: %s\n\n", maskPath) ;
                mask = matrixUChar(0, (pInSAR->res).lena - 1, 0, (pInSAR->res).lenr - 1) ;
                if (!fread(mask[0], sizeof(unsigned char), dimY * dimX, maskFile->f)) {
                    ase("Failed to read residue mask") ;
                }
                for (i = 0; i < dimY; i++) {
                    for (j = 0; j < dimX; j++) {
                        if (!mask[i][j]) {
                            residue[i][j] = conexb ;
                        }
                    }
                }
                freeMatrixUChar(mask, 0, 0) ;
                freeRawFileDescriptor(maskFile) ;
            }
        }
    }

	comptage(&Nres) ;
	Nrest = Nres ;

	seuilmin = (unsigned short)(maxshort*seuilsuiv) ;
	printf("Residues still to be connected:\n") ;
	ptr_pdd = ptr_first_pdd ;
	rescohmax() ;
	stop = ptr_pdd->az ;
	while(stop) {
		Npdd-- ;
		i0 = ptr_pdd->az ;
		j0 = ptr_pdd->ra ;
		if((residue[i0][j0] == resmoin) || (residue[i0][j0] == resplus)) {
			if(((Nres + 100) < Nrest) || (Nres < 100)) {
				seuil = coherence[i0][j0] ;
				printf("%-ld     %-f \r", Nres, (float)seuil/maxshort) ;
				Nrest = Nres ;
				fflush(stdout) ;
			}
			seuil = maxshort ;
			seuilmin = (unsigned short)(maxshort*seuilsuiv) ;
			seuilmin = (seuil < seuilmin)? seuil : seuilmin ;
			ok = 10 ;
			dok = 5 ;
			ajok = 1 ;
			bord = 0 ;
			ra = ramin ;
			rr = rrmin ;
			ptr_ichaine = ptr_schaine ;

			addIntegrationPathStartingPoint(i0, j0, 1) ;
			addIntegrationPathStartingPoint(i0, j0, 0) ;
			while(integrationStartingPoint->suiv != (integrationPathStartingPoint *)NULL) {
				if(integrationStartingPoint->hb ) bord = residuesUpSearch(&seuil, &ok, &dok, &i0, &j0, &ra, &rr, &test1, &test2, &bord) ;
				else bord = residuesDownSearch(&seuil, &ok, &dok, &i0, &j0, &ra, &rr, &test1, &test2, &bord) ;
			}
			addIntegrationPathStartingPoint(i0, j0, 1) ;
			addIntegrationPathStartingPoint(i0, j0, 0) ;
			while(integrationStartingPoint->suiv != (integrationPathStartingPoint *)NULL) {
				if(integrationStartingPoint->hb ) nethaut(&ok, &dok) ;
				else netbas(&ok, &dok) ;
			}
			calcharge(&charge) ;

			seuil = coherence[i0][j0] ;
			while((charge) && (!bord))
			{
				test1 = 1 ;
				s = ts ;
				while(test1)
				{
					test1 = 0 ;
					test2 = 0 ;
					do
					{
						ptr_chaine = ptr_ochaine = ptr_dchaine ;
						while(ptr_ochaine != ptr_ichaine)
						{
							i = ptr_ochaine->az ;
							if((i) && (i<dimY-1)) {
								j = ptr_ochaine->ra ;
								addIntegrationPathStartingPoint(i, j, 1) ;
								addIntegrationPathStartingPoint(i, j, 0) ;
								while(integrationStartingPoint->suiv != (integrationPathStartingPoint *)NULL) {
									if(integrationStartingPoint->hb ) bord = residuesUpSearch(&seuil, &ok, &dok, &i, &j, &ra, &rr, &test1, &test2, &bord) ;
									else bord = residuesDownSearch(&seuil, &ok, &dok, &i, &j, &ra, &rr, &test1, &test2, &bord) ;
								}
								addIntegrationPathStartingPoint(i, j, 1) ;
								addIntegrationPathStartingPoint(i, j, 0) ;
								while(integrationStartingPoint->suiv != (integrationPathStartingPoint *)NULL) {
									if(integrationStartingPoint->hb ) nethaut(&ok, &dok) ;
									else netbas(&ok, &dok) ;
								}
							}
							ptr_ochaine = ptr_ochaine->suiv ;
						}
						ptr_ichaine = ptr_chaine ;
						calcharge(&charge) ;
					}
					while((ptr_chaine != ptr_dchaine)) ;
					if(!test2) test1 = 1 ;
					if(ts) {
						if(((!charge) || (bord))) s-- ;
						else s = ts ;
						test1 *= s ;
					}

					ptr_ichaine = ptr_schaine ;
					if(bord) test1 = 0 ;
					ra += dra ;
					rr += drr ;
				}
				ra = ramin ;
				rr = rrmin ;
				seuil++ ;
				calcharge(&charge) ;
			}

			ok = 5 ;
			addIntegrationPathStartingPoint(i0, j0, 1) ;
			addIntegrationPathStartingPoint(i0, j0, 0) ;
			while(integrationStartingPoint->suiv != (integrationPathStartingPoint *)NULL)
			{
				if(integrationStartingPoint->hb ) nethaut(&ok, &dok) ;
				else netbas(&ok, &dok) ;
			}
			if(!charge) bord = 0 ;
			if(bord) ptr_dchaine->ch = -1*(charge) ;
			makeResidueConnection(&bord) ;
			decompte(&Nres) ;
			lib() ;
		}

		if(Npdd) {
			ptr_pdd++ ;
			stop = ptr_pdd->az ;
		}
		else {
			Npdd = Npdd0 ;
			rescohmax() ;
			ptr_pdd = ptr_first_pdd ;
		}
	}
	printf("\n") ;
	comptage(&Nres) ;
	seuilmin = 0 ;
	nettoyage(&seuilmin) ;

	sauvegarde(pInSAR->connexionsFile) ;
	printf("Connexion image file: %s\nDimensions: %-4d X %-4d\n", pInSAR->connexionsFile->accessPath, dimX, dimY) ;

	freeRawFileDescriptor(pInSAR->connexionsFile) ;
	pInSAR->connexionsFile = NULL ;

	freeMatrixShortUnsigned(coherence, 0, 0) ;
	freeMatrixUChar(residue, 0, 0) ;
	free(integrationStartingPoint) ;
	free(ptr_dchaine) ;
}

/*============================     FONCTIONS     ====================================================*/

/* ________________ recherche vers le bas ________________ */

int residuesDownSearch(unsigned short *ptr1, unsigned char *ptr2, unsigned char *ptr3, int *ptr_i, int *ptr_j, int *ptr_ra, int *ptr_rr, unsigned char *ptr_test1, unsigned short *ptr_test2, int *ptr_bord)
{
	unsigned char	*ptr_res, ok, ok1, p, dok, vtb, vth ;
	unsigned short	*ptr_coh, seuil ;
	int		j, i0, j0, tb, tb0 = 1, th, th0, stop, bord, ib, jg, jd ;
	integrationPathStartingPoint	*ptr_pile ;

	seuil = *ptr1 ;
	bord = *ptr_bord ;
	ok = *ptr2 ;
	dok = *ptr3 ;
	ok1 = (unsigned char)5 ;
	p = (unsigned char)1 ;
	ptr_pile = integrationStartingPoint ;
	i0 = ptr_pile->az ;
	j0 = ptr_pile->ra ;
	ib = *ptr_i - (int)(*ptr_ra * sqrt(1. - (double)(j0 - *ptr_j)*(j0 - *ptr_j)/(*ptr_rr * *ptr_rr))) ;
	integrationStartingPoint = ptr_pile->suiv ;
	free(ptr_pile) ;
	while((i0) && (tb0) && (i0>ib))
	{
		j = j0 ;
		ptr_coh = coherenceScale + i0*dimX + j ;
		ptr_res = firstPtrRes + i0*dimX + j ;
		vtb = (*(ptr_res-dimX)) + dok - ok ;
		tb = tb0 = (((*(ptr_coh-dimX) < seuil) && (*(ptr_res-dimX) < ok1)) || (vtb < ok1))? 1 : 0 ;
		vth = (*(ptr_res+dimX)) + dok - ok ;
		th = th0 = (((*(ptr_coh+dimX) < seuil) && (*(ptr_res+dimX) < ok1)) || (vth < ok1))? 1 : 0 ;
		stop = 1 ;
		if(*ptr_res == conexb)
		{
			achaine(i0, j, *ptr_res, &p) ;
			bord = 1 ;
		}
		vtb = *ptr_res - ok ;
		if(*ptr_res < ok1)
		{
			if((*ptr_coh < seuilmin) || (*ptr_res == resplus) || (*ptr_res == resmoin))
				achaine(i0, j, *ptr_res, &p) ;
			*ptr_res += ok ;
			if(*ptr_coh < seuil) *ptr_test1 = 1 ;
			*ptr_test2 = (*ptr_test2 < *ptr_coh)? *ptr_coh : *ptr_test2 ;
		}
		else *ptr_res += (vtb < ok1)? 0 : dok ;

		jg = *ptr_j - (int)(*ptr_rr * sqrt(1. - (double)(i0 - *ptr_i)*(i0 - *ptr_i)/(*ptr_ra * *ptr_ra))) ;
		jd = *ptr_j + (int)(*ptr_rr * sqrt(1. - (double)(i0 - *ptr_i)*(i0 - *ptr_i)/(*ptr_ra * *ptr_ra))) ;
		while((j<dimX-1) && (stop) && (j<jd))
		{
			j++ ;
			ptr_coh++ ;
			ptr_res++ ;
			propag(ptr_res, ptr_coh, &seuil, &ok1, &ok, &dok, &tb, &th, &stop, &i0, &j, &p, ptr_test1, ptr_test2, &bord) ;
		}
		if(j == dimX-1)
		{
			bord = 1 ;
			achaine(i0, j, conexb, &p) ;
		}

		j = j0 ;
		ptr_coh = coherenceScale + i0*dimX + j ;
		ptr_res = firstPtrRes + i0*dimX + j ;
		tb = tb0 ;
		th = th0 ;
		stop = 1 ;
		while((j) && (stop) && (j>jg))
		{
			j-- ;
			ptr_coh-- ;
			ptr_res-- ;
			propag(ptr_res, ptr_coh, &seuil, &ok1, &ok, &dok, &tb, &th, &stop, &i0, &j, &p, ptr_test1, ptr_test2, &bord) ;
		}
		if(!j)
		{
			bord = 1 ;
			achaine(i0, j, conexb, &p) ;
		}

		i0-- ;
	}
	if(!i0)
	{
		bord = 1 ;
		achaine(i0, j0, conexb, &p) ;
	}
	*ptr1 = seuil ;
	return (bord) ;
}


/* ________________ recherche vers le haut ________________ */

int residuesUpSearch(unsigned short *ptr1, unsigned char *ptr2, unsigned char *ptr3, int *ptr_i, int *ptr_j, int *ptr_ra, int *ptr_rr, unsigned char *ptr_test1, unsigned short *ptr_test2, int *ptr_bord)
{
	unsigned char	*ptr_res, ok, ok1,  p, dok, vtb, vth ;
	unsigned short	*ptr_coh, seuil ;
	int		j, i0, j0, th, th0 = 1, tb, tb0, stop, bord, ih, jg, jd ;
	integrationPathStartingPoint	*ptr_pile ;

	seuil = *ptr1 ;
	bord = *ptr_bord ;
	ok = *ptr2 ;
	dok = *ptr3 ;
	ok1 = (unsigned char)5 ;
	p = (unsigned char)1 ;
	ptr_pile = integrationStartingPoint ;
	i0 = ptr_pile->az ;
	j0 = ptr_pile->ra ;
	ih = *ptr_i + (int)(*ptr_ra * sqrt(1. - (double)(j0 - *ptr_j)*(j0 - *ptr_j)/(*ptr_rr * *ptr_rr))) ;

	integrationStartingPoint = ptr_pile->suiv ;
	free(ptr_pile) ;
	while((i0 < dimY-1) && (th0) && (i0<ih))
	{
		j = j0 ;
		ptr_coh = coherenceScale + i0*dimX + j ;
		ptr_res = firstPtrRes + i0*dimX + j ;
		vtb = (*(ptr_res-dimX)) + dok - ok ;
		tb = tb0 = (((*(ptr_coh-dimX) < seuil) && (*(ptr_res-dimX) < ok1)) || (vtb < ok1))? 1 : 0 ;
		vth = (*(ptr_res+dimX)) + dok - ok ;
		th = th0 = (((*(ptr_coh+dimX) < seuil) && (*(ptr_res+dimX) < ok1)) || (vth < ok1))? 1 : 0 ;
		stop = 1 ;
		if(*ptr_res == conexb)
		{
			achaine(i0, j, *ptr_res, &p) ;
			bord = 1 ;
		}

		vtb = *ptr_res - ok ;
		if(*ptr_res < ok1)
		{
			if((*ptr_coh < seuilmin) || (*ptr_res == resplus) || (*ptr_res == resmoin))
				achaine(i0, j, *ptr_res, &p) ;
			*ptr_res += ok ;
			if(*ptr_coh < seuil) *ptr_test1 = 1 ;
			*ptr_test2 = (*ptr_test2 < *ptr_coh)? *ptr_coh : *ptr_test2 ;
		}
		else *ptr_res += (vtb < ok1)? 0 : dok ;
		jg = *ptr_j - (int)(*ptr_rr * sqrt(1. - (double)(i0 - *ptr_i)*(i0 - *ptr_i)/(*ptr_ra * *ptr_ra))) ;
		jd = *ptr_j + (int)(*ptr_rr * sqrt(1. - (double)(i0 - *ptr_i)*(i0 - *ptr_i)/(*ptr_ra * *ptr_ra))) ;

		while((j<dimX-1) && (stop) && (j<jd))
		{
			j++ ;
			ptr_coh++ ;
			ptr_res++ ;
			propag(ptr_res, ptr_coh, &seuil, &ok1, &ok, &dok, &tb, &th, &stop, &i0, &j, &p, ptr_test1, ptr_test2, &bord) ;
		}
		if(j == dimX-1)
		{
			bord = 1 ;
			achaine(i0, j, conexb, &p) ;
		}

		j = j0 ;
		ptr_coh = coherenceScale + i0*dimX + j ;
		ptr_res = firstPtrRes + i0*dimX + j ;
		th = th0 ;
		tb = tb0 ;
		stop = 1 ;
		while((j) && (stop) && (j>jg))
		{
			j-- ;
			ptr_coh-- ;
			ptr_res-- ;
			propag(ptr_res, ptr_coh, &seuil, &ok1, &ok, &dok, &tb, &th, &stop, &i0, &j, &p, ptr_test1, ptr_test2, &bord) ;
		}
		if(!j)
		{
			bord = 1 ;
			achaine(i0, j, conexb, &p) ;
		}
		i0++ ;
	}
	if(i0 == dimY-1)
	{
		bord = 1 ;
		achaine(i0, j0, conexb, &p) ;
	}
	*ptr1 = seuil ;
	return (bord) ;
}


/* ________________ Ajout dans la pile ________________ */

void		addIntegrationPathStartingPoint(int i, int j, unsigned char sens)
{
	integrationPathStartingPoint	*ptr_pile ;

	ptr_pile = integrationStartingPoint ;
	if ((integrationStartingPoint = (integrationPathStartingPoint *)calloc (1, sizeof(integrationPathStartingPoint))) == NULL)
	{
		sprintf (ertex, "Erreur d'allocation sur ptr_pile") ;
		ase (ertex) ;
	}
	integrationStartingPoint->az = i ;
	integrationStartingPoint->ra = j ;
	integrationStartingPoint->hb = sens ;
	integrationStartingPoint->suiv = ptr_pile ;
}


/* ________________ Ajout dans la chaine ________________ */

void		achaine(int i, int j, unsigned char signe, unsigned char *ptr)
{
	struct chaine	*ptr_chaine ;

	if(ajok)
	{
		ptr_chaine = ptr_dchaine ;
		if ((ptr_dchaine = (struct chaine *)calloc (1, sizeof(struct chaine))) == NULL)
		{
			sprintf (ertex, "Erreur d'allocation sur ptr_chaine") ;
			ase (ertex) ;
		}
		ptr_dchaine->az = i ;
		ptr_dchaine->ra = j ;
		ptr_dchaine->s = signe ;
		ptr_dchaine->p = *ptr ;
		if(ptr_dchaine->s == resplus) ptr_dchaine->ch =  1 ;
		if(ptr_dchaine->s == resmoin) ptr_dchaine->ch = -1 ;
		ptr_dchaine->lien = ptr_dchaine->suiv = ptr_chaine ;
	}
	*ptr = (unsigned char)0 ;
	ajok = ((signe == conexb) || (!ajok))? 0 : 1 ;

/*
printf("chaine: %d\t%d\t%u\t%d\n", i, j, signe, ajok) ;
*/
}


/* ________________ Calcul de la charge d'une connexion ________________ */

void		calcharge(int *ptr)
{
	struct chaine	*ptr_chaine ;
	int		charge ;

	ptr_chaine = ptr_dchaine ;
	charge = (ptr_chaine->suiv != (struct chaine *)NULL)? 0 : 1 ;
	while(ptr_chaine->suiv != (struct chaine *)NULL)
	{
		if(ptr_chaine->s == resplus) charge++ ;
		if(ptr_chaine->s == resmoin) charge-- ;
		ptr_chaine = ptr_chaine->suiv ;

	}
	*ptr = charge ;
}


/* ________________ connexion d'une chaine de residus ________________ */

void	makeResidueConnection(int *ptr)
{
	struct chaine	*ptr_chaine, *ptr_schaine ;
	unsigned char	connexion ;
	int		id, jd, is, js ;

	connexion = (*ptr)? conexb : conex0 ;
	ptr_chaine = ptr_dchaine ;
	while((ptr_chaine->suiv)->suiv != (struct chaine *)NULL)
	{
		ptr_schaine = ptr_chaine->suiv ;
		ppv(&ptr_chaine, &ptr_schaine) ;
		ptr_chaine->lien = ptr_schaine ;
//		ptr_chaine->p = conex0 ;
		if(connexion == conex0)(ptr_chaine->lien)->ch += ptr_chaine->ch ;
		else ptr_chaine->ch = 1 ;
		ptr_chaine = ptr_chaine->suiv ;
	}

/*
        if(connexion == conexb) {
            ptr_chaine = ptr_dchaine ;
            while((ptr_chaine->ch) && (ptr_chaine->suiv)->suiv != (struct chaine *)NULL) {
                ptr_chaine->p = conexb ;
                ptr_chaine = ptr_chaine->lien ;
            }
        }
*/
/*
	ptr_chaine = ptr_dchaine ;
	while((ptr_chaine->suiv)->suiv != (struct chaine *)NULL) {
		if(!(ptr_chaine->sdp)) {
                    dseg = ptr_chaine ;
                    while((dseg->lien->sdp < 2) && (dseg->ch) && ((dseg->lien)->suiv != (struct chaine *)NULL)) {
                        seg = dseg->lien ;
                        if(connexion == conex0) seg->ch += dseg->ch ;
                        else dseg->ch = 1 ;
                        if(!seg->ch) seg->lien->sdp-- ;
                        dseg = seg ;
                    }
                }
                ptr_chaine = ptr_chaine->suiv ;
	}
*/
	ptr_chaine = ((ptr_dchaine->s == conexb) && (!*ptr))? ptr_dchaine->suiv : ptr_dchaine ;
	while((ptr_chaine->suiv)->suiv != (struct chaine *)NULL)
	{
		if(ptr_chaine->ch)
		{
			id = ptr_chaine->az ;
			jd = ptr_chaine->ra ;
			ptr_schaine = ptr_chaine->lien ;
			is = ptr_schaine->az ;
			js = ptr_schaine->ra ;
			lien(jd, id, js, is, connexion) ;
//			lien(jd, id, js, is, ptr_chaine->p) ;
		}
		ptr_chaine = ptr_chaine->suiv ;
	}
}


/* ________________ impression d'une chaine ________________ */

void	pchaine(void)
{
	struct chaine	*ptr_chaine ;
	unsigned char	s, p ;
	int		i, j, charge, ch, k, l ;

	charge = 0 ;
	ptr_chaine = ptr_dchaine ;
	while(ptr_chaine->suiv != (struct chaine *)NULL)
	{
		if(ptr_chaine->s == resplus) charge++ ;
		if(ptr_chaine->s == resmoin) charge-- ;
		s = ptr_chaine->s ;
		p = ptr_chaine->p ;
		i = ptr_chaine->az ;
		j = ptr_chaine->ra ;
		k = (ptr_chaine->lien)->az ;
		l = (ptr_chaine->lien)->ra ;
		ch = ptr_chaine->ch ;
		ptr_chaine = ptr_chaine->suiv ;
		printf("(%-4d ; %-4d) --> signe = %u  charge = %d  premier? = %u  charge cumulee = %d  lien: (%-4d ; %-4d) coh = %d\n", i, j, s, ch, p, charge, k, l, *(coherenceScale+i*dimX+j)) ;
	}
	printf("\n") ;
}


/* ________________ Connexion de 2 residus ________________ */

void		lien(int x0, int y0, int x1, int y1, unsigned char connexion)
{
	unsigned char	*ptr_res ;
    int		i, i1, j = 0, j0, j1, sx, sy ;
	double		a ;

	ptr_res = firstPtrRes + y0*dimX + x0 ;
	sx = (x1<x0)? -1 : 1 ;
	sy = (y1<y0)? -1 : 1 ;
	i1 = x1 - x0 ;
	*ptr_res = connexion ;
	if(i1!=0)
	{
		a = ((double)(y1 - y0))/((double)i1) ;
		for(i=0; i!=i1; i+=sx)
		{
			j0 = (int)(a*i) ;
			j1 = (int)(a*(i+sx)) ;
			for(j=j0; j!=j1; j+=sy)
			{
				if(*(ptr_res + j*dimX + i) == rien)
					*(ptr_res + j*dimX + i) =  connexion ;
			}
			if(*(ptr_res + j*dimX + i) == rien)
				*(ptr_res + j*dimX + i) = connexion ;
		}
		if(*(ptr_res + j*dimX + i) == rien)
			*(ptr_res + j*dimX + i) = connexion ;

	}
	else
	{
		j1 = y1 - y0 ;
		for(j=0; j!=j1; j+=sy)
		{
			if(*(ptr_res + j*dimX) == rien)
				*(ptr_res + j*dimX) = connexion ;
		}
		if(*(ptr_res + j*dimX) == rien)
			*(ptr_res + j*dimX) = connexion ;
	}
	*(firstPtrRes + y1*dimX + x1) = connexion ;
}


/* ________________ recherche d'un plus proche voisin ________________ */

void		ppv(struct chaine **ptr1, struct chaine **ptr2)
{
	struct chaine	*ptr_chaine, *ptr_dechaine ;
	long		is, js ;
	long		dist, mindist ;

	mindist = (long)dimY*dimY + dimX*dimX ;
	ptr_dechaine = *ptr1 ;
	ptr_chaine = ptr_dechaine->suiv ;
	while(ptr_chaine->suiv != (struct chaine *)NULL)
	{
		is = (long)ptr_chaine->az - ptr_dechaine->az ;
		js = (long)ptr_chaine->ra - ptr_dechaine->ra ;
		dist = is * is + js * js ;
		if(dist < mindist)
		{
			mindist = dist ;
			*ptr2 = ptr_chaine ;
		}
		ptr_chaine = ptr_chaine->suiv ;
	}
}


/* ________________ Nettoyage de l'image des connexions ________________ */

void		nettoyage(unsigned short *ptr)
{
	unsigned char	*ptr_res ;
	unsigned short	*ptr_coh ;
	int		i, j ;

	ptr_res = firstPtrRes ;
	ptr_coh = coherenceScale ;
	for(i = 0; i < dimY; i++) {
		for(j = 0; j < dimX; j++, ptr_res++, ptr_coh++) {
			if((*ptr_res == rien) && (*ptr_coh > *ptr)) *ptr_res = 0 ;
			else {
				*ptr_res = 255 ;
				*ptr_coh = maxshort ;
			}
		}
	}
}

/* ________________ Liberation d'une chaine ________________ */

void	lib(void)
{
	struct chaine	*ptr_chaine ;

	while(ptr_dchaine->suiv != (struct chaine *)NULL)
	{
		ptr_chaine = ptr_dchaine->suiv ;
		free(ptr_dchaine) ;
		ptr_dchaine = ptr_chaine ;
	}
}


/* ________________ Nettoyage vers le bas ________________ */

void		netbas(unsigned char *ptr1, unsigned char *ptr2)
{
	unsigned char	*ptr_res, ok, dok, ok1 = 5, vtb, vth ;
	int		j, i0, j0, tb, tb0 = 1, tb1, th, th0, th1, stop ;
	integrationPathStartingPoint	*ptr_pile ;
	ok = *ptr1 ;
	dok = *ptr2 ;
	ptr_pile = integrationStartingPoint ;
	i0 = ptr_pile->az ;
	j0 = ptr_pile->ra ;
/*
printf("netbas : %d\t%d\t%u\n", i0, j0, seuil) ;
*/
	integrationStartingPoint = ptr_pile->suiv ;
	free(ptr_pile) ;
	while((i0) && (tb0))
	{
		j = j0 ;
		ptr_res = firstPtrRes + i0*dimX + j ;
		vtb = (*(ptr_res-dimX)) - ok ;
		tb = tb0 = (vtb <= ok1)? 1 : 0 ;
		vth = (*(ptr_res+dimX)) - ok ;
		th = th0 = (vth <= ok1)? 1 : 0 ;
		stop = 1 ;
		vtb = *ptr_res - ok ;
		*ptr_res -= (vtb <= ok1)? dok : 0 ;

		while((j<dimX-1) && (stop))
		{
			j++ ;
			ptr_res++ ;
			vtb = *ptr_res - ok ;
			if(vtb <= ok1)
			{
				vtb = (*(ptr_res-dimX)) - ok ;
				tb1 = (vtb <= ok1)? 1 : 0 ;
				if(tb1-tb == 1) addIntegrationPathStartingPoint(i0-1, j, 0) ;
				tb = tb1 ;

				vth = (*(ptr_res+dimX)) - ok ;
				th1 = (vth <= ok1)? 1 : 0 ;
				if(th1-th == 1) addIntegrationPathStartingPoint(i0+1, j, 1) ;
				th = th1 ;

				*ptr_res -= dok ;
			}
			else	stop = 0 ;
		}

		j = j0 ;
		ptr_res = firstPtrRes + i0*dimX + j ;
		tb = tb0 ;
		th = th0 ;
		stop = 1 ;
		while((j) && (stop))
		{
			j-- ;
			ptr_res-- ;
			vtb = *ptr_res - ok ;
			if(vtb <= ok1)
			{
				vtb = (*(ptr_res-dimX)) - ok ;
				tb1 = (vtb <= ok1)? 1 : 0 ;
				if(tb1-tb == 1) addIntegrationPathStartingPoint(i0-1, j, 0) ;
				tb = tb1 ;

				vth = (*(ptr_res+dimX)) - ok ;
				th1 = (vth <= ok1)? 1 : 0 ;
				if(th1-th == 1) addIntegrationPathStartingPoint(i0+1, j, 1) ;
				th = th1 ;

				*ptr_res -= dok ;
			}
			else	stop = 0 ;
		}
		i0-- ;
	}
}


/* ________________ Nettoyage vers le haut ________________ */

void	nethaut(unsigned char *ptr1, unsigned char *ptr2)
{
	unsigned char	*ptr_res, ok, dok, ok1 = 5, vtb, vth ;
	int		j, i0, j0, th, th0 = 1, th1, tb, tb0, tb1, stop ;
	integrationPathStartingPoint	*ptr_pile ;

	ok = *ptr1 ;
	dok = *ptr2 ;
	ptr_pile = integrationStartingPoint ;
	i0 = ptr_pile->az ;
	j0 = ptr_pile->ra ;
/*
printf("nethaut: %d\t%d\t%u\n", i0, j0, seuil) ;
*/
	integrationStartingPoint = ptr_pile->suiv ;
	free(ptr_pile) ;
	while((i0 < dimY-1) && (th0))
	{
		j = j0 ;
		ptr_res = firstPtrRes + i0*dimX + j ;
		vtb = (*(ptr_res-dimX)) - ok ;
		tb = tb0 = (vtb <= ok1)? 1 : 0 ;
		vth = (*(ptr_res+dimX)) - ok ;
		th = th0 = (vth <= ok1)? 1 : 0 ;
		stop = 1 ;
		vtb = *ptr_res - ok ;
		*ptr_res -= (vtb <= ok1)? dok : 0 ;
		while((j<dimX-1) && (stop))
		{
			j++ ;
			ptr_res++ ;
			vtb = *ptr_res - ok ;
			if(vtb <= ok1)
			{
				vtb = (*(ptr_res-dimX)) - ok ;
				tb1 = (vtb <= ok1)? 1 : 0 ;
				if(tb1-tb == 1) addIntegrationPathStartingPoint(i0-1, j, 0) ;
				tb = tb1 ;

				vth = (*(ptr_res+dimX)) - ok ;
				th1 = (vth <= ok1)? 1 : 0 ;
				if(th1-th == 1) addIntegrationPathStartingPoint(i0+1, j, 1) ;
				th = th1 ;

				*ptr_res -= dok ;
			}
			else	stop = 0 ;

		}

		j = j0 ;
		ptr_res = firstPtrRes + i0*dimX + j ;
		th = th0 ;
		tb = tb0 ;
		stop = 1 ;
		while((j) && (stop))
		{
			j-- ;
			ptr_res-- ;
			vtb = *ptr_res - ok ;
			if(vtb <= ok1)
			{
				vtb = (*(ptr_res-dimX)) - ok ;
				tb1 = (vtb <= ok1)? 1 : 0 ;
				if(tb1-tb == 1) addIntegrationPathStartingPoint(i0-1, j, 0) ;
				tb = tb1 ;

				vth = (*(ptr_res+dimX)) - ok ;
				th1 = (vth <= ok1)? 1 : 0 ;
				if(th1-th == 1) addIntegrationPathStartingPoint(i0+1, j, 1) ;
				th = th1 ;

				*ptr_res -= dok ;
			}
			else	stop = 0 ;
		}
		i0++ ;
	}
}

/* ________________ Recherche du résidu de plus haute cohérence ________________ */

void	rescohmax(void)
{
	connexionStartingPoint	*ptr_pdd ;
	unsigned char	*ptr_res ;
	unsigned short	*ptr_coh, minu = maxshort ;
	int		i, j, Npdd, Npdd1 ;

	Npdd = Npdd0 ;
	ptr_pdd = ptr_first_pdd ;
	while(Npdd)
	{
		Npdd-- ;
		ptr_pdd->az = 0 ;
		ptr_pdd->seuil = 0 ;
		ptr_pdd++ ;
	}
	Npdd1 = Npdd = Npdd0 ;
	ptr_pdd = ptr_first_pdd ;
	ptr_res = firstPtrRes + dimX ;
	ptr_coh = coherenceScale + dimX ;
	for(i=1; i<dimY-1; i++)
	{
		for(j=0; j<dimX; j++, ptr_res++, ptr_coh++)
		{
			if((*ptr_res == resmoin) || (*ptr_res == resplus))
			{
				if(Npdd)
				{
					Npdd-- ;
					ptr_pdd->az = i ;
					ptr_pdd->ra = j ;
					ptr_pdd->seuil = *ptr_coh ;
					ptr_pdd++ ;
					if(minu>*ptr_coh) minu = *ptr_coh ;
				}
				else
				{
					if(Npdd1)
					{
						Npdd1-- ;
						ptr_pdd->az = i ;
						ptr_pdd->ra = j ;
						ptr_pdd->seuil = *ptr_coh ;
						ptr_pdd++ ;
					}
					else
					{
						ptr_pdd->az = i ;
						ptr_pdd->ra = j ;
						ptr_pdd->seuil = *ptr_coh ;
						tri() ;
						Npdd1 = Npdd0 ;
						ptr_pdd = ptr_first_pdd + Npdd0 ;
					}
				}

			}
		}
	}
	tri() ;
}


/* ________________ Recherche du minimum de cohérence local le plus proche de chaque résidus ________________ */
/* ________________ 		    et déplacement du résidus vers ce minimum 		     ________________ */

void	mincohres(void)
{
	unsigned char	*ptr_res, s, connexion = 3 ;
	int		i0, j0, dec, stop1, stop2 = 1, Npdd ;
	connexionStartingPoint	*ptr_pdd ;

	while(stop2)
	{
		ptr_pdd = ptr_first_pdd ;
		stop2 = 0 ;
		Npdd = Npdd0 ;
		rescohmax() ;
		stop1 = ptr_pdd->az ;
		while((stop1) && (Npdd))
		{
			Npdd-- ;
			stop1 = i0 = ptr_pdd->az ;
			j0 = ptr_pdd->ra ;
			ptr_pdd++ ;
			ptr_res = firstPtrRes + i0*dimX + j0 ;
			s = *ptr_res ;
			dec = ppvcohmin(&i0, &j0) ;
			dec = (*(ptr_res + dec) == rien)? dec : 0 ;
			*ptr_res = connexion ;
			ptr_res += dec ;
			if(dec) stop2 = 1 ;
			*ptr_res = s ;
		}
	}
}

/* ________________ Recherche du minimum de cohérence le plus proche d'un résidu ________________ */

int	ppvcohmin(int *ptr_i0, int *ptr_j0)
{
	unsigned short	*ptr_coh, mincoh, v[4] ;
	int		i, dec = 0, s = 4 ;

	ptr_coh = coherenceScale + *ptr_i0*dimX + *ptr_j0 ;
	mincoh = *ptr_coh ;
	v[0] = (*ptr_i0 < dimY-1)? *(ptr_coh + dimX) : maxshort ;
	v[1] = (*ptr_j0 < dimX-1)? *(ptr_coh + 1) : maxshort ;
	v[2] = (*ptr_i0 > 0)? *(ptr_coh - dimX) : maxshort ;
	v[3] = (*ptr_j0 > 0)? *(ptr_coh -1) : maxshort ;
	for(i=0; i<4; i++)
	{
		if(v[i] < mincoh)
		{
			s = i ;
			mincoh = v[i] ;
		}
	}
	switch(s)
	{
		case 0 : dec = dimX ;
			 *ptr_i0 += 1 ;
			 break ;
		case 1 : dec = 1 ;
			 *ptr_j0 += 1 ;
			 break ;
		case 2 : dec = -dimX ;
			 *ptr_i0 -= 1 ;
			 break ;
		case 3 : dec = -1 ;
			 *ptr_j0 -= 1 ;
			 break ;
	}

	return(dec) ;
}


/* ________________ Propagation dans une discontinuité réelle ________________ */

void		propag(unsigned char *ptr_res, unsigned short *ptr_coh, unsigned short *ptr_seuil, unsigned char *ptr_ok1, unsigned char *ptr_ok, unsigned char *ptr_dok, int *ptr_tb, int *ptr_th, int *ptr_stop, int *ptr_i0, int *ptr_j, unsigned char *ptr_p, unsigned char *ptr_test1, unsigned short *ptr_test2, int *ptr_bord)
{
	unsigned char	ok, ok1, dok, vtb, vth ;
	int		tb1, th1, i0, j ;

	ok = *ptr_ok ;
	ok1 = *ptr_ok1 ;
	dok = *ptr_dok ;
	i0 = *ptr_i0 ;
	j = *ptr_j ;

	if(*ptr_res == conexb)
	{
		achaine(i0, j, *ptr_res, ptr_p) ;
		*ptr_bord = 1 ;
	}

	if(*ptr_res < ok1)
	{
		*ptr_test2 = (*ptr_test2 < *ptr_coh)? *ptr_coh : *ptr_test2 ;
		if(*ptr_coh < *ptr_seuil)
		{
			tb1 = ((*(ptr_coh-dimX) < *ptr_seuil) && (*(ptr_res-dimX) < ok1))? 1 : 0 ;
			if(tb1-*ptr_tb == 1) addIntegrationPathStartingPoint(i0-1, j, 0) ;
			*ptr_tb = tb1 ;

			th1 = ((*(ptr_coh+dimX) < *ptr_seuil) && (*(ptr_res+dimX) < ok1))? 1 : 0 ;
			if(th1-*ptr_th == 1) addIntegrationPathStartingPoint(i0+1, j, 1) ;
			*ptr_th = th1 ;

			if((*ptr_coh < seuilmin) || (*ptr_res == resplus) || (*ptr_res == resmoin))
				achaine(i0, j, *ptr_res, ptr_p) ;
			*ptr_res += ok ;
			*ptr_test1 = 1 ;
		}
		else	*ptr_stop = 0 ;
	}
	else
	{
		vtb = *ptr_res - ok ;
		if(vtb < ok1) *ptr_stop = 0 ;
		else
		{
			vtb = *(ptr_res-dimX) + dok - ok ;
			tb1 = (((*(ptr_coh-dimX) < *ptr_seuil) && (*(ptr_res-dimX) < ok1)) || (vtb < ok1))? 1 : 0 ;
			if(tb1-*ptr_tb == 1) addIntegrationPathStartingPoint(i0-1, j, 0) ;
			*ptr_tb = tb1 ;

			vth = *(ptr_res+dimX) + dok - ok ;
			th1 = (((*(ptr_coh+dimX) < *ptr_seuil) && (*(ptr_res+dimX) < ok1)) || (vth < ok1))? 1 : 0 ;
			if(th1-*ptr_th == 1) addIntegrationPathStartingPoint(i0+1, j, 1) ;
			*ptr_th = th1 ;
			*ptr_res += dok ;
		}
	}
}

/* ________________ Sauvegarde du résultat ________________ */

void sauvegarde(rawFileDescriptor *outputFile)
{
	FILE *f1 ;
	char *filePath ;

	fwrite((unsigned char *)firstPtrRes,1, dimY * dimX, outputFile->f) ;

	filePath = initStringWith2Strings(outputFile->accessPath, ".sup") ;
	if((f1 = fopen(filePath, "w")) == NULL) {
		sprintf (ertex, "Failed to create %s", filePath) ;
		ase (ertex) ;
	}
	fwrite((unsigned short *)coherenceScale, 2, dimY * dimX, f1) ;
	fclose(f1) ;
	free(filePath) ;
}


/* ________________ comptage des résidus ________________ */

void	comptage(long *ptr)
{
	unsigned char	*ptr_res ;
	int		i, j ;

	*ptr = 0 ;
	ptr_res = firstPtrRes + dimX ;
	for(i=1; i<dimY-1; i++)
		for(j=0; j<dimX; j++, ptr_res++)
			if((*ptr_res == resplus) || (*ptr_res == resmoin)) (*ptr)++ ;
}


/* ________________ decompte des résidus connectés ________________ */

void	decompte(long *ptr)
{
	struct chaine	*ptr_chaine ;

	ptr_chaine = ptr_dchaine ;
	while(ptr_chaine->suiv != (struct chaine *)NULL)
	{
		if((ptr_chaine->s == resmoin) || (ptr_chaine->s == resplus)) (*ptr)-- ;
		ptr_chaine = ptr_chaine->suiv ;
	}
}


/* ________________ tri des résidus de plus haute cohérence ________________ */
/*
Méthode de tri extraite de:
"Numerical Recipes in C";
W.H. Press, B.P. Flannery, S.A. Teukolsky, W.T. Veterling;
Cambridge University Press 1988; pp 245-247.
*/

void	tri(void)
{
	connexionStartingPoint	*ptr_pdd, *ptr_pdd1 ;
	int		l, j, ir, i, n ;

	ptr_pdd = ptr_pdd1 = ptr_first_pdd + 2*Npdd0 + 1 ;
	n = 2*Npdd0 + 1 ;
	l = (n>>1) + 1 ;
	ir = n ;
	for(;;)
	{
		if(l>1)
		{
			l-- ;
			ptr_pdd->az = (ptr_pdd1 - l)->az ;
			ptr_pdd->ra = (ptr_pdd1 - l)->ra ;
			ptr_pdd->seuil = (ptr_pdd1 - l)->seuil ;
		}
		else
		{
			ptr_pdd->az = (ptr_pdd1 - ir)->az ;
			ptr_pdd->ra = (ptr_pdd1 - ir)->ra ;
			ptr_pdd->seuil = (ptr_pdd1 - ir)->seuil ;
			(ptr_pdd1 - ir)->az = (ptr_pdd1 - 1)->az ;
			(ptr_pdd1 - ir)->ra = (ptr_pdd1 - 1)->ra ;
			(ptr_pdd1 - ir)->seuil = (ptr_pdd1 - 1)->seuil ;
			if(--ir == 1)
			{
				(ptr_pdd1 - 1)->az = ptr_pdd->az ;
				(ptr_pdd1 - 1)->ra = ptr_pdd->ra ;
				(ptr_pdd1 - 1)->seuil = ptr_pdd->seuil ;
				return ;
			}
		}
		i = l ;
		j = l<<1 ;
		while(j<=ir)
		{
			if((j<ir) && ((ptr_pdd1 - j)->seuil < (ptr_pdd1 - j - 1)->seuil)) ++j ;
			if(ptr_pdd->seuil < (ptr_pdd1 - j)->seuil)
			{
				(ptr_pdd1 - i)->az = (ptr_pdd1 - j)->az ;
				(ptr_pdd1 - i)->ra = (ptr_pdd1 - j)->ra ;
				(ptr_pdd1 - i)->seuil = (ptr_pdd1 - j)->seuil ;
				j += (i=j) ;
			}
			else j = ir + 1 ;
		}
		(ptr_pdd1 - i)->az = ptr_pdd->az ;
		(ptr_pdd1 - i)->ra = ptr_pdd->ra ;
		(ptr_pdd1 - i)->seuil = ptr_pdd->seuil ;
	}
}


/* ________________ Calcul de la cohérence moyenne au sein d'une connexion ________________ */
void		seuilmoyen(unsigned short *ptr)
{
	long		n, sm ;
	struct chaine	*r ;

	n = sm = 0 ;
	r = ptr_dchaine ;
	while(r->suiv != (struct chaine *)NULL)
	{
		if((r->s == resmoin) || (r->s == resplus)) {
			sm += (long)*(coherenceScale + r->az*dimX + r->ra) ;
			n++ ;
		}
		r = r->suiv ;
	}
	*ptr = (short)(sm/n)  ;
}


/* ________________ Extension du bord ________________ */

void		bordcoh(unsigned short *seuil)
{
	int		i, j ;
	unsigned short	*ptr_coh ;

	for(i=0; i<dimY; i+=dimY-1)
	{
		for(j=0; j<dimX; j++)
		{
			ptr_coh = coherenceScale + i*dimX + j  ;
			if(*ptr_coh < *seuil)
			{
				if(!i) 	addIntegrationPathStartingPoint(i, j, 1) ;
				else 	addIntegrationPathStartingPoint(i, j, 0) ;
				while(integrationStartingPoint->suiv != (integrationPathStartingPoint *)NULL)
				{
					if(integrationStartingPoint->hb ) bhaut(seuil) ;
					else bbas(seuil) ;
				}
			}
		}
	}

	for(j=0; j<dimX; j+=dimX-1)
	{
		for(i=1; i<dimY-1; i++)
		{
			ptr_coh = coherenceScale + i*dimX + j  ;
			if(*ptr_coh < *seuil)
			{
				addIntegrationPathStartingPoint(i, j, 1) ;
				addIntegrationPathStartingPoint(i, j, 0) ;
				while(integrationStartingPoint->suiv != (integrationPathStartingPoint *)NULL)
				{
					if(integrationStartingPoint->hb ) bhaut(seuil) ;
					else bbas(seuil) ;
				}
			}
		}
	}
}

/* ________________ Déplacement du bord vers le bas ________________ */

void		bbas(unsigned short *seuil)
{
	unsigned char	*ptr_res ;
	unsigned short	*ptr_coh ;
    int		j, i0, j0, tb, tb0 = 1, tb1, th = 0, th0 = 0, th1, stop = 0 ;
	integrationPathStartingPoint	*ptr_pile ;
	ptr_pile = integrationStartingPoint ;
	i0 = ptr_pile->az ;
	j0 = ptr_pile->ra ;

	integrationStartingPoint = ptr_pile->suiv ;
	free(ptr_pile) ;
	while((i0) && (tb0))
	{
		j = j0 ;
		ptr_res = firstPtrRes + i0*dimX + j ;
		ptr_coh = coherenceScale + i0*dimX + j ;
		tb = tb0 = ((*(ptr_coh-dimX) > *seuil) ||(*(ptr_res-dimX) == conexb))? 0 : 1 ;
		if(i0 < dimY-1) th = th0 = ((*(ptr_coh+dimX) > *seuil) ||(*(ptr_res+dimX) == conexb))? 0 : 1 ;
		if(*ptr_res != conexb) {
			stop = 1 ;
			*ptr_res = conexb ;

			while((j<dimX-1) && (stop))
			{
				j++ ;
				ptr_res++ ;
				ptr_coh++ ;
				if(*ptr_coh < *seuil)
				{
					tb1 = ((*(ptr_coh-dimX) > *seuil) ||(*(ptr_res-dimX) == conexb))? 0 : 1 ;
					if(tb1-tb == 1) addIntegrationPathStartingPoint(i0-1, j, 0) ;
					tb = tb1 ;

					if(i0 < dimY-1) {
						th1 = ((*(ptr_coh+dimX) > *seuil) ||(*(ptr_res+dimX) == conexb))? 0 : 1 ;
						if(th1-th == 1) addIntegrationPathStartingPoint(i0+1, j, 1) ;
						th = th1 ;
					}
					*ptr_res = conexb ;
				}
				else	stop = 0 ;
			}

			j = j0 ;
			ptr_res = firstPtrRes + i0*dimX + j ;
			ptr_coh = coherenceScale + i0*dimX + j ;
			tb = tb0 ;
			th = th0 ;
			stop = 1 ;
			while((j) && (stop))
			{
				j-- ;
				ptr_res-- ;
				ptr_coh-- ;
				if(*ptr_coh < *seuil)
				{
					tb1 = ((*(ptr_coh-dimX) > *seuil) ||(*(ptr_res-dimX) == conexb))? 0 : 1 ;
					if(tb1-tb == 1) addIntegrationPathStartingPoint(i0-1, j, 0) ;
					tb = tb1 ;

					if(i0 < dimY-1) {
						th1 = ((*(ptr_coh+dimX) > *seuil) ||(*(ptr_res+dimX) == conexb))? 0 : 1 ;
						if(th1-th == 1) addIntegrationPathStartingPoint(i0+1, j, 1) ;
						th = th1 ;
					}
					*ptr_res = conexb ;
				}
				else	stop = 0 ;
			}
		}
		i0-- ;
	}
}


/* ________________ Déplacement du bord vers le haut ________________ */

void		bhaut(unsigned short *seuil)
{
	unsigned char	*ptr_res ;
	unsigned short	*ptr_coh ;
    int		j, i0, j0, tb = 0, tb0 = 0, tb1, th, th0 = 1, th1, stop ;
	integrationPathStartingPoint	*ptr_pile ;
	ptr_pile = integrationStartingPoint ;
	i0 = ptr_pile->az ;
	j0 = ptr_pile->ra ;

	integrationStartingPoint = ptr_pile->suiv ;
	free(ptr_pile) ;
	while((i0 < dimY-1) && (th0))
	{
		j = j0 ;
		ptr_res = firstPtrRes + i0*dimX + j ;
		ptr_coh = coherenceScale + i0*dimX + j ;
		if(i0) tb = tb0 = ((*(ptr_coh-dimX) > *seuil) ||(*(ptr_res-dimX) == conexb))? 0 : 1 ;
		th = th0 = ((*(ptr_coh+dimX) > *seuil) ||(*(ptr_res+dimX) == conexb))? 0 : 1 ;
		if(*ptr_res != conexb) {
			stop = 1 ;
			*ptr_res = conexb ;

			while((j<dimX-1) && (stop))
			{
				j++ ;
				ptr_res++ ;
				ptr_coh++ ;
				if(*ptr_coh < *seuil) {
					if(i0) {
						tb1 = ((*(ptr_coh-dimX) > *seuil) ||(*(ptr_res-dimX) == conexb))? 0 : 1 ;
						if(tb1-tb == 1) addIntegrationPathStartingPoint(i0-1, j, 0) ;
						tb = tb1 ;
					}

					th1 = ((*(ptr_coh+dimX) > *seuil) ||(*(ptr_res+dimX) == conexb))? 0 : 1 ;
					if(th1-th == 1) addIntegrationPathStartingPoint(i0+1, j, 1) ;
					th = th1 ;
					*ptr_res = conexb ;
				}
				else	stop = 0 ;
			}

			j = j0 ;
			ptr_res = firstPtrRes + i0*dimX + j ;
			ptr_coh = coherenceScale + i0*dimX + j ;
			if(i0) tb = tb0 ;
			th = th0 ;
			stop = 1 ;
			while((j) && (stop))
			{
				j-- ;
				ptr_res-- ;
				ptr_coh-- ;
				if(*ptr_coh < *seuil)
				{
					if(i0) {
						tb1 = ((*(ptr_coh-dimX) > *seuil) ||(*(ptr_res-dimX) == conexb))? 0 : 1 ;
						if(tb1-tb == 1) addIntegrationPathStartingPoint(i0-1, j, 0) ;
						tb = tb1 ;
					}

					th1 = ((*(ptr_coh+dimX) > *seuil) ||(*(ptr_res+dimX) == conexb))? 0 : 1 ;
					if(th1-th == 1) addIntegrationPathStartingPoint(i0+1, j, 1) ;
					th = th1 ;
					*ptr_res = conexb ;
				}
				else	stop = 0 ;
			}
		}
		i0++ ;
	}
}
