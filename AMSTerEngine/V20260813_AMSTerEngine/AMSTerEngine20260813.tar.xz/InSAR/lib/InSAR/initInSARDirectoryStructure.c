
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  initInSARDirectoryStructure.c
//  initInSAR
//
//  Created by Dominique Derauw on 25/09/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#include "initInSARDirectoryStructure.h"


/* Create a default directory structure for InSAR processing */
void createInSARDirectoryStructureAtPath(char *aPath)
{
    char subDirectoryPath[_MAX_PATH_LENGTH_], *aDir ;
    
    if(isDir(aPath)) {
        if(!isWriteAccessGrantedAtPath(aPath)) {
            sprintf(ertex, "Write acces denied at path %s", aPath) ;
            ase(ertex) ;
        }
    }
    else {
        aDir = getDirectoryPathFromPath(aPath) ;
        if(!isWriteAccessGrantedAtPath(aDir)) {
            sprintf(ertex, "Write acces denied at path %s", aDir) ;
            ase(ertex) ;
        }
        free(aDir) ;
        
        if(mkdir((const char *)aPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create directory at path %s\n", aPath) ;
            ase(ertex) ;
        }
    }
    
    sprintf(subDirectoryPath, "%s/TextFiles", aPath) ;
    if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
        if(errno != EEXIST) {
            sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
            ase(ertex) ;
        }
    }
    
    sprintf(subDirectoryPath, "%s/InSARProducts", aPath) ;
    if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
        if(errno != EEXIST) {
            sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
            ase(ertex) ;
        }
    }
    
    sprintf(subDirectoryPath, "%s/GeoProjection", aPath) ;
    if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
        if(errno != EEXIST) {
            sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
            ase(ertex) ;
        }
    }
    
#ifdef INCLUDESBINSAR
    
    sprintf(subDirectoryPath, "%s/SBInSARProducts", aPath) ;
    if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
        if(errno != EEXIST) {
            sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
            ase(ertex) ;
        }
    }
    
    sprintf(subDirectoryPath, "%s/SBInSARProducts/SubBands", aPath) ;
    if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
        if(errno != EEXIST) {
            sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
            ase(ertex) ;
        }
    }
    
    sprintf(subDirectoryPath, "%s/SBInSARProducts/SBInSAR", aPath) ;
    if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
        if(errno != EEXIST) {
            sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
            ase(ertex) ;
        }
    }
    
    sprintf(subDirectoryPath, "%s/SBInSARProducts/MCA", aPath) ;
    if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
        if(errno != EEXIST) {
            sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
            ase(ertex) ;
        }
    }
    
#endif
}

char isInSARDirectoryStructureAtPath(char *aPath)
{
    char *subDirectoryPath ;
    char *InSARParaFilePath ;
    
    if(!aPath) {
        return(0) ;
    }
    if(!isDir(aPath)) {
        return(0) ;
    }

    subDirectoryPath = initStringWith2Strings(aPath, "/TextFiles") ;
    if(!isDir(subDirectoryPath)) {
        free(subDirectoryPath) ;
        return(0) ;
    }
    InSARParaFilePath = initStringWith2Strings(subDirectoryPath, "/InSARParameters.txt") ;
    if (!fileExistsAtPath(InSARParaFilePath)) {
        free(InSARParaFilePath) ;
        return(0) ;
    }
    free(InSARParaFilePath) ;
    free(subDirectoryPath) ;
    
    subDirectoryPath = initStringWith2Strings(aPath, "/InSARProducts") ;
    if(!isDir(subDirectoryPath)) {
        free(subDirectoryPath) ;
        return(0) ;
    }
    free(subDirectoryPath) ;
    
    subDirectoryPath = initStringWith2Strings(aPath, "/GeoProjection") ;
    if(!isDir(subDirectoryPath)) {
        free(subDirectoryPath) ;
        return(0) ;
    }
    free(subDirectoryPath) ;
    
    subDirectoryPath = initStringWith2Strings(aPath, "/SBInSARProducts") ;
    if(!isDir(subDirectoryPath)) {
        free(subDirectoryPath) ;
        return(0) ;
    }
    free(subDirectoryPath) ;
    
    return(1) ;
}

