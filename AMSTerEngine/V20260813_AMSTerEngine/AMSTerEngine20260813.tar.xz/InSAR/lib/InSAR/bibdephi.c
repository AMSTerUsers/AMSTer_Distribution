
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* bibdephi.c */
#include "pourtous.h"
#include "bibdephi.h"

/* global variables declaration */
#if !defined(_CONNEXIONS_DEPHI_COMMON_DEFS_)
#define _CONNEXIONS_DEPHI_COMMON_DEFS_
int lena, lenr ;
unsigned char    *ptr_first_res ;
integrationPathStartingPoint    *ptr_dpile ;
#endif


int unsigned **zoneMap, zoneIndex ;
float	DephiOk ;
float	*ptr_first_phi, *ptr_first_dephi, *ptr_first_coh ;
float   **interferometricPhase, **unwrappedPhase, **coherence ;
struct pdd	pdd ;


/* ________________ Recherche du point de depart suivant ________________ */

int	ps(char init)
{
	unsigned char	*ptr_res ;
	int 		val, stop = 1 ;
	int		i, j, j0 ;
	static int	i0 = 1 ;
	float		*ptr_dephi ;

    if (init) {
        i0 = 1 ;
        return(1) ;
    }
    
	i = i0 ;
    j = j0 = 1 ;
	while((i<lena-1) && (stop))
	{
		j = 1 ;
		while((j<lenr-2) && (stop))
		{
			ptr_dephi = ptr_first_dephi + i*(lenr-1) + j ;
			ptr_res = ptr_first_res + i*lenr + j ;
			if(*ptr_dephi == DephiOk && ((!*ptr_res) || (!*(ptr_res + 1))))
			{
				i0 = i ;
				j0 = j ;
				stop = 0 ;
			}
			j++ ;
		}
		i++ ;
	}

	if((i == lena-1) && (j == lenr-2)) val = 0 ;
	else {
		val = 1 ;
        zoneIndex++ ;
        pdd.zoneIndex ++ ;
		pdd.az = i0 ;
		pdd.ra = j0 ;
		pdd.min = PI ;
		pdd.max = -PI ;
        pdd.phaseAvg = 0. ;
        pdd.cohAvg = 0. ;
        pdd.xM = pdd.yM = 0. ;
        pdd.zoneSize = 0 ;                  /* This size is the total number of pixels within the considered zone */
        pdd.validZoneSize = 0 ;             /* This size correspond to the size of non null coherence values within the considered zone */
        /* If first phase component is provided, reinitialize Matrix and Vector for mean square correction */
        if (ptr_first_coh != NULL) {
            for (i = 1; i <= 3; i++) {
                for (j = 1; j <= 3; j++) {
                    pdd.M[i][j] = 0. ;
                }
                pdd.V[i] = 0. ;
            }
        }
	}
	return (val) ;
}
/* ________________ remplissage vers le bas ________________ */

void	bas()
{
    unsigned char	*ptr_res ;
    int		j, i0, j0, tb, tb0 = 1, th, stop ;
    float		*ptr_phi, *ptr_dephi ;
    struct pile	*ptr_pile ;

    ptr_pile = ptr_dpile ;
    i0 = ptr_pile->az ;
    j0 = ptr_pile->ra ;

    ptr_dpile = ptr_pile->suiv ;
    free(ptr_pile) ;
    ptr_dephi = ptr_first_dephi + i0*(lenr-1) + j0 ;
    while((i0>=0) && (tb0) && (*ptr_dephi == DephiOk)) 
    {
        j = j0 ;
        ptr_res = ptr_first_res + i0*lenr + j ;
        ptr_phi = ptr_first_phi + i0*(lenr-1) + j ;
        tb0 = ((*ptr_res) && (*(ptr_res + 1)))? 0 : 1 ;
        tb = (*(ptr_res + 1))? 0 : 1 ;
        th = (*(ptr_res + lenr + 1))? 0 : 1 ;
        stop = 1 ;

        zoneMap[i0][j] = zoneIndex ;
        if(*(ptr_dephi+lenr-1) == DephiOk)
            *ptr_dephi = *ptr_phi ;
        else
            *ptr_dephi = dphi(ptr_dephi+lenr-1, ptr_phi, ptr_phi+lenr-1, i0, j) ;

        while((j<lenr-2) && (stop))
        {
            if((*(ptr_dephi + 1) == DephiOk) && ((!*(ptr_res + 1)) || (!*(ptr_res + lenr + 1))))
                dd(&ptr_phi, &ptr_res, &ptr_dephi, &i0, &j, &tb, &th) ;
            else	stop = 0 ;
        }

        j = j0 ;
        ptr_res = ptr_first_res + i0*lenr + j ;
        ptr_phi = ptr_first_phi + i0*(lenr-1) + j ;
        ptr_dephi = ptr_first_dephi + i0*(lenr-1) + j ;
        tb = (*ptr_res)? 0 : 1 ; ;
        th = (*(ptr_res + lenr))? 0 : 1 ;
        stop = 1 ;
        while((j) && (stop))
        {
            if((*(ptr_dephi - 1) == DephiOk) && ((!*ptr_res) || (!*(ptr_res + lenr))))
                dg(&ptr_phi, &ptr_res, &ptr_dephi, &i0, &j, &tb, &th) ;
            else	stop = 0 ;
        }
        i0-- ;
        ptr_dephi = ptr_first_dephi + i0*(lenr-1) + j0 ;
    }
}


/* ________________ remplissage vers le haut ________________ */

void haut()
{
    unsigned char	*ptr_res ;
    int		j, i0, j0, th, th0 = 1, tb, stop ;
    float		*ptr_phi, *ptr_dephi ;
    struct pile	*ptr_pile ;

    ptr_pile = ptr_dpile ;
    i0 = ptr_pile->az ;
    j0 = ptr_pile->ra ;
    ptr_dpile = ptr_pile->suiv ;
    free(ptr_pile) ;
    ptr_dephi = ptr_first_dephi + i0*(lenr-1) + j0 ;
    while((i0 < lena-1) && (th0) && (*ptr_dephi == DephiOk)) 
    {
        j = j0 ;
        ptr_res = ptr_first_res + i0*lenr + j ;
        ptr_phi = ptr_first_phi + i0*(lenr-1) + j ;
        th0 = ((*(ptr_res + lenr)) && (*(ptr_res + lenr + 1)))? 0 : 1 ;
        th = (*(ptr_res + lenr + 1))? 0 : 1 ;
        tb = (*(ptr_res + 1))? 0 : 1 ;
        stop = 1 ;
        
        zoneMap[i0][j] = zoneIndex ;
        if(*(ptr_dephi-lenr+1) == DephiOk)
            *ptr_dephi = *ptr_phi ;
        else
            *ptr_dephi = dphi(ptr_dephi-lenr+1, ptr_phi, ptr_phi-lenr+1, i0, j) ;

        while((j<lenr-2) && (stop))
        {
            if((*(ptr_dephi + 1) == DephiOk) && ((!*(ptr_res + 1)) || (!*(ptr_res + lenr + 1))))
                dd(&ptr_phi, &ptr_res, &ptr_dephi, &i0, &j, &tb, &th) ;
            else	stop = 0 ;
        }

        j = j0 ;
        ptr_res = ptr_first_res + i0*lenr + j ;
        ptr_phi = ptr_first_phi + i0*(lenr-1) + j ;
        ptr_dephi = ptr_first_dephi + i0*(lenr-1) + j ;
        th = (*(ptr_res + lenr))? 0 : 1 ;
        tb = (*ptr_res)? 0 : 1 ;
        stop = 1 ;
        while((j) && (stop))
        {
            if((*(ptr_dephi - 1) == DephiOk) && ((!*ptr_res) || (!*(ptr_res + lenr))))
                dg(&ptr_phi, &ptr_res, &ptr_dephi, &i0, &j, &tb, &th) ;
            else	stop = 0 ;
        }
        i0++ ;
        ptr_dephi = ptr_first_dephi + i0*(lenr-1) + j0 ;
    }
}


/* ________________ Ajout dans la pile ________________ */

void apile(int i, int j, unsigned char sens)
{
	struct pile	*ptr_pile ;
	if((i>=0) && (i<lena-1)) {
		if(*(ptr_first_dephi + i*(lenr-1) + j) == DephiOk) {
			ptr_pile = ptr_dpile ;
			if ((ptr_dpile = (struct pile *)calloc (1, sizeof(struct pile))) == NULL) 
			{	
				sprintf (ertex, "Erreur d'allocation sur ptr_pile") ;
				ase (ertex) ;
			}
			ptr_dpile->az = i ;
			ptr_dpile->ra = j ;
			ptr_dpile->hb = sens ;
			ptr_dpile->suiv = ptr_pile ;
		}
	}
}

/* ________________ déroulement à droite ________________ */

void dd(float **aptr_phi, unsigned char **aptr_res, float **aptr_dephi, int *ptr_i0, int *ptr_j, int *ptr_tb, int *ptr_th)
{
	int	tb1, th1 ;
    
	*(*aptr_dephi + 1) = dphi(*aptr_dephi, *aptr_phi + 1, *aptr_phi, *ptr_i0, *ptr_j) ;
    zoneMap[*ptr_i0][*ptr_j + 1] = zoneIndex ;

	(*ptr_j)++ ;
	(*aptr_res)++ ;
	(*aptr_phi)++ ;
	(*aptr_dephi)++ ;
	tb1 = (*(*aptr_res + 1))? 0 : 1 ;
	if(tb1 - *ptr_tb == 1) apile(*ptr_i0 - 1, *ptr_j, 0) ;
	*ptr_tb = tb1 ;
	th1 = (*(*aptr_res + lenr + 1))? 0 : 1 ;
	if(th1 - *ptr_th == 1) apile(*ptr_i0 + 1, *ptr_j, 1) ;
	*ptr_th = th1 ;
}


/* ________________ déroulement à gauche ________________ */

void dg(float **aptr_phi, unsigned char **aptr_res, float **aptr_dephi, int *ptr_i0, int *ptr_j, int *ptr_tb, int *ptr_th)
{
	int	tb1, th1 ;

	*(*aptr_dephi - 1) = dphi(*aptr_dephi, *aptr_phi - 1, *aptr_phi, *ptr_i0, *ptr_j) ;
    zoneMap[*ptr_i0][*ptr_j - 1] = zoneIndex ;
    
	(*ptr_j)-- ;
	(*aptr_res)-- ;
	(*aptr_phi)-- ;
	(*aptr_dephi)-- ;
	tb1 = (**aptr_res)? 0 : 1 ;
	if(tb1 - *ptr_tb == 1) apile(*ptr_i0 - 1, *ptr_j, 0) ;
	*ptr_tb = tb1 ;
	th1 = (*(*aptr_res + lenr))? 0 : 1 ;
	if(th1 - *ptr_th == 1) apile(*ptr_i0 + 1, *ptr_j, 1) ;
	*ptr_th = th1 ;
}

/* ________________ Deroulement de la phase d'un point ________________ */

double	dphi(float *dephi0, float *phi1, float *phi0, int iY, int iX)
{
	double	dephi1 ;
	
	dephi1 = dephi(phi1, phi0) + *dephi0 ;

	if(pdd.min > dephi1)
	{
		pdd.min = dephi1 ;
		pdd.minaz = iY ;
		pdd.minra = iX ;
	}
	if(pdd.max < dephi1)
	{
		pdd.max = dephi1 ;
		pdd.maxaz = iY ;
		pdd.maxra = iX ;
	}
    pdd.zoneSize++ ;
    
    if ((ptr_first_coh != NULL) && coherence[iY][iX]) {
        pdd.validZoneSize++ ;
        pdd.M[1][1] += pow((double)iX, 2.) * coherence[iY][iX] ;
        pdd.M[1][2] += iX * iY * coherence[iY][iX] ;
        pdd.M[1][3] += iX * coherence[iY][iX] ;
        pdd.M[2][2] += pow((double)iY, 2.) * coherence[iY][iX] ;
        pdd.M[2][3] += iY * coherence[iY][iX] ;
        pdd.M[3][3] += coherence[iY][iX] ;
        
        pdd.V[1] += iX * dephi1 * coherence[iY][iX] ;
        pdd.V[2] += iY * dephi1 * coherence[iY][iX] ;
        pdd.V[3] += dephi1 * coherence[iY][iX] ;

        pdd.phaseAvg += (double)dephi1 * coherence[iY][iX] ;
        pdd.cohAvg += (double)coherence[iY][iX] ;
        
        pdd.xM += (double)iX * coherence[iY][iX]  ;
        pdd.yM += (double)iY * coherence[iY][iX] ;
    }
    else {
        pdd.phaseAvg += (double)dephi1 ;
        pdd.cohAvg += 1 ;
    }

	return dephi1 ;
}


/* ________________ Normalisation vers le bas ________________ */

void normbas()
{
	unsigned char	*ptr_res ;
	int		j, i0, j0, tb, tb0 = 1, th, stop ;
	float		*ptr_phi, *ptr_dephi ;
	struct pile	*ptr_pile ;
	
	ptr_pile = ptr_dpile ;
	i0 = ptr_pile->az ;
	j0 = ptr_pile->ra ;
	
	/*
	 printf("bas:  %d\t%d\t%f\n", i0, j0) ;
	 */
	ptr_dpile = ptr_pile->suiv ;
	free(ptr_pile) ;
	ptr_phi = ptr_first_phi + i0*(lenr-1) + j0 ;
	while((i0>=0) && (tb0) && (*ptr_phi != DephiOk)) 
	{
		j = j0 ;
		ptr_res = ptr_first_res + i0*lenr + j ;
		ptr_dephi = ptr_first_dephi + i0*(lenr-1) + j ;
		tb0 = ((*ptr_res) && (*(ptr_res + 1)))? 0 : 1 ;
		tb = (*(ptr_res + 1))? 0 : 1 ;
		th = (*(ptr_res + lenr + 1))? 0 : 1 ;
		stop = 1 ;
        
        /* If an external DEM was used, we remove the best plane computed for this zone */
        if(ptr_first_coh != NULL){
            *ptr_dephi -= (float)(pdd.V[1] * j + pdd.V[2] * i0 + pdd.V[3]) ;
        }
        else {
            *ptr_dephi -= pdd.min ;
        }
        
//		*ptr_dephi -= pdd.min ;
		*ptr_phi = DephiOk ;
		while((j<lenr-2) && (stop))
		{
			if((*(ptr_phi + 1)!=DephiOk) && ((!*(ptr_res + 1)) || (!*(ptr_res + lenr + 1))))
				ndd(&ptr_phi, &ptr_res, &ptr_dephi, &i0, &j, &tb, &th) ;
			else	stop = 0 ;
		}
		
		j = j0 ;
		ptr_res = ptr_first_res + i0*lenr + j ;
		ptr_phi = ptr_first_phi + i0*(lenr-1) + j ;
		ptr_dephi = ptr_first_dephi + i0*(lenr-1) + j ;
		tb = (*ptr_res)? 0 : 1 ;
		th = (*(ptr_res + lenr))? 0 : 1 ;
		stop = 1 ;
		while((j) && (stop))
		{
			if((*(ptr_phi - 1)!=DephiOk) && ((!*ptr_res) || (!*(ptr_res + lenr))))
				ndg(&ptr_phi, &ptr_res, &ptr_dephi, &i0, &j, &tb, &th) ;
			else	stop = 0 ;
		}
		i0-- ;
		ptr_phi = ptr_first_phi + i0*(lenr-1) + j0 ;
	}
}


/* ________________ Normalisation vers le haut ________________ */

void normhaut()
{
	unsigned char	*ptr_res ;
	int		j, i0, j0, th, th0 = 1, tb, stop ;
	float		*ptr_phi, *ptr_dephi ;
	struct pile	*ptr_pile ;
	
	ptr_pile = ptr_dpile ;
	i0 = ptr_pile->az ;
	j0 = ptr_pile->ra ;
	/*
	 printf("haut: %d\t%d\t%f\n", i0, j0) ;
	 */
	ptr_dpile = ptr_pile->suiv ;
	free(ptr_pile) ;
	ptr_phi = ptr_first_phi + i0*(lenr-1) + j0 ;
	while((i0 < lena-1) && (th0) && (*ptr_phi != DephiOk)) 
	{
		j = j0 ;
		ptr_res = ptr_first_res + i0*lenr + j ;
		ptr_dephi = ptr_first_dephi + i0*(lenr-1) + j ;
		th0 = ((*(ptr_res + lenr)) && (*(ptr_res + lenr + 1)))? 0 : 1 ;
		tb = (*(ptr_res + 1))? 0 : 1 ;
		th = (*(ptr_res + lenr + 1))? 0 : 1 ;
		stop = 1 ;
        
        /* If an external DEM was used, we remove the best plane computed for this zone */
        if(ptr_first_coh != NULL){
            *ptr_dephi -= (float)(pdd.V[1] * j + pdd.V[2] * i0 + pdd.V[3]) ;
        }
        else {
            *ptr_dephi -= pdd.min ;
        }
        
//		*ptr_dephi -= pdd.min ;
        
		*ptr_phi = DephiOk ;
		while((j<lenr-2) && (stop))
		{
			
			if((*(ptr_phi + 1)!=DephiOk) && ((!*(ptr_res + 1)) || (!*(ptr_res + lenr + 1))))
				ndd(&ptr_phi, &ptr_res, &ptr_dephi, &i0, &j, &tb, &th) ;
			else	stop = 0 ;
		}
		j = j0 ;
		ptr_res = ptr_first_res + i0*lenr + j ;
		ptr_phi = ptr_first_phi + i0*(lenr-1) + j ;
		ptr_dephi = ptr_first_dephi + i0*(lenr-1) + j ;
		tb = (*ptr_res)? 0 : 1 ;
		th = (*(ptr_res + lenr))? 0 : 1 ;
		stop = 1 ;
		while((j) && (stop))
		{
			if((*(ptr_phi - 1)!=DephiOk) && ((!*ptr_res) || (!*(ptr_res + lenr))))
				ndg(&ptr_phi, &ptr_res, &ptr_dephi, &i0, &j, &tb, &th) ;
			else	stop = 0 ;
		}
		i0++ ;
		ptr_phi = ptr_first_phi + i0*(lenr-1) + j0 ;
	}
}

/* ________________ Ajout dans la pile ________________ */

void apileNorme(int i, int j, unsigned char sens)
{
    struct pile	*ptr_pile ;
    if((i>=0) && (i<lena-1)) {
        if(*(ptr_first_phi + i*(lenr - 1) + j) != DephiOk) {
            ptr_pile = ptr_dpile ;
            if ((ptr_dpile = (struct pile *)calloc (1, sizeof(struct pile))) == NULL) 
            {	
                sprintf (ertex, "Erreur d'allocation sur ptr_pile") ;
                ase (ertex) ;
            }
            ptr_dpile->az = i ;
            ptr_dpile->ra = j ;
            ptr_dpile->hb = sens ;
            ptr_dpile->suiv = ptr_pile ;
        }
    }
}


/* ________________ Normalisation à droite ________________ */

void ndd(float **aptr_phi, unsigned char **aptr_res, float **aptr_dephi, int *ptr_i0, int *ptr_j, int *ptr_tb, int *ptr_th)
{
	int	tb1, th1 ;
    
    /* If an external DEM was used, we remove the best plane computed for this zone */
    if(ptr_first_coh != NULL){
        *(*aptr_dephi + 1) -= (float)(pdd.V[1] * *ptr_j + pdd.V[2] * *ptr_i0 + pdd.V[3]) ;
    }
    else {
        *(*aptr_dephi + 1) -= pdd.min ;
    }
    
    (*ptr_j)++ ;
	(*aptr_res)++ ;
	(*aptr_phi)++ ;
	(*aptr_dephi)++ ;
	tb1 = (*(*aptr_res + 1))? 0 : 1 ;
	if(tb1 - *ptr_tb == 1) apileNorme(*ptr_i0 - 1, *ptr_j, 0) ;
	*ptr_tb = tb1 ;
	th1 = (*(*aptr_res + lenr + 1))? 0 : 1 ;
	if(th1 - *ptr_th == 1) apileNorme(*ptr_i0 + 1, *ptr_j, 1) ;
	*ptr_th = th1 ;
	**aptr_phi = DephiOk ;
}


/* ________________ Normalisation à gauche ________________ */

void ndg(float **aptr_phi, unsigned char **aptr_res, float **aptr_dephi, int *ptr_i0, int *ptr_j, int *ptr_tb, int *ptr_th)
{
	int	tb1, th1 ;
	
    /* If an external DEM was used, we remove the best plane computed for this zone */
    if(ptr_first_coh != NULL){
        *(*aptr_dephi - 1) -= (float)(pdd.V[1] * *ptr_j + pdd.V[2] * *ptr_i0 + pdd.V[3]) ;
    }
    else {
        *(*aptr_dephi - 1) -= pdd.min ;
    }
    
    (*ptr_j)-- ;
	(*aptr_res)-- ;
	(*aptr_phi)-- ;
	(*aptr_dephi)-- ;
	tb1 = (**aptr_res)? 0 : 1 ;
	if(tb1 - *ptr_tb == 1) apileNorme(*ptr_i0 - 1, *ptr_j, 0) ;
	*ptr_tb = tb1 ;
	th1 = (*(*aptr_res + lenr))? 0 : 1 ;
	if(th1 - *ptr_th == 1) apileNorme(*ptr_i0 + 1, *ptr_j, 1) ;
	*ptr_th = th1 ;
	**aptr_phi = DephiOk ;
}

