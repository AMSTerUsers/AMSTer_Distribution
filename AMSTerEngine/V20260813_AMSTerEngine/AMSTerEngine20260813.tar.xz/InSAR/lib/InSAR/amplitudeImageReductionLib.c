
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  amplitudeImageReductionLib.c
//  amplitudeImageReduction
//
//  Created by Dominique Derauw on 26/09/14.
//  Completely revised on January 2020
//  Copyright © 2020 Dominique Derauw. All rights reserved.
//
//

#include <stdio.h>
#include "amplitudeImageReductionLib.h"


int amplitudeImageReduction(CSVStruct *csv)
{
    char *InSARparametersFilePath = NULL, *aPath, *inputFilePath, *outputFilePath ;
    char computeSlaveAmplitude, computeMasterAmplitude, InSARParametersFileFound ;
    char verbose ;
    int    currentDirectoryFdesc, i ;
    int xDim, yDim, xReductionFactor, yReductionFactor ;
    int xReducedDim = 0, yReducedDim = 0 ;
    int xDimBorder, yDimBorder ;
    InSARParametersStruct    *pInSAR ;
    CSLImage *anImage ;
    struct infoImage *infoImage ;
    CSVStruct *polMode ;
    keyValue *textFile ;
    time_t startTime, endTime ;
    polygon *aoi = NULL ;
    rawFileDescriptor *inputFile, *outputFile ;
    
    verbose = (isArgumentPresentInCSV(csv, "chut!"))? 0 : 1 ;
    time(&startTime) ;
    
    /* Detect if only one image of the InSAR pair must be reduced */
    computeSlaveAmplitude = computeMasterAmplitude = 1 ;
    if(isArgumentPresentInCSV(csv, "masterOnly"))
        computeSlaveAmplitude = 0 ;
    if(isArgumentPresentInCSV(csv, "slaveOnly"))
        computeMasterAmplitude = 0 ;
    
    if(isArgumentPresentInCSV(csv, "help"))
        amplitudeImageReductionHelp() ;
    
    if (isArgumentPresentInCSV(csv, "path=")) {
        rawFileReduction(csv) ;
        time(&endTime) ;
        duration(startTime, endTime) ;
        return(0) ;
    }
    
    /* Change working directory to current directory */
    currentDirectoryFdesc = open(".", O_RDONLY) ;
    fchdir(currentDirectoryFdesc) ;

    /* Test if first parameter is a directory that may contain an image in CSL format */
    if (csv->numberOfEntries == 1 || !isDir((char *)csv->stringVal[1])) {
        /* If not, look for an InSAR parameters file */
        InSARParametersFileFound = 0 ;
        i = 1 ;
        while (i < csv->numberOfEntries) {
            InSARparametersFilePath = initStringWithString((char *)csv->stringVal[i]) ;
            if(fileExistsAtPath(InSARparametersFilePath)) {
                InSARParametersFileFound = 1 ;
                break ;
            }
            i++ ;
            free(InSARparametersFilePath) ;
        }
        
        
        /* If InSAR parameter file not given as parameter, look for it in current directory */
        if(!InSARParametersFileFound) {
            InSARparametersFilePath = initStringWithString("./TextFiles/InSARParameters.txt") ;
            if(!fileExistsAtPath(InSARparametersFilePath)){
                free(InSARparametersFilePath) ;
                InSARparametersFilePath = initStringWithString("./InSARParameters.txt") ;
                if(!fileExistsAtPath(InSARparametersFilePath))
                    amplitudeImageReductionHelp() ;
            }
            InSARParametersFileFound = 1 ;
        }
        
        xDimBorder = yDimBorder = 0 ;
        if (InSARParametersFileFound) {
            pInSAR = readInSARParametersFileAtPath(InSARparametersFilePath) ;
            pInSAR->flag |= (isFlagPresentInCSV(csv, "C"))? _CALIBRATE_IN_SIGMA0_ : pInSAR->flag ;
            if ((i = isArgumentPresentInCSV(csv, "C="))) {
                sscanf(csv->stringVal[i] + 2, "%lf", &pInSAR->averageBeta0CalibrationConstant) ;
                pInSAR->flag |= _CALIBRATE_IN_SIGMA0_ ;
            }
            
            xReductionFactor = (pInSAR->red).Fra ;
            yReductionFactor = (pInSAR->red).Faz ;
            
            if (isFlagPresentInCSV(csv, "-i")) {
                aoi = pInSAR->aoi ;
                xDimBorder = pInSAR->coh.spi / 2 + pInSAR->coh.cor / 2 ;
                yDimBorder = pInSAR->coh.spi / 2 + pInSAR->coh.coa / 2 ;
            }
            
            if (verbose) {
                printf("Computation of reduced amplitude image(s):\n\n") ;
            }
            
            if(computeMasterAmplitude){
                if (pInSAR->flag & _CALIBRATE_IN_SIGMA0_) {
                    if (!fileExistsAtPath(pInSAR->externalSlantRangeDEMFile->accessPath)) {
                        /* We will verify if an external DEM is associated with the master image and recreate an external slant range DEM if possible */
                        generateExternalSlantRangeDEM(pInSAR) ;
                    }
                    openExternalSlantRangeDEMFile(pInSAR) ;
                }
                
                if (isFlagPresentInCSV(csv, "-i") && pInSAR->masterInterpolation) {
                    inputFilePath = initStringWith3Strings(pInSAR->interpolatedMaster->dataDirectoryPath, "/SLCImage.", pInSAR->masterPolarizationChannel) ;
                }
                else {
                    inputFilePath = initStringWithString((pInSAR->ima1).filePath) ;
                }
                
                if ((inputFile = openRawFileForReadingAtPath(inputFilePath)) == NULL) {
                    sprintf(ertex, "Failed to open input file for reading.\n--> %s\n", inputFilePath) ;
                    ase(ertex) ;
                }
                inputFile->xDim = (pInSAR->ima1).lenr ;
                inputFile->yDim = (pInSAR->ima1).lena ;
                inputFile->xLowerIndex = xDimBorder ;
                inputFile->yLowerIndex = yDimBorder ;
                inputFile->aoi = aoi ;
                
                outputFilePath = initStringWithString((pInSAR->mod1).filePath) ;
                outputFile = openRawFileForWritingAtPath(outputFilePath) ;
                
                if(verbose) {
                    printf("Master image:\t%s\n", inputFilePath) ;
                    printf("Result:\t%s\n", outputFilePath) ;
                    printf("Used reduction factors: (%-3d x %3d)   (Range x Azimuth)\n", xReductionFactor, yReductionFactor) ;

                }
                complexImageReduction(inputFile, outputFile, xReductionFactor, yReductionFactor) ;
                if (verbose) {
                    printf("Result dimensions: %-ld X %-ld   (Range x Azimuth)\n\n", outputFile->xDim, outputFile->yDim) ;
                }

                pInSAR->mod1.lenr = outputFile->xDim ;
                pInSAR->mod1.lena = outputFile->yDim ;
                
                inputFile->aoi = NULL ;
                freeRawFileDescriptor(inputFile) ;
                freeRawFileDescriptor(outputFile) ;
                free(inputFilePath) ;
                free(outputFilePath) ;
            }
            
            if(computeSlaveAmplitude){
                if (isFlagPresentInCSV(csv, "-i")) {
                    inputFilePath = initStringWith3Strings(pInSAR->interpolatedSlave->dataDirectoryPath, "/SLCData.", pInSAR->slavePolarizationChannel) ;
                }
                else {
                    inputFilePath = initStringWithString((pInSAR->ima2).filePath) ;
                }
                if ((inputFile = openRawFileForReadingAtPath(inputFilePath)) == NULL) {
                    sprintf(ertex, "Failed to open input file for reading.\n--> %s\n", inputFilePath) ;
                    ase(ertex) ;
                }
                inputFile->xDim = (pInSAR->ima2).lenr ;
                inputFile->yDim = (pInSAR->ima2).lena ;
                inputFile->xLowerIndex = xDimBorder ;
                inputFile->yLowerIndex = yDimBorder ;
                inputFile->aoi = aoi ;
                
                outputFilePath = initStringWithString((pInSAR->mod2).filePath) ;
                outputFile = openRawFileForWritingAtPath(outputFilePath) ;
                
                if (verbose) {
                    printf("Slave image:\t%s\n", inputFilePath) ;
                    printf("Result:\t%s\n", outputFilePath) ;
                    printf("Used reduction factors: (%-3d x %3d)   (Range x Azimuth)\n", xReductionFactor, yReductionFactor) ;
                }
                complexImageReduction(inputFile, outputFile, xReductionFactor, yReductionFactor) ;
                if (verbose) {
                    printf("Result dimensions: %-ld X %-ld   (Range x Azimuth)\n\n", outputFile->xDim, outputFile->yDim) ;
                }
                
                pInSAR->mod2.lenr = outputFile->xDim ;
                pInSAR->mod2.lena = outputFile->yDim ;
                
                inputFile->aoi = NULL ;
                freeRawFileDescriptor(inputFile) ;
                freeRawFileDescriptor(outputFile) ;
                free(inputFilePath) ;
                free(outputFilePath) ;
            }
            
            saveInSARParametersFileAtPath(pInSAR, InSARparametersFilePath) ;
            free(pInSAR) ;
        }
        
    }
    else {
        /* If no InSAR parameters, consider a single image to be reduced */
        /* parameters being passed as arguments */
        if ((anImage = getCSLImageStructureAtPath(csv->stringVal[1])) == NULL) {
            sprintf(ertex, "Input image is not a .csl image : %s", csv->stringVal[1]) ;
            ase(ertex) ;
        }

        if (csv->numberOfEntries < 4) {
            printf("Missing reduction parameters\n") ;
            amplitudeImageReductionHelp() ;
        }
        if(!sscanf(csv->stringVal[2], "%d", &xReductionFactor)) {
            ase("No valid x reduction factor given as second argument") ;
        }
        if(!sscanf(csv->stringVal[3], "%d", &yReductionFactor)) {
            ase("No valid y reduction factor given as second argument") ;
        }
        aPath = initStringWith2Strings(anImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
        infoImage = readInfoImageFromTextFile(aPath) ;
        free(aPath) ;
        xDim = infoImage->rangeDimension ;
        yDim = infoImage->azimuthDimension ;
        
        polMode = readCSVInString(infoImage->polMode) ;
        textFile = allocAKeyValuePair() ;
        setStringValForKeyIn(textFile, "Amplitude image(s) of available SLC channel(s)", "") ;
        setStringValForKeyIn(textFile, "**********************************************", "") ;
        
        for(i = 0; i < polMode->numberOfEntries; i++) {
            inputFilePath = initStringWith3Strings((char *)(anImage->dataDirectoryPath), "/SLCData.", polMode->stringVal[i]) ;
            if ((inputFile = openRawFileForReadingAtPath(inputFilePath))) {
                inputFile->xDim = xDim ;
                inputFile->yDim = yDim ;
                inputFile->xLowerIndex = 0 ;
                inputFile->yLowerIndex = 0 ;
                inputFile->aoi = aoi ;
                
                outputFilePath = initStringWith4Strings((char *)(anImage->dataDirectoryPath), "/SLCData.", polMode->stringVal[i], ".mod") ;
                outputFile = openRawFileForWritingAtPath(outputFilePath) ;
                
                sprintf(aComment, "Channel %d outputFilename", i + 1) ;
                setStringValForKeyIn(textFile, getPointerToFileNameInPath(outputFilePath), aComment) ;
                printf("Input image:\t%s\n", inputFilePath) ;
                printf("Result:\t%s\n", outputFilePath) ;
                complexImageReduction(inputFile, outputFile, xReductionFactor, yReductionFactor) ;
                printf("Result dimensions: %-ld X %-ld   (Range x Azimuth)\n\n", outputFile->xDim, outputFile->yDim) ;
                xReducedDim = outputFile->xDim ;
                yReducedDim = outputFile->yDim ;
                
                freeRawFileDescriptor(inputFile) ;
                freeRawFileDescriptor(outputFile) ;
                free(inputFilePath) ;
                free(outputFilePath) ;
            }
            else {
                printf("--> Requested %s polarization not found. Skipping reduction\n", polMode->stringVal[i]) ;
            }
        }
        
        setStringValForKeyIn(textFile, "", "") ;
        setIntValForKeyIn(textFile, xDim, "SLC X size [pixels]") ;
        setIntValForKeyIn(textFile, yDim, "SLC Y size [pixels]") ;
        setIntValForKeyIn(textFile, xReductionFactor, "X reduction factor [pixels]") ;
        setIntValForKeyIn(textFile, yReductionFactor, "Y reduction factor [pixels]") ;
        setIntValForKeyIn(textFile, xReducedDim, "Reduced image X size [pixels]") ;
        setIntValForKeyIn(textFile, yReducedDim, "Reduced image Y size [pixels]") ;
        aPath = initStringWith2Strings(anImage->infoDirectoryPath, "/modImageInfo.txt") ;
        writeParameterFileAtPath(textFile, aPath) ;
        
        free(aPath) ;
        freeKeyValueList(textFile) ;
    }
    if (verbose) {
        time(&endTime) ;
        duration(startTime, endTime) ;
    }
    
    return(0) ;
}


void amplitudeImageReductionHelp()
{
    printf("\nUsage:\n-1- amplitudeImagesReduction [/pathTo/InSARParameters.txt] [masterOnly / slaveOnly]\n") ;
    printf("\nThis routine will compute the amplitude master and slave images.\n") ;
    printf("Amplitude is computed by box averaging to lead to reduced images.\n") ;
    printf("\nIf used with no parameters, the routine will look for an \"InSARparameters.txt\".\n") ;
    printf("file within the working directory or within the ./TextFiles subdirectory.\n") ;
    printf("Any other path to a text file containing InSAR parameters can be given as\nfirst parameter.\n\n") ;
    printf("Additionaly, the keywords \"slaveOnly\" or\"masterOnly\" can be used to compute\n the reduced amplitude image of a single image\n") ;
    printf("\n-2- amplitudeImagesReduction /pathTo/Image xReductionFactor yReductionFactor\n") ;
    printf("In this case, the first parameter must be the path to an image in CSL format\n") ;
    printf("The second parameter must be an integer value giving the reducing factor in X\n") ;
    printf("The third parameter must be an integer value giving the reducing factor in Y\n") ;
    printf("\n-3- amplitudeImageReduction path=/pathToFile xDim=xDimension yDim=yDimension rX=xReductionFactor rY=yReductionFactor\n") ;
    exit(0) ;
}



int	complexImageReduction(rawFileDescriptor *inputFile, rawFileDescriptor *outputFile, int xReductionFactor, int yReductionFactor)
{
    int i, j ;
    size_t k, l, xDim, yDim ;
    int inputRangeIndex, dX ;
    size_t xReducedDim, yReducedDim ;
    float *outputImage, Norme ;
    complexFloat	**inputImage ;
    progressCounter *aCounter ;
    polygon *aoi ;
    
    
    /* ------------------- Amplitude image reduction ------------------- */
    
    xDim = inputFile->xDim ;
    yDim = inputFile->yDim ;
    aoi = inputFile->aoi ;
    if (aoi == NULL) {
        aoi = allocQuadrilateral() ;
        aoi->P[0].x = aoi->P[3].x = aoi->P[0].y = aoi->P[1].y = 0 ;
        aoi->P[1].x = aoi->P[2].x = xDim - 1 ;
        aoi->P[2].y = aoi->P[3].y = yDim - 1 ;
    }
    dX = (int)(round(aoi->P[0].x)) ;

    outputFile->xDim = xReducedDim = (aoi->P[1].x - aoi->P[0].x + 1 - 2 * inputFile->xLowerIndex) / xReductionFactor ;
    outputFile->yDim = yReducedDim = (aoi->P[3].y - aoi->P[0].y + 1 - 2 * inputFile->yLowerIndex) / yReductionFactor ;
    inputImage = matrixComplexFloat(0, yReductionFactor - 1, 0, xDim - 1) ;
    outputImage = vectorFloat(0, xReducedDim - 1) ;
    
    Norme = (float)(yReductionFactor * xReductionFactor) ;
    aCounter = initProgressCounterWithMinMaxValue(0, yReducedDim - 1) ;
    
    fseek(inputFile->f, (inputFile->yLowerIndex + aoi->P[0].y) * xDim * sizeof(complexFloat), SEEK_SET) ;
    for(k = 0; k < yReducedDim; k++) {
        if(xDim * yReductionFactor != fread((complexFloat *)inputImage[0], sizeof(complexFloat), xDim * yReductionFactor, inputFile->f)) {
            sprintf(ertex, "Failed to read into input file %s", inputFile->accessPath) ;
            perror(ertex) ;
            exit(-1) ;
        }
        
        for(l = 0; l < xReducedDim; l++) {
            outputImage[l] = 0. ;
            for(i = 0; i < yReductionFactor; i++) {
                inputRangeIndex = l * xReductionFactor + inputFile->xLowerIndex + dX ;
                for(j = 0; j < xReductionFactor; j++, inputRangeIndex++)
                    outputImage[l] += sqmC(inputImage[i][inputRangeIndex]) ;
            }
            outputImage[l] = sqrtf(outputImage[l] / Norme) ;
            
            /* If calibration is requested, do it */
/*
 if(pInSAR) {
            if (pInSAR->flag & _CALIBRATE_IN_SIGMA0_) {
                H = externalSlantRangeDEM[l] ;
                earthRadiusAtPoint(rangePosition, azimuthPosition, H, pInSAR->geo) ;
                anIndex = (l)? l - 1 : 0 ;
                deltaH = externalSlantRangeDEM[l] - externalSlantRangeDEM[(l)? l - 1 : 0] ;
                slope = (deltaH * sin(pInSAR->geo->solving->alpha) / ((rangeReductionFactor * pInSAR->masterInfo->rangeResolutionCell) + deltaH * cos(pInSAR->geo->solving->alpha))) ;
                
                sinAlpha = sin(pInSAR->geo->solving->alpha) * cos(atan(slope)) / (1. + deltaH / (rangeReductionFactor * pInSAR->masterInfo->rangeResolutionCell) * cos(pInSAR->geo->solving->alpha)) ;
                sinAlpha = fabs(sinAlpha) ;
                
                outputImage[l] = (sinAlpha)? 10 * (2 * log10f(outputImage[l]) - 2 * log10f(pInSAR->averageBeta0CalibrationConstant) + log10f((float)sinAlpha)) : -80. ;
                outputImage[l] = (outputImage[l] < -80)? -80. : outputImage[l] ;
            }
 }
*/

        }
        if(xReducedDim != fwrite((float *)outputImage, sizeof(float), xReducedDim, outputFile->f)) {
            sprintf(ertex, "Failed to write into output file %s", outputFile->accessPath) ;
            perror(ertex) ;
            exit(-1) ;
        }
        updatePointProgressCounterForIndex(aCounter, k) ;
    }
    updatePointProgressCounterForIndex(aCounter, k) ;
    
    freeMatrixComplexFloat(inputImage, 0, 0) ;
    freeVectorFloat(outputImage, 0) ;
    freeProgressCounter(aCounter) ;
    if (inputFile->aoi == NULL) {
        freePolygon(aoi) ;
    }
    return(0) ;
}

int    imageReduction(rawFileDescriptor *inputFile, rawFileDescriptor *outputFile, int xReductionFactor, int yReductionFactor, char whatToDo)
{
    int i, j ;
    size_t k, l, xDim, yDim ;
    int inputRangeIndex; 
    size_t xReducedDim, yReducedDim ;
    float *outputImage, Norme ;
    float **inputImage ;
    complexFloat aComplex ;
    progressCounter *aCounter ;
    polygon *aoi ;
    
    
    /* ------------------- Amplitude image reduction ------------------- */
    
    xDim = inputFile->xDim ;
    yDim = inputFile->yDim ;
    aoi = inputFile->aoi ;
    if (aoi == NULL) {
        aoi = allocQuadrilateral() ;
        aoi->P[0].x = aoi->P[3].x = aoi->P[0].y = aoi->P[1].y = 0 ;
        aoi->P[1].x = aoi->P[2].x = xDim - 1 ;
        aoi->P[2].y = aoi->P[3].y = yDim - 1 ;
    }
    outputFile->xDim = xReducedDim = (aoi->P[1].x - aoi->P[0].x + 1 - 2 * inputFile->xLowerIndex) / xReductionFactor ;
    outputFile->yDim = yReducedDim = (aoi->P[3].y - aoi->P[0].y + 1 - 2 * inputFile->yLowerIndex) / yReductionFactor ;
    inputImage = matrixFloat(0, yReductionFactor - 1, 0, xDim - 1) ;
    outputImage = vectorFloat(0, xReducedDim - 1) ;
    
    Norme = (float)(yReductionFactor * xReductionFactor) ;
    aCounter = initProgressCounterWithMinMaxValue(0, yReducedDim - 1) ;
    
    fseek(inputFile->f, (inputFile->yLowerIndex + aoi->P[0].y) * xDim * sizeof(float), SEEK_SET) ;
    for(k = 0; k < yReducedDim; k++) {
        if(xDim * yReductionFactor != fread((float *)inputImage[0], sizeof(float), xDim * yReductionFactor, inputFile->f)) {
            sprintf(ertex, "Failed to read into input file %s", inputFile->accessPath) ;
            perror(ertex) ;
            exit(-1) ;
        }
        
        for(l = 0; l < xReducedDim; l++) {
            outputImage[l] = 0. ;
            aComplex.r = aComplex.i = 0 ;
            for(i = 0; i < yReductionFactor; i++) {
                inputRangeIndex = l * xReductionFactor + inputFile->xLowerIndex + aoi->P[0].x ;
                for(j = 0; j < xReductionFactor; j++, inputRangeIndex++) {
                    if (whatToDo == 1) {
                        aComplex.r += cosf(inputImage[i][inputRangeIndex]) ;
                        aComplex.i += sinf(inputImage[i][inputRangeIndex]) ;
                    }
                    else
                        outputImage[l] += inputImage[i][inputRangeIndex] ;
                }
            }
            if (whatToDo == 1)
                outputImage[l] = phiC(aComplex) ;
            else
                outputImage[l] = outputImage[l] / Norme ;
        }
        if(xReducedDim != fwrite((float *)outputImage, sizeof(float), xReducedDim, outputFile->f)) {
            sprintf(ertex, "Failed to write into output file %s", outputFile->accessPath) ;
            perror(ertex) ;
            exit(-1) ;
        }
        updatePointProgressCounterForIndex(aCounter, k) ;
    }
    updatePointProgressCounterForIndex(aCounter, k) ;
    
    freeMatrixFloat(inputImage, 0, 0) ;
    freeVectorFloat(outputImage, 0) ;
    freeProgressCounter(aCounter) ;
    if (inputFile->aoi == NULL) {
        freePolygon(aoi) ;
    }
    return(0) ;
}

void rawFileReduction(CSVStruct *csv)
{
    char *inputFilePath, *outputFilePath ;
    char whatToDo ;
    int argumentIndex, xDim, yDim, xReductionFactor, yReductionFactor ;
    rawFileDescriptor *inputFile, *outputFile ;

    argumentIndex = isArgumentPresentInCSV(csv, "path=") ;
    inputFilePath = initStringWithString(csv->stringVal[argumentIndex] + 5) ;

    argumentIndex = isArgumentPresentInCSV(csv, "xDim=") ;
    sscanf(csv->stringVal[argumentIndex], "xDim=%d", &xDim) ;
    argumentIndex = isArgumentPresentInCSV(csv, "yDim=") ;
    sscanf(csv->stringVal[argumentIndex], "yDim=%d", &yDim) ;
    argumentIndex = isArgumentPresentInCSV(csv, "rX=") ;
    sscanf(csv->stringVal[argumentIndex], "rX=%d", &xReductionFactor) ;
    argumentIndex = isArgumentPresentInCSV(csv, "rY=") ;
    sscanf(csv->stringVal[argumentIndex], "rY=%d", &yReductionFactor) ;
    
    whatToDo = isFlagPresentInCSV(csv, "i") ;
    whatToDo += 2 * isFlagPresentInCSV(csv, "f") ;
    if (whatToDo) {
        if (whatToDo == 1)
            printf("Phase image reduction of phase image at path: %s\n", inputFilePath) ;
        else
            printf("Float image reduction of float image at path: %s\n", inputFilePath) ;
       outputFilePath = initStringWith2Strings(inputFilePath, ".red") ;
    }
    else {
        printf("Amplitude image reduction of complex image at path: %s\n", inputFilePath) ;
        outputFilePath = initStringWith2Strings(inputFilePath, ".mod") ;
    }
    printf("Result image: %s\n", outputFilePath) ;
    printf("Input image dimensions: %d X %d\n", xDim, yDim) ;
    printf("Reduction factors: %d X %d\n", xReductionFactor, yReductionFactor) ;

    inputFile = openRawFileForReadingAtPath(inputFilePath) ;
    inputFile->xDim = xDim ;
    inputFile->yDim = yDim ;
    outputFile = openRawFileForWritingAtPath(outputFilePath) ;
    
    if (whatToDo) {
        imageReduction(inputFile, outputFile, xReductionFactor, yReductionFactor, whatToDo) ;
    }
    else {
        complexImageReduction(inputFile, outputFile, xReductionFactor, yReductionFactor) ;
    }

    printf("Result image dimensions: %ld X %ld\n\n", outputFile->xDim, outputFile->yDim) ;

    free(inputFilePath) ;
    free(outputFilePath) ;
    freeRawFileDescriptor(inputFile) ;
    freeRawFileDescriptor(outputFile) ;
}
