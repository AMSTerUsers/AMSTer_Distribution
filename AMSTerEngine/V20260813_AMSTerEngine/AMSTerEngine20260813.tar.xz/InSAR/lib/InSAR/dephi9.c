
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678*/
/* Program dephi9.c                       */
/* Author : DERAUW D. , SAREOS            */


#include "dephi9.h"


/* main programm start */
int branchCutPhaseUnwrapping(InSARParametersStruct *pInSAR)
{
	/* local variables declaration */
	unsigned char	**connexions, **mask, biggestZoneIndex = '\0' ;
    char *aPath, *coherenceFilePath, *detPhUnPhaseComponentFileName ;
	int		lena_phi, lenr_phi ;
	int		i, j, i0, j0, Da, Dr ;
	int		rangePosition, azimuthPosition ;
    int unsigned maxZoneSize ;
	long	seekValue ;
	float	**biasedCoherence ;
    float *detPhUnComponentLine ;
	rawFileDescriptor *interferogramFile, *aFile = NULL, *zoneMapFile ;
    rawFileDescriptor *detPhUnPhaseComponent ;
    floatMatrix *unwrappedPhaseObject ;
    struct pdd normalization ;
//    rawFileDescriptor *brol ;

/*----------------------------------  INITIALISATION  -----------------------------------*/
	genFloatInf() ;
	DephiOk = floatInf ;

    /* Open requested interferogram */
    interferogramFile = selectInterferogram(pInSAR) ;

    /* Open first phase component if required */
    if (pInSAR->flag & FIRST_PHASE_COMPONENT_EXISTS) {
        openFirstPhaseComponentFile(pInSAR) ;
        if (pInSAR->flag & FLATTENING_CORRECTION) {
            if(!openCoherenceFile(pInSAR))
                ase("Failed to open coherence file") ;
        }
    }

    /* Test if deformation measurement is considered ...*/
    defoOrTopo(pInSAR) ;

    /* Open connexion file */
    pInSAR->connexionsFile = openRawFileForReadingAtPath((pInSAR->conex).filePath) ;

    /* Update resuts dimensions */
	lena_phi = (pInSAR->interf).lena ;
	lenr_phi = (pInSAR->interf).lenr ;
	lena = (pInSAR->conex).lena ;
	lenr = (pInSAR->conex).lenr ;
	(pInSAR->dephi).lena = (pInSAR->srDEM).lena = lena - 1 ;
	(pInSAR->dephi).lenr = (pInSAR->srDEM).lenr = lenr - 1 ;


    /* Create unwrapped phase file for output */
    openUnwrappedPhaseFile(pInSAR) ;

	printf("Phase unwrapping\n") ;
	printf("****************\n") ;
	printf("interferogram file: %s\n", interferogramFile->accessPath) ;
	printf("Connexions image file: %s\n", pInSAR->connexionsFile->accessPath) ;
	printf("Unwrapped phase file: %s\n", pInSAR->unwrappedPhaseFile->accessPath);
	if(pInSAR->flag & _PHASE_TO_MEASUREMENT_CONVERSION_) {
        if (pInSAR->flag & _TOPO_) {
            rangePosition = lenr_phi / 2 * (pInSAR->red).Fra  + (pInSAR->sup).Sgra + (pInSAR->coh).spi / 2 + (pInSAR->coh).cor / 2 ;
            azimuthPosition = lena_phi / 2 * (pInSAR->red).Faz  + (pInSAR->sup).Sbaz + (pInSAR->coh).spi / 2 + (pInSAR->coh).cor / 2 ;
            pInSAR->ambiguityAltitude = ambiguityAltitudeAtPoint(rangePosition, azimuthPosition, 0., pInSAR) ;
            printf("Ambiguity altitude at interferogram centre: %f\n", pInSAR->ambiguityAltitude) ;
        }
	}


	/* ------------------- Allocation de mémoire et lecture de l'image des résidus ------------------- */

	connexions = matrixUChar(0, lena - 1, 0, lenr-1) ;
	ptr_first_res = connexions[0] ;

	fread (connexions[0], sizeof(unsigned char), lena * lenr, pInSAR->connexionsFile->f) ;
    if (pInSAR->flag & _COHERENCE_THRESHOLD_) {
        biasedCoherence = matrixFloat(0, 1, 0, lenr + 1) ;

        coherenceFilePath = (pInSAR->cohder).filePath ;
        if((pInSAR->biasedCoherenceFile = openRawFileForReadingAtPath(coherenceFilePath)) == NULL)
            ase("Failed to open biased coherence image file for reading\n") ;
        for(i = 0; i < lena; i++) {
            seekValue = (long)(i * (lenr + 1)) * sizeof(float) ;
            fseek(pInSAR->biasedCoherenceFile->f, seekValue, 0) ;
            fread (biasedCoherence[0], sizeof(float), 2 * (lenr + 1), pInSAR->biasedCoherenceFile->f) ;
            for(j = 0; j < lenr; j++) {
                if (((biasedCoherence[0][j] + biasedCoherence[0][j + 1] + biasedCoherence[1][j] + biasedCoherence[1][j + 1]) / 4.) < pInSAR->conex.seuilnet)
                    connexions[i][j] = 255 ;
            }
        }
        freeMatrixFloat(biasedCoherence, 0, 0) ;
    }

	/* ------------------- Allocation de mémoire et lecture de l'interférogramme ------------------- */
	interferometricPhase = matrixFloat(0, (pInSAR->dephi).lena - 1, 0, (pInSAR->dephi).lenr - 1) ;
	ptr_first_phi = interferometricPhase[0] ;

	Da = ((pInSAR->interf).lena - (pInSAR->dephi).lena)/2 ;
	Dr = ((pInSAR->interf).lenr - (pInSAR->dephi).lenr)/2 ;
	for(i = 0; i < (pInSAR->dephi).lena ; i++) {
		seekValue = (long)((Da + i) * lenr_phi + Dr) * sizeof(float) ;
		fseek(interferogramFile->f, seekValue, 0) ;
		fread (&interferometricPhase[i][0], sizeof(float), (pInSAR->dephi).lenr, interferogramFile->f) ;
	}

    /* Allocate and read coherence file if needed */
    ptr_first_coh = NULL ;
    if (pInSAR->flag & FLATTENING_CORRECTION) {
        coherence = matrixFloat(0, (pInSAR->dephi).lena - 1, 0, (pInSAR->dephi).lenr - 1) ;
        ptr_first_coh = coherence[0] ;
        for(i = 0; i < (pInSAR->dephi).lena ; i++) {
            seekValue = (long)((Da + i) * lenr_phi + Dr) * sizeof(float) ;
            fseek(pInSAR->coherenceFile->f, seekValue, 0) ;
            fread (&coherence[i][0], sizeof(float), (pInSAR->dephi).lenr, pInSAR->coherenceFile->f) ;
        }
    }

    /* Allocate zone map */
    zoneMap = matrixIntUnsigned(0, (pInSAR->dephi).lena - 1, 0, (pInSAR->dephi).lenr - 1) ;
    zoneIndex = 0 ;
    aPath = initStringWith2Strings((pInSAR->dephi).filePath, ".zoneMap") ;
    zoneMapFile = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;

	/* ------------------- Allocation de mémoire et initialisation de l'interférogramme déroulé ------------------- */

    unwrappedPhaseObject = allocFloatMatrixWithIndexes(0, (pInSAR->dephi).lena - 1, 0, (pInSAR->dephi).lenr - 1) ;
	unwrappedPhase = unwrappedPhaseObject->mf ;
	ptr_first_dephi = unwrappedPhase[0] ;

	for(i = 0; i < (pInSAR->dephi).lena ; i++)
		for(j = 0; j < (pInSAR->dephi).lenr; j++) unwrappedPhase[i][j] = DephiOk ;

	/* ------------------- Allocation de mémoire du debut de la pile ------------------- */

	if ((ptr_dpile = (struct pile *)calloc (1, sizeof(struct pile))) == NULL)
	{
		sprintf (ertex, "Erreur d'allocation sur ptr_pile") ;
		ase (ertex) ;
	}
	ptr_dpile->suiv = (struct pile *)NULL ;


	/* ------------------- Deroulement de la phase dans l'interférogramme ------------------- */
    /* Init starting point structure */
    pdd.zoneIndex = 0 ;
    normalization.M = matrixDouble(1, 3, 1, 3) ;
    normalization.V = vectorDouble(1, 3) ;
    if (pInSAR->flag & FLATTENING_CORRECTION) {
        pdd.M = matrixDouble(1, 3, 1, 3) ;
        pdd.V = vectorDouble(1, 3) ;

        maxZoneSize = 0 ;
        /* First run to find biggest zone on which compute the slope of the plane to be removed */
        while(ps(0)) {
            i0 = pdd.az ;
            j0 = pdd.ra ;

            apile(i0, j0, 1) ;
            apile(i0-1, j0, 0) ;
            while(ptr_dpile->suiv != (struct pile *)NULL)
            {
                if(ptr_dpile->hb ) haut() ;
                else bas() ;
            }

            decphi(pInSAR) ;
            if (maxZoneSize < pdd.validZoneSize) {
                normalization.V[1] = pdd.V[1] ;
                normalization.V[2] = pdd.V[2] ;
                normalization.xM = pdd.xM ;
                normalization.yM = pdd.yM ;
                normalization.V[3] = pdd.V[3] ;
                normalization.phaseAvg = pdd.phaseAvg ;
                maxZoneSize = pdd.validZoneSize ;
                biggestZoneIndex = pdd.zoneIndex ;
            }

        }

//        normalization.V[1] /= pdd.zoneIndex ;
//        normalization.V[2] /= pdd.zoneIndex ;
//        normalization.V[3] = normalization.phaseAvg - normalization.V[1] * normalization.xM - normalization.V[2] * normalization.yM - normalization.V[3] ;

        for(i = 0; i < (pInSAR->dephi).lena ; i++)
            for(j = 0; j < (pInSAR->dephi).lenr; j++) unwrappedPhase[i][j] = DephiOk ;
        ps(1) ;
    }

    /* Now proceed to phase unwrapping */
    zoneIndex = 0 ;
    pdd.zoneIndex = 0 ;
	while(ps(0)) {
		i0 = pdd.az ;
		j0 = pdd.ra ;

        apile(i0, j0, 1) ;
		apile(i0-1, j0, 0) ;
		while(ptr_dpile->suiv != (struct pile *)NULL)
		{
			if(ptr_dpile->hb ) haut() ;
			else bas() ;
		}

 		decphi(pInSAR) ;
        if (pInSAR->flag & FLATTENING_CORRECTION) {
            memcpy(&pdd.V[1], &normalization.V[1], 3 * sizeof(double)) ;
            if (pdd.zoneIndex != biggestZoneIndex) {
//                pdd.V[3] = normalization.V[3] + pdd.phaseAvg - pdd.V[1] * pdd.xM - pdd.V[2] * pdd.yM - pdd.V[3] ;
                pdd.V[3] = pdd.phaseAvg ;
            }
        }

        if (pInSAR->flag & _NO_PHASE_NORMALIZATION_) {
            if (pInSAR->flag & FLATTENING_CORRECTION) {
                pdd.V[1] = pdd.V[2] = pdd.V[3] = 0 ;
            }
            pdd.min = 0.0 ;
        }

		apileNorme(i0, j0, 1) ;
		apileNorme(i0 - 1, j0, 0) ;
		while(ptr_dpile->suiv != (struct pile *)NULL)
		{
			if(ptr_dpile->hb ) normhaut() ;
			else normbas() ;
		}

	}

/*
    aPath = initStringWith2Strings(pInSAR->unwrappedPhaseFile->accessPath, ".out") ;
    brol = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;
    fwrite(unwrappedPhase[0], sizeof(float), (pInSAR->dephi).lena * (pInSAR->dephi).lenr, brol->f) ;
    freeRawFileDescriptor(brol) ;
*/

    /* If some isolated points are not unwrapped, their unwrapped phase is equal to their phase */
    /* Those points are those surrounded by connexions */
    /* They can be issued as a mask for excluding points during the geoprojection process */
    zoneIndex = 0 ;
    mask = NULL ;
    if (pInSAR->flag & _COHERENCE_THRESHOLD_) {
        aPath = initStringWith2Strings(interferogramFile->directoryPath, "/mask") ;
        aFile = openRawFileForWritingAtPath(aPath) ;
        free(aPath) ;
        mask = matrixUChar(0, pInSAR->dephi.lena - 1, 0, pInSAR->dephi.lenr - 1) ;
    }
    for(i = 0; i < (pInSAR->dephi).lena ; i++) {
        for(j = 0; j < (pInSAR->dephi).lenr; j++) {
            if (pInSAR->flag & _COHERENCE_THRESHOLD_) {
                mask[i][j] = (unwrappedPhase[i][j] == DephiOk)? 0 : 255 ;
            }

            if(unwrappedPhase[i][j] == DephiOk) {
                zoneMap[i][j] = zoneIndex ;
                unwrappedPhase[i][j] = (pInSAR->flag & _NO_NAN_FILL_)? interferometricPhase[i][j] : pInSAR->DEMExcludingValue ;
            }
        }
    }
    if (pInSAR->flag & _COHERENCE_THRESHOLD_) {
        fwrite (mask[0], sizeof(mask[0][0]), (lena - 1) * (lenr - 1), aFile->f) ;
        freeRawFileDescriptor(aFile) ;
        freeMatrixUChar(mask, 0, 0) ;
    }
    printf("Phase unwrapping done\n") ;

    /* If detPhUn preprocessing, add the two phase components */
    if (pInSAR->flag & _DETPHUN_) {
        detPhUnPhaseComponentFileName = initStringWith2Strings(pInSAR->dephi.filePath, ".detPhUn") ;
        detPhUnPhaseComponent = openRawFileForReadingAndWritingAtPath(detPhUnPhaseComponentFileName) ;
        detPhUnComponentLine = vectorFloat(0, (pInSAR->dephi).lenr - 1) ;
        for(i = 0; i < (pInSAR->dephi).lena ; i++) {
            seekValue = (long)((Da + i) * lenr_phi + Dr) * sizeof(float) ;
            fseek(detPhUnPhaseComponent->f, seekValue, SEEK_SET) ;
            fread (detPhUnComponentLine, sizeof(float), (pInSAR->dephi).lenr, detPhUnPhaseComponent->f) ;

            for ( j = 0; j < (pInSAR->dephi).lenr; j++) {
                unwrappedPhase[i][j] += detPhUnComponentLine[j] ;
            }
        }
        freeVectorFloat(detPhUnComponentLine, 0) ;
        
        /* Unlink detphun phase component */
        unlink(detPhUnPhaseComponentFileName) ;
        free(detPhUnPhaseComponentFileName) ;
        freeRawFileDescriptor(detPhUnPhaseComponent) ;
        
        /* Unlink intermediate phase residue */
        closeRawFile(interferogramFile) ;
        unlink(interferogramFile->accessPath) ;
    }

    /* Save unwrapped phase */
    fwrite (unwrappedPhase[0], sizeof(float), (pInSAR->dephi).lena * (pInSAR->dephi).lenr, pInSAR->unwrappedPhaseFile->f) ;
    printf("Unwrapped phase image size: %-4d X %-4d\n", (pInSAR->dephi).lenr, (pInSAR->dephi).lena) ;
    fflush(pInSAR->unwrappedPhaseFile->f) ;

    /* Save zone map */
	fwrite (zoneMap[0], sizeof(int unsigned), (pInSAR->dephi).lena * (pInSAR->dephi).lenr, zoneMapFile->f) ;
	freeRawFileDescriptor(zoneMapFile) ;

	freeFloatMatrix(unwrappedPhaseObject) ;
	freeMatrixFloat(interferometricPhase, 0, 0) ;
	freeMatrixUChar(connexions, 0, 0) ;


    if (ptr_first_coh != NULL) {
        freeMatrixFloat(coherence, 0, 0) ;
        freeMatrixDouble(pdd.M, 1, 1) ;
        freeVectorDouble(pdd.V, 1) ;
        freeMatrixDouble(normalization.M, 1, 1) ;
        freeVectorDouble(normalization.V, 1) ;
    }

    freeSelectedInterferogram(pInSAR) ;

    return (1) ;
}

/* ------------------- Fonctions ------------------- */


/* ________________ Valeur de normalisation ________________ */

void decphi(InSARParametersStruct *pInSAR)
{
	int rangePosition, azimuthPosition ;
    int	*index, i, j ;
    double hamin, hamax, signe ;

	rangePosition = (pdd.minra * (pInSAR->red).Fra + (pInSAR->sup).Sgra + (pInSAR->coh).spi / 2 + (pInSAR->coh).cor / 2) ;
	azimuthPosition = (pdd.minaz * (pInSAR->red).Faz + (pInSAR->sup).Sbaz) + (pInSAR->coh).spi / 2 + (pInSAR->coh).coa / 2 ;
	hamin = ambiguityAltitudeAtPoint(rangePosition, azimuthPosition, 0., pInSAR) ;

	rangePosition = (pdd.maxra * (pInSAR->red).Fra + (pInSAR->sup).Sgra + (pInSAR->coh).spi / 2 + (pInSAR->coh).cor / 2) ;
	azimuthPosition = (pdd.maxaz * (pInSAR->red).Faz + (pInSAR->sup).Sbaz) + (pInSAR->coh).spi / 2 + (pInSAR->coh).coa / 2 ;
	hamax = ambiguityAltitudeAtPoint(rangePosition, azimuthPosition, 0., pInSAR) ;

	if((hamin < 0) && (hamax < 0)) {
		pdd.min = pdd.max ;
		pdd.minaz = pdd.maxaz ;
		pdd.minra = pdd.maxra ;
	}

    if (pInSAR->flag & FIRST_PHASE_COMPONENT_EXISTS) {
        /* If a first phase component is given, ideally we should know a fixed point for which the altitude is unchanged */
        /* This point should be used to find the normalization value in order to set its residual unwrapped phase to zero */
        /* Since we do not have a reference point, the generated DEM will once again be relative. */
        /* To reduce the error, the phase normalization gap is set to the average measured unwrapped residual phase */
        pdd.phaseAvg /= (double)pdd.cohAvg ;
        pdd.xM /= (double)pdd.cohAvg ;
        pdd.yM /= (double)pdd.cohAvg ;
        pdd.min = pdd.phaseAvg ;

        if (pInSAR->flag & FLATTENING_CORRECTION) {
            /* Here, we compute the best plane to be removed for the zone under concern */
            /* If the zone is smaller than 5x5 pixels, we simply apply a global phase shift */
            pdd.xM /= pdd.validZoneSize ;
            pdd.yM /= pdd.validZoneSize ;
            if (pdd.validZoneSize > 25) {
                index = vectorInt(1, 3) ;
                for(i = 1; i <= 3; i++) {
                    for(j = i + 1; j <= 3; j++) {
                        pdd.M[j][i] = pdd.M[i][j] ;
                    }
                }
                ludcmp(pdd.M, 3, index, &signe) ;
                lubksb(pdd.M, 3, index, pdd.V) ;

                freeVectorInt(index, 1) ;
            }
            else {
                pdd.V[1] = pdd.V[2] = 0 ;
                pdd.V[3] = pdd.phaseAvg ;
            }
        }
    }
}

