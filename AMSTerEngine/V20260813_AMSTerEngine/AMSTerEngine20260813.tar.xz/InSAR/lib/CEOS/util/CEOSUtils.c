
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  CEOSUtils.c
//  Some small functions to clean a few old CEOS reader programs
//
//  Created by Dominique Derauw on 19/03/2021.
//  Copyrights SAREOS - Dominique Derauw
//
//

#include "CEOSUtils.h"

struct CEOS_LF *allocCEOSLeaderFileStruct() 
{
    struct CEOS_LF *lf ;

    if((lf = (struct CEOS_LF *)malloc(sizeof(struct CEOS_LF))) == NULL) {
        ase("Failed to allocate Leader File structure\n") ;
    }

    lf->dss = NULL ;
    lf->map = NULL ;
    lf->platform = NULL ;
    lf->facility = NULL ;
    lf->state = NULL ;
//    lf->lineRecordHeader = NULL ;

    return (lf) ;
}


/* Volume Directory File reader*/
struct CEOS_VDF	*readCEOS_VDF(char *VDFFilePath)
{
	int i ;
    char *aString ;
    struct CEOS_VDF	*vdf ;
	rawFileDescriptor *VDFFile ;
    
    /* Volume Directory File opening */
	if((VDFFile = openRawFileForReadingAtPath(VDFFilePath)) == NULL) {
		ase("Failed to open Volume Directory File\n") ;
    }
	
    if((vdf = (struct CEOS_VDF *)malloc(sizeof(struct CEOS_VDF))) == NULL) {
        ase("Failed to allocate VDF header Structure\n") ;
    }

    if (fread(&(vdf->fdr), 1, sizeof(struct fdr), VDFFile->f) != sizeof(struct fdr)) {
        ase("Failed to read File Data Record\n") ;
    }
    aString = initStringWithStringOfLength(vdf->fdr.log_set_id, 16) ;
    printf("\t---> Dealing with %s data.\n", aString) ;
    free(aString) ;

	vdf->numberOfFilePointerRecords = readIntInASCIIStringOfLength(vdf->fdr.num_fil_ptr, 4) ;
	if((vdf->fpr = malloc(sizeof(struct fpr) * vdf->numberOfFilePointerRecords)) == NULL) {
        ase("Failed to allocate VDF header Structure\n") ;
    }
	
	for(i = 0; i < vdf->numberOfFilePointerRecords; i++) {
		fread(&(vdf->fpr[i]), sizeof(struct fpr), 1, VDFFile->f) ;
    }
	fread(&(vdf->text), 1, sizeof(struct text), VDFFile->f) ;
	    
	freeRawFileDescriptor(VDFFile) ;
    return vdf ;
}

/* Leader File Reader */
struct CEOS_LF	*readCEOS_LF(char *LFFilePath)
{
    char isRSAT1 = 0 ;
    int i, numberOfRecords, numberOfStateVectors, recordLength ;
    long fileShift, filePos ;
    struct CEOS_LF		*lf ;
	rawFileDescriptor *LFFile ;
    
    lf = allocCEOSLeaderFileStruct() ;
    
    /* Leader File opening */
	if((LFFile = openRawFileForReadingAtPath(LFFilePath)) == NULL)
		ase("Failed to open Volume Directory File\n") ;

    /* Leader File reading in CHAR format */
    /* File Descriptor Record reading */
    recordLength = sizeof(struct fdr_fix_seg) ;
    if ((fread(&lf->fdr_fix, sizeof(struct fdr_fix_seg), 1, LFFile->f)) != 1) {
        ase("Faild to read Data set summary record") ;
    }
    recordLength = sizeof(struct leader_var_seg) ;
    if ((fread(&lf->fdr_var, sizeof(struct leader_var_seg), 1, LFFile->f)) != 1) {
        ase("Faild to read Data set summary record") ;
    }

    if (!strncmp(lf->fdr_fix.file_name, "RSAT-1", 6)) {
        isRSAT1 = 1 ;
        if (strncmp(lf->fdr_fix.file_name, "RSAT-1-SAR-SLC", 14)) {
            printf("\t---> %.14s\n", lf->fdr_fix.file_name) ;
            ase("\t-/-> RadarSat-1 image is not SLC") ;
        }
    }

    /* Data Set Summary Record reading*/
    numberOfRecords = readIntInASCIIStringOfLength(lf->fdr_var.n_data_set_summ_rec, 6) ; 
    if(!numberOfRecords) {
        ase("Leader File wrong format : No Data Set Summary Record\n") ;
    }
    else {
        recordLength = sizeof(struct dss) ;
        fileShift = readIntInASCIIStringOfLength(lf->fdr_var.data_set_summ_rec_len, 6) ;
        fileShift -= recordLength ;
        if((lf->dss = (struct dss *)malloc(sizeof(struct dss))) == NULL) {
            ase("Failed toi allocate Data Set Summary Record\n") ;
        }

        if ((fread(lf->dss, (size_t)recordLength, (size_t)1, LFFile->f) != 1)) {
            ase("Faild to read Data set summary record") ;
        }

        if (fseek(LFFile->f, fileShift, SEEK_CUR)) {
            ase("Failed to seek within leader file\n") ;
        }
    }
    
    /* Lecture du Map Projection Record */
    numberOfRecords = readIntInASCIIStringOfLength(lf->fdr_var.n_map_projec_rec, 6) ; 
    if(!numberOfRecords) {
        printf("Leader File : Map Projection Record Not present\n") ;
        lf->map = (struct map *)NULL ;
    }
    else {
        recordLength = sizeof(struct map) ;
        recordLength = readIntInASCIIStringOfLength(lf->fdr_var.map_projec_rec_len, 6) ;
        if((lf->map = (struct map *)malloc(sizeof(struct map))) == NULL) {
            ase("Failed to allocate Map Record") ;
        }
        if ((fread(lf->map, recordLength, 1, LFFile->f) != 1)) {
            ase("Faild to read Data set summary record") ;
        }
    }
    
    /* Lecture du Platform Position Data Record */
    if (isRSAT1) {
        locateRSAT1PlatformRecordInFile(LFFile) ;
    } 
    
    numberOfRecords = readIntInASCIIStringOfLength(lf->fdr_var.n_plat_pos_data_rec, 6) ; 
    if(!numberOfRecords) printf("Leader File : Platform Position Data Record not present\n") ;
    else {
        recordLength = sizeof(struct platform) ;
        fileShift = readIntInASCIIStringOfLength(lf->fdr_var.plat_pos_data_rec_len, 6) ;
        fileShift -= recordLength ;
        if((lf->platform = malloc(recordLength)) == NULL) {
            ase("Failed to allocate Platform Record") ;
        }
        if ((fread(lf->platform, recordLength, 1, LFFile->f) != 1)) {
            ase("Failed to read Data set summary record") ;
        }
		
        /* State vectore reading */

        filePos = ftell(LFFile->f) ;
        numberOfStateVectors = readIntInASCIIStringOfLength(lf->platform->num_data_points, 4) ; 
        lf->state = vect_state(0, numberOfStateVectors - 1) ;

        fread(lf->state, numberOfStateVectors, sizeof(struct state_vec), LFFile->f) ;

        filePos -= ftell(LFFile->f) ;
        fileShift += filePos ;
        
        if (fseek(LFFile->f, fileShift, SEEK_CUR)) {
            ase("Failed to seek within leader file\n") ;
        }
   }

	lf->nfacility = 0 ;
    /* Lecture des Facility Records */
    numberOfRecords = readIntInASCIIStringOfLength(lf->fdr_var.n_facility_data_rec_1, 6) ; 
    if(!numberOfRecords) printf("Leader File : Facility Data Record not present\n") ;
    else {
        recordLength = sizeof(struct fac_gen_type) ;
        recordLength = readIntInASCIIStringOfLength(lf->fdr_var.facility_data_rec_len_1, 6) ;
        if((lf->facility = (struct fac_gen_type **)malloc(sizeof(struct fac_gen_type *))) == NULL) 
            ase("Failed to allocate Facility Record") ;
        for(i = 0; i < numberOfRecords ; i++) {
            if((lf->facility[i] = (struct fac_gen_type *)malloc(sizeof(struct fac_gen_type))) == NULL) {
                ase("Failed to allocate Facility Record") ;
            }
            fread(lf->facility[i], recordLength, 1, LFFile->f) ;
/*
            if ((fread(lf->facility[i], recordLength, 1, LFFile->f) != 1)) {
                ase("Faild to read Data set summary record") ;
            }
*/
        }
        lf->nfacility = numberOfRecords ;
    }
	
	freeRawFileDescriptor(LFFile) ;    
    return lf ;
}

/* Imagery Option File reader*/
struct CEOS_IMOF	*readCEOS_IMOF(char *IMOFFilePath)
{
    int numberOfRecords, recordsLength ;
    long fileShift ;
    struct CEOS_IMOF	*imof ;
	rawFileDescriptor *IMOFFile ;
	union intChar4 recLength ;
    
    if((imof = (struct CEOS_IMOF *)malloc(sizeof(struct CEOS_IMOF))) == NULL) {
        ase("Failed to allocate IMage Option File") ;
    }
    /* W allocate three data record header to read first, median and last one ( necessary for RSAT-1) */
    if ((imof->dataRecordHeader = malloc (3 * sizeof(imof->dataRecordHeader[0]))) == NULL) {
        ase("Failed to allocate data record header structure\n") ;
    }
    

    /* IMOF File reading*/
	if((IMOFFile = openRawFileForReadingAtPath(IMOFFilePath)) == NULL) {
		free(imof) ;
		return((struct CEOS_IMOF *)NULL) ;
    }
	
	fread(&(imof->imof_fix), 1, sizeof(struct fdr_fix_seg), IMOFFile->f) ;
	fread(&(imof->imof_var), 1, sizeof(struct data_var_seg), IMOFFile->f) ;

	memcpy(recLength.charVal, imof->imof_fix.header.rec_len, 4) ;
	if(!isArchBigEndian()) {
		swap4bytesStruct(&recLength.intVal) ;
	}
    numberOfRecords = readIntInASCIIStringOfLength(imof->imof_var.data_nrecs, 6) ;
    recordsLength = readIntInASCIIStringOfLength(imof->imof_var.data_rec_len, 6) ;

    fileShift = (long)recLength.intVal ;
    fseek(IMOFFile->f, fileShift, SEEK_SET) ;
    fread(imof->dataRecordHeader, sizeof(imof->dataRecordHeader[0]), 1, IMOFFile->f) ;

    fileShift = (long)recLength.intVal + numberOfRecords / 2 * recordsLength ;
    fseek(IMOFFile->f, fileShift, SEEK_SET) ;
    fread(imof->dataRecordHeader + 1, sizeof(imof->dataRecordHeader[0]), 1, IMOFFile->f) ;

    fileShift = (long)recLength.intVal + (numberOfRecords - 1)* recordsLength ;
    fseek(IMOFFile->f, fileShift, SEEK_SET) ;
    fread(imof->dataRecordHeader + 2, sizeof(imof->dataRecordHeader[0]), 1, IMOFFile->f) ;

    
	freeRawFileDescriptor(IMOFFile) ;
    return imof ;
}

/* ----------------- Libération d'une structure VDF ----------------- */
void	freeStructCEOS_VDF(struct CEOS_VDF *vdf) 
{
	free(vdf->fpr) ;
	free(vdf) ;
}

/* ----------------- Libération d'une structure LF ----------------- */
void	freeStructCEOS_LF(struct CEOS_LF *lf) 
{
    int	i ;
    
    free(lf->dss) ;
    if(lf->map != (struct map *)NULL) free(lf->map) ;
    if(lf->platform != (struct platform *)NULL) free(lf->platform) ;
    free_vect_state(lf->state, 0) ;
    for(i = 0; i < lf->nfacility; i++)
        free(lf->facility[i]) ;

    free(lf->facility) ;
}

/* ----------------- Allocation de mémoire pour un vecteur de vecteurs d'état ----------------- */

struct state_vec	*vect_state(int ncl, int nch)
{
    size_t stateVecSize ;
	struct state_vec *m = NULL ;

    stateVecSize = sizeof(struct state_vec ) ;
    stateVecSize = (nch - ncl + 1) * sizeof(struct state_vec ) ;
	if((m = malloc(stateVecSize)) == NULL) {
		ase("Failed to allocate state vecotors\n") ;
	}
	m -= ncl ;
	return(m) ;
}

/* ----------------- Libération de mémoire pour une vecteurs d'état ----------------- */

void	free_vect_state(struct state_vec *m, int ncl)
{
	free((char *)(m+ncl)) ;
}




/* Look for RSAT1 platform record in leader file */
void locateRSAT1PlatformRecordInFile(rawFileDescriptor *leaderFile)
{
    long recordLength, fileShift ;
    size_t headerRecordLength ; 
    struct rec_header *recordHeader ;
    union intChar4 recLen ;
    {
        /* data */
    };
    

    headerRecordLength = sizeof(recordHeader[0]) ;
    recordHeader = malloc(headerRecordLength) ;
    if (recordHeader == NULL) {
        ase("Failed to allocate a CEOS record header") ;
    }
    
    rewind(leaderFile->f) ;
    fileShift = 0 ;

    do {
        if (fread(recordHeader, headerRecordLength, 1, leaderFile->f) != 1) {
            ase("failed to read record header in leader file") ;
        }
        if(!isArchBigEndian()) {
            memcpy(recLen.charVal, recordHeader->rec_len, 4) ;
            swap4bytesStruct(&(recLen.intVal)) ;
        }
        recordLength = (long)recLen.intVal ;

        fileShift = recordLength - headerRecordLength ;
        if (fseek(leaderFile->f, fileShift, SEEK_CUR) == -1) {
            ase("\t-/-> Failed to seek into leader file") ;
        }        
    } while (recordHeader->rec_sub_cod1 != 18 || recordHeader->rec_sub_typ != 30 || recordHeader->rec_sub_cod2 != 18 || recordHeader->rec_sub_cod3 != 20) ;

    if (fseek(leaderFile->f, -recordLength, SEEK_CUR) == -1) {
        ase("\t-/-> Failed to seek into leader file") ;
    }
        
    free(recordHeader) ;
}