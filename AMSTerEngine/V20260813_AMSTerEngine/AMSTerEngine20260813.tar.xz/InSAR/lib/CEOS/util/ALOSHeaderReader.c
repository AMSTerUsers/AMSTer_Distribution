
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  Bibliothèque de fonctions servant à la lecture des headers CEOS
 *  lecheader
 *
 *  Created by Dominique Derauw on Mon Feb 18 2002.
 *  Copyright (c) 2001 Dominique Derauw All rights reserved.
 *
 */

#include "ALOSHeaderReader.h"
#include "vectors.h"

/* Volume Directory File reader*/
struct ALOS_VDF	*readALOS_VDF(char *VDFFilePath)
{
	int i ;
	struct fdr volumeDescriptorRecord ;
    struct ALOS_VDF	*vdf ;
	rawFileDescriptor *VDFFile ;
    
    /* Volume Directory File opening */
    if((vdf = (struct ALOS_VDF *)malloc(sizeof(struct ALOS_VDF))) == NULL) {
        ase("Failed to allocate VDF header Structure\n") ;
    }
	if((VDFFile = openRawFileForReadingAtPath(VDFFilePath)) == NULL) {
		ase("Failed to open Volume Directory File\n") ;
    }
	fread(&volumeDescriptorRecord, 1, sizeof(struct fdr), VDFFile->f) ;
	vdf->numberOfFilePointerRecords = readIntInASCIIStringOfLength(volumeDescriptorRecord.num_fil_ptr, 4) ;
	if((vdf->fpr = malloc(sizeof(struct fpr) * vdf->numberOfFilePointerRecords)) == NULL) {
        ase("Failed to allocate VDF header Structure\n") ;
    }
	for(i = 0; i < vdf->numberOfFilePointerRecords; i++)
		fread(&(vdf->fpr[i]), sizeof(struct fpr), 1, VDFFile->f) ;
	fread(&(vdf->text), 1, sizeof(struct text), VDFFile->f) ;
	    
	freeRawFileDescriptor(VDFFile) ;
    return vdf ;
}

/* Leader File Reader */
struct ALOS_LF	*readALOS_LF(char *LFFilePath)
{
    int			numberOfRecords, index ;
    size_t  recordLength ;
    long		filePos ;
    union intChar4	rec ;
    struct ALOS_LF		*lf ;
	rawFileDescriptor *LFFile ;
    
    if((lf = (struct ALOS_LF *)malloc(sizeof(struct ALOS_LF))) == NULL) 
        ase("Failed to allocate Leader File structure\n") ;

    /* Leader File opening */
	if((LFFile = openRawFileForReadingAtPath(LFFilePath)) == NULL)
		ase("Failed to open Volume Directory File\n") ;

    /* Leader File reading in CHAR format */
    /* File Descriptor Record reading */
    fread(&lf->fdr_fix, 1, sizeof(struct fdr_fix_seg), LFFile->f) ;
    fread(&lf->fdr_var, 1, sizeof(struct leader_var_seg), LFFile->f) ;
	if(!isArchBigEndian())
		swap4bytesStruct(lf->fdr_fix.header.rec_len) ;
    memcpy(rec.charVal, lf->fdr_fix.header.rec_len, 4) ;

    /* Data Set Summary Record reading*/
    numberOfRecords = readIntInASCIIStringOfLength(lf->fdr_var.n_data_set_summ_rec, 6) ; 
    if(!numberOfRecords) ase("Leader File wrong format : No Data Set Summary Record") ;
    else {
        recordLength = readIntInASCIIStringOfLength(lf->fdr_var.data_set_summ_rec_len, 6) ;
        if((lf->dss = (struct dss *)malloc(sizeof(struct dss))) == NULL) 
            ase("Failed toi allocate Data Set Summary Record") ;
        fread(lf->dss, 1, recordLength, LFFile->f) ;
    }
    
    /* Lecture du Map Projection Record */
    numberOfRecords = readIntInASCIIStringOfLength(lf->fdr_var.n_map_projec_rec, 6) ; 
    if(!numberOfRecords) {
        lf->map = (struct map *)NULL ;
    }
    else {
        recordLength = readIntInASCIIStringOfLength(lf->fdr_var.map_projec_rec_len, 6) ;
        if((lf->map = (struct map *)malloc(sizeof(struct map))) == NULL) 
            ase("Failed to allocate Map Record") ;
        fread(lf->map, 1, recordLength, LFFile->f) ;
    }
    
    /* Lecture du Platform Position Data Record */
    numberOfRecords = readIntInASCIIStringOfLength(lf->fdr_var.n_plat_pos_data_rec, 6) ; 
    if(!numberOfRecords) printf("Leader File : Platform Position Data Record not present\n") ;
    else {
        filePos = ftell(LFFile->f) ;
        recordLength = readIntInASCIIStringOfLength(lf->fdr_var.plat_pos_data_rec_len, 6) ;
        if((lf->platform = (struct platform *)malloc(sizeof(struct platform))) == NULL) 
            ase("Failed to allocate Platform Record") ;
        if (fread(lf->platform, 1, sizeof(struct platform), LFFile->f) != recordLength) {
            filePos += (size_t)recordLength ;
            fseek(LFFile->f, filePos, SEEK_SET) ;
        }
		
		lf->state = &(lf->platform->stateVector[0]) ;
   }
	
	/* Read attitude Data record if present */
    numberOfRecords = readIntInASCIIStringOfLength(lf->fdr_var.n_att_data_rec, 6) ; 
    if(!numberOfRecords) printf("Leader File : Attitude Data Record not present\n") ;
    else {
        filePos = ftell(LFFile->f) ;
        recordLength = readIntInASCIIStringOfLength(lf->fdr_var.att_data_rec_len, 6) ;
        if((lf->attitude = (struct attitudeDataRecord *)malloc(sizeof(struct attitudeDataRecord))) == NULL) 
            ase("Failed to allocate Attitude Record") ;
        fread(lf->attitude, 1, 16, LFFile->f) ;
        numberOfRecords = readIntInASCIIStringOfLength(lf->attitude->numberOfAttitudeDataPoints, 4) ;
        if((lf->attitude->data = malloc(numberOfRecords * sizeof(struct attitudeData))) == NULL) 
            ase("Failed to allocate Attitude Data pointer") ;
        for (index = 0; index < numberOfRecords; index++) {
            fread(&(lf->attitude->data[index]), 1, sizeof(struct attitudeData), LFFile->f) ;
        }
        filePos += (size_t)recordLength ;
        fseek(LFFile->f, filePos, SEEK_SET) ;
	}
	
	/* Skip radiometric data record if present */
    numberOfRecords = readIntInASCIIStringOfLength(lf->fdr_var.n_rad_data_rec, 6) ; 
    if(!numberOfRecords) printf("Leader File : Radiometric Data Record not present\n") ;
    else {
        recordLength = readIntInASCIIStringOfLength(lf->fdr_var.rad_data_rec_len, 6) ;
		fseek(LFFile->f, (long)recordLength, SEEK_CUR) ;
	}
	
	if((lf->dataQualityRecord = malloc(sizeof(dataQualityRecordStruct))) == NULL)
		ase("Failed to allocate Data Quality Summary Record\n") ;
	fread(lf->dataQualityRecord, sizeof(dataQualityRecordStruct), 1, LFFile->f) ;

	
	freeRawFileDescriptor(LFFile) ;    
    return lf ;
}

/* Imagery Option File reader*/
struct ALOS_IMOF	*readALOS_IMOF(char *IMOFFilePath)
{
    size_t dataRecordLength ;
    struct ALOS_IMOF	*imof ;
	rawFileDescriptor *IMOFFile ;
    
    if((imof = (struct ALOS_IMOF *)malloc(sizeof(struct ALOS_IMOF))) == NULL)
        ase("Failed to allocate Image Option File") ;
    
    if((imof->signalDataRecord = (signalDataRecordStruct *)malloc(sizeof(signalDataRecordStruct))) == NULL)
        ase("Failed to allocate Image Option File") ;
    
    /* IMOF File reading*/
	if((IMOFFile = openRawFileForReadingAtPath(IMOFFilePath)) == NULL) {
		free(imof) ;
		return((struct ALOS_IMOF *)NULL) ;
    }
	
	clearerr(IMOFFile->f) ;

	fread(&(imof->imof_fix), sizeof(struct fdr_fix_seg), 1, IMOFFile->f) ;
	fread(&(imof->imof_var), sizeof(struct data_var_seg), 1, IMOFFile->f) ;
    dataRecordLength = readIntInASCIIStringOfLength(imof->imof_var.data_rec_len, 6) ;
    fseek(IMOFFile->f, (long)dataRecordLength, SEEK_CUR) ;
	fread(imof->signalDataRecord, sizeof(signalDataRecordStruct), 1, IMOFFile->f) ;

/*    out = openRawFileForWritingAtPath("/home/dd/DATA/Images/ALOS/brol.raw") ;
    buffer = malloc(dataRecordLength) ;
    i = 0 ;
    while ((recLen = fread(buffer, dataRecordLength, 1, IMOFFile->f)) == 1)
    {
        fwrite(buffer + 544, 37344, 1, out->f) ;
        i++ ;
    }
    printf("%d\n", i) ;
    free(buffer) ;
    freeRawFileDescriptor(out) ;
*/
    freeRawFileDescriptor(IMOFFile) ;
    return imof ;
}

/* ----------------- Libération d'une structure VDF ----------------- */
void	freeStructALOS_VDF(struct ALOS_VDF *vdf) 
{
	free(vdf->fpr) ;
	free(vdf) ;
}

/* ----------------- Libération d'une structure LF ----------------- */
void	freeStructALOS_LF(struct ALOS_LF *lf) 
{
    
    free(lf->dss) ;
    if(lf->map != (struct map *)NULL) free(lf->map) ;
    if(lf->platform != (struct platform *)NULL) free(lf->platform) ;
}
