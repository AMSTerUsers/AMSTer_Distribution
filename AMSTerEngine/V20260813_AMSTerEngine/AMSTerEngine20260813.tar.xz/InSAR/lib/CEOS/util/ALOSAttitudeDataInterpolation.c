
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  ALOSAttitudeDataInterpolation.c
//  ALOSDataReader
//
//  Created by Dominique Derauw on 22/10/12.
//
//

#include <stdio.h>
#include "ALOSAttitudeDataInterpolation.h"

void ALOSAttitudeDataInterpolation(struct infoImage *info, struct attitudeDataRecord *attitudeRecord)
{
//    int i ;
    int i0, numberOfDataPoints, polynomialOrder ;
    int		j, k, l, *indexI ;
    double	**T, signe, *timeStamp, *pitch, *pitchRate, *roll, *rollRate, *yaw, *yawRate ;
//    double  diffAvg, diffAvg0, dataPointTime1, dataPointTime0 ;
    double aDouble ;
    struct attitudeData *data ;
    
    numberOfDataPoints = readIntInASCIIStringOfLength(attitudeRecord->numberOfAttitudeDataPoints, 4) ;
    data = attitudeRecord->data ;
    
    /* We wil select only the five attitude data encompassing the data */
/*
    if(numberOfDataPoints > 5) {
        i0 = 0 ;
        dataPointTime0 = readDoubleInASCIIStringOfLength(data[0].millisecondsOfDay, 8) * 1.e-3 ;
        dataPointTime1 = readDoubleInASCIIStringOfLength(data[4].millisecondsOfDay, 8) * 1.e-3 ;
        diffAvg0 = fabs((info->LPAT + info->FPAT)/2. - (dataPointTime1 + dataPointTime0)/2.) ;
        for (i = 0; i < numberOfDataPoints - 5; i++) {
            dataPointTime0 = readDoubleInASCIIStringOfLength(data[i].millisecondsOfDay, 8) * 1.e-3 ;
            dataPointTime1 = readDoubleInASCIIStringOfLength(data[i + 4].millisecondsOfDay, 8) * 1.e-3 ;
            diffAvg = fabs((info->LPAT + info->FPAT)/2. - (dataPointTime1 + dataPointTime0)/2.) ;
            if(diffAvg < diffAvg0) {
                diffAvg0 = diffAvg ;
                i0 = i ;
            }
        }
        numberOfDataPoints = 5 ;
    }
*/
    
    /* We will suppose that all attitude data points given in the Raw header are ecmpassing closely the data acquisition time interval */
    /* Consequently, all attitude data points will be considered for least square calculation of second order approx of Yaw */
    i0 = 0 ;

    /* initialize polynome coefficients for attitude components */
    if(info->pitch == NULL)
        info->pitch = vectorDouble(0, info->polynomialOrder) ;
    if(info->pitchRate == NULL)
        info->pitchRate = vectorDouble(0, info->polynomialOrder) ;
    if(info->roll == NULL)
        info->roll = vectorDouble(0, info->polynomialOrder) ;
    if(info->rollRate == NULL)
        info->rollRate = vectorDouble(0, info->polynomialOrder) ;
    if(info->yaw == NULL)
        info->yaw = vectorDouble(0, info->polynomialOrder) ;
    if(info->yawRate == NULL)
        info->yawRate = vectorDouble(0, info->polynomialOrder) ;
    
    polynomialOrder = 3 ;
    indexI = vectorInt(1, polynomialOrder) ;
    T = matrixDouble(1, polynomialOrder, 1, polynomialOrder) ;
    for(k = 1; k <= polynomialOrder; k++) {
        info->pitch[k - 1] = 0. ;
        info->pitchRate[k - 1] = 0. ;
        info->roll[k - 1] = 0. ;
        info->rollRate[k - 1] = 0. ;
        info->yaw[k - 1] = 0. ;
        info->yawRate[k - 1] = 0. ;
        for(l = k; l <= polynomialOrder; l++) {
            T[k][l] = T[l][k] = 0.0 ;
        }
    }
    
    timeStamp = vectorDouble(0, numberOfDataPoints - 1) ;
    pitch = vectorDouble(0, numberOfDataPoints - 1) ;
    roll = vectorDouble(0, numberOfDataPoints - 1) ;
    yaw = vectorDouble(0, numberOfDataPoints - 1) ;
    pitchRate = vectorDouble(0, numberOfDataPoints - 1) ;
    rollRate = vectorDouble(0, numberOfDataPoints - 1) ;
    yawRate = vectorDouble(0, numberOfDataPoints - 1) ;
    for(j = 0; j < numberOfDataPoints; j++) {
        aDouble = timeStamp[j] = (readDoubleInASCIIStringOfLength(data[i0 + j].millisecondsOfDay, 8) * 1.e-3 - info->FPAT) / info->lineTimeInterval ;
        pitch[j] = readDoubleInASCIIStringOfLength(data[i0 + j].pitch, 14) ;
        pitchRate[j] = readDoubleInASCIIStringOfLength(data[i0 + j].pitchRate, 14) ;
        roll[j] = readDoubleInASCIIStringOfLength(data[i0 + j].roll, 14) ;
        rollRate[j] = readDoubleInASCIIStringOfLength(data[i0 + j].rollRate, 14) ;
        yaw[j] = readDoubleInASCIIStringOfLength(data[i0 + j].yaw, 14) ;
        yawRate[j] = readDoubleInASCIIStringOfLength(data[i0 + j].yawRate, 14) ;
        
//        printf("%f\t%f\n", timeStamp[j], yaw[j]) ;
    }

    /* Compute matrix and vectors for mean square interpolation */
    for(k = 0; k < polynomialOrder; k++) {
        for(j = 0; j < numberOfDataPoints; j++) {
            aDouble = pow(timeStamp[j],(double)k) ;
            info->pitch[k] += aDouble * pitch[j] ;
            info->pitchRate[k] += aDouble * pitchRate[j] ;
            info->roll[k] += aDouble * roll[j] ;
            info->rollRate[k] += aDouble * rollRate[j] ;
            info->yaw[k] += aDouble * yaw[j] ;
            info->yawRate[k] += aDouble * yawRate[j] ;
        }
        for(l = k; l < polynomialOrder; l++) {
            for(j = 0; j < numberOfDataPoints; j++) {
                T[k + 1][l + 1] += pow(timeStamp[j], (double)(k + l)) ;
            }
        }
    }
    
    for(k = 1; k <= polynomialOrder; k++) {
        for(l = k + 1; l <= polynomialOrder; l++)
            T[l][k] = T[k][l] ;
    }
    
    ludcmp(T, polynomialOrder, indexI, &signe) ;
    lubksb(T, polynomialOrder, indexI, &info->pitch[-1]) ;
    lubksb(T, polynomialOrder, indexI, &info->pitchRate[-1]) ;
    lubksb(T, polynomialOrder, indexI, &info->roll[-1]) ;
    lubksb(T, polynomialOrder, indexI, &info->rollRate[-1]) ;
    lubksb(T, polynomialOrder, indexI, &info->yaw[-1]) ;
    lubksb(T, polynomialOrder, indexI, &info->yawRate[-1]) ;
    
    freeVectorDouble(timeStamp, 0) ;
    freeVectorDouble(pitch, 0) ;
    freeVectorDouble(pitchRate, 0) ;
    freeVectorDouble(roll, 0) ;
    freeVectorDouble(rollRate, 0) ;
    freeVectorDouble(yaw, 0) ;
    freeVectorDouble(yawRate, 0) ;
    freeVectorInt(indexI, 1) ;
    freeMatrixDouble(T, 1, 1) ;

}
