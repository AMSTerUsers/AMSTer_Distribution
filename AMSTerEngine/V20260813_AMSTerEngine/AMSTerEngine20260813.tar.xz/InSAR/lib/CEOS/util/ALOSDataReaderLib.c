
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  ALOSDataReaderLib.c
//  ALOSDataReader
//
//  Created by Dominique Derauw on 03/02/2020.
//  Copyright © 2020 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "ALOSDataReaderLib.h"



CSVStruct *ALOSDataReader(CSVStruct *csv) {
    char *inputDir, *outputDir, *outputImagePath, fileName[_MAX_PATH_LENGTH_], *aDir ;
    char isScanSAR = 0 ;
    char lookDir[3] ;
    int imageIndex, lookDirIndex ;
    keyValue *parametersList ;
    CSLImage *thisImage ;
    ALOSHeader *header ;
    SLCImageInfo *info ;
    time_t startTime, stopTime ;
    CSVStruct *ALOSDirList ;
    CSVStruct *savedCSLImages = NULL ;
    
    if(csv->numberOfEntries == 1 || isArgumentPresentInCSV(csv, "help") || isArgumentPresentInCSV(csv, "-h")) {
        ALOSDataReaderHelp() ;
    }
    if(isArgumentPresentInCSV(csv, "-create")) {
        createALOSDataReaderParameterFileAtPath(csv->stringVal[1]) ;
    }
    time(&startTime) ;
    
    /* If parameter 1 is a directory, we will consider it contains one or more ALOS files to be read */
    if (isDir(csv->stringVal[1])) {
        /* Bulk processing must be considered */
        inputDir = outputDir = csv->stringVal[1] ;
        if (csv->numberOfEntries >= 3) {
            if (isDir(csv->stringVal[2])) {
                outputDir = csv->stringVal[2] ;
            }
        }
        
        /* Search for all directories containing a Volume directory file */
        if (!(ALOSDirList = recursiveSearchOfFileInDir("VOL-AL", inputDir))) {
            printf("No ALOS Volume Directory files found in input directory") ;
            ALOSDataReaderHelp() ;
        }
        /* Remove those that are within an already read .csl image */
        for (imageIndex = 0; imageIndex < ALOSDirList->numberOfEntries; imageIndex++) {
            aDir = getDirectoryPathFromPath(ALOSDirList->stringVal[imageIndex]) ;
            inputDir = getDirectoryPathFromPath(aDir) ;
            if (isCSLImageAtPath(inputDir)) {
                removeStringValAtIndexInCSVStruct(imageIndex, ALOSDirList) ;
                imageIndex-- ;
            }
            free(aDir) ;
            free(inputDir) ;
        }
        
        
        sprintf(lookDir, "LR") ;
        parametersList = allocAKeyValuePair() ;
        for (imageIndex = 0; imageIndex < ALOSDirList->numberOfEntries; imageIndex++) {
            inputDir = getDirectoryPathFromPath(ALOSDirList->stringVal[imageIndex]) ;
            setStringValForKeyIn(parametersList, inputDir, "Path to directory containing ALOS data") ;
            setStringValForKeyIn(parametersList, getPointerToFileNameInPath(ALOSDirList->stringVal[imageIndex]), "Volume Directory File filename") ;
            
            header = readALOSHeader(parametersList) ;
            info  = readInfoImageFromALOSHeader(header, 0) ;
            lookDirIndex = (int)((info->lookDirection + 1) / 2) ;
            sprintf(fileName, "/%.3s_%s_%.1s%.1s", info->platformName, info->acquisitionDate, info->heading, lookDir + lookDirIndex) ;
            outputImagePath = initStringWith3Strings(outputDir, fileName, ".csl") ;

            if (info->numberOfSubswaths > 1) {
                printf("\t---> Scansar mode. %d subswaths present\n", info->numberOfSubswaths) ;
                isScanSAR = 1 ;
            }

            if ((isCSLImageAtPath(outputImagePath)) && isArgumentPresentInCSV(csv, "keepExisting")) {
                printf("\t---> Image already existing at indicated path. Skipping reading as requested.\n") ;
            }
            else {
                if ((isCSLImageAtPath(outputImagePath))) {
                    removeDirectoryAtPath(outputImagePath) ;
                }
                thisImage = createCSLDirectoryStructureAtPath(outputImagePath, __ALOS__) ;
                if (!isScanSAR) {
                    saveALOSInfoImageInCSLImage(info, thisImage) ;
                    copyALOSHeadersToHeadersDirectory(parametersList, thisImage) ;
                    readAndConvertALOS_SLCData(info, thisImage, header, parametersList) ;
                    freeCSLImageStructure(thisImage) ;
                }
                else {
printf("ScanSAR reading still not implemented. Skipping.\n\n") ;
                }
            }
            



            savedCSLImages = addStringValInCSVStruct(outputImagePath, savedCSLImages) ;

            freeALOSHeader(header) ;
            freeInfoImage(info) ;
            free(inputDir) ;
            free(outputImagePath) ;
        }
        
        freeKeyValueList(parametersList) ;
        freeCSVStruct(ALOSDirList) ;
    }
    else {
        parametersList = readParameterFileAtPath(csv->stringVal[1]) ;
        verifyALOSParametersList(parametersList) ;
        thisImage = createCSLDirectoryStructureAtPath(getStringValForKeyIn(parametersList, "Path to output"), __ALOS__) ;
        
        header = readALOSHeader(parametersList) ;
        info  = readInfoImageFromALOSHeader(header, 0) ;
        
        saveALOSInfoImageInCSLImage(info, thisImage) ;
        copyALOSHeadersToHeadersDirectory(parametersList, thisImage) ;
        readAndConvertALOS_SLCData(info, thisImage, header, parametersList) ;
        savedCSLImages = addStringValInCSVStruct(thisImage->imageDirectoryPath, savedCSLImages) ;
        
        freeALOSHeader(header) ;
        freeInfoImage(info) ;
    }
    
    
    time(&stopTime) ;
    duration(startTime, stopTime) ;
    
    return (savedCSLImages) ;
}

void ALOSDataReaderHelp()
{
    printf("\nUsage:\n ALOSDataReader /pathTo/parameterFile [-create]\n");
    printf("\nThis routine will read ALOS data and save it in CSL format.\n");
    printf("\nIf adding \"-create\" command line parameter, \nan example parameter file will be created at indicated path.\n") ;
    exit(0) ;
}

void createALOSDataReaderParameterFileAtPath(char *aPath)
{
    keyValue *parameterList ;
    
    parameterList = allocAKeyValuePair() ;
    setStringValForKeyIn(parameterList, "ALOSDataReader parameter file", "") ;
    setStringValForKeyIn(parameterList, "*****************************", "") ;
    setStringValForKeyIn(parameterList, "PathToDirectory", "Path to directory containing ALOS data") ;
    setStringValForKeyIn(parameterList, "VOL-ALPSR...", "Volume Directory File filename") ;
    setStringValForKeyIn(parameterList, "outputFilePath", "Path to output image in CSL format") ;
    
    writeParameterFileAtPath(parameterList, aPath) ;
    
    exit(0) ;
}

ALOSHeader *readALOSHeader(keyValue *parameterList)
{
    char *aPath, *inputDirectory, *vdfName, *lfName, *tfName ;
    char *productID, *sceneID ;
    char **directoryEntries ;
    char aKey[10] ;
    int i, imofIndex, numberOfEntries ;
    int numberOfPolarizationChannels ;
    ALOSHeader *header ;
    
    if((header = malloc(sizeof(ALOSHeader))) == NULL)
        ase("Failed to allocate CEOS Header\n") ;
    
    inputDirectory = getStringValForKeyIn(parameterList, "Path to directory containing ALOS data") ;
    vdfName = getStringValForKeyIn(parameterList, "Volume") ;
    aPath = initStringWith3Strings(inputDirectory, "/", vdfName) ;
    header->vdf = readALOS_VDF(aPath) ;
    free(aPath) ;
    
    productID = allocStringOfLength(32) ;
    sceneID = allocStringOfLength(33) ;
    memcpy(productID, &(header->vdf->text.prod_type_id[8]), 32) ;
    memcpy(sceneID, &(header->vdf->text.scene_id[7]), 33) ;
    stripWhiteCharsAtEndOfString(productID) ;
    stripWhiteCharsAtEndOfString(sceneID) ;
    setStringValForKeyIn(parameterList, productID, "productID") ;
    setStringValForKeyIn(parameterList, sceneID, "sceneID") ;
    switch (productID[2]) {
    case 'S':
        numberOfPolarizationChannels = 1 ;
        break;
    case 'D':
        numberOfPolarizationChannels = 2 ;
        break;
    case 'Q':
        numberOfPolarizationChannels = 4 ;
        break;
    default:
        ase("Wrong product ID. It does not contains polarization scheme code (S, D or Q)") ;
        break;
    }
    setIntValForKeyIn(parameterList, numberOfPolarizationChannels, "Number of polarisation channels") ;
    
    lfName = initStringWith4Strings("LED-", sceneID, "-", productID) ;
    aPath = initStringWith3Strings(inputDirectory, "/", lfName) ;
    header->lf = readALOS_LF(aPath) ;
    setStringValForKeyIn(parameterList, lfName, "lfName") ;
    free(aPath) ;
    free(lfName) ;
    
    tfName = initStringWith4Strings("TRL-", sceneID, "-", productID) ;
    setStringValForKeyIn(parameterList, tfName, "tfName") ;
    free(tfName) ;
    
    header->imof = malloc((header->vdf->numberOfFilePointerRecords - 2) * sizeof(struct ALOS_IMOF *)) ;
    numberOfEntries = getNumberOfDirectoryEntriesAtPath(inputDirectory) ;
    directoryEntries = getDirectoryEntriesAtPath(inputDirectory) ;
    imofIndex = 0 ;
    for(i = 0; i < numberOfEntries; i++) {
        if(!strncmp(directoryEntries[i], "IMG", 3)) {
            aPath = initStringWith3Strings(inputDirectory, "/", directoryEntries[i]) ;
            header->imof[imofIndex] = readALOS_IMOF(aPath) ;
            sprintf(aKey, "channel%.1d", imofIndex) ;
            setStringValForKeyIn(parameterList, directoryEntries[i], aKey) ;
            free(aPath) ;
            imofIndex++ ;
        }
    }
    setIntValForKeyIn(parameterList, imofIndex, "numberOfChannels") ;
    for(i = 0; i < numberOfEntries; i++)
        free(directoryEntries[i]) ;
    free(directoryEntries) ;
    free(productID) ;
    free(sceneID) ;
    
    return(header) ;
}


void copyALOSHeadersToHeadersDirectory(keyValue *parameterList, CSLImage *thisImage)
{
    char *inputDirectory, *buffer, *vdfName, *lfName, *nulName, *imofName ;
    char inputPath[_MAX_PATH_LENGTH_], destinationPath[_MAX_PATH_LENGTH_] ;
    char *aPath ;
    char aKey[10] ;
    int i, i0, numberOfChannels ;
    long aLong ;
    rawFileDescriptor *inputHeader = NULL, *outputHeader = NULL ;
    
    numberOfChannels = getIntValForKeyIn(parameterList, "numberOfChannels") ;
    thisImage->numberOfHeaderFiles = numberOfChannels + 2 ;
    inputDirectory = getStringValForKeyIn(parameterList, "Path to directory containing ALOS data") ;
    
    vdfName = getStringValForKeyIn(parameterList, "Volume") ;
    aPath = initStringWith3Strings(inputDirectory, "/", vdfName) ;
    if(!fileExistsAtPath(aPath))
        ase("Volume directory file not found at given path\n") ;
    free(aPath) ;
    
    lfName = getStringValForKeyIn(parameterList, "lfName") ;
    aPath = initStringWith3Strings(inputDirectory, "/", lfName) ;
    if(!fileExistsAtPath(aPath))
        ase("Leader file not found at given path\n") ;
    free(aPath) ;
    
    imofName = getStringValForKeyIn(parameterList, "channel0") ;
    aPath = initStringWith3Strings(inputDirectory, "/", imofName) ;
    if(!fileExistsAtPath(aPath))
        ase("Data file not found at given path\n") ;
    free(aPath) ;
    
    i0 = 2 ;
    nulName = getStringValForKeyIn(parameterList, "tfName") ;
    if((nulName != NULL) && (*nulName != '\0') ) {
        aPath = initStringWith3Strings(inputDirectory, "/",  nulName) ;
        if(fileExistsAtPath(aPath))
            thisImage->numberOfHeaderFiles++ ;
        free(aPath) ;
        i0 = 3 ;
    }
    thisImage->headerFileNames = (char **)malloc(sizeof(char *) * thisImage->numberOfHeaderFiles) ;
    
    thisImage->headerFileNames[0] = initStringWithString(vdfName) ;
    thisImage->headerFileNames[1] = initStringWithString(lfName) ;
    if(i0 == 3)
        thisImage->headerFileNames[2] = initStringWithString(nulName) ;
    
    for(i = 0; i < numberOfChannels; i++) {
        sprintf(aKey, "channel%.1d", i) ;
        thisImage->headerFileNames[i + i0] = initStringWith2Strings(getStringValForKeyIn(parameterList, aKey), ".ifdr") ;
    }
    
    /* Read and write Headers */
    for(i = 0; i < i0; i++) {
        sprintf(inputPath, "%s/%s", inputDirectory, thisImage->headerFileNames[i]) ;
        if((inputHeader = openRawFileForReadingAtPath(inputPath)) == NULL)
            ase("Failed to open header file\n") ;
        sprintf(destinationPath, "%s/%s", thisImage->headersDirectoryPath, thisImage->headerFileNames[i]) ;
        outputHeader = openRawFileForWritingAtPath(destinationPath) ;
        buffer = malloc(inputHeader->fileLength) ;
        fread(buffer, inputHeader->fileLength, 1, inputHeader->f) ;
        fwrite(buffer, inputHeader->fileLength, 1, outputHeader->f) ;
        
        free(buffer) ;
        freeRawFileDescriptor(inputHeader) ;
        freeRawFileDescriptor(outputHeader) ;
    }
    
    aLong = sizeof(struct ALOS_IMOF) ;
    buffer = malloc(aLong) ;
    for(; i < thisImage->numberOfHeaderFiles ; i++) {
        sprintf(aKey, "channel%.1d", i - i0) ;
        sprintf(inputPath, "%s/%s", inputDirectory, getStringValForKeyIn(parameterList, aKey)) ;
        inputHeader = openRawFileForReadingAtPath(inputPath) ;
        sprintf(destinationPath, "%s/%s", thisImage->headersDirectoryPath, thisImage->headerFileNames[i]) ;
        outputHeader = openRawFileForWritingAtPath(destinationPath) ;
        fread(buffer, aLong, 1, inputHeader->f) ;
        fwrite(buffer, aLong, 1, outputHeader->f) ;
    }
    
    free(buffer) ;
    freeRawFileDescriptor(inputHeader) ;
    freeRawFileDescriptor(outputHeader) ;
}

void saveALOSInfoImageInCSLImage(SLCImageInfo *info, CSLImage *thisImage)
{
    char *aPath = NULL ;
    char isRaw = 0 ;
    
    if (info->sensorSpecificInfo != NULL) {
        isRaw = 1 ;
        aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/RAWImageInfo.txt") ;
    }
    else {
        aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
    }
    saveInfoImage(info, aPath) ;
    saveInfoKmlInDir(info, thisImage->infoDirectoryPath) ;
    
    if (isRaw) {
        appendParameterFileAtPath(info->parameterList, aPath) ;
    }
    free(aPath) ;
}




void readAndConvertALOS_SLCData(SLCImageInfo *info, CSLImage *thisImage, ALOSHeader *header, keyValue *parameterList)
{
    char aPath[_MAX_PATH_LENGTH_], *textFilePath ;
    char *inputDirectory, *inputFileName ;
    char aKey[10], isRaw ;
    int i, j, k, numberOfDataRecords, numberOfSamplesPerLine, numberOfBytesPerPixel ;
    long dataRecordLength, dataRecordHeaderLength, fileShift ;
    float cosPhaseShift ;
    rawFileDescriptor *inputFile, *outputFile ;
    complexChar     *ccIn = NULL ;
    complexShort    *csIn = NULL ;
    complexFloat    *cfOut, *cfIn = NULL ;
    progressCounter *aCounter = NULL ;
    CSVStruct *polMode ;
    ALOSRawInfoImage *rawInfo ;
    keyValue *savedDataCharacteristics ;
    
    /* Determine if we deal with raw data */
    isRaw = 0 ;
    if(info->sensorSpecificInfo != NULL) {
        rawInfo = info->sensorSpecificInfo ;
        isRaw = rawInfo->isRaw ;
    }

    /* Determine if we deal with old spotlight data that must be phase shifted */
    cosPhaseShift = 0 ;
    if (strncmp(info->productionTime, "20210301", 8) < 0 && strncmp(info->productID, "SBS", 3) == 0) {
        cosPhaseShift = 1 ;
    }
    

    if(header->imof == NULL) {
        numberOfDataRecords = readIntInASCIIStringOfLength(header->vdf->fpr[1].ref_file_nrecs, 8) - 1 ;
        dataRecordLength = readIntInASCIIStringOfLength(header->vdf->fpr[1].ref_file_max_reclen, 8) ;
        dataRecordHeaderLength = 412 ;
        numberOfSamplesPerLine = (int)(dataRecordLength - dataRecordHeaderLength) / 4 ;
    }
    else {
        numberOfDataRecords = readIntInASCIIStringOfLength(header->imof[0]->imof_var.data_nrecs, 6) ;
        dataRecordLength = readIntInASCIIStringOfLength(header->imof[0]->imof_var.data_rec_len, 6) ;
        dataRecordHeaderLength = dataRecordLength - readIntInASCIIStringOfLength(header->imof[0]->imof_var.SAR_data_bytes_per_rec, 8) ;
        numberOfSamplesPerLine = (int)(dataRecordLength - dataRecordHeaderLength) / readIntInASCIIStringOfLength(header->imof[0]->imof_var.nbytes_group, 4) ;
    }
    
    inputDirectory = getStringValForKeyIn(parameterList, "Path to directory containing ALOS data") ;
    printf("\n\nALOS data reader:\n****************\n") ;
    printf("Input data directory: %s\n", inputDirectory) ;
    
 //   numberOfTopBorderLines = readIntInASCIIStringOfLength(header->imof[0]->imof_var.top_bord, 4) ;
 //   numberOfBottomBorderLines = readIntInASCIIStringOfLength(header->imof[0]->imof_var.bottom_bord, 4) ;
    numberOfBytesPerPixel = readIntInASCIIStringOfLength(header->imof[0]->imof_var.nbytes_group, 4) ;
    
    if (isRaw) {
        ccIn = vectorComplexChar(0, numberOfSamplesPerLine - 1) ;
    }
    else {
        csIn = vectorComplexShort(0, numberOfSamplesPerLine - 1) ;
        cfIn = vectorComplexFloat(0, numberOfSamplesPerLine - 1) ;
    }
    
    cfOut = vectorComplexFloat(0, numberOfSamplesPerLine - 1) ;
    polMode = readCSVInString(info->polMode) ;
    fileShift = sizeof(struct fdr_fix_seg) + sizeof(struct data_var_seg) ;
    for(k = 0; k < polMode->numberOfEntries; k++) {
        savedDataCharacteristics = allocAKeyValuePair() ;
        sprintf(aKey, "channel%.1d", k) ;
        inputFileName = getStringValForKeyIn(parameterList, aKey) ;
        printf("\nInput data filename:  %s\n", inputFileName) ;
        sprintf(aPath, "%s/%s", inputDirectory, inputFileName) ;
        inputFile = openRawFileForReadingAtPath(aPath) ;
        fseek(inputFile->f, fileShift, SEEK_SET) ;
        if (isRaw) {
            setStringValForKeyIn(savedDataCharacteristics, "RAW data structure", "") ;
            sprintf(aPath, "%s/%s.%s", thisImage->dataDirectoryPath, "RAWData", polMode->stringVal[k]) ;
        }
        else {
            setStringValForKeyIn(savedDataCharacteristics, "SLC data structure", "") ;
            sprintf(aPath, "%s/%s.%s", thisImage->dataDirectoryPath, "SLCData", polMode->stringVal[k]) ;
        }
        outputFile = openRawFileForWritingAtPath(aPath) ;
        textFilePath = initStringWith4Strings(thisImage->infoDirectoryPath, "/", getFileNameFromPath(aPath), ".txt") ;
        
        printf("Reading and converting %s data set into %s\n", polMode->stringVal[k], thisImage->imageDirectoryPath) ;
        aCounter = initProgressCounterWithMinMaxValue(0, numberOfDataRecords - 1) ;
        for(i = 0 ; i < numberOfDataRecords ; i++) {
            fseek(inputFile->f, dataRecordHeaderLength, SEEK_CUR) ;
            if (!isRaw) {
                if(numberOfBytesPerPixel == 4) {
                    fread((complexShort *)csIn, sizeof(complexShort), numberOfSamplesPerLine, inputFile->f) ;
                    for(j = 0; j < numberOfSamplesPerLine ; j++) {
                        if(!isArchBigEndian()) {
                            swapComplexShort(&csIn[j]) ;
                        }
                        cfOut[j].r = (float)csIn[j].r ;
                        cfOut[j].i = (float)csIn[j].i ;
                    }
                }
                else {
                    fread((complexFloat *)cfIn, sizeof(complexFloat), numberOfSamplesPerLine, inputFile->f) ;
                    for(j = 0; j < numberOfSamplesPerLine ; j++) {
                        if(!isArchBigEndian()) {
                            swapComplexFloat(&cfIn[j]) ;
                        }
                        cfOut[j] = cfIn[j] ;
                    }
                }
                
                if (cosPhaseShift == -1) {
                    for (j = 0; j < numberOfSamplesPerLine; j++){
                        cfOut[j] = mRC(cfOut[j], cosPhaseShift) ;
                    }
                }
                cosPhaseShift *= -1 ;
                
                fwrite((complexFloat *)cfOut, sizeof(complexFloat), numberOfSamplesPerLine, outputFile->f) ;
            }
            else {
                fread((complexChar *)ccIn, sizeof(complexChar), numberOfSamplesPerLine, inputFile->f) ;
                fwrite((complexChar *)ccIn, sizeof(complexChar), numberOfSamplesPerLine, outputFile->f) ;
                /*
                 for(j = 0; j < numberOfSamplesPerLine ; j++) {
                 cfOut[j].r = (float)ccIn[j].r - rawInfo->IDCBias ;
                 cfOut[j].i = (float)ccIn[j].i - rawInfo->QDCBias ;
                 }
                 */
            }
            //            fwrite((complexFloat *)cfOut, sizeof(complexFloat), numberOfSamplesPerLine, outputFile->f) ;
            updateProgressCounterForIndex(aCounter, i) ;
        }
        freeRawFileDescriptor(inputFile) ;
        freeRawFileDescriptor(outputFile) ;
        
        /* Save Data file characteristics */
        setStringValForKeyIn(savedDataCharacteristics, "******************", "") ;
        setStringValForKeyIn(savedDataCharacteristics, "complex", "Data type") ;
        setStringValForKeyIn(savedDataCharacteristics, "byte - byte", "Data structure") ;
        if (isArchBigEndian()) {
            setStringValForKeyIn(savedDataCharacteristics, "Big endian", "Data byte order") ;
        }
        else
            setStringValForKeyIn(savedDataCharacteristics, "Low endian", "Data byte order") ;
        setIntValForKeyIn(savedDataCharacteristics, info->rangeDimension, "Number of columns") ;
        setIntValForKeyIn(savedDataCharacteristics, info->azimuthDimension, "Number of raws") ;
        writeParameterFileAtPath(savedDataCharacteristics, textFilePath) ;
        freeKeyValueList(savedDataCharacteristics) ;
        free(textFilePath) ;
    }
    freeProgressCounter(aCounter) ;
    
    if(isRaw) {
        freeVectorComplexChar(ccIn, 0) ;
    }
    else {
        freeVectorComplexShort(csIn, 0) ;
        freeVectorComplexFloat(cfIn, 0) ;
    }
    
    freeVectorComplexFloat(cfOut, 0) ;
    freeCSVStruct(polMode) ;
}

void freeALOSHeader(ALOSHeader *header)
{
    freeStructALOS_VDF(header->vdf) ;
    freeStructALOS_LF(header->lf) ;
    free(header->imof) ;
    free(header) ;
}


void verifyALOSParametersList(keyValue *parametersList)
{
    char *dirIn, *aPath ;
    
    dirIn = getStringValForKeyIn(parametersList, "Path to directory containing ALOS data") ;
    while(dirIn[strlen(dirIn) - 1] == '/')
        dirIn[strlen(dirIn) - 1] = '\0' ;
    
    if(!isDir(dirIn))
        ase("Given input path is not a valid directory\n") ;
    if(!isReadAccessGrantedAtPath(dirIn))
        ase("Read acces not granted for input path\n") ;
    
    aPath = initStringWith3Strings(dirIn, "/", getStringValForKeyIn(parametersList, "Volume")) ;
    if(!fileExistsAtPath(aPath))
        ase("Volume Directory file does not exists at given input path\n") ;
    free(aPath) ;
}

