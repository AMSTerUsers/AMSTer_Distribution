
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  RSAT2DataReaderLib.c
//  RSAT2DAtaReader
//
//  Created by Dominique Derauw on 12/02/15.
//  Copyright (c) 2015 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "RSAT2DataReaderLib.h"

CSVStruct *RSAT2DataReader(CSVStruct *csv)
{
    char *aPath, *RSAT2AccesPath, *CSLImagePath, *CSLImageName ;
    char *inputDir, *outputDir = NULL ;
    char *productInfoFilePath ;
    char beamID[8] ;
    char forceReading ;
    int i ;
    keyValue *parametersList ;
    CSLImage *thisImage ;
    SLCImageInfo *info ;
    time_t startTime, endTime ;
    CSVStruct *RSAT2DirList = NULL ;
    CSVStruct *savedCSLImages = NULL ;

    time(&startTime) ;
    if(csv->numberOfEntries == 1)
        RSAT2DataReaderHelp() ;
    if(isArgumentPresentInCSV(csv, "help") || isArgumentPresentInCSV(csv, "-h"))
        RSAT2DataReaderHelp() ;
    
    if(isArgumentPresentInCSV(csv, "-create"))
        createRSAT2DataReaderParameterFileAtPath((char *)csv->stringVal[1]) ;
    
    /* If parameter 1 is a directory, we will consider it contains one or more RSAT2 files to be read */
    if (isDir((char *)csv->stringVal[1])) {
        /* Bulk processing must be considered */
        inputDir = initStringWithString(csv->stringVal[1]) ;
        outputDir = initStringWithString(inputDir) ;
        if (csv->numberOfEntries > 2) {
            if (isDir((char *)csv->stringVal[2])) {
                free(outputDir) ;
                outputDir = initStringWithString(csv->stringVal[2]) ;
            }
        }
        
        forceReading = !isArgumentPresentInCSV(csv, "keepExisting") ;
        
        /* First we test if the given directory is a RADARSAT2 image container itself */
        if (isSubStringPresentInString(inputDir, "RS2_")) {
            RSAT2DirList = addStringValInCSVStruct(inputDir, NULL) ;
            if (!strcmp(inputDir, outputDir)) {
                free(outputDir) ;
                outputDir = getDirectoryPathFromPath(inputDir) ;
            }
        }
        else {
            RSAT2DirList = recursiveSearchOfDirInDir("RS2_", inputDir) ;
        }
        
        if (!RSAT2DirList) {
            ase("No RSAT2 image directories found at given path.\n") ;
        }
        
        for (i = 0; i < RSAT2DirList->numberOfEntries; i++) {
            RSAT2AccesPath = RSAT2DirList->stringVal[i] ;
            productInfoFilePath = initStringWith2Strings(RSAT2AccesPath, "/product.xml") ;
            if (fileExistsAtPath(productInfoFilePath)) {
                CSLImagePath = initStringWith2Strings(outputDir, "/.tempCSLImage.csl") ;
                removeDirectoryAtPath(CSLImagePath) ;
                
                //                CSLImagePath = replaceSubStringsInString(CSLImagePath, "//", "/") ;
                thisImage = createCSLDirectoryStructureAtPath(CSLImagePath, __RSAT2__) ;
                copyRSAT2HeaderToCSLImage(thisImage, productInfoFilePath) ;
                
                aPath = initStringWith3Strings(thisImage->headersDirectoryPath, "/", getPointerToFileNameInPath(productInfoFilePath)) ;
                info = createSLCImageInfoForRSAT2Data(aPath) ;
                free(aPath) ;
                
                aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
                saveInfoImage(info, aPath) ;
                free(aPath) ;
                
                sscanf(info->productID, "%s_", beamID) ;
                sprintf(accessPath, "RS2_%s_%.8s_%.1s.csl", beamID, info->acquisitionDate, info->heading) ;
                CSLImageName = initStringWithString(accessPath) ;
                
                aPath = initStringWith3Strings(outputDir, "/", CSLImageName) ;
                if (isDir(aPath)) {
                    printf("\n\n---> Image %s already existing in destination directory\n", CSLImageName) ;
                    if (forceReading) {
                        printf("\t---> Forcing re-reading\n") ;
                        removeDirectoryAtPath(aPath) ;
                    }
                    else {
                        printf("\t---> Skipping reading\n") ;
                        removeDirectoryAtPath(CSLImagePath) ;
                    }
                }
                if (!isDir(aPath)) {
                    renameCSLImage(thisImage, CSLImageName) ;
                    readRSAT2DATALayersInto(thisImage, info, RSAT2AccesPath) ;
                    savedCSLImages = addStringValInCSVStruct(aPath, savedCSLImages) ;
                }
                else {
                    
                }
                
                freeCSLImageStructure(thisImage) ;
                freeInfoImage(info) ;
            }
            free(productInfoFilePath) ;
        }
        
        free(inputDir) ;
        free(outputDir) ;
    }
    else {
        /* Reading based on parameter file is considered */
        parametersList = readParameterFileAtPath(csv->stringVal[1]) ;
        
        if((CSLImagePath = getStringValForKeyIn(parametersList, "Path to output image in CSL format")) == NULL)
            ase("Path to output image not found in parameter file...") ;
        thisImage = createCSLDirectoryStructureAtPath(CSLImagePath, __RSAT2__) ;
        
        RSAT2AccesPath = getStringValForKeyIn(parametersList, "RSAT2 data directory") ;
        productInfoFilePath = initStringWith2Strings(RSAT2AccesPath, "/product.xml") ;
        copyRSAT2HeaderToCSLImage(thisImage, productInfoFilePath) ;
        
        aPath = initStringWith3Strings(thisImage->headersDirectoryPath, "/", getPointerToFileNameInPath(productInfoFilePath)) ;
        info = createSLCImageInfoForRSAT2Data(aPath) ;
        free(aPath) ;
        free(productInfoFilePath) ;
        
        aPath = initStringWith2Strings(thisImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
        saveInfoImage(info, aPath) ;
        free(aPath) ;
        
        readRSAT2DATALayersInto(thisImage, info, RSAT2AccesPath) ;
        savedCSLImages = addStringValInCSVStruct(thisImage->imageDirectoryPath, savedCSLImages) ;

        freeCSLImageStructure(thisImage) ;
        freeInfoImage(info) ;
        freeKeyValueList(parametersList) ;
    }
    
    
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    
    return(savedCSLImages) ;
}

void RSAT2DataReaderHelp()
{
    printf("\nUsage:") ;
    printf("\n\t-1- RSAT2DataReader /pathToParameterFile [-create]\n") ;
    printf("\n\t-2- RSAT2DataReader /inputDir [/outputDir] [-r]\n") ;
    printf("\n\n\tThis routine will read SLC RadarSAT2 Level 1 data and save it in CSL format.\n");
    printf("\n\tIf adding \"-create\" command line parameter, \n\tan example parameter file will be created at indicated path.\n") ;
    printf("\n\tIf giving an input directory, all data found in it \n\twill be read and saved in the given output directory\n") ;
    printf("\n\tIf no output directory is given, all read data will be \n\tsaved in the input directory\n") ;
    printf("\n\tBy default, already existing data in the output directory\n\t will not be re-read. \n\tThe -r option force re-reading data\n") ;
    exit(0) ;
}

void createRSAT2DataReaderParameterFileAtPath(char *aPath)
{
    keyValue *parameters ;
    
    parameters = allocAKeyValuePair() ;
    setStringValForKeyIn(parameters, "RSAT2DataReader parameter file", "") ;
    setStringValForKeyIn(parameters, "******************************", "") ;
    setStringValForKeyIn(parameters, "PathToRSAT2Directory", "RSAT2 data directory path (directory containing the manifest.safe file).") ;
    setStringValForKeyIn(parameters, "outputFilePath", "Path to output image in CSL format") ;
    setStringValForKeyIn(parameters, "", "") ;
    setStringValForKeyIn(parameters, "Do not modify, change names, remove or add any file within the predefined RSAT2 directory structure!", "") ;
    
    writeParameterFileAtPath(parameters, aPath) ;
    
    exit(0) ;
}

void copyRSAT2HeaderToCSLImage(CSLImage *aCSLImage, char *productInfoFilePath)
{
    char *outputPath, *buffer ;
    int bufferSize ;
    long fileSeek ;
    rawFileDescriptor *xmlFile ;
    
    bufferSize = 2048 ;
    buffer = allocStringOfLength(bufferSize) ;
    
    outputPath = initStringWith3Strings(aCSLImage->headersDirectoryPath, "/", getPointerToFileNameInPath(productInfoFilePath)) ;
    copyFileAtPathToPath(productInfoFilePath, outputPath) ;
    
    xmlFile = openRawFileForReadingAndWritingAtPath(outputPath) ;
    fgets(buffer, bufferSize, xmlFile->f) ;
    while (replaceSubStringInString(buffer, "xmlns", "xmln0")) {
        fgets(buffer, bufferSize, xmlFile->f) ;
    }
    fileSeek = ftell(xmlFile->f) - strlen(buffer) ;
    fseek(xmlFile->f, fileSeek, SEEK_SET) ;
    fprintf(xmlFile->f, "%s", buffer) ;
    fflush(xmlFile->f) ;
    
    freeRawFileDescriptor(xmlFile) ;
    free(buffer) ;
}


void readRSAT2DATALayersInto(CSLImage *image, SLCImageInfo *info, char *RSAT2AccesPath)
{
    char *outputPath, *inputPath ;
    int layerIndex, iX, iY, azimuthIndex, rangeIndex ;
    int xTiffDim, yTiffDim ;
    float demodulationPhase ;
    complexShort *TiffLineBuffer ;
    complexFloat *anOutputLine, *demodulation ;
    CSVStruct *csv ;
    TIFF *tifImage ;
    rawFileDescriptor *outputLayerFile ;
    progressCounter *counter ;
    RSAT2AdditionalInfo *RSAT2Specific ;

    RSAT2Specific = (RSAT2AdditionalInfo *)info->sensorSpecificInfo ;
    
    csv = readCSVInString(info->polMode) ;
    for (layerIndex = 0; layerIndex < csv->numberOfEntries; layerIndex++) {
        /* Creating output stream */
        outputPath = initStringWith3Strings(image->dataDirectoryPath, "/SLCData.", csv->stringVal[layerIndex]) ;
        if((outputLayerFile = openRawFileForWritingAtPath(outputPath)) == NULL) {
            sprintf(ertex, "Failed to create output file at path %s", outputPath) ;
            ase(ertex) ;
            exit(-1) ;
        }
        free(outputPath) ;

        /* Opening input image layer */
        inputPath = initStringWith4Strings(RSAT2AccesPath, "/imagery_", csv->stringVal[layerIndex], ".tif") ;
        if((tifImage = XTIFFOpen(inputPath, "r")) == NULL)
            ase("failed to open tiff layer") ;
        
        TIFFGetField(tifImage, TIFFTAG_IMAGEWIDTH, &xTiffDim);
        TIFFGetField(tifImage, TIFFTAG_IMAGELENGTH, &yTiffDim);
        TiffLineBuffer = vectorComplexShort(0, xTiffDim - 1) ;
        anOutputLine = vectorComplexFloat(0, xTiffDim - 1) ;
        demodulation = vectorComplexFloat(0, xTiffDim - 1) ;
        for (iX = 0; iX < xTiffDim; iX++) {
            demodulationPhase = 4. * PI * info->radarCarrierFrequency / speedOfLight * (info->slantRange[0] + iX * info->rangeResolutionCell) ;
            demodulation[iX].r = cosf(demodulationPhase) ;
            demodulation[iX].i = sinf(demodulationPhase) ;
        }
        
        printf("\nReading RSAT2 stripmap data: %s polarization layer\n", csv->stringVal[layerIndex]) ;
        counter = initProgressCounterWithMinMaxValue(0, yTiffDim - 1) ;
        for (iY = 0; iY < yTiffDim; iY++) {
            azimuthIndex = (RSAT2Specific->isAzimuthFlipped)? yTiffDim - iY - 1 : iY ;
            if (TIFFReadScanline(tifImage, TiffLineBuffer, azimuthIndex, 0) == -1) {
                ase("TIFF read error") ;
            }
            
            for (iX = 0; iX < xTiffDim; iX++) {
                rangeIndex = (RSAT2Specific->isRangeFlipped)? xTiffDim - iX - 1 : iX ;
                anOutputLine[rangeIndex].r = (float)TiffLineBuffer[iX].r ;
                anOutputLine[rangeIndex].i = (float)TiffLineBuffer[iX].i ;
//                anOutputLine[rangeIndex] = mC(anOutputLine[rangeIndex], demodulation[rangeIndex]) ;
            }
            fwrite(anOutputLine, sizeof(complexFloat), xTiffDim, outputLayerFile->f) ;
            updateProgressCounterForIndex(counter, iY) ;
        }
        updateProgressCounterForIndex(counter, iY) ;
        
        freeVectorComplexShort(TiffLineBuffer, 0) ;
        freeVectorComplexFloat(anOutputLine, 0) ;
        freeVectorComplexFloat(demodulation, 0) ;
        freeProgressCounter(counter) ;
        TIFFClose(tifImage) ;
   }

    freeCSVStruct(csv) ;
}
