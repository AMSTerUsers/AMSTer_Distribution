
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  targetVector.c
 *  decPol
 *
 *  Created by Dominique Derauw on 11/03/05.
 *  Copyright 2005 __MyCompanyName__. All rights reserved.
 *
 */

#include "targetVector.h"
#include "cohOpt.h"

targVectObject *allocTargetVectorObject()
{
	targVectObject *target ;
	if((target = malloc(sizeof(targVectObject))) == NULL) {
		ase("Cannot allocate targetVector Object") ;
	}
	target->fHH = target->fVV = target->fXX = target->fVH = target->fHV = NULL ;
	target->HH = target->VV = target->XX = target->VH = target->HV = NULL ;
	return target ;
}

void registerFilesForTargetVector(rawFileSet *track, targVectObject *target)
{
	target->numberOfFiles = track->numberOfFiles ;
	target->fHH = track->f[0] ;
	target->fVV = track->f[1] ;
	if(track->numberOfFiles == 3) {
		target->fXX = track->f[2] ;
	}
	else {
		target->fHV = track->f[2] ;
		target->fVH = track->f[3] ;
	}
	target->dimX = track->dimX ;
	target->dimY = track->dimY ;
    target->aoi = track->aoi ;
	target->k = matrixComplexFloat(0, target->aoi->dimX - 1, 1, 3) ;
	target->HH = vectorComplexFloat(0, target->aoi->dimX - 1) ;
	target->VV = vectorComplexFloat(0, target->aoi->dimX - 1) ;
    target->XX = vectorComplexFloat(0, target->aoi->dimX - 1) ;
    target->HV = vectorComplexFloat(0, target->aoi->dimX - 1) ;
    target->VH = vectorComplexFloat(0, target->aoi->dimX - 1) ;

    target->currentLine = -1 ;
}

complexFloat **kVectorsForLine(int line, targVectObject *target)
{
	int	i ;
	long offset ;
	float norme1, norme2 ;
    
    if(line != target->currentLine++ && line < target->dimY) {
        /* First, seek into files */
		offset = ((target->aoi->yMin + line) * target->dimX + target->aoi->xMin) * sizeof(complexFloat) ;
		fseek(target->fHH, offset, SEEK_SET) ;
		fseek(target->fVV, offset, SEEK_SET) ;
        if(target->numberOfFiles == 3) {
		fseek(target->fXX, offset, SEEK_SET) ;
        }
        else {
            fseek(target->fHV, offset, SEEK_SET) ;
            fseek(target->fVH, offset, SEEK_SET) ;
        }
        
        /* Now that we are at the right position, we read a line of data in each polarimetric component */
        fread(target->HH, sizeof(complexFloat), target->aoi->dimX, target->fHH) ;
        fread(target->VV, sizeof(complexFloat), target->aoi->dimX, target->fVV) ;
        if(target->numberOfFiles == 3) {
            fread(target->XX, sizeof(complexFloat), target->aoi->dimX, target->fXX) ;
        }
        else {
            /* If XX averaged cross polarization is not provided, we computed from HV and VH components */
            fread(target->HV, sizeof(complexFloat), target->aoi->dimX, target->fHV) ;
            fread(target->VH, sizeof(complexFloat), target->aoi->dimX, target->fVH) ;
            for(i = 0; i < target->aoi->dimX; i++) {
                target->XX[i] = mRC(aC(target->HV[i], target->VH[i]), .5) ;
            }
        }
        
        /* Finally, we compute the k vector for each point of the current line */
        norme1 = (float)1./sqrt(2.) ;
        norme2 = (float)sqrt(2.) ;
        for(i = 0; i < target->aoi->dimX; i++) {
            target->k[i][1] = mRC(aC(target->HH[i], target->VV[i]), norme1) ;
            target->k[i][2] = mRC(sC(target->HH[i], target->VV[i]), norme1) ;
            target->k[i][3] = mRC(target->XX[i], norme2) ;
        }
	}
	if(line >= target->dimY) return (complexFloat **)NULL ;
    
	
	return(target->k) ;
}


void freeTargetVectorObject(targVectObject *target)
{
	if (target->HH) {
		freeVectorComplexFloat(target->HH, 0) ;
		target->HH = NULL ;
	}
	
	if (target->VV) {
		freeVectorComplexFloat(target->VV, 0) ;
		target->VV = NULL ;
	}
	
	if (target->XX) {
		freeVectorComplexFloat(target->XX, 0) ;
		target->XX = NULL ;
	}
	
	if (target->HV) {
		freeVectorComplexFloat(target->HV, 0) ;
		target->HV = NULL ;
	}
	
	if (target->VH) {
		freeVectorComplexFloat(target->VH, 0) ;
		target->VH = NULL ;
	}
	free(target) ;
}


void outerProduct(complexFloat *k1, complexFloat *k2, complexFloat **T)
{
	int i, j ;
	complexFloat tC ;
	
	for(j = 1; j <= 3; j++) {
		tC = cC(k2[j]) ;
		for(i = 1; i <= 3; i++)
			T[i][j] = mC(k1[i], tC) ;
	}
}


