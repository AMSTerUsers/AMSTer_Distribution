
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  H_A_Alpha.c
 *  cohOpt
 *
 *  Created by Dominique Derauw on 25/03/05.
 *  Copyright (c) 2005 Dominique Derauw. All rights reserved.
 *
 */

#include "H_A_Alpha.h"

float entropyForEigenValues(float *eigenValue)
{
    float	P1, P2, P3, S ;
    	
	S = eigenValue[1] + eigenValue[2] + eigenValue[3] ;
	eigenValue[1] /= S ;
	P1 = (eigenValue[1] > 0.)? eigenValue[1] * log(eigenValue[1]) : 0. ;
	eigenValue[2] /= S ;
	P2 = (eigenValue[2] > 0.)? eigenValue[2] * log(eigenValue[2]) : 0. ;
	eigenValue[3] /= S ;
	P3 = (eigenValue[3] > 0.)? eigenValue[3] * log(eigenValue[3]) : 0. ;
	return -(P1 + P2 + P3)/log(3.) ;
}

float anisotropyForEigenValues(float *eigenValue)
{
	float	num, den, anisotropy ;
/*
    float	vP1, vP2, vP3 ;
    
	vP1 = eigenValue[1] ;
	vP2 = eigenValue[2] ;
	vP3 = eigenValue[3] ;
	if(vP1 < vP2) swapFloatValues(&vP1, &vP2) ;
	if(vP2 < vP3) swapFloatValues(&vP2, &vP3) ;
	if(vP1 < vP2) swapFloatValues(&vP1, &vP2) ;

	return (vP2 - vP3)/(vP2 + vP3) ;
*/
	num = eigenValue[2] - eigenValue[3] ;
	den = eigenValue[2] + eigenValue[3] ;
	anisotropy = (den)? num/den : 0.0 ;
	
	return anisotropy ;
}

float	alphaForEigenValuesAndEigenVectors(float *eigenValue, complexFloat **eigenVector)
{
    int		k, l ;
    float	cosin[4], norme, alpha, cosAlpha ;
    
	alpha = 0.0 ;
	for(k = 1; k <= 3; k++) {
		norme = 0.0 ;
		for(l = 1; l <= 3; l++) {
			cosin[l] = sqmC(eigenVector[l][k]) ;
			norme += cosin[l] ;
		}
		cosAlpha = (norme)? sqrt(cosin[1] / norme) : 0.0 ;
		alpha += (float)(eigenValue[k] * acos(cosAlpha)) ;
    }
    return alpha ;
}


/* initialisation de la matrice de cohérence */
void initT(complexFloat **T)
{
    int	i, j ;
    
    for(i = 1; i<= 3; i++)
        for(j = 1; j <= 3; j++)
            T[i][j].r = T[i][j].i = 0.0 ;
}


void swapFloatValues(float *val1, float *val2)
{
	float temp ;
	
	temp = *val1 ;
	*val1 = *val2 ;
	*val2 = temp ;
}

