
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  coherencyMatrix.c
 *  cohOpt
 *
 *  Created by Dominique Derauw on 24/03/05.
 *  Copyright 2005 Dominique Derauw. All rights reserved.
 *
 */

#include "coherencyMatrix.h"

coherencyMatrixObject *allocAndInitCoherencyMatrixObject(char *name, targVectObject *k1, targVectObject *k2, int mAvX, int mAvY, int bAvX, int bAvY)
{
	int i, j ;
	coherencyMatrixObject *cOb ;
	
	cOb = (coherencyMatrixObject *)malloc(sizeof(coherencyMatrixObject)) ;
	sprintf(cOb->name, "%s", name) ;
	cOb->movingAverageX = mAvX ;
	cOb->movingAverageY = mAvY ;
	cOb->boxAverageX = bAvX ;
	cOb->boxAverageY = bAvY ;
	cOb->MC = matrixPileComplexFloat(1, 3, 1, 3, 0, k1->aoi->dimX - 1) ;
	cOb->MT = matrixComplexFloat(1, 3, 1, 3) ;

	cOb->k1 = k1 ;
	cOb->k2 = k2 ;
	
	cOb->mAv = (mAvObject ***)malloc(3 * sizeof(mAvObject **)) - 1 ;
	for(i = 1; i<= 3; i++) {
		cOb->mAv[i] = (mAvObject **)malloc(3 * sizeof(mAvObject *)) - 1 ;
		for(j = 1; j<= 3; j++) {
			cOb->mAv[i][j] = allocMovingAverageObject() ;
			initMovingAverageObject("complexFloat", cOb->movingAverageX, cOb->movingAverageY, k1->aoi->dimX, k1->aoi->dimY, cOb->mAv[i][j]) ;
		}
	}
		
    cOb->eigenVectors = matrixComplexFloat(1, 3, 1, 3) ;
    cOb->eigenValues = vectorFloat(1, 3) ;
	
	return cOb ;
}

void freeCoherencyMatrixObject(coherencyMatrixObject *cOb)
{
	int i, j ;
		
	freeMatrixPileComplexFloat(cOb->MC, 1, 1, 0) ;
	freeMatrixComplexFloat(cOb->MT, 1, 1) ;
	
	for(i = 1; i<= 3; i++) {
		for(j = 1; j<= 3; j++)
			freeMovingAverageObject(cOb->mAv[i][j]) ;
		free(cOb->mAv[i] + 1) ;
	}
	free(cOb->mAv + 1) ;
	
	freeMatrixComplexFloat(cOb->eigenVectors, 1, 1) ;
	freeVectorFloat(cOb->eigenValues, 1) ;
	free(cOb) ;
}

complexFloat **getAveragedCoherencyMatrixAtIndex(int index, coherencyMatrixObject *cOb)
{
	int i, j ;
	
	for(i = 1; i <= 3; i++)
		for(j = 1; j <= 3; j++)
			cOb->MT[i][j] = ((complexFloat *)cOb->mAv[i][j]->average)[index] ;
	return cOb->MT ;
}



void movingAverageOnCoherencyMatrix(coherencyMatrixObject *cOb)
{
	int	j, k, l ;
	
	for(j = 0; j < cOb->k1->aoi->dimX; j++) {
		outerProduct(cOb->k1->k[j], cOb->k2->k[j], cOb->MT) ;
		for(k = 1; k <= 3; k++) 
			for(l = 1; l <= 3; l++) 
				cOb->MC[k][l][j] = cOb->MT[k][l] ;
	}

	for(k = 1; k<=3; k++) 
		for(l = 1; l<=3; l++) 
			addNextLineInMovingAverage(cOb->MC[k][l], cOb->mAv[k][l]) ;
	
	if(cOb->k1->currentLine >= cOb->movingAverageY - 1) {
		for(k = 1; k<=3; k++)
			for(l = 1; l<=3; l++)
				getMovingAverage(cOb->mAv[k][l]) ;
	}
}


void movingAverageOnCoherencyMatrixUpperTriangle(coherencyMatrixObject *cOb)
{
	int	j, k, l ;
	
	for(j = 0; j < cOb->k1->aoi->dimX; j++) {
		outerProduct(cOb->k1->k[j], cOb->k2->k[j], cOb->MT) ;
		for(k = 1; k<=3; k++)
			for(l = k; l<=3; l++)
				cOb->MC[k][l][j] = cOb->MT[k][l] ;
	}

/*
if(!strcmp(cOb->name, "T22"))
	fwrite(cOb->MC[2][3], sizeof(complexFloat), cOb->k1->dimX, cOb->anOutputFile) ;
*/

	for(k = 1; k<=3; k++)
		for(l = k; l<=3; l++)
			addNextLineInMovingAverage(cOb->MC[k][l], cOb->mAv[k][l]) ;
	
	if(cOb->k1->currentLine >= cOb->movingAverageY - 1) {
		for(k = 1; k<=3; k++)
			for(l = k; l<=3; l++)
				getMovingAverage(cOb->mAv[k][l]) ;
	}
}
