
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  cohOptPar.c
 *  cohOptPar
 *
 *  Created by Dominique Derauw on Wed Mar 23 2005.
 *  Copyright (c) 2005 Dominique Derauw. All rights reserved.
 *
 */

#include "cohOpt.h"

int PolInSARProductsGeneration(CSVStruct *csv)
{
	char *aPath = NULL, InSARParametersFileFound ;
	int	currentDirectoryFdesc, i ;
	InSARParametersStruct	*pInSAR ;
    interfaceParameters	*p ;
	cohOpt	*pp ;
	time_t startTime, endTime ;
	
	InSARParametersFileFound = 0 ;
	currentDirectoryFdesc = open(".", O_RDONLY) ;
	fchdir(currentDirectoryFdesc) ;

    if(isArgumentPresentInCSV(csv, "help") || isArgumentPresentInCSV(csv, "-h")) {
        polInSARGenHelp() ;
    }

	i = 1 ;
	while (i < csv->numberOfEntries) {
		aPath = initStringWithString(csv->stringVal[i]) ;
		if(fileExistsAtPath(aPath)) {
			InSARParametersFileFound = 1 ;
			break ;
		}
		i++ ;
		free(aPath) ;
	}
	if(!InSARParametersFileFound) {
		aPath = initStringWithString("./TextFiles/InSARParameters.txt") ;
		if(!fileExistsAtPath(aPath)){
			free(aPath) ;
			aPath = initStringWithString("./InSARParameters.txt") ;
			if(!fileExistsAtPath(aPath)) {
				polInSARGenHelp() ;
				free(aPath) ;
			}
		}
		InSARParametersFileFound = 1 ;
	}
	time(&startTime) ;
	pInSAR = readInSARParametersFileAtPath(aPath) ;
	
    p = createInterfaceParameters(pInSAR) ;
	p->computeOrbitalPhase = 1 ;
	pp = initCohOpt(p) ;
    saveInSARParametersFileAtPath(pInSAR, aPath) ;
	
    coherenceOptimization(pp) ;
	
    displayParameters(pp, stdout) ;
    freeCohOpt(pp) ;
	free(p) ;

	freeInSARParametersStruct(pInSAR) ;
	free(aPath) ;
	
	time(&endTime) ;
	duration(startTime, endTime) ;
	return(0) ;
}


void polInSARGenHelp()
{
	printf("Usage:\nPolInSARProductsGeneration [/pathTo/InSARParameters.txt] \n") ;
	printf("The routine will perform a coherence optimization computation\n") ;
	printf("using all four polarization channels available for both the master\n");
	printf("and the slave image.\n The master image file name and the interpolated\n");
	printf("slave image file name are used as generic names to locate each channels.\n");
	printf("Polarimetric channels are identified by HH, HV, VH and VV.\n");
	printf("\nIf used with no parameters, the routine will look for an InSARparameters.txt file\n within the working directory or within the ./TextFiles subdirectory\n") ;
	printf("Any other path to a text file containing InSAR parameters can be given as first parameter\n\n") ;
	exit(0) ;
}

void displayParameters(cohOpt *pp, FILE *fout)
{
	fprintf(fout, "\n\nTrack 1 : \n") ;
    fprintf(fout, "\tInput Directory :\t\t%s\n", pp->track1->location) ;
    fprintf(fout, "\tGeneric File name :\t%s\n", pp->track1->genericName) ;
    fprintf(fout, "\tRange dimension :\t\t%d\n", pp->track1->dimX) ;
    fprintf(fout, "\tAzimuth dimension :\t%d\n", pp->track1->dimY) ;
	fprintf(fout, "\nTrack 2 : \n") ;
    fprintf(fout, "\tInput Directory :\t\t%s\n", pp->track2->location) ;
    fprintf(fout, "\tGeneric File name :\t%s\n", pp->track2->genericName) ;
    fprintf(fout, "\tRange dimension :\t\t%d\n", pp->track2->dimX) ;
    fprintf(fout, "\tAzimuth dimension :\t%d\n", pp->track2->dimY) ;
    fprintf(fout, "\nMoving Average :\n\tRange dimension :\t%d\n", pp->movingAverageX) ;
    fprintf(fout, "\tAzimuth dimension :\t\t%d\n", pp->movingAverageY) ;
    fprintf(fout, "\nBox Averaging factors :\n\tRange :\t%d\n", pp->boxAverageX) ;
    fprintf(fout, "\tAzimuth :\t%d\n", pp->boxAverageY) ;
	fprintf(fout, "\nResults : \n") ;
    fprintf(fout, "\tOutput Directory :\t\t%s\n", pp->optimizedCoherences->location) ;
    fprintf(fout, "\tGeneric File name :\t%s\n", pp->optimizedCoherences->genericName) ;
    fprintf(fout, "\tRange dimension :\t\t%d\n", pp->optimizedCoherences->dimX) ;
    fprintf(fout, "\tAzimuth dimension :\t%d\n", pp->optimizedCoherences->dimY) ;
}

interfaceParameters	*createInterfaceParameters(InSARParametersStruct *pInSAR)
{
    interfaceParameters	*p ;
	CSVStruct *polMode ;
	
    
    if((p = calloc(1, sizeof(interfaceParameters))) == NULL) {
        ase("failed to allocate interfaceParameters\n") ;
        exit(-1) ;
    }
	
	polMode = readCSVInString(pInSAR->masterInfo->polMode) ;
	p->track1 = allocFilesParameters(polMode->numberOfEntries) ;
	freeCSVStruct(polMode) ;
	polMode = readCSVInString(pInSAR->slaveInfo->polMode) ;
	p->track2 = allocFilesParameters(polMode->numberOfEntries) ;
	freeCSVStruct(polMode) ;
	p->orbitalPhase = allocFilesParameters(1) ;
	p->optimizedCoherences = allocFilesParameters(3) ;
	
	p->track1->location = initStringWithString((pInSAR->masterImage)->dataDirectoryPath) ;
	p->track1->genericName = initStringWithString("SLCData") ;

    p->track2->location = initStringWithString(pInSAR->interpolatedSlave->dataDirectoryPath) ;
	p->track2->genericName = initStringWithString("SLCData") ;
	
	p->orbitalPhase->location = initStringWithString(p->track1->location) ;
	p->orbitalPhase->genericName = initStringWithString("NONE") ;
	
	p->optimizedCoherences->location = getDirectoryPathFromPath(pInSAR->coh.filePath) ;
	p->optimizedCoherences->genericName = initStringWithString("optimizedCoherence") ;
	
	sprintf(p->calculateH_A_Alpha, "YES") ;
	sprintf(p->calculateInterferograms, "YES") ;
	sprintf(p->calculateModuleImages, "YES") ;
    
    p->track1->dimX = pInSAR->ima1.lenr ;
    p->track1->dimY = pInSAR->ima1.lena ;
    p->track2->dimX = pInSAR->ima2.lenr ;
    p->track2->dimY = pInSAR->ima2.lena ;
    
    p->track1->aoi->xMin = p->track2->aoi->xMin = p->orbitalPhase->aoi->xMin = pInSAR->sup.Sgra + pInSAR->coh.spi / 2 ;
    p->track1->aoi->yMin = p->track2->aoi->yMin = p->orbitalPhase->aoi->yMin = pInSAR->sup.Sbaz + pInSAR->coh.spi / 2 ;
    p->track1->aoi->xMax = p->track2->aoi->xMax = p->orbitalPhase->aoi->xMax = pInSAR->sup.Sdra - pInSAR->coh.spi / 2 ;
    p->track1->aoi->yMax = p->track2->aoi->yMax = p->orbitalPhase->aoi->xMax = pInSAR->sup.Shaz - pInSAR->coh.spi / 2 ;
    p->track1->aoi->dimX = p->track2->aoi->dimX = p->orbitalPhase->aoi->dimX = p->track1->aoi->xMax - p->track1->aoi->xMin + 1 ;
    p->track1->aoi->dimY = p->track2->aoi->dimY = p->orbitalPhase->aoi->dimY = p->track1->aoi->yMax - p->track1->aoi->yMin + 1 ;
    
	p->movingAverageX = pInSAR->coh.cor ;
	p->movingAverageY = pInSAR->coh.coa ;
	p->boxAverageX = pInSAR->red.Fra ;
	p->boxAverageY = pInSAR->red.Faz ;

    if(p->boxAverageY < 1) p->boxAverageY = 1 ;
	if(p->boxAverageX < 1) p->boxAverageX = 1 ;
	if(p->movingAverageY < 3) p->movingAverageY = 3 ;
	if(p->movingAverageX < 3) p->movingAverageX = 3 ;
	
	pInSAR->coh.cor = p->movingAverageX ;
	pInSAR->coh.coa = p->movingAverageY ;
	pInSAR->red.Fra = p->boxAverageX ;
	pInSAR->red.Faz = p->boxAverageY ;
	
	p->pInSAR = pInSAR ;
	
    return (p) ;
}

/* Ouverture des fichiers sources */
void openInputFiles(cohOpt *pp)
{
    char fileAcces[_MAX_PATH_LENGTH_] ;
    char polMode[4][3] ;
	int i ;
	CSVStruct *polModeMaster, *polModeSlave ;
	
    polModeMaster = readCSVInString(pp->pInSAR->masterInfo->polMode) ;
    polModeSlave = readCSVInString(pp->pInSAR->slaveInfo->polMode) ;
    if(polModeMaster->numberOfEntries < 3 || polModeSlave->numberOfEntries < 3)
        ase("Master images is not a full polarimetric SAR acquisition\n") ;

    sprintf(polMode[0], "HH") ;
    sprintf(polMode[1], "VV") ;
    sprintf(polMode[2], "HV") ;
    sprintf(polMode[3], "VH") ;
    
	/* All polarimetric channels of the master image are supposed to be within the CSLImage structure */
	/* having a file name with extension corresponding to the polarimetric channel */
    if (polModeMaster->numberOfEntries == 3) {
        sprintf(polMode[2], "XX") ;
    }
    for(i = 0; i < polModeMaster->numberOfEntries; i++) {
		sprintf(fileAcces, "%s/%s.%s", pp->track1->location, pp->track1->genericName, polMode[i]) ;
		if((pp->track1->f[i] = fopen(fileAcces, "r")) == NULL) {
			ase(fileAcces) ;
		}
    }

	/* All polarimetric channels of the interpolated slave image are supposed to be within the CSLImage structure */
	/* having a file name with extension corresponding to the polarimetric channel */
    sprintf(polMode[2], "HV") ;
    if (polModeSlave->numberOfEntries == 3) {
        sprintf(polMode[2], "XX") ;
    }

	for(i = 0; i < polModeSlave->numberOfEntries; i++) {
		sprintf(fileAcces, "%s/%s.%s", pp->track2->location, pp->track2->genericName, polMode[i]) ;
		if((pp->track2->f[i] = fopen(fileAcces, "r")) == NULL) {
			ase(fileAcces) ;
		}
	}
	
	if(pp->calculateInterferograms) {
		if((pp->isTopographicPhaseGiven = (strncmp(pp->orbitalPhase->genericName, "NONE", 4) != 0))) {
            /* !!! Should be revised because fileOffset corresponds to slave image */
            /* Up to now, no orbital phase is given in input */
            /* In case an orbital phase would be given, fileOffset should be adapted to the real corresponding area, i.e. the supperposition. */
			pp->orbitalPhase->f[0] = (FILE *)malloc(sizeof(FILE)) ;
			sprintf(fileAcces, "%s/%s", pp->orbitalPhase->location, pp->orbitalPhase->genericName) ;
			if((pp->orbitalPhase->f[0] = fopen(fileAcces, "r")) == NULL) {
				ase(fileAcces) ;
			}
		}
	}
	
	freeCSVStruct(polModeMaster) ;
	freeCSVStruct(polModeSlave) ;
}

/* Open output files */
void openOutputFiles(cohOpt *p)
{
    char	*filePath, extension[3][8] ;
	int		i ;
	
    sprintf(extension[0], ".c1") ;
    sprintf(extension[1], ".c2") ;
    sprintf(extension[2], ".c3") ;
    
	for(i = 0; i < 3; i++) {
		filePath = initStringWith3Strings(p->optimizedCoherences->location, p->optimizedCoherences->genericName, extension[i]) ;
		if((p->optimizedCoherences->f[i] = fopen(filePath, "w")) == NULL) {
			free(filePath) ;
			ase(filePath) ;
		}
		free(filePath) ;
	}
/*	
	free(p->pInSAR->coh.filePath) ;
	p->pInSAR->coh.filePath = initStringWith3Strings(p->optimizedCoherences->location, p->optimizedCoherences->genericName, extension[0]) ;
*/	
	if(p->calculateH_A_Alpha) {
		filePath = initStringWith3Strings(p->HAA1->location, p->HAA1->genericName, ".Entropy") ;
		if((p->HAA1->f[0] = fopen(filePath, "w")) == NULL) {
			free(filePath) ;
			ase(filePath) ;
		}
		free(filePath) ;

		filePath = initStringWith3Strings(p->HAA1->location, p->HAA1->genericName, ".Anisotropy") ;
		if((p->HAA1->f[1] = fopen(filePath, "w")) == NULL) {
			free(filePath) ;
			ase(filePath) ;
		}
		free(filePath) ;

		filePath = initStringWith3Strings(p->HAA1->location, p->HAA1->genericName, ".Alpha") ;
		if((p->HAA1->f[2] = fopen(filePath, "w")) == NULL) {
			free(filePath) ;
			ase(filePath) ;
		}
		free(filePath) ;

		filePath = initStringWith3Strings(p->HAA2->location, p->HAA2->genericName, ".Entropy") ;
		if((p->HAA2->f[0] = fopen(filePath, "w")) == NULL) {
			free(filePath) ;
			ase(filePath) ;
		}
		free(filePath) ;

		filePath = initStringWith3Strings(p->HAA2->location, p->HAA2->genericName, ".Anisotropy") ;
		if((p->HAA2->f[1] = fopen(filePath, "w")) == NULL) {
			free(filePath) ;
			ase(filePath) ;
		}
		free(filePath) ;

		filePath = initStringWith3Strings(p->HAA2->location, p->HAA2->genericName, ".Alpha") ;
		if((p->HAA2->f[2] = fopen(filePath, "w")) == NULL) {
			free(filePath) ;
			ase(filePath) ;
		}
		free(filePath) ;
	}
	
	if(p->calculateInterferograms) {
		sprintf(extension[0], ".i1") ;
		sprintf(extension[1], ".i2") ;
		sprintf(extension[2], ".i3") ;
		
		for(i = 0; i < 3; i++) {
			filePath = initStringWith3Strings(p->interferograms->location, p->interferograms->genericName, extension[i]) ;
			if((p->interferograms->f[i] = fopen(filePath, "w")) == NULL) {
				free(filePath) ;
				ase(filePath) ;
			}
			free(filePath) ;
		}
/*		
		free(p->pInSAR->interf.filePath) ;
		p->pInSAR->interf.filePath = initStringWith3Strings(p->interferograms->location, p->interferograms->genericName, extension[0]) ;
		free(p->pInSAR->filter.filePath) ;
		p->pInSAR->filter.filePath = initStringWithString(p->pInSAR->interf.filePath) ;
*/
	}
	
	if(p->calculateModuleImages) {
		sprintf(extension[0], ".HH.mod") ;
		sprintf(extension[1], ".VV.mod") ;
		sprintf(extension[2], ".XX.mod") ;
		
		for(i = 0; i < 3; i++) {
			filePath = initStringWith3Strings(p->moduleImages1->location, p->moduleImages1->genericName, extension[i]) ;
			if((p->moduleImages1->f[i] = fopen(filePath, "w")) == NULL) {
				free(filePath) ;
				ase(filePath) ;
			}
			free(filePath) ;

			filePath = initStringWith3Strings(p->moduleImages2->location, p->moduleImages2->genericName, extension[i]) ;
			if((p->moduleImages2->f[i] = fopen(filePath, "w")) == NULL) {
				free(filePath) ;
				ase(filePath) ;
			}
			free(filePath) ;
		}
		
		free(p->pInSAR->mod1.filePath) ;
		p->pInSAR->mod1.filePath = initStringWith3Strings(p->moduleImages1->location, p->moduleImages1->genericName, extension[0]) ;
		free(p->pInSAR->mod2.filePath) ;
		p->pInSAR->mod2.filePath = initStringWith3Strings(p->moduleImages2->location, p->moduleImages2->genericName, extension[0]) ;
	}
}

rawFileSet *allocFilesParameters(int N)
{
	int i ;
	rawFileSet *p ;
	
	if((p = malloc(sizeof(rawFileSet))) == NULL)
		ase("failed to allocate rawFileSet") ;
	
	p->location = NULL ;
	p->genericName = NULL ;
	p->numberOfFiles = N ;
	p->f = (FILE **)malloc(N * sizeof(FILE *)) ;
	for(i = 0; i < N; i++)
		p->f[i] = NULL ;
    
    p->aoi = malloc(sizeof(p->aoi[0])) ;
	
	return p ;
}

void freeFilesParameters(rawFileSet *p)
{
	int i ;
	
	if(p->location != NULL) {
		free(p->location) ;
	}
	if(p->genericName != NULL) {
		free(p->genericName) ;
	}
	
	for(i = 0; i < p->numberOfFiles; i++) {
		if(p->f[i] != NULL) {
			fclose(p->f[i]) ;
		}
	}
	free(p->f) ;
    
    if (p->aoi) {
        free(p->aoi) ;
    }
	free(p) ;
}


cohOpt *initCohOpt(interfaceParameters *p)
{
	char polMode[5][4] ;
	int i, j ;
	cohOpt *pp ;
	
/* Allocation of processing parameters structure */
	if((pp = (cohOpt *)malloc(sizeof(cohOpt))) == NULL)
		ase("Failed to allocate cohOpt : ") ;
	
	sprintf(polMode[0], ".HH") ;
	sprintf(polMode[1], ".VV") ;
	sprintf(polMode[2], ".HV") ;
	sprintf(polMode[3], ".VH") ;
	sprintf(polMode[4], ".XX") ;
	
	pp->computeOrbitalPhase = p->computeOrbitalPhase ;
	pp->pInSAR = p->pInSAR ;
	pp->track1 = p->track1 ;
	pp->track2 = p->track2 ;
	pp->optimizedCoherences = p->optimizedCoherences ;
	pp->orbitalPhase = p->orbitalPhase ;
	pp->calculateInterferograms = (!strcmp(p->calculateInterferograms,	"YES"))? 1 : 0 ;
	pp->calculateH_A_Alpha		= (!strcmp(p->calculateH_A_Alpha,		"YES"))? 1 : 0 ;
	pp->calculateModuleImages	= (!strcmp(p->calculateModuleImages,	"YES"))? 1 : 0 ;
    openInputFiles(pp) ;
	
	pp->boxAverageX = p->boxAverageX ;
	pp->boxAverageY = p->boxAverageY ;
	pp->movingAverageX = p->movingAverageX ;
	pp->movingAverageY = p->movingAverageY ;
    
	pp->k1 = allocTargetVectorObject() ;
	pp->k2 = allocTargetVectorObject() ;
	registerFilesForTargetVector(p->track1, pp->k1) ;
	registerFilesForTargetVector(p->track2, pp->k2) ;
    	
	pp->T11 = allocAndInitCoherencyMatrixObject("T11", pp->k1, pp->k1, p->movingAverageX, p->movingAverageY, p->boxAverageX, p->boxAverageY) ;
	pp->T22 = allocAndInitCoherencyMatrixObject("T22", pp->k2, pp->k2, p->movingAverageX, p->movingAverageY, p->boxAverageX, p->boxAverageY) ;
	pp->O12 = allocAndInitCoherencyMatrixObject("O12", pp->k1, pp->k2, p->movingAverageX, p->movingAverageY, p->boxAverageX, p->boxAverageY) ;

	pp->optimizedCoherences->dimX = pp->T11->mAv[1][1]->outputRect.dimX / pp->boxAverageX ;
	pp->optimizedCoherences->dimY = pp->T11->mAv[1][1]->outputRect.dimY / pp->boxAverageY ;

	pp->piM = matrixComplexFloat(1, 3, 1, 3) ;
	pp->piT = matrixComplexFloat(1, 3, 1, 3) ;
	pp->M = matrixComplexFloat(1, 3, 1, 3) ;
	pp->MO12T = matrixComplexFloat(1, 3, 1, 3) ;
	pp->iMT11 = matrixComplexFloat(1, 3, 1, 3) ;
	pp->iMT22 = matrixComplexFloat(1, 3, 1, 3) ;
	pp->optimumScatteringMechanism1 = matrixComplexFloat(1, 3, 1, 3) ;
	pp->optimumScatteringMechanism2 = matrixComplexFloat(1, 3, 1, 3) ;
	pp->v1 = vectorFloat(1, 3) ;
	pp->v2 = vectorFloat(1, 3) ;
	pp->coh = matrixFloat(0, 2, 0, pp->optimizedCoherences->dimX - 1) ;
	
	if(pp->computeOrbitalPhase) pp->isTopographicPhaseGiven = 1 ;
	if(pp->calculateInterferograms) {
		pp->interferograms = allocFilesParameters(3) ;
		pp->interferograms->location = initStringWithString(pp->optimizedCoherences->location) ;
		pp->interferograms->genericName = initStringWithString("optimizedInterferogram") ;
		pp->interferograms->dimX = pp->optimizedCoherences->dimX ;
		pp->interferograms->dimY = pp->optimizedCoherences->dimY ;
		pp->complexInterferograms = matrixComplexFloat(0, 2, 0, pp->optimizedCoherences->dimX - 1) ;
		pp->complexReferencePhases = matrixComplexFloat(0, 2, 0, pp->optimizedCoherences->dimX - 1) ;
		pp->interferometricPhases = matrixFloat(0, 2, 0, pp->optimizedCoherences->dimX - 1) ;
		pp->diag = vectorComplexFloat(1, 3) ;
		if(pp->isTopographicPhaseGiven) {
			pp->oph = vectorFloat(0, pp->orbitalPhase->aoi->dimX - 1) ;
			pp->movingAverageOnOrbitalPhase = allocMovingAverageObject() ;
			initMovingAverageObject("float", pp->movingAverageX, p->movingAverageY, pp->k1->aoi->dimX, pp->k1->aoi->dimY, pp->movingAverageOnOrbitalPhase) ;
		}
		pp->pInSAR->interf.lenr = pp->pInSAR->coh.lenr = pp->optimizedCoherences->dimX ;
		pp->pInSAR->interf.lena = pp->pInSAR->coh.lena = pp->optimizedCoherences->dimY ;
	}

	if(pp->calculateH_A_Alpha) {
		pp->HAA1 = allocFilesParameters(3) ;
		pp->HAA2 = allocFilesParameters(3) ;
		pp->HAA1->location = initStringWithString(pp->optimizedCoherences->location) ;
		pp->HAA2->location = initStringWithString(pp->optimizedCoherences->location) ;
		pp->HAA1->genericName = getFileNameFromPath((pp->pInSAR->masterImage)->imageDirectoryPath) ;
		pp->HAA2->genericName = getFileNameFromPath((pp->pInSAR->slaveImage)->imageDirectoryPath) ;
		stripExtensionAtEndOfPath(pp->HAA1->genericName) ;
		stripExtensionAtEndOfPath(pp->HAA2->genericName) ;
		pp->HAA1->dimX = pp->HAA2->dimX = pp->optimizedCoherences->dimX ;
		pp->HAA1->dimY = pp->HAA2->dimY = pp->optimizedCoherences->dimY ;
		pp->H_A_Alpha1 = matrixFloat(0, 2, 0, pp->optimizedCoherences->dimX - 1) ;
		pp->H_A_Alpha2 = matrixFloat(0, 2, 0, pp->optimizedCoherences->dimX - 1) ;
	}
	
	if(pp->calculateModuleImages) {
		pp->moduleImages1 = allocFilesParameters(3) ;
		pp->moduleImages2 = allocFilesParameters(3) ;
		pp->moduleImages1->location = initStringWithString(pp->optimizedCoherences->location) ;
		pp->moduleImages2->location = initStringWithString(pp->optimizedCoherences->location) ;
		pp->moduleImages1->genericName = getFileNameFromPath((pp->pInSAR->mod1).filePath) ;
		pp->moduleImages2->genericName = getFileNameFromPath((pp->pInSAR->mod2).filePath) ;
		for(i = 0; i < 5; i++) {
			removeStringInString(pp->moduleImages1->genericName, polMode[i]) ;
			removeStringInString(pp->moduleImages2->genericName, polMode[i]) ;
		}
		removeStringInString(pp->moduleImages1->genericName, ".mod") ;
		removeStringInString(pp->moduleImages2->genericName, ".mod") ;
		pp->moduleImages1->dimX = pp->moduleImages2->dimX = pp->optimizedCoherences->dimX ;
		pp->moduleImages1->dimY = pp->moduleImages2->dimY = pp->optimizedCoherences->dimY ;
		pp->modules1 = matrixFloat(0, 2, 0, pp->optimizedCoherences->dimX - 1) ;
		pp->modules2 = matrixFloat(0, 2, 0, pp->optimizedCoherences->dimX - 1) ;
		pp->mod = vectorFloat(0, pp->k1->aoi->dimX - 1) ;
		pp->movingAverageOnModules = (mAvObject ***)malloc(2 * sizeof(mAvObject **)) - 1 ;
		for(i = 1; i<= 2; i++) {
			pp->movingAverageOnModules[i] = (mAvObject **)malloc(3 * sizeof(mAvObject *)) - 1 ;
			for(j = 1; j<= 3; j++) {
				pp->movingAverageOnModules[i][j] = allocMovingAverageObject() ;
				initMovingAverageObject("float", pp->movingAverageX, p->movingAverageY, pp->k1->aoi->dimX, pp->k1->aoi->dimY, pp->movingAverageOnModules[i][j]) ;
			}
		}
		pp->pInSAR->mod1.lenr = pp->pInSAR->mod2.lenr = pp->optimizedCoherences->dimX ;
		pp->pInSAR->mod1.lena = pp->pInSAR->mod2.lena = pp->optimizedCoherences->dimY ;
	}

	pp->norme = (float)(pp->boxAverageX * pp->boxAverageY) ;
	pp->currentLine = -1 ;
	
    openOutputFiles(pp) ;

	return pp ;
}


/* Libération des pointeurs et fermeture des fichiers */
void freeCohOpt(cohOpt *pp)
{
	int i, j ;
	
	freeFilesParameters(pp->track1) ;
	freeFilesParameters(pp->track2) ;
	freeFilesParameters(pp->optimizedCoherences) ;
	freeFilesParameters(pp->orbitalPhase) ;
	if(pp->k1 != NULL) freeTargetVectorObject(pp->k1) ;
	if(pp->k2 != NULL) freeTargetVectorObject(pp->k2) ;
	freeCoherencyMatrixObject(pp->T11) ;
	freeCoherencyMatrixObject(pp->T22) ;
	freeCoherencyMatrixObject(pp->O12) ;
	freeMatrixComplexFloat(pp->piM, 1, 1) ;
	freeMatrixComplexFloat(pp->piT, 1, 1) ;
	freeMatrixComplexFloat(pp->M, 1, 1) ;
	freeMatrixComplexFloat(pp->MO12T, 1, 1) ;
	freeMatrixComplexFloat(pp->iMT11, 1, 1) ;
	freeMatrixComplexFloat(pp->iMT22, 1, 1) ;
	freeMatrixComplexFloat(pp->optimumScatteringMechanism1, 1, 1) ;
	freeMatrixComplexFloat(pp->optimumScatteringMechanism2, 1, 1) ;
	freeVectorFloat(pp->v1, 1) ;
	freeVectorFloat(pp->v2, 1) ;
	freeMatrixFloat(pp->coh, 0, 0) ;
	if(pp->calculateH_A_Alpha) {
		freeFilesParameters(pp->HAA1) ;
		freeFilesParameters(pp->HAA2) ;
		freeMatrixFloat(pp->H_A_Alpha1, 0, 0) ;
		freeMatrixFloat(pp->H_A_Alpha2, 0, 0) ;
	}
	if(pp->calculateInterferograms) {
		freeFilesParameters(pp->interferograms) ;
		freeMatrixComplexFloat(pp->complexInterferograms, 0, 0) ;
		freeMatrixComplexFloat(pp->complexReferencePhases, 0, 0) ;
		freeMatrixFloat(pp->interferometricPhases, 0, 0) ;
		freeVectorComplexFloat(pp->diag, 1) ;
	}
	if(pp->calculateModuleImages) {
		freeFilesParameters(pp->moduleImages1) ;
		freeFilesParameters(pp->moduleImages2) ;
		freeMatrixFloat(pp->modules1, 0, 0) ;
		freeMatrixFloat(pp->modules2, 0, 0) ;
		freeVectorFloat(pp->mod, 0) ;
		for(i = 1; i<= 2; i++) {
			for(j = 1; j<= 3; j++)
				freeMovingAverageObject(pp->movingAverageOnModules[i][j]) ;
			free(pp->movingAverageOnModules[i] + 1) ;
		}
		free(pp->movingAverageOnModules + 1) ;
	}

	
	free(pp) ;
}


