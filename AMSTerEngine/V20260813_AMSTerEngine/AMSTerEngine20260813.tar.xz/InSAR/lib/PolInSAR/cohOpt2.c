
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  cohOpt.c
 *  cohOpt
 *
 *  Created by Dominique Derauw on Wed Mar 23 2005.
 *  Copyright (c) 2005 Dominique Derauw. All rights reserved.
 *
 */

#include "cohOpt.h"
void printfMatriceDouble(double **M) ;
void printfMatrice(complexFloat **M) ;



void coherenceOptimization(cohOpt *pp)
{
    int		i,j, k, l, m, iX, pourcent = 0 ;
	complexFloat tC ;
    
    fprintf(stdout, "Coherence optimization:\n") ;
	initMovingAverageOnCoherencyMatrices(pp) ;
    for(i = 0; i < pp->optimizedCoherences->dimY; i++) {
		/* Initialize requested results lines to zero vectors */
		for(j = 0; j < 3; j++) resetFloatVectorToZero(pp->coh[j], 0, pp->optimizedCoherences->dimX - 1) ;
		if(pp->calculateH_A_Alpha) {
			for(j = 0; j < 3; j++) resetFloatVectorToZero(pp->H_A_Alpha1[j], 0, pp->optimizedCoherences->dimX - 1) ;
			for(j = 0; j < 3; j++) resetFloatVectorToZero(pp->H_A_Alpha2[j], 0, pp->optimizedCoherences->dimX - 1) ;
		}
		if(pp->calculateInterferograms) {
			for(j = 0; j < 3; j++) resetFloatVectorToZero(pp->interferometricPhases[j], 0, pp->optimizedCoherences->dimX - 1) ;
			for(j = 0; j < 3; j++) resetComplexFloatVectorToZero(pp->complexInterferograms[j], 0, pp->optimizedCoherences->dimX - 1) ;
			for(j = 0; j < 3; j++) resetComplexFloatVectorToZero(pp->complexReferencePhases[j], 0, pp->optimizedCoherences->dimX - 1) ;
		}
		if(pp->calculateModuleImages) {
			for(j = 0; j < 3; j++) resetFloatVectorToZero(pp->modules1[j], 0, pp->optimizedCoherences->dimX - 1) ;
			for(j = 0; j < 3; j++) resetFloatVectorToZero(pp->modules2[j], 0, pp->optimizedCoherences->dimX - 1) ;
		}
			
		for(k = 0; k < pp->boxAverageY; k++) {
			pp->currentLine++ ;
			/* Update target vectors for current line in input images */
			kVectorsForLine(pp->currentLine, pp->k1) ;
			kVectorsForLine(pp->currentLine, pp->k2) ;
            
			movingAverageOnModuleImages(pp) ;
			/* Perform moving average for coherenccy matrix elements */
			movingAverageOnCoherencyMatrix(pp->T11) ;
			movingAverageOnCoherencyMatrix(pp->T22) ;
			movingAverageOnCoherencyMatrix(pp->O12) ;
			
			if(pp->calculateInterferograms && pp->isTopographicPhaseGiven) movingAverageOnOrbitalPhase(pp) ;
			
			for(j = 0; j < pp->optimizedCoherences->dimX; j++) {
				/* Test if box averaged master HH mod is not null to proceed */
				iX = j * pp->boxAverageX ; /* iX is the current full resolution X image index */
				for(l = 0; l < pp->boxAverageX; l++, iX++) {
					boxAveragingOfModulesForIndex(iX, pp) ;
				}
				if (pp->modules1[0][j]) {					
					for(l = 0, iX = j * pp->boxAverageX; l < pp->boxAverageX; l++, iX++) {
						pp->MT11 = getAveragedCoherencyMatrixAtIndex(iX, pp->T11) ;
						pp->MT22 = getAveragedCoherencyMatrixAtIndex(iX, pp->T22) ;
						pp->MO12 = getAveragedCoherencyMatrixAtIndex(iX, pp->O12) ;
						getOptimizedCoherencesForIndex(j, pp) ;
						
						if(pp->calculateInterferograms) getOptimizedComplexInterferogramsForIndex(iX, pp) ;
						if(pp->calculateH_A_Alpha) boxAveragingOfH_A_AlphaForIndex(iX, pp) ;
					}
				}				
			}
		}

		for(m = 0; m < 3; m++) {
			for(j = 0; j < pp->optimizedCoherences->dimX; j++) {
                pp->coh[m][j] /= pp->norme ;
            }
            fwrite(pp->coh[m], sizeof(float), pp->optimizedCoherences->dimX, pp->optimizedCoherences->f[m]) ;
			fflush(pp->optimizedCoherences->f[m]) ;
            
			if(pp->calculateInterferograms) {
				for(j = 0; j < pp->optimizedCoherences->dimX; j++) {
					tC = mC(pp->complexInterferograms[m][j], pp->complexReferencePhases[m][j]) ;
					pp->interferometricPhases[m][j] = phi(&tC) ;
				}
				fwrite(pp->interferometricPhases[m], sizeof(float), pp->optimizedCoherences->dimX, pp->interferograms->f[m]) ;
				fflush(pp->interferograms->f[m]) ;

			}
		}

		if(pp->calculateH_A_Alpha) saveH_A_Alpha(pp) ;
		if(pp->calculateModuleImages) saveModules(pp) ;
				
        if(pourcent < (100 * (i + 1) / pp->optimizedCoherences->dimY)) {
            pourcent = 100 * (i + 1) / pp->optimizedCoherences->dimY ;
            fprintf(stdout, "%2d%%  ", pourcent) ;
            fflush(stdout) ;
            if(pourcent == 10*(pourcent/10)) fprintf(stdout, "\n") ;
        }
    }
}


void initMovingAverageOnCoherencyMatrices(cohOpt *pp)
{
	int i ;
	
	for(i = 0; i < pp->movingAverageY - 1; i++) {
		pp->currentLine++ ;
        
		movingAverageOnCoherencyMatrix(pp->T11) ;
		movingAverageOnCoherencyMatrix(pp->T22) ;
		movingAverageOnCoherencyMatrix(pp->O12) ;
        
		if(pp->calculateModuleImages) movingAverageOnModuleImages(pp) ;
		if(pp->calculateInterferograms  && pp->isTopographicPhaseGiven) movingAverageOnOrbitalPhase(pp) ;
	}
}


void piMatrixCalculation(cohOpt *pp)
{
/* Square root of the inverse of T22 */
	transpose3X3Matrix(pp->T22->eigenVectors, pp->piM) ;
	inverseOfSquareRootOfEigenValues(pp->T22->eigenValues, pp->v2) ;
	multiplyMatrixByDiag(pp->piM, pp->v2) ;
	multiplyMatrixByMatrixInPlace(pp->piM, pp->T22->eigenVectors) ;
	
/* Square root of the inverse of T11 */
	transpose3X3Matrix(pp->T11->eigenVectors, pp->M) ;
	inverseOfSquareRootOfEigenValues(pp->T11->eigenValues, pp->v1) ;
	multiplyMatrixByDiag(pp->M, pp->v1) ;
	multiplyMatrixByMatrixInPlace(pp->M, pp->T11->eigenVectors) ;

/* Calculation of Matrix PI */
	multiplyMatrixByMatrixInPlace(pp->piM, pp->MO12) ;
	multiplyMatrixByMatrixInPlace(pp->piM, pp->M) ;
	
/* and of its transpose */
	transpose3X3Matrix(pp->piM, pp->piT) ;
}


void getOptimizedCoherencesForIndex(int index, cohOpt *pp)
{
	int i ;
    
//    invert3X3HMatrix(pp->MT11, pp->iMT11) ;
//	invert3X3HMatrix(pp->MT22, pp->iMT22) ;
	if (invertMatrixComplexFloat(pp->MT11, pp->iMT11, 3) && invertMatrixComplexFloat(pp->MT22, pp->iMT22, 3))
	{
		transpose3X3Matrix(pp->MO12, pp->MO12T) ;
		
		multiplyMatrixByMatrix(pp->MO12, pp->iMT11, pp->M) ;
		multiplyMatrixByMatrixInPlace(pp->M, pp->MO12T) ;
		multiplyMatrixByMatrixInPlace(pp->M, pp->iMT22) ;
		
	cplx_diag_mat3(pp->M, pp->optimumScatteringMechanism2, pp->v2) ;
		
	//	addRandEpsilonTo3X3MatrixElement(pp->M) ;
	//	jacobiComplexe(pp->M, 3, pp->v2, pp->optimumScatteringMechanism2, SORT) ;

		if(pp->calculateInterferograms) {
		/* Optimum scattering mechanism 1 calculation */
			multiplyMatrixByMatrix(pp->MO12T, pp->iMT22, pp->M) ;
			multiplyMatrixByMatrixInPlace(pp->M, pp->MO12) ;
			multiplyMatrixByMatrixInPlace(pp->M, pp->iMT11) ;
	cplx_diag_mat3(pp->M, pp->optimumScatteringMechanism1, pp->v1) ;
	//		printfMatrice(pp->M) ;
	//		addRandEpsilonTo3X3MatrixElement(pp->M) ;
	//		jacobiComplexe(pp->M, 3, pp->v1, pp->optimumScatteringMechanism1, SORT) ;
			
			for(i = 1; i <= 3; i++) {
				pp->v2[i] = (pp->v1[i] + pp->v2[i])/2. ;
			}
		}
		for(i = 0; i < 3; i++) {
			pp->v2[i + 1] = (pp->v2[i + 1] > 1.)? 1. : pp->v2[i + 1] ;
			pp->coh[i][index] += sqrt(pp->v2[i + 1]) ;
		}
	}
}

void getOptimizedComplexInterferogramsForIndex(int index, cohOpt *pp)
{
	int i, reducedImageIndex ;
	float oph ;
	complexFloat tC ;
	
	transpose3X3MatrixInPlace(pp->optimumScatteringMechanism1) ;
	diagOfMatrixProduct(pp->optimumScatteringMechanism2, pp->optimumScatteringMechanism1, pp->diag) ;
	
	reducedImageIndex = div(index, pp->boxAverageX).quot ;
	if(pp->isTopographicPhaseGiven) {
		oph = ((float *)pp->movingAverageOnOrbitalPhase->average)[index] ;
		tC.r = cos(oph) ;
		tC.i = sin(oph) ;
		
		for(i = 0; i < 3; i++) pp->complexReferencePhases[i][reducedImageIndex] = aC(pp->complexReferencePhases[i][reducedImageIndex], cC(mC(pp->diag[i + 1], tC))) ;
	}
	else
		for(i = 0; i < 3; i++) pp->complexReferencePhases[i][reducedImageIndex] = aC(pp->complexReferencePhases[i][reducedImageIndex], cC(pp->diag[i + 1])) ;	
	
	multiplyMatrixByMatrix(pp->optimumScatteringMechanism2, pp->O12->MT, pp->M) ;
	diagOfMatrixProduct(pp->M, pp->optimumScatteringMechanism1, pp->diag) ;
	for(i = 0; i < 3; i++) pp->complexInterferograms[i][reducedImageIndex] = aC(pp->complexInterferograms[i][reducedImageIndex], pp->diag[i + 1]) ;
}


void transpose3X3Matrix(complexFloat **M1, complexFloat **M2)
{
	int	i, j ;
	
	for(j = 1; j <= 3; j++)
		for(i = 1 ; i <= 3; i++)
			M2[i][j] = cC(M1[j][i]) ;
}


void transpose3X3MatrixInPlace(complexFloat **M)
{
	int	i, j, N ;
	complexFloat tC ;
	
	N = 3 ;
	for(i = 1; i <= N - 1; i++) {
		for(j = i + 1 ; j <= N; j++) {
			tC = cC(M[i][j]) ;
			M[i][j] = cC(M[j][i]) ;
			M[j][i] = tC ;
		}
	}
}


void inverseOfSquareRootOfEigenValues(float *eigenValues, float *v)
{
	int	i ;
	
	for(i = 1 ; i <= 3; i++) {
		v[i] = (float)(1. / sqrt(eigenValues[i])) ;
	}	
}


void multiplyMatrixByDiag(complexFloat **M, float *v)
{
	int	i, j ;
	
	for(i = 1 ; i <= 3; i++)
		for(j = 1; j <= 3; j++)
			M[i][j] = mRC(M[i][j], v[i]) ;
}


void multiplyMatrixByMatrixInPlace(complexFloat **M1, complexFloat **M2)
{
	int	i, j, k ;
	complexFloat tC[4] ;
	
	for(j = 1; j <= 3; j++) {
		for(i = 1 ; i <= 3; i++) {
			tC[i].r = tC[i].i = 0.0 ;
			for(k = 1; k <= 3; k++) {
				tC[i] = aC(tC[i], mC(M2[i][k], M1[k][j])) ;
			}
		}
		for(i = 1; i <= 3; i++)
			M1[i][j] = tC[i] ;
	}	
}


void multiplyMatrixByMatrix(complexFloat **M1, complexFloat **M2, complexFloat **M3)
{
	int	i, j, k ;
	
	for(i = 1 ; i <= 3; i++) {
		for(j = 1; j <= 3; j++) {
			M3[i][j].r = M3[i][j].i = 0.0 ;
			for(k = 1; k <= 3; k++) {
				M3[i][j] = aC(M3[i][j], mC(M2[i][k], M1[k][j])) ;
			}
		}
	}
}


void diagOfMatrixProduct(complexFloat **M1, complexFloat **M2, complexFloat *diag)
{
	int	i, k ;
	
	for(i = 1 ; i <= 3; i++) {
		diag[i].r = diag[i].i = 0.0 ;
		for(k = 1; k <= 3; k++) 
			diag[i] = aC(diag[i], mC(M2[i][k], M1[k][i])) ;
	}
}

void resetFloatVectorToZero(float *v, int iMin, int iMax)
{
	int i ;
	
	for(i = iMin; i <= iMax; i++) v[i] = 0.0 ;
}

void resetComplexFloatVectorToZero(complexFloat *v, int iMin, int iMax)
{
	int i ;
	
	for(i = iMin; i <= iMax; i++) v[i].r = v[i].i = 0.0 ;
}

void boxAveragingOfH_A_AlphaForIndex(int index, cohOpt *pp)
{
	int	reducedImageIndex ;
	
	reducedImageIndex = div(index, pp->boxAverageX).quot ;
//cplx_diag_mat3(pp->MT11, pp->T11->eigenVectors, pp->T11->eigenValues) ;
	jacobiComplexe(pp->MT11, 3, pp->T11->eigenValues, pp->T11->eigenVectors, SORT) ;
	pp->H_A_Alpha1[0][reducedImageIndex] += entropyForEigenValues(pp->T11->eigenValues) ;
	pp->H_A_Alpha1[1][reducedImageIndex] += anisotropyForEigenValues(pp->T11->eigenValues) ;
	pp->H_A_Alpha1[2][reducedImageIndex] += alphaForEigenValuesAndEigenVectors(pp->T11->eigenValues, pp->T11->eigenVectors) ;
//cplx_diag_mat3(pp->MT22, pp->T22->eigenVectors, pp->T22->eigenValues) ;
	jacobiComplexe(pp->MT22, 3, pp->T22->eigenValues, pp->T22->eigenVectors, SORT) ;
	pp->H_A_Alpha2[0][reducedImageIndex] += entropyForEigenValues(pp->T22->eigenValues) ;
	pp->H_A_Alpha2[1][reducedImageIndex] += anisotropyForEigenValues(pp->T22->eigenValues) ;
	pp->H_A_Alpha2[2][reducedImageIndex] += alphaForEigenValuesAndEigenVectors(pp->T22->eigenValues, pp->T22->eigenVectors) ;
}

void saveH_A_Alpha(cohOpt *pp)
{
	int	i, j ;
	
	for(i = 0; i < 3; i++) {
		for(j = 0; j < pp->HAA1->dimX; j++) {
			pp->H_A_Alpha1[i][j] /= pp->norme ;
			pp->H_A_Alpha2[i][j] /= pp->norme ;
		}
		fwrite(pp->H_A_Alpha1[i], sizeof(float), pp->HAA1->dimX, pp->HAA1->f[i]) ;
		fwrite(pp->H_A_Alpha2[i], sizeof(float), pp->HAA2->dimX, pp->HAA2->f[i]) ;
		fflush(pp->HAA1->f[i]) ;
		fflush(pp->HAA2->f[i]) ;
	}

}


void movingAverageOnModuleImages(cohOpt *pp)
{
	int		i, j ;

	for(j = 0; j < pp->k1->aoi->dimX; j++) {
		pp->mod[j] = modC(pp->k1->HH[j]) ;
	}
    addNextLineInMovingAverage(pp->mod, pp->movingAverageOnModules[1][1]) ;

    for(j = 0; j < pp->k1->aoi->dimX; j++) {
		pp->mod[j] = modC(pp->k1->VV[j]) ;
	}
    addNextLineInMovingAverage(pp->mod, pp->movingAverageOnModules[1][2]) ;

    for(j = 0; j < pp->k1->aoi->dimX; j++) {
		pp->mod[j] = modC(pp->k1->XX[j]) ;
	}
    addNextLineInMovingAverage(pp->mod, pp->movingAverageOnModules[1][3]) ;
	
	for(j = 0; j < pp->k2->aoi->dimX; j++) {
		pp->mod[j] = modC(pp->k2->HH[j]) ;
	}
    addNextLineInMovingAverage(pp->mod, pp->movingAverageOnModules[2][1]) ;

    for(j = 0; j < pp->k2->aoi->dimX; j++) {
		pp->mod[j] = modC(pp->k2->VV[j]) ;
	}
    addNextLineInMovingAverage(pp->mod, pp->movingAverageOnModules[2][2]) ;

    for(j = 0; j < pp->k2->aoi->dimX; j++) {
		pp->mod[j] = modC(pp->k2->XX[j]) ;
	}
    addNextLineInMovingAverage(pp->mod, pp->movingAverageOnModules[2][3]) ;
	
	if(pp->k1->currentLine >= pp->movingAverageY - 1) {
        for(i = 1; i<=2; i++) {
            for(j = 1; j<=3; j++) {
				getMovingAverage(pp->movingAverageOnModules[i][j]) ;
            }
        }
	}
	
}

void movingAverageOnOrbitalPhase(cohOpt *pp)
{	
	if(pp->computeOrbitalPhase)
		computeOrbitalPhaseLine(pp) ;
	else
		fread(pp->oph, sizeof(float), pp->orbitalPhase->dimX, pp->orbitalPhase->f[0]) ;
	
	addNextLineInMovingAverage(pp->oph, pp->movingAverageOnOrbitalPhase) ;
	if(pp->k1->currentLine >= pp->movingAverageY - 1) 
		getMovingAverage(pp->movingAverageOnOrbitalPhase) ;
}

void computeOrbitalPhaseLine(cohOpt *pp)
{
	int i, rangePosition, azimuthPosition ;
	
	azimuthPosition = pp->currentLine + pp->pInSAR->sup.Sbaz ;
	for(i = 0; i < pp->orbitalPhase->aoi->dimX; i++) {
		rangePosition = i + pp->pInSAR->sup.Sgra ;
		pp->oph[i] = orbitalPhaseAtPoint(rangePosition, azimuthPosition, pp->pInSAR) ;
	}
}

void boxAveragingOfModulesForIndex(int index, cohOpt *pp)
{
	int	reducedImageIndex ;
	
	reducedImageIndex = div(index, pp->boxAverageX).quot ;
	pp->modules1[0][reducedImageIndex] += ((float *)pp->movingAverageOnModules[1][1]->average)[index] ;
	pp->modules1[1][reducedImageIndex] += ((float *)pp->movingAverageOnModules[1][2]->average)[index] ;
	pp->modules1[2][reducedImageIndex] += ((float *)pp->movingAverageOnModules[1][3]->average)[index] ;
	pp->modules2[0][reducedImageIndex] += ((float *)pp->movingAverageOnModules[2][1]->average)[index] ;
	pp->modules2[1][reducedImageIndex] += ((float *)pp->movingAverageOnModules[2][2]->average)[index] ;
	pp->modules2[2][reducedImageIndex] += ((float *)pp->movingAverageOnModules[2][3]->average)[index] ;
}

void saveModules(cohOpt *pp)
{
	int	i, j ;
	
	for(i = 0; i < 3; i++) {
		for(j = 0; j < pp->moduleImages1->dimX; j++) {
			pp->modules1[i][j] /= pp->norme ;
			pp->modules2[i][j] /= pp->norme ;
		}
		fwrite(pp->modules1[i], sizeof(float), pp->moduleImages1->dimX, pp->moduleImages1->f[i]) ;
		fwrite(pp->modules2[i], sizeof(float), pp->moduleImages2->dimX, pp->moduleImages2->f[i]) ;
		fflush(pp->moduleImages1->f[i]) ;
		fflush(pp->moduleImages2->f[i]) ;
	}

}


void printfMatriceDouble(double **M)
{
    int	i, j ;
    
    printf("\n[") ;
    for(i = 1; i <= 3; i++) {
        for(j = 1; j <=3; j++) {
            printf("%10.7g", M[i][j]) ;
            if(j<3) printf("\t") ;
        }
        if(i<3) printf("  \n") ;
    }
    printf("]\n") ;
}


void printfMatrice(complexFloat **M)
{
    int	i, j ;
    
    printf("\n[") ;
    for(i = 1; i <= 3; i++) {
        for(j = 1; j <=3; j++) {
            printf("%10.7g + i*%10.7g", M[i][j].r, M[i][j].i) ;
            if(j<3) printf("\t") ;
        }
        if(i<3) printf("  \n") ;
    }
    printf("]\n") ;
}


void invert3X3Matrix(complexFloat **M, complexFloat **iM)
{
	int	i, j ;
	complexFloat	det ;

	
	iM[1][1] = sC(mC(M[2][2], M[3][3]), mC(M[3][2], M[2][3])) ;
	iM[1][2] = sC(mC(M[3][2], M[1][3]), mC(M[1][2], M[3][3])) ;
	iM[1][3] = sC(mC(M[1][2], M[2][3]), mC(M[2][2], M[1][3])) ;

	iM[2][1] = sC(mC(M[3][1], M[2][3]), mC(M[2][1], M[3][3])) ;
	iM[2][2] = sC(mC(M[1][1], M[3][3]), mC(M[3][1], M[1][3])) ;
	iM[2][3] = sC(mC(M[2][1], M[1][3]), mC(M[1][1], M[2][3])) ;

	iM[3][1] = sC(mC(M[2][1], M[3][2]), mC(M[3][1], M[2][2])) ;
	iM[3][2] = sC(mC(M[3][1], M[1][2]), mC(M[1][1], M[3][2])) ;
	iM[3][3] = sC(mC(M[1][1], M[2][2]), mC(M[2][1], M[1][2])) ;
	
	det = aC(aC(mC(M[1][1], iM[1][1]), mC(M[1][2], iM[2][1])), mC(M[1][3], iM[3][1])) ;
	det = mRC(cC(det), 1./sqmC(det)) ;
	
	for(i = 1; i <= 3; i++) {
		for(j = 1; j <= 3; j++) {
			iM[i][j] = divC(iM[i][j], det) ;
		}
	}
}


void invert3X3HMatrix(complexFloat **M, complexFloat **iM)
{
	int	i, j ;
	double	det ;

	
	iM[1][1].r = M[2][2].r * M[3][3].r - sqmC(M[2][3]) ;
	iM[1][2] = sC(mC(cC(M[2][3]), M[1][3]), mRC(M[1][2], M[3][3].r)) ;
	iM[1][3] = sC(mC(M[1][2], M[2][3]), mRC(M[1][3], M[2][2].r)) ;

	iM[2][1] = cC(iM[1][2]) ;
	iM[2][2].r =M[1][1].r * M[3][3].r - sqmC(M[1][3]) ;
	iM[2][3] = sC(mC(cC(M[1][2]), M[1][3]), mRC(M[2][3], M[1][1].r)) ;

	iM[3][1] = cC(iM[1][3]) ;
	iM[3][2] = cC(iM[2][3]) ;
	iM[3][3].r = M[1][1].r * M[2][2].r - sqmC(M[1][2]) ;
	
	iM[1][1].i = iM[2][2].i = iM[3][3].i = 0. ;
	
	det =    M[1][1].r *  M[2][2].r *  M[3][3].r 
		  - (M[1][1].r * sqmC(M[2][3]) + M[2][2].r * sqmC(M[1][3]) + M[3][3].r * sqmC(M[1][2])) 
		  +  2. * mC(mC(M[1][2], M[2][3]), cC(M[1][3])).r ;
   
	det = 1. / det ;
    
	for(i = 1; i <= 3; i++) {
		for(j = 1; j <= 3; j++) {
			iM[i][j] = mRC(iM[i][j], det) ;
		}
	}
}

void addRandEpsilonTo3X3MatrixElement(complexFloat **M)
{
	int i ;
	float trace = 0. ;
	float my_rand, epsilon ;

	for(i = 1; i <= 3; i++) trace += M[i][i].r ;
    trace *= 1.0e-6 ;
    
	epsilon = trace * 1.e-6 + eps ;
	
	my_rand = (float)rand() / RAND_MAX * 2. ; M[1][1].r += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[1][1].i += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[1][2].r += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[1][2].i += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[1][3].r += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[1][3].i += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[2][1].r += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[2][1].i += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[2][2].r += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[2][2].i += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[2][3].r += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[2][3].i += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[3][1].r += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[3][1].i += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[3][2].r += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[3][2].i += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[3][3].r += epsilon * my_rand ;
	my_rand = (float)rand() / RAND_MAX * 2. ; M[3][3].i += epsilon * my_rand ;
}

/*******************************************************************************
Routine  : cplx_diag_mat3
Authors  : Laurent FERRO-FAMIL
Creation : 08/2005
Update   :
*-------------------------------------------------------------------------------
Description :  Computes the eigenvectors and eigenvalues of a 3*3 hermitian
matrix (literal expressions)
*-------------------------------------------------------------------------------
Inputs arguments :
T : 3*3 complex hermitian matrix
Returned values  :
V : 3*3 complex eigenvector matrix
L : 3 elements eigenvalue real vector
*******************************************************************************/
void cplx_diag_mat3(complexFloat **T, complexFloat **V, float *L)
{
float my_rand,ep2,p2,n,mod,ang,tmp;
complexFloat  z1,z2,z3,z1p,z2p,z3p,tra,tmpc,tmpc1,tmpc2,tmpc3,tmpc4,tmpc5,tmpc6;
complexFloat  fac0,fac1,fac2,fac3,v1,v2,v3,tr3,pt3,s1,s2,deta;
complexFloat  e1,e2,e3,a,b,c;

/*coherency matrix is [a z1 z2;conj(z1) b z3;conj(z2) conj(z3) c]
but each element a b c etc can be an m x n array i.e  an image
or part of an image*/

ep2=(T[1][1].r+T[2][2].r+T[3][3].r)*1e-6+eps;

my_rand = (float)rand()/RAND_MAX*2; z1.r=T[1][2].r+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; z1.i=T[1][2].i+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; z1p.r=T[2][1].r+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; z1p.i=T[2][1].i+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; z2.r=T[1][3].r+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; z2.i=T[1][3].i+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; z2p.r=T[3][1].r+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; z2p.i=T[3][1].i+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; z3.r=T[2][3].r+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; z3.i=T[2][3].i+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; z3p.r=T[3][2].r+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; z3p.i=T[3][2].i+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; a.r=T[1][1].r+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; a.i=T[1][1].i+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; b.r=T[2][2].r+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; b.i=T[2][2].i+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; c.r=T[3][3].r+ep2*my_rand;
my_rand = (float)rand()/RAND_MAX*2; c.i=T[3][3].i+ep2*my_rand;

tra.r=(a.r+b.r+c.r)/3;
tra.i=(a.i+b.i+c.i)/3;

fac0.r=z1.r*z1p.r-z1.i*z1p.i+z2.r*z2p.r-z2.i*z2p.i+z3.r*z3p.r-z3.i*z3p.i;

fac0.i=z1.r*z1p.i+z1.i*z1p.r+z2.r*z2p.i+z2.i*z2p.r+z3.r*z3p.i+z3.i*z3p.r;

tmpc1 = mC(a,b);
tmpc2 = mC(a,c);
tmpc3 = mC(b,c);
s1.r=tmpc1.r+tmpc2.r+tmpc3.r-fac0.r;
s1.i=tmpc1.i+tmpc2.i+tmpc3.i-fac0.i;

tmpc1 = mC(z1,z1p);tmpc1 = mC(c,tmpc1);
tmpc2 = mC(z2,z2p);tmpc2 = mC(b,tmpc2);
tmpc3 = mC(z3,z3p);tmpc3 = mC(a,tmpc3);
tmpc4 = mC(z1,z2p);tmpc4 = mC(tmpc4,z3);
tmpc5 = mC(z1p,z2);tmpc5 = mC(tmpc5,z3p);
tmpc4.r += tmpc5.r; tmpc4.i += tmpc5.i; 
tmpc5 = mC(a,b); tmpc5 = mC(tmpc5,c);

deta.r=tmpc5.r-tmpc1.r-tmpc2.r+tmpc4.r-tmpc3.r;
deta.i=tmpc5.i-tmpc1.i-tmpc2.i+tmpc4.i-tmpc3.i;

tmpc1 = mC(a,a);
tmpc2 = mC(a,b);
tmpc3 = mC(b,b);
tmpc4 = mC(a,c);
tmpc5 = mC(b,c);
tmpc6 = mC(c,c);
s2.r=tmpc1.r-tmpc2.r+tmpc3.r-tmpc4.r-tmpc5.r+tmpc6.r+3*fac0.r;
s2.i=tmpc1.i-tmpc2.i+tmpc3.i-tmpc4.i-tmpc5.i+tmpc6.i+3*fac0.i;

tmpc1 = mC(s1,tra);
tmpc2 = mC(tra,tra);tmpc2 = mC(tra,tmpc2);
fac1.r=27*deta.r-27*tmpc1.r+54*tmpc2.r;
fac1.i=27*deta.i-27*tmpc1.i+54*tmpc2.i;

tmpc1 = mC(fac1,fac1);
tmpc2 = mC(s2,s2);tmpc2 = mC(s2,tmpc2);
tmpc3.r = tmpc1.r-4*tmpc2.r;tmpc3.i = tmpc1.i-4*tmpc2.i;
mod = sqrt(tmpc3.r*tmpc3.r+tmpc3.i*tmpc3.i);
ang = atan2(tmpc3.i,tmpc3.r);

tr3.r=fac1.r+sqrt(mod)*cos(ang/2.);
tr3.i=fac1.i+sqrt(mod)*sin(ang/2.);

mod = sqrt(tr3.r*tr3.r+tr3.i*tr3.i);
ang = atan2(tr3.i,tr3.r);

pt3.r=pow(mod,1./3.)*cos(ang/3.);pt3.i=pow(mod,1./3.)*sin(ang/3.);
p2 = pow(2.,1./3.);

fac2.r=1;fac2.i=sqrt(3);
fac3.r=1;fac3.i=-sqrt(3);

tmpc1.r = s2.r*p2+eps;tmpc1.i = s2.i*p2+eps;
tmpc2.r = 3*pt3.r+eps;tmpc2.i = 3*pt3.i+eps; 
tmpc1 = divC(tmpc1,tmpc2);
e1.r = tra.r+pt3.r/(3*p2)+tmpc1.r;
e1.i = tra.i+pt3.i/(3*p2)+tmpc1.i;

tmpc1 = mC(fac2,s2);
tmpc2.r = 3*pt3.r*p2*p2+eps ;tmpc2.i = 3*pt3.i*p2*p2+eps ;
tmpc1 = divC(tmpc1,tmpc2);
tmpc2 = mC(fac3,pt3);
tmpc3.r = tmpc2.r/(6*p2+eps); tmpc3.i = tmpc2.i/(6*p2+eps); 
e2.r = tra.r-tmpc1.r-tmpc3.r;
e2.i = tra.i-tmpc1.i-tmpc3.i;

tmpc1 = mC(fac3,s2);
tmpc2.r = 3*pt3.r*p2*p2+eps ;tmpc2.i = 3*pt3.i*p2*p2+eps ;
tmpc1 = divC(tmpc1,tmpc2);
tmpc2 = mC(fac2,pt3);
tmpc3.r = tmpc2.r/(6*p2+eps); tmpc3.i = tmpc2.i/(6*p2+eps);
e3.r = tra.r-tmpc1.r-tmpc3.r;
e3.i = tra.i-tmpc1.i-tmpc3.i;

L[1]=sqrt(e1.r*e1.r+e1.i*e1.i);
L[2]=sqrt(e2.r*e2.r+e2.i*e2.i);
L[3]=sqrt(e3.r*e3.r+e3.i*e3.i);

    
/*sorting of eigenvalues by amplitude*/

if(L[2]>L[1])
{
 tmp = L[1]; L[1] = L[2]; L[2] = tmp;
}   
if(L[3]>L[1])
{
 tmp = L[1]; L[1] = L[3]; L[3] = tmp;
}   
if(L[3]>L[2])
{
 tmp = L[2]; L[2] = L[3]; L[3] = tmp;
}   

/*biggest eigenvector*/
tmpc1.r = b.r-L[1];tmpc1.i = b.i;
tmpc1 = mC(tmpc1,z2);
tmpc2.r = a.r-L[1];tmpc2.i = a.i;
tmpc2 = mC(tmpc2,z3);

tmpc.r = tmpc1.r-(z1.r*z3.r-z1.i*z3.i);
tmpc.i = tmpc1.i-(z3.r*z1.i+z3.i*z1.r);
v2.r=tmpc2.r-(z1p.r*z2.r-z1p.i*z2.i);
v2.i=tmpc2.i-(z1p.r*z2.i+z1p.i*z2.r);
v2=divC(v2,tmpc);
v1.r = 1; v1.i = 0;
v3.r=(L[1]-a.r-(z1.r*v2.r-z1.i*v2.i));
v3.i=-a.i-(z1.r*v2.i+z1.i*v2.r);
v3=divC(v3,z2);

n=sqrt(v1.r*v1.r+v1.i*v1.i+v2.r*v2.r+v2.i*v2.i+v3.r*v3.r+v3.i*v3.i);

V[1][1].r=v1.r/(n+eps);V[1][1].i=v1.i/(n+eps);
V[2][1].r=v2.r/(n+eps);V[2][1].i=v2.i/(n+eps);
V[3][1].r=v3.r/(n+eps);V[3][1].i=v3.i/(n+eps);

/*second eigenvector*/

tmpc1.r = b.r-L[2];tmpc1.i = b.i;
tmpc1 = mC(tmpc1,z2);
tmpc2.r = a.r-L[2];tmpc2.i = a.i;
tmpc2 = mC(tmpc2,z3);

tmpc.r = tmpc1.r-(z1.r*z3.r-z1.i*z3.i);
tmpc.i = tmpc1.i-(z3.r*z1.i+z3.i*z1.r);
v2.r=tmpc2.r-(z1p.r*z2.r-z1p.i*z2.i);
v2.i=tmpc2.i-(z1p.r*z2.i+z1p.i*z2.r);
v2=divC(v2,tmpc);
v1.r = 1; v1.i = 0;
v3.r=(L[2]-a.r-(z1.r*v2.r-z1.i*v2.i));
v3.i=-a.i-(z1.r*v2.i+z1.i*v2.r);
v3=divC(v3,z2);

n=sqrt(v1.r*v1.r+v1.i*v1.i+v2.r*v2.r+v2.i*v2.i+v3.r*v3.r+v3.i*v3.i);

V[1][2].r=v1.r/(n+eps);V[1][2].i=v1.i/(n+eps);
V[2][2].r=v2.r/(n+eps);V[2][2].i=v2.i/(n+eps);
V[3][2].r=v3.r/(n+eps);V[3][2].i=v3.i/(n+eps);

/*smallest eigenvector*/

tmpc1.r = b.r-L[3];tmpc1.i = b.i;
tmpc1 = mC(tmpc1,z2);
tmpc2.r = a.r-L[3];tmpc2.i = a.i;
tmpc2 = mC(tmpc2,z3);

tmpc.r = tmpc1.r-(z1.r*z3.r-z1.i*z3.i);
tmpc.i = tmpc1.i-(z3.r*z1.i+z3.i*z1.r);
v2.r=tmpc2.r-(z1p.r*z2.r-z1p.i*z2.i);
v2.i=tmpc2.i-(z1p.r*z2.i+z1p.i*z2.r);
v2=divC(v2,tmpc);
v1.r = 1; v1.i = 0;
v3.r=(L[3]-a.r-(z1.r*v2.r-z1.i*v2.i));
v3.i=-a.i-(z1.r*v2.i+z1.i*v2.r);
v3=divC(v3,z2);

n=sqrt(v1.r*v1.r+v1.i*v1.i+v2.r*v2.r+v2.i*v2.i+v3.r*v3.r+v3.i*v3.i);

V[1][3].r=v1.r/(n+eps);V[1][3].i=v1.i/(n+eps);
V[2][3].r=v2.r/(n+eps);V[2][3].i=v2.i/(n+eps);
V[3][3].r=v3.r/(n+eps);V[3][3].i=v3.i/(n+eps);

}
