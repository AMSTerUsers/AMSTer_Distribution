
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  matrixObjects.c
 *  fluxOptimization
 *
 *  Created by Dominique Derauw on 24/01/12.
 *  Copyright 2012 Dominique Derauw. All rights reserved.
 *
 */

#include "matrixObjects.h"

/* Matrix object routines */ 

matrixObject *allocMatrixObjectofTypeWithIndexes(int unsigned type, int rowLowerIndex, int rowUpperIndex, int columnLowerIndex, int columnUpperIndex)
{
	int	iX, iY ;
	matrixObject *aMatrix ;
	
	if((aMatrix = malloc(sizeof(matrixObject))) == NULL) 
		perror("Failed to allocate a floatMatrix") ;
	
	aMatrix->matrixID = NULL ;
	aMatrix->histo = NULL ;
	aMatrix->mf = NULL ;
	aMatrix->md = NULL ;
	aMatrix->m = NULL;
	aMatrix->rowLowerIndex = rowLowerIndex ;
	aMatrix->rowUpperIndex = rowUpperIndex ;
	aMatrix->columnLowerIndex = columnLowerIndex ;
	aMatrix->columnUpperIndex = columnUpperIndex ;
	
	aMatrix->xDim = columnUpperIndex - columnLowerIndex + 1 ;
	aMatrix->yDim = rowUpperIndex - rowLowerIndex + 1 ;
	aMatrix->histMin = 0. ;
	aMatrix->histMax = 0. ;
	aMatrix->histBins = 256 ;
	aMatrix->noVal = -9999. ;
	aMatrix->frame = NULL ;
	
	if (type == _REAL32_ID_) {
		aMatrix->matrixType = _REAL32_ID_ ;
		aMatrix->mf = matrixFloat(rowLowerIndex, rowUpperIndex, columnLowerIndex, columnUpperIndex) ;
		for (iY = rowLowerIndex; iY <= rowUpperIndex; iY++) {
			for (iX = columnLowerIndex; iX <= columnUpperIndex; iX++) {
				aMatrix->mf[iY][iX] = 0. ;
			}
		}
		aMatrix->m = (void **)aMatrix->mf ;
	}
	
	if (type == _REAL64_ID_) {
		aMatrix->matrixType = _REAL64_ID_ ;
		aMatrix->md = matrixDouble(rowLowerIndex, rowUpperIndex, columnLowerIndex, columnUpperIndex) ;
		for (iY = rowLowerIndex; iY <= rowUpperIndex; iY++) {
			for (iX = columnLowerIndex; iX <= columnUpperIndex; iX++) {
				aMatrix->md[iY][iX] = 0. ;
			}
		}
		aMatrix->m = (void **)aMatrix->md ;
	}
	

	return(aMatrix) ;
}

floatMatrix *allocFloatMatrixWithIndexes(int rowLowerIndex, int rowUpperIndex, int columnLowerIndex, int columnUpperIndex)
{
	floatMatrix *aFloatMatrix ;
	
	aFloatMatrix = allocMatrixObjectofTypeWithIndexes(_REAL32_ID_, rowLowerIndex, rowUpperIndex, columnLowerIndex, columnUpperIndex) ;
	
	return(aFloatMatrix) ;
}

void freeMatrixObject(matrixObject *aMatrix)
{
	if (!aMatrix) {
		return ;
	}
	
	if(aMatrix->matrixID) {
		free(aMatrix->matrixID) ;
	}

	if (aMatrix->histo) {
		free(aMatrix->histo) ;
	}
	
	if (aMatrix->mf) {
        freeMatrixFloat(aMatrix->mf, aMatrix->rowLowerIndex, aMatrix->columnLowerIndex) ;
    }

	if (aMatrix->md) {
        freeMatrixDouble(aMatrix->md, aMatrix->rowLowerIndex, aMatrix->columnLowerIndex) ;
    }

	if (aMatrix->frame) {
		free(aMatrix->frame) ;
	}
	
	free(aMatrix) ;


}

void freeFloatMatrix(floatMatrix *aFloatMatrix)
{
	freeMatrixObject(aFloatMatrix) ;
}


/* Computes basic stats on float matrix: histo, min, max, mean, sigma, centre of mass, integral*/
/* If floatMatrix histBins set to zero, histo is not calculated */
void statMatWithHistoInterval(floatMatrix *aMatrix, float histMin, float histMax, int histBins)
{	
	aMatrix->histMin = histMin ;
	aMatrix->histMax = histMax ;
	aMatrix->histBins = histBins ;
	
	statMat(aMatrix) ;
}

/* Computes basic stats on float matrix: histo, min, max, mean, sigma, centre of mass, integral*/
/* If floatMatrix histBins previously set to zero, histo is not calculated */
void statMat(matrixObject *aMatrix)
{
	int iX, iY, anIndex ;
	float aFloatVal ;
	double aDoubleVal, Sx2 ;

	if(aMatrix->histo) {
		freeVectorInt(aMatrix->histo, 0) ;
	}
	aMatrix->histo= vectorInt(0, aMatrix->histBins - 1) ;
	for(iX = 0; iX < aMatrix->histBins; iX++) {
		aMatrix->histo[iX] = 0 ;
	}

	aMatrix->minValXIndex = aMatrix->maxValXIndex = aMatrix->columnLowerIndex - 1 ;
	aMatrix->minValYIndex = aMatrix->maxValYIndex = aMatrix->rowLowerIndex - 1 ;
	anIndex = 0 ;
	if (aMatrix->histBins) {
		if(!aMatrix->histMin && !aMatrix->histMax) {
			if (aMatrix->matrixType == _REAL32_ID_) {
				aDoubleVal = (double) *(aMatrix->mf[0]) ;
				while (aDoubleVal == aMatrix->noVal || isnan(aDoubleVal)) {
					anIndex++ ;
					aDoubleVal = (double) *(aMatrix->mf[0] + anIndex) ;
				}
				aMatrix->minVal = aMatrix->maxVal = aDoubleVal ;
				for(iY = aMatrix->rowLowerIndex; iY <= aMatrix->rowUpperIndex; iY++) {
					for(iX = aMatrix->columnLowerIndex; iX <= aMatrix->columnUpperIndex; iX++) {
						aDoubleVal = (double)aMatrix->mf[iY][iX] ;
						if(aDoubleVal != aMatrix->noVal && !isnan(aMatrix->mf[iY][iX])) {
							if(aMatrix->minVal >= aDoubleVal) {
								aMatrix->minVal = aDoubleVal ;
								aMatrix->minValXIndex = iX ; 
								aMatrix->minValYIndex = iY ;
							}
							if(aMatrix->maxVal <= aDoubleVal) {
								aMatrix->maxVal = aDoubleVal ;
								aMatrix->maxValXIndex = iX ; 
								aMatrix->maxValYIndex = iY ;
							}
						}
					}
				}
			}
			if (aMatrix->matrixType == _REAL64_ID_) {
				aDoubleVal = *(aMatrix->md[0]) ;
				while (aDoubleVal == aMatrix->noVal || isnan(aDoubleVal)) {
					anIndex++ ;
					aDoubleVal = *(aMatrix->md[0] + anIndex) ;
				}
				aMatrix->minVal = aMatrix->maxVal = aDoubleVal ;
				for(iY = aMatrix->rowLowerIndex; iY <= aMatrix->rowUpperIndex; iY++) {
					for(iX = aMatrix->columnLowerIndex; iX <= aMatrix->columnUpperIndex; iX++) {
						aDoubleVal = aMatrix->mf[iY][iX] ;
						if(aDoubleVal != aMatrix->noVal && !isnan(aDoubleVal)) {
							if(aMatrix->minVal >= aDoubleVal) {
								aMatrix->minVal = aDoubleVal ;
								aMatrix->minValXIndex = iX ; 
								aMatrix->minValYIndex = iY ;
							}
							if(aMatrix->maxVal <= aDoubleVal) {
								aMatrix->maxVal = aDoubleVal ;
								aMatrix->maxValXIndex = iX ; 
								aMatrix->maxValYIndex = iY ;
							}
						}
					}
				}
			}

			aMatrix->histMin = aMatrix->minVal ;
			aMatrix->histMax = aMatrix->maxVal ;
		}
		else {
			aMatrix->minVal = aMatrix->histMax ;
			aMatrix->maxVal = aMatrix->histMin ;
		}
	}
	else {
		aMatrix->histMax = aMatrix->minVal = __DBL_MAX__ ;
		aMatrix->histMin = aMatrix->maxVal = -__DBL_MAX__ ;
	}
	
	aMatrix->size = 0 ;
	aMatrix->integral = aMatrix->xC = aMatrix->yC = Sx2 = 0. ;
	for(iY = aMatrix->rowLowerIndex; iY <= aMatrix->rowUpperIndex; iY++) {
		for(iX = aMatrix->columnLowerIndex; iX <= aMatrix->columnUpperIndex; iX++) {
			if (aMatrix->matrixType == _REAL32_ID_) {
				aDoubleVal = (double) aMatrix->mf[iY][iX] ;
				if((aDoubleVal >= aMatrix->histMin) && (aDoubleVal <= aMatrix->histMax) && aDoubleVal != aMatrix->noVal && !isnan(aDoubleVal)) {
					Sx2 += pow(aDoubleVal, 2) ;
					aMatrix->integral += aDoubleVal ;
					aMatrix->xC += iX * aDoubleVal ;
					aMatrix->yC += iY * aDoubleVal ;
					if(aMatrix->minVal > aDoubleVal) {
						aMatrix->minVal = aDoubleVal ;
						aMatrix->minValXIndex = iX ; 
						aMatrix->minValYIndex = iY ;
					}
					if(aMatrix->maxVal < aDoubleVal) {
						aMatrix->maxVal = aDoubleVal ;
						aMatrix->maxValXIndex = iX ; 
						aMatrix->maxValYIndex = iY ;
					}
					aFloatVal = aMatrix->histBins * (aDoubleVal - aMatrix->histMin) / (aMatrix->histMax - aMatrix->histMin) ;
					if (aMatrix->histBins) {
						anIndex = (aMatrix->histMax == aMatrix->histMin)? 0 : (int)floorf(aFloatVal) ;
						if(anIndex == aMatrix->histBins) 
							anIndex-- ;
						aMatrix->histo[anIndex]++ ;
					}
					
					aMatrix->size++ ;
				}
			}
			if (aMatrix->matrixType == _REAL64_ID_) {
				aDoubleVal = aMatrix->md[iY][iX] ;
				if((aDoubleVal >= aMatrix->histMin) && (aDoubleVal <= aMatrix->histMax) && aDoubleVal != aMatrix->noVal && !isnan(aDoubleVal)) {
					Sx2 += pow(aDoubleVal, 2) ;
					aMatrix->integral += aDoubleVal ;
					aMatrix->xC += iX * aDoubleVal ;
					aMatrix->yC += iY * aDoubleVal ;
					if(aMatrix->minVal > aDoubleVal) {
						aMatrix->minVal = aDoubleVal ;
						aMatrix->minValXIndex = iX ; 
						aMatrix->minValYIndex = iY ;
					}
					if(aMatrix->maxVal < aDoubleVal) {
						aMatrix->maxVal = aDoubleVal ;
						aMatrix->maxValXIndex = iX ; 
						aMatrix->maxValYIndex = iY ;
					}
					aFloatVal = aMatrix->histBins * (aDoubleVal - aMatrix->histMin) / (aMatrix->histMax - aMatrix->histMin) ;
					if (aMatrix->histBins) {
						anIndex = (aMatrix->histMax == aMatrix->histMin)? 0 : (int)floorf(aFloatVal) ;
						if(anIndex == aMatrix->histBins) 
							anIndex-- ;
						aMatrix->histo[anIndex]++ ;
					}
					
					aMatrix->size++ ;
				}
			}
		}
	}
	aMatrix->xC /= aMatrix->integral ;
	aMatrix->yC /= aMatrix->integral ;

	aMatrix->average = (aMatrix->size)? aMatrix->integral / aMatrix->size : aMatrix->integral;
	aMatrix->standardDeviation = (aMatrix->size)? sqrt((Sx2 - aMatrix->size * powf(aMatrix->average, 2.)) / (aMatrix->size - 1)) : 0 ;
	
	aMatrix->mostPopulatedBin = anIndex = 0 ;
	for(iX = 0; iX < aMatrix->histBins; iX++) {
		if(anIndex < aMatrix->histo[iX]) {
			anIndex = aMatrix->histo[iX] ;
			aMatrix->mostPopulatedBin = iX ;
		}
	}
}

void setFrameOfFloatMatrix(float xMinVal, float yMinVal, float xMaxVal, float yMaxVal, floatMatrix *M)
{
	if (M->frame == NULL) {
		if((M->frame = malloc(sizeof(rectangleType))) == NULL) {
			ase("Failed to allocate rectangle frame for float matrix object") ;
		}
	}
	
	M->frame->xMin = xMinVal ;
	M->frame->yMin = yMinVal ;
	M->frame->xMax = xMaxVal ;
	M->frame->yMax = yMaxVal ;
}


coord2D getPointFromPixelCoordInFloatMatrix(int iX, int iY, floatMatrix *M)
{
    coord2D aPoint ;

	if (M->frame) {	
    aPoint.x = M->frame->xMin + (iX - M->rowLowerIndex) * (M->frame->xMax - M->frame->xMin) / (M->rowUpperIndex - M->rowLowerIndex) ; 
    aPoint.y = M->frame->yMin + (iY - M->columnLowerIndex) * (M->frame->yMax - M->frame->yMin) / (M->columnUpperIndex - M->columnLowerIndex) ;
	}

    return(aPoint) ;
}


/* Float vector routines */
floatVector *allocFloatVectorWithIndexes(int lowerIndex, int upperIndex)
{
	floatVector *aFloatVector ;

	aFloatVector = allocFloatVector() ;
	aFloatVector->v = vectorFloat(lowerIndex, upperIndex) ;
	aFloatVector->lowerIndex = lowerIndex ;
	aFloatVector->upperIndex = upperIndex ;
	aFloatVector->xDim = upperIndex - lowerIndex + 1 ;

	return(aFloatVector) ;

}

floatVector *allocFloatVector(void) 
{
	floatVector *aFloatVector ;
	
	if((aFloatVector = malloc(sizeof(floatVector))) == NULL) 
		perror("Failed to allocate a aFloatVector") ;
	
	aFloatVector->ID = NULL ;
	aFloatVector->histo = NULL ;
	aFloatVector->v = NULL ;
	
	aFloatVector->histMin = 0. ;
	aFloatVector->histMax = 0. ;
	aFloatVector->histBins = 256 ;
	aFloatVector->noVal = -9999. ;
	
	return(aFloatVector) ;
}
void freeFloatVector(floatVector *aFloatVector)
{
	if(aFloatVector->ID != NULL) {
		free(aFloatVector->ID) ;
	}
	free(aFloatVector->histo) ;
    if (aFloatVector->v) {
        freeVectorFloat(aFloatVector->v, aFloatVector->lowerIndex) ;
    }
	
	free(aFloatVector) ;
}


void statOnVectorFloatWithHistoInterval(floatVector *aFloatVector, float histMin, float histMax, int histBins)
{	
	aFloatVector->histMin = histMin ;
	aFloatVector->histMax = histMax ;
	aFloatVector->histBins = histBins ;
	
	statOnVectorFloat(aFloatVector) ;
}



void statOnVectorFloat(floatVector *aFloatVector)
{
	int iX, anIndex ;
	float aFloatVal, Sx2 ;

	genFloatInf() ;

	if(aFloatVector->histo != NULL) {
		freeVectorInt(aFloatVector->histo, 0) ;
	}

	aFloatVector->histo = vectorInt(0, aFloatVector->histBins - 1) ;
	for(iX = 0; iX < aFloatVector->histBins; iX++) {
		aFloatVector->histo[iX] = 0 ;
	}

	ascendingSort(aFloatVector->xDim, aFloatVector->v - 1) ;

	aFloatVector->minValXIndex = aFloatVector->maxValXIndex = aFloatVector->lowerIndex - 1 ;
	anIndex = aFloatVector->lowerIndex ;
	aFloatVector->minVal = aFloatVector->histMax ;
	aFloatVector->maxVal = aFloatVector->histMin ;

	if(!aFloatVector->histMin && !aFloatVector->histMax) {
		while (anIndex < aFloatVector->upperIndex && (aFloatVector->v[anIndex] == aFloatVector->noVal || isnan(aFloatVector->v[anIndex]))) {
			anIndex++ ;
		}
		anIndex += (aFloatVector->v[anIndex] == aFloatVector->noVal || isnan(aFloatVector->v[anIndex]))? 1 : 0 ;
		
		if (anIndex  <= aFloatVector->upperIndex) {
			aFloatVector->minVal = aFloatVector->maxVal = aFloatVector->v[anIndex] ;
			for(iX = aFloatVector->lowerIndex; iX <= aFloatVector->upperIndex; iX++) {
				if(aFloatVector->v[iX] != aFloatVector->noVal && !isnan(aFloatVector->v[iX]) && !isinf(aFloatVector->v[iX])) {
					if(aFloatVector->minVal >= aFloatVector->v[iX]) {
						aFloatVector->minVal = aFloatVector->v[iX] ;
						aFloatVector->minValXIndex = iX ; 
					}
					if(aFloatVector->maxVal <= aFloatVector->v[iX]) {
						aFloatVector->maxVal = aFloatVector->v[iX] ;
						aFloatVector->maxValXIndex = iX ; 
					}
				}
			}
		}
		aFloatVector->histMin = aFloatVector->minVal ;
		aFloatVector->histMax = aFloatVector->maxVal ;
	}
	
	aFloatVector->size = 0 ;
	aFloatVector->integral = aFloatVector->xC = Sx2 = 0. ;
	for(iX = aFloatVector->lowerIndex; iX <= aFloatVector->upperIndex; iX++) {
		if((aFloatVector->v[iX] >= aFloatVector->histMin) && (aFloatVector->v[iX] <= aFloatVector->histMax) && aFloatVector->v[iX] != aFloatVector->noVal && !isnan(aFloatVector->v[iX])) {
			aFloatVal = aFloatVector->histBins * (aFloatVector->v[iX] - aFloatVector->histMin) / (aFloatVector->histMax - aFloatVector->histMin) ;
			if (!isnan(aFloatVal) && !isinf(aFloatVal)) {
				Sx2 += pow(aFloatVector->v[iX], 2) ;
				aFloatVector->integral += aFloatVector->v[iX] ;
				aFloatVector->xC += iX * aFloatVector->v[iX] ;
				if(aFloatVector->minVal > aFloatVector->v[iX]) {
					aFloatVector->minVal = aFloatVector->v[iX] ;
					aFloatVector->minValXIndex = iX ; 
				}
				if(aFloatVector->maxVal < aFloatVector->v[iX]) {
					aFloatVector->maxVal = aFloatVector->v[iX] ;
					aFloatVector->maxValXIndex = iX ; 
				}
				anIndex = (aFloatVector->histMax == aFloatVector->histMin)? 0 : (int)floorf(aFloatVal) ;
				if(anIndex == aFloatVector->histBins) {
					anIndex-- ;
				}
				aFloatVector->histo[anIndex]++ ;
				aFloatVector->size++ ;
			}
		}
	}
	aFloatVector->xC /= aFloatVector->integral ;
	aFloatVector->average = (aFloatVector->size)? aFloatVector->integral / aFloatVector->size : 0 ;
	anIndex = aFloatVector->xDim / 2 ;
	aFloatVector->median = aFloatVector->v[anIndex] ;
	if (2 * anIndex != aFloatVector->xDim) {
		aFloatVector->median += aFloatVector->v[++anIndex] ;
		aFloatVector->median /= 2. ;
	}
	
	
	aFloatVector->standardDeviation = sqrt(Sx2 / aFloatVector->size - pow(aFloatVector->average, 2.)) ;
	
	aFloatVector->mostPopulatedBin = anIndex = 0 ;
	for(iX = 0; iX < aFloatVector->histBins; iX++) {
		if(anIndex < aFloatVector->histo[iX]) {
			anIndex = aFloatVector->histo[iX] ;
			aFloatVector->mostPopulatedBin = iX ;
		}
	}
}



double **getMatrixDoubleOfMatrixObject(matrixObject *aMatrix) 
{
	int iX, iY ;
	
	if (aMatrix->matrixType == _REAL32_ID_ && !aMatrix->md) {
		aMatrix->md = matrixDouble(0, aMatrix->yDim - 1, 0, aMatrix->xDim - 1) ;
		for (iY = 0; iY < aMatrix->yDim; iY++) {
			for (iX = 0; iX < aMatrix->xDim; iX++) {
				aMatrix->md[iY][iX] = (double)aMatrix->mf[iY][iX] ;
			}
		}
	}

	return (aMatrix->md) ;
}


float **getMatrixFloatOfMatrixObject(matrixObject *aMatrix) 
{
	int iX, iY ;
	
	if (aMatrix->matrixType == _REAL64_ID_ && !aMatrix->mf) {
		aMatrix->mf = matrixFloat(0, aMatrix->yDim - 1, 0, aMatrix->xDim - 1) ;
		for (iY = 0; iY < aMatrix->yDim; iY++) {
			for (iX = 0; iX < aMatrix->xDim; iX++) {
				aMatrix->mf[iY][iX] = (float)aMatrix->md[iY][iX] ;
			}
		}
	}

	return (aMatrix->mf) ;
}