
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/* resmat.c */
/* Fonctions d'inversion matricielle et de résolution par substitution */

/* Routines de résolutions de systèmes d'équations linéaires extraites de:
   "Numerical recipes in C, The Art of Scientific Computing."
   William H. Press, Brian P. Flannery, Saul A. Teukolsky, William T. Vetterling.
   Cambridge University Press, 1988
*/

#include "pourtous.h"
#include "resmat.h"
#include "vectors.h"
#include "matrix.h"
#include "complexCalculus.h"


/* ----------------- Décomposition LU ----------------- */

void ludcmp(double **a, int n, int *indx, double *s)
{
    int	i, imax = 0, j, k ;
    double	big, dum, sum, temp ;
    double	*vv ;
    
    vv = vectorDouble(1,n) ;
    
    *s = 1. ;
    for (i=1; i<=n; i++)
    {
        big = 0.0 ;
        for (j=1; j<=n; j++)
        {
            if ((temp = fabs(a[i][j])) > big) big = temp;
        }
        if (big == 0.0)
            ase("Singular matrix in routine LUDCMP");
        vv[i] = 1.0/big ;
    }
    for (j=1; j<=n; j++) {
        for (i=1; i<j; i++) {
            sum = a[i][j] ;
            for (k=1; k<i; k++) sum -= a[i][k] * a[k][j] ;
            a[i][j] = sum ;
        }
        
        big = 0.0 ;
        for (i=j; i<=n; i++) {
            sum = a[i][j] ;
            for (k=1; k<j; k++)
                sum -= a[i][k]*a[k][j];
            
            a[i][j] = sum;
            if ( (dum=vv[i]*fabs(sum)) >= big) {
                big=dum ;
                imax=i;
            }
        }
        
        if (j != imax) {
            for (k=1; k<=n; k++) {
                dum = a[imax][k] ;
                a[imax][k] = a[j][k] ; 
                a[j][k] = dum ; 
            }
            *s = -(*s) ;
            vv[imax] = vv[j] ;
        }
        indx[j] = imax;
        
        if (a[j][j] == 0.0) a[j][j] = TINY; 
        if (j != n) {
            dum = 1.0/(a[j][j]); 
            for (i=j+1; i<=n; i++) a[i][j] *= dum ;
        }
    }
    freeVectorDouble(vv, 1);
}

complexFloat ** ludcmpComplexFloat(complexFloat **a, int n, int *indx, float *s)
{
    int	i, imax = 0, j, k ;
    float big, temp, dum ;
    complexFloat sum, tempC ;
    float	*vv ;
    
    vv = vectorFloat(1,n) ;
    
    *s = 1. ;
    for (i=1; i<=n; i++) {
        big = 0.0 ;
        for (j=1; j<=n; j++) {
            if ((temp = modC(a[i][j])) > big) big = temp;
        }
        
        if (big == 0.0) {
            return(NULL) ;
//            ase("Singular matrix in routine LUDCMP");
        }
        vv[i] = 1.0/big ;
    }
    
    for (j=1; j<=n; j++) {
        for (i=1; i<j; i++) {
            sum = a[i][j] ;
            for (k=1; k<i; k++)
                sum = sC(sum, mC(a[i][k], a[k][j])) ;
            a[i][j] = sum ;
        }
        
        big = 0.0 ;
        for (i=j; i<=n; i++) {
            sum = a[i][j] ;
            for (k=1; k<j; k++)
                sum = sC(sum, mC(a[i][k], a[k][j])) ;
            
            a[i][j] = sum;
            if ((dum = vv[i] * modC(sum)) >= big) {
                big=dum ;
                imax=i;
            }
        }
        
        if (j != imax) {
            for (k=1; k<=n; k++) {
                tempC = a[imax][k] ;
                a[imax][k] = a[j][k] ;
                a[j][k] = tempC ;
            }
            *s = -(*s) ;
            vv[imax] = vv[j] ;
        }
        indx[j] = imax;
        
        if (modC(a[j][j]) == 0.0) a[j][j].r = a[j][j].i = TINY;
        if (j != n)  {
            for (i=j+1; i<=n; i++) a[i][j] = divC(a[i][j], a[j][j]) ;
        }
    }
    freeVectorFloat(vv, 1);
    return(a) ;
}



void ludcmpComplexDouble(complexDouble **a, int n, int *indx, float *s)
{
    int	i, imax = 0, j, k ;
    double big, temp, dum ;
    complexDouble sum, tempC ;
    double	*vv ;
    
    vv = vectorDouble(1,n) ;
    
    *s = 1. ;
    for (i=1; i<=n; i++) {
        big = 0.0 ;
        for (j=1; j<=n; j++) {
            if ((temp = modComplexDouble(a[i][j])) > big) big = temp ;
        }
        
        if (big == 0.0)
            ase("Singular matrix in routine LUDCMP");
        vv[i] = 1.0/big ;
    }
    
    for (j=1; j<=n; j++) {
        for (i=1; i<j; i++) {
            sum = a[i][j] ;
            for (k=1; k<i; k++)
                sum = subtComplexDouble(sum, multComplexDouble(a[i][k], a[k][j])) ;
            a[i][j] = sum ;
        }
        
        big = 0.0 ;
        for (i=j; i<=n; i++) {
            sum = a[i][j] ;
            for (k=1; k<j; k++)
                sum = subtComplexDouble(sum, multComplexDouble(a[i][k], a[k][j])) ;
            
            a[i][j] = sum;
            if ((dum = vv[i] * modComplexDouble(sum)) >= big) {
                big=dum ;
                imax=i;
            }
        }
        
        if (j != imax) {
            for (k=1; k<=n; k++) {
                tempC = a[imax][k] ;
                a[imax][k] = a[j][k] ;
                a[j][k] = tempC ;
            }
            *s = -(*s) ;
            vv[imax] = vv[j] ;
        }
        indx[j] = imax;
        
        if (modComplexDouble(a[j][j]) == 0.0) a[j][j].r = a[j][j].i = TINY;
        if (j != n)  {
            for (i=j+1; i<=n; i++) a[i][j] = divComplexDouble(a[i][j], a[j][j]) ;
        }
    }
    freeVectorDouble(vv, 1);
}



/* ----------------- Résolution par substitution ----------------- */

void lubksb(double **a, int n, int *indx, double *b)
{
    int	i, ii=0, ip, j ;
    double	sum ;
    
    for (i=1; i<=n; i++)
    {
        ip=indx[i] ;
        sum=b[ip] ;
        b[ip] =b[i] ;
        if (ii)
            for (j =ii; j<=i-1; j++) sum -= a[i][j] * b[j] ;
        else if (sum) ii=i ;
        b[i]=sum ;
    }
    for (i=n; i>0; i--)
    {
        sum=b[i] ;
        for(j=i+1; j<=n; j++) sum -= a[i][j]*b[j] ; 
        b[i]=sum/a[i][i] ;
    }
}


void lubksbComplexFloat(complexFloat **a, int n, int *indx, complexFloat *b)
{
    int	i, ii=0, ip, j ;
    complexFloat	sum ;
    
    for (i=1; i<=n; i++)
    {
        ip=indx[i] ;
        sum=b[ip] ;
        b[ip] =b[i] ;
        if (ii)
            for (j =ii; j<=i-1; j++)
                sum = sC(sum, mC(a[i][j], b[j])) ;
        else if (modC(sum)) ii=i ;
        b[i]=sum ;
    }
    for (i=n; i>0; i--)
    {
        sum=b[i] ;
        for(j=i+1; j<=n; j++)
            sum = sC(sum, mC(a[i][j], b[j])) ;
        
        b[i]=divC(sum, a[i][i]) ;
    }
}


void lubksbComplexDouble(complexDouble **a, int n, int *indx, complexDouble *b)
{
    int	i, ii=0, ip, j ;
    complexDouble	sum ;
    
    for (i=1; i<=n; i++)
    {
        ip=indx[i] ;
        sum=b[ip] ;
        b[ip] =b[i] ;
        if (ii)
            for (j =ii; j<=i-1; j++)
                sum = subtComplexDouble(sum, multComplexDouble(a[i][j], b[j])) ;
        else if (modComplexDouble(sum)) ii=i ;
        b[i]=sum ;
    }
    for (i=n; i>0; i--)
    {
        sum=b[i] ;
        for(j=i+1; j<=n; j++)
            sum = subtComplexDouble(sum, multComplexDouble(a[i][j], b[j])) ;
        
        b[i]=divComplexDouble(sum, a[i][i]) ;
    }
}


void invertMatrixDouble(double **M, double ** iM, int rank)
{
    int *indx, i, j ;
    double sign, *col, **MM ;
    
    indx = vectorInt(1, rank) ;
    col = vectorDouble(1, rank) ;
    MM = matrixDouble(1, rank, 1, rank) ;
    memcpy(MM[1] + 1, M[1] + 1, rank * rank * sizeof(float)) ;
    
    ludcmp(MM, rank, indx, &sign) ;
    
    for(j = 1; j <= rank; j++) {
        for(i = 1; i <= rank; i++)
            col[i] = 0.0;
        col[j] = 1.0;
        
        lubksb(MM, rank, indx, col) ;
        for(i = 1; i <= rank; i++)
            iM[i][j] = col[i];
    }
    freeVectorInt(indx, 1) ;
    freeVectorDouble(col, 1) ;
    freeMatrixDouble(MM, 1, 1) ;
}

complexFloat **invertMatrixComplexFloat(complexFloat **M, complexFloat ** iM, int rank)
{
    int *indx, i, j ;
    float sign ;
    complexFloat *col, **MM ;
    
    MM = matrixComplexFloat(1, rank, 1, rank) ;
    memcpy(MM[1] + 1, M[1] + 1, rank * rank * sizeof(complexFloat)) ;
    indx = vectorInt(1, rank) ;
    
    if (ludcmpComplexFloat(MM, rank, indx, &sign)) {
        col = vectorComplexFloat(1, rank) ;
        for(j = 1; j <= rank; j++) {
            for(i = 1; i <= rank; i++)
                col[i].r = col[i].i = 0.0 ;
            col[j].r = 1.0 ;
            
            lubksbComplexFloat(MM, rank, indx, col) ;
            for(i = 1; i <= rank; i++)
                iM[i][j] = col[i];
        }
        freeVectorInt(indx, 1) ;
        freeVectorComplexFloat(col, 1) ;
        freeMatrixComplexFloat(MM, 1, 1) ;    

        return(iM) ;    
    }
    else {
        freeVectorInt(indx, 1) ;
        freeMatrixComplexFloat(MM, 1, 1) ;        
        return (NULL) ;
    }
    

}

void invertMatrixComplexFloatInDoublePrecision(complexFloat **M, complexFloat ** iM, int rank)
{
    int *indx, i, j ;
    float sign ;
    complexDouble *col, **MM ;
    
    indx = vectorInt(1, rank) ;
    col = vectorComplexDouble(1, rank) ;
    MM = matrixComplexDouble(1, rank, 1, rank) ;
    for(j = 1; j <= rank; j++) {
        for(i = 1; i <= rank; i++) {
            MM[i][j].r = (double)M[i][j].r ;
            MM[i][j].i = (double)M[i][j].i ;
        }
    }
    ludcmpComplexDouble(MM, rank, indx, &sign) ;
    
    for(j = 1; j <= rank; j++) {
        for(i = 1; i <= rank; i++)
            col[i].r = col[i].i = 0.0 ;
        col[j].r = 1.0 ;
        
        lubksbComplexDouble(MM, rank, indx, col) ;
        for(i = 1; i <= rank; i++) {
            iM[i][j].r = (float)col[i].r;
            iM[i][j].i = (float)col[i].i;
        }
    }
    freeVectorInt(indx, 1) ;
    freeVectorComplexDouble(col, 1) ;
    freeMatrixComplexDouble(MM, 1, 1) ;
}

/* Linear system resolution */
/* Solves a system of type M.X = V */
void linearSystemResolution(double **theMatrix, double *theVector, int rank)
{
    int *indx ;
    double sign ;
    double **M ;
    
    indx = vectorInt(1, rank) ;
    
    /* Save the provided matrix */
    M = matrixDouble(0, rank - 1, 0, rank - 1) ;
    memcpy(M[0], &theMatrix[1][1], rank * rank * sizeof(double)) ;
    
    ludcmp(theMatrix, rank, indx, &sign) ;
    lubksb(theMatrix, rank, indx, theVector) ;
    
    /* Restore provided matrix */
    memcpy(&theMatrix[1][1], M[0], rank * rank * sizeof(double)) ;
    freeMatrixDouble(M, 0, 0) ;
    
    freeVectorInt(indx, 1) ;
}


