
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  matrixPile.c
 *  MCA
 *
 *  Created by Dominique Derauw on 06/01/10.
 *  Copyright 2010 Dominique Derauw All rights reserved.
 *
 */

/* MatrixPile definition and allocation on continuous memory space */
#include "matrixPile.h"

/* npl and nph are the lower and higher index of the matrix layer    (Z) */
/* nrl and nrh are the lower and higher index of the matrix rows     (Y) */
/* ncl and nch are the lower and higher index of the matrix columns  (X) */

/* ----------------- Allocation of a continuous space for a matrix pile of char unsigned  ----------------- */
unsigned char	***matrixPileUChar(int npl, int nph, int nrl, int nrh, int ncl, int nch)
{
	int		i, j, NLayers, NRows, NCols ;
	unsigned char	***aMatrixPile ;

	NLayers = nph - npl + 1 ;
	NRows = nrh - nrl + 1 ;
	NCols = nch - ncl + 1 ;

	/* Allocation of a column vector of pointers to index layers of the pile */
	if((aMatrixPile = (unsigned char ***) malloc((unsigned) NLayers * sizeof(unsigned char **))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile -= npl ;

	/* Allocating column vectors to index matrix rows */
	if((aMatrixPile[npl] = (unsigned char **)malloc((unsigned)NLayers * NRows * sizeof(unsigned char *))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl] -= nrl ;

	/* Indexing the pile vector */
	for(i = 1; i < NLayers; i++)
		aMatrixPile[npl + i] = &aMatrixPile[npl][i * NRows] ;


	/* Allocation of the required continuous space for the whole pile */
	if((aMatrixPile[npl][nrl] = (unsigned char *)malloc((unsigned)NLayers * NRows * NCols * sizeof(unsigned char))) == NULL) {
		perror("Unsigned char matrixPile contunuous space allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl][nrl] -= ncl ;

	/* Indexing of the column vectors */
	for(i = 0; i < NLayers; i++) {
		for(j = 0; j < NRows; j++) {
			if(i + j) aMatrixPile[npl + i][nrl + j] = &aMatrixPile[npl][nrl][(i * NRows + j) * NCols] ;
		}
	}

	return(aMatrixPile) ;
}


/* ----------------- De-allocation of a matrixPile of char unsigned ----------------- */

void	freeMatrixPileUChar(unsigned char ***aMatrixPile, int npl, int nrl, int ncl)
{
	free(aMatrixPile[npl][nrl] + ncl) ;
	free((void *)(aMatrixPile[npl] + nrl)) ;
	free((void *)(aMatrixPile + npl)) ;
}



/* ----------------- Allocation of a continuous space for a matrix pile of short  ----------------- */

short	***matrixPileShort(int npl, int nph, int nrl, int nrh, int ncl, int nch)
{
	int		i, j, NLayers, NRows, NCols ;
	short	***aMatrixPile ;

	NLayers = nph - npl + 1 ;
	NRows = nrh - nrl + 1 ;
	NCols = nch - ncl + 1 ;

	/* Allocation of a column vector of pointers to index layers of the pile */
	if((aMatrixPile = (short ***) malloc((unsigned) NLayers * sizeof(short **))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile -= npl ;

	/* Allocating column vectors to index matrix rows */
	if((aMatrixPile[npl] = (short **)malloc((unsigned)NLayers * NRows * sizeof(short *))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl] -= nrl ;

	/* Indexing the pile vector */
	for(i = 1; i < NLayers; i++)
		aMatrixPile[npl + i] = &aMatrixPile[npl][i * NRows] ;


	/* Allocation of the required continuous space for the whole pile */
	if((aMatrixPile[npl][nrl] = (short *)malloc((unsigned)NLayers * NRows * NCols * sizeof(short))) == NULL) {
		perror("Unsigned char matrixPile contunuous space allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl][nrl] -= ncl ;

	/* Indexing of the column vectors */
	for(i = 0; i < NLayers; i++) {
		for(j = 0; j < NRows; j++) {
			if(i + j) aMatrixPile[npl + i][nrl + j] = &aMatrixPile[npl][nrl][(i * NRows + j) * NCols] ;
		}
	}

	return(aMatrixPile) ;
}


/* ----------------- De-allocation of a matrixPile of short ----------------- */

void	freeMatrixPileShort(short ***aMatrixPile, int npl, int nrl, int ncl)
{
	free(aMatrixPile[npl][nrl] + ncl) ;
	free((void *)(aMatrixPile[npl] + nrl)) ;
	free((void *)(aMatrixPile + npl)) ;
}



/* ----------------- Allocation of a continuous space for a matrix pile of short unsigned  ----------------- */
unsigned short	***matrixPileShortUnsigned(int npl, int nph, int nrl, int nrh, int ncl, int nch)
{
	int		i, j, NLayers, NRows, NCols ;
	unsigned short	***aMatrixPile ;

	NLayers = nph - npl + 1 ;
	NRows = nrh - nrl + 1 ;
	NCols = nch - ncl + 1 ;

	/* Allocation of a column vector of pointers to index layers of the pile */
	if((aMatrixPile = (unsigned short ***) malloc((unsigned) NLayers * sizeof(unsigned short **))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile -= npl ;

	/* Allocating column vectors to index matrix rows */
	if((aMatrixPile[npl] = (unsigned short **)malloc((unsigned)NLayers * NRows * sizeof(unsigned short *))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl] -= nrl ;

	/* Indexing the pile vector */
	for(i = 1; i < NLayers; i++)
		aMatrixPile[npl + i] = &aMatrixPile[npl][i * NRows] ;


	/* Allocation of the required continuous space for the whole pile */
	if((aMatrixPile[npl][nrl] = (unsigned short *)malloc((unsigned)NLayers * NRows * NCols * sizeof(unsigned short))) == NULL) {
		perror("Unsigned char matrixPile contunuous space allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl][nrl] -= ncl ;

	/* Indexing of the column vectors */
	for(i = 0; i < NLayers; i++) {
		for(j = 0; j < NRows; j++) {
			if(i + j) aMatrixPile[npl + i][nrl + j] = &aMatrixPile[npl][nrl][(i * NRows + j) * NCols] ;
		}
	}

	return(aMatrixPile) ;
}


/* ----------------- De-allocation of a matrixPile of short unsigned ----------------- */

void	freeMatrixPileShortUnsigned(unsigned short ***aMatrixPile, int npl, int nrl, int ncl)
{
	free(aMatrixPile[npl][nrl] + ncl) ;
	free((void *)(aMatrixPile[npl] + nrl)) ;
	free((void *)(aMatrixPile + npl)) ;
}



/* ----------------- Allocation of a continuous space for a matrix pile of int  ----------------- */
int	***matrixPileInt(int npl, int nph, int nrl, int nrh, int ncl, int nch)
{
	int		i, j, NLayers, NRows, NCols ;
	int	***aMatrixPile ;

	NLayers = nph - npl + 1 ;
	NRows = nrh - nrl + 1 ;
	NCols = nch - ncl + 1 ;

	/* Allocation of a column vector of pointers to index layers of the pile */
	if((aMatrixPile = (int ***) malloc((unsigned) NLayers * sizeof(int **))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile -= npl ;

	/* Allocating column vectors to index matrix rows */
	if((aMatrixPile[npl] = (int **)malloc((unsigned)NLayers * NRows * sizeof(int *))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl] -= nrl ;

	/* Indexing the pile vector */
	for(i = 1; i < NLayers; i++)
		aMatrixPile[npl + i] = &aMatrixPile[npl][i * NRows] ;


	/* Allocation of the required continuous space for the whole pile */
	if((aMatrixPile[npl][nrl] = (int *)malloc((unsigned)NLayers * NRows * NCols * sizeof(int))) == NULL) {
		perror("Unsigned char matrixPile contunuous space allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl][nrl] -= ncl ;

	/* Indexing of the column vectors */
	for(i = 0; i < NLayers; i++) {
		for(j = 0; j < NRows; j++) {
			if(i + j) aMatrixPile[npl + i][nrl + j] = &aMatrixPile[npl][nrl][(i * NRows + j) * NCols] ;
		}
	}

	return(aMatrixPile) ;
}


/* ----------------- De-allocation of a matrixPile of int ----------------- */

void	freeMatrixPileInt(int ***aMatrixPile, int npl, int nrl, int ncl)
{
	free(aMatrixPile[npl][nrl] + ncl) ;
	free((void *)(aMatrixPile[npl] + nrl)) ;
	free((void *)(aMatrixPile + npl)) ;
}



/* ----------------- Allocation of a continuous space for a matrix pile of float  ----------------- */
float	***matrixPileFloat(int npl, int nph, int nrl, int nrh, int ncl, int nch)
{
	int		i, j, NLayers, NRows, NCols ;
	float	***aMatrixPile ;

	NLayers = nph - npl + 1 ;
	NRows = nrh - nrl + 1 ;
	NCols = nch - ncl + 1 ;

	/* Allocation of a column vector of pointers to index layers of the pile */
	if((aMatrixPile = (float ***) malloc((unsigned) NLayers * sizeof(float **))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile -= npl ;

	/* Allocating column vectors to index matrix rows */
	if((aMatrixPile[npl] = (float **)malloc((unsigned)NLayers * NRows * sizeof(float *))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl] -= nrl ;

	/* Indexing the pile vector */
	for(i = 1; i < NLayers; i++)
		aMatrixPile[npl + i] = &aMatrixPile[npl][i * NRows] ;


	/* Allocation of the required continuous space for the whole pile */
	if((aMatrixPile[npl][nrl] = (float *)malloc((unsigned)NLayers * NRows * NCols * sizeof(float))) == NULL) {
		perror("Unsigned char matrixPile contunuous space allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl][nrl] -= ncl ;

	/* Indexing of the column vectors */
	for(i = 0; i < NLayers; i++) {
		for(j = 0; j < NRows; j++) {
			if(i + j) aMatrixPile[npl + i][nrl + j] = &aMatrixPile[npl][nrl][(i * NRows + j) * NCols] ;
		}
	}

	return(aMatrixPile) ;
}


/* ----------------- De-allocation of a matrixPile of float ----------------- */

void	freeMatrixPileFloat(float ***aMatrixPile, int npl, int nrl, int ncl)
{
	free(aMatrixPile[npl][nrl] + ncl) ;
	free((void *)(aMatrixPile[npl] + nrl)) ;
	free((void *)(aMatrixPile + npl)) ;
}



/* ----------------- Allocation of a continuous space for a matrix pile of double  ----------------- */
double	***matrixPileDouble(int npl, int nph, int nrl, int nrh, int ncl, int nch)
{
	int		i, j, NLayers, NRows, NCols ;
	double	***aMatrixPile ;

	NLayers = nph - npl + 1 ;
	NRows = nrh - nrl + 1 ;
	NCols = nch - ncl + 1 ;

	/* Allocation of a column vector of pointers to index layers of the pile */
	if((aMatrixPile = (double ***) malloc((unsigned) NLayers * sizeof(double **))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile -= npl ;

	/* Allocating column vectors to index matrix rows */
	if((aMatrixPile[npl] = (double **)malloc((unsigned)NLayers * NRows * sizeof(double *))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl] -= nrl ;

	/* Indexing the pile vector */
	for(i = 1; i < NLayers; i++)
		aMatrixPile[npl + i] = &aMatrixPile[npl][i * NRows] ;

	/* Allocation of the required continuous space for the whole pile */
	if((aMatrixPile[npl][nrl] = (double *)malloc((unsigned)NLayers * NRows * NCols * sizeof(double))) == NULL) {
		perror("Unsigned char matrixPile contunuous space allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl][nrl] -= ncl ;

	/* Indexing of the column vectors */
	for(i = 0; i < NLayers; i++) {
		for(j = 0; j < NRows; j++) {
			if(i + j) aMatrixPile[npl + i][nrl + j] = &aMatrixPile[npl][nrl][(i * NRows + j) * NCols] ;
		}
	}

	return(aMatrixPile) ;
}


/* ----------------- De-allocation of a matrixPile of double ----------------- */

void	freeMatrixPileDouble(double ***aMatrixPile, int npl, int nrl, int ncl)
{
	free(aMatrixPile[npl][nrl] + ncl) ;
	free((void *)(aMatrixPile[npl] + nrl)) ;
	free((void *)(aMatrixPile + npl)) ;
}


/* ----------------- Allocation of a continuous space for a matrix pile of char unsigned  ----------------- */
complexFloat	***matrixPileComplexFloat(int npl, int nph, int nrl, int nrh, int ncl, int nch)
{
	int		i, j, NLayers, NRows, NCols ;
	complexFloat	***aMatrixPile ;

	NLayers = nph - npl + 1 ;
	NRows = nrh - nrl + 1 ;
	NCols = nch - ncl + 1 ;

	/* Allocation of a column vector of pointers to index layers of the pile */
	if((aMatrixPile = (complexFloat ***) malloc((unsigned) NLayers * sizeof(complexFloat **))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile -= npl ;

	/* Allocating column vectors to index matrix rows */
	if((aMatrixPile[npl] = (complexFloat **)malloc((unsigned)NLayers * NRows * sizeof(complexFloat *))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl] -= nrl ;

	/* Indexing the pile vector */
	for(i = 1; i < NLayers; i++)
		aMatrixPile[npl + i] = &aMatrixPile[npl][i * NRows] ;

	/* Allocation of the required continuous space for the whole pile */
	if((aMatrixPile[npl][nrl] = (complexFloat *)malloc((unsigned)NLayers * NRows * NCols * sizeof(complexFloat))) == NULL) {
		perror("Unsigned char matrixPile contunuous space allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl][nrl] -= ncl ;

	/* Indexing of the column vectors */
	for(i = 0; i < NLayers; i++) {
		for(j = 0; j < NRows; j++) {
			if(i + j) aMatrixPile[npl + i][nrl + j] = &aMatrixPile[npl][nrl][(i * NRows + j) * NCols] ;
		}
	}

	return(aMatrixPile) ;
}


/* ----------------- De-allocation of a matrixPile of complex float ----------------- */

void	freeMatrixPileComplexFloat(complexFloat ***aMatrixPile, int npl, int nrl, int ncl)
{
	free(aMatrixPile[npl][nrl] + ncl) ;
	free((void *)(aMatrixPile[npl] + nrl)) ;
	free((void *)(aMatrixPile + npl)) ;
}



/* ----------------- Allocation of a continuous space for a matrix pile of complex double  ----------------- */
complexDouble	***matrixPileComplexDouble(int npl, int nph, int nrl, int nrh, int ncl, int nch)
{
	int		i, j, NLayers, NRows, NCols ;
	complexDouble	***aMatrixPile ;

	NLayers = nph - npl + 1 ;
	NRows = nrh - nrl + 1 ;
	NCols = nch - ncl + 1 ;

	/* Allocation of a column vector of pointers to index layers of the pile */
	if((aMatrixPile = (complexDouble ***) malloc((unsigned) NLayers * sizeof(complexDouble **))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile -= npl ;

	/* Allocating column vectors to index matrix rows */
	if((aMatrixPile[npl] = (complexDouble **)malloc((unsigned)NLayers * NRows * sizeof(complexDouble *))) == NULL) {
		perror("Unsigned char matrixPile allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl] -= nrl ;

	/* Indexing the pile vector */
	for(i = 1; i < NLayers; i++)
		aMatrixPile[npl + i] = &aMatrixPile[npl][i * NRows] ;


	/* Allocation of the required continuous space for the whole pile */
	if((aMatrixPile[npl][nrl] = (complexDouble *)malloc((unsigned)NLayers * NRows * NCols * sizeof(complexDouble))) == NULL) {
		perror("Unsigned char matrixPile contunuous space allocation error ") ;
		exit(-1) ;
	}
	aMatrixPile[npl][nrl] -= ncl ;

	/* Indexing of the column vectors */
	for(i = 0; i < NLayers; i++) {
		for(j = 0; j < NRows; j++) {
			if(i + j) aMatrixPile[npl + i][nrl + j] = &aMatrixPile[npl][nrl][(i * NRows + j) * NCols] ;
		}
	}

	return(aMatrixPile) ;
}


/* ----------------- De-allocation of a matrixPile of complex double ----------------- */

void	freeMatrixPileComplexDouble(complexDouble ***aMatrixPile, int npl, int nrl, int ncl)
{
	free(aMatrixPile[npl][nrl] + ncl) ;
	free((void *)(aMatrixPile[npl] + nrl)) ;
	free((void *)(aMatrixPile + npl)) ;
}




