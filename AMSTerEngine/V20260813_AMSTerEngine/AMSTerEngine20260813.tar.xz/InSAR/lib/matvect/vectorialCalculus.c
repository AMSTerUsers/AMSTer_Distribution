
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  vectorialCalculus.c
 *  slant2GroundProj
 *
 *  Created by Dominique Derauw on 1/09/08.
 *  Copyright 2008 Dominique Derauw . All rights reserved.
 *
 */

#include "vectorialCalculus.h"

void	vectorialProduct(double *V, double *v1, double *v2)
{
    V[0] = v1[1] * v2[2] - v1[2] * v2[1] ;
    V[1] = v1[2] * v2[0] - v1[0] * v2[2] ;
    V[2] = v1[0] * v2[1] - v1[1] * v2[0] ;
}

double	scalarProduct(double *v1, double *v2) 
{
    return (v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2]) ;
}


double vectorNorm(double *v)
{
	return(sqrt(scalarProduct(v, v))) ;
}

void vectorDiffInPlace(double *v1, double *v2)
{
	int i ;
	
	for(i = 0; i < 3; i++) v1[i] -= v2[i] ;
}

void vectorDiff(double *v1_v2, double *v1, double *v2)
{
	int i ;
	
	for(i = 0; i < 3; i++) v1_v2[i] = v1[i] - v2[i] ;
}

void normalizeVector(double *aVector)
{
	int i ;
	double norme ;
	
	norme = vectorNorm(aVector) ;
	for(i = 0; i < 3; i++)
		aVector[i] /= norme ;
}

