
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  tile2tileInterpolation.c
//  detPhUn
//
//  Created by Dominique Derauw on 14/11/2017.
//  Copyright © 2017 Dominique Derauw. All rights reserved.
//

#include "tile2tileInterpolation.h"


/* Attention! T here is a 4 X 3 matrix. It may be confusing. Sub matrix T[0-1][0-2] contains the affine transform. T[2][0-1] and T[3][0-1] contain x and y frequency shift and sampling in case spectrums are  not centred */


/* X dimension interpolation */
void    tile2TileInterpolComplexAlongXAxis(tileTool *inputTile, double **T, tileTool *outputTile, char withMirroring)
{
    char isUnitary ;
    int    i, j, lenX, lenX0, expLenX, xBorder, p, index ;
    int xDim, yDim ;
    long seekVal ;
    complexFloat    *aLign, *aNullLine ;
    double D ;
    double frequencyShift, sampling, phaseFactor ;
    complexFloat *u, phasor ;
    CZTInterpolator *V ;
    progressCounter *aCounter ;
    
    xDim = inputTile->xDimIn ;
    yDim = inputTile->yDimIn ;
    
    lenX0 = ((int)(outputTile->xDimOut) < xDim)? xDim : (int)(outputTile->xDimOut) ;
    lenX = lenX0 ;
    ceil2(&lenX, &expLenX) ;
    xBorder = (lenX - lenX0)/2 ;
    
    aLign = vectorComplexFloat(0, lenX - 1) ;
    aNullLine = vectorComplexFloat(0, lenX - 1) ;
    
    /* Init interpolator */
    T[0][1] /= T[1][1] ;
    T[0][0] -= T[0][1] * T[1][0] ;
    T[0][2] -= T[0][1] * T[1][2]  - (1. - T[0][0]) * xBorder ;
    
    isUnitary = (T[0][0] == 1. && T[0][1] == 0. && T[0][2] == 0.)? 1 : 0 ;
    
    u = NULL ;
    V = NULL ;
    aCounter = NULL ;
    if (!isUnitary) {
        printf("Interpolation along X axis\n") ;
        V = initInterpolator(lenX, T[0][0]) ;
        u = vectorComplexFloat(0, lenX) ;
        
        for(i = 0; i < lenX; i++)
            aNullLine[i].r = aNullLine[i].i = 0. ;
        
        aCounter = initProgressCounterWithMinMaxValue(0, yDim) ;
    }
    
    /* Frequency shift */
    frequencyShift = T[2][0] ;
    sampling = T[2][1] ;
    phaseFactor = PI ;
    if(sampling)
        phaseFactor = 2. * PI *(-frequencyShift / sampling + .5) ;
    
    seekVal = inputTile->xDimIn * sizeof(complexFloat) ;
    for(i = 0; i < yDim ; i++)
    {
        memcpy(aLign, aNullLine, lenX * sizeof(complexFloat)) ;
        memcpy(aLign + xBorder, inputTile->tile[i], seekVal) ;
        
        if (!isUnitary) {
            if(withMirroring) {
                p = xBorder + xDim - 1 ;
                while(p < lenX) {
                    for(index = p + 1, j = 1; j < xDim; index++, j++)
                        if(index < lenX) {
                            aLign[index].r = aLign[p - j].r ;
                            aLign[index].i = aLign[p - j].i ;
                        }
                    p += xDim - 1 ;
                }
                p = xBorder ;
                while(p >= 0) {
                    for(index = p - 1, j = 1; j < xDim; index--, j++)
                        if(index >= 0) {
                            aLign[index].r = aLign[p + j].r ;
                            aLign[index].i = aLign[p + j].i ;
                        }
                    p -= xDim - 1 ;
                }
            }
            
            for(j=0; j<lenX; j++) {
                phasor.r = (float)cos((double)phaseFactor * j) ;
                phasor.i = (float)sin((double)phaseFactor * j) ;
                u[j] = mC(aLign[j], phasor) ;
            }
            
            D = T[0][1] * i + T[0][2] ;
            CZTInterpolation(u, T[0][0], D, V) ;
            
            for(j=0; j<lenX; j++)
            {
                phasor.r = (float)cos(-phaseFactor * (T[0][0]*j + D))/lenX ;
                phasor.i = (float)sin(-phaseFactor * (T[0][0]*j + D))/lenX ;
                aLign[j] = mC(phasor, u[j]) ;
            }
            updateProgressCounterForIndex(aCounter, i) ;
        }
        memcpy(outputTile->tile[i], aLign + xBorder, outputTile->xDimIn * sizeof(complexFloat)) ;
    }
    
    if (!isUnitary) {
        updateProgressCounterForIndex(aCounter, i) ;
        freeCZTInterpolator(V) ;
        freeVectorComplexFloat(u, 0) ;
        
    }
    freeVectorComplexFloat(aLign, 0) ;
    freeVectorComplexFloat(aNullLine, 0) ;
}

/* Y dimension interpolation */
void    tile2TileInterpolComplexAlongYAxis(tileTool *inputTile, double **T, tileTool *outputTile, char withMirroring)
{
    char isUnitary ;
    int    i, j, k, lenY, lenY0, expLenY, yBorder, p, index ;
    int    xDimBloc, xDimLastBloc, NBlocs, xIndex ;
    complexFloat    **aBloc, **aNullBloc ;
    double D ;
    double frequencyShift, sampling, phaseFactor ;
    complexFloat *u, phasor ;
    CZTInterpolator *V ;
    progressCounter *aCounter ;
    
    isUnitary = (T[1][0] == 0. && T[1][1] == 1 && T[1][2] == 0.)? 1 : 0 ;
    
    lenY0 = (outputTile->yDimOut < inputTile->yDimIn)? inputTile->yDimIn : outputTile->yDimOut ;
    lenY = lenY0 ;
    ceil2(&lenY, &expLenY) ;
    yBorder= (lenY - lenY0)/2 ;
    
    
    xDimBloc = _INTERPOL_MEM_MAX_SIZE_ / lenY / sizeof(complexFloat) ;
    NBlocs = inputTile->xDimIn / xDimBloc ;
    xDimLastBloc = inputTile->xDimIn - NBlocs * xDimBloc ;
    xDimBloc = (NBlocs)? xDimBloc : xDimLastBloc ;
    
    u = NULL ;
    V = NULL ;
    aCounter = NULL ;
    if (!isUnitary) {
        printf("\nInterpolation along Y axis\n") ;
        printf("lenY = %d\tyBorder = %d\n", lenY, yBorder) ;
        printf("xDimBloc = %d\txDimLastBloc = %d\n", xDimBloc, xDimLastBloc) ;
        printf("NBlocs = %d\txDimLastBloc = %d\n", NBlocs, xDimLastBloc) ;
        V = initInterpolator(lenY, T[1][1]) ;
        u = vectorComplexFloat(0, lenY) ;
        aCounter = initProgressCounterWithMinMaxValue(0, outputTile->xDimOut) ;
    }
    /*
     printf("Creating output file\n") ;
     aNullVector = vectorComplexFloat(0, outputFile->xDim - 1) ;
     for(i = 0; i < outputFile->yDim; i++) {
     fwrite((complexFloat *)aNullVector, outputFile->xDim, sizeof(complexFloat), outputFile->f) ;
     }
     fflush(outputFile->f) ;
     freeVectorComplexFloat(aNullVector, 0) ;
     */
    aBloc = (complexFloat **)matrixComplexFloat(0, lenY - 1, 0, xDimBloc - 1) ;
    aNullBloc = (complexFloat **)matrixComplexFloat(0, lenY - 1, 0, xDimBloc - 1) ;
    for(i = 0; i < lenY; i++) {
        for(j = 0; j < xDimBloc; j++) {
            aNullBloc[i][j].r = aNullBloc[i][j].i = 0. ;
        }
    }
    
    /* Frequency shift */
    frequencyShift = T[3][0] ;
    sampling = T[3][1] ;
    phaseFactor = PI ;
    if(sampling)
        phaseFactor = 2. * PI *(-frequencyShift / sampling + .5) ;
    
    for(k = 0; k <= NBlocs; k++) {
        xIndex = k * xDimBloc ;
        memcpy(aBloc[0], aNullBloc[0], xDimBloc * lenY * sizeof(complexFloat)) ;
        
        if(k == NBlocs) {
            xDimBloc = xDimLastBloc ;
        }
        
        for(i = 0; i < (int)(inputTile->yDimIn); i++) {
            memcpy(aBloc[i] + yBorder, inputTile->tile[i] + xIndex * sizeof(complexFloat), xDimBloc * sizeof(complexFloat)) ;
        }
        
        
        for(i = 0; i < xDimBloc; i++) {
            if (!isUnitary) {
                if(withMirroring) {
                    p = yBorder + inputTile->yDimIn - 1 ;
                    while(p < lenY) {
                        for(index = p + 1, j = 1; j < (int)(inputTile->yDimIn); index++, j++)
                            if(index < lenY) {
                                aBloc[index][i] = aBloc[p - j][i] ;
                            }
                        p += inputTile->yDimIn - 1 ;
                    }
                    p = yBorder ;
                    while(p >= 0) {
                        for(index = p - 1, j = 1; j < (int)(inputTile->yDimIn); index--, j++)
                            if(index >= 0) {
                                aBloc[index][i] = aBloc[p + j][i] ;
                            }
                        p -= inputTile->yDimIn - 1 ;
                    }
                }
                
                for(j = 0; j < lenY; j++) {
                    phasor.r = (float)cos((double)phaseFactor * j) ;
                    phasor.i = (float)sin((double)phaseFactor * j) ;
                    u[j] = mC(aBloc[j][i], phasor) ;
                }
                
                D = T[1][0] * (i + xIndex) + T[1][2] + (1. - T[1][1]) * yBorder ;
                CZTInterpolation(u, T[1][1], D, V) ;
                
                for(j = yBorder; j < lenY - yBorder; j++) {
                    phasor.r = (float)cos(-phaseFactor * (T[1][1]*j + D))/lenY ;
                    phasor.i = (float)sin(-phaseFactor * (T[1][1]*j + D))/lenY ;
                    aBloc[j][i] = mC(phasor, u[j]) ;
                }
                updateProgressCounterForIndex(aCounter, i + xIndex) ;
            }
        }
        
        for(i = 0; i < (int)(outputTile->yDimIn); i++) {
            memcpy(outputTile->tile[i] + xIndex * sizeof(complexFloat), aBloc[i] + yBorder, xDimBloc * sizeof(complexFloat)) ;
        }
    }
    
    if (!isUnitary) {
        updateProgressCounterForIndex(aCounter, outputTile->xDimOut) ;
        freeVectorComplexFloat(u, 0) ;
        freeCZTInterpolator(V) ;
    }
    
    freeMatrixComplexFloat(aBloc, 0, 0) ;
    freeMatrixComplexFloat(aNullBloc, 0, 0) ;
}
