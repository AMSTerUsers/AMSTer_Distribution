
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  jsonLib.c
 *  AMSTerEngine
 *
 *  Created by Dominique Derauw on 29/11/2023.
 *  Copyright 2023 SAREOS - Dominique Derauw. All rights reserved.
 *
 */

#include "jsonLib.h"

char *readJsonFileIntoBuffer(char *jsonFilePath) 
{
    char *buffer, *aLine ; 
    size_t ii ;
    rawFileDescriptor *jsonFile ;

    if((jsonFile = openRawFileForReadingAndWritingAtPath(jsonFilePath)) == NULL) {
        return(NULL) ;
    }
    buffer = malloc(jsonFile->fileLength + 1) ;

    ii = 0 ;
    while ((aLine = fgets(buffer + ii, jsonFile->fileLength, jsonFile->f))) {
        ii += strlen(aLine) ;
    }
    stripWhiteCharsInString(buffer) ;
    freeRawFileDescriptor(jsonFile) ;

    return(buffer) ;
}

CSVStruct *getCSVForKeyInJsonFile(char *jsonFilePath, char *theKey)
{
    char *buffer0, *buffer, *fullKey, *stringVal ;
    int ii ;
    size_t keyLength, iSup, iSup1, iSup2 ;
    CSVStruct *csv = NULL ;

    buffer0 = buffer = readJsonFileIntoBuffer(jsonFilePath) ;
    fullKey = initStringWith3Strings("\"", theKey, "\":\"") ;
    keyLength = strlen(fullKey) ;

    while ((ii = locateSubStringInString(buffer, fullKey)) > 0) {
        ii += keyLength ;
        buffer += ii ;
        iSup = locateSubStringInString(buffer, "\"") ;
        stringVal = allocStringOfLength(iSup) ;
        strncpy(stringVal, buffer, iSup) ;
        csv = addStringValInCSVStruct(stringVal, csv) ;
        buffer += iSup ;
        free(stringVal) ;
    }

    /* If not found, look if it is found as a number */
    if (!csv) {
        free(fullKey) ;
        fullKey = initStringWith3Strings("\"", theKey, "\":") ;
        keyLength = strlen(fullKey) ;
        buffer = buffer0 ;
        while ((ii = locateSubStringInString(buffer, fullKey)) > 0) {
            ii += keyLength ;
            buffer += ii ;
            iSup1 = locateSubStringInString(buffer, ",") ;
            iSup2 = locateSubStringInString(buffer, "}") ;
            iSup = (iSup1 < iSup2)? iSup1 : iSup2 ;
            stringVal = allocStringOfLength(iSup) ;
            strncpy(stringVal, buffer, iSup) ;
            csv = addStringValInCSVStruct(stringVal, csv) ;
            buffer += iSup ;
            free(stringVal) ;
        }
    }
    
    free(buffer0) ;
    free(fullKey) ;

    return(csv) ;
}

keyValue *readJsonFileAsKeyValueList(char *jsonFilePath) 
{
    char *buffer; 
    size_t ii ;
    keyValue *json, *aKeyVal ;

    buffer = readJsonFileIntoBuffer(jsonFilePath) ;
    /* If file is not starting by {, we consider it is not in json format */
    if (buffer[0] != '\{') {
        return(NULL) ;
    }
    
    json = allocAKeyValuePair() ;
    ii = 1 ;
    if (buffer[ii] == '\"') {
        aKeyVal = getNextKeyVal(buffer + ii) ;
        if (aKeyVal) {
            aKeyVal->nextOne = json->nextOne ;
            freeKeyValuePair(json) ;
            json = aKeyVal ;
        }
    }
    
    return(json) ;
}


keyValue *getNextKeyVal(char *buffer)
{
    size_t ii = 0, iVal = 0, maxLength ;
    keyValue *aKeyVal = NULL ;

    if (buffer[ii] != '\"') {
        return (NULL) ;
    }

    maxLength = strlen(buffer) - 3 ;
    while (!isJsonEndChar(buffer + ii)) {
        if (ii < maxLength && !strncmp(buffer + ii, "\":\"", 3)) {
            iVal = ii ;
        }
        ii++ ;
    }
    
    if (--iVal) {
        buffer++ ;
        aKeyVal = allocAKeyValuePair() ;
        aKeyVal->key = allocStringOfLength(iVal) ;
        memcpy(aKeyVal->key, buffer, iVal) ;
        iVal += 4 ;
        aKeyVal->stringVal = allocStringOfLength(ii - iVal) ;
        memcpy(aKeyVal->stringVal, buffer + iVal, ii - iVal -1) ;
    }

    return(aKeyVal) ;
}

char isJsonEndChar(char *aChar)
{
    return(*aChar == ',' || *aChar == '}' || *aChar == ']') ;
}

char isJsonStartChar(char *aChar)
{
    return(*aChar == '{' || *aChar == '[' || *aChar == '"') ;
}