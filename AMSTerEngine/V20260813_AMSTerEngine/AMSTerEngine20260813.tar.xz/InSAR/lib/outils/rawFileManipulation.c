
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  rawFileManipulation.c
//  geoProjection
//
//  Created by Dominique Derauw on 16/03/17.
//
//

#include "rawFileManipulation.h"


void verticalFlipOfDataOfTypeAtPath(char *aPath, int xDim, int yDim, char inPlace)
{
    char *filePath ;
    int iY ;
    long unsigned seekVal, seekValUp, seekValDown ;
    size_t type ;
    rawFileDescriptor *inputFile, *outputFile ;
    void *aLign, *lignUp, *lignDown ;

    if ((inputFile = openRawFileForReadingAndWritingAtPath(aPath)) == NULL) {
        printf("Cannot flip data. Failed to open file %s\n", aPath) ;
    }
    type = (size_t)(inputFile->fileLength / xDim / yDim) ;

    if (inPlace) {
        lignUp = vectorOfType(0, xDim - 1, type) ;
        lignDown = vectorOfType(0, xDim - 1, type) ;
        seekValDown = xDim * (yDim - 1) * type ;
        seekValUp = 0 ;

        for (iY = 0; iY < yDim / 2; iY++) {
            fseek(inputFile->f, seekValUp, SEEK_SET) ;
            fread(lignUp, type, xDim, inputFile->f) ;

            fseek(inputFile->f, seekValDown, SEEK_SET) ;
            fread(lignDown, type, xDim, inputFile->f) ;
            fseek(inputFile->f, seekValDown, SEEK_SET) ;
            fwrite(lignUp, type, xDim, inputFile->f) ;

            fseek(inputFile->f, seekValUp, SEEK_SET) ;
            fwrite(lignDown, type, xDim, inputFile->f) ;

            seekValDown -= xDim * type ;
            seekValUp += xDim * type ;
        }

        freeVectorOfType(lignDown, 0, type) ;
        freeVectorOfType(lignUp, 0, type) ;
        freeRawFileDescriptor(inputFile) ;
    }
    else {
        filePath = initStringWith2Strings(inputFile->accessPath, ".flipped") ;
        outputFile = openRawFileForReadingAndWritingAtPath(filePath) ;

        seekVal = xDim * (yDim - 1) * type ;
        aLign = vectorOfType(0, xDim - 1, type) ;

        for (iY = yDim; iY != 0; iY--) {
            fseek(inputFile->f, seekVal, SEEK_SET) ;
            fread(aLign, type, xDim, inputFile->f) ;
            fwrite(aLign, type, xDim, outputFile->f) ;
            seekVal -= xDim * type ;
        }

        freeVectorOfType(aLign, 0, type) ;
        freeRawFileDescriptor(inputFile) ;
        freeRawFileDescriptor(outputFile) ;
        free(filePath) ;
    }

}

void floatFilesArithmetics(char *filePath1, char *arithmeticOperator, float operand, char *filePath2, char *outputPath)
{
    char inPlace ;
    size_t iX, iB ;
    size_t nBlocs, lastBlocSize, blocSize ;
    float *data1, *data2, *result ;
    rawFileDescriptor *file1, *file2 = NULL, *outputFile = NULL ;

    if((file1 = openRawFileForReadingAndWritingAtPath(filePath1)) == NULL) {
        perror("Failed to open first file") ;
        return ;
    }
    file1->typeSize = 4 ;

    if (filePath2) {
        if((file2 = openRawFileForReadingAtPath(filePath2)) == NULL) {
            perror("Failed to open second file") ;
            return ;
        }

        if (file1->fileLength != file2->fileLength) {
            perror("Float files do no have same dimensions") ;
            return ;
        }
        file2->typeSize = 4 ;
    }

    if (4 * (file1->fileLength / 4) != file1->fileLength) {
        perror("Files are not float files") ;
        return ;
    }

    inPlace = _IN_PLACE_ ;
    if (outputPath) {
        inPlace = 0 ;
        outputFile = openRawFileForWritingAtPath(outputPath) ;
    }

    data1 = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    data2 = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    result = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    nBlocs = file1->fileLength / file1->typeSize / _BUFFER_SIZE_ ;
    lastBlocSize = file1->fileLength / file1->typeSize - nBlocs * _BUFFER_SIZE_  ;

    if (!filePath2) {
        for (iX = 0; iX < _BUFFER_SIZE_; iX++) {
            data2[iX] = operand ;
        }
    }

    for (iB = 0; iB <= nBlocs; iB++) {
        blocSize = (iB == nBlocs)? lastBlocSize : _BUFFER_SIZE_ ;
        if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
            ase("floatFileArithmetics: failed to seek into input file 1") ;
        }
        if ((blocSize != fread(data1, file1->typeSize, blocSize, file1->f))) {
            ase("floatFileArithmetics: failed to read input file 1") ;
        }
        if (filePath2) {
            if (fseek(file2->f, iB * _BUFFER_SIZE_ * file2->typeSize, SEEK_SET)) {
                ase("floatFileArithmetics: failed to seek into input file 2") ;
            }
            if ((blocSize != fread(data2, file2->typeSize, blocSize, file2->f))) {
                ase("floatFileArithmetics: failed to read input file 2") ;
            }
        }

        for (iX = 0; iX < blocSize; iX++) {
            switch (arithmeticOperator[0]) {
                case '+':
                    result[iX] = data1[iX] + data2[iX] ;
                    break;

                case '-':
                    result[iX] = data1[iX] - data2[iX] ;
                    break;

                case 'x':
                    result[iX] = data1[iX] * data2[iX] ;
                    break;

                case '*':
                    result[iX] = data1[iX] * data2[iX] ;
                    break;

                case '/':
                    result[iX] = data1[iX] / data2[iX] ;
                    break;

                default:
                    break;
            }
        }
        if (inPlace) {
            if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
                ase("floatFileArithmetics: failed to seek into output file") ;
            }

            if ((blocSize != fwrite(result, file1->typeSize, blocSize, file1->f))) {
                ase("floatFileArithmetics: failed to write into result file") ;
            }
        }
        else {
            if ((blocSize != fwrite(result, file1->typeSize, blocSize, outputFile->f))) {
                ase("floatFileArithmetics: failed to into result file") ;
            }
        }
    }

    freeVectorOfType(data1, 0, file1->typeSize) ;
    freeVectorOfType(data2, 0, file1->typeSize) ;
    freeVectorOfType(result, 0, file1->typeSize) ;
    freeRawFileDescriptor(file1) ;
    if (filePath2) {
        freeRawFileDescriptor(file2) ;
    }
    if (!inPlace) {
        freeRawFileDescriptor(outputFile) ;
    }

}

/* Performs simple raw files arithmetics */
/* Operator can be +, -, * or / */
/* A and B are multiplicative factors. filePath2 can be set to NULL to only multiply file1 by its factor.*/
/* e.g.  A file1 + B file2 */
/* raw files can be float (_REAL32_ID_) or complex float (_CPLX32_ID_) type */
void rawFilesArithmetics(float A, char *filePath1, char *arithmeticOperator, float B, char *filePath2, char *outputPath, int typeID)
{
    char inPlace ;
    size_t iX, iB ;
    size_t nBlocs, lastBlocSize, blocSize ;
    float *floatData1, *floatData2, *floatResult ;
    complexFloat *cfData1, *cfData2, *cfResult ;
    void *data1, *data2, *result ;
    rawFileDescriptor *file1, *file2 = NULL, *outputFile = NULL ;

    if((file1 = openRawFileForReadingAndWritingAtPath(filePath1)) == NULL) {
        perror("Failed to open first file") ;
        return ;
    }
    switch (typeID) {
    case _REAL32_ID_:
        file1->typeSize = 4 ;
        break;
    
    case _CPLX32_ID_:
        file1->typeSize = 8 ;
        break;
    
    default:
        file1->typeSize = 4 ;
        break;
    }

    if (filePath2) {
        if((file2 = openRawFileForReadingAtPath(filePath2)) == NULL) {
            perror("Failed to open second file") ;
            return ;
        }

        if (file1->fileLength != file2->fileLength) {
            perror("Float files do no have same dimensions") ;
            return ;
        }
        file2->typeSize = file1->typeSize ;
    }

    if (file1->typeSize * (file1->fileLength / file1->typeSize) != file1->fileLength) {
        perror("Files are not of given type") ;
        return ;
    }

    inPlace = _IN_PLACE_ ;
    if (outputPath) {
        inPlace = 0 ;
        outputFile = openRawFileForWritingAtPath(outputPath) ;
    }

    nBlocs = file1->fileLength / file1->typeSize / _BUFFER_SIZE_ ;
    lastBlocSize = file1->fileLength / file1->typeSize - nBlocs * _BUFFER_SIZE_  ;
    data1 = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    data2 = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    result = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    switch (typeID) {
    case _CPLX32_ID_:
        cfData1 = (complexFloat *) data1 ;
        cfData2 = (complexFloat *) data2 ;
        cfResult = (complexFloat *) result ;
    break;
    
    default:
        floatData1 = (float *) data1 ;
        floatData2 = (float *) data2 ;
        floatResult = (float *) result ;
    }


    if (!filePath2) {
        switch (typeID)
        {
        case _CPLX32_ID_:
            for (iX = 0; iX < _BUFFER_SIZE_; iX++) {
                cfData2[iX].r = cfData2[iX].i = 1. ;
            }
        break;
        
        default:
            for (iX = 0; iX < _BUFFER_SIZE_; iX++) {
                floatData2[iX] = 1. ;
            }
            break;
        }
    }

    for (iB = 0; iB <= nBlocs; iB++) {
        blocSize = (iB == nBlocs)? lastBlocSize : _BUFFER_SIZE_ ;
        if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
            ase("floatFileArithmetics: failed to seek into input file 1") ;
        }
        if ((blocSize != fread(data1, file1->typeSize, blocSize, file1->f))) {
            ase("floatFileArithmetics: failed to read input file 1") ;
        }
        if (filePath2) {
            if (fseek(file2->f, iB * _BUFFER_SIZE_ * file2->typeSize, SEEK_SET)) {
                ase("floatFileArithmetics: failed to seek into input file 2") ;
            }
            if ((blocSize != fread(data2, file2->typeSize, blocSize, file2->f))) {
                ase("floatFileArithmetics: failed to read input file 2") ;
            }
        }

        switch (arithmeticOperator[0]) {
            case '+':
                switch (typeID) {
                case _CPLX32_ID_:
                    for (iX = 0; iX < blocSize; iX++) {
                        cfResult[iX] = aC(mRC(cfData1[iX], A), mRC(cfData2[iX], B)) ;
                    }
                    break;
                case _REAL32_ID_ :
                    for (iX = 0; iX < blocSize; iX++) {
                        floatResult[iX] = A * floatData1[iX] + B * floatData2[iX] ;
                    }
                    break ;
                }
            break;

            case '-':
                switch (typeID) {
                case _CPLX32_ID_:
                    for (iX = 0; iX < blocSize; iX++) {
                        cfResult[iX] = sC(mRC(cfData1[iX], A), mRC(cfData2[iX], B)) ;
                    }
                    break;
                case _REAL32_ID_ :
                    for (iX = 0; iX < blocSize; iX++) {
                        floatResult[iX] = A * floatData1[iX] - B * floatData2[iX] ;
                    }
                    break ;
                }
            break;

            case 'x' || '*':
                switch (typeID) {
                case _CPLX32_ID_:
                    if (!filePath2) {
                        for (iX = 0; iX < blocSize; iX++) {
                            cfResult[iX] = mRC(cfData1[iX], A) ;
                        }
                    }
                    else {
                        for (iX = 0; iX < blocSize; iX++) {
                            cfResult[iX] = mC(mRC(cfData1[iX], A), mRC(cfData2[iX], B)) ;
                        }
                    }
                break;
                case _REAL32_ID_ :
                    for (iX = 0; iX < blocSize; iX++) {
                        floatResult[iX] = A * floatData1[iX] * B * floatData2[iX] ;
                    }
                    break ;
                }
            break;

            case '/':
                switch (typeID) {
                case _CPLX32_ID_:
                    if (!filePath2 && B) {
                        for (iX = 0; iX < blocSize; iX++) {
                            cfResult[iX] = mRC(cfData1[iX], A/B) ;
                        }
                    }
                    else {
                        for (iX = 0; iX < blocSize; iX++) {
                            cfResult[iX] = mRC(mC(mRC(cfData1[iX], A), cC(cfData2[iX])), 1 / (B * sqmC(cfData2[iX]))) ;
                        }
                    }
                break;
                case _REAL32_ID_ :
                    for (iX = 0; iX < blocSize; iX++) {
                        floatResult[iX] = (B)? A * floatData1[iX] / (B * floatData2[iX]) : A * floatData1[iX] ;
                    }
                break ;
                }
            break;

            default:
                break;
        }
    
        if (inPlace) {
            if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
                ase("floatFileArithmetics: failed to seek into output file") ;
            }

            if ((blocSize != fwrite(result, file1->typeSize, blocSize, file1->f))) {
                ase("floatFileArithmetics: failed to write into result file") ;
            }
        }
        else {
            if ((blocSize != fwrite(result, file1->typeSize, blocSize, outputFile->f))) {
                ase("floatFileArithmetics: failed to into result file") ;
            }
        }
    }

    freeVectorOfType(data1, 0, file1->typeSize) ;
    freeVectorOfType(data2, 0, file1->typeSize) ;
    freeVectorOfType(result, 0, file1->typeSize) ;
    freeRawFileDescriptor(file1) ;
    if (filePath2) {
        freeRawFileDescriptor(file2) ;
    }
    if (!inPlace) {
        freeRawFileDescriptor(outputFile) ;
    }

}
/* Phase computation of given float file given in input */
void wrapFloatFile(char *filePath1, char *outputPath)
{
    char inPlace ;
    size_t iX, iB ;
    size_t nBlocs, lastBlocSize, blocSize ;
    float *data1, *result ;
    complexFloat aComplex ;
    rawFileDescriptor *file1, *file2 = NULL, *outputFile = NULL ;

    if((file1 = openRawFileForReadingAndWritingAtPath(filePath1)) == NULL) {
        perror("Failed to open first file") ;
        return ;
    }
    file1->typeSize = 4 ;


    if (4 * (file1->fileLength / 4) != file1->fileLength) {
        perror("File is not a float files") ;
        return ;
    }

    inPlace = _IN_PLACE_ ;
    if (outputPath) {
        inPlace = 0 ;
        outputFile = openRawFileForWritingAtPath(outputPath) ;
    }

    data1 = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    result = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    nBlocs = file1->fileLength / file1->typeSize / _BUFFER_SIZE_ ;
    lastBlocSize = file1->fileLength / file1->typeSize - nBlocs * _BUFFER_SIZE_  ;

    for (iB = 0; iB <= nBlocs; iB++) {
        blocSize = (iB == nBlocs)? lastBlocSize : _BUFFER_SIZE_ ;
        if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
            ase("floatFileArithmetics: failed to seek into input file") ;
        }
        if ((blocSize != fread(data1, file1->typeSize, blocSize, file1->f))) {
            ase("floatFileArithmetics: failed to read input file") ;
        }

        for (iX = 0; iX < blocSize; iX++) {
            aComplex.r = cosf(data1[iX]) ;
            aComplex.i = sinf(data1[iX]) ;
            result[iX] = phi(&aComplex) ;
        }
        if (inPlace) {
            if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
                ase("floatFileArithmetics: failed to seek into output file") ;
            }

            if ((blocSize != fwrite(result, file1->typeSize, blocSize, file1->f))) {
                ase("floatFileArithmetics: failed to write into result file") ;
            }
        }
        else {
            if ((blocSize != fwrite(result, file1->typeSize, blocSize, outputFile->f))) {
                ase("floatFileArithmetics: failed to into result file") ;
            }
        }
    }

    freeVectorOfType(data1, 0, file1->typeSize) ;
    freeVectorOfType(result, 0, file1->typeSize) ;
    freeRawFileDescriptor(file1) ;
    freeRawFileDescriptor(file2) ;
    if (!inPlace) {
        freeRawFileDescriptor(outputFile) ;
    }
}


rawFileDescriptor *floatFileXGradient(rawFileDescriptor *inputFile, rawFileDescriptor *outputFile)
{
    char *outputPath ;
    int unsigned iX, iY, xTileIndex, yTileIndex, xTileSize, yTileSize ;
    float **M ;
    tileTool *fileTile ;
    rawFileDescriptor *aFile ;
    
    if (!outputFile) {
        outputPath = initStringWith2Strings(inputFile->accessPath, ".XGradient") ;
        aFile = openRawFileForReadingAndWritingAtPath(outputPath) ;
        outputFile = aFile ;
        free(outputPath) ;
    }
    
    xTileSize = 256 ;
    yTileSize = 256 ;
    fileTile = allocTileToolForFilesOfType(inputFile, outputFile, "float") ;
    M = (float **)initTileToolWithSizes(fileTile, xTileSize, yTileSize, 1, 1) ;
    
    for (yTileIndex = 0; yTileIndex < fileTile->yTileNumber; yTileIndex++) {
        for (xTileIndex = 0; xTileIndex < fileTile->xTileNumber; xTileIndex++) {
            readTileAtIndexes(fileTile, xTileIndex, yTileIndex) ;
            for (iY = 1; iY < yTileSize - 1; iY++) {
                for (iX = 1; iX < yTileSize - 1; iX++) {
                    M[iY][iX] = (M[iY][iX + 1] - M[iY][iX - 1]) / 2 ;
                }
            }
            writeTile(fileTile) ;
        }
    }
    
    return(outputFile) ;
}

/* This function multiplies a float file by a char mask, provided the value of the file is lower than a given threshold */
/* The aim is creatig a new mask from a given one, unmasking point above a given coherence threshold */
/* If maskFilePath is NULL, input file (coherence) itself is set to zero where lower to threshold and saved at destination path */
void maskFloatFileIfLowerThanThreshold(char *filePath1, char *maskFilePath, char *outputPath, float threshold)
{
    char inPlace, *mask ;
    size_t iX, iB ;
    float *data1 ;
    size_t nBlocs, lastBlocSize, blocSize ;
    rawFileDescriptor *file1, *file2 = NULL, *outputFile = NULL ;
    
    if((file1 = openRawFileForReadingAndWritingAtPath(filePath1)) == NULL) {
        perror("rawFileManipulation: maskFloatFileIfLowerThanThreshold: Failed to open float file") ;
        return ;
    }
    file1->typeSize = 4 ;
    
    if (maskFilePath) {
        if((file2 = openRawFileForReadingAtPath(maskFilePath)) == NULL) {
            perror("rawFileManipulation: maskFloatFileIfLowerThanThreshold: Failed to open mask file") ;
            return ;
        }
        file2->typeSize = 1 ;        
        if (file1->fileLength != 4 * file2->fileLength) {
            perror("rawFileManipulation: maskFloatFileIfLowerThanThreshold: Float file and mask do no have same dimensions") ;
            return ;
        }
    }
    
    inPlace = _IN_PLACE_ ;
    if (outputPath) {
        inPlace = 0 ;
        outputFile = openRawFileForWritingAtPath(outputPath) ;
    }
    
    data1 = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    if (maskFilePath) {
        mask = vectorOfType(0, _BUFFER_SIZE_ - 1, file2->typeSize) ;
    }
    nBlocs = file1->fileLength / file1->typeSize / _BUFFER_SIZE_ ;
    lastBlocSize = file1->fileLength / file1->typeSize - nBlocs * _BUFFER_SIZE_  ;
    
    for (iB = 0; iB <= nBlocs; iB++) {
        blocSize = (iB == nBlocs)? lastBlocSize : _BUFFER_SIZE_ ;
        if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
            ase("floatFileArithmetics: failed to seek into input file 1") ;
        }
        if ((blocSize != fread(data1, file1->typeSize, blocSize, file1->f))) {
            ase("floatFileArithmetics: failed to read input file 1") ;
        }
        if (maskFilePath) {
            if (fseek(file2->f, iB * _BUFFER_SIZE_ * file2->typeSize, SEEK_SET)) {
                ase("floatFileArithmetics: failed to seek into mask file") ;
            }
            if ((blocSize != fread(mask, file2->typeSize, blocSize, file2->f))) {
                ase("floatFileArithmetics: failed to read mask file") ;
            }
            for (iX = 0; iX < blocSize; iX++) {
                data1[iX] = (data1[iX] < threshold && !mask[iX])? 0. : data1[iX] ;
            }
        }
        else {
            for (iX = 0; iX < blocSize; iX++) {
                data1[iX] = (data1[iX] < threshold)? 0. : data1[iX] ;
            }
        }

        if (inPlace) {
            if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
                ase("floatFileArithmetics: failed to seek into output file") ;
            }
            
            if ((blocSize != fwrite(data1, file1->typeSize, blocSize, file1->f))) {
                ase("floatFileArithmetics: failed to write into result file") ;
            }
        }
        else {
            if ((blocSize != fwrite(data1, file1->typeSize, blocSize, outputFile->f))) {
                ase("floatFileArithmetics: failed to into result file") ;
            }
        }
    }
    
    freeVectorOfType(data1, 0, file1->typeSize) ;
    freeRawFileDescriptor(file1) ;
    if (maskFilePath) {
        freeRawFileDescriptor(file2) ;
        freeVectorOfType(mask, 0, file1->typeSize) ;
    }
    if (!inPlace) {
        freeRawFileDescriptor(outputFile) ;
    }
    
}

/* This function sets result to floatVal where mask is set. */
/* It is to say when mask bits are set as requested by maskSelector value */
/* By defaukt, AMSTerEngine considers 0 as the non-masking value */
void maskFloatFileWithValue(char *filePath1, char *maskFilePath, char *outputPath, float floatVal, char unsigned maskSelector)
{
    char inPlace, *mask ;
    size_t iX, iB ;
    size_t nBlocs, lastBlocSize, blocSize ;
    float *data1, *result ;
    rawFileDescriptor *file1, *file2 = NULL, *outputFile = NULL ;
    
    if((file1 = openRawFileForReadingAndWritingAtPath(filePath1)) == NULL) {
        perror("Failed to open first file") ;
        return ;
    }
    file1->typeSize = 4 ;
    
    if((file2 = openRawFileForReadingAtPath(maskFilePath)) == NULL) {
        perror("Failed to open second file") ;
        return ;
    }
    file2->typeSize = 1 ;
    
    if (file1->fileLength != 4 * file2->fileLength) {
        perror("Float file and mask do no have same dimensions") ;
        return ;
    }
    
    inPlace = _IN_PLACE_ ;
    if (outputPath) {
        inPlace = 0 ;
        outputFile = openRawFileForWritingAtPath(outputPath) ;
    }
    
    data1 = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    mask = vectorOfType(0, _BUFFER_SIZE_ - 1, file2->typeSize) ;
    result = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    nBlocs = file1->fileLength / file1->typeSize / _BUFFER_SIZE_ ;
    lastBlocSize = file1->fileLength / file1->typeSize- nBlocs * _BUFFER_SIZE_  ;
    
    for (iB = 0; iB <= nBlocs; iB++) {
        blocSize = (iB == nBlocs)? lastBlocSize : _BUFFER_SIZE_ ;
        if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
            ase("floatFileArithmetics: failed to seek into input file 1") ;
        }
        if ((blocSize != fread(data1, file1->typeSize, blocSize, file1->f))) {
            ase("floatFileArithmetics: failed to read input file 1") ;
        }
        if (fseek(file2->f, iB * _BUFFER_SIZE_ * file2->typeSize, SEEK_SET)) {
            ase("floatFileArithmetics: failed to seek into mask file") ;
        }
        if ((blocSize != fread(mask, file2->typeSize, blocSize, file2->f))) {
            ase("floatFileArithmetics: failed to read mask file") ;
        }
        
        for (iX = 0; iX < blocSize; iX++) {
            result[iX] = (mask[iX] & maskSelector)? floatVal : data1[iX] ;
        }

        if (inPlace) {
            if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
                ase("floatFileArithmetics: failed to seek into output file") ;
            }
            
            if ((blocSize != fwrite(result, file1->typeSize, blocSize, file1->f))) {
                ase("floatFileArithmetics: failed to write into result file") ;
            }
        }
        else {
            if ((blocSize != fwrite(result, file1->typeSize, blocSize, outputFile->f))) {
                ase("floatFileArithmetics: failed to into result file") ;
            }
        }
    }
    
    freeVectorOfType(data1, 0, file1->typeSize) ;
    freeVectorOfType(mask, 0, file2->typeSize) ;
    freeVectorOfType(result, 0, file1->typeSize) ;
    freeRawFileDescriptor(file1) ;
    if (maskFilePath) {
        freeRawFileDescriptor(file2) ;
    }
    if (!inPlace) {
        freeRawFileDescriptor(outputFile) ;
    }
    
}





/* This function adapts a char mask with respect to a float file (coherence). */ 
/* Input mask is a three-level mask. */
/* If mask == 0, no masking is considered */
/* If mask == 1, masking is preserved whatever the coherence level (e.g. water bodies). */
/* If mask == 2, masking is set if coherence is lower than threshold and unset if higher. */
/* Saved mask is binary (0 or 1). */
char *maskThresholdingByFile(char *maskFilePath, char *coherenceFilePath, float threshold, size_t thresholdAll)
{
    char *outputMaskFilePath, aChar[2] ;
    char *maskIn, *maskOut ;
    float *coh ;
    size_t iX, iB ;
    size_t nBlocs, lastBlocSize, blocSize ;
    rawFileDescriptor *cohFile, *maskFile = NULL, *outputFile = NULL ;
    
    if((cohFile = openRawFileForReadingAndWritingAtPath(coherenceFilePath)) == NULL) {
        perror("Failed to open thresholding file") ;
        return NULL ;
    }
    cohFile->typeSize = 4 ;
    
    if((maskFile = openRawFileForReadingAtPath(maskFilePath)) == NULL) {
        if (!thresholdAll) {
            perror("Failed to open mask file") ;
            return NULL ;
        }
        outputMaskFilePath = initStringWith2Strings(cohFile->directoryPath, "thresholdedSlantRangeMask") ;
    }
    else {
        maskFile->typeSize = 1 ;
        strncpy(aChar, maskFile->fileName, 1) ;
        convertStringToUppercase(aChar) ;
        outputMaskFilePath = initStringWith4Strings(maskFile->directoryPath, "thresholded", aChar, maskFile->fileName + 1) ;

        if (cohFile->fileLength != 4 * maskFile->fileLength) {
            perror("Float file and mask do no have same dimensions") ;
            return NULL ;
        }
    }
    
    if((outputFile = openRawFileForWritingAtPath(outputMaskFilePath)) == NULL) {
        perror("Failed to open output mask file") ;
        return NULL ;
    }
    
    
    coh = vectorOfType(0, _BUFFER_SIZE_ - 1, cohFile->typeSize) ;
    maskIn = vectorOfType(0, _BUFFER_SIZE_ - 1, 1) ;
    maskOut = vectorOfType(0, _BUFFER_SIZE_ - 1, 1) ;
    nBlocs = cohFile->fileLength / cohFile->typeSize / _BUFFER_SIZE_ ;
    lastBlocSize = cohFile->fileLength / cohFile->typeSize - nBlocs * _BUFFER_SIZE_  ;
    
    for (iB = 0; iB <= nBlocs; iB++) {
        blocSize = (iB == nBlocs)? lastBlocSize : _BUFFER_SIZE_ ;
        if (fseek(cohFile->f, iB * _BUFFER_SIZE_ * cohFile->typeSize, SEEK_SET)) {
            ase("floatFileArithmetics: maskThresholding: failed to seek into thresholding file") ;
        }
        if ((blocSize != fread(coh, cohFile->typeSize, blocSize, cohFile->f))) {
            ase("maskThresholding: failed to read input thresholding file") ;
        }

        if (maskFile) {
            if (fseek(maskFile->f, iB * _BUFFER_SIZE_ * maskFile->typeSize, SEEK_SET)) {
                ase("maskThresholding: failed to seek into mask file") ;
            }
            if ((blocSize != fread(maskIn, maskFile->typeSize, blocSize, maskFile->f))) {
                ase("maskThresholding: failed to read mask file") ;
            }
        }
        
        for (iX = 0; iX < blocSize; iX++) {
            if (thresholdAll) {
                maskOut[iX] = (maskIn[iX] & 0b00000001)? 1 : (coh[iX] < threshold)? 1 : 0 ;
            }
            else {
                maskOut[iX] = (maskIn[iX] & 0b00000001)? 1 : (maskIn[iX] & 0b00000010)? ((coh[iX] < threshold)? 1 : 0): 0 ;
            }
        }

        if ((blocSize != fwrite(maskOut, 1, blocSize, outputFile->f))) {
            ase("maskThresholding: failed to write into result file") ;
        }
    }
    
    freeVectorOfType(coh, 0, cohFile->typeSize) ;
    freeVectorOfType(maskIn, 0, 1) ;
    freeVectorOfType(maskOut, 0, 1) ;
    freeRawFileDescriptor(cohFile) ;
    freeRawFileDescriptor(maskFile) ;
    freeRawFileDescriptor(outputFile) ;  

    return (outputMaskFilePath) ;  
}


/* Invert binary mask */
void invertBinaryMask(char *filePath1, char *outputPath)
{
    char inPlace ;
    char *data1 ;
    size_t iX, iB ;
    size_t nBlocs, lastBlocSize, blocSize ;
    rawFileDescriptor *file1, *outputFile = NULL ;

    if((file1 = openRawFileForReadingAndWritingAtPath(filePath1)) == NULL) {
        perror("Failed to open first file") ;
        return ;
    }
    file1->typeSize = 1 ;

    inPlace = _IN_PLACE_ ;
    if (outputPath) {
        inPlace = 0 ;
        outputFile = openRawFileForWritingAtPath(outputPath) ;
    }

    data1 = vectorOfType(0, _BUFFER_SIZE_ - 1, file1->typeSize) ;
    nBlocs = file1->fileLength / file1->typeSize / _BUFFER_SIZE_ ;
    lastBlocSize = file1->fileLength / file1->typeSize - nBlocs * _BUFFER_SIZE_  ;

    for (iB = 0; iB <= nBlocs; iB++) {
        blocSize = (iB == nBlocs)? lastBlocSize : _BUFFER_SIZE_ ;
        if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
            ase("invertBinaryMask: failed to seek into input file") ;
        }
        if ((blocSize != fread(data1, file1->typeSize, blocSize, file1->f))) {
            ase("invertBinaryMask: failed to read input file") ;
        }

        for (iX = 0; iX < blocSize; iX++) {
            data1[iX] = (data1[iX])? 0 : 1 ;
        }
        if (inPlace) {
            if (fseek(file1->f, iB * _BUFFER_SIZE_ * file1->typeSize, SEEK_SET)) {
                ase("invertBinaryMask: failed to seek into output file") ;
            }

            if ((blocSize != fwrite(data1, file1->typeSize, blocSize, file1->f))) {
                ase("invertBinaryMask: failed to write into result file") ;
            }
        }
        else {
            if ((blocSize != fwrite(data1, file1->typeSize, blocSize, outputFile->f))) {
                ase("invertBinaryMask: failed to into result file") ;
            }
        }
    }

    freeVectorOfType(data1, 0, file1->typeSize) ;
    freeRawFileDescriptor(file1) ;
    if (!inPlace) {
        freeRawFileDescriptor(outputFile) ;
    }
}

/* As its name state it, this function will crop a file based on its aoi if defined in the rawFileDescriptor. */
/* It is the file on disk that will be cropped. Not the data contained within the structure */
void cropRawFile(rawFileDescriptor *aFile)
{
    char *tempFilePath ;
    int xMin, xMax, yMin, yMax, xDim, yDim, iY ;
    size_t xCroppedDim;
    quadrilateral *aoi ;
    rawFileDescriptor *tempFile ;
    void *buffer ;

    if (!fileExistsAtPath(aFile->accessPath) || !aFile->aoi || !aFile->typeSize) {
        return ;
    }
    xDim = aFile->xDim ;
    yDim = aFile->yDim ;
    aoi = aFile->aoi ;

    xMin = aoi->P[0].x ;
    if (xMin < 0 || xMin > xDim - 1) {
        return ;
    }
    xMax = aoi->P[2].x ;
    if (xMax < 0 || xMax > xDim - 1 || xMax < xMin) {
        return ;
    }
    
    yMin = aoi->P[0].y ;
    if (yMin < 0 || yMin > yDim - 1) {
        return ;
    }
    yMax = aoi->P[2].y ;
    if (yMax < 0 || yMax > yDim - 1 || yMax < yMin) {
        return ;
    }
    xCroppedDim = xMax - xMin + 1 ;

    buffer = malloc(xCroppedDim * aFile->typeSize) ;
    
    tempFilePath = initStringWith2Strings(aFile->directoryPath, "/.tempFile") ;
    tempFile = openRawFileForWritingAtPath(tempFilePath) ;
    fseek(aFile->f, yMin * xDim + xMin, SEEK_SET) ;
    for ( iY = 0; iY < yMax - yMin + 1; iY++) {
        fread(buffer, aFile->typeSize, xCroppedDim, aFile->f) ;
        fwrite(buffer, aFile->typeSize, xCroppedDim, tempFile->f) ;
        fseek(aFile->f, (xDim - xCroppedDim) * aFile->typeSize, SEEK_CUR) ;
    }
    closeRawFile(aFile) ;
    unlink(aFile->accessPath) ;
    closeRawFile(tempFile) ;
    rename(aFile->accessPath, tempFile->accessPath) ;
    freeRawFileDescriptor(aFile) ;
    freeRawFileDescriptor(tempFile) ;
    free(buffer) ;
}

