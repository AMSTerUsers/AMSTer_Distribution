
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  interpolCZT.c
 *  envisatLevel0DataReader
 *
 *  Created by Dominique Derauw on 10/06/05.
 *  Copyright 2005 Dominique derauw. All rights reserved.
 *
 */

/* update of Interpolation tool to be adapted to the current fft home made libraries */

#include "interpolCZT.h"

CZTInterpolator	*initInterpolator(int len, double A)
{
	CZTInterpolator	*V ;

	if((V = (CZTInterpolator *)calloc (1, sizeof(CZTInterpolator))) == NULL) {	
		perror("Erreur d'allocation sur StrInterpol") ;
		exit(-1) ;
	}

	if((V->h = (complexFloat *)calloc ((int unsigned)(2 * len), sizeof(complexFloat))) == NULL) {	
		perror("Erreur d'allocation sur ptr_h") ;
		exit(-1) ;
	}

	if((V->i = (complexFloat *)calloc ((int unsigned)len, sizeof(complexFloat))) == NULL) {	
		sprintf (ertex, "Erreur d'allocation sur ptr_i") ;
		ase (ertex) ;
	}

	if((V->g = (complexFloat *)calloc ((int unsigned)(2 * len), sizeof(complexFloat))) == NULL) {	
		sprintf (ertex, "Erreur d'allocation sur ptr_g") ;
		ase (ertex) ;
	}

	V->len = len ;
	V->doubleLengthFFT = initFFT(2*len, 1, ALONGX) ;
	V->simpleLengthFFT = initFFT(len, 1, ALONGX) ;

	V->filter = NULL ;
	
	updateInterpolator(V, A) ;
	
 	return V ;
}

void updateInterpolator(CZTInterpolator *V, double A)
{
	int j, len, Index ;
	double ch, sh ;
	
	len = V->len ;
	V->A = A ;
       
	/* Génération des fonctions h et i */
	/* ------------------------------- */
	for(j=0; j<len; j++) {
		ch = cos((double)PI * A * j * j / len) ;
		sh = sin((double)PI * A * j * j / len) ;
		(V->h)[j].r = (V->i)[j].r = (float)ch ;
		(V->h)[j].i = (float)(-sh) ;
		(V->i)[j].i = (float)sh ;
	}

	Index = len ;
	for(j=len; j>0; j--, Index++) {
		ch = cos((double) PI * A * j * j / len) ;
		sh = sin((double)-PI * A * j * j / len) ;
		(V->h)[Index].r = (float)ch ;
		(V->h)[Index].i = (float)sh ;
	}

	fftX(FORWARD_FFT, V->h, V->doubleLengthFFT) ;
}

/* Interpolation complexe */
/* ______________________ */

void	CZTInterpolation(complexFloat *u, double A, double B, CZTInterpolator *V)
{
	int		j, len ;
	float   cg, sg ;
	complexFloat	tc ; 
	
	/* Interpolation proprement dite. */
	/* ______________________________ */
	
	if(A != V->A)
		updateInterpolator(V, A) ;
	len = V->len ;
	
	for(j = len; j < (2 * len); j++) {
		(V->g)[j].r = (V->g)[j].i = 0. ; 
	}
	
	fftX(FORWARD_FFT, u, V->simpleLengthFFT) ;	
	if (V->filter) {
		for(j=0; j<len; j++) {
			u[j] = mRC(u[j], V->filter[j]) ;
		}
	}

	for(j=0; j<len; j++) {
		cg = (float)cos(((double)PI * j/len) * (A * j + 2 * B)) ;
		sg = (float)sin(((double)PI * j/len) * (A * j + 2 * B)) ;
		(V->g)[j].r = cg * u[j].r - sg * u[j].i ;
		(V->g)[j].i = sg * u[j].r + cg * u[j].i ;
	}
	fftX(FORWARD_FFT, V->g, V->doubleLengthFFT);
	
	
	for(j=0; j<2*len; j++) {
		tc.r = (V->g)[j].r * (V->h)[j].r - (V->g)[j].i * (V->h)[j].i ;
		tc.i = (V->g)[j].i * (V->h)[j].r + (V->g)[j].r * (V->h)[j].i ;
		(V->g)[j].r = tc.r ;
		(V->g)[j].i = tc.i ;
  	}
	fftX(INVERSE_FFT, V->g, V->doubleLengthFFT) ;
	
	for(j=0; j<len; j++)
	{
		u[j].r = (V->g)[j].r * (V->i)[j].r - (V->g)[j].i * (V->i)[j].i ;
		u[j].i = (V->g)[j].i * (V->i)[j].r + (V->g)[j].r * (V->i)[j].i ;
	}
}

void freeCZTInterpolator(CZTInterpolator *V)
{
	free(V->g) ;
	free(V->h) ;
	free(V->i) ;
	freeFFT(V->doubleLengthFFT) ;
	freeFFT(V->simpleLengthFFT) ;
	if (V->filter) {
		freeVectorFloat(V->filter, 0) ;
	}
	
	free(V) ;
}


float *allocAndInitApodizationFilterOfLength(int xDim, float alpha)
{
	int iX ;
	float *filter ;

	filter = vectorFloat(0, xDim - 1) ;
	for (iX = 0; iX < xDim; iX++) {
		filter[iX] = alpha - (1. - alpha) * cosf(TWOPI * (float)iX / (float)(xDim +  1)) ;
	}
	
	return (filter) ;
}


void allocAndInitCosineSumFilterInCZTInterpolator(CZTInterpolator *V, float alpha) 
{
	V->filter = allocAndInitApodizationFilterOfLength(V->len, alpha) ;
}