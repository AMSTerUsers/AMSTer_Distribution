
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  sortingRoutines.c
//  InSAR suite
//
//  Created by Dominique Derauw on 24/08/16.
//
//

#include "sortingRoutines.h"

/* Sorting routines allows sorting float vectors in ascending or descending orders with respect to the first vector sent */
/* Start index of each vector is one, not zero! */
/* Addapted from Recipice in C */

/* Sorting routine in descending order */
void	descendingSort(int n, float *vector)
{
    int		l, j, ir, i;
    float v ;
    
    l = (n>>1) + 1 ;
    ir = n ;
    for(;;) {
        if(l>1) {
            l-- ;
            v = vector[n + 1 - l] ;
        }
        else {
            v = vector[n + 1 - ir] ;
            vector[n + 1 - ir] = vector[n] ;
            if(--ir == 1) {
                vector[n] = v ;
                return ;
            }
        }
        i = l ;
        j = l<<1 ;
        while(j<=ir) {
            if((j<ir) && vector[n + 1 - j] < vector[n - j]) ++j ;
            if(v < vector[n + 1 - j]) {
                vector[n + 1 - i] = vector[n + 1 - j] ;
                j += (i=j) ;
            }
            else j = ir + 1 ;
        }
        vector[n + 1 - i] = v ;
    }
}

/* Sorting routine in ascending order */
void	ascendingSort(int n, float *vector)
{
    int		l, j, ir, i;
    float v ;
    
    l = (n >> 1) + 1 ;
    ir = n ;
    for(;;) {
        if(l>1) {
            l-- ;
            v = vector[l] ;
        }
        else {
            v = vector[ir] ;
            vector[ir] = vector[1] ;
            if(--ir == 1) {
                vector[1] = v ;
                return ;
            }
        }
        i = l ;
        j = l << 1 ;
        while(j <= ir) {
            if((j < ir) && vector[j] < vector[j + 1]) ++j ;
            if(v < vector[j]) {
                vector[i] = vector[j] ;
                j += (i=j) ;
            }
            else j = ir + 1 ;
        }
        vector[i] = v ;
    }
}

/* Sorting routine in descending order */
void	descendingSort3(int n, float *vector1, int *vector2, int *vector3)
{
    int		l, j, ir, i;
    float v1, v2, v3 ;
    
    l = (n>>1) + 1 ;
    ir = n ;
    for(;;) {
        if(l>1) {
            l-- ;
            v1 = vector1[n + 1 - l] ;
            v2 = vector2[n + 1 - l] ;
            v3 = vector3[n + 1 - l] ;
        }
        else {
            v1 = vector1[n + 1 - ir] ;
            v2 = vector2[n + 1 - ir] ;
            v3 = vector3[n + 1 - ir] ;
            vector1[n + 1 - ir] = vector1[n] ;
            vector2[n + 1 - ir] = vector2[n] ;
            vector3[n + 1 - ir] = vector3[n] ;
            if(--ir == 1) {
                vector1[n] = v1 ;
                vector2[n] = v2 ;
                vector3[n] = v3 ;
                return ;
            }
        }
        i = l ;
        j = l<<1 ;
        while(j<=ir) {
            if((j<ir) && vector1[n + 1 - j] < vector1[n - j]) ++j ;
            if(v1 < vector1[n + 1 - j]) {
                vector1[n + 1 - i] = vector1[n + 1 - j] ;
                vector2[n + 1 - i] = vector2[n + 1 - j] ;
                vector3[n + 1 - i] = vector3[n + 1 - j] ;
                j += (i=j) ;
            }
            else j = ir + 1 ;
        }
        vector1[n + 1 - i] = v1 ;
        vector2[n + 1 - i] = v2 ;
        vector3[n + 1 - i] = v3 ;
    }
}

/* Sorting routine in ascending order */
void	ascendingSort3(int n, float *vector1, int *vector2, int *vector3)
{
    int		l, j, ir, i;
    float v1, v2, v3 ;
    
    l = (n >> 1) + 1 ;
    ir = n ;
    for(;;) {
        if(l>1) {
            l-- ;
            v1 = vector1[l] ;
            v2 = vector2[l] ;
            v3 = vector3[l] ;
        }
        else {
            v1 = vector1[ir] ;
            v2 = vector2[ir] ;
            v3 = vector3[ir] ;
            vector1[ir] = vector1[1] ;
            vector2[ir] = vector2[1] ;
            vector3[ir] = vector3[1] ;
            if(--ir == 1) {
                vector1[1] = v1 ;
                vector2[1] = v2 ;
                vector3[1] = v3 ;
                return ;
            }
        }
        i = l ;
        j = l << 1 ;
        while(j <= ir) {
            if((j < ir) && vector1[j] < vector1[j + 1]) ++j ;
            if(v1 < vector1[j]) {
                vector1[i] = vector1[j] ;
                vector2[i] = vector2[j] ;
                vector3[i] = vector3[j] ;
                j += (i=j) ;
            }
            else j = ir + 1 ;
        }
        vector1[i] = v1 ;
        vector2[i] = v2 ;
        vector3[i] = v3 ;
    }
}



/* Divide & conquer home-made sorting routine  of int vector v[0 ; N-1] */
/* Sent vector is sorted in place in ascending or descending order */
/* An index vector is returned in order to allow sorting in the same way vectors associated to the sent one */
int *sortIntVect(int *v, int *index, int N, int flag) {
    int *vv ;
    int *iindex ;
    int i ;

    if (!index) {
        index = vectorInt(0, N - 1) ;
    }
    for (i = 0; i < N; i++) {   
        index[i] = i ;
    }
    
    vv = vectorInt(0, N - 1) ;
    iindex = vectorInt(0, N - 1) ;

    cutAndSortInt(v, vv, index, iindex, 0, N - 1, flag) ;
    
    freeVectorInt(vv, 0) ;
    freeVectorInt(iindex, 0) ;
    
    return (index) ;
}

int isIntGreaterOrEqualToInt(int val1, int val2)
{
    return((val1 >= val2)? 1 : 0) ;
}

int isIntLowerOrEqualToInt(int val1, int val2)
{
    return((val1 <= val2)? 1 : 0) ;
}

// Merge Function
void mergeAndSortInt(int *v, int *vv, int *index, int* iindex, int lowerIndex, int middleIndex, int upperIndex, int flag)
{
    int i, j, k;
    int (*testFunction)(int, int) ;

    if (flag == _ASCENDING_SORT_) {
        testFunction = isIntLowerOrEqualToInt ;
    }
    else {
        testFunction = isIntGreaterOrEqualToInt ;
    }
    

    for (i = lowerIndex; i <= upperIndex; i++) {
        vv[i] = v[i] ;
        iindex[i] = index[i] ;
    }

    k = lowerIndex ;
    i = lowerIndex ;
    j = middleIndex + 1 ;
    while (i <= middleIndex && j <= upperIndex) {
        if (testFunction(vv[i], vv[j])) {
            v[k] = vv[i] ;
            index[k] = iindex[i] ;
            i++ ;
        }
        else {
            v[k] = vv[j] ;
            index[k] = iindex[j] ;
           j++ ;
        }
        k++;
    }

    while (i <= middleIndex) {
        v[k] = vv[i];
        index[k] = iindex[i] ;
        i++ ;
        k++ ;
    }
    while (j <= upperIndex) {
        v[k] = vv[j];
        index[k] = iindex[j] ;
        j++;
        k++;
    }
}

void cutAndSortInt(int *v, int *vv, int *index, int* iindex, int lowerIndex, int upperIndex, int flag)
{
    int middleIndex ; 

    if (lowerIndex < upperIndex) {
        middleIndex = lowerIndex + (upperIndex - lowerIndex) / 2 ;
        cutAndSortInt(v, vv, index, iindex, lowerIndex, middleIndex, flag) ;
        cutAndSortInt(v, vv, index, iindex, middleIndex + 1, upperIndex, flag) ;
        mergeAndSortInt(v, vv, index, iindex, lowerIndex, middleIndex, upperIndex, flag) ;
    }
}


/* Divide & conquer home-made sorting routine of float vector v[0 ; N-1] */
/* Sent vector is sorted in place in ascending or descending order */
/* An index vector is returned in order to allow sorting in the same way vectors associated to the sent one */
int *sortFloatVector(float *v, int *index, int N, int flag) {
    int *iindex ;
    int i ;
    float *vv ;

    if (!index) {
        index = vectorInt(0, N - 1) ;
        for (i = 0; i < N; i++) {   
            index[i] = i ;
        }
    }
    
    vv = vectorFloat(0, N - 1) ;
    iindex = vectorInt(0, N - 1) ;

    cutAndSortFloat(v, vv, index, iindex, 0, N - 1, flag) ;
    
    freeVectorFloat(vv, 0) ;
    freeVectorInt(iindex, 0) ;
    
    return (index) ;
}

int isFloatGreaterOrEqualToFloat(float val1, float val2)
{
    return((val1 >= val2)? 1 : 0) ;
}

int isFloatLowerOrEqualToFloat(float val1, float val2)
{
    return((val1 <= val2)? 1 : 0) ;
}

// Merge Function
void mergeAndSortFloat(float *v, float *vv, int *index, int* iindex, int lowerIndex, int middleIndex, int upperIndex, int flag)
{
    int i, j, k;
    int (*testFunction)(float, float) ;

    if (flag == _ASCENDING_SORT_) {
        testFunction = isFloatLowerOrEqualToFloat ;
    }
    else {
        testFunction = isFloatGreaterOrEqualToFloat ;
    }
    

    for (i = lowerIndex; i <= upperIndex; i++) {
        vv[i] = v[i] ;
        iindex[i] = index[i] ;
    }

    k = lowerIndex ;
    i = lowerIndex ;
    j = middleIndex + 1 ;
    while (i <= middleIndex && j <= upperIndex) {
        if (testFunction(vv[i], vv[j])) {
            v[k] = vv[i] ;
            index[k] = iindex[i] ;
            i++ ;
        }
        else {
            v[k] = vv[j] ;
            index[k] = iindex[j] ;
           j++ ;
        }
        k++;
    }

    while (i <= middleIndex) {
        v[k] = vv[i];
        index[k] = iindex[i] ;
        i++ ;
        k++ ;
    }
    while (j <= upperIndex) {
        v[k] = vv[j];
        index[k] = iindex[j] ;
        j++;
        k++;
    }
}

void cutAndSortFloat(float *v, float *vv, int *index, int* iindex, int lowerIndex, int upperIndex, int flag)
{
    int middleIndex ; 

    if (lowerIndex < upperIndex) {
        middleIndex = lowerIndex + (upperIndex - lowerIndex) / 2 ;
        cutAndSortFloat(v, vv, index, iindex, lowerIndex, middleIndex, flag) ;
        cutAndSortFloat(v, vv, index, iindex, middleIndex + 1, upperIndex, flag) ;
        mergeAndSortFloat(v, vv, index, iindex, lowerIndex, middleIndex, upperIndex, flag) ;
    }
}



/* Divide & conquer home-made sorting routine of double vector v[0 ; N-1] */
/* Sent vector is sorted in place in ascending or descending order */
/* An index vector is returned in order to allow sorting in the same way vectors associated to the sent one */
int *sortDoubleVector(double *v, int *index, int N, int flag) {
    int *iindex ;
    int i ;
    double *vv ;

    if (!index) {
        index = vectorInt(0, N - 1) ;
    }
    for (i = 0; i < N; i++) {   
        index[i] = i ;
    }
    
    vv = vectorDouble(0, N - 1) ;
    iindex = vectorInt(0, N - 1) ;

    cutAndSortDouble(v, vv, index, iindex, 0, N - 1, flag) ;
    
    freeVectorDouble(vv, 0) ;
    freeVectorInt(iindex, 0) ;
    
    return (index) ;
}

int isDoubleGreaterOrEqualToDouble(double val1, double val2)
{
    return((val1 >= val2)? 1 : 0) ;
}

int isDoubleLowerOrEqualToDouble(double val1, double val2)
{
    return((val1 <= val2)? 1 : 0) ;
}

// Merge Function
void mergeAndSortDouble(double *v, double *vv, int *index, int* iindex, int lowerIndex, int middleIndex, int upperIndex, int flag)
{
    int i, j, k;
    int (*testFunction)(double, double) ;

    if (flag == _ASCENDING_SORT_) {
        testFunction = isDoubleLowerOrEqualToDouble ;
    }
    else {
        testFunction = isDoubleGreaterOrEqualToDouble ;
    }
    

    for (i = lowerIndex; i <= upperIndex; i++) {
        vv[i] = v[i] ;
        iindex[i] = index[i] ;
    }

    k = lowerIndex ;
    i = lowerIndex ;
    j = middleIndex + 1 ;
    while (i <= middleIndex && j <= upperIndex) {
        if (testFunction(vv[i], vv[j])) {
            v[k] = vv[i] ;
            index[k] = iindex[i] ;
            i++ ;
        }
        else {
            v[k] = vv[j] ;
            index[k] = iindex[j] ;
           j++ ;
        }
        k++;
    }

    while (i <= middleIndex) {
        v[k] = vv[i];
        index[k] = iindex[i] ;
        i++ ;
        k++ ;
    }
    while (j <= upperIndex) {
        v[k] = vv[j];
        index[k] = iindex[j] ;
        j++;
        k++;
    }
}

void cutAndSortDouble(double *v, double *vv, int *index, int* iindex, int lowerIndex, int upperIndex, int flag)
{
    int middleIndex ; 

    if (lowerIndex < upperIndex) {
        middleIndex = lowerIndex + (upperIndex - lowerIndex) / 2 ;
        cutAndSortDouble(v, vv, index, iindex, lowerIndex, middleIndex, flag) ;
        cutAndSortDouble(v, vv, index, iindex, middleIndex + 1, upperIndex, flag) ;
        mergeAndSortDouble(v, vv, index, iindex, lowerIndex, middleIndex, upperIndex, flag) ;
    }
}

/* String version */
int *sortStringVect(char **v, int *index, int N, int flag) 
{
    char **vv ;
    int *iindex ;
    int i ;

    if (!index) {
        index = vectorInt(0, N - 1) ;
    }
    for (i = 0; i < N; i++) {   
        index[i] = i ;
    }
    
    vv = calloc(N, sizeof(vv[0])) ;
    iindex = vectorInt(0, N - 1) ;

    cutAndSortStringVect(v, vv, index, iindex, 0, N - 1, flag) ;
    
    for (i = 0; i < N; i++) {
        free(vv[i]) ;
    }
    free(vv) ;
    freeVectorInt(iindex, 0) ;
    
    return (index) ;
}

int isStringGreaterOrEqualToString(char *string1, char *string2)
{
    return((strcmp(string1, string2) < 0)? 0 : 1) ;
}

int isStringLowerOrEqualToString(char *string1, char *string2)
{
    return((strcmp(string1, string2) > 0)? 0 : 1) ;
}

// Merge Function
void mergeAndSortStringVect(char **v, char **vv, int *index, int* iindex, int lowerIndex, int middleIndex, int upperIndex, int flag)
{
    int i, j, k;
    int (*testFunction)(char *, char *) ;

    if (flag == _ASCENDING_SORT_) {
        testFunction = isStringLowerOrEqualToString ;
    }
    else {
        testFunction = isStringGreaterOrEqualToString ;
    }
    

    for (i = lowerIndex; i <= upperIndex; i++) {
        if(vv[i]) {
            free(vv[i]) ;
        }
        vv[i] = initStringWithString(v[i]) ;
        iindex[i] = index[i] ;
    }

    k = lowerIndex ;
    i = lowerIndex ;
    j = middleIndex + 1 ;
    while (i <= middleIndex && j <= upperIndex) {
        free(v[k]) ;
        if (testFunction(vv[i], vv[j])) {
            v[k] = initStringWithString(vv[i]) ;
            index[k] = iindex[i] ;
            i++ ;
        }
        else {
            v[k] = initStringWithString(vv[j]) ;
            index[k] = iindex[j] ;
           j++ ;
        }
        k++;
    }

    while (i <= middleIndex) {
        free(v[k]) ;
        v[k] = initStringWithString(vv[i]) ;
        index[k] = iindex[i] ;
        i++ ;
        k++ ;
    }
    while (j <= upperIndex) {
        free(v[k]) ;
        v[k] = initStringWithString(vv[j]) ;
        index[k] = iindex[j] ;
        j++;
        k++;
    }
}

void cutAndSortStringVect(char **v, char **vv, int *index, int* iindex, int lowerIndex, int upperIndex, int flag)
{
    int middleIndex ; 

    if (lowerIndex < upperIndex) {
        middleIndex = lowerIndex + (upperIndex - lowerIndex) / 2 ;
        cutAndSortStringVect(v, vv, index, iindex, lowerIndex, middleIndex, flag) ;
        cutAndSortStringVect(v, vv, index, iindex, middleIndex + 1, upperIndex, flag) ;
        mergeAndSortStringVect(v, vv, index, iindex, lowerIndex, middleIndex, upperIndex, flag) ;
    }
}
