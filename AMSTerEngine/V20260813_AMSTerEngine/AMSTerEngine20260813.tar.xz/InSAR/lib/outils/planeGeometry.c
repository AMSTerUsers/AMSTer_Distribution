
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  planeGeometry.c
 *  initInSAR
 *
 *  Created by Dominique Derauw on 1/11/11.
 *  Copyright 2011 Dominique Derauw. All rights reserved.
 *
 */

#include "planeGeometry.h"

polygon *allocPolygon(int numberOfAngles)
{
	int	i ;
	polygon *aPolygon ;

    if((aPolygon = malloc(sizeof(polygon))) == NULL) {
		perror("Failed to allocate a polygon") ;
        exit(-1 );
    }
	aPolygon->N = numberOfAngles ;

    if((aPolygon->P = calloc(aPolygon->N, sizeof(aPolygon->P[0]))) == NULL) {
		perror("Failed to allocate summits of polygon") ;
        exit(-1 );
    }

    if((aPolygon->V = malloc(aPolygon->N * sizeof(double *))) == NULL) {
		perror("Failed to allocate summits of polygon") ;
        exit(-1 );
    }

	for(i = 0; i < aPolygon->N; i++)
		aPolygon->V[i] = (double *)&aPolygon->P[i].x ;

	return(aPolygon) ;
}

polygon *getCopyOfPolygon(polygon *aPolygon)
{
    int i ;
    polygon *polygonCopy ;

    polygonCopy = allocPolygon(aPolygon->N) ;
    for(i = 0; i < aPolygon->N; i++) {
        memcpy(polygonCopy->V[i], aPolygon->V[i], 2 * sizeof(aPolygon->V[0][0])) ;
    }

    return (polygonCopy) ;
}

coord2D *allocPoint(void)
{
    coord2D *aPoint ;

    aPoint = malloc(sizeof(coord2D)) ;
    aPoint->x = aPoint->y = 0 ;

    return (aPoint) ;
}

segment *allocSegment(void)
{
    return(allocPolygon(2)) ;
}

segment *allocTriangle(void)
{
    return(allocPolygon(3)) ;
}

quadrilateral *allocQuadrilateral(void)
{
    return(allocPolygon(4)) ;
}

void freePolygon(polygon *aPolygone)
{
    if (aPolygone->P) {
        free(aPolygone->P) ;
        aPolygone->P = NULL ;
    }
    if (aPolygone->V) {
        free(aPolygone->V) ;
        aPolygone->V = NULL ;
    }
	free(aPolygone) ;
}


void planeAffineTransformOfPoint(double *initialPoint, double *transformedPoint, double **usedAffineTransform)
{
    double xVal ;

    /* x2 = aX x1 + bX y1 + cX */
	/* y2 = aY x1 + bY y1 + cY */
	xVal = usedAffineTransform[0][0] * initialPoint[0] + usedAffineTransform[0][1] * initialPoint[1] + usedAffineTransform[0][2] ;
	transformedPoint[1] = usedAffineTransform[1][0] * initialPoint[0] + usedAffineTransform[1][1] * initialPoint[1] + usedAffineTransform[1][2] ;
    transformedPoint[0] = xVal ;
}

coord2D  *planeAffineTransformOfCoord2D(coord2D *initialPoint, coord2D *transformedPoint, double **usedAffineTransform)
{
    double xVal ;

    if (transformedPoint == NULL) {
        transformedPoint = initialPoint ;
    }

	/* x2 = aX x1 + bX y1 + cX */
	/* y2 = aY x1 + bY y1 + cY */
	xVal = usedAffineTransform[0][0] * initialPoint->x + usedAffineTransform[0][1] * initialPoint->y + usedAffineTransform[0][2] ;
	transformedPoint->y = usedAffineTransform[1][0] * initialPoint->x + usedAffineTransform[1][1] * initialPoint->y + usedAffineTransform[1][2] ;
    transformedPoint->x = xVal ;

    return (transformedPoint) ;
}

double **inversePlaneAffineTransform(double **initialTransform, double **inverseTransform)
{
	double determinant, tempVal ;

    if (inverseTransform == NULL) {
        inverseTransform = matrixDouble(0, 1, 0, 2) ;
    }
	determinant = initialTransform[0][0] * initialTransform[1][1] - initialTransform[1][0] * initialTransform[0][1] ;

	inverseTransform[0][2] = (initialTransform[0][1] * initialTransform[1][2] - initialTransform[1][1] * initialTransform[0][2]) / determinant ;
	inverseTransform[1][2] = (initialTransform[1][0] * initialTransform[0][2] - initialTransform[0][0] * initialTransform[1][2]) / determinant ;
	tempVal = initialTransform[1][1] / determinant ;
	inverseTransform[1][1] = initialTransform[0][0] / determinant ;
    inverseTransform[0][0] = tempVal ;
	inverseTransform[0][1] = - initialTransform[0][1] / determinant ;
	inverseTransform[1][0] = - initialTransform[1][0] / determinant ;

    return (inverseTransform) ;

}

polygon *planeAffineTransformOfPolygon(polygon *initialPolygon, polygon *transformedPolygon, double **usedAffineTransform)
{
	int i ;
	polygon *targetPolygon ;

	if(transformedPolygon == NULL)
		targetPolygon = allocPolygon(initialPolygon->N) ;
	else
		targetPolygon = transformedPolygon ;

	for(i = 0; i < initialPolygon->N; i++)
		planeAffineTransformOfPoint(initialPolygon->V[i], targetPolygon->V[i], usedAffineTransform) ;

	return(targetPolygon) ;
}

/* Returns the circumbscribed rectangle to the given polygon */
polygon *circumscribedRectangleOfPolygon(polygon *aPolygone)
{
    int i ;
	polygon *targetRectangle ;

    targetRectangle = allocPolygon(4) ;

    targetRectangle->P[0].x = targetRectangle->P[2].x = aPolygone->P[0].x ;
    targetRectangle->P[0].y = targetRectangle->P[2].y = aPolygone->P[0].y ;
    for (i = 0; i < aPolygone->N; i++) {
        targetRectangle->P[0].x = (targetRectangle->P[0].x > aPolygone->P[i].x)? aPolygone->P[i].x : targetRectangle->P[0].x ;
        targetRectangle->P[0].y = (targetRectangle->P[0].y > aPolygone->P[i].y)? aPolygone->P[i].y : targetRectangle->P[0].y ;
        targetRectangle->P[2].x = (targetRectangle->P[2].x < aPolygone->P[i].x)? aPolygone->P[i].x : targetRectangle->P[2].x ;
        targetRectangle->P[2].y = (targetRectangle->P[2].y < aPolygone->P[i].y)? aPolygone->P[i].y : targetRectangle->P[2].y ;
    }
    targetRectangle->P[1].x = targetRectangle->P[2].x ;
    targetRectangle->P[1].y = targetRectangle->P[0].y ;
    targetRectangle->P[3].x = targetRectangle->P[0].x ;
    targetRectangle->P[3].y = targetRectangle->P[2].y ;

	return(targetRectangle) ;
}

double **allocUnitaryAffineTransform()
{
    double **T ;

    T = matrixDouble(0, 1, 0, 2) ;
    T[0][0] = T[1][1] = 1. ;

    return(T) ;
}

double **getCopyOfAffineTransform(double **T)
{
    double **T2 ;

    T2 = matrixDouble(0, 1, 0, 2) ;
    T2[0][0] = T[0][0] ;
    T2[0][1] = T[0][1] ;
    T2[0][2] = T[0][2] ;
    T2[1][0] = T[1][0] ;
    T2[1][1] = T[1][1] ;
    T2[1][2] = T[1][2] ;

    return(T2) ;
}

char isAffineTransformUnitary(double **T)
{
    char isIt ;

    isIt = 0 ;
    if (T[0][0] == 1 && T[1][1] == 1) {
        if (!T[0][1] && !T[0][2] && !T[1][0] && !T[1][2]) {
            isIt = 1 ;
        }
    }

    return (isIt) ;
}


char isAffineTransformNULL(double **T)
{
    char isIt ;

    isIt = 0 ;
    if (!T[0][0] && !T[1][1]) {
        if (!T[0][1] && !T[0][2] && !T[1][0] && !T[1][2]) {
            isIt = 1 ;
        }
    }

    return (isIt) ;
}



char isPointIncludedInPolygon(coord2D *aPoint, polygon *aPolygon)
{
    char test = 0 ;
    int i, j ;
    for (i = 0, j = aPolygon->N - 1; i < aPolygon->N; j = i++) {
        if (((aPolygon->P[i].y > aPoint->y) != (aPolygon->P[j].y > aPoint->y)) &&
            (aPoint->x < (aPolygon->P[j].x - aPolygon->P[i].x) * (aPoint->y - aPolygon->P[i].y) / (aPolygon->P[j].y - aPolygon->P[i].y) + aPolygon->P[i].x)) {
                test = !test;
        }
    }
    return test;
}


char polygonesIntersects(polygon *polygon1, polygon *polygon2)
{
    char test ;
    int NIntersects, i, j, k, l ;
    segment *seg1, *seg2 ;
    coord2D *aPoint ;

    seg1 = allocSegment() ;
    seg2 = allocSegment() ;
    NIntersects = 0 ;
    for (i = 0; i < polygon1->N; i++) {
        NIntersects += isPointIncludedInPolygon(&polygon1->P[i], polygon2) ;
    }
    for (i = 0; i < polygon2->N; i++) {
        NIntersects += isPointIncludedInPolygon(&polygon2->P[i], polygon1) ;
    }
    for (i = 0, k = polygon1->N - 1; i < polygon1->N; k = i++) {
        memcpy(seg1->V[0], polygon1->V[k], 2 * sizeof(seg1->V[0][0])) ;
        memcpy(seg1->V[1], polygon1->V[i], 2 * sizeof(seg1->V[0][0])) ;
        for (j = 0, l = polygon2->N - 1; j < polygon2->N; l = j++) {
            memcpy(seg2->V[0], polygon2->V[l], 2 * sizeof(seg2->V[0][0])) ;
            memcpy(seg2->V[1], polygon2->V[j], 2 * sizeof(seg2->V[0][0])) ;

            aPoint = segmentIntersect(seg1, seg2) ;
            if (aPoint) {
                free(aPoint) ;
                NIntersects++ ;
            }
        }
    }
    test = (NIntersects)? 1 : 0 ;


    freePolygon(seg1) ;
    freePolygon(seg2) ;

    return (test) ;
}

coord2D *segmentIntersect(segment *seg1, segment *seg2)
{
    char test ;
    double a1, a2, b1, b2, d1, d2, x, y  ;
    coord2D *intersectPoint = NULL ;

    d1 = (seg1->P[0].x - seg1->P[1].x) ;
    d2 = (seg2->P[0].x - seg2->P[1].x) ;
    a1 = (seg1->P[0].y - seg1->P[1].y) / d1 ;
    a2 = (seg2->P[0].y - seg2->P[1].y) / d2 ;
    b1 = (a1)? (seg1->P[0].x * seg1->P[1].y - seg1->P[1].x * seg1->P[0].y) / d1 : seg1->P[0].y ;
    b2 = (a2)? (seg2->P[0].x * seg2->P[1].y - seg2->P[1].x * seg2->P[0].y) / d2 : seg2->P[0].y ;

    test = 0 ;
    x = y = 0.0 ;
    if (d1 && d2) {
        x = (b2 - b1) / (a1 - a2) ;
        y = a1 * x + b1 ;

        test  = (x >= seg1->P[0].x && x <= seg1->P[1].x)? 1 : (x <= seg1->P[0].x && x >= seg1->P[1].x)? 1 : 0 ;
        test *= (x >= seg2->P[0].x && x <= seg2->P[1].x)? 1 : (x <= seg2->P[0].x && x >= seg2->P[1].x)? 1 : 0 ;
    }
    else {
        if (d1 == d2) {
            test = (seg1->P[0].x == seg2->P[0].x)? 1 : 0 ;
        }
        else {
            if (d1) {
                x = seg2->P[0].x ;
                y = a1 * x + b1 ;

                test  = (y >= seg2->P[0].y && y <= seg2->P[1].y)? 1 : (y <= seg2->P[0].y && y >= seg2->P[1].y)? 1 : 0 ;
                test *= (x >= seg1->P[0].x && x <= seg1->P[1].x)? 1 : (x <= seg1->P[0].x && x >= seg1->P[1].x)? 1 : 0 ;
            }
            else {
                x = seg1->P[0].x ;
                y = a2 * x + b2 ;

                test  = (y >= seg1->P[0].y && y <= seg1->P[1].y)? 1 : (y <= seg1->P[0].y && y >= seg1->P[1].y)? 1 : 0 ;
                test *= (x >= seg2->P[0].x && x <= seg2->P[1].x)? 1 : (x <= seg2->P[0].x && x >= seg2->P[1].x)? 1 : 0 ;
            }
        }
    }

    if (test) {
        intersectPoint = allocPoint() ;
        intersectPoint->x = x ;
        intersectPoint->y = y ;
    }
    return(intersectPoint) ;
}


double **combinedAffineTransform(double **T2, double **T1)
{
    double **T ;

    T = matrixDouble(0, 1, 0, 2) ;

    T[0][0] = T2[0][0] * T1[0][0] + T2[0][1] * T1[1][0] ;
    T[0][1] = T2[0][0] * T1[0][1] + T2[0][1] * T1[1][1] ;
    T[0][2] = T2[0][0] * T1[0][2] + T2[0][1] * T1[1][2] + T2[0][2] ;

    T[1][0] = T2[1][0] * T1[0][0] + T2[1][1] * T1[1][0] ;
    T[1][1] = T2[1][0] * T1[0][1] + T2[1][1] * T1[1][1] ;
    T[1][2] = T2[1][0] * T1[0][2] + T2[1][1] * T1[1][2] + T2[1][2] ;

    return (T) ;
}

coord2D *getCentreOfPolygon(polygon *aoi)
{
    int i ;
    coord2D *centralPoint ;

    centralPoint = allocPoint() ;
    for (i = 0; i < aoi->N; i++) {
        centralPoint->x += aoi->P->x ;
        centralPoint->y += aoi->P->y ;
    }
    centralPoint->x /= aoi->N ;
    centralPoint->y /= aoi->N ;

    return(centralPoint) ;
}

double EuclidianDistanceBetween2DPoints(coord2D *p1, coord2D *p2)
{
    return (sqrt(pow(p1->x - p2->x, 2) + pow(p1->y - p2->y, 2))) ;
}
