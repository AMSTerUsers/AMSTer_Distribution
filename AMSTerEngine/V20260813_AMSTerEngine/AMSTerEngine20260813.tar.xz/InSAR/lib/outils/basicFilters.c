
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  basicFilters.c
//  biasedCoherenceEstimation
//
//  Created by Dominique Derauw on 24/08/16.
//
//

#include "basicFilters.h"


/* Median Filtering of a float file. */
/* Sent tileTool must be allocated for input and output files. */
/* Consequently, allocTileToolForFilesOfType must have been run first. */
/* Initialization will be performed taking into account box filter size. */
/* Filter size must be odd. If not, sizes will be converted to nex odd value. */
/* For the moment, we only consider float images */
void medianFilter(tileTool *aTileTool, int unsigned xFilterSize, int unsigned yFilterSize)
{
    int unsigned xTileIndex, yTileIndex ;
    int unsigned xTileSize, yTileSize ;
    int unsigned iX, iY ;
    int unsigned iXFiltre, iYFiltre, indexFiltre, filterSize ;
    float **tile, **localTile ;
    float *medianFilterVector ;
    
    /* Filter sizes must be odd */
    xFilterSize = 2 * (xFilterSize / 2) + 1 ;
    yFilterSize = 2 * (yFilterSize / 2) + 1 ;
    filterSize = xFilterSize * yFilterSize ;
    medianFilterVector = vectorFloat(0, xFilterSize * yFilterSize - 1) ;
    
    /* Initialize tile size to fit within image */
    xTileSize = _X_FILTER_TILE_SIZE_ ;
    while (xTileSize > aTileTool->xDimIn) {
        xTileSize /= 2 ;
    }
    yTileSize = _Y_FILTER_TILE_SIZE_ ;
    while (yTileSize > aTileTool->yDimIn) {
        yTileSize /= 2 ;
    }
    
    initTileToolWithSizes(aTileTool, xTileSize, yTileSize, xFilterSize + 1, yFilterSize + 1) ;
    setMirroringForTileTool(aTileTool) ;
    localTile = matrixFloat(0, yTileSize - 1, 0, xTileSize - 1) ;
    
    for (yTileIndex = 0; yTileIndex < aTileTool->yTileNumber; yTileIndex++) {
        for (xTileIndex = 0; xTileIndex < aTileTool->xTileNumber; xTileIndex++) {
            tile = (float **)readTileAtIndexes(aTileTool, xTileIndex, yTileIndex) ;
            
            for (iY = 0; iY < yTileSize - yFilterSize; iY++) {
                for (iX = 0; iX < xTileSize - xFilterSize; iX++) {
                    indexFiltre = 0 ;
                    for (iYFiltre = 0; iYFiltre < yFilterSize; iYFiltre++) {
                        for (iXFiltre = 0; iXFiltre < xFilterSize; iXFiltre++) {
                            medianFilterVector[indexFiltre] = tile[iY + iYFiltre][iX + iXFiltre] ;
                            indexFiltre ++ ;
                        }
                    }
                    
                    ascendingSort(filterSize, medianFilterVector - 1) ;
                    localTile[iY + yFilterSize / 2][iX + xFilterSize / 2] = medianFilterVector[filterSize / 2] ;
                }
            }
            memcpy(tile[0], localTile[0], xTileSize * yTileSize * aTileTool->typeSize) ;
            writeTile(aTileTool) ;
        }
    }
    
    freeVectorFloat(medianFilterVector, 0) ;
    freeMatrixFloat(localTile, 0, 0) ;
}



/* Median Filtering of a float file. */
/* Sent raw file must contain file dimensions. */
/* File can contain NaN. They will be excluded from the filtering */
void medianFilterOfFloatFile(rawFileDescriptor *aFloatFile, int unsigned xFilterSize, int unsigned yFilterSize, float *excludedVal)
{
    char *aFilePath, isEven, paf ;
    int unsigned xTileIndex, yTileIndex ;
    int unsigned xTileSize, yTileSize ;
    int unsigned xFilterSize_2, yFilterSize_2, filterSize, filterSize_2 ;
    int unsigned iX, iY ;
    int unsigned iXFiltre, iYFiltre, indexFiltre ;
    int *index ;
    float **tile, **localTile ;
    float *medianFilterVector, median ;
    tileTool *aTileTool ;
    rawFileDescriptor *outputFile, *brol ;

    genFloatNaN() ;
    genFloatInf() ;
    
    aFilePath = initStringWith2Strings(aFloatFile->accessPath, ".mf") ;
    outputFile = openRawFileForReadingAndWritingAtPath(aFilePath) ;
    outputFile->xDim = aFloatFile->xDim ;
    outputFile->yDim = aFloatFile->yDim ;
    free(aFilePath) ;
    
    filterSize = xFilterSize * yFilterSize ;
    medianFilterVector = vectorFloat(0, filterSize - 1) ;
    index = vectorInt(0, filterSize - 1) ;
    
    /* Initialize tile size to fit within image */
    xTileSize = _X_FILTER_TILE_SIZE_ ;
    while (xTileSize > aFloatFile->xDim) {
        xTileSize /= 2 ;
    }
    yTileSize = _Y_FILTER_TILE_SIZE_ ;
    while (yTileSize > aFloatFile->yDim) {
        yTileSize /= 2 ;
    }
    
    
    /* half filter size */
    xFilterSize_2 = xFilterSize / 2 ;
    yFilterSize_2 = yFilterSize / 2 ;
    filterSize_2 = filterSize / 2 ;
    isEven = (2 * filterSize_2 == filterSize)? 1 : 0 ;
    
    aTileTool = allocTileToolForFilesOfType(aFloatFile, outputFile, "float") ;
    initTileToolWithSizes(aTileTool, xTileSize, yTileSize, xFilterSize_2, yFilterSize_2) ;
    localTile = matrixFloat(0, yTileSize - 1, 0, xTileSize - 1) ;
    
//    paf = 0 ;
//    brol = openRawFileForReadingAndWritingAtPath("/mnt/HDD1/brol") ;
    for (yTileIndex = 0; yTileIndex < aTileTool->yTileNumber; yTileIndex++) {
        for (xTileIndex = 0; xTileIndex < aTileTool->xTileNumber; xTileIndex++) {
            tile = (float **)readTileAtIndexes(aTileTool, xTileIndex, yTileIndex) ;
            memcpy(localTile[0], tile[0], xTileSize * yTileSize * __SIZEOF_FLOAT__) ;
            
            for (iY = 0; iY < yTileSize - yFilterSize + 1; iY++) {
                for (iX = 0; iX < xTileSize - xFilterSize + 1; iX++) {
                    indexFiltre = 0 ;
                    for (iYFiltre = 0; iYFiltre < yFilterSize; iYFiltre++) {
                        memcpy(medianFilterVector + indexFiltre, tile[iY + iYFiltre] + iX, xFilterSize * aTileTool->typeSize) ;
                        indexFiltre += xFilterSize ;
                    }

                    if (excludedVal) {
                        for (iXFiltre = 0; iXFiltre < filterSize; iXFiltre++) {
                            medianFilterVector[iXFiltre] = (medianFilterVector[iXFiltre] == *excludedVal)? floatNaN : medianFilterVector[iXFiltre] ;
                        }
                    }
                    for (iXFiltre = 0; iXFiltre < filterSize; iXFiltre++) {
                        medianFilterVector[iXFiltre] = (areFloatValsEquals(medianFilterVector[iXFiltre], floatNaN))? floatInf : medianFilterVector[iXFiltre] ;
                    }
                    
                    sortFloatVector(medianFilterVector, index, filterSize, _ASCENDING_SORT_) ;

                    isEven = iXFiltre = 0 ;
                    while (!areFloatValsEquals(medianFilterVector[iXFiltre], floatInf) && iXFiltre < filterSize) {
                        iXFiltre ++ ;
                        isEven = (isEven)? 0 : 1 ;
                    }
                    filterSize_2 = ++iXFiltre / 2 ;

                    median = (isEven)? (medianFilterVector[filterSize_2] + medianFilterVector[filterSize_2 + 1]) / 2 : medianFilterVector[filterSize_2] ;
                    median = (areFloatValsEquals(median, floatInf))? floatNaN : median ;
                    localTile[aTileTool->y0EA + iY][aTileTool->x0EA + iX] = median ;
                    
                }
            }
            memcpy(tile[0], localTile[0], xTileSize * yTileSize * __SIZEOF_FLOAT__) ;
            writeTile(aTileTool) ;
        }
    }
    
    freeVectorFloat(medianFilterVector, 0) ;
    freeVectorInt(index, 0) ;
    freeMatrixFloat(localTile, 0, 0) ;
}

void meanFilterOfFloatFile(rawFileDescriptor *aFloatFile, int unsigned xFilterSize, int unsigned yFilterSize, float *excludedVal)
{
    char *aFilePath, isEven, paf ;
    int unsigned xTileIndex, yTileIndex ;
    int unsigned xTileSize, yTileSize ;
    int unsigned xFilterSize_2, yFilterSize_2, filterSize, filterSize_2 ;
    int unsigned iX, iY ;
    int unsigned iXFiltre, iYFiltre, indexFiltre ;
    int *index ;
    float **tile, **localTile ;
    float *meanFilterVector, mean ;
    tileTool *aTileTool ;
    rawFileDescriptor *outputFile, *brol ;

    genFloatNaN() ;
    genFloatInf() ;
    
    aFilePath = initStringWith2Strings(aFloatFile->accessPath, ".meanFiltered") ;
    outputFile = openRawFileForReadingAndWritingAtPath(aFilePath) ;
    outputFile->xDim = aFloatFile->xDim ;
    outputFile->yDim = aFloatFile->yDim ;
    free(aFilePath) ;
    
    filterSize = xFilterSize * yFilterSize ;
    meanFilterVector = vectorFloat(0, filterSize - 1) ;
    index = vectorInt(0, filterSize - 1) ;
    
    /* Initialize tile size to fit within image */
    xTileSize = _X_FILTER_TILE_SIZE_ ;
    while (xTileSize > aFloatFile->xDim) {
        xTileSize /= 2 ;
    }
    yTileSize = _Y_FILTER_TILE_SIZE_ ;
    while (yTileSize > aFloatFile->yDim) {
        yTileSize /= 2 ;
    }
    
    
    /* half filter size */
    xFilterSize_2 = xFilterSize / 2 ;
    yFilterSize_2 = yFilterSize / 2 ;
    filterSize_2 = filterSize / 2 ;
    isEven = (2 * filterSize_2 == filterSize)? 1 : 0 ;
    
    aTileTool = allocTileToolForFilesOfType(aFloatFile, outputFile, "float") ;
    initTileToolWithSizes(aTileTool, xTileSize, yTileSize, xFilterSize_2, yFilterSize_2) ;
    localTile = matrixFloat(0, yTileSize - 1, 0, xTileSize - 1) ;
    
    for (yTileIndex = 0; yTileIndex < aTileTool->yTileNumber; yTileIndex++) {
        for (xTileIndex = 0; xTileIndex < aTileTool->xTileNumber; xTileIndex++) {
            tile = (float **)readTileAtIndexes(aTileTool, xTileIndex, yTileIndex) ;
            memcpy(localTile[0], tile[0], xTileSize * yTileSize * __SIZEOF_FLOAT__) ;
            
            for (iY = 0; iY < yTileSize - yFilterSize + 1; iY++) {
                for (iX = 0; iX < xTileSize - xFilterSize + 1; iX++) {
                    indexFiltre = 0 ;
                    for (iYFiltre = 0; iYFiltre < yFilterSize; iYFiltre++) {
                        memcpy(meanFilterVector + indexFiltre, tile[iY + iYFiltre] + iX, xFilterSize * aTileTool->typeSize) ;
                        indexFiltre += xFilterSize ;
                    }
                    
                    if (excludedVal) {
                        for (iXFiltre = 0; iXFiltre < filterSize; iXFiltre++) {
                            meanFilterVector[iXFiltre] = (meanFilterVector[iXFiltre] == *excludedVal)? floatNaN : meanFilterVector[iXFiltre] ;
                        }
                    }
                    
                    mean = 0 ;
                    indexFiltre = 0 ;
                    for (iXFiltre = 0; iXFiltre < filterSize; iXFiltre++) {
                        if (!areFloatValsEquals(meanFilterVector[iXFiltre], floatNaN)) {
                            mean += meanFilterVector[iXFiltre] ;
                            indexFiltre++ ;
                        }
                    }

                    if (indexFiltre) {
                        mean /= indexFiltre ;
                    }
                    else {
                        mean = floatNaN ;
                    }
                    
                    localTile[aTileTool->y0EA + iY][aTileTool->x0EA + iX] = mean ;
                    
                }
            }
            memcpy(tile[0], localTile[0], xTileSize * yTileSize * __SIZEOF_FLOAT__) ;
            writeTile(aTileTool) ;
        }
    }
    
    freeVectorFloat(meanFilterVector, 0) ;
    freeVectorInt(index, 0) ;
    freeMatrixFloat(localTile, 0, 0) ;
}