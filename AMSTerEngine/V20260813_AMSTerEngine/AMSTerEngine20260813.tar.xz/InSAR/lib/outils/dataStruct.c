
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  dataStruct.c
//  spectralCoh
//
//  Created by Dominique Derauw on 15/07/16.
//  Copyright (c) 2016 Dominique Derauw. All rights reserved.
//

#include "dataStruct.h"

dataStruct *allocDataStruct()
{
    dataStruct *dataDescriptor ;
    
    if((dataDescriptor = (dataStruct *)malloc(sizeof(dataStruct))) == NULL)
        ase("initMCA.c: Failed to allocate file structure") ;
    
    return (dataDescriptor) ;
}

void initDataStructOfTypeWithSizes(dataStruct *dataDescriptor, size_t type, int xDim, int yDim)
{
    dataDescriptor->rangeDim = xDim ;
    dataDescriptor->azimuthDim = yDim ;
    dataDescriptor->dataType = type ;
    
    allocAndInitMemoryForDataStruct(dataDescriptor) ;
}

void allocAndInitDataStructForRawFile(rawFileDescriptor *aFile)
{
    dataStruct *dataDescriptor ;

    dataDescriptor = allocDataStruct() ;
    
    dataDescriptor->rangeDim = aFile->xDim ;
    dataDescriptor->azimuthDim = aFile->yDim ;
    dataDescriptor->dataType = aFile->typeSize ;
    dataDescriptor->file = aFile ;
    
    allocAndInitMemoryForDataStruct(dataDescriptor) ;
}

void freeMermoryForDataStruct(dataStruct *anImage)
{
    free(anImage->data) ;
    free(anImage->indexedData) ;
    //	free(anImage) ;
}



/* Alloc and index image memory space */
void allocAndInitMemoryForDataStruct(dataStruct *anImage)
{
    int i, numberOfLinesPerBloc ;
    long blocSize, lineSize ;
    div_t qr ;
    
    /* Compute the line size */
    lineSize = anImage->rangeDim * anImage->dataType ;
    
    /* compute the number of line a bloc of _DATA_STRUCT_MAX_BLOC_SIZE_ size could contain */
    numberOfLinesPerBloc = (int)ldiv(_DATA_STRUCT_MAX_BLOC_SIZE_, anImage->rangeDim * anImage->dataType).quot ;
    
    /* If image fit in a single bloc, consider only image number of lines */
    numberOfLinesPerBloc = (numberOfLinesPerBloc > anImage->azimuthDim)? anImage->azimuthDim : numberOfLinesPerBloc ;
    anImage->numberOfLinesPerBloc = numberOfLinesPerBloc ;
    
    /* Compute number of blocs to be read, including the last one that can be incomplete */
    qr = div(anImage->azimuthDim, numberOfLinesPerBloc) ;
    anImage->numberOfBlocs = (qr.rem)? qr.quot + 1 : qr.quot ;
    
    /* Compute the corresponding bloc size */
    blocSize = anImage->rangeDim * anImage->dataType * numberOfLinesPerBloc ;
    
    /* Allocating dedicated memory space */
    if((anImage->data = malloc(blocSize)) == NULL)
        ase("Failed to allocate memory space for input/output data");
    
    /* Indexing memory for matrix adressing of data */
    
    anImage->indexedData = malloc(numberOfLinesPerBloc * sizeof(void *)) ;
    for (i = 0; i < numberOfLinesPerBloc; i++) {
        *(anImage->indexedData + i) = anImage->data + i * lineSize ;
    }
}
