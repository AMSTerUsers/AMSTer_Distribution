
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  fonctionPolynome.c
 *  georef
 *
 *  Created by Dominique Derauw on Thu Feb 21 2002.
 *  Copyright (c) 2001 Dominique Derauw All rights reserved.
 *
 */

#include "pourtous.h"
#include "polynomials.h"
#include "vectors.h"

xPolynomial *allocXPolynomialOfOrder(int N) 
{
	xPolynomial	*fX ;
	
    if((fX = malloc(sizeof(xPolynomial))) == NULL) {
        ase("Failed to allocate a polynomial") ;
        exit(-1) ;
    }
	fX->order = N ;
	fX->coefs = vectorDouble(0, N) ;
	
	return fX ;
}


double yValForPolynomial(xPolynomial *fX, double x) 
{
	int i ;
	double y ;
	
	y = 0 ;
	for(i = 0; i <= fX->order; i++)
		y += fX->coefs[i] * pow(x, (double)i) ;
	
	return y ;
}

void freeXPolynomial(xPolynomial *fX)
{
	freeVectorDouble(fX->coefs, 0) ;
	free(fX) ;
}
