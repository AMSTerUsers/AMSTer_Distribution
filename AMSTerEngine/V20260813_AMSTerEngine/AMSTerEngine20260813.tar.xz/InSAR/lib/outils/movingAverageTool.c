
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  movingAverageTool.c
 *  decPol
 *
 *  Created by Dominique Derauw on 11/03/05.
 *  Copyright 2005 __MyCompanyName__. All rights reserved.
 *
 */

#include "movingAverageTool.h"

mAvObject *allocMovingAverageObject()
{
	mAvObject *target ;
	if((target = malloc(sizeof(mAvObject))) == NULL)
		ase("Cannot allocate movingAverage Object") ;
	return target ;
}

void initMovingAverageObject(char *stringType, int dimX1, int dimY1, int dimX2, int dimY2, mAvObject *target)
{
	target->averagingWindow.xMin = 0 ;
	target->averagingWindow.yMin = 0 ;
	target->averagingWindow.dimX = dimX1 ;
	target->averagingWindow.dimY = dimY1 ;
	target->norme = dimX1 * dimY1 ;

	target->inputRect.xMin = 0 ;
	target->inputRect.yMin = 0 ;
	target->inputRect.dimX = dimX2 ;
	target->inputRect.dimY = dimY2 ;
	
	target->outputRect.xMin = 0 ;
	target->outputRect.yMin = 0 ;
	target->outputRect.dimX = target->inputRect.dimX - target->averagingWindow.dimX + 1 ;
	target->outputRect.dimY = target->inputRect.dimY - target->averagingWindow.dimY + 1 ;
	
	sprintf(target->stringType, "%s", stringType) ;
	target->type = -1 ;
	
	if(!strcmp(stringType, "float")) {
		target->type = _REAL32_ID_ ;
		target->sizeOfType = sizeof(float) ;
		target->movingWindow = matrixFloat(-1, target->averagingWindow.dimY, 0, target->inputRect.dimX - 1) ;
		target->average = vectorFloat(0, target->outputRect.dimX - 1) ;
	}
	
	if(!strcmp(stringType, "complexFloat")) {
		target->type = _CPLX32_ID_ ;
		target->sizeOfType = sizeof(complexFloat) ;
		target->movingWindow = matrixComplexFloat(-1, target->averagingWindow.dimY, 0, target->inputRect.dimX - 1) ;
		target->average = vectorComplexFloat(0, target->outputRect.dimX - 1) ;
	}

	if(!strcmp(stringType, "double")) {
		target->type = _REAL64_ID_ ;
		target->sizeOfType = sizeof(double) ;
		target->movingWindow = matrixDouble(-1, target->averagingWindow.dimY, 0, target->inputRect.dimX - 1) ;
		target->average = vectorDouble(0, target->outputRect.dimX - 1) ;
	}

	if(!strcmp(stringType, "complexDouble"))  {
		target->type = _CPLX64_ID_ ;
		target->sizeOfType = sizeof(complexDouble) ;
		target->movingWindow = matrixComplexDouble(-1, target->averagingWindow.dimY, 0, target->inputRect.dimX - 1) ;
		target->average = vectorComplexDouble(0, target->outputRect.dimX - 1) ;
	}

	if(target->type == -1) ase("Wrong type for maving average object") ;
}

void addNextLineInMovingAverage(void *source, mAvObject *target)
{
	int		i ;
	float	**fTarget ;
	double	**dTarget ;
	complexFloat **cFTarget ;
	complexDouble **cDTarget ;
	void	*firstLine ;
	
	switch (target->type) {
	case _REAL32_ID_ :
		fTarget = ((float **)target->movingWindow) ;
		memcpy(fTarget[0], source, target->inputRect.dimX * target->sizeOfType) ;
		for(i = 0; i < target->inputRect.dimX; i++)
			fTarget[-1][i] += fTarget[0][i] - fTarget[target->averagingWindow.dimY][i] ;
		
		firstLine = fTarget[target->averagingWindow.dimY] ;
		for(i = target->averagingWindow.dimY ; i > 0; i--)
			fTarget[i] = fTarget[i - 1] ;
		fTarget[0] = (float *)firstLine ;
		break ;
		
	case _CPLX32_ID_ :  
		cFTarget = (complexFloat **)target->movingWindow ;
		memcpy(cFTarget[0], source, target->inputRect.dimX * target->sizeOfType) ;
		for(i = 0; i < target->inputRect.dimX; i++) {
			cFTarget[-1][i].r += cFTarget[0][i].r - cFTarget[target->averagingWindow.dimY][i].r ;
			cFTarget[-1][i].i += cFTarget[0][i].i - cFTarget[target->averagingWindow.dimY][i].i ;
		}
		
		firstLine = cFTarget[target->averagingWindow.dimY] ;
		for(i = target->averagingWindow.dimY ; i > 0; i--)
			cFTarget[i] = cFTarget[i - 1] ;
		cFTarget[0] = (complexFloat *)firstLine ;
		break ;
	
	case _REAL64_ID_ :  
		dTarget = ((double **)target->movingWindow) ;
		memcpy(dTarget[0], source, target->inputRect.dimX * target->sizeOfType) ;
		for(i = 0; i < target->inputRect.dimX; i++)
			dTarget[-1][i] += dTarget[0][i] - dTarget[target->averagingWindow.dimY][i] ;

		firstLine = dTarget[target->averagingWindow.dimY] ;
		for(i = target->averagingWindow.dimY ; i > 0; i--)
			dTarget[i] = dTarget[i - 1] ;
		dTarget[0] = (double *)firstLine ;
		break ;

	case _CPLX64_ID_ :  
		cDTarget = ((complexDouble **)target->movingWindow) ;
		memcpy(cDTarget[0], source, target->inputRect.dimX * target->sizeOfType) ;
		for(i = 0; i < target->inputRect.dimX; i++) {
			cDTarget[-1][i].r += cDTarget[0][i].r - cDTarget[target->averagingWindow.dimY][i].r ;
			cDTarget[-1][i].i += cDTarget[0][i].i - cDTarget[target->averagingWindow.dimY][i].i ;
		}

		firstLine = cDTarget[target->averagingWindow.dimY] ;
		for(i = target->averagingWindow.dimY ; i > 0; i--)
			cDTarget[i] = cDTarget[i - 1] ;
		cDTarget[0] = (complexDouble *)firstLine ;
		break ;
	}
}

void *getMovingAverage(mAvObject *target)
{
	int	i ;
	float	*fAverage, fVal ;
	double	*dAverage, dVal ;
	complexFloat *cFAverage, cFVal ;
	complexDouble *cDAverage, cDVal ;
	
	switch (target->type) {
	case _REAL32_ID_ :
		fVal = 0.0 ;
		fAverage = ((float *)target->average) ;
		for(i = 0; i < target->averagingWindow.dimX; i++) fVal += ((float **)target->movingWindow)[-1][i] ;
		
		for(i = 0; i < target->outputRect.dimX - 1; i++) {
			fAverage[i] = fVal / target->norme ;
			fVal += ((float **)target->movingWindow)[-1][i + target->averagingWindow.dimX] - ((float **)target->movingWindow)[-1][i] ;
		}
		fAverage[i] = fVal / target->norme ;

		break ;

	case _CPLX32_ID_ :
		cFVal.r = cFVal.i = 0.0 ;
		cFAverage = ((complexFloat *)target->average) ;
		for(i = 0; i < target->averagingWindow.dimX; i++) {
			cFVal.r += ((complexFloat **)target->movingWindow)[-1][i].r ;
			cFVal.i += ((complexFloat **)target->movingWindow)[-1][i].i ;
		}
		
		for(i = 0; i < target->outputRect.dimX - 1; i++) {
			cFAverage[i].r = cFVal.r / target->norme ;
			cFAverage[i].i = cFVal.i / target->norme ;
			cFVal.r += ((complexFloat **)target->movingWindow)[-1][i + target->averagingWindow.dimX].r - ((complexFloat **)target->movingWindow)[-1][i].r ;
			cFVal.i += ((complexFloat **)target->movingWindow)[-1][i + target->averagingWindow.dimX].i - ((complexFloat **)target->movingWindow)[-1][i].i ;
		}
		cFAverage[i].r = cFVal.r / target->norme ;
		cFAverage[i].i = cFVal.i / target->norme ;

		break ;

	case _REAL64_ID_ :
		dVal = 0.0 ;
		dAverage = ((double *)target->average) ;
		for(i = 0; i < target->averagingWindow.dimX; i++) dVal += ((double **)target->movingWindow)[-1][i] ;
		
		for(i = 0; i < target->outputRect.dimX - 1; i++) {
			dAverage[i] = dVal / target->norme ;
			dVal += ((double **)target->movingWindow)[-1][i + target->averagingWindow.dimX] - ((double **)target->movingWindow)[-1][i] ;
		}
		dAverage[i] = dVal / target->norme ;

		break ;

	case _CPLX64_ID_ :
		cDVal.r = cDVal.i = 0.0 ;
		cDAverage = ((complexDouble *)target->average) ;
		for(i = 0; i < target->averagingWindow.dimX; i++) {
			cDVal.r += ((complexDouble **)target->movingWindow)[-1][i].r ;
			cDVal.i += ((complexDouble **)target->movingWindow)[-1][i].i ;
		}
		
		for(i = 0; i < target->outputRect.dimX - 1; i++) {
			cDAverage[i].r = cDVal.r / target->norme ;
			cDAverage[i].i = cDVal.i / target->norme ;
			cDVal.r += ((complexDouble **)target->movingWindow)[-1][i + target->averagingWindow.dimX].r - ((complexDouble **)target->movingWindow)[-1][i].r ;
			cDVal.i += ((complexDouble **)target->movingWindow)[-1][i + target->averagingWindow.dimX].i - ((complexDouble **)target->movingWindow)[-1][i].i ;
		}
		cDAverage[i].r = cDVal.r / target->norme ;
		cDAverage[i].i = cDVal.i / target->norme ;

		break ;
	}
	
	return target->average ;
}

void freeMovingAverageObject(mAvObject *target)
{

	if(!strcmp(target->stringType, "float")) {
		freeMatrixFloat(target->movingWindow, -1, 0) ;
		freeVectorFloat(target->average, 0) ;
	}
	
	if(!strcmp(target->stringType, "complexFloat")) {
		freeMatrixComplexFloat(target->movingWindow, -1, 0) ;
		freeVectorComplexFloat(target->average, 0) ;
	}

	if(!strcmp(target->stringType, "double")) {
		freeMatrixDouble(target->movingWindow, -1, 0) ;
		freeVectorDouble(target->average, 0) ;
	}

	if(!strcmp(target->stringType, "complexDouble"))  {
		freeMatrixComplexDouble(target->movingWindow, -1, 0) ;
		freeVectorComplexDouble(target->average, 0) ;
	}
	free(target) ;
}