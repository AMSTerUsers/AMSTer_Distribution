
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  counters.c
 *  ersRAWReader
 *
 *  Created by Dominique Derauw on 7/09/06.
 *  Copyright 2006 Dominique Derauw All rights reserved.
 *
 */

#include "counters.h"


/* Little functions to create and display progress counters */

progressCounter *allocProgressCounter(void) 
{
	progressCounter *aProgressCounter ;
	
	if((aProgressCounter = malloc(sizeof(progressCounter))) == NULL)
		ase("Failed to allocate progress counter") ;
	return aProgressCounter ;
}

progressCounter *initProgressCounterWithMinMaxValue(int min, int max)
{
	progressCounter *aProgressCounter ;

	aProgressCounter = allocProgressCounter() ;
	aProgressCounter->output = stdout ;
	aProgressCounter->minIndex = min ;
	aProgressCounter->maxIndex = max ;
	aProgressCounter->gap = max-min ;
	aProgressCounter->formerValue = 0 ;
    aProgressCounter->displayIndex = 0 ;
	
	return aProgressCounter ;
}

void resetProgressCounter(progressCounter *aProgressCounter)
{
    aProgressCounter->formerValue = 0 ;
    aProgressCounter->displayIndex = 0 ;
}

int updateProgressCounterForIndex(progressCounter *p, int anIndex) 
{
	int percent ;
	
	p->currentIndex = anIndex ;
	percent = (p->gap)? 100 * (p->currentIndex - p->minIndex) / p->gap : 100;
	if(percent > p->formerValue) {
		if(!p->displayIndex) {
            fprintf(p->output, "\t") ;
        }
		fprintf(p->output, "%3d%% ", percent) ;
		fflush(p->output) ;
		p->formerValue = percent ;
        p->displayIndex++ ;
		if(p->displayIndex == 10) {
            fprintf(p->output, "\n") ;
            p->displayIndex = 0 ;
        }
	}
	
	return percent ;
}

int updatePointProgressCounterForIndex(progressCounter *p, int anIndex) 
{
	int fraction ;
	
	p->currentIndex = anIndex ;
	fraction = (p->gap)? 20 * (p->currentIndex - p->minIndex) / p->gap : 20 ;
	if(fraction > p->formerValue) {
		fprintf(p->output, ".") ;
		fflush(p->output) ;
		p->formerValue = fraction ;
		if(fraction == 20) fprintf(p->output, "\n") ;
	}
	
	return fraction ;
}

void freeProgressCounter(progressCounter *p) 
{
	free(p) ;
}
