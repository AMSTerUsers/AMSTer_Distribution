
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  byteSwap.c
 *  ersRAWReader
 *
 *  Created by Dominique Derauw on 6/09/06.
 *  Copyright 2006 Dominique Derauw. All rights reserved.
 *
 */

#include "byteSwap.h"

void swapByteStructOfType(void *aByteStruct, size_t byteSize)
{
    switch (byteSize) {
        case 2:
            swap2bytesStruct(aByteStruct) ;
            break;
            
        case 4:
            swap4bytesStruct(aByteStruct) ;
            break;
            
        case 8:
            swap8bytesStruct(aByteStruct) ;
            break;
            
        default:
            break;
    }
}

void swap2bytesStruct(void *a2bytesStruct)
{
	BE2BytesStruct *BEValue ;
	LE2BytesStruct LEValue ;
	
	BEValue = (BE2BytesStruct *)a2bytesStruct ; 
	LEValue.b1 = BEValue->b1 ;
	LEValue.b0 = BEValue->b0 ;
	
	memcpy(a2bytesStruct, &LEValue, 2) ;
}

void swapShort(short *aShort)
{
	swap2bytesStruct(aShort) ;
}


void swap4bytesStruct(void *a4bytesStruct)
{
	BE4BytesStruct *BEValue ;
	LE4BytesStruct LEValue ;
	
	BEValue = (BE4BytesStruct *)a4bytesStruct ; 
	LEValue.b3 = BEValue->b3 ;
	LEValue.b2 = BEValue->b2 ;
	LEValue.b1 = BEValue->b1 ;
	LEValue.b0 = BEValue->b0 ;
	
	memcpy(a4bytesStruct, &LEValue, 4) ;
}


void swapInt(int *anInt)
{
	swap4bytesStruct(anInt) ;
}


void swapFloat(float *aFloat)
{
	swap4bytesStruct(aFloat) ;
}

void swap8bytesStruct(void *a8bytesStruct)
{
	BE8BytesStruct *BEValue ;
	LE8BytesStruct LEValue ;
	
	BEValue = (BE8BytesStruct *)a8bytesStruct ; 
	LEValue.b7 = BEValue->b7 ;
	LEValue.b6 = BEValue->b6 ;
	LEValue.b5 = BEValue->b5 ;
	LEValue.b4 = BEValue->b4 ;
	LEValue.b3 = BEValue->b3 ;
	LEValue.b2 = BEValue->b2 ;
	LEValue.b1 = BEValue->b1 ;
	LEValue.b0 = BEValue->b0 ;
	
	memcpy(a8bytesStruct, &LEValue, 8) ;
}

void swapDouble(double *aDouble)
{
	swap8bytesStruct(aDouble) ;
}

void swapLongLong(long long *aLongLong)
{
	swap8bytesStruct(aLongLong) ;
}

void swapComplexShort(complexShort *aComplexShort)
{
	swap2bytesStruct(&(aComplexShort->r)) ;
	swap2bytesStruct(&(aComplexShort->i)) ;
}

void swapComplexFloat(complexFloat *aComplexFloat)
{
	swap4bytesStruct(&(aComplexFloat->r)) ;
	swap4bytesStruct(&(aComplexFloat->i)) ;
}

