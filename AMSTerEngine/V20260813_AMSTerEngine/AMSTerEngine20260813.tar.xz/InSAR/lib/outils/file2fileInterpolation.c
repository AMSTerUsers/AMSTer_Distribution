
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  file2fileInterpolation.c
//  cutAndZoomCSLImage
//
//  Created by Dominique Derauw on 17/03/16.
//  Copyright (c) 2016 Dominique Derauw. All rights reserved.
//

#include "file2fileInterpolation.h"

afineInterpolationParameters *allocAfineInterpolationParameters(void) 
{
    afineInterpolationParameters *params ;

    params = calloc(1, sizeof(params[0])) ;
    params->afineTransform = matrixDouble(0, 1, 0, 2) ;
    params->spectrumShift = matrixDouble(0, 1, 0, 1) ;

    return(params) ;
}

/* Attention! T here is a 4 X 3 matrix. It may be confusing. Sub matrix T[0-1][0-2] contains the affine transform. T[2][0-1] and T[3][0-1] contain x and y frequency shift and sampling in case spectrums are  not centred */


/* X dimension interpolation */
void	interpolComplexAlongXAxis(rawFileDescriptor *inputFile, double **transformCoefficients, rawFileDescriptor *outputFile, char withMirroring)
{
    char isUnitary ;
    int	i, j, lenX, lenX0, expLenX, xBorder, p, index ;
    int xDim, yDim ;
    long seekVal ;
    complexFloat	*aLign, *aNullLine ;
    double D, **T ;
    double frequencyShift, sampling, phaseFactor ;
    complexFloat *u, phasor ;
    CZTInterpolator *V ;
    progressCounter *aCounter ;
    
    xDim = inputFile->aoi->P[2].x - inputFile->aoi->P[0].x + 1 ;
    yDim = inputFile->aoi->P[2].y - inputFile->aoi->P[0].y + 1 ;
    
    lenX0 = ((int)(outputFile->xDim) < xDim)? xDim : (int)(outputFile->xDim) ;
    lenX = lenX0 ;
    ceil2(&lenX, &expLenX) ;
    xBorder = (lenX - lenX0)/2 ;
    
    aLign = vectorComplexFloat(0, lenX - 1) ;
    aNullLine = vectorComplexFloat(0, lenX - 1) ;
    
    /* Init interpolator */
    T = getCopyOfAffineTransform(transformCoefficients) ;

    T[0][1] /= T[1][1] ;
    T[0][0] -= T[0][1] * T[1][0] ;
    T[0][2] -= T[0][1] * T[1][2]  - (1. - T[0][0]) * xBorder ;
    
    isUnitary = (T[0][0] == 1. && T[0][1] == 0. && T[0][2] == 0.)? 1 : 0 ;
    
    u = NULL ;
    V = NULL ;
    aCounter = NULL ;
    if (!isUnitary) {
        printf("Interpolation along X axis\n") ;
        V = initInterpolator(lenX, T[0][0]) ;
        u = vectorComplexFloat(0, lenX) ;
        
        for(i = 0; i < lenX; i++)
            aNullLine[i].r = aNullLine[i].i = 0. ;
        
        aCounter = initProgressCounterWithMinMaxValue(0, yDim) ;
    }
    
    /* Frequency shift */
    frequencyShift = transformCoefficients[2][0] ;
    sampling = transformCoefficients[2][1] ;
    phaseFactor = PI ;
    if(sampling)
        phaseFactor = 2. * PI *(-frequencyShift / sampling + .5) ;
    
    seekVal = (inputFile->aoi->P[0].y * inputFile->xDim + inputFile->aoi->P[0].x) * sizeof(complexFloat) ;
    for(i = 0; i < yDim ; i++)
    {
        memcpy(aLign, aNullLine, lenX * sizeof(complexFloat)) ;
        fseek(inputFile->f, seekVal, SEEK_SET) ;
        fread ((complexFloat *)&aLign[xBorder], xDim, sizeof(complexFloat), inputFile->f) ;
        seekVal += inputFile->xDim * sizeof(complexFloat) ;
        
        if (!isUnitary) {
            if(withMirroring) {
                p = xBorder + xDim - 1 ;
                while(p < lenX) {
                    for(index = p + 1, j = 1; j < xDim; index++, j++)
                        if(index < lenX) {
                            aLign[index].r = aLign[p - j].r ;
                            aLign[index].i = aLign[p - j].i ;
                        }
                    p += xDim - 1 ;
                }
                p = xBorder ;
                while(p >= 0) {
                    for(index = p - 1, j = 1; j < xDim; index--, j++)
                        if(index >= 0) {
                            aLign[index].r = aLign[p + j].r ;
                            aLign[index].i = aLign[p + j].i ;
                        }
                    p -= xDim - 1 ;
                }
            }
            
            for(j=0; j<lenX; j++) {
                phasor.r = (float)cos((double)phaseFactor * j) ;
                phasor.i = (float)sin((double)phaseFactor * j) ;
                u[j] = mC(aLign[j], phasor) ;
            }
            
            D = T[0][1] * i + T[0][2] ;
            CZTInterpolation(u, T[0][0], D, V) ;
            
            for(j=0; j<lenX; j++)
            {
                phasor.r = (float)cos(-phaseFactor * (T[0][0]*j + D))/lenX ;
                phasor.i = (float)sin(-phaseFactor * (T[0][0]*j + D))/lenX ;
                aLign[j] = mC(phasor, u[j]) ;
            }
            updateProgressCounterForIndex(aCounter, i) ;
        }
        fwrite((complexFloat *)&aLign[xBorder], outputFile->xDim, sizeof(complexFloat), outputFile->f) ;
    }
    
    if (!isUnitary) {
        updateProgressCounterForIndex(aCounter, i) ;
        freeCZTInterpolator(V) ;
        freeVectorComplexFloat(u, 0) ;
        
    }
    freeVectorComplexFloat(aLign, 0) ;
    freeVectorComplexFloat(aNullLine, 0) ;
    freeMatrixDouble(T, 0, 0) ;
}

/* Y dimension interpolation */
void	interpolComplexAlongYAxis(rawFileDescriptor *inputFile, double **T, rawFileDescriptor *outputFile, char withMirroring)
{
    char isUnitary ;
    size_t	iUL, jUL ;
    int i, j, k, lenY, lenY0, expLenY, yBorder, p, index ;
    int	xDimBloc, xDimLastBloc, NBlocs, xIndex ;
    //	fpos_t fileShift ;
    long fileShift ;
    complexFloat	**aBloc, **aNullBloc ;
    double D ;
    double frequencyShift, sampling, phaseFactor ;
    complexFloat *u, phasor ;
    CZTInterpolator *V ;
    progressCounter *aCounter ;
    
    isUnitary = (T[1][0] == 0. && T[1][1] == 1 && T[1][2] == 0.)? 1 : 0 ;
    
    lenY0 = (outputFile->yDim < inputFile->yDim)? inputFile->yDim : outputFile->yDim ;
    lenY = lenY0 ;
    ceil2(&lenY, &expLenY) ;
    yBorder= (lenY - lenY0)/2 ;
    
    
    xDimBloc = _INTERPOL_MEM_MAX_SIZE_ / lenY / sizeof(complexFloat) ;
    NBlocs = inputFile->xDim / xDimBloc ;
    xDimLastBloc = inputFile->xDim - NBlocs * xDimBloc ;
    xDimBloc = (NBlocs)? xDimBloc : xDimLastBloc ;
    
    u = NULL ;
    V = NULL ;
    aCounter = NULL ;
    if (!isUnitary) {
        printf("\nInterpolation along Y axis\n") ;
        printf("lenY = %d\tyBorder = %d\n", lenY, yBorder) ;
        printf("xDimBloc = %d\txDimLastBloc = %d\n", xDimBloc, xDimLastBloc) ;
        printf("NBlocs = %d\txDimLastBloc = %d\n", NBlocs, xDimLastBloc) ;
        V = initInterpolator(lenY, T[1][1]) ;
        u = vectorComplexFloat(0, lenY) ;
        aCounter = initProgressCounterWithMinMaxValue(0, outputFile->xDim) ;
    }
    /*
     printf("Creating output file\n") ;
     aNullVector = vectorComplexFloat(0, outputFile->xDim - 1) ;
     for(i = 0; i < outputFile->yDim; i++) {
     fwrite((complexFloat *)aNullVector, outputFile->xDim, sizeof(complexFloat), outputFile->f) ;
     }
     fflush(outputFile->f) ;
     freeVectorComplexFloat(aNullVector, 0) ;
     */
    aBloc = (complexFloat **)matrixComplexFloat(0, lenY - 1, 0, xDimBloc - 1) ;
    aNullBloc = (complexFloat **)matrixComplexFloat(0, lenY - 1, 0, xDimBloc - 1) ;
    for(i = 0; i < lenY; i++) {
        for(j = 0; j < xDimBloc; j++) {
            aNullBloc[i][j].r = aNullBloc[i][j].i = 0. ;
        }
    }
    
    /* Frequency shift */
    frequencyShift = T[3][0] ;
    sampling = T[3][1] ;
    phaseFactor = PI ;
    if(sampling)
        phaseFactor = 2. * PI *(-frequencyShift / sampling + .5) ;
    
    for(k = 0; k <= NBlocs; k++) {
        xIndex = k * xDimBloc ;
        memcpy(aBloc[0], aNullBloc[0], xDimBloc * lenY * sizeof(complexFloat)) ;
        
        if(k == NBlocs) {
            xDimBloc = xDimLastBloc ;
        }
        
        for(iUL = 0; iUL < inputFile->yDim; iUL++) {
            fileShift = (iUL * inputFile->xDim + xIndex) * sizeof(complexFloat) ;
            if(fseek(inputFile->f, fileShift, SEEK_SET))
                //			fileShift = ((fpos_t)iUL * inputFile->xDim + xIndex) * sizeof(complexFloat) ;
                //			if(fsetpos(inputFile->f, &fileShift))
                ase("Failed to seek in input file before reading");
            fread(aBloc[iUL + yBorder], xDimBloc, sizeof(complexFloat), inputFile->f) ;
        }
        
        
        for(i = 0; i < xDimBloc; i++) {
            if (!isUnitary) {
                if(withMirroring) {
                    p = yBorder + inputFile->yDim - 1 ;
                    while(p < lenY) {
                        for(index = p + 1, jUL = 1; jUL < inputFile->yDim; index++, jUL++)
                            if(index < lenY) {
                                aBloc[index][i] = aBloc[p - jUL][i] ;
                            }
                        p += inputFile->yDim - 1 ;
                    }
                    p = yBorder ;
                    while(p >= 0) {
                        for(index = p - 1, jUL = 1; jUL < inputFile->yDim; index--, jUL++)
                            if(index >= 0) {
                                aBloc[index][i] = aBloc[p + jUL][i] ;
                            }
                        p -= inputFile->yDim - 1 ;
                    }
                }
                
                for(j = 0; j < lenY; j++) {
                    phasor.r = (float)cos((double)phaseFactor * j) ;
                    phasor.i = (float)sin((double)phaseFactor * j) ;
                    u[j] = mC(aBloc[j][i], phasor) ;
                }
                
                D = T[1][0] * (i + xIndex) + T[1][2] + (1. - T[1][1]) * yBorder ;
                CZTInterpolation(u, T[1][1], D, V) ;
                
                for(j = yBorder; j < lenY - yBorder; j++) {
                    phasor.r = (float)cos(-phaseFactor * (T[1][1]*j + D))/lenY ;
                    phasor.i = (float)sin(-phaseFactor * (T[1][1]*j + D))/lenY ;
                    aBloc[j][i] = mC(phasor, u[j]) ;
                }
                updateProgressCounterForIndex(aCounter, i + xIndex) ;
            }
        }
        
        for(iUL = 0; iUL < outputFile->yDim; iUL++) {
            fileShift = (iUL * outputFile->xDim + xIndex) * sizeof(complexFloat) ;
            if(fseek(outputFile->f, fileShift, SEEK_SET))
                //			fileShift = ((fpos_t)iUL * outputFile->xDim + xIndex) * sizeof(complexFloat) ;
                //			if(fsetpos(outputFile->f, &fileShift))
                ase("Failed to seek in output file before writing") ;
            fwrite(aBloc[iUL + yBorder], sizeof(complexFloat), xDimBloc, outputFile->f) ;
        }
    }
    
    if (!isUnitary) {
        updateProgressCounterForIndex(aCounter, outputFile->xDim) ;
        freeVectorComplexFloat(u, 0) ;
        freeCZTInterpolator(V) ;
    }
    
    freeMatrixComplexFloat(aBloc, 0, 0) ;
    freeMatrixComplexFloat(aNullBloc, 0, 0) ;
}





/* This function interpolates a given matrix M of float having dimensions xDim x yDim pixels */
/* Interpolation applies an affine transform given through T containing coeeficients Ax, Bx, CX and Ay, By, Cy */
/* The applied transform is : */ 
/* x1 = Ax * x2 + Bx * y2 + Cx */
/* y1 = Ay * x2 + By * y2 + Cy */
void interpolFloatMatrixInPlace(float **M, int xDimInput, int yDimInput, double **T)
{
	int j, k, xDim, yDim ;
	double D, c ;
	complexFloat **u, *v, cs ;
	CZTInterpolator *zoomX, *zoomY ;
	
    xDim = ceil2ofIntVal(xDimInput) ;
    yDim = ceil2ofIntVal(yDimInput) ;
//	if(xDim != xDimInput || yDim != yDimInput)
//		ase("Matrix must have dimensions equal to a power of 2 to be interpolated!\n") ;
	
	T[0][1] /= T[1][1] ;
	T[0][0] -= T[0][1] * T[1][0] ;
	T[0][2] -= T[0][1] * T[1][2] - (1. - T[0][0]) * 0. ;
	
	zoomX = initInterpolator(xDim, T[0][0]) ;
	zoomY = initInterpolator(yDim, T[1][1]) ;
	u = matrixComplexFloat(0, xDim - 1, 0, yDim - 1) ;
	v = vectorComplexFloat(0, yDim - 1) ;
    /* init u & v with zeros */
    for(k = 0; k < xDim; k++)
        u[0][k].r = u[0][k].i = 0.0 ;
    for(j = 0; j < yDim; j++) {
        memcpy(u[j], u[0], xDim * sizeof(complexFloat)) ;
        v[j].r = v[j].i = 0.0 ;
    }

	/* X zoom */
	for(j = 0; j < yDimInput; j++) {
		c = -1. ;
		for(k = 0; k < xDimInput; k++) {
			c *= -1. ;
			u[j][k].r = c * M[j][k] ; 
			u[j][k].i = 0. ; 
		}
		
		D = T[0][1] * j + T[0][2] ;
		CZTInterpolation(u[j], T[0][0], D, zoomX) ;
		for(k = 0; k < xDim; k++) {
			cs.r = (float)cos(-(double)PI * (T[0][0]*k + D))/xDim ;
			cs.i = (float)sin(-(double)PI * (T[0][0]*k + D))/xDim ;
			u[j][k].r = mC(cs, u[j][k]).r ;
			u[j][k].i = 0 ;
		}
	}
	
	/* Y zoom */
	for(k = 0; k < xDimInput; k++) {
		c = -1. ;
		for(j = 0; j < yDim; j++) {
			c *= -1. ;
			v[j] = mRC(u[j][k], c) ;
		}
		
		D = T[1][0] * k + T[1][2] ;
		CZTInterpolation(v, T[1][1], D, zoomY) ;
		
		for(j = 0; j < yDimInput; j++) {
			cs.r = (float)cos(-(double)PI * (T[0][0]*j + D))/yDim ;
			cs.i = (float)sin(-(double)PI * (T[0][0]*j + D))/yDim ;
			M[j][k] = (mC(cs, v[j])).r ;
		}
	}
	
	freeVectorComplexFloat(v, 0) ;
	freeMatrixComplexFloat(u, 0, 0) ;
	freeCZTInterpolator(zoomX) ;
	freeCZTInterpolator(zoomY) ;
}
