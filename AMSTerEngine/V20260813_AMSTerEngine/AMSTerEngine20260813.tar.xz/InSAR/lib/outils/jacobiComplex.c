
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  jacobiComplexe.c
 *  decPol
 *
 *  Created by Dominique Derauw on Wed Sep 25 2002.
 *  Copyright (c) 2002 Dominique Derauw. All rights reserved.
 *
 */

#include "jacobiComplexe.h"


/*
 *  jacobiComplexe.c
 *  Adaptation au cas de matrices Hermitienne de la methode de Jacobi decrite dans :
NUMERICAL RECIPES IN C: THE ART OF SCIENTIFIC COMPUTING (ISBN 0-521-43108-5)
Copyright (C) 1988-1992 by Cambridge University Press.
Programs Copyright (C) 1988-1992 by Numerical Recipes Software.
 */

int jacobiComplexe(complexFloat **a, int n, float d[], complexFloat **v, int sort)
{
    int 		j, iq, ip ,i ;
    double 		tresh, theta, t, sm, s, h, g, c, *b, *z, normeAipiq ;
//    double tau ;
    complexDouble	al ;
    
    b = vectorDouble(1, n) ;
    z = vectorDouble(1, n) ;
    for(ip = 1; ip <=  n; ip++) { 				/* Initialize to the identity matrix. */
        for(iq = 1; iq <=  n; iq++) v[ip][iq].r = v[ip][iq].i = 0.0 ;
        v[ip][ip].r = 1.0;
    }
    
    for(ip = 1; ip <=  n; ip++) { 				/* Initialize b and d to the diagonal of a. */
        b[ip] = d[ip] = (double)a[ip][ip].r ;
        z[ip] = 0.0 ; 						/* This vector will accumulate terms of the form tapq as in equation (11.1.14). */
    }

    for(i = 1; i <=  50; i++) {
        sm = 0.0 ;
        for(ip = 1; ip <=  n-1; ip++) { 			/* Sum off-diagonal elements. */
            for(iq = ip + 1; iq <=  n; iq++)
            sm += sqrt((double)a[ip][iq].r * (double)a[ip][iq].r + (double)a[ip][iq].i * (double)a[ip][iq].i) ;
        }

        if (sm ==  0.0) { 					/*The normal return, which relies on quadratic convergence to machine underflow. */
            freeVectorDouble(z, 1) ;
            freeVectorDouble(b, 1) ;
			if(sort) eigsrt(d, v, n) ;
            return(1);
        }
        
        if (i < 4)
            tresh = 0.2 * sm/(n*n) ; 				/* ...on the first three sweeps. */
        else
            tresh = 0.0; 					/* ...thereafter. */
        
        for(ip = 1; ip <=  n-1; ip++) {
            for(iq = ip + 1; iq <=  n; iq++) {
                normeAipiq = sqrt((double)a[ip][iq].r * (double)a[ip][iq].r + (double)a[ip][iq].i * (double)a[ip][iq].i) ;
                g = 100.0 * normeAipiq ;
                                                            /* After four sweeps, skip the rotation if the off-diagonal element is small. */
                if (i > 4 && (fabs(d[ip])+g) == fabs(d[ip]) && (fabs(d[iq])+g) == fabs(d[iq]))
                    a[ip][iq].i = a[ip][iq].r = 0.0;
                else 
                    if (normeAipiq > tresh) {
                        h = d[iq]-d[ip] ;
                        if ((fabs(h)+g)  ==  fabs(h))
                            t = normeAipiq/h ; 			/* t = 1/(2teta) */
                        else {
                            theta = 0.5*h/normeAipiq ; 	/* Equation (11.1.10).*/
                            t = 1.0/(fabs(theta)+sqrt(1.0+theta*theta)) ;
                            if (theta < 0.0) t = -t ;
                        }
                        c = 1.0/sqrt(1+t*t) ;
                        s = t*c ;
//                        tau = s/(1.0+c) ;
                        h = t*normeAipiq ;
                        z[ip] -=  h ;
                        z[iq] +=  h ;
                        d[ip] -=  h ;
                        d[iq] +=  h ;
                        al.r = s * (double)a[ip][iq].r / normeAipiq ;
                        al.i = s * (double)a[ip][iq].i / normeAipiq ;
                        a[ip][iq].r = a[ip][iq].i = 0.0;

                        for(j = 1; j < ip; j++) { 	/* Case of rotations 1 j < p. */
//                            ROTATE(a,j,ip,j,iq)
                            rotate1(a, j, ip, j, iq, c, al) ;
                        }
						
                        for(j = ip+1; j < iq; j++) { 	/* Case of rotations p < j < q. */
//                            ROTATE(a,ip,j,j,iq)
                            rotate2(a, ip, j, j, iq, c, al) ;
                        }
						
                        for(j = iq+1; j <= n; j++) { 	/* Case of rotations q < j n. */
//                            ROTATE(a,ip,j,iq,j)
                            rotate3(a, ip, j, iq, j, c, al) ;
                        }

                        for(j = 1; j <= n; j++) {
//                            ROTATE(v,j,ip,j,iq)
                            rotate1(v, j, ip, j, iq, c, al) ;
                        }
                    }
            }
        }
        for(ip = 1; ip <= n; ip++) {
            b[ip] +=  z[ip] ;
            d[ip] = b[ip] ; 				/* Update d with the sum of tapq, */
            z[ip] = 0.0 ; 				/* and reinitialize z. */
        }
    }
	return(0) ;
//    perror("Too many iterations in routine jacobi") ;
}

void	rotate1(complexFloat **a, int i, int j, int k, int l, double c, complexDouble s) 
{
    complexDouble	g, h ;
    
    g.r = (double)a[i][j].r ;
    g.i = (double)a[i][j].i ;
    h.r = (double)a[k][l].r ;
    h.i = (double)a[k][l].i ;
    
    a[i][j].r = (float)(c * g.r - (s.r * h.r + s.i * h.i)) ;
    a[i][j].i = (float)(c * g.i - (s.r * h.i - s.i * h.r)) ;
    a[k][l].r = (float)(c * h.r + (s.r * g.r - s.i * g.i)) ;
    a[k][l].i = (float)(c * h.i + (s.r * g.i + s.i * g.r)) ;
}

void	rotate2(complexFloat **a, int i, int j, int k, int l, double c, complexDouble s) 
{
    complexDouble	g, h ;
    
    g.r = (double)a[i][j].r ;
    g.i = (double)a[i][j].i ;
    h.r = (double)a[k][l].r ;
    h.i = (double)a[k][l].i ;
    
    a[i][j].r = (float)(c * g.r - (s.r * h.r + s.i * h.i)) ;
    a[i][j].i = (float)(c * g.i + (s.r * h.i - s.i * h.r)) ;
    a[k][l].r = (float)(c * h.r + (s.r * g.r + s.i * g.i)) ;
    a[k][l].i = (float)(c * h.i - (s.r * g.i - s.i * g.r)) ;
}

void	rotate3(complexFloat **a, int i, int j, int k, int l, double c, complexDouble s) 
{
    complexDouble	g, h ;
    
    g.r = (double)a[i][j].r ;
    g.i = (double)a[i][j].i ;
    h.r = (double)a[k][l].r ;
    h.i = (double)a[k][l].i ;
    
    a[i][j].r = (float)(c * g.r - (s.r * h.r - s.i * h.i)) ;
    a[i][j].i = (float)(c * g.i - (s.r * h.i + s.i * h.r)) ;
    a[k][l].r = (float)(c * h.r + (s.r * g.r + s.i * g.i)) ;
    a[k][l].i = (float)(c * h.i + (s.r * g.i - s.i * g.r)) ;
}



/* Given the eigenvalues d[1..n] and eigenvectors v[1..n][1..n] as output fromjacobi (�11.1) ortqli(�11.3), 
this routine sorts the eigenvalues into descending order, and rearranges the columns of v correspondingly. The method is straight insertion. 
*/
void eigsrt(float d[], complexFloat **v, int n) 
{ 
	int		k, j, i ; 
	float	p ;
	complexFloat vTemp ;
	
	for (i = 1; i < n; i++) { 
		p = d[k = i];
		for (j = i + 1; j <= n; j++) 
			if(d[j] >= p) p = d[k = j]; 
		if (k != i) { 
			d[k] = d[i]; 
			d[i] = p; 
			for (j = 1; j <= n; j++) { 
				vTemp = v[j][i]; 
				v[j][i] = v[j][k]; 
				v[j][k] = vTemp; 
			} 
		} 
	} 
} 
