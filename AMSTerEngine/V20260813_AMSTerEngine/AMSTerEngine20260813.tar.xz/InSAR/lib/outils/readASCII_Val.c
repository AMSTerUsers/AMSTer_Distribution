
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  readAsciiVal.c
 *  lecheader
 *
 *  Created by Dominique Derauw on Wed Feb 20 2002.
 *  Copyright (c) 2001 Dominique Derauw All rights reserved.
 *
 */

#include "readASCII_Val.h"

/* ________________ Reading of a int in an non-null terminated string ________________ */

int	readIntInASCIIStringOfLength(char *stringToRead, int numberOfCharInString)
{
	char	s[32] ;
	int	nscan, returnedValue = 0 ;

    errno = 0 ;
	memcpy(s, stringToRead, (int unsigned)numberOfCharInString) ;
	s[numberOfCharInString] = '\0' ;
	if((nscan = sscanf(s, "%d", &returnedValue)) <= 0)
        errno = NO_VALUE_READ ;
    
	return(returnedValue) ;
}


/* ________________ Reading of a long in an non-null terminated string ________________ */

long readLongInASCIIStringOfLength(char *stringToRead, int numberOfCharInString)
{
	char	s[64] ;
	int	nscan ;
	long returnedValue ;

    errno = 0 ;
	memcpy(s, stringToRead, (int unsigned)numberOfCharInString) ;
	s[numberOfCharInString] = '\0' ;
	if((nscan = sscanf(s, "%ld", &returnedValue)) <= 0)
        errno = NO_VALUE_READ ;
	return(returnedValue) ;

}


/* ________________ Reading of a float in an non-null terminated string ________________ */

float readFloatInASCIIStringOfLength(char *stringToRead, int numberOfCharInString)
{
	char	s[32] ;
	int	i, nscan ;
	float returnedValue ;
	
    errno = 0 ;
	memcpy(s, stringToRead, (int unsigned)numberOfCharInString) ;
	s[numberOfCharInString] = '\0' ;
	for(i=0; i<numberOfCharInString; i++) if((s[i] == 'd') || (s[i] == 'D')) s[i] = 'E' ;
	if((nscan = sscanf(s, "%f", &returnedValue)) <= 0)
        errno = NO_VALUE_READ ;
	return(returnedValue) ;

}


/* ________________ Reading of a double in an non-null terminated string ________________ */

double readDoubleInASCIIStringOfLength(char *stringToRead, int numberOfCharInString)
{
	char	*stringVal ;
	int	i, nscan ;
	double returnedValue = 0. ;
	
    errno = 0 ;
    stringVal = allocStringOfLength(numberOfCharInString + 1) ;
	memcpy(stringVal, stringToRead, (int unsigned)numberOfCharInString) ;
	stringVal[numberOfCharInString] = '\0' ;
	for(i=0; i<numberOfCharInString; i++) if((stringVal[i] == 'd') || (stringVal[i] == 'D')) stringVal[i] = 'E' ;
    if((nscan = sscanf(stringVal, "%lf", &returnedValue)) <= 0) {
        errno = NO_VALUE_READ ;
    }
    
    free(stringVal) ;
	return(returnedValue) ;
}


