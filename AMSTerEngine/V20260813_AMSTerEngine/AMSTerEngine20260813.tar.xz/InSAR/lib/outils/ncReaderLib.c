
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  ncReaderLib.c
//  S1DataReader
//
//  Created by Dominique Derauw on 09/04/2025.
//  Copyright © SAREOS - Dominique Derauw. All rights reserved.
//


#include "ncReaderLib.h"

/*
int main(int argc, const char **argv) 
{
    char *ncFilePath ;
    int ncID, ncStatus ;
    int ncDims, ncVars, ncAttributes, unlimitedDims ;
    int groupID ;
    groupStruct *rootGroup ;
    CSVStruct *groupList ;
    ncAtb *attList ;
    ncVar *aVarStruct ;
    


    ncFilePath = initStringWithString("/home/dd/SAR/DATA/Images/S1/LagunaLaFea/ETAD/S1A_IW_ETA__AXDV_20250203T095650_20250203T095718_057730_071DE2_F0EE.SAFE/measurement/S1A_IW_ETA__AXDV_20250203T095650_20250203T095718_057730_071DE2.nc") ;

    ncReadAndSaveGroupVars(ncFilePath, "/IW2/Burst0001", "/home/dd/SAR/DATA/Images/S1/LagunaLaFea/ETAD") ;

    ncStatus = nc_open(ncFilePath, NC_NOWRITE, &ncID) ;
    ncStatusCheck(ncStatus) ;
    
    ncStatus = nc_inq(ncID, &ncDims, &ncVars, &ncAttributes, &unlimitedDims) ;
    ncStatusCheck(ncStatus) ;

    rootGroup = ncGetSubGroupsForGroup(NULL, ncID) ;
    groupList = listGroupStruct(rootGroup, NULL) ;

    groupID = getGroupIdForPath(rootGroup, "/IW2/Burst0001") ;
    aVarStruct = ncGetGroupVarsDescription(groupID) ;

    freeVarDesc(aVarStruct) ;


    attList = ncGetGroupAtts(groupID, NC_GLOBAL) ;
    free_ncAttribute(attList) ;

    ncGetGroupDims(groupID) ;
*/
/*
    theSlice = (short **)ncGetCubeSliceAtPath(ncID, "/VNIR/IMAGE/PIX", 67, "TIME") ; 
    aFile = openRawFileForWritingAtPath("/home/dd/dox/shortSlice67") ;
    fwrite(theSlice[0], sizeof(short), 520 * 520, aFile->f) ;
    freeRawFileDescriptor(aFile) ;
*/
/*
    freeCSVStruct(groupList) ;
    freeSubGroupsOfGroup(rootGroup) ;
    freeGroupStruct(rootGroup) ;
    
    ncStatus = nc_close(ncID) ;
    ncStatusCheck(ncStatus) ;
    
    exit(0) ; 
}
*/
void ncStatusCheck(int status)
{
    if (status != NC_NOERR) {
        ase((char *)nc_strerror(status)) ;
    }
}

/* Allocation of an empty  group structure */
groupStruct *allocGroupStruct(void) {
    groupStruct *thisGroup ;

    thisGroup = malloc(sizeof(thisGroup[0])) ;
    thisGroup->parentGroup = NULL ;
    thisGroup->subGroupId = NULL ;
    thisGroup->subGroup = NULL ;

    return (thisGroup) ;
}

/* Get sub groups full description within a group */
/* If thisGroup == NULL, it is groupID that is considered, then group structure is allocated and returned */
/* the return group structure containes all subgroups structures with their attributes and variable descriptions*/
/*Variables themselves are not returned */
groupStruct *ncGetSubGroupsForGroup(groupStruct *thisGroup, int groupID) {
    int i, ncStatus, numberOfGroups ;
    size_t aLength ;

    if (thisGroup == NULL) {
        thisGroup = allocGroupStruct() ;
        thisGroup->groupID = groupID ;
    }

    /* Get this group name */
    ncStatus = nc_inq_grpname_len(thisGroup->groupID, &aLength) ;
    ncStatusCheck(ncStatus) ;
    thisGroup->groupName = allocStringOfLength(aLength) ;
    ncStatus = nc_inq_grpname(thisGroup->groupID, thisGroup->groupName) ;
    ncStatusCheck(ncStatus) ;


    /* Get number of sub groups */
    ncStatus = nc_inq_grps(thisGroup->groupID, &numberOfGroups, NULL) ;
    ncStatusCheck(ncStatus) ;
    thisGroup->numberOfSubGroups = numberOfGroups ;
    if (numberOfGroups) {
        /* Get groups IDs */
        thisGroup->subGroupId = vectorInt(0, numberOfGroups - 1) ;
        thisGroup->subGroup = malloc(numberOfGroups * sizeof(thisGroup->subGroup[0])) ;
        ncStatus = nc_inq_grps(thisGroup->groupID, &numberOfGroups, thisGroup->subGroupId) ;
        ncStatusCheck(ncStatus) ;
        /* Get sub groups */
        for (i = 0; i < numberOfGroups; i++) {
            thisGroup->subGroup[i] = ncGetSubGroupsForGroup(NULL, thisGroup->subGroupId[i]) ;
            thisGroup->subGroup[i]->parentGroup = thisGroup ;
        }
    }

    thisGroup->dims = ncGetGroupDims(thisGroup->groupID) ;
    thisGroup->gpAtt = ncGetGroupAtts(thisGroup->groupID, NC_GLOBAL) ;
    thisGroup->ncVars = ncGetGroupVarsDescription(thisGroup->groupID) ;
    
    return(thisGroup) ;
}

/* This function simply displays group tree structure */
CSVStruct *listGroupStruct(groupStruct *aGroup, CSVStruct *aCSV)
{
    int i ;

    aCSV = addStringValInCSVStruct(aGroup->groupName, aCSV) ;
    if (!aGroup->numberOfSubGroups) {
        for ( i = 0; i < aCSV->numberOfEntries; i++) {
            printf("%s/", aCSV->stringVal[i]) ;
        }
        printf("\n") ;
    }
    else {
        for ( i = 0; i < aGroup->numberOfSubGroups; i++) {
            aCSV = listGroupStruct(aGroup->subGroup[i], aCSV) ;
            removeStringValAtIndexInCSVStruct(aCSV->numberOfEntries - 1, aCSV) ;
        }
    }

    return (aCSV) ;
}

/* Free a group structure */
void freeGroupStruct(groupStruct *aGroup)
{
        free(aGroup->groupName) ;
        aGroup->groupName = NULL ;
        if (aGroup->subGroupId) {
            freeVectorInt(aGroup->subGroupId, 0) ;
            aGroup->subGroupId = NULL ;
        }

        if (aGroup->subGroup) {
            free(aGroup->subGroup) ;
            aGroup->subGroup = NULL ;
        }

        if (aGroup->dims) {
            freeGroupDims(aGroup->dims) ;
        }
        
        if (aGroup->gpAtt) {
            free_ncAttribute(aGroup->gpAtt) ;
        }
        
        if (aGroup->ncVars) {
            freeVarDesc(aGroup->ncVars) ;
        }
        
        free(aGroup) ;
}

/* Free nested group list */
void freeSubGroupsOfGroup(groupStruct *aGroup)
{
    int i, N ;
    groupStruct *parentGroup ;

    if (!aGroup->numberOfSubGroups) {
        parentGroup = aGroup->parentGroup ;
        freeGroupStruct(aGroup) ;
        parentGroup->numberOfSubGroups-- ;
    }
    else {
        while ((N = aGroup->numberOfSubGroups)) {
            for ( i = 0; i < N; i++) {
                freeSubGroupsOfGroup(aGroup->subGroup[i]) ;
            } 
        }
    }
}

/* Retreive subgroup at given path starting from an already read parent group structure */
/* netCDF path is given as a unix/linux-like path */
groupStruct *getSubGroupForPath(groupStruct *rootGroup, char *aPath)
{
    int i, groupIndex ;
    char *aString ;
    CSVStruct *csvPath ;
    groupStruct *thisGroup, *childGroup ;

    aString = initStringWithString(aPath) ;
    replaceNSubStringInString(aString, "/", ",") ;
    csvPath = readCSVInString(aString) ;
    removeEmptyValsInCSV(csvPath) ;

    thisGroup = rootGroup ;
    for (i = 0; i < csvPath->numberOfEntries; i++) {
        groupIndex = 0 ;
        childGroup = thisGroup->subGroup[groupIndex] ;
        while ((groupIndex < thisGroup->numberOfSubGroups) && strcmp(childGroup->groupName, csvPath->stringVal[i])) {
            groupIndex++ ;
            childGroup = thisGroup->subGroup[groupIndex] ;
        }
        if (groupIndex == thisGroup->numberOfSubGroups) {
            printf("\t-/-> Group %s not found\n", aPath) ;
            return (NULL) ;
        }
        else {
            thisGroup = thisGroup->subGroup[groupIndex] ;
        }
    }
    free(aString) ;

    return (thisGroup) ;
}

/* Retreive the group ID at given path starting from a parent group */
/* netCDF path is given as a unix/linux-like path */
int getGroupIdForPath(groupStruct *rootGroup, char *aPath)
{
    groupStruct *thisGroup ;

    thisGroup = getSubGroupForPath(rootGroup, aPath) ;

    return (thisGroup->groupID) ;
}

/* This function extract a slice of a 3D data set, returning a matrix */
/* Slice index gives the index from which the slice is extracted on the given dimName axis */
/* dimName is the dimension name along which the slice is extracted */
/* type is set as void. The caller has to know what he is expecting to make the corresponding cast */
void **ncGetCubeSliceAtPath(int ncID, char *aPath, int sliceIndex, char *dimName)
{
    char *groupPath, *varName, *aString, ncName[NC_MAX_NAME] ;
    short **aMatrixShort ;
    int i, groupID, varID, varNDims, *varDimsID ;
    int ncStatus ;
    int dimIndex, xDim, yDim ;
    void **theMatrix ;
    nc_type varType ;
    size_t aDim, start[3], count[3] ;
    groupStruct *rootGroup ;
    CSVStruct *csv ; 

    aString = initStringWithString(aPath) ;
    replaceNSubStringInString(aString, "/", ",") ;
    csv = readCSVInString(aString) ;
    removeEmptyValsInCSV(csv) ;
    varName = initStringWithString(csv->stringVal[csv->numberOfEntries - 1]) ;
    i = locateSubStringInString(aPath, varName) - 1 ;
    aString = initStringWithString(aPath) ;
    aString[i] = '\0' ;
    groupPath = aString ; 

    rootGroup = ncGetSubGroupsForGroup(NULL, ncID) ;
    groupID = getGroupIdForPath(rootGroup, groupPath) ;
    ncStatus = nc_inq_varid(groupID, varName, &varID) ;
    ncStatusCheck(ncStatus) ;
    ncStatus = nc_inq_varndims(groupID, varID, &varNDims) ;
    ncStatusCheck(ncStatus) ;
    if (varNDims != 3) {
        printf("\t-/-> nc data is not 3D. No slice extracted\n") ;
        return (NULL) ;
    }
    varDimsID = vectorInt(0, 2) ;
    ncStatus = nc_inq_vardimid(groupID, varID, varDimsID) ;
    ncStatusCheck(ncStatus) ;

    dimIndex = 0 ;
    xDim = yDim = 0 ;
    for(i = 0; i < varNDims; i++) {
        ncStatus = nc_inq_dim(groupID, varDimsID[i], ncName, &aDim) ;
        ncStatusCheck(ncStatus) ;
        printf("Dimension: %s\t%ld\n", dimName, aDim) ;
        if (!strcmp(dimName, ncName)) {
            start[i] = sliceIndex ;
            count[i] = 1 ;
            dimIndex = i ;
        }
        else {
            start[i] = 0 ;
            count[i] = aDim ;
            if (!xDim) {
                xDim = aDim ;
            }
            else {
                yDim = aDim ;
            }
        }
    }
    if (!dimIndex) {
        printf("\t-/-> Requested dimension %s not found.\n", dimName) ;
        return(NULL) ;
    }
    ncStatus = nc_inq_vartype(groupID, varID, &varType) ;
    ncStatusCheck(ncStatus) ;
    ncStatus = nc_inq_type(groupID, varType, ncName, &aDim) ;
    ncStatusCheck(ncStatus) ;
    printf("Type name: %s\tType length: %ld\n", ncName, aDim) ;
   
    switch (aDim) {
    case 2:
        aMatrixShort = matrixShort(0, xDim - 1, 0, yDim - 1) ;
        theMatrix = (void **)aMatrixShort ;
        ncStatus = nc_get_vara_short(groupID, varID, start, count, aMatrixShort[0]) ;
        ncStatusCheck(ncStatus) ;
        break;
    
    default:
        return (NULL) ;
        break;
    }


    free(aString) ;
    free(varName) ;
    freeVectorInt(varDimsID, 0) ;

    return (theMatrix) ;
}


/* Allocate an empty attribute structure */
ncAtb *alloc_ncAttribute(void)
{
    ncAtb *thisAttribute ;

    thisAttribute = malloc(sizeof(thisAttribute[0])) ;
    thisAttribute->attributeName = NULL ;
    thisAttribute->dataTypeName = NULL ;
    thisAttribute->data = NULL ;
    thisAttribute->nextOne = NULL ;

    return(thisAttribute) ;
}

/* Allocate a list of attribute strucutre */
ncAtb *allocAtbList(int unsigned N)
{
    int unsigned i ;
    ncAtb *attList, *currentAtb ;

    currentAtb = attList = alloc_ncAttribute() ;
    i = N - 1 ;
    while (i) {
        i-- ;
        currentAtb->nextOne = alloc_ncAttribute() ;
        currentAtb = currentAtb->nextOne ;
    }

    return (attList) ;
}

/* Free attribute structure */
void free_ncAttribute(ncAtb *thisAttribute) 
{
    if (thisAttribute) {
        free(thisAttribute->attributeName) ;
        free(thisAttribute->dataTypeName) ;
        if (thisAttribute->data) {
            free(thisAttribute->data) ;
        }
        
        free_ncAttribute(thisAttribute->nextOne) ;
        free(thisAttribute) ;
    }
}

/* Get atrributes of a given group or variable within a group */
ncAtb *ncGetGroupAtts(int groupID, int attributeID) 
{
    char name[NC_MAX_NAME + 1] ;
    int ncStatus, nAtb ;
    ncAtb *attList = NULL, *currentAtb ;

    ncStatus = nc_inq_varnatts(groupID, attributeID, &nAtb) ;
    ncStatusCheck(ncStatus) ;

    if (nAtb) {
        currentAtb = attList = allocAtbList(nAtb) ;
        
        for (int attIndex = 0; attIndex < nAtb; attIndex++) {
            currentAtb->groupID = groupID ;
            ncStatus = nc_inq_attname(groupID, attributeID, attIndex, name);
            ncStatusCheck(ncStatus) ;
            currentAtb->attributeName = initStringWithString(name) ;
            
            ncStatus = nc_inq_atttype(groupID, attributeID, name, &currentAtb->ncDataTypeID);
            ncStatusCheck(ncStatus) ;
            
            ncStatus = nc_inq_attlen(groupID, attributeID, name, &currentAtb->dataLength);
            ncStatusCheck(ncStatus) ;
            
            switch (currentAtb->ncDataTypeID) {
                case NC_BYTE:
                    currentAtb->data = malloc(currentAtb->dataLength) ;
                    ncStatus = nc_get_att_ubyte(groupID, attributeID, name, currentAtb->data);
                    ncStatusCheck(ncStatus) ;
                    currentAtb->dataTypeID = _UCHAR_ID_ ;
                    currentAtb->dataTypeName = initStringWithString("BOOL") ;
                break ;

                case NC_CHAR:
                    currentAtb->data = allocStringOfLength(currentAtb->dataLength) ;
                    ncStatus = nc_get_att_text(groupID, attributeID, name, currentAtb->data);
                    ncStatusCheck(ncStatus) ;
                    currentAtb->dataTypeID = _UCHAR_ID_ ;
                    currentAtb->dataTypeName = initStringWithString("STRING") ;
                break ;

                case NC_INT :
                    currentAtb->data = malloc(currentAtb->dataLength * sizeof(int)) ;
                    ncStatus = nc_get_att_int(groupID, attributeID, name, currentAtb->data) ;
                    currentAtb->dataTypeID = _INT32_ID_ ;
                    currentAtb->dataTypeName = initStringWithString("INT") ;
               break ;

                case NC_FLOAT :
                    currentAtb->data = malloc(currentAtb->dataLength * sizeof(float)) ;
                    ncStatus = nc_get_att_float(groupID, attributeID, name, currentAtb->data) ;
                    currentAtb->dataTypeID = _REAL32_ID_ ;
                    currentAtb->dataTypeName = initStringWithString("FLOAT") ;
                break ;

                case NC_DOUBLE :
                    currentAtb->data = malloc(currentAtb->dataLength * sizeof(double)) ;
                    ncStatus = nc_get_att_double(groupID, attributeID, name, currentAtb->data) ;
                    currentAtb->dataTypeID = _REAL64_ID_ ;
                    currentAtb->dataTypeName = initStringWithString("DOUBLE") ;
                break ;

            default:
                break ;
            }

            currentAtb = currentAtb->nextOne ;
        }
    }

    return (attList) ;
}

/* Allocate group dimensions structure */
grpDim *allocGroupDims(void)
{
    grpDim *aGroupDims ;

    aGroupDims = malloc(sizeof(aGroupDims[0])) ;
    aGroupDims->dimName = NULL ;
    aGroupDims->dimID = NULL ;
    aGroupDims->dimVal = NULL ;

    return (aGroupDims) ;
}

/* Free group dimensions structure */
void freeGroupDims(grpDim *aGroupDims)
{
    int i ;

    if (aGroupDims) {
        for ( i = 0; i < aGroupDims->nDims; i++) {
            free(aGroupDims->dimName[i]) ;
        }
        free(aGroupDims->dimName) ;
        
        if (aGroupDims->dimID) {
            freeVectorInt(aGroupDims->dimID, 0) ;
        }

        if (aGroupDims->dimVal) {
            free(aGroupDims->dimVal) ;
        }
    }
}

/* Get all available dimensions within a group with their respective names and IDs */
grpDim *ncGetGroupDims(int groupID)
{
    char name[NC_MAX_NAME + 1] ;
    int ncStatus ;
    grpDim *thisGroupDims ;

    thisGroupDims = allocGroupDims() ;

    ncStatus = nc_inq_ndims(groupID, &thisGroupDims->nDims);
    ncStatusCheck(ncStatus) ;

    thisGroupDims->groupID = groupID ;
    thisGroupDims->dimName = malloc(thisGroupDims->nDims) ;
    thisGroupDims->dimID = vectorInt(0, thisGroupDims->nDims - 1) ;
    thisGroupDims->dimVal = malloc(thisGroupDims->nDims * sizeof(size_t)) ;

    ncStatus = nc_inq_dimids(groupID, &thisGroupDims->nDims, thisGroupDims->dimID, 0) ;
    ncStatusCheck(ncStatus) ;

    for (int i = 0; i < thisGroupDims->nDims; i++) {
        ncStatus = nc_inq_dimname(groupID, thisGroupDims->dimID[i], name);
        thisGroupDims->dimName[i] = initStringWithString(name) ;
        ncStatusCheck(ncStatus) ;
        
        ncStatus = nc_inq_dimlen(groupID, thisGroupDims->dimID[i], thisGroupDims->dimVal + i);
        ncStatusCheck(ncStatus) ;        
    }

    return (thisGroupDims) ;
}


/* Empty variable descriptor allocation */
ncVar *allocVarDesc(void)
{
    ncVar *varDesc ;

    varDesc = malloc(sizeof(varDesc[0])) ;
    varDesc->varName = NULL ;
    varDesc->nDims = NULL ;
    varDesc->nAtt = NULL ;
    varDesc->dimID = NULL ;
    varDesc->varType = NULL ;
    varDesc->varAtt = NULL ;

    return(varDesc) ;
}

/* Free a variable descriptor */
void freeVarDesc(ncVar *aVarDesc)
{
    int i ;

    if (aVarDesc) {
        freeCSVStruct(aVarDesc->varName) ;
        free(aVarDesc->varType) ;
        free(aVarDesc->nDims) ;
        free(aVarDesc->nAtt) ;
        for (i = 0; i < aVarDesc->nVars; i++) {
            free(aVarDesc->dimID[i]) ;
            if(aVarDesc->varAtt[i]) {
                free_ncAttribute(aVarDesc->varAtt[i]) ;
            }
        }
        free(aVarDesc->dimID) ;
        free(aVarDesc->varAtt) ;
    }
    free(aVarDesc) ;
}

/* Get a variable descriptor with variable attributes. Variable itself is not read */
ncVar *ncGetGroupVarsDescription(int groupID)
{
    char name[NC_MAX_NAME + 1] ;
    int ncStatus ;
    int i ;
    ncVar *varDesc ;

    varDesc = allocVarDesc() ;
    varDesc->groupID = groupID ;

    ncStatus = nc_inq_nvars(groupID, &varDesc->nVars) ;
    ncStatusCheck(ncStatus) ;

    varDesc->nDims = malloc(varDesc->nVars * sizeof(varDesc->nDims[0])) ;
    varDesc->nAtt = malloc(varDesc->nVars * sizeof(varDesc->nAtt[0])) ;
    varDesc->dimID = malloc(varDesc->nVars * sizeof(varDesc->dimID[0])) ;
    varDesc->varID = malloc(varDesc->nVars * sizeof(varDesc->varID[0])) ;
    varDesc->varType = malloc(varDesc->nVars * sizeof(varDesc->varType[0])) ;
    varDesc->varAtt = malloc(varDesc->nVars * sizeof(varDesc->varAtt[0])) ;

    for (i = 0; i < varDesc->nVars; i++) {
        ncStatus = nc_inq_varndims(groupID, i, varDesc->nDims + i) ;
        ncStatusCheck(ncStatus) ;

        ncStatus = nc_inq_varnatts(groupID, i, varDesc->nAtt + i) ;
        ncStatusCheck(ncStatus) ;

        varDesc->dimID[i] = malloc(varDesc->nDims[i] * sizeof(varDesc->dimID[i][0])) ;
        ncStatus = nc_inq_vardimid(groupID, i, varDesc->dimID[i]) ;
        ncStatusCheck(ncStatus) ;

        ncStatus = nc_inq_varname(groupID, i, name) ;
        ncStatusCheck(ncStatus) ;
        varDesc->varName = addStringValInCSVStruct(name, varDesc->varName) ;

        ncStatus = nc_inq_vartype(groupID, i, varDesc->varType + i) ;
        ncStatusCheck(ncStatus) ;

        ncStatus = nc_inq_varid(groupID, name, varDesc->varID + i) ;
        ncStatusCheck(ncStatus) ;

        varDesc->varAtt[i] = NULL ;
        if (varDesc->nAtt[i]) {
            varDesc->varAtt[i] = ncGetGroupAtts(groupID, varDesc->varID[i]) ;
        }
    }
    
    return(varDesc) ;
}


/* Returns a keyValue list with variable description and variable attributes */
keyValue *getVarAttOfGroup(int groupID, char *variableName)
{
    int varIndex ; 
    int i, j, dim ;
    size_t totalSize = 1 ;
    keyValue *pList, *pList2 ;

    ncVar *varDesc ;
    grpDim *varDims ;

    /* Get variable descriptor */
    varDesc = ncGetGroupVarsDescription(groupID) ;

    varIndex = isStringValPresentInCSV(variableName, varDesc->varName) ;
    if (varIndex) {
        varIndex-- ;
        
        pList = allocAKeyValuePair() ;
        /* Get variable dimensions */
        varDims = ncGetGroupDims(groupID) ;
        setStringValForKeyIn(pList, varDesc->varName->stringVal[varIndex], "Variable name") ;
        setIntValForKeyIn(pList, varDesc->varID[varIndex], "Variable ncID") ;
        setIntValForKeyIn(pList, varDesc->varType[varIndex], "Variable ncType") ;
        switch (varDesc->varType[varIndex]) {
            case NC_INT:
            setStringValForKeyIn(pList, "int", "Variable type") ;
            break;
            
            case NC_FLOAT:
            setStringValForKeyIn(pList, "float", "Variable type") ;
            break;
            
            case NC_DOUBLE:
            setStringValForKeyIn(pList, "double", "Variable type") ;
            break;
            
            default:
            break;
        }
        setIntValForKeyIn(pList, varDesc->nDims[varIndex], "Variable rank") ;

        for ( i = 0; i < varDesc->nDims[varIndex]; i++) {
            for ( j = 0; j < varDims->nDims; j++) {
                if (varDesc->dimID[varIndex][i] == varDims->dimID[j]) {
                    dim = varDims->dimVal[j] ;
                    setIntValForKeyIn(pList, dim, varDims->dimName[j]) ;
                    totalSize *= dim ;
                }
            }
        }
        setLongValForKeyIn(pList, totalSize, "Total size") ;

        /* Get variable attributes */
        pList2 = getGroupAtts(varDesc->varAtt[varIndex]) ;
        joinKeyValLists(pList, pList2) ;
    } 
    else {
        printf("\t-/-> Searched variable:%s\n", variableName) ;
        ase("\t-/-> Requested variable not found\n") ;
    }
    
    freeVarDesc(varDesc) ;

    return (pList) ;
}

/* Read a given variable within a group */
void ncReadAndSaveGroupVariableAtPath(int groupID, char *variableName, char *destinationDir)
{
    char *aPath ;
    int varID ; 
    void *data ;
    size_t totalSize ;
    nc_type ncDataType ;
    keyValue *params ;
    rawFileDescriptor *aFile ;

    params= getVarAttOfGroup(groupID, variableName) ;

    aFile = openRawFileForWritingAtPath(destinationDir) ;
    ncDataType = getIntValForKeyIn(params, "Variable ncType") ;
    varID = getIntValForKeyIn(params, "Variable ncID") ;
    totalSize = getIntValForKeyIn(params, "Total size") ;
    
    switch (ncDataType) {
        case NC_INT:
        totalSize *= sizeof(int) ;    
        break;
        
        case NC_FLOAT:
            totalSize *= sizeof(float) ;    
        break;
        
        case NC_DOUBLE:
        totalSize *= sizeof(double) ;    
        break;
        
        default:
        break;
    }
    
    data = malloc(totalSize) ;
    if (!data) {
        ase("\t-/-> Failed to allocate memory for nc data reading\n") ;
    }
    
    nc_get_var(groupID, varID, data) ;

    aPath = initStringWith3Strings(destinationDir, "/", variableName) ;
    aFile = openRawFileForWritingAtPath(aPath) ;
    fwrite(data, totalSize, 1, aFile->f) ;

    free(aPath) ;
    aPath = initStringWith2Strings(aFile->accessPath, ".txt") ;
    freeRawFileDescriptor(aFile) ;

    writeParameterFileAtPath(params, aPath) ;
    free(aPath) ;
    freeKeyValueList(params) ;
}



/* Read all variables of a given group */
void ncReadAndSaveGroupVars(char *ncFilePath, char *groupPath, char *destinationDir)
{
    char *aPath ;
    int i ;
    int ncID, ncStatus ;
    int groupID ; 
    keyValue *pList ;

    groupStruct *rootGroup ;
    ncAtb *grpAtts ;
    ncVar *varDesc ;

    /* Open nc file */
    ncStatus = nc_open(ncFilePath, NC_NOWRITE, &ncID) ;
    ncStatusCheck(ncStatus) ;

    /* Get nc file nested group structure */
    rootGroup = ncGetSubGroupsForGroup(NULL, ncID) ;

    /* Find requested group ID */
    groupID = getGroupIdForPath(rootGroup, groupPath) ;

    /* Get and save group attributes */
    grpAtts = ncGetGroupAtts(groupID, NC_GLOBAL) ;
    pList = getGroupAtts(grpAtts) ;
    aPath = initStringWith2Strings(destinationDir, "/ncGroupAtts.txt") ;
    writeParameterFileAtPath(pList, aPath) ;
    free(aPath) ;
    freeKeyValueList(pList) ;
    free_ncAttribute(grpAtts) ;

    /* Get variable descriptor */
    varDesc = ncGetGroupVarsDescription(groupID) ;
    for ( i = 0; i < varDesc->nVars; i++) {
        ncReadAndSaveGroupVariableAtPath(groupID, varDesc->varName->stringVal[i], destinationDir) ;
    }
}


keyValue *getGroupAtts(ncAtb *thisAttribute) 
{
    char unsigned *anUChar ;
    keyValue *pList ;

    pList = allocAKeyValuePair() ;

    while ((thisAttribute)) {
        switch (thisAttribute->ncDataTypeID) {
        case NC_BYTE :
        anUChar = thisAttribute->data ;
        if (anUChar[0]) {
            setStringValForKeyIn(pList, "Yes", thisAttribute->attributeName) ;
        }
        else {
            setStringValForKeyIn(pList, "No", thisAttribute->attributeName) ;
        }
        break ;

        case NC_CHAR :
            setStringValForKeyIn(pList, thisAttribute->data, thisAttribute->attributeName) ;
        break ;
    
        case NC_INT : 
        setStringValForKeyIn(pList, "int", "Data type") ;
        setIntValForKeyIn(pList, NC_INT, "ncDataType") ;
        if (thisAttribute->dataLength == 1) {
            setIntValForKeyIn(pList, *(int *)thisAttribute->data, thisAttribute->attributeName) ;
        }
        else {
            setVectorIntForKeyIn(pList, (int *)thisAttribute->data, thisAttribute->dataLength, thisAttribute->attributeName) ;
        }
        break ;
        
        case NC_FLOAT :
        setStringValForKeyIn(pList, "float", "Data type") ;
        setIntValForKeyIn(pList, NC_FLOAT, "ncDataType") ;
        if (thisAttribute->dataLength == 1) {
            setFloatValForKeyIn(pList, *(float *)thisAttribute->data, thisAttribute->attributeName) ;
        }
        else {
            setVectorFloatForKeyIn(pList, (float *)thisAttribute->data, thisAttribute->dataLength, thisAttribute->attributeName) ;
        }
        break ;
    
        case NC_DOUBLE :
        setStringValForKeyIn(pList, "double", "Data type") ;
        setIntValForKeyIn(pList, NC_DOUBLE, "ncDataType") ;
        if (thisAttribute->dataLength == 1) {
            setDoubleValForKeyIn(pList, *(double *)thisAttribute->data, thisAttribute->attributeName) ;
        }
        else {
            setVectorDoubleForKeyIn(pList, (double *)thisAttribute->data, thisAttribute->dataLength, thisAttribute->attributeName) ;
        }
        break ;
    
        default:
            break;
        }

        thisAttribute = thisAttribute->nextOne ;
    }

    return (pList) ;
}