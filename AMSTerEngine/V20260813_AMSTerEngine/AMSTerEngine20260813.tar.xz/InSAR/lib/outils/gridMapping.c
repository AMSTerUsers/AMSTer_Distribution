
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  grid.c
 *  SLC2PRI
 *
 *  Created by Dominique Derauw on Mon Oct 13 2003.
 *  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
 *
 */

#include "gridMapping.h"

/* Grid allocation */
gridMap *allocGridStructure()
{
    gridMap * aGrid ;

    if ((aGrid = malloc(sizeof(gridMap))) != NULL) {
        aGrid->charVal = NULL ;
        aGrid->floatVal = NULL ;
        aGrid->val = NULL ;
        aGrid->T = NULL ;
        aGrid->M = NULL ;
        aGrid->typeSize = 0 ;
        aGrid->outVal = 0. ;
        aGrid->noVal = 1. * genFloatNaN() ;
    }

    return(aGrid) ;
}

void freeGridMap(gridMap *aGridMap)
{
    if (aGridMap != NULL) {
        if (aGridMap->val != NULL) {
            freeMatrixDouble(aGridMap->val, 0, 0) ;
            aGridMap->val = NULL ;
        }   

        if (aGridMap->charVal) {
            freeMatrixUChar((unsigned char **)aGridMap->charVal, 0, 0) ;
            aGridMap->charVal = NULL ;
        }

        if (aGridMap->floatVal != NULL) {
            freeMatrixFloat(aGridMap->floatVal, 0, 0) ;
            aGridMap->floatVal = NULL ;
        }
        
        if (aGridMap->T != NULL) {
            freeMatrixDouble(aGridMap->T, 0, 0) ;
            aGridMap->T = NULL ;
        }
        aGridMap->M = NULL ;

        free(aGridMap) ;
    }
}

/* A grid, is a mesh covering a bidimensional data */
/* In the following, we use the names dimGridX and dimGridY for the mesh dimensions */
/* It is to say, typically, the dimensions of the output image or data file */
/* Size of the grid itself, it is to say the input data dimension is given by Nx and Ny */

/* Grid creation and initialization */
/* except grid values to be attributed specifically by caller */
/* Grid spacing is calculated from required number of grid points Nx and Ny */
gridMap *createGrid(int dimGridX, int dimGridY, int Nx, int Ny)
{
    gridMap *grid ;

    if(!Nx || !Ny || (Nx > dimGridX) || (Ny > dimGridY)) grid = (gridMap *)NULL ;
    else {
        if((grid = allocGridStructure()) != NULL) {
            grid->Nx = Nx ;
            grid->Ny = Ny ;
            grid->dimGridX = dimGridX ;
            grid->dimGridY = dimGridY ;
            grid->dNx = (dimGridX - 1) / (Nx - 1) ;
            if(dimGridX - (Nx - 1) * grid->dNx - 1) grid->dNx++ ;
            grid->dNy = (dimGridY - 1) / (Ny - 1) ;
            if(dimGridY - (Ny - 1) * grid->dNy - 1) grid->dNy++ ;
            grid->x0 = (dimGridX - grid->dNx * (Nx - 1) - 1) / 2 ;
            grid->y0 = (dimGridY - grid->dNy * (Ny - 1) - 1) / 2 ;
            grid->val = matrixDouble(0, Nx - 1, 0, Ny - 1) ;
        }
    }

    return grid ;
}

/* Grid creation and initialization */
/* except grid values to be attributed specifically by caller */
/* X Grid spacing is is given in dNx */
/* Number of Y Grid points is given in Ny */
gridMap *createGridWithXSpacing(int dimGridX, int dimGridY, int dNx, int Ny)
{
    gridMap *grid ;

    if((dNx < 1) || !Ny || (dNx > dimGridX / 3) || (Ny > dimGridY)) grid = (gridMap *)NULL ;
    else {
        if((grid = allocGridStructure()) != NULL) {
            grid->dNx = dNx ;
            grid->Ny = Ny ;
            grid->dimGridX = dimGridX ;
            grid->dimGridY = dimGridY ;
            grid->Nx = div(dimGridX, dNx).quot + (div(dimGridX, dNx).rem != 0) + 1 ;
            grid->dNy = (dimGridY - 1) / (Ny - 1) ;
            if(dimGridY - (Ny - 1) * grid->dNy - 1) grid->dNy++ ;
            grid->x0 = (dimGridX - grid->dNx * (grid->Nx - 1) - 1) / 2 ;
            grid->y0 = (dimGridY - grid->dNy * (grid->Ny - 1) - 1) / 2 ;
            grid->val = matrixDouble(0, grid->Nx - 1, 0, grid->Ny - 1) ;
        }
    }

    return grid ;
}

/* Grid creation and initialization */
/* except grid values to be attributed specifically by caller */
/* Number of X Grid points is given in Nx */
/* Y Grid spacing is is given in dNy */
gridMap *createGridWithYSpacing(int dimGridX, int dimGridY, int Nx, int dNy)
{
    gridMap *grid ;

    if(!Nx || (dNy < 1) || (Nx > dimGridX) || (dNy > dimGridY / 3)) grid = (gridMap *)NULL ;
    else {
        if((grid = allocGridStructure()) != NULL) {
            grid->Nx = Nx ;
            grid->dNy = dNy ;
            grid->dimGridX = dimGridX ;
            grid->dimGridY = dimGridY ;
            grid->dNx = (dimGridX - 1) / (Nx - 1) ;
            if(dimGridX - (Nx - 1) * grid->dNx - 1) grid->dNx++ ;
            grid->Ny = div(dimGridY, dNy).quot + (div(dimGridY, dNy).rem != 0) + 1 ;
            grid->x0 = (dimGridX - grid->dNx * (grid->Nx - 1) - 1) / 2 ;
            grid->y0 = (dimGridY - grid->dNy * (grid->Ny - 1) - 1) / 2 ;
            grid->val = matrixDouble(0, grid->Nx - 1, 0, grid->Ny - 1) ;
        }
    }

    return grid ;
}

/* Grid creation and initialization */
/* except grid values to be attributed specifically by caller */
/* dimGridX x dimGridY is the dimension of the mesh to overlay on the grid */
/* dNx x dNy is the number of overlayed mesh cells per grid element */
/* From these values, the size of the input grid is computed and allocated */
gridMap *createGridWithXYSpacing(int dimGridX, int dimGridY, int dNx, int dNy)
{
    gridMap *grid ;

    if((dNx < 1) || (dNy < 1) || (dNx > dimGridX / 3) || (dNy > dimGridY / 3)) grid = (gridMap *)NULL ;
    else {
        if((grid = allocGridStructure()) != NULL) {
            grid->dNx = dNx ;
            grid->dNy = dNy ;
            grid->dimGridX = dimGridX ;
            grid->dimGridY = dimGridY ;
            grid->Nx = div(dimGridX, dNx).quot + (div(dimGridX, dNx).rem != 0) + 1 ;
            grid->Ny = div(dimGridY, dNy).quot + (div(dimGridY, dNy).rem != 0) + 1 ;
            grid->x0 = (dimGridX - grid->dNx * (grid->Nx - 1) - 1) / 2 ;
            grid->y0 = (dimGridY - grid->dNy * (grid->Ny - 1) - 1) / 2 ;
            grid->val = matrixDouble(0, grid->Nx - 1, 0, grid->Ny - 1) ;
        }
    }

    return grid ;
}

/* Float grid creation and initialization. Only grid size and sampling are given */
/* All other parameters (covered area & origin) must be set by caller including grid values */
/* Nx x Ny is the dimension of the input grid */
/* dNx x dNy is the number of overlayed mesh cells per grid element */
gridMap *createFloatGridOfSize(int Nx, int Ny, int dNx, int dNy)
{
    gridMap *grid = NULL ;

    grid = createGridOfSize(Nx, Ny, dNx, dNy, 4) ;
    grid->floatVal = (float **)(grid->M) ;

    return grid ;
}

/* Creation and initialization of a grid of given type. Only grid size and sampling are given */
/* All other parameters (covered area & origin) must be set by caller including grid values */
/* Nx x Ny is the dimension of the input grid */
/* dNx x dNy is the number of overlayed mesh cells per grid element */
gridMap *createGridOfSize(int Nx, int Ny, int dNx, int dNy, size_t typeSize)
{
    gridMap *grid = NULL ;

    if((grid = allocGridStructure()) != NULL) {
        grid->dNx = dNx ;
        grid->dNy = dNy ;
        grid->dimGridX = (Nx - 1) * dNx + 1 ;
        grid->dimGridY = (Ny - 1) * dNy + 1 ;
        grid->Nx = Nx ;
        grid->Ny = Ny ;
        grid->x0 = (grid->dimGridX - grid->dNx * (grid->Nx - 1) - 1) / 2 ;
        grid->y0 = (grid->dimGridY - grid->dNy * (grid->Ny - 1) - 1) / 2 ;
        grid->M = matrixOfType(0, grid->Nx - 1, 0, grid->Ny - 1, typeSize) ;
        grid->typeSize = typeSize ;
        switch (typeSize) {
            case 1:
            grid->charVal = (char **)(grid->M) ;
            break;
        
            case 4:
            grid->floatVal = (float **)(grid->M) ;
            break;
        
        default:
            grid->val = (double **)(grid->M) ;
        break;
        }
    }

    return grid ;
}


/* Convert grid point into corresponding image coordinate */
coord2D	imageCoordinateForGridPoint(gridMap *grid, int xGrid, int yGrid)
{
    coord2D point ;

    point.x = grid->x0 + xGrid * grid->dNx ;
    point.y = grid->y0 + yGrid * grid->dNy ;

    return point ;
}

/* Convert image coordinate to corresponding grid position */
coord2D gridCoordinateForImagePoint(gridMap *grid, int xImage, int yImage)
{
    coord2D	gridCoordinate ;

    gridCoordinate.x = (xImage - (double)grid->x0)/(double)grid->dNx ;
    gridCoordinate.y = (yImage - (double)grid->y0)/(double)grid->dNy ;

    return gridCoordinate ;
}

/* Convert grid point into corresponding image coordinate */
coord2D	imageCoordinateForGridCoordinate(gridMap *grid, coord2D gridCoordinate)
{
    coord2D imageCoordinate ;

    imageCoordinate.x = grid->x0 + gridCoordinate.x * grid->dNx ;
    imageCoordinate.y = grid->y0 + gridCoordinate.y * grid->dNy ;

    return imageCoordinate ;
}

/* Convert image coordinate to corresponding grid position */
coord2D gridCoordinateForImageCoordinate(gridMap *grid, coord2D imageCoordinate)
{
    coord2D	gridCoordinate ;

    gridCoordinate.x = (imageCoordinate.x - (double)grid->x0)/(double)grid->dNx ;
    gridCoordinate.y = (imageCoordinate.y - (double)grid->y0)/(double)grid->dNy ;

    return gridCoordinate ;
}

/* interpolate grid value at image point coordinate (Triangular interpolation) */
double	interpolGridForImagePosition(gridMap *grid, int xImage, int yImage)
{
    int		n, m, i1x, i2x, i3x, i1y, i2y, i3y ;
    double	A, B, C ;
    coord2D	gridCoordinate ;

    gridCoordinate = gridCoordinateForImagePoint(grid, xImage, yImage) ;

	if((gridCoordinate.x >= 0) && (gridCoordinate.x <= grid->Nx - 1) && (gridCoordinate.y >= 0) && (gridCoordinate.y <= grid->Ny - 1)) {
		n = ceil((gridCoordinate.y + gridCoordinate.x) / 2) ;
		m = ceil((gridCoordinate.y - gridCoordinate.x) / 2) ;
		i1x = i2x = i3x = n - m ;
		i1y = i2y = i3y = n + m - 1 * (n + m != 0) ;

        C = grid->val[i1x][i1y] ;
        if (areFloatValsEquals(C, grid->noVal)) {
            return (grid->noVal) ;
        }

		i2x += (gridCoordinate.x > i1x)? +1 : (gridCoordinate.x < i1x)? -1 : 0 ;
		A = grid->val[i2x][i2y] ;
        if (areFloatValsEquals(A, grid->noVal)) {
            return (grid->noVal) ;
        }
        A -=  C ;
		if(gridCoordinate.x < i1x) A *= -1 ;

		i3y += (gridCoordinate.y  > i1y)? +1 : (gridCoordinate.y  < i1y)? -1 : 0 ;
        B = grid->floatVal[i3x][i3y] ;
        if (areFloatValsEquals(B, grid->noVal)) {
            return (grid->noVal) ;
        }
        B -=  C ;
		if(gridCoordinate.y < i1y) B *= -1 ;

		return A * (gridCoordinate.x - i1x) + B * (gridCoordinate.y - i1y) + C ;
	}
	else return grid->outVal ;
}


/* interpolate grid value at image point coordinate (Triangular interpolation) */
/* This function is added simply to allow computing value for a non integer image point coordinate */
double	interpolGridForImageCoordinate(gridMap *grid, double xImage, double yImage)
{
    int		n, m, i1x, i2x, i3x, i1y, i2y, i3y ;
    double	A, B, C ;
    coord2D	gridCoordinate, imageCoordinate ;

    imageCoordinate.x = xImage ;
    imageCoordinate.y = yImage ;
    if (grid->T != NULL) {
        planeAffineTransformOfCoord2D(&imageCoordinate, &imageCoordinate, grid->T) ;
    }

    gridCoordinate = gridCoordinateForImageCoordinate(grid, imageCoordinate) ;

	if((gridCoordinate.x >= 0) && (gridCoordinate.x <= grid->Nx - 1) && (gridCoordinate.y >= 0) && (gridCoordinate.y <= grid->Ny - 1)) {
		n = ceil((gridCoordinate.y + gridCoordinate.x) / 2) ;
		m = ceil((gridCoordinate.y - gridCoordinate.x) / 2) ;
		i1x = i2x = i3x = n - m ;
		i1y = i2y = i3y = n + m - 1 * (n + m != 0) ;

		C = grid->val[i1x][i1y] ;
        if (areFloatValsEquals(C, grid->noVal)) {
            return (grid->noVal) ;
        }

		i2x += (gridCoordinate.x > i1x)? +1 : (gridCoordinate.x < i1x)? -1 : 0 ;
        A = grid->val[i2x][i2y] ;
        if (areFloatValsEquals(A, grid->noVal)) {
            return (grid->noVal) ;
        }
        A -=  C ;
		if(gridCoordinate.x < i1x) A *= -1 ;

		i3y += (gridCoordinate.y  > i1y)? +1 : (gridCoordinate.y  < i1y)? -1 : 0 ;
        B = grid->val[i3x][i3y] ;
        if (areFloatValsEquals(B, grid->noVal)) {
            return (grid->noVal) ;
        }
        B -=  C ;
		if(gridCoordinate.y < i1y) B *= -1 ;

		return A * (gridCoordinate.x - i1x) + B * (gridCoordinate.y - i1y) + C ;
    }
    else return grid->outVal ;
}


/* interpolate grid value at image point coordinate (Triangular interpolation) */
/* This function is added simply to allow computing value for a non integer image point coordinate */
double	interpolFloatGridForImageCoordinate(gridMap *grid, double xImage, double yImage)
{
    int		n, m, i1x, i2x, i3x, i1y, i2y, i3y ;
    double	A, B, C ;
    coord2D	gridCoordinate, imageCoordinate ;

    imageCoordinate.x = xImage ;
    imageCoordinate.y = yImage ;
    if (grid->T != NULL) {
        planeAffineTransformOfCoord2D(&imageCoordinate, &imageCoordinate, grid->T) ;
    }

    gridCoordinate = gridCoordinateForImageCoordinate(grid, imageCoordinate) ;

	if((gridCoordinate.x >= 0) && (gridCoordinate.x <= grid->Nx - 1) && (gridCoordinate.y >= 0) && (gridCoordinate.y <= grid->Ny - 1)) {
		n = ceil((gridCoordinate.y + gridCoordinate.x) / 2) ;
		m = ceil((gridCoordinate.y - gridCoordinate.x) / 2) ;
		i1x = i2x = i3x = n - m ;
		i1y = i2y = i3y = n + m - 1 * (n + m != 0) ;

        C = grid->floatVal[i1x][i1y] ;
		if (areFloatValsEquals(C, grid->noVal)) {
            return (grid->noVal) ;
        }

		i2x += (gridCoordinate.x > i1x)? +1 : (gridCoordinate.x < i1x)? -1 : 0 ;
        A = grid->floatVal[i2x][i2y] ;
        if (areFloatValsEquals(A, grid->noVal)) {
            return (grid->noVal) ;
        }
		A -=  C ;
		if(gridCoordinate.x < i1x) A *= -1 ;

		i3y += (gridCoordinate.y  > i1y)? +1 : (gridCoordinate.y  < i1y)? -1 : 0 ;
        B = grid->floatVal[i3x][i3y] ;
        if (areFloatValsEquals(B, grid->noVal)) {
            return (grid->noVal) ;
        }
		B -=  C ;
		if(gridCoordinate.y < i1y) B *= -1 ;

		return A * (gridCoordinate.x - i1x) + B * (gridCoordinate.y - i1y) + C ;
    }
    else return grid->outVal ;
}


/* Square extrapolation of grid values */
/* All four values of a grid cell are taken into account and weighted with respect to the distance of the target point to the cell corner */
double weightedExtrapolationOfGridForImageCoordinate(gridMap *grid, double xImage, double yImage)
{
    int ix0, iy0 ;
    double dx, dy, resultValue ;
    coord2D	gridCoordinate, imageCoordinate ;

    imageCoordinate.x = xImage ;
    imageCoordinate.y = yImage ;
    if (grid->T != NULL) {
        planeAffineTransformOfCoord2D(&imageCoordinate, &imageCoordinate, grid->T) ;
    }

    gridCoordinate = gridCoordinateForImageCoordinate(grid, imageCoordinate) ;

	if((gridCoordinate.x >= 0) && (gridCoordinate.x <= grid->Nx - 1) && (gridCoordinate.y >= 0) && (gridCoordinate.y <= grid->Ny - 1)) {
        ix0 = (int)floor(gridCoordinate.x) ;
        iy0 = (int)floor(gridCoordinate.y) ;
        dx = gridCoordinate.x - floor(gridCoordinate.x) ;
        dy = gridCoordinate.y - floor(gridCoordinate.y) ;
        if (ix0 == grid->Nx - 1) {
            ix0-- ;
            dx = 1;
        }
        if (iy0 == grid->Ny - 1) {
            iy0-- ;
            dy = 1;
        }
    }
    else {
        return grid->outVal ;
    }

    if (grid->floatVal) {
        resultValue = (1. - dy) * (dx * grid->floatVal[ix0 + 1][iy0] + (1. - dx) * grid->floatVal[ix0][iy0]) + dy * (dx * grid->floatVal[ix0 + 1][iy0 + 1] + (1. - dx) * grid->floatVal[ix0][iy0 + 1]);
    }
    else {
        resultValue = (1. - dy) * (dx * grid->val[ix0 + 1][iy0] + (1. - dx) * grid->val[ix0][iy0]) + dy * (dx * grid->val[ix0 + 1][iy0 + 1] + (1. - dx) * grid->val[ix0][iy0 + 1]);
    }
    
    return (resultValue) ;
}

/* Nearest neighbour interpolation of grid values */
/* Returns the expected value if dealing with float grid */
/* In case of byte grid, it returns 0. Expected value is saved within grid->charOutput variable */
float nearestNeighbourInterpolationOfGridForImageCoordinate(gridMap *grid, double xImage, double yImage)
{
    int ix0, iy0 ;
    double dx, dy, resultValue = 0 ;
    coord2D	gridCoordinate, imageCoordinate ;

    imageCoordinate.x = xImage ;
    imageCoordinate.y = yImage ;
    if (grid->T != NULL) {
        planeAffineTransformOfCoord2D(&imageCoordinate, &imageCoordinate, grid->T) ;
    }

    gridCoordinate = gridCoordinateForImageCoordinate(grid, imageCoordinate) ;
    resultValue = grid->outVal ;
	if((gridCoordinate.x >= 0) && (gridCoordinate.x <= grid->Nx - 1) && (gridCoordinate.y >= 0) && (gridCoordinate.y <= grid->Ny - 1)) {
        ix0 = (int)floor(gridCoordinate.x) ;
        iy0 = (int)floor(gridCoordinate.y) ;
        dx = gridCoordinate.x - floor(gridCoordinate.x) ;
        dy = gridCoordinate.y - floor(gridCoordinate.y) ;
        if (dx > .5) {
            ix0++ ;
        }
        if (dy > .5) {
            iy0++ ;
        }
        
        switch (grid->typeSize) {
        case 1:
            grid->charOutput = grid->charVal[ix0][iy0] ;
            break;
        
        case 4:
            resultValue = grid->floatOutput = grid->floatVal[ix0][iy0] ;
            break;
        
        default:
            break;
        }
    }
    return resultValue ;
}



/* Square extrapolation of phase grid values */
/* All four values of a grid cell are taken into account and weighted with respect to the distance of the target point to the cell corner */
float weightedExtrapolationOfPhaseGridForImageCoordinate(gridMap *grid, double xImage, double yImage)
{
    int ix0, iy0 ;
    double dx, dy, resultPhase ;
    complexDouble gridVal[4], resultValue ;
    coord2D	gridCoordinate, imageCoordinate ;

    imageCoordinate.x = xImage ;
    imageCoordinate.y = yImage ;
    if (grid->T != NULL) {
        planeAffineTransformOfCoord2D(&imageCoordinate, &imageCoordinate, grid->T) ;
    }

    gridCoordinate = gridCoordinateForImageCoordinate(grid, imageCoordinate) ;

	if((gridCoordinate.x >= 0) && (gridCoordinate.x <= grid->Nx - 2) && (gridCoordinate.y >= 0) && (gridCoordinate.y <= grid->Ny - 2)) {
        ix0 = (int)floor(gridCoordinate.x) ;
        iy0 = (int)floor(gridCoordinate.y) ;
        dx = gridCoordinate.x - floor(gridCoordinate.x) ;
        dy = gridCoordinate.y - floor(gridCoordinate.y) ;

        gridVal[0].r = (double)cosf(grid->floatVal[ix0][iy0]) ;
        gridVal[0].i = (double)sinf(grid->floatVal[ix0][iy0]) ;
        gridVal[1].r = (double)cosf(grid->floatVal[ix0 + 1][iy0]) ;
        gridVal[1].i = (double)sinf(grid->floatVal[ix0 + 1][iy0]) ;
        gridVal[2].r = (double)cosf(grid->floatVal[ix0 + 1][iy0 + 1]) ;
        gridVal[2].i = (double)sinf(grid->floatVal[ix0 + 1][iy0 + 1]) ;
        gridVal[3].r = (double)cosf(grid->floatVal[ix0][iy0 + 1]) ;
        gridVal[3].i = (double)sinf(grid->floatVal[ix0][iy0 + 1]) ;

        resultValue.r = (1. - dy) * (dx * gridVal[1].r + (1. - dx) * gridVal[0].r) + dy * (dx * gridVal[2].r + (1. - dx) * gridVal[3].r) ;
        resultValue.i = (1. - dy) * (dx * gridVal[1].i + (1. - dx) * gridVal[0].i) + dy * (dx * gridVal[2].i + (1. - dx) * gridVal[3].i) ;
        resultPhase = phaseOfComplexDouble(&resultValue) ;

        return ((float)resultPhase) ;
    }
    else return grid->outVal ;
}


