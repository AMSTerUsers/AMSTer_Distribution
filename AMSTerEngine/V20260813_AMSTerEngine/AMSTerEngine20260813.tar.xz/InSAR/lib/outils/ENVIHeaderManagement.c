
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  ENVIHeaderManagement.c
//  slantRangeDEM
//
//  Created by Dominique Derauw on 24/04/2017.
//  Copyright © 2017 Dominique Derauw. All rights reserved.
//

#include "ENVIHeaderManagement.h"

keyValue *readENVIHeader(char *HDRPath)
{
    char *key, *stringVal, *stringVal2 = NULL, itsOk ;
    int xRefIndex, yRefIndex ;
    double X0, Y0 ;
    keyValue *ENVIHeader = NULL ;
    rawFileDescriptor *ENVIHeaderFile ;
    CSVStruct *aCSV;

    if ((ENVIHeaderFile = openRawFileForReadingAtPath(HDRPath))) {
        ENVIHeader = allocAKeyValuePair() ;
        fgets(aTextLine, TEXT_LINE_MAX_LENGTH, ENVIHeaderFile->f) ;
        if (strncmp(aTextLine, "ENVI", 4)) {
            freeKeyValueList(ENVIHeader) ;
            return(NULL) ;
        }

        while (fgets(aTextLine, TEXT_LINE_MAX_LENGTH, ENVIHeaderFile->f)) {
            stripWhiteCharsAtStartOfString(aTextLine) ;
            if((key = getStringUpToDelimiter(aTextLine, "="))) {
                stripWhiteCharsAtStartOfString(key) ;
                stripWhiteCharsAtEndOfString(key) ;
                convertStringToLowercase(key) ;

                stringVal = getStringAfterDelimiter(aTextLine, "=") ;
                stripWhiteCharsAtStartOfString(stringVal) ;
                if (!strncmp(stringVal, "{", 1)) {
                    itsOk = 1 ;
                    while (!isSubStringPresentInString(aTextLine, "}") && itsOk) {
                        if((itsOk = (fgets(aTextLine, TEXT_LINE_MAX_LENGTH, ENVIHeaderFile->f) != NULL))) {
                            stringVal2 = concatenateStrings(stringVal, aTextLine) ;
                            free(stringVal) ;
                            stringVal = stringVal2 ;
                        }
                    }
                    removeAnyOccurrenceOfSubStringInString(stringVal, "{") ;
                    removeAnyOccurrenceOfSubStringInString(stringVal, "}") ;
                }

                stripWhiteCharsAtStartOfString(stringVal) ;
                stripWhiteCharsAtEndOfString(stringVal) ;
                replaceWhiteCharsInStringByChar(stringVal, 0x20) ;
                setStringValForKeyIn(ENVIHeader, stringVal, key) ;

                free(key) ;
                free(stringVal) ;
            }
        }

        if((stringVal = getStringValForKeyIn(ENVIHeader, "map info"))) {
            aCSV = readCSVInString(stringVal) ;
            if (aCSV->numberOfEntries >= 8) {
                setStringValForKeyIn(ENVIHeader, aCSV->stringVal[0], "Coordinate system") ;
                setStringValForKeyIn(ENVIHeader, aCSV->stringVal[1], "X index of reference pixel") ;
                setStringValForKeyIn(ENVIHeader, aCSV->stringVal[2], "Y index of reference pixel") ;
                setStringValForKeyIn(ENVIHeader, aCSV->stringVal[3], "Easting of reference pixel") ;
                setStringValForKeyIn(ENVIHeader, aCSV->stringVal[4], "Northing of reference pixel") ;
                setStringValForKeyIn(ENVIHeader, aCSV->stringVal[5], "X sampling") ;
                setStringValForKeyIn(ENVIHeader, aCSV->stringVal[6], "Y sampling") ;
                if(isSubStringPresentInString(getStringValForKeyIn(ENVIHeader, "Coordinate"), "UTM")) {
                    setStringValForKeyIn(ENVIHeader, aCSV->stringVal[7], "UTMZone") ;
                    setStringValForKeyIn(ENVIHeader, aCSV->stringVal[8], "Emisphere") ;
                    setStringValForKeyIn(ENVIHeader, aCSV->stringVal[9], "Geoid") ;
                    if (aCSV->numberOfEntries > 10) {
                        stringVal = getStringAfterDelimiter(aCSV->stringVal[10], "=") ;
                        removeAnyOccurrenceOfSubStringInString(stringVal, "}") ;
                        setStringValForKeyIn(ENVIHeader, stringVal, "Units") ;
                        free(stringVal) ;
                    }
                }
                else {
                    setStringValForKeyIn(ENVIHeader, aCSV->stringVal[7], "Geoid") ;
                    if (aCSV->numberOfEntries > 8) {
                        stringVal = getStringAfterDelimiter(aCSV->stringVal[8], "=") ;
                        removeAnyOccurrenceOfSubStringInString(stringVal, "}") ;
                        setStringValForKeyIn(ENVIHeader, stringVal, "Units") ;
                        free(stringVal) ;
                    }
                }
                 removeKeyValuePairIn(ENVIHeader, "map info") ;

                xRefIndex = getIntValForKeyIn(ENVIHeader, "X index") - 1 ;
                yRefIndex = getIntValForKeyIn(ENVIHeader, "lines") - getIntValForKeyIn(ENVIHeader, "Y index") + 1 ;
                X0 = getDoubleValForKeyIn(ENVIHeader, "Easting") - xRefIndex * getDoubleValForKeyIn(ENVIHeader, "X sampling") ;
                Y0 = getDoubleValForKeyIn(ENVIHeader, "Northing") - yRefIndex * getDoubleValForKeyIn(ENVIHeader, "Y sampling") ;
                setDoubleValForKeyIn(ENVIHeader, X0, "Lower left pixel X coordinate") ;
                setDoubleValForKeyIn(ENVIHeader, Y0, "Lower left pixel Y coordinate") ;
            }
            freeCSVStruct(aCSV) ;
        }
/*
        stripExtensionAtEndOfPath(ENVIHeaderFile->accessPath) ;
        aPath = initStringWith2Strings(ENVIHeaderFile->accessPath, ".txt") ;
        writeParameterFileAtPath(ENVIHeader, aPath) ;
        free(aPath) ;
 */
        freeRawFileDescriptor(ENVIHeaderFile) ;
    }

    return (ENVIHeader) ;
}

void writeENVIHeaderAtPath(char *headerPath, keyValue *ENVIHeader)
{
    char *coordinatSystem, *aPath, *binFilePath ;
    int UTMZone, indiceZoneLatUTM ;
    int anInt ;
    rawFileDescriptor *outputFile ;

    if (strncmp(getPointerToLastFileExtensionInPath(headerPath), "hdr", 3)) {
        binFilePath = initStringWithString(headerPath) ;
        if (!strncmp(getPointerToLastFileExtensionInPath(headerPath), "bin", 3) || !strncmp(getPointerToLastFileExtensionInPath(headerPath), "bil", 3)) {
            stripExtensionAtEndOfPath(binFilePath) ;
        }
        
        aPath = initStringWith2Strings(binFilePath, ".hdr") ;
        free(binFilePath) ;
    }
    else {
        aPath = initStringWithString(headerPath) ;
    }
    

    if ((outputFile = openRawFileForWritingAtPath(aPath)) == NULL) {
        ase("Failed to create ENVI Header at requested path") ;
    }
    fprintf(outputFile->f, "ENVI\n") ;
    fprintf(outputFile->f, "File type = ENVI Standard\n") ;
//    fprintf(outputFile->f, "Description = {%s}\n", description) ;

    if ((anInt = getIntValForKeyIn(ENVIHeader, "header"))) {
        fprintf(outputFile->f, "Header offset = %d\n", anInt) ;
    }
    else {
        fprintf(outputFile->f, "Header offset = 0\n") ;
    }
    
    if ((anInt = getIntValForKeyIn(ENVIHeader, "bands"))) {
        fprintf(outputFile->f, "Bands = %d\n", anInt) ;
    }
    else {
        fprintf(outputFile->f, "Bands = 1\n") ;
    }
    
    if ((anInt = getIntValForKeyIn(ENVIHeader, "data type"))) {
        fprintf(outputFile->f, "Data type = %d\n", anInt) ;
    }
    else {
        fprintf(outputFile->f, "Data type = 4\n") ;
    }
    
    if (isArchBigEndian()) {
        fprintf(outputFile->f, "byte order = 1\n") ;
    }
    else {
        fprintf(outputFile->f, "byte order = 0\n") ;
    }

    fprintf(outputFile->f, "Samples = %d\n", getIntValForKeyIn(ENVIHeader, "samples")) ;
    fprintf(outputFile->f, "Lines = %d\n", getIntValForKeyIn(ENVIHeader, "lines")) ;

    if ((coordinatSystem = getStringValForKeyIn(ENVIHeader, "Coordinate system"))) {
        if (!strncmp(coordinatSystem, "UTM", 3)) {
            fprintf(outputFile->f, "Map info = {UTM, 1.0, 1.0, ") ;
            fprintf(outputFile->f, "%lf, %lf, ", getFloatValForKeyIn(ENVIHeader, "Easting of reference pixel"), getFloatValForKeyIn(ENVIHeader, "Northing of reference pixel")) ;
            fprintf(outputFile->f, "%lf, %lf, ", getFloatValForKeyIn(ENVIHeader, "X sampling"), getFloatValForKeyIn(ENVIHeader, "X sampling")) ;
            UTMZone = getIntValForKeyIn(ENVIHeader, "UTMZone") ;
            fprintf(outputFile->f, "%d, ", UTMZone) ;
            indiceZoneLatUTM = getIntValForKeyIn(ENVIHeader, "indiceZoneLatUTM") ;
            if (isKeyValPresent(ENVIHeader, "Emisphere")) {
                fprintf(outputFile->f, "%s, ", getStringValForKeyIn(ENVIHeader, "Emisphere")) ;
            }
            else {
                if (indiceZoneLatUTM < 12) {
                    fprintf(outputFile->f, "South, ") ;
                }
                else {
                    fprintf(outputFile->f, "North, ") ;
                }
            }
            fprintf(outputFile->f, "WGS84, units=Meters}\n") ;
        }
        else {
            fprintf(outputFile->f, "Map info = {Geographic Lat/Lon, 1.0, 1.0, ") ;
            fprintf(outputFile->f, "%lf, %lf, ", getFloatValForKeyIn(ENVIHeader, "Easting of reference pixel"), getFloatValForKeyIn(ENVIHeader, "Northing of reference pixel")) ;
            fprintf(outputFile->f, "%lf, %lf, ", getFloatValForKeyIn(ENVIHeader, "X sampling"), getFloatValForKeyIn(ENVIHeader, "X sampling")) ;
            fprintf(outputFile->f, "WGS84, units=Degrees}\n") ;
        }
    }
    fprintf(outputFile->f, "Data ignore value = NAN\n") ;

    freeRawFileDescriptor(outputFile) ;
    free(aPath) ;

}

char *getENVIHeaderPathOfFile(char *aPath)
{
    char *headerPath = NULL ;
    char *copyOfPath ;

    copyOfPath = initStringWithString(aPath) ;
    headerPath = initStringWith2Strings(copyOfPath, ".hdr") ;
    if (!fileExistsAtPath(headerPath)) {
        free(headerPath) ;
        stripExtensionAtEndOfPath(copyOfPath) ;
        headerPath = initStringWith2Strings(copyOfPath, ".hdr") ;
        if (!fileExistsAtPath(headerPath)) {
            free(headerPath) ;
            headerPath = NULL ;
        }
    }
    free(copyOfPath) ;

    return(headerPath) ;
}

/* Sending an Envi header file, this function returns the corresponding data file path */
/* It looks after a file with name without .hdr extension or with .bin or .bil extension in place of the .hdr one */
char *getENVIFileCorrespondingToHeader(char *aPath)
{
    char *dataFilePath = NULL ;
    char *copyOfPath ;

    copyOfPath = initStringWithString(aPath) ;
    dataFilePath = initStringWithString(aPath) ;
    stripExtensionAtEndOfPath(dataFilePath) ;

    if (!fileExistsAtPath(dataFilePath)) {
        free(dataFilePath) ;
        stripExtensionAtEndOfPath(copyOfPath) ;
        dataFilePath = initStringWith2Strings(copyOfPath, ".bin") ;
        if (!fileExistsAtPath(dataFilePath)) {
            free(dataFilePath) ;
            dataFilePath = initStringWith2Strings(copyOfPath, ".bil") ;
            if (!fileExistsAtPath(dataFilePath)) {
                free(dataFilePath) ;
                dataFilePath = NULL ;
            }
        }
    }
    free(copyOfPath) ;

    return(dataFilePath) ;
}


void generateENVIHeaderForRawFile(rawFileDescriptor *inputFile, char makeLink)
{
    char *outputPath, *newFilePath ;
    char *aString ;
    int dataType ;
    rawFileDescriptor *outputFile ;

    openRawFileForReading(inputFile) ;
    dataType = (int)(inputFile->fileLength / (inputFile->xDim * inputFile->yDim)) ;
    newFilePath = initStringWith2Strings(inputFile->accessPath, ".bil") ;
    if (makeLink) {
        symlink(inputFile->accessPath, newFilePath) ;
    }
    else {
        rename(inputFile->accessPath, newFilePath) ;
    }
    free(newFilePath) ;


    outputPath = initStringWith2Strings(inputFile->accessPath, ".hdr") ;
    outputFile = openRawFileForWritingAtPath(outputPath) ;
    free(outputPath) ;

    fprintf(outputFile->f, "ENVI\n") ;
    aString = initStringWithString(outputFile->fileName) ;
    stripExtensionAtEndOfPath(aString) ;
    sprintf(aTextLine, "%s\n", aString) ;
    fprintf(outputFile->f, "file type = ENVI Standard\n") ;
    fprintf(outputFile->f, "description = {%s}\n", aTextLine) ;
    fprintf(outputFile->f, "header offset = 0\n") ;
    fprintf(outputFile->f, "bands = 1\n") ;
    fprintf(outputFile->f, "interleave = BSQ\n") ;
    fprintf(outputFile->f, "data type = %d\n", dataType) ;

    if (isArchBigEndian()) {
        fprintf(outputFile->f, "byte order = 1\n") ;
    }
    else {
        fprintf(outputFile->f, "byte order = 0\n") ;
    }

    fprintf(outputFile->f, "samples = %ld\n", inputFile->xDim) ;
    fprintf(outputFile->f, "lines = %ld\n", inputFile->yDim) ;

//    fprintf(outputFile->f, "data ignore value = NAN\n") ;

    free(aString) ;
    freeRawFileDescriptor(outputFile) ;


}
void generateENVIHeaderForFile(char *aPath, int xDim, int yDim, char makeLink)
{
    rawFileDescriptor *inputFile ;

    if (!(inputFile = openRawFileForReadingAtPath(aPath))) {
        return ;
    }

    inputFile->xDim = xDim ;
    inputFile->yDim = yDim ;


    if (ldiv(inputFile->fileLength, xDim * yDim).rem) {
        ase("Wrong file dimensions\n") ;
    }

    generateENVIHeaderForRawFile(inputFile, makeLink) ;

    freeRawFileDescriptor(inputFile) ;
}



