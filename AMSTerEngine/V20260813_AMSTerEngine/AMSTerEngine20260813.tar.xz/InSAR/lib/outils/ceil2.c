
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/



/* ceil2.c */
/*---------------------------------------------------------------------------------------------------*/
/* Fonction retournant la plus grande puissance de 2 supérieure au nombre donne. */
/*
 *  Created by Dominique Derauw a long time ago.
 *  Copyright (c) Dominique Derauw. All rights reserved.
 *
 */

#include "ceil2.h"


void	ceil2(int *ptr_nb, int *ptr_expnb)
{
	/* definition of structure corresponding to a float in low-endian format */
	typedef struct	{
			unsigned m : 23;
			unsigned e : 8 ;
			unsigned s : 1 ;
			} fl ;

	/* definition of variables */
	fl		a;

	union {
			fl 	structfloat;
			float 	tempfloat;
	} u ;

	u.tempfloat = (float)*ptr_nb;		/* Passage d'entier a float */
	a = u.structfloat;					/* Lecture du float structure */
	if (isArchBigEndian()) {
		swap4bytesStruct(&a) ;
	}
	
	if(a.m != 0) {
		a.m = 0;							/* Mise a zero de la partie fractionnaire */
		*ptr_expnb = (int) (a.e - 126);		/* Lecture de l'exposant et passage de char a integer*/
		if (isArchBigEndian()) {
			swap4bytesStruct(&a) ;
		}
		u.structfloat = a;
		*ptr_nb = (int)(2 * u.tempfloat);	/* Lecture de la puissance de 2 recherchee et passage a entier. */
	}
	else	*ptr_expnb = (int) (a.e - 127);	
}

int ceil2ofIntVal(int anInt)
{
	int anExponent ;
	
	ceil2(&anInt, &anExponent) ;
	
	return anInt ;
}

int ceil2ofFloatVal(float aFloat)
{
	int anInt, anExponent ;
	
	anInt = (int)ceilf(aFloat) ;
	ceil2(&anInt, &anExponent) ;
	
	return anInt ;
}
