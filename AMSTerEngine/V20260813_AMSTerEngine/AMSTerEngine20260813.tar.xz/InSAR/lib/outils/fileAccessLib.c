
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  fileAccesLib.c
 *  trackDataReader
 *
 *  Created by Dominique Derauw on 3/02/05.
 *  Copyright 2005 Dominique Derauw All rights reserved.
 *
 */

#include "fileAccessLib.h"

/* Returns de last item between "/" or simply the last item from a path */
char *getFileNameFromPath(char *aPath)
{
	char *fileName, *strippedPath ;
    size_t index ;

    if (!aPath) {
        return (aPath) ;
    }

	fileName = initStringWithString(getPointerToFileNameInPath(aPath)) ;
    if(!fileName) {
        strippedPath = initStringWithString(aPath) ;
        index = strlen(strippedPath) ;
        while (strippedPath[--index] == '/') {
            strippedPath[index] = 0 ;
        }
        fileName = initStringWithString(getPointerToFileNameInPath(strippedPath)) ;
        free(strippedPath) ;
    }

	return(fileName) ;
}

/* Locate last occurrence of "/" in a file path */
char *getPointerToFileNameInPath(char *path)
{
	int	i = 0, position = 0 ;

    if (path) {
        while(path[i]) {
            if(path[i] =='/') position = i ;
            i++ ;
        }

        if(position) {
            return(&path[++position]) ;
        }
        else {
            return(path) ;
        }

    }
    return (NULL) ;
}

char *getDirectoryName(char *aPath)
{
    char *dirName ;
    int	i = 0, position = 0, formerIndex = 0 ;

    if (aPath) {
        while(aPath[i]) {
            if(aPath[i] =='/') {
                formerIndex = position ;
                position = i ;
            }
            i++ ;
        }

        if(position) {
            if (aPath[++position]) {
                dirName = initStringWithString(aPath + position) ;
            }
            else {
                dirName = initStringWithString(aPath + formerIndex) ;
                dirName[strlen(dirName) - 1] = 0 ;
            }
        }
        else {
            dirName = initStringWithString(aPath) ;
        }
        return(dirName) ;
    }
    return (NULL) ;
}

char *getFileExtensionFromPath(char *aPath)
{
	char *extension = NULL ;

	extension = initStringWithString(getPointerToLastFileExtensionInPath(aPath)) ;

	return(extension) ;
}

char *getPointerToFileExtensionInPath(char *path)

{
	int	i = 0, position = 0 ;

    if (path) {
        while(path[i]) {
            if(path[i] == '.') {
                position = i ;
                break ;
            }
            i++ ;
        }
        
        if(position > 0)
            return(path + position + 1) ;
    }
    
    return(NULL) ;
}

char *getPointerToLastFileExtensionInPath(char *path)
{
    long i = 0, position = 0 ;

    if (path) {
        i = strlen(path) - 1 ;
        while(i) {
            if(path[i] =='.') {
                position = i ;
                break ;
            }
            i-- ;
        }
    }

    if(position) {
        return(path + position + 1) ;
    }
    else {
        return(NULL) ;
    }
}

void stripExtensionAtEndOfPath(char *aPath)
{
    int	i = 0, position = 0 ;

    if (aPath) {
        while(aPath[i]) {
            if(aPath[i] =='.') position = i ;
            i++ ;
        }

        if(position)
            aPath[position] = '\0' ;
    }
    
}

void stripAllExtensions(char *aPath)
{
    int	i = 0 ;

    while(aPath[i] != '.' && aPath[i] ) {
        i++ ;
    }

    aPath[i] = '\0' ;
}

char *addExtensionAtEndOfPath(char *aPath, char *extension)
{
	char *aNewPath ;

	if(!strncmp(extension, ".", 1))
		aNewPath = initStringWith2Strings(aPath, extension) ;
	else
		aNewPath = initStringWith3Strings(aPath, ".", extension) ;

	return aNewPath ;
}

/* Return upper directory. Returned path must be freed by caller. */
char *getDirectoryPathFromPath(char *aPath)
{
	char	*dir, itsOk = 0 ;
	size_t length = 0 ;
	int		i = 0 ;

	if(aPath == NULL) return(aPath) ;

    if ((aPath = expandEnvironmentVariablesInPath(aPath)) == NULL) {
        return (NULL) ;
    }

    while(aPath[i]) {
        if(aPath[i] =='/') {
            length = i ;
            itsOk = 1 ;
        }
        i++ ;
    }
    if (!itsOk) {
        return(NULL) ;
    }
    
    dir = allocStringOfLength(++length) ;
    memcpy(dir, aPath, length) ;

    free(aPath) ;

	return dir ;
}

char *getUpperDirectoryPath(char *aDirectoryPath)
{
    char *dir ;
    long unsigned length ;

    dir = initStringWithString(aDirectoryPath) ;
    length = strlen(aDirectoryPath) ;
    while (dir[length - 1] == '/') {
        dir[length - 1] = '\0' ;
        length -- ;
    }
    while (dir[length - 1] != '/' && length > 0) {
        dir[length - 1] = '\0' ;
        length -- ;
    }

    return(dir) ;
}

char isValidDirectoryForPath(char *path)
{
    if (isDir(path) || fileExistsAtPath(path)) {
        return(1) ;
    }

    return(0) ;
}

char isSymbolicLink(char *path)
{
    struct stat buffer ;

    if(path == NULL) return(0) ;
    if(!lstat(path, &buffer)) {
        return(S_ISLNK(buffer.st_mode)) ;
    }

    return(0) ;
}

char fileExistsAtPath(char *aPath)
{
    struct stat buffer ;

    if(aPath == NULL) return(0) ;
    if(isDir(aPath)) return(0) ;
    
    if ((aPath = expandEnvironmentVariablesInPath(aPath)) == NULL) {
        return (0) ;
    }
    stripWhiteCharsAtEndOfString(aPath) ;
    if(!stat(aPath, &buffer)) {
        if(buffer.st_mode & S_IFREG) {
            free(aPath) ;
            return(1) ;
        }
    }
    free(aPath) ;

    return(0) ;
}

char isDir(char *aPath)
{
    char *fullPath ;
	struct stat buffer ;

    if(aPath == NULL) return(0) ;
    
    if ((fullPath = expandEnvironmentVariablesInPath(aPath)) == NULL) {
        return (0) ;
    }

	if(!stat(fullPath, &buffer)) {
        if(buffer.st_mode & S_IFDIR) {
            free(fullPath) ;
			return(1) ;
        }
	}

    free(fullPath) ;

	return 0 ;
}

/* Check access path at given location or at parent dir if given location is not a directory */
char isWriteAccessGrantedAtPath(char *aPath)
{
	char *accessPath ;
	int nGroups, i ;
	uid_t myUID ;
	gid_t myGID, *groupList ;
	struct stat buffer ;

	myUID = getuid() ;
    if ((aPath = expandEnvironmentVariablesInPath(aPath)) == NULL) {
        return (0) ;
    }

    if (!isDir(aPath)) {
        accessPath = getDirectoryPathFromPath(aPath) ;
        if(!isDir(accessPath)) {
            free(aPath) ;
            free(accessPath) ;
            return (0) ;
        }
    }
    else {
        accessPath = initStringWithString(aPath) ;
    }

	if(stat(accessPath, &buffer)) {
        free(aPath) ;
        free(accessPath) ;
		return(0) ;
	}
    free(aPath) ;
    free(accessPath) ;

	if(buffer.st_uid == myUID) {
		if(buffer.st_mode & S_IWUSR)
			return(1) ;
	}

	nGroups = getgroups(0, NULL) ;
	groupList = malloc(nGroups * sizeof(gid_t)) ;
	nGroups = getgroups(nGroups, groupList) ;
	for(i = 0; i < nGroups; i++) {
		myGID = groupList[i] ;
		if(buffer.st_gid == myGID) {
			if(buffer.st_mode & S_IWGRP) {
	            free(groupList) ;
				return(1) ;
            }
		}
	}

	if(buffer.st_mode & S_IWOTH) {
	    free(groupList) ;
		return(1) ;
    }

	free(groupList) ;
	return(0) ;
}

char isReadAccessGrantedAtPath(char *aPath)
{
	char *dir ;
	int nGroups, i ;
	uid_t myUID ;
	gid_t myGID, *groupList ;
	struct stat buffer ;

	myUID = getuid() ;
    if ((aPath = expandEnvironmentVariablesInPath(aPath)) == NULL) {
        return (0) ;
    }

	if(!stat(aPath, &buffer)) {
		if(buffer.st_mode & S_IFREG) {
            if((dir = getDirectoryPathFromPath(aPath)) == NULL) {
                free(aPath) ;
                return(0) ;
            }

			if(stat(dir, &buffer)) {
                free(dir) ;
                free(aPath) ;
				return(0) ;
			}
            free(dir) ;
		}
        if((buffer.st_mode & S_IFDIR) == 0) {
            free(aPath) ;
            return(0) ;
        }
	}
	else {
        free(aPath) ;
		return(0) ;
	}
    free(aPath) ;

	if(buffer.st_uid == myUID) {
		if(buffer.st_mode & S_IRUSR)
			return(1) ;
	}

	nGroups = getgroups(0, NULL) ;
	groupList = malloc(nGroups * sizeof(gid_t)) ;
	nGroups = getgroups(nGroups, groupList) ;
	for(i = 0; i < nGroups; i++) {
		myGID = groupList[i] ;
		if(buffer.st_gid == myGID) {
            if(buffer.st_mode & S_IRGRP) {
                free(groupList) ;
				return(1) ;
            }
		}
	}

	free(groupList) ;
	if(buffer.st_mode & S_IROTH)
		return(1) ;

	return(0) ;
}

char isRWAccessGrantedAtPath(char *aPath)
{
    return (isReadAccessGrantedAtPath(aPath) & isWriteAccessGrantedAtPath(aPath)) ;
}

off_t getFileLengthAtPath(char *path) {
    struct stat buffer ;

    if(!stat(path, &buffer)) {
        if(buffer.st_mode & S_IFREG) {
            return(buffer.st_size) ;
        }
    }
    return(0) ;
}

/* Recursively search directories of given name in given directory and subdirectories */
/* If dirName == NULL or dirName == "", all subdirectories are returned.*/
/* Name can be partial */
/* List of full path of found directories is returned */
CSVStruct *recursiveSearchOfDirInDir(char *dirName, char *dir)
{
    char *aPath ;
    char **directoryContent ;
    int  N, i, j ;
    CSVStruct *csvOut = NULL, *aCSV = NULL ;

    directoryContent = getDirectoryContentAtPath(dir, &N) ;
    if (directoryContent == NULL) {
        return (csvOut) ;
    }
    
    for (i = 0; i < N; i++) {
        aPath = initStringWith3Strings(dir, "/", directoryContent[i]) ;
        if (isDir(aPath)) {
            if (dirName) {
                if (isSubStringPresentInString(directoryContent[i], dirName) || dirName[0] == '\0') {
                    csvOut = addStringValInCSVStruct(aPath, csvOut) ;
                }
            }
            else {
                csvOut = addStringValInCSVStruct(aPath, csvOut) ;
            }
            if((aCSV = recursiveSearchOfDirInDir(dirName, aPath)) != NULL) {
                for (j = 0; j < aCSV->numberOfEntries; j++) {
                    csvOut = addStringValInCSVStruct(aCSV->stringVal[j], csvOut) ;
                }
                freeCSVStruct(aCSV) ;
            }
        }
        free(directoryContent[i]) ;
        free(aPath) ;
    }
    free(directoryContent) ;

    return (csvOut) ;
}

/* As its name states it, returns the listing of directories of given name within given directory */
/* dirName may be partial. If NULL or empty string, all found directories are returned. */
CSVStruct *listDirectoriesOfNameInDir(char *dirName, char *searchedDir)
{
    char *aPath, **directoryContent ;
    int N, i ; 
    CSVStruct *csvOut = NULL ;

    if (searchedDir[strlen(searchedDir) - 1] == '/') {
        searchedDir[strlen(searchedDir) - 1] = '\0' ;
    }
    
    directoryContent = getDirectoryContentAtPath(searchedDir, &N) ;
    for (i = 0; i < N; i++) {
        aPath = initStringWith3Strings(searchedDir, "/", directoryContent[i]) ;
        if (isDir(aPath)) {
            if (dirName) {
                if (isSubStringPresentInString(directoryContent[i], dirName) || dirName[0] == '\0') {
                    csvOut = addStringValInCSVStruct(aPath, csvOut) ;
                }
            }
            else {
                csvOut = addStringValInCSVStruct(aPath, csvOut) ;
            }
        }
        
        free(aPath) ;
        free(directoryContent[i]) ;
    }
    free(directoryContent) ;

    return(csvOut) ;
}

/* As its name states it, returns the listing of a given directory */
CSVStruct *getCSVDirectoryListingAtPath(char *aDir)
{
    char *aPath, **directoryContent ;
    int N, i ; 
    CSVStruct *csvOut = NULL ;

    directoryContent = getDirectoryContentAtPath(aDir, &N) ;
    for (i = 0; i < N; i++) {
        aPath = initStringWith3Strings(aDir, "/", directoryContent[i]) ;
        csvOut = addStringValInCSVStruct(aPath, csvOut) ;
        free(aPath) ;
        free(directoryContent[i]) ;
    }
    free(directoryContent) ;

    return(csvOut) ;
}


/* As its name states it, this function searches for file of given name within input directory */
/* It returns full path to found files */
/* File name can be partial */
CSVStruct *recursiveSearchOfFileInDir(char *fileName, char *dir)
{
    char *aPath ;
    char **directoryContent ;
    int  N, i, j ;
    CSVStruct *csvOut = NULL, *aCSV = NULL ;

    directoryContent = getDirectoryContentAtPath(dir, &N) ;
    for (i = 0; i < N; i++) {
        aPath = initStringWith3Strings(dir, "/", directoryContent[i]) ;
        if (isDir(aPath)) {
            if((aCSV = recursiveSearchOfFileInDir(fileName, aPath)) != NULL) {
                for (j = 0; j < aCSV->numberOfEntries; j++) {
                    csvOut = addStringValInCSVStruct(aCSV->stringVal[j], csvOut) ;
                }
                freeCSVStruct(aCSV) ;
            }
        }
        else {
            if (fileName) {
                if (isSubStringPresentInString(directoryContent[i], fileName)) {
                    csvOut = addStringValInCSVStruct(aPath, csvOut) ;
                }
            }
            else {
                csvOut = addStringValInCSVStruct(aPath, csvOut) ;
            }
        }
        free(aPath) ;
        free(directoryContent[i]) ;
    }
    free(directoryContent) ;

    return (csvOut) ;
}

/* As its name states it, this function searches for file of given name within input directory and sub directories */
/* It returns the names of found files */
/* File name can be partial */
CSVStruct *recursiveSearchOfFileNamesInDir(char *fileName, char *dir)
{
    char *aPath ;
    char **directoryContent ;
    int  N, i, j ;
    CSVStruct *csvOut = NULL, *aCSV = NULL ;

    directoryContent = getDirectoryContentAtPath(dir, &N) ;
    for (i = 0; i < N; i++) {
        aPath = initStringWith3Strings(dir, "/", directoryContent[i]) ;
        if (isDir(aPath)) {
            if((aCSV = recursiveSearchOfFileNamesInDir(fileName, aPath)) != NULL) {
                for (j = 0; j < aCSV->numberOfEntries; j++) {
                    csvOut = addStringValInCSVStruct(aCSV->stringVal[j], csvOut) ;
                }
                freeCSVStruct(aCSV) ;
            }
        }
        else {
            if (fileName) {
                if (isSubStringPresentInString(directoryContent[i], fileName)) {
                    csvOut = addStringValInCSVStruct(directoryContent[i], csvOut) ;
                }
            }
            else {
                csvOut = addStringValInCSVStruct(directoryContent[i], csvOut) ;
            }
        }
        free(aPath) ;
        free(directoryContent[i]) ;
    }
    free(directoryContent) ;

    return (csvOut) ;
}

/* Returns full path of found files with extension within given directory */
CSVStruct *listFilesWithExtensionInDir(char *extension, char *dir)
{
    char *aPath, *searchedExtension, *foundExtension ;
    char **directoryContent ;
    int  i, N ;
    CSVStruct *csvOut = NULL ;

    if (isDir(dir)) {    
        searchedExtension = extension ;
        if (extension[0] == '.') {
            searchedExtension++ ;
        }
        directoryContent = getDirectoryContentAtPath(dir, &N) ;
        for (i = 0; i < N; i++) {
            aPath = initStringWith3Strings(dir, "/", directoryContent[i]) ;
            if (fileExistsAtPath(aPath)) {
                if ((foundExtension = getPointerToLastFileExtensionInPath(directoryContent[i])) != NULL) {
                    if (!strcmp(searchedExtension, foundExtension)) {
                        csvOut = addStringValInCSVStruct(aPath, csvOut) ;
                    }
                }
            }
            free(directoryContent[i]) ;
            free(aPath) ;
        }
        free(directoryContent) ;
    }

    return (csvOut) ;
}

/* Returns full path of found files with name within given directory */
/* File name can be partial */
CSVStruct *listFilesWithNameInDir(char *fileName, char *dir)
{
    char *aPath ;
    char **directoryContent ;
    int  i, N ;
    CSVStruct *csvOut = NULL ;

    if (isDir(dir)) {    
        directoryContent = getDirectoryContentAtPath(dir, &N) ;
        for (i = 0; i < N; i++) {
            aPath = initStringWith3Strings(dir, "/", directoryContent[i]) ;
            if (isSubStringPresentInString(directoryContent[i], fileName)) {
                csvOut = addStringValInCSVStruct(aPath, csvOut) ;
            }
            free(directoryContent[i]) ;
            free(aPath) ;
        }
        free(directoryContent) ;
    }

    return (csvOut) ;
}


CSVStruct *recursiveSearchOfFilesWithExtensionInDir(char *extension, char *dir)
{
    char *aPath, *searchedExtension, *foundExtension ;
    char **directoryContent ;
    int  i, j, N ;
    CSVStruct *csvOut = NULL, *aCSV = NULL ;

    if (isDir(dir)) {    
        searchedExtension = extension ;
        if (extension[0] == '.') {
            searchedExtension++ ;
        }
        directoryContent = getDirectoryContentAtPath(dir, &N) ;
        for (i = 0; i < N; i++) {
            aPath = initStringWith3Strings(dir, "/", directoryContent[i]) ;
            if (isDir(aPath)) {
                if((aCSV = recursiveSearchOfFilesWithExtensionInDir(extension, aPath)) != NULL) {
                    for (j = 0; j < aCSV->numberOfEntries; j++) {
                        csvOut = addStringValInCSVStruct(aCSV->stringVal[j], csvOut) ;
                    }
                    freeCSVStruct(aCSV) ;
                }
            }
            else {
                if ((foundExtension = getPointerToLastFileExtensionInPath(directoryContent[i])) != NULL) {
                    if (!strcmp(searchedExtension, foundExtension)) {
                        csvOut = addStringValInCSVStruct(aPath, csvOut) ;
                    }
                }
            }
            free(directoryContent[i]) ;
            free(aPath) ;
        }
        free(directoryContent) ;
    }

    return (csvOut) ;
}

char isDirPresentInSubDir(char *searchedDir, char *startingDir)
{
    char isOk = 0 ;
    CSVStruct *csv ;
    
    if((csv = recursiveSearchOfDirInDir(searchedDir, startingDir))) {
        isOk = 1 ;
        freeCSVStruct(csv) ;
    }
    
    return (isOk) ;
}



char isFilePresentInSubDir(char *fileName, char *dir)
{
    char isOk = 0 ;
    CSVStruct *csv ;
    
    if((csv = recursiveSearchOfFileInDir(fileName, dir))) {
        isOk = 1 ;
        freeCSVStruct(csv) ;
    }
    
    return (isOk) ;
}

/* This function returns the content of a directory. The pointer to (int)N is updated with the number of entries found */
char **getDirectoryContentAtPath(char *aPath, int *numberOfEntries)
{
	char **dirList, *expandedPath ;

    if ((expandedPath = expandEnvironmentVariablesInPath(aPath)) == NULL) {
		return((char **)NULL) ;
    }
    /* Get number of entries in directory */
	if(!(*numberOfEntries = getNumberOfDirectoryEntriesAtPath(expandedPath))) {
        free(expandedPath) ;
		return((char **)NULL) ;
    }

	/* Get entry list in directory */
    dirList = getDirectoryEntriesAtPath(expandedPath) ;
    free(expandedPath) ;

	return(dirList) ;
}

/* Returns the content of visible files within a directory. If willing to get the number of available files, use getDirectoryContentAtPath */
char **getDirectoryEntriesAtPath(char *aPath)
{
    char **entries, *path ;
    int i, numberOfEntries ;
    DIR *dirp ;
    struct dirent *entry ;

    if (!isDir(aPath)) {
        return((char **)NULL) ;
    }
    
    /* Get number of entries in directory */
    if(!(numberOfEntries = getNumberOfDirectoryEntriesAtPath(aPath))) {
        return((char **)NULL) ;
    }

    /* Point to directory path */
    path = allocStringOfLength(strlen(aPath) + 2) ;
    sprintf(path, "%s/.", aPath) ;

    /* Open directory and return directory pointer */
    if((dirp = opendir(path)) == NULL) {
        fprintf(stderr,"Cannot open directory: %s\n", aPath) ;
        return((char **)NULL ) ;
    }
    rewinddir(dirp) ;

    /* Allocate entry set */
    if((entries = (char **)malloc(numberOfEntries * sizeof (char *))) == NULL) {
        fprintf(stderr, "Failed to allocate directory list") ;
        return((char **)NULL ) ;
    }
    
    i = 0 ;
    while ((entry = readdir(dirp)) != NULL) {
        if(strncmp(entry->d_name, ".", 1)) {
            if((entries[i] = initStringWithString(entry->d_name)) == NULL){
                fprintf(stderr, "Failed to allocate entry in directory list") ;
                return((char **)NULL) ;
            }
            i++ ;
        }
    }

    free(path) ;
    (void)closedir(dirp) ;

    return(entries) ;
}

void freeDirectoryEntriesAtPath(char **entries, char *aPath)
{
    int i, numberOfEntries ;

    /* Get number of entries in directory */
    if(!(numberOfEntries = getNumberOfDirectoryEntriesAtPath(aPath)))
        return ;

    for (i = 0; i < numberOfEntries; i++) {
        free(entries[i]) ;
    }
    free(entries) ;
}

char **getAllDirectoryEntriesAtPath(char *aPath)
{
    char **entries, *path ;
    int i, numberOfEntries ;
    DIR *dirp ;
    struct dirent *entry ;

    /* Get number of entries in directory */
    if(!(numberOfEntries = getNumberOfAllDirectoryEntriesAtPath(aPath)))
        return((char **)NULL) ;

    /* Point to directory path */
    path = allocStringOfLength(strlen(aPath) + 2) ;
    sprintf(path, "%s/.", aPath) ;

    /* Open directory and return directory pointer */
    if((dirp = opendir(path)) == NULL) {
        fprintf(stderr,"Cannot open directory: %s\n", aPath) ;
        return((char **)NULL ) ;
    }

    /* Allocate entry set */
    if((entries = (char **)malloc(numberOfEntries * sizeof (char *))) == NULL) {
        fprintf(stderr, "Failed to allocate directory list") ;
        return((char **)NULL ) ;
    }
    rewinddir(dirp) ;
    i = 0 ;
    while ((entry = readdir(dirp)) != NULL) {
        if(strncmp(entry->d_name, ".", 1)) {
            if((entries[i] = initStringWithString(entry->d_name)) == NULL){
                fprintf(stderr, "Failed to allocate entry in directory list") ;
                return((char **)NULL) ;
            }
            i++ ;
        }
        else {
            if(strlen(entry->d_name) > 1 && strncmp(entry->d_name + 1, ".", 1)) {
                if((entries[i] = initStringWithString(entry->d_name)) == NULL){
                    fprintf(stderr, "Failed to allocate entry in directory list") ;
                    return((char **)NULL) ;
                }
                i++ ;
            }
        }
    }

    free(path) ;
    (void)closedir(dirp) ;

    return(entries) ;
}

void freeDirectoryEntries(char **entries, int numberOfEntries)
{
    int i ;

    for (i = 0; i < numberOfEntries; i++) {
        free(entries[i]) ;
    }
    free(entries) ;
}

/* Count number of visible files within a directory */
int getNumberOfDirectoryEntriesAtPath(char *aPath)
{
    char *path ;
    int numberOfEntries ;
    DIR *dirp ;
    struct dirent *dp ;

    path = allocStringOfLength(strlen(aPath) + 2) ;
    sprintf(path, "%s/.", aPath) ;

    numberOfEntries = 0 ;
    if((dirp = opendir(path)) == NULL) {
        return(0) ;
    }

    while ((dp = readdir(dirp)) != NULL) {
        if(strncmp(dp->d_name, ".", 1)) {
            numberOfEntries ++ ;
        }
    }

    free(path) ;
    (void)closedir(dirp) ;

    return(numberOfEntries) ;
}

int getNumberOfAllDirectoryEntriesAtPath(char *aPath)
{
    char *path ;
    int numberOfEntries ;
    DIR *dirp ;
    struct dirent *dp ;

    path = allocStringOfLength(strlen(aPath) + 2) ;
    sprintf(path, "%s/.", aPath) ;

    numberOfEntries = 0 ;
    if((dirp = opendir(path)) == NULL) {
        return(0) ;
    }

    while ((dp = readdir(dirp)) != NULL) {
        if(strncmp(dp->d_name, ".", 1)) {
            numberOfEntries ++ ;
        }
        else {
            if(strlen(dp->d_name) > 1 &&strncmp(dp->d_name + 1, ".", 1)) {
                numberOfEntries ++ ;
            }
        }
    }

    free(path) ;
    (void)closedir(dirp) ;

    return(numberOfEntries) ;
}

/* Recursively create directories to cope with path */
void makeDirRecursively(char *aPath)
{
    char *parentDir, *currentPath, *dirName ;

    if (!aPath) {
        return ;
    }
    if (isDir(aPath)) {
        return ;
    }
    
    parentDir = getDirectoryPathFromPath(aPath) ;
    while (!isDir(parentDir)) {
        makeDirRecursively(parentDir) ;
    }
    dirName = getDirectoryName(aPath) ;
    currentPath = initStringWith3Strings(parentDir, "/", dirName) ;
    free(dirName) ;
    
    if(!isDir(currentPath)) {
        if(mkdir((const char *)currentPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create image directory at path %s\n", currentPath) ;
            ase(ertex) ;
        }
    }
    free(currentPath) ;
}

void removeDirectoryAtPath(char *aPath)
{
    char **entry, *fullPath ;
    int N, i ;

    if ((aPath = expandEnvironmentVariablesInPath(aPath)) == NULL) {
		return ;
    }
    if (!isDir(aPath)) {
        free(aPath) ;
        return ;
    }

    N = getNumberOfAllDirectoryEntriesAtPath(aPath) ;
    entry = getAllDirectoryEntriesAtPath(aPath) ;
    for (i = 0; i < N; i++) {
        fullPath = initStringWith3Strings(aPath, "/", entry[i]) ;
        if (isDir(fullPath)) {
            removeDirectoryAtPath(fullPath) ;
        }
        if (isSymbolicLink(fullPath)) {
            unlink(fullPath) ;
        }       
        if (fileExistsAtPath(fullPath)) {
            unlink(fullPath) ;
        }
        free(fullPath) ;
        free(entry[i]) ;
    }
    free(entry) ;
    
    if(rmdir(aPath)) {
        printf("Failed to remove %s directory\n", aPath) ;
        sprintf(ertex, "Failed to remove %s directory\n", aPath) ;
        ase(ertex) ;
    }
    free(aPath) ;
}


void copyFileAtPathToPath(char *inputPath, char *outputPath)
{
    char *buffer, *outputDir ;
//    char *commandLine ;
    unsigned long nread, bufferSize ;
    FILE *inputFile, *outputFile ;

    if (!fileExistsAtPath(inputPath)) {
        printf("Copy file to file : Requested file does not exists at indicated path:\t---> %s\n", inputPath) ;
        return ;
    }

    if ((inputFile = fopen(inputPath, "r")) == NULL) {
        sprintf(ertex, "Failed to open input file: %s", inputPath) ;
        ase(ertex) ;
    }

    outputDir = getDirectoryPathFromPath(outputPath) ;
    if (!isDir(outputDir)) {
        makeDirRecursively(outputDir) ;
    }
    free(outputDir) ;
    
    if ((outputFile = fopen(outputPath, "w")) == NULL) {
        sprintf(ertex, "Failed to create output file: %s", outputPath) ;
        ase(ertex) ;
    }

    bufferSize = _BUFFER_SIZE_ ;
    if((buffer = malloc(bufferSize)) == NULL) {
        printf("Failed to allocate buffer for reading/writing data file") ;
        printf("Input file = %s\n Output file = %s\n", inputPath, outputPath) ;
        return ;
    }
    while ((nread = fread(buffer, 1, bufferSize, inputFile)) == bufferSize) {
        fwrite(buffer, 1, bufferSize, outputFile);
    }
    if (feof(inputFile)) {
        fwrite(buffer, 1, nread, outputFile) ;
    }

    free(buffer) ;
    fclose(inputFile) ;
    fclose(outputFile) ;
}

void copyDirAtPathToPath(char *inputDir, char *outputDir)
{
    char *aPath, *aDirName ;
    int  i ;
    size_t anIndex ;
    CSVStruct *inputDirList ;

    /* Create root directory at destination if required */
    if (!isDir(outputDir)) {
        if(mkdir((const char *)outputDir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create directory at path %s\n", outputDir) ;
            ase(ertex) ;
        }
    }
    
    /* List sub direcories and create corresponding ones at destinaton */
    anIndex = strlen(inputDir) ;
    if ((inputDirList = recursiveSearchOfDirInDir(NULL, inputDir))) {
        for (i = 0; i < inputDirList->numberOfEntries; i++) {
            aDirName = inputDirList->stringVal[i] + anIndex ; 
            aPath = initStringWith3Strings(outputDir, "/", aDirName) ;

            /* Create root directory at destination if required */
            if (!isDir(aPath)) {
                if(mkdir((const char *)aPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
                    sprintf(ertex, "Failed to create directory at path %s\n", aPath) ;
                    ase(ertex) ;
                }
            }

            free(aPath) ;
        }
        freeCSVStruct(inputDirList) ;
    }

    inputDirList = recursiveSearchOfFileInDir(NULL, inputDir) ;
    for (i = 0; i < inputDirList->numberOfEntries; i++) {
        aDirName = inputDirList->stringVal[i] + anIndex ; 
        aPath = initStringWith3Strings(outputDir, "/", aDirName) ;
        copyFileAtPathToPath(inputDirList->stringVal[i], aPath) ;

        free(aPath) ;
    }
    freeCSVStruct(inputDirList) ;

}


/* Expend environment variables in path */
/* This function allows taking into account environment variables in paths */
/* Returns NULL if not a valid path starting by / */
char *expandEnvironmentVariablesInPath(char *aPath)
{
    char *fullPath = NULL, *currentPath = NULL, *aString  ;
    char *target ;
    int i ;
    CSVStruct *csv ;

    if (!aPath) {
        return (aPath) ;
    }
    
    if((aString = initStringWithString(aPath))) {
        stripWhiteCharsAtEndOfString(aString) ;
        stripWhiteCharsAtStartOfString(aString) ;
        replaceNSubStringInString(aString, "/", ",") ;

        csv = readCSVInString(aString) ;
        removeEmptyValsInCSV(csv) ;
        free(aString) ;

        for (i = 0; i < csv->numberOfEntries; i++) {
            aString = csv->stringVal[i] ;
            if(!strncmp(csv->stringVal[i], "$", 1)) {
                removeAnyOccurrenceOfSubStringInString(aString, "(") ;
                removeAnyOccurrenceOfSubStringInString(aString, ")") ;
                removeAnyOccurrenceOfSubStringInString(aString, "{") ;
                removeAnyOccurrenceOfSubStringInString(aString, "}") ;
                if (!(aString = getenv(csv->stringVal[i] + 1))) {
                    freeCSVStruct(csv) ;
                    return (NULL) ;
                }
            }

            if(!i) {
                if (!strcmp(aString, ".")) {
                    fullPath = allocStringOfLength(1024) ;
                    fullPath = initStringWithString(getcwd(fullPath, 1024)) ;
                }
                else if (!strcmp(aString, "~")) {
                    fullPath = initStringWithString(getenv("HOME")) ;
                }
                else {
                    fullPath = initStringWith2Strings("/", aString) ;
                }
            }
            else {
                free(fullPath) ;
                fullPath = initStringWith3Strings(currentPath, "/", aString) ;
                free(currentPath) ;
            }
            currentPath = initStringWithString(fullPath) ;
        }
        freeCSVStruct(csv) ;
    }

    if (currentPath) {
        free(currentPath) ;
        currentPath = NULL ;
    }

    if (fullPath) {
        currentPath = replaceSubStringsInString(fullPath, "//", "/") ;
        free(fullPath) ;
    }
    
    if (isSymbolicLink(currentPath)) {
        target = realpath(currentPath, NULL) ;
        free(currentPath) ;
        currentPath = initStringWithString(target) ;
        free(target) ;
    }
    
    return(currentPath) ;
}


/* This function verify if a given file has an companion file with same name but with another extension */
/* Companion file can have an additional extension or a replacement extension */
/* The found path if any is returned */
char *getCorrespondingFilePathWithExtension(char *filePath, char *anExtension)
{
    char *aPath, *aString, *extension, test = 0 ;
    char *fileExtension ;

    if (filePath && anExtension) {
        if(!strncmp(anExtension, ".", 1)) {
            extension = initStringWithString(anExtension) ;
        }
        else {
            extension = initStringWith2Strings(".", anExtension) ;
        }
        
        /* If the given file path itself ends with the given extension we return 0 */
        if ((fileExtension = getPointerToLastFileExtensionInPath(filePath))) {
            if (!strcmp(fileExtension, extension + 1)) {
                free(extension) ;
                return(0) ;
            }
        }

        aPath = addExtensionAtEndOfPath(filePath, extension) ;
        if (fileExistsAtPath(aPath)) {
            test = 1 ;
        }
        else{
            free(aPath) ; 
            aString = initStringWithString(filePath) ;
            stripExtensionAtEndOfPath(aString) ;
            aPath = addExtensionAtEndOfPath(aString, extension) ;
            if (fileExistsAtPath(aPath)) {
                test = 1 ;
            }
            free(aString) ;
        }
        free(extension) ;

        if (test) {
            return (aPath) ;
        }
        free(aPath) ;
        return (NULL) ;
    }
    return (NULL) ;
} 


/* This simple function verify the existance of a file having the same name than another one but with an additional or another extension */
char correspondingFileWithExtensionExists(char *filePath, char *anExtension)
{
    char *aPath ;

    aPath = getCorrespondingFilePathWithExtension(filePath, anExtension) ;
    if(aPath) {
        free(aPath) ;
        return (1) ;
    }
    return (0) ;
}

