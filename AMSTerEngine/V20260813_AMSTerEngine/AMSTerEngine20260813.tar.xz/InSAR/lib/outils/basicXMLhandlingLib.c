
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  basicXMLhandlingRoutines.c
//  TSXDataReader
//
//  Created by Dominique Derauw on 7/01/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "basicXMLHandlingLib.h"

/* Basic XPath routine to explore xml file */
// Adapted from Libxml Tutorial
//
// John Fleck
// http://xmlsoft.org/tutorial/apd.html
//

CSVStruct *readCSVInXMLFileForXPath(xmlChar *xPath, xmlDocPtr XMLdoc)
{
    int i ;
    xmlNodeSetPtr nodeset;
    xmlXPathObjectPtr result;
    xmlChar *XMLValue ;
    CSVStruct *csv = NULL ;
    
    result = getnodeset (XMLdoc, xPath);
    if (result) {
        nodeset = result->nodesetval;
        for (i = 0; i < nodeset->nodeNr; i++) {
            XMLValue = xmlNodeListGetString(XMLdoc, nodeset->nodeTab[i]->xmlChildrenNode, 1);
            csv = addStringValInCSVStruct((char *)XMLValue, csv) ;
            xmlFree(XMLValue);
        }
        xmlXPathFreeObject (result);
    }
    else {
        return(NULL) ;
    }
    
    return (csv) ;
}

CSVStruct *readCSVInXMLFileForXPathOccurenceN(xmlChar *xPath, xmlDocPtr XMLdoc, int occurence)
{
    xmlNodeSetPtr nodeset;
    xmlXPathObjectPtr result;
    xmlChar *XMLValue ;
    CSVStruct *csv = NULL ;
    
    result = getnodeset (XMLdoc, xPath);
    if (result) {
        nodeset = result->nodesetval;
        XMLValue = xmlNodeListGetString(XMLdoc, nodeset->nodeTab[occurence]->xmlChildrenNode, 1);
        csv = addStringValInCSVStruct((char *)XMLValue, csv) ;
        xmlFree(XMLValue);
        xmlXPathFreeObject (result);
    }
    else {
        return(NULL) ;
    }
    
    return (csv) ;
}

CSVStruct *addCSVFromXMLFileForXPath(xmlChar *xPath, xmlDocPtr XMLdoc, CSVStruct *aCSV)
{
    int i ;
	xmlNodeSetPtr nodeset;
	xmlXPathObjectPtr result;
	xmlChar *XMLValue ;
    
	result = getnodeset (XMLdoc, xPath);
    if (result) {
		nodeset = result->nodesetval;
		for (i = 0; i < nodeset->nodeNr; i++) {
            XMLValue = xmlNodeListGetString(XMLdoc, nodeset->nodeTab[i]->xmlChildrenNode, 1);
            aCSV = addStringValInCSVStruct((char *)XMLValue, aCSV) ;
            xmlFree(XMLValue);
        }
		xmlXPathFreeObject (result);
    }
    else {
        return(NULL) ;
    }
    
    return (aCSV) ;
}

CSVStruct *getAttributeInXMLDocForXPath(xmlChar *xPath, xmlDocPtr XMLdoc)
{
    char **propsNames, **propsVal, *attributeName ;
    int i, j ;
	xmlNodeSetPtr nodeset;
	xmlXPathObjectPtr result;
    CSVStruct *csv = NULL ;
    
    attributeName = getXMLAttributeFromXMLPath(xPath) ;
	result = getnodeset (XMLdoc, xPath);
    if (result) {
		nodeset = result->nodesetval;
		for (i = 0; i < nodeset->nodeNr; i++) {
            if((propsNames = getPropsNameOfNode(nodeset->nodeTab[i])) != NULL) {
                if((propsVal = getPropsOfNode(nodeset->nodeTab[i])) != NULL) {
                    j = 0 ;
                    while (propsNames[j]) {
                        if (!strcmp(propsNames[j], attributeName)) {
                            csv = addStringValInCSVStruct(propsVal[j], csv) ;
                        }
                        j++ ;
                    }
                    j = 0 ;
                    while (propsVal[j]) {
                        free(propsVal[j]) ;
                        j++ ;
                    }
                    free(propsVal) ;
                }
                j = 0 ;
                while (propsNames[j]) {
                    free(propsNames[j]) ;
                    j++ ;
                }
                free(propsNames) ;
            }
        }
		xmlXPathFreeObject (result);
        if (attributeName != NULL) {
            free(attributeName) ;
        }
    }
    else {
        return(NULL) ;
    }
    
    return (csv) ;
}

char *getXMLAttributeFromXMLPath(xmlChar *xPath)
{
    char *aString ;
    int unsigned i ;
    
    i = 0 ;
    while (strncmp((char*)&xPath[i], "[@", 2)) {
        i++ ;
        if (i == strlen((char *)xPath) - 2) {
            return(NULL) ;
        }
    }
    aString = initStringWithString((char *)&xPath[i + 2]) ;
    i = 0 ;
    while (aString[i] != ' ' && aString[i] != '=' && aString[i] != ']') {
        i++ ;
    }
    aString[i] = '\0' ;

    return (aString) ;
}

int getNumberOfPropsForNode(xmlNodePtr aNode)
{
    int numberOfProps ;
    xmlAttr *currentAttribute ;

    if(aNode) {
        numberOfProps = 0 ;
        currentAttribute = aNode->properties ;
        while (currentAttribute) {
            numberOfProps ++ ;
            currentAttribute = currentAttribute->next ;
        }
    }
    else
        return(0) ;

    return (numberOfProps) ;
}

char **getPropsOfNode(xmlNodePtr aNode)
{
    char **propsSet ;
    int i, numberOfProps ;
    xmlAttr *currentAttribute ;
    
    propsSet = NULL ;
    if(aNode) {
        if((numberOfProps = getNumberOfPropsForNode(aNode))) {
            if ((propsSet = malloc((numberOfProps + 1) * sizeof(char *))) == NULL) {
                ase("Failed to allocate vector of xml node properties") ;
                exit(-1) ;
            }
            
            currentAttribute = aNode->properties ;
            for (i = 0; i < numberOfProps; i++) {
                propsSet[i] = initStringWithString((char *)currentAttribute->children->content) ;
                currentAttribute = currentAttribute->next ;
            }
            propsSet[i] = NULL ;
        }
    }
    
    return (propsSet) ;
}

char **getPropsNameOfNode(xmlNodePtr aNode)
{
    char **propsSet ;
    int i, numberOfProps ;
    xmlAttr *currentAttribute ;
    
    propsSet = NULL ;
    if(aNode) {
        if((numberOfProps = getNumberOfPropsForNode(aNode))) {
            if ((propsSet = malloc((numberOfProps + 1) * sizeof(char *))) == NULL) {
                ase("Failed to allocate vector of xml node properties") ;
                exit(-1) ;
            }
            
            currentAttribute = aNode->properties ;
            for (i = 0; i < numberOfProps; i++) {
                propsSet[i] = initStringWithString((char *)currentAttribute->name) ;
                currentAttribute = currentAttribute->next ;
            }
            propsSet[i] = NULL ;
        }
    }
    
    return (propsSet) ;
}

xmlDocPtr getdoc (char *docname)
{
	xmlDocPtr doc;
	doc = xmlParseFile(docname);
	
	if (doc == NULL ) {
		ase("Failed to parse XML file\n");
	}
    
	return doc;
}

xmlXPathObjectPtr getnodeset (xmlDocPtr doc, xmlChar *xpath)
{
	xmlXPathContextPtr context;
	xmlXPathObjectPtr result;
    
	context = xmlXPathNewContext(doc);
	if (context == NULL) {
        //		printf("Error in xmlXPathNewContext\n");
		return NULL;
	}
	result = xmlXPathEvalExpression(xpath, context);
	xmlXPathFreeContext(context);
    
	if (result == NULL) {
        //		printf("Error in xmlXPathEvalExpression\n");
		return NULL;
	}
    
	if(xmlXPathNodeSetIsEmpty(result->nodesetval)){
		xmlXPathFreeObject(result);
        //        printf("No result\n");
		return NULL;
	}
	return result;
}


/* ListChildNodes from given Level */
void listChildNodes(xmlNodePtr cur, char *tabs)
{
    char *ident ;
    
    ident = initStringWith2Strings(tabs, "\t") ;
    
    while (cur != NULL) {
        if (xmlStrcmp(cur->name, (const xmlChar *)"text")) {
            printf("%s---> Node name: %s", ident, cur->name) ;
            if (cur->ns) {
                printf("\tName space: %s", (const xmlChar *)cur->ns->prefix) ;
            }
            printf("\n") ;
            listChildNodes(cur->children, ident);
        }
        else if (cur->content) {
            if (xmlStrncmp(cur->content, (const xmlChar *)"\n", 1)) {
                printf("%s---> Node content: %s\n", ident, (char *)cur->content) ;
            }
        }
        cur = cur->next;
    }
    
    free(ident) ;
}


/* Find content */
/* This function lists in a CSV all children content corresponding to a searched node name starting from a given node */
/* If propertyName is given, corresponding property will be searched and returned */
/* In a xml path of the form <entry><title>Fourt</title> search node is "//entry/title" and Fourt will be returned */
/* In an xml path of the form <entry><link "href=fourt.com"/> search node is "//entry/link", propertyName is "href" and Fourt.com is returned */
/* In an xml path of the form <entry><name "brol=truc"/>Fourt</name> search node is "//entry/name", propertyName is "brol", property is "truc" and Fourt is returned */
CSVStruct *findContentInXMLFromNode(xmlNodePtr cur, char *searchedNodes, char *propertyName, char *property, CSVStruct *csvIn)
{
    char *searchedNode, *nextNodes = NULL, *tempString ;
    int i ;
    CSVStruct *csvNode ;
    
    if (searchedNodes == NULL) {
        return(csvIn) ;
    }
    
    tempString = initStringWithString(searchedNodes) ;
    replaceNSubStringInString(tempString, "/", ",") ;
    csvNode = readCSVInString(tempString) ;
    free(tempString) ;
    removeEmptyValsInCSV(csvNode) ;
    searchedNode = initStringWithString(csvNode->stringVal[0]) ;
    
    if (csvNode->numberOfEntries > 1) {
        nextNodes = initStringWithString(csvNode->stringVal[1]) ;
    }
    for (i = 2; i < csvNode->numberOfEntries; i++) {
        tempString = initStringWithString(nextNodes) ;
        free(nextNodes) ;
        nextNodes = initStringWith3Strings(tempString, "/", csvNode->stringVal[i]) ;
        free(tempString) ;
    }
    freeCSVStruct(csvNode) ;
    
    while (cur != NULL) {
        if (xmlStrcmp(cur->name, (const xmlChar *)"text")) {
            if (!xmlStrcmp(cur->name, (const xmlChar *)searchedNode)) {
                if (nextNodes) {
                    csvIn = findContentInXMLFromNode(cur->children, nextNodes, propertyName, property, csvIn) ;
                }
                else {
                    if (cur->children) {
                        if (cur->properties && propertyName) {
                            if (!xmlStrcmp(cur->properties->name, (const xmlChar *)propertyName)) {
                                if (property) {
                                    if (!xmlStrcmp(cur->properties->children->content, (const xmlChar *)property)) {
                                        csvIn = addStringValInCSVStruct((char *)cur->children->content, csvIn) ;
                                    }
                                }
                                else {
                                    csvIn = addStringValInCSVStruct((char *)cur->children->content, csvIn) ;
                                }
                            }
                        }
                        else {
                            if (cur->children->content) {
                                if (xmlStrncmp(cur->children->content, (const xmlChar *)"\n", 1)) {
                                    csvIn = addStringValInCSVStruct((char *)cur->children->content, csvIn) ;
                                }
                            }
                        }
                    }
                    else {
                        if (cur->properties && propertyName) {
                            if (!xmlStrcmp(cur->properties->name, (const xmlChar *)propertyName)) {
                                csvIn = addStringValInCSVStruct((char *)cur->properties->children->content, csvIn) ;
                            }
                        }
                    }    
                }
            }
            csvIn = findContentInXMLFromNode(cur->children, searchedNodes, propertyName, property, csvIn) ;
        }

        cur = cur->next;
    }

    free(searchedNode) ;
    if (nextNodes) {
        free(nextNodes) ;
    }
    
    return(csvIn) ;
}
