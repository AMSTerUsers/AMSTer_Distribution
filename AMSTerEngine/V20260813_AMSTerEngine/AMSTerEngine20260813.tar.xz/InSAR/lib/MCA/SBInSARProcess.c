
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  SBInSARCoreProcess.c
 *  MCA
 *
 *  Created by Dominique Derauw on April 29, 2009
 *  Copyright 2009 Dominique Derauw. All rights reserved.
 *
 */

#include "SBInSARProcess.h"


int SBInSAR (CSVStruct *csv) {
    char processingStep ;
    char *SBInSARParametersPath = NULL, SBInSARParametersFileFound ;
    int    currentDirectoryFdesc, i ;
    InSARParametersStruct *pInSAR ;
    bandSplitStruct *bspMaster, *bspSlave ;
    keyValue *SBInSARParams ;
    struct rlimit limit ;
    time_t startTime, endTime, stepTime ;
    
    /* Increase the system limit number of openfiles */
    if(!getrlimit(RLIMIT_NOFILE, &limit)) {
        //        printf("rlim_cur = %llu\t rlim_max = %llu\n", limit.rlim_cur, limit.rlim_max) ;
        limit.rlim_cur = MAX_NUMBER_OF_OPENED_FILES ;
        
        if(setrlimit(RLIMIT_NOFILE, &limit)) {
            printf("Failed to change the limit number of opened files") ;
        }
/*
        if(!getrlimit(RLIMIT_NOFILE, &limit)) {
            printf("rlim_cur = %llu\t rlim_max = %llu\n", limit.rlim_cur, limit.rlim_max) ;
        }
*/
    }
    
    /* Is help requested? */
    if(isArgumentPresentInCSV(csv, "help") || isArgumentPresentInCSV(csv, "-h")) {
        SBInSARHelp() ;
    }
    
    /* Look for SBInSAR parameter file */
    SBInSARParametersFileFound = 0 ;
    currentDirectoryFdesc = open(".", O_RDONLY) ;
    fchdir(currentDirectoryFdesc) ;
    
    i = 1 ;
    while (i < csv->numberOfEntries) {
        SBInSARParametersPath = initStringWithString(csv->stringVal[i]) ;
        if(fileExistsAtPath(SBInSARParametersPath)) {
            SBInSARParametersFileFound = 1 ;
            break ;
        }
        i++ ;
        free(SBInSARParametersPath) ;
    }
    if(!SBInSARParametersFileFound) {
        SBInSARParametersPath = initStringWithString("./TextFiles/SBInSARParameters.txt") ;
        if(!fileExistsAtPath(SBInSARParametersPath)){
            free(SBInSARParametersPath) ;
            SBInSARParametersPath = initStringWithString("./SBInSARParameters.txt") ;
            if(!fileExistsAtPath(SBInSARParametersPath))
                SBInSARHelp() ;
        }
        SBInSARParametersFileFound = 1 ;
    }
    time(&startTime) ;
    
    
    /* Read SBInSAR parameters */
    SBInSARParams = readParameterFileAtPath(SBInSARParametersPath) ;
    
    /* Verify the existence of required directory structure and create one if needed */
    verifySBInSARDirectoryStructureAtPath(getStringValForKeyIn(SBInSARParams, "Root")) ;
    
    /* Read associated InSAR parameters */
    pInSAR = readInSARParametersFileAtPath(getStringValForKeyIn(SBInSARParams, "InSAR parameters file")) ;
    pInSAR->SBInSARRootDirectory = getStringValForKeyIn(SBInSARParams, "Root") ;
    
    processingStep = 0 ;
    if (isArgumentPresentInCSV(csv, "-split")) processingStep = _PERFORM_BAND_SPLIT_ ;
    if (isArgumentPresentInCSV(csv, "-interf")) processingStep = _PERFORM_SBINSAR_ ;
    if (isArgumentPresentInCSV(csv, "-mca")) processingStep = _PERFORM_MCA_ ;
    
    pInSAR->flag |= (isFlagPresentInCSV(csv, "d"))? _ADDITIONAL_DEMODULATION_ : pInSAR->flag ;
    if (isFlagPresentInCSV(csv, "d")) {
        printf("Demodulation to base band requested\n") ;
        setStringValForKeyIn(SBInSARParams, "Yes", "Demodulation to baseband") ;
    }
    else {
        setStringValForKeyIn(SBInSARParams, "No", "Demodulation to baseband") ;
    }
    
    
    /* Master image sub-views splitting */
    bspMaster = masterImageSubViewsSplitting(SBInSARParams, pInSAR, processingStep) ;
    writeParameterFileAtPath(SBInSARParams, SBInSARParametersPath) ;
    free(SBInSARParametersPath) ;
    time(&endTime) ;
    duration(startTime, endTime) ;
    stepTime = endTime ;
    
    /* Slave image sub-views splitting */
    bspSlave = slaveImageSubViewsSplitting(SBInSARParams, pInSAR, processingStep) ;
    time(&endTime) ;
    duration(stepTime, endTime) ;
    stepTime = endTime ;
    
    /* Generate interferometric products */
    if(!processingStep || (processingStep == _PERFORM_SBINSAR_)) {
        SBInSARProcessingOfSubViews(bspMaster, bspSlave, pInSAR) ;
        time(&endTime) ;
        duration(stepTime, endTime) ;
        stepTime = endTime ;
    }
    
    //    writeParameterFileAtPath(p, (char *)argv[1]) ;
    
    if(!processingStep || (processingStep == _PERFORM_MCA_)) {
        multiChromaticPhaseLinearRegression(SBInSARParams, pInSAR, bspMaster) ;
        time(&endTime) ;
        duration(stepTime, endTime) ;
        stepTime = endTime ;
    }
    
    saveInSARParametersFileAtPath(pInSAR, getStringValForKeyIn(SBInSARParams, "InSAR parameters file")) ;
    freeInSARParametersStruct(pInSAR) ;
    freeKeyValueList(SBInSARParams) ;
    
    printf("\nTotal processing time:\n") ;
    time(&endTime) ;
    duration(startTime, endTime) ;
    return 0;
}


/* Sub-band splitting process */
/* Master image sub-views splitting */
bandSplitStruct *masterImageSubViewsSplitting(keyValue *SBInSARParams, InSARParametersStruct *pInSAR, char processingStep)
{
    bandSplitStruct *bsp ;
    
    printf("\nMaster image sub-band splitting characteristics:\n") ;
    bsp = allocAndInitSplitBandStruct(SBInSARParams, pInSAR->masterImage, pInSAR->masterPolarizationChannel) ;
    
    if(!processingStep || processingStep == _PERFORM_BAND_SPLIT_) {
        createSubImagesFiles(bsp) ;
        fprintf(stdout, "\nSplitting master image %s into sub-bands: ", bsp->image->path);
        fflush(stdout) ;
        subViewsSplitting(bsp) ;
        fprintf(stdout, "\n") ;
    }
    if (processingStep == _PERFORM_SBINSAR_) {
        openSubImages(bsp) ;
    }
    
    if(processingStep == _PERFORM_BAND_SPLIT_)
        closeOpenedFilesForBandSplitStruct(bsp) ;
    
    freeBandSplitStructWorkingMemory(bsp) ;
    return(bsp) ;
}

/* Slave image sub-views splitting */
bandSplitStruct *slaveImageSubViewsSplitting(keyValue *p, InSARParametersStruct *pInSAR, char processingStep)
{
    char *filePath ;
    bandSplitStruct *bsp ;
    
    if (!(pInSAR->flag & _ADDITIONAL_DEMODULATION_)) {
        filePath = initStringWith3Strings(pInSAR->interpolatedSlave->dataDirectoryPath, "/SLCData.", pInSAR->slavePolarizationChannel) ;
        setStringValForKeyIn(p, filePath, "File to split") ;
        free(filePath) ;
    }
    
    printf("\nSlave image sub-band splitting characteristics:\n") ;
    bsp = allocAndInitSplitBandStruct(p, pInSAR->slaveImage, pInSAR->slavePolarizationChannel) ;
    
    //    bsp->coreg = initBSCoregistrationStruct(pInSAR, p) ;
    
    if(!processingStep || processingStep == _PERFORM_BAND_SPLIT_) {
        createSubImagesFiles(bsp) ;
        printf("\nSplitting slave image %s into sub-bands: ", bsp->image->path);
        fflush(stdout) ;
        subViewsSplitting(bsp) ;
        fprintf(stdout, "\n") ;
    }
    if (processingStep == _PERFORM_SBINSAR_) {
        openSubImages(bsp) ;
    }
    
    if(processingStep == _PERFORM_BAND_SPLIT_)
        closeOpenedFilesForBandSplitStruct(bsp) ;
    
    freeBandSplitStructWorkingMemory(bsp) ;
    return(bsp) ;
}

void SBInSARHelp()
{
    fprintf(stdout, "Usage:\nSBInSAR /path/parameterFile [split/interf/mca] [-d]\n") ;
    fprintf(stdout, "-1- SBInSAR /path/parameterFile       \t==> Full processing\n") ;
    fprintf(stdout, "-2- SBInSAR /path/parameterFile split \t==> Sub-band splitting processing\n") ;
    fprintf(stdout, "-3- SBInSAR /path/parameterFile interf\t==> Sub-band interferometric processing\n") ;
    fprintf(stdout, "-4- SBInSAR /path/parameterFile mca   \t==> MCA processing\n") ;
    fprintf(stdout, "Options 3 and 4 requires preceding step(s) to be completed\n") ;
    fprintf(stdout, "\nIf working with non coregistered image, option -d should be used to demodulate each sub-band to its own baseband\n") ;
    exit(0) ;
}


void verifySBInSARDirectoryStructureAtPath(char *rootWorkingDirectory)
{
    char subDirectoryPath[_MAX_PATH_LENGTH_] ;
    if (!isDir(rootWorkingDirectory)) {
        if(mkdir((const char *)rootWorkingDirectory, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create directory at path %s\n", rootWorkingDirectory) ;
            ase(ertex) ;
        }
    }
    
    sprintf(subDirectoryPath, "%s/SubBands", rootWorkingDirectory) ;
    if (!isDir(subDirectoryPath)) {
        if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
            ase(ertex) ;
        }
    }
    
    sprintf(subDirectoryPath, "%s/SBInSAR", rootWorkingDirectory) ;
    if (!isDir(subDirectoryPath)) {
        if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
            ase(ertex) ;
        }
    }
    
    sprintf(subDirectoryPath, "%s/MCA", rootWorkingDirectory) ;
    if (!isDir(subDirectoryPath)) {
        if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
            ase(ertex) ;
        }
    }
}


void SBInSARProcessingOfSubViews(bandSplitStruct *bspMaster, bandSplitStruct *bspSlave, InSARParametersStruct *pInSAR)
{
    char *masterFileName, *slaveFileName, *SBInSARDir ;
	int i, Nsb ;
	
	Nsb = bspMaster->subBands->Nsb ;
	printf("\n\nGenerating InSAR products for each sub-band");
	
    /* Determine generic file name of subviews */
    masterFileName = initStringWithString("master") ;
    slaveFileName = initStringWithString("slave") ;
    
    SBInSARDir = initStringWith2Strings(pInSAR->SBInSARRootDirectory, "/SBInSAR") ;
    
	for(i = 0; i < Nsb; i++) {
		printf("\n\tSub-band N° %d: ", i + 1) ;
		pInSAR->masterImageFile = bspMaster->subImage[i]->file ;
		pInSAR->slaveImageFile = bspSlave->subImage[i]->file ;
        
        
		sprintf(accessPath, "%s/%s.%d", SBInSARDir, getFileNameFromPath((pInSAR->mod1).filePath), i) ;
		pInSAR->masterAmplitudeImageFile = openRawFileForWritingAtPath(accessPath) ;
		sprintf(accessPath, "%s/%s.%d", SBInSARDir, getFileNameFromPath((pInSAR->mod2).filePath), i) ;
		pInSAR->slaveAmplitudeImageFile = openRawFileForWritingAtPath(accessPath) ;
		sprintf(accessPath, "%s/%s.%d", SBInSARDir, getFileNameFromPath((pInSAR->interf).filePath), i) ;
		pInSAR->interferogramFile = openRawFileForWritingAtPath(accessPath) ;
		sprintf(accessPath, "%s/%s.%d", SBInSARDir, getFileNameFromPath((pInSAR->coh).filePath), i) ;
		pInSAR->coherenceFile = openRawFileForWritingAtPath(accessPath) ;
		sprintf(accessPath, "%s/%s.%d", SBInSARDir, "sigmaPhi", i) ;
		if((pInSAR->phaseStandardDeviationImageFile = openRawFileForWritingAtPath(accessPath)) == NULL)
			ase("Failed to open phase standard deviation image file\n") ;
        
		
		SBInSARCoreProcess(pInSAR) ;
        
        if (!i) {
            pInSAR->interf.lenr = pInSAR->interferogramFile->xDim ;
            pInSAR->interf.lena = pInSAR->interferogramFile->yDim ;

        }
		
		freeRawFileDescriptor(pInSAR->masterImageFile) ;
		freeRawFileDescriptor(pInSAR->slaveImageFile) ;
		freeRawFileDescriptor(pInSAR->masterAmplitudeImageFile) ;
		freeRawFileDescriptor(pInSAR->slaveAmplitudeImageFile) ;
		freeRawFileDescriptor(pInSAR->interferogramFile) ;
		freeRawFileDescriptor(pInSAR->coherenceFile) ;
		freeRawFileDescriptor(pInSAR->phaseStandardDeviationImageFile) ;
	}
    
    pInSAR->masterImageFile = pInSAR->slaveImageFile = NULL ;
    pInSAR->masterAmplitudeImageFile = pInSAR->slaveAmplitudeImageFile = NULL ;
    pInSAR->interferogramFile = pInSAR->coherenceFile = pInSAR->phaseStandardDeviationImageFile = NULL ;

    free(masterFileName) ;
    free(slaveFileName) ;
}


/* Interferogram, coherence and module images generation from a Master and Slave interferometric pair */
void SBInSARCoreProcess(InSARParametersStruct *pInSAR)
{
	/* local variables declaration */
	int i, is, j, k, l, lenr, lena, cor, coa, Ncote ;
	int Dresa, Dresr ;
	int Faz, Fra, IndiceColonne, IndiceLigneBI, IndiceLigne ;
	long Ldec ;
	float Norme, Norme2, aPhase ;
    float xFilterWidth, yFilterWidth ;
	float *Coherence ;
	float *Interfero ;
	float *InterferoF ;
	float *EcartType ;
	float *Module1 ;
	float *Module2 ;
	float **MInterfFiltre, *tMInterfFiltre, *MInterfFiltre0 ;
	float **MInterfc, *tMInterfc, *MInterfc0 ;
	float **MA1, **MA2, *tMA1, *tMA2, *MA10, *MA20 ;
	float **MMod1, **MMod2, *tMMod1, *tMMod2, *MMod10, *MMod20 ;
	double *scMod1, *scMod2, slMod1, slMod2, *scd1, *scd2, sn1, sld1, sld2 ;
	float td1 ;
	complexFloat		tempc, tempc1, *standardDeviation ;
	complexFloat		*PhaseComplexe, *PhaseComplexeF ;
	complexFloat		**MphiF, *tMphiF, *MphiF0 ;
	complexFloat		**Mphi, *tMphi, *Mphi0 ;
	complexFloat		**Mphic, *tMphic, *Mphic0 ;
	complexDouble		*scn, sln, *scET, slET, *scnI, slnI, *scnIF, slnIF ;
	struct BlocInSAR	BI ;
	progressCounter *aCounter ;
    
/*----------------------------------  INITIALISATION  -----------------------------------*/

	/* copying parameters to local variables */
	coa = pInSAR->coh.coa ;
	cor = pInSAR->coh.cor ;
	Fra = pInSAR->red.Fra ;
	Faz = pInSAR->red.Faz ;
	
	/* Verifying Ncote is odd */
	Ncote = pInSAR->coh.spi ;
	Ncote = 2 * (Ncote / 2) + 1 ;
	
	/* Calculating dimension of working area of input data */
	lenr = pInSAR->sup.Sdra - pInSAR->sup.Sgra - Ncote + 2 ;
	lena = pInSAR->sup.Shaz - pInSAR->sup.Sbaz - Ncote + 2 ;
	
	/* Calculating normalization factors for moving average and box average */
	Norme = (float)(pInSAR->red.Faz * pInSAR->red.Fra) ;
	Norme2 = (float)(pInSAR->coh.coa * pInSAR->coh.cor) ;

	/* Calculating dimension of output product */
	pInSAR->interferogramFile->xDim = pInSAR->coherenceFile->xDim = pInSAR->masterAmplitudeImageFile->xDim = pInSAR->slaveAmplitudeImageFile->xDim = Dresr = (lenr - pInSAR->coh.cor + 1)/pInSAR->red.Fra ;
	pInSAR->interferogramFile->yDim = pInSAR->coherenceFile->yDim = pInSAR->masterAmplitudeImageFile->yDim = pInSAR->slaveAmplitudeImageFile->yDim = Dresa = (lena - pInSAR->coh.coa + 1)/pInSAR->red.Faz ;
    pInSAR->interf.lenr = pInSAR->interferogramFile->xDim ;
    pInSAR->interf.lena = pInSAR->interferogramFile->yDim ;
	
	/* We will work on memory blocks of 64Mb max when considering complexFloat blocks of data (8 bytes per pixels) */
	BI.Dima = (pInSAR->masterImageFile->xDim  > pInSAR->slaveImageFile->xDim)? 8 * 1024 * 1024 / pInSAR->masterImageFile->xDim : 8 * 1024 * 1024 / pInSAR->slaveImageFile->xDim ;

    /* We limit azimuth size of blocks to 2400 lines for filtering reasons (Filtering of 5 successive blocs of 512 lignes with 2x32 pixels borders) */
    BI.Dima = (BI.Dima > 2400)? 2400 : BI.Dima ;
	BI.IndiceLigne = pInSAR->sup.Sbaz ;

	/* InSAR data blocks and filter initialization */
    pInSAR->flag |= WITH_FILTERING ;
	AllocBlocInSAR(&BI, pInSAR) ;
    initFiltering(&BI, pInSAR) ;
    xFilterWidth = pInSAR->filter.sigmar ;
    yFilterWidth = pInSAR->filter.sigmaz ;
    
	pInSAR->filter.sigmar = 1. ;
	pInSAR->filter.sigmaz = 1. ;
	initSecondFilter(&BI, pInSAR) ;
	pInSAR->filter.sigmar = xFilterWidth ;
	pInSAR->filter.sigmaz = yFilterWidth ;
	
    BI.f1 = pInSAR->masterImageFile->f ;
	BI.f2 = pInSAR->slaveImageFile->f ;

	/* ------------------- Initialisation ------------------- */
	Interfero = vectorFloat(0, Dresr-1) ;
	InterferoF = vectorFloat(0, Dresr-1) ;
	EcartType = vectorFloat(0, Dresr-1) ;
	Coherence = vectorFloat(0, Dresr-1) ;
	Module1 = vectorFloat(0, Dresr-1) ;
	Module2 = vectorFloat(0, Dresr-1) ;
	scd1 = vectorDouble(0, lenr-1) ;
	scd2 = vectorDouble(0, lenr-1) ;
	scMod1 = vectorDouble(0, lenr-1) ;
	scMod2 = vectorDouble(0, lenr-1) ;
	scn = vectorComplexDouble(0, lenr-1) ;
	scET = vectorComplexDouble(0, lenr-1) ;
	scnI = vectorComplexDouble(0, lenr-1) ;
	scnIF = vectorComplexDouble(0, lenr-1) ;
	PhaseComplexe = vectorComplexFloat(0, Dresr-1) ;
	PhaseComplexeF = vectorComplexFloat(0, Dresr-1) ;
	standardDeviation = vectorComplexFloat(0, Dresr-1) ;
	MA1 = matrixFloat(-1, coa-1, 0, lenr-1) ;
	MA10 = MA1[-1] ;
	MA2 = matrixFloat(-1, coa-1, 0, lenr-1) ;
	MA20 = MA2[-1] ;
	MMod1 = matrixFloat(-1, coa-1, 0, lenr-1) ;
	MMod10 = MMod1[-1] ;
	MMod2 = matrixFloat(-1, coa-1, 0, lenr-1) ;
	MMod20 = MMod2[-1] ;
	Mphi = matrixComplexFloat(-1, coa-1, 0, lenr-1) ;
	Mphi0 = Mphi[-1] ;
	MphiF = matrixComplexFloat(-1, coa-1, 0, lenr-1) ;
	MphiF0 = MphiF[-1] ;
	Mphic = matrixComplexFloat(-1, coa-1, 0, lenr-1) ;
	Mphic0 = Mphic[-1] ;
	MInterfFiltre  = matrixFloat(0, coa + Ncote - 2, 0, lenr+Ncote-2) ;
	MInterfFiltre0 = MInterfFiltre[0] ;
	MInterfc = matrixFloat(-1, coa-1, 0, lenr-1) ;
	MInterfc0 = MInterfc[-1] ;

	
	for(i=0; i<lenr; i++) {
		
		scnI[i].r = scnI[i].i = scnIF[i].r = scnIF[i].i = scET[i].r = scET[i].i = scn[i].r = scn[i].i = scd1[i] = scd2[i] = scMod1[i] = scMod2[i] = 0.0 ;
		Mphi[-1][i].r = Mphi[-1][i].i = 0.0 ;
		Mphic[-1][i].r = Mphic[-1][i].i = 0.0 ;
		MphiF[-1][i].r = MphiF[-1][i].i = 0.0 ;
		MInterfc[-1][i] = 0.0 ;
		MA1[-1][i] = MA2[-1][i] = 0.0 ;
		MMod1[-1][i] = MMod2[-1][i] = 0.0 ;
	}

    GenPhiWithDoubleFiltering(&BI, pInSAR) ;

	IndiceLigneBI = 0 ;
	IndiceLigne = 0 ;
	for(i=0; i<coa+Ncote-2; i++) {
		TransfertInterfFiltre(MInterfFiltre[i], &BI, IndiceLigneBI, 0) ;
		IndiceLigneBI++ ;
	}

	IndiceLigneBI = 0 ;
	for(i=0; i<coa-1; i++) {
		TransfertPhi(Mphi[i], &BI, IndiceLigneBI, Ncote/2) ;
		TransfertPhiFiltre(MphiF[i], &BI, IndiceLigneBI, Ncote/2) ;
		TransfertMod(MA1[i], MA2[i], &BI, IndiceLigneBI, Ncote/2) ;
		IndiceLigneBI++ ;
		IndiceLigne++ ;
		for(j=0; j<lenr; j++)
		{
			MMod1[i][j] = (float)sqrt(MA1[i][j]) ;
			MMod2[i][j] = (float)sqrt(MA2[i][j]) ;
			td1 = (double)aphi(MInterfFiltre, &Ncote, &i, &j) ;
			tempc1.r = (float)cos(td1) ;
			tempc1.i = (float)sin(td1) ;
			Mphic[i][j].r = Mphi[i][j].r * tempc1.r + Mphi[i][j].i * tempc1.i ;
			Mphic[i][j].i = Mphi[i][j].i * tempc1.r - Mphi[i][j].r * tempc1.i ;
			scnI[j].r += (double)Mphi[i][j].r ;
			scnI[j].i += (double)Mphi[i][j].i ;
			scnIF[j].r += (double)MphiF[i][j].r ;
			scnIF[j].i += (double)MphiF[i][j].i ;
			scn[j].r += (double)Mphic[i][j].r ;
			scn[j].i += (double)Mphic[i][j].i ;
			scd1[j] += (double)MA1[i][j] ;
			scd2[j] += (double)MA2[i][j] ;
			scMod1[j] += (double)MMod1[i][j] ;
			scMod2[j] += (double)MMod2[i][j] ;

			tempc.r = (float)Mphic[i][j].r ;
			tempc.i = (float)Mphic[i][j].i ;
			MInterfc[i][j] = phi(&tempc) ;
			scET[j].r += (double)MInterfc[i][j] ;
			scET[j].i += pow((double)MInterfc[i][j], 2.) ;
		}
	}

	/* ------------------- Calcul de la cohérence ------------------- */
	is = coa - 1 ;
	aCounter = initProgressCounterWithMinMaxValue(0, Dresa) ;
	for(i=0; i<Dresa; i++)
	{
		for(j=0; j<Dresr; j++) {
			Coherence[j] = EcartType[j] = Interfero[j] = InterferoF[j] = Module1[j] = Module2[j] = PhaseComplexe[j].r = PhaseComplexe[j].i = PhaseComplexeF[j].r = PhaseComplexeF[j].i = 0.0 ;
			standardDeviation[j].r = standardDeviation[j].i = 0.0 ;
		}

		for(l=0; l<Faz; l++) {
			if(IndiceLigneBI == BI.Dima - Ncote + 1) {
                GenPhiWithDoubleFiltering(&BI, pInSAR) ;
				IndiceLigneBI = 0 ;
			}
			TransfertInterfFiltre(MInterfFiltre[is + Ncote - 1], &BI, IndiceLigneBI, Ncote - 1) ;
			TransfertPhi(Mphi[is], &BI, IndiceLigneBI, Ncote/2) ;
			TransfertPhiFiltre(MphiF[is], &BI, IndiceLigneBI, Ncote/2) ;
			TransfertMod(MA1[is], MA2[is], &BI, IndiceLigneBI, Ncote/2) ;
			IndiceLigneBI++ ;
			IndiceLigne++ ;
			for(j=0; j<lenr; j++)
			{
				MMod1[is][j] = (float)sqrt(MA1[is][j]) ;
				MMod2[is][j] = (float)sqrt(MA2[is][j]) ;

				td1 = (double)aphi(MInterfFiltre, &Ncote, &is, &j) ;

				tempc1.r = cos(td1) ;
				tempc1.i = sin(td1) ;
				Mphic[is][j].r = Mphi[is][j].r * tempc1.r + Mphi[is][j].i * tempc1.i ;
				Mphic[is][j].i = Mphi[is][j].i * tempc1.r - Mphi[is][j].r * tempc1.i ;
				scnI[j].r += (double)Mphi[is][j].r - (double)Mphi[-1][j].r ;
				scnI[j].i += (double)Mphi[is][j].i - (double)Mphi[-1][j].i ;
				scnIF[j].r += (double)MphiF[is][j].r - (double)MphiF[-1][j].r ;
				scnIF[j].i += (double)MphiF[is][j].i - (double)MphiF[-1][j].i ;
				scn[j].r += (double)Mphic[is][j].r - (double)Mphic[-1][j].r ;
				scn[j].i += (double)Mphic[is][j].i - (double)Mphic[-1][j].i ;
				scd1[j] += (double)MA1[is][j] - (double)MA1[-1][j] ;
				scd2[j] += (double)MA2[is][j] - (double)MA2[-1][j] ;
				scMod1[j] += (double)MMod1[is][j] - (double)MMod1[-1][j] ;
				scMod2[j] += (double)MMod2[is][j] - (double)MMod2[-1][j] ;
				tempc.r = Mphic[is][j].r ;
				tempc.i = Mphic[is][j].i ;
				MInterfc[is][j] = phi(&tempc) ;
//				scET[j].r += MInterfc[is][j] - MInterfc[-1][j] ;
//				scET[j].i += pow(MInterfc[is][j], 2.) - pow(MInterfc[-1][j], 2.) ;
			}
	
			slnI.r = slnI.i = slnIF.r = slnIF.i = sln.r = sln.i = slET.r = slET.i = sld1 = sld2 = slMod1 = slMod2 = 0.0 ;
			for(j=0; j<cor-1; j++)
			{
				slnI.r += scnI[j].r ;
				slnI.i += scnI[j].i ;
				slnIF.r += scnIF[j].r ;
				slnIF.i += scnIF[j].i ;
				sln.r += scn[j].r ;
				sln.i += scn[j].i ;
				sld1 += scd1[j] ;
				sld2 += scd2[j] ;
//				slET.r += scET[j].r ;
//				slET.i += scET[j].i ;
				slMod1 += scMod1[j] ;
				slMod2 += scMod2[j] ;
			}

			for(j=0; j<Dresr; j++)
			{
				for(k=0; k<Fra; k++){
					IndiceColonne = j * Fra + k + cor-1 ;
					slnI.r += scnI[IndiceColonne].r ;
					slnI.i += scnI[IndiceColonne].i ;
					slnIF.r += scnIF[IndiceColonne].r ;
					slnIF.i += scnIF[IndiceColonne].i ;
					sln.r += scn[IndiceColonne].r ;
					sln.i += scn[IndiceColonne].i ;
					sld1 += scd1[IndiceColonne] ;
					sld2 += scd2[IndiceColonne] ;
					slMod1 += scMod1[IndiceColonne] ;
					slMod2 += scMod2[IndiceColonne] ;
					sn1 = sld1*sld2 ;
//					slET.r += scET[IndiceColonne].r ;
//					slET.i += scET[IndiceColonne].i ;
					Coherence[j] += (sn1 > Chouillat)? (float)(sqrt((sln.r * sln.r + sln.i * sln.i)/sn1)) : 0 ;
//					EcartType[j] += (float)(sqrt(fabs(slET.i /Norme2 - pow(slET.r /Norme2, 2.)))) ;
					aPhase = phaseOfComplexDouble(&sln) ;
					standardDeviation[j].r += aPhase ;
					standardDeviation[j].i += pow(aPhase, 2.) ;
					PhaseComplexe[j].r += (float)slnI.r ;
					PhaseComplexe[j].i += (float)slnI.i ;
					PhaseComplexeF[j].r += (float)slnIF.r ;
					PhaseComplexeF[j].i += (float)slnIF.i ;
					Module1[j] += (float)fabs(slMod1) ;
					Module2[j] += (float)fabs(slMod2) ;
					IndiceColonne = j * Fra + k ;
					slnI.r -= scnI[IndiceColonne].r ;
					slnI.i -= scnI[IndiceColonne].i ;
					slnIF.r -= scnIF[IndiceColonne].r ;
					slnIF.i -= scnIF[IndiceColonne].i ;
					sln.r -= scn[IndiceColonne].r ;
					sln.i -= scn[IndiceColonne].i ;
					sld1 -= scd1[IndiceColonne] ;
					sld2 -= scd2[IndiceColonne] ;
					slMod1 -= scMod1[IndiceColonne] ;
					slMod2 -= scMod2[IndiceColonne] ;
//					slET.r -= scET[IndiceColonne].r ;
//					slET.i -= scET[IndiceColonne].i ;
				}
			}
	
			tMphi = Mphi[-1] ; tMphiF = MphiF[-1] ; tMphic = Mphic[-1] ; tMInterfc = MInterfc[-1] ; tMA1 = MA1[-1] ; tMA2= MA2[-1] ;
			tMMod1 = MMod1[-1] ; tMMod2= MMod2[-1] ;
			for(j=-1; j<is; j++)
			{
				Mphi[j] = Mphi[j+1] ;
				MphiF[j] = MphiF[j+1] ;
				Mphic[j] = Mphic[j+1] ;
				MInterfc[j] = MInterfc[j+1] ;
				MA1[j] = MA1[j+1] ;
				MA2[j] = MA2[j+1] ;
				MMod1[j] = MMod1[j+1] ;
				MMod2[j] = MMod2[j+1] ;
			}
			Mphi[is] = tMphi ; MphiF[is] = tMphiF ; Mphic[is] = tMphic ; MInterfc[is] = tMInterfc ; MA1[is] = tMA1 ; MA2[is] = tMA2 ;
 			MMod1[is] = tMMod1 ; MMod2[is] = tMMod2 ;

			tMInterfFiltre = MInterfFiltre[0] ;
			for(j=0; j<coa+Ncote-2; j++) MInterfFiltre[j] = MInterfFiltre[j+1] ;
			MInterfFiltre[coa+Ncote-2] = tMInterfFiltre ;
		}

		for(j=0; j<Dresr; j++) {
			Coherence[j] /= Norme ;
//			EcartType[j] /= Norme ;
			EcartType[j] = (float)sqrt(fabs(standardDeviation[j].i / (Norme - 1) - pow(standardDeviation[j].r / (Norme - 1), 2.))) ;
			Module1[j] /= Norme * Norme2 ;
			Module2[j] /= Norme * Norme2 ;
			tempc.r = (float)(PhaseComplexe[j].r) ;
			tempc.i = (float)(PhaseComplexe[j].i) ;
			Interfero[j] = (float)phi(&tempc) ;
			tempc.r = (float)(PhaseComplexeF[j].r) ;
			tempc.i = (float)(PhaseComplexeF[j].i) ;
			InterferoF[j] = (float)phi(&tempc) ;
		}

		Ldec = (long)i*Dresr*sizeof(float) ;
		if(fseek(pInSAR->coherenceFile->f, Ldec, 0))
			ase("inCohMod.c : Failed to fseek in coherence file") ;
		fwrite((float *)Coherence, sizeof(float), Dresr, pInSAR->coherenceFile->f) ;
		
		if(fseek(pInSAR->phaseStandardDeviationImageFile->f, Ldec, 0))
			ase("inCohMod.c : Failed to fseek in sigmaPhi file") ;
		fwrite((float *)EcartType, sizeof(float), Dresr, pInSAR->phaseStandardDeviationImageFile->f) ;
		
		if(fseek(pInSAR->interferogramFile->f, Ldec, 0))
			ase("inCohMod.c : Failed to fseek in interferogram file") ;
		fwrite((float *)Interfero, sizeof(float), Dresr, pInSAR->interferogramFile->f) ;

		if(fseek(pInSAR->masterAmplitudeImageFile->f, Ldec, 0))
			ase("inCohMod.c : Failed to fseek in master module file") ;
		fwrite((float *)Module1, sizeof(float), Dresr, pInSAR->masterAmplitudeImageFile->f) ;
		
		if(fseek(pInSAR->slaveAmplitudeImageFile->f, Ldec, 0))
			ase("inCohMod.c : Failed to fseek in slave module file") ;
		fwrite((float *)Module2, sizeof(float), Dresr, pInSAR->slaveAmplitudeImageFile->f) ;
		
		updatePointProgressCounterForIndex(aCounter, i) ;
	}

	freeVectorFloat(Interfero, 0) ;
	freeVectorFloat(InterferoF, 0) ;
	freeVectorFloat(Coherence, 0) ;
	freeVectorFloat(Module1, 0) ;
	freeVectorFloat(Module2, 0) ;
	freeVectorComplexDouble(scn, 0) ;
	freeVectorComplexDouble(scnI, 0) ;
	freeVectorComplexDouble(scnIF, 0) ;
	freeVectorDouble(scd1, 0) ;
	freeVectorDouble(scd2, 0) ;
	freeVectorDouble(scMod1, 0) ;
	freeVectorDouble(scMod2, 0) ;
	free(MInterfFiltre0) ;
	free(MInterfFiltre) ;
	free(MInterfc0) ;
	free(--MInterfc) ;
	free(Mphi0) ;
	free(--Mphi) ;
	free(Mphic0) ;
	free(--Mphic) ;
	free(MA10) ;
	free(--MA1) ;
	free(MA20) ;
	free(--MA2) ;
	free(MMod10) ;
	free(--MMod1) ;
	free(MMod20) ;
	free(--MMod2) ;
	freeVectorComplexFloat(PhaseComplexe, 0) ;
	freeVectorComplexFloat(PhaseComplexeF, 0) ;
	LibBlocInSAR(&BI) ;

	return ;
}



