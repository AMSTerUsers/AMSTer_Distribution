
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  initMCA.c
 *  rangeSubViewsSplitting
 *
 *  Created by Dominique Derauw on 10/11/08.
 *  Copyright 2008 Dominique Derauw. All rights reserved.
 *
 */

#include "initMCA.h"

bandSplitStruct *allocAndInitSplitBandStruct(keyValue *SBInSARParams, CSLImage *inputImage, char *pol)
{
    char *aPath, *filePath, *subImageGenericFileName, *infoImagePath ;
    char *rootWorkingDirectory, *subBandsDirectory ;
	int Nsb, i, fftDim ;
	bandSplitStruct *bsp ;
    SLCImageInfo *newInfo ;
    
    infoImagePath = initStringWith2Strings(inputImage->infoDirectoryPath, "/SLCImageInfo.txt") ;
    newInfo = readInfoImageFromTextFile(infoImagePath) ;
    free(infoImagePath) ;

    if (!(filePath = getStringValForKeyIn(SBInSARParams, "File to split"))) {
        filePath = initStringWith3Strings(inputImage->dataDirectoryPath, "/SLCData.", pol) ;
    }
    
	/* Allocate bandSplitStruct */
	if((bsp = malloc(sizeof(bandSplitStruct))) == NULL)
		ase("initMCA.c : Failed to allocate structure for MCA parameters") ;

	/* Allocating data strucutre for input image */
	if((bsp->image = (dataStruct *)malloc(sizeof(dataStruct))) == NULL)
		ase("initMCA.c: Failed to allocate input file structure") ;
    
	/* Allocate sensorParams structure */
	if((bsp->sensor = (sensorParams *)malloc(sizeof(sensorParams))) == NULL)
		ase("initMCA.c: Failed to allocate sensorParams structure") ;
	
	/* Allocate splitting parameters */
	if((bsp->subBands = (bandSplitParams *)malloc(sizeof(bandSplitParams))) == NULL)
		ase("initMCA.c: Failed to allocate bandSplitParams structure") ;
    
    /* Allocating Fourier space required structure and data space */
    if((bsp->Fourier = (FourierWorld *)malloc(sizeof(FourierWorld))) == NULL)
        ase("initMCA.c: Failed to allocate FourierWorld structure") ;
    
	/* Init input file and data space in memory*/
	/* Reading input file path into parameter file */
    bsp->image->path = filePath ;
	
	/* Opening input file path for reading */
	if((bsp->image->file = openRawFileForReadingAtPath(bsp->image->path)) == NULL)
		ase("Failed to open input file") ;
	
    bsp->image->rangeDim   = bsp->image->file->xDim = newInfo->rangeDimension ;
    bsp->image->azimuthDim = bsp->image->file->yDim = newInfo->azimuthDimension ;

	/* Allocating and indexing memory space for subImage */
    bsp->image->dataType = sizeof(complexFloat) ;
	allocAndInitMemoryForDataStruct(bsp->image) ;
	
	/* Initializing positionning variables */
	bsp->image->firstLineIndex = bsp->image->currentLineIndex = bsp->image->currentBlocIndex = 0 ;
	
    /* Init sensorParams structure */
    bsp->sensor->f0 = newInfo->radarCarrierFrequency ;
    bsp->sensor->fvo = 0. ;
    bsp->sensor->B = newInfo->rangeBandwidth ;
    bsp->sensor->fs = newInfo->rangeSamplingFrequency ;
    bsp->sensor->rangeSampling = newInfo->rangeResolutionCell ;
    bsp->sensor->minimumSlantRange = newInfo->slantRange[0] ;

	if(bsp->sensor->fs < bsp->sensor->B) {
		bsp->sensor->fs = bsp->sensor->B ;
		printf("Range sampling frequency declared smaller than range signal bandwidth\n") ;
		printf("==> Range sampling frequency set to range signal bandwidth: %lf\n", bsp->sensor->B) ;
	}

	bsp->sensor->apodizationCoef = getDoubleValForKeyIn(SBInSARParams, "Apodization") ;
    if(plError == KEY_VALUE_NOT_FOUND || !(bsp->sensor->apodizationCoef)) {
		printf("Apodization coefficient set to default value of 0.54 (Hamming filter)") ;
        bsp->sensor->apodizationCoef = 0.54 ;
    }

    /* Init splitting parameters */
    /* Initializing flags */
    bsp->subBands->flag = 0 ;
    
    /* Read number of requested sub bands */
	bsp->subBands->Nsb = Nsb = getIntValForKeyIn(SBInSARParams, "Sub-bands number") ;
    if(plError == KEY_VALUE_NOT_FOUND) {
		ase("Missing keyword and value in parameter file:\t/* Sub-bands number */ not found") ;
    }
    
    /* Read sub bands bandwidth */
	bsp->subBands->Bp = getDoubleValForKeyIn(SBInSARParams, "Bandwidth of sub-bands") ;
    if(plError == KEY_VALUE_NOT_FOUND) {
		ase("Missing keyword and value in parameter file:\t/* Bandwidth of sub-bands */ not found") ;
    }
    
    /* Read sub bands frequency shift */
	bsp->subBands->deltaf = getDoubleValForKeyIn(SBInSARParams, "Sub-bands frequency shift") ;
	
    if (isSubStringPresentInString(getStringValForKeyIn(SBInSARParams, "Demodulation to baseband"), "Yes")) {
        bsp->subBands->flag |= _ADDITIONAL_DEMODULATION_ ;
        bsp->subBands->Nsb = 2 ;
    }
    
	verifySubBandsParameters(bsp) ;
    setDoubleValForKeyIn(SBInSARParams, bsp->subBands->deltaf, "Sub-bands frequency shift") ;
    setDoubleValForKeyIn(SBInSARParams, bsp->subBands->Bp, "Bandwidth of sub-bands") ;
    setIntValForKeyIn(SBInSARParams, bsp->subBands->Nsb, "Sub-bands number") ;
    Nsb = bsp->subBands->Nsb ;
    
    /* Allocating a vector of subImage structures */
    if((bsp->subImage = (dataStruct **)malloc(Nsb * sizeof(dataStruct *))) == NULL) {
        ase("initMCA.c: Failed to allocate subImages structure") ;
    }
    
    /* Initialize subviews */
	for(i = 0; i < Nsb; i++) {
        if((bsp->subImage[i] = (dataStruct *)malloc(sizeof(dataStruct))) == NULL) {
			ase("initMCA.c: Failed to allocate subImages structure") ;
        }
            
		/* Initializing positionning variables */	
		bsp->subImage[i]->firstLineIndex = bsp->subImage[i]->currentLineIndex = bsp->subImage[i]->currentBlocIndex = 0 ;		
		
		/* Initializing subImage dimensions */
		bsp->subImage[i]->rangeDim   = bsp->image->rangeDim ;
		bsp->subImage[i]->azimuthDim = bsp->image->azimuthDim ;
		
		/* Allocating and indexing memory space for subImage */
        bsp->subImage[i]->dataType = sizeof(complexFloat) ;
		allocAndInitMemoryForDataStruct(bsp->subImage[i]) ;
	}
    
    /* Create generic file name of subviews */
    rootWorkingDirectory = getStringValForKeyIn(SBInSARParams, "Root") ;
    subBandsDirectory = initStringWith2Strings(rootWorkingDirectory, "/SubBands") ;
    bsp->workingDirectory = initStringWithString(rootWorkingDirectory) ;
    bsp->subBandsDirectory = initStringWithString(subBandsDirectory) ;
    
    subImageGenericFileName = initStringWithString(getPointerToFileNameInPath(inputImage->imageDirectoryPath)) ;
    stripExtensionAtEndOfPath(subImageGenericFileName) ;
    
    for(i = 0; i < Nsb; i++) {
        /* Generating subImage file path */
        if(i < 10) sprintf(accessPath, "%s/%s.%-1d.csl", subBandsDirectory, subImageGenericFileName, i) ;
        else sprintf(accessPath, "%s/%s.%-2d.csl", subBandsDirectory, subImageGenericFileName, i) ;
        
        /* We verify if sub-band processing was already performed with the same parameters */
        /* Up to now, we simply verify there are no existing split images. It is up to the user to trash all if modifying spliting parameters */
        if (!isCSLImageAtPath(accessPath)) {
            copyCSLImage(inputImage->imageDirectoryPath, accessPath, _CSLIMAGE_INFO_ | _CSLIMAGE_HEADERS_) ;
        }
        
        /* Now, we update sub-band parameters */
        infoImagePath = initStringWith2Strings(accessPath, "/Info/SLCImageInfo.txt") ;
        newInfo->radarCarrierFrequency = bsp->sensor->f0 + bsp->subBands->fci[i] ;
        newInfo->wavelength = c0 / newInfo->radarCarrierFrequency ;
        newInfo->rangeBandwidth = bsp->subBands->Bp ;
        saveInfoImage(newInfo, infoImagePath) ;
        free(infoImagePath) ;
        
        if (isFilePresentInCSLImage(inputImage, "externalSlantRangeDEM")) {
            aPath = initStringWith2Strings(inputImage->dataDirectoryPath, "/externalSlantRangeDEM") ;
            filePath = initStringWith2Strings(accessPath, "/Data/externalSlantRangeDEM") ;
            copyFileAtPathToPath(aPath, filePath) ;
            free(aPath) ;
            free(filePath) ;
        }
        
        /* Saving file path into struct variable */
        bsp->subImage[i]->path = initStringWith3Strings(accessPath, "/Data/", bsp->image->file->fileName) ;
    }
   
    free(subBandsDirectory) ;
    free(subImageGenericFileName) ;
    
	/* Initializing range FFT */
    fftDim = bsp->Fourier->fftDim ;
	bsp->Fourier->rangeFFT = initFFT(fftDim, bsp->image->numberOfLinesPerBloc, ALONGX) ; /* Defines a range FFT on a matrix of size fftDim x azimuthDim */
	
	/* Allocating a memory space for working in the Fourier space */
	/* FFT routines requires a power of 2 dimention */
	/* The read data bloc will be transferd in and centered the memory space having a power of 2 as X dimension (range) */
    if ((bsp->Fourier->aNullLine = calloc(fftDim, sizeof(complexFloat))) == NULL) {
        ase("Failed to allocate memory space for aNullLine");
    }
	if((bsp->Fourier->data = (complexFloat *)malloc(bsp->image->numberOfLinesPerBloc * fftDim * sizeof(complexFloat))) == NULL)
		ase("Failed to allocate memory space for FFT");
	
	/* Indexing Fourier memory space */
	if((bsp->Fourier->indexedData = (complexFloat **)malloc(bsp->image->numberOfLinesPerBloc * sizeof(complexFloat *))) == NULL)
		ase("initMCA.c: Failed to allocate indexed data") ;
	for(i = 0; i < bsp->image->numberOfLinesPerBloc; i++) bsp->Fourier->indexedData[i] = bsp->Fourier->data + i * fftDim ;
	
	/* Allocating memory for the filtered Fourier spectrum */
	if((bsp->Fourier->filteredData = (complexFloat *)malloc(bsp->image->numberOfLinesPerBloc * fftDim * sizeof(complexFloat))) == NULL)
		ase("Failed to allocate memory space for filtered data in the Fourier space");
	
	/* Indexing Fourier memory space */
	if((bsp->Fourier->indexedFilteredData = (complexFloat **)malloc(bsp->image->numberOfLinesPerBloc * sizeof(complexFloat *))) == NULL)
		ase("initMCA.c: Failed to allocate indexed filtered data") ;
	for(i = 0; i < bsp->image->numberOfLinesPerBloc; i++) bsp->Fourier->indexedFilteredData[i] = bsp->Fourier->filteredData + i * fftDim ;
	
	/* Generating filter */
	bsp->Fourier->filter = genFilter(bsp) ;
	
    /* Generating de-Hamming filter */
    bsp->Fourier->deHammingFilter = genDeHammingFilter(bsp) ;
    
    /* Generating re-Hamming filter */
    bsp->Fourier->reHammingFilter = genReHammingFilter(bsp) ;
    
    /* Set interpolation parameters to NULL */
    bsp->coreg = NULL ;
    
    freeInfoImage(newInfo) ;
    
	return(bsp) ;
}

/* Free bandSplitStruct totally */
void freeBandSplitStruct(bandSplitStruct *bsp) 
{
	int i ;
	
	freeBandSplitStructWorkingMemory(bsp) ;
	closeOpenedFilesForBandSplitStruct(bsp) ;

	for(i = 0; i < bsp->subBands->Nsb; i++) {
		free(bsp->subImage[i]) ;
	}
	free(bsp->subImage) ;
	free(bsp->subBands) ;
	free(bsp->sensor) ;
	freeRawFileDescriptor(bsp->image->file) ;
	free(bsp->image) ;
    
    if (bsp->coreg) {
        if (bsp->coreg->isGrid) {
            freeGridMap(bsp->coreg->rangeCoregistrationGrid) ;
        }
        free(bsp->coreg) ;
    }
    free(bsp->workingDirectory) ;
    free(bsp->subBandsDirectory) ;

	free(bsp) ;
}

/* Open sub-band image files */
void createSubImagesFiles(bandSplitStruct *bsp)
{
	int i ;
    
	for(i = 0; i < bsp->subBands->Nsb; i++) {
        bsp->subImage[i]->file = createRawFileForReadingAndWritingAtPath(bsp->subImage[i]->path) ;
        
		/* Initializing subImage dimensions */
		bsp->subImage[i]->file->xDim = bsp->image->rangeDim ;
		bsp->subImage[i]->file->yDim = bsp->image->azimuthDim ;
	}
}


/* Open sub-band image files */
void openSubImages(bandSplitStruct *bsp)
{
	int i ;
    
	for(i = 0; i < bsp->subBands->Nsb; i++) {
        bsp->subImage[i]->file = openRawFileForReadingAndWritingAtPath(bsp->subImage[i]->path) ;
        
		/* Initializing subImage dimensions */
		bsp->subImage[i]->file->xDim = bsp->image->rangeDim ;
		bsp->subImage[i]->file->yDim = bsp->image->azimuthDim ;
	}
}


/* Close all open files that were open int band-split processing, i.e. sub-band image files */
void closeOpenedFilesForBandSplitStruct(bandSplitStruct *bsp)
{
	int i ;
    
	for(i = 0; i < bsp->subBands->Nsb; i++) {
		freeRawFileDescriptor(bsp->subImage[i]->file) ;
	}
}


/* Free bandSplitStruct working memory only */
/* Input file is closed but resulting files stays open */
/* Parameters are preserved */
void freeBandSplitStructWorkingMemory(bandSplitStruct *bsp) 
{
	int i ;
	
    freeHammingFilter(bsp->Fourier->deHammingFilter) ;
    freeHammingFilter(bsp->Fourier->reHammingFilter) ;
	freeSubBandFilter(bsp->Fourier->filter) ;
	free(bsp->Fourier->indexedFilteredData) ;
	free(bsp->Fourier->filteredData) ;
	free(bsp->Fourier->indexedData) ;
    free(bsp->Fourier->aNullLine) ;
    free(bsp->Fourier->data) ;
	freeFFT(bsp->Fourier->rangeFFT) ;
	free(bsp->Fourier) ;
	for(i = 0; i < bsp->subBands->Nsb; i++) {
		freeMermoryForDataStruct(bsp->subImage[i]) ;
	}
//	freeRawFileDescriptor(bsp->image->file) ;
	freeMermoryForDataStruct(bsp->image) ;
}


/* Verify adequation between number of sub-bands, sub-bands bandwith, sub-bands shifts and full bandwidth */
/* Calculate values if some are set to zero in the parameter file */
void verifySubBandsParameters(bandSplitStruct *bsp)
{
	int Nsb, i, fftDim ;
	double deltaf, dfmin ;
	
	fprintf(stdout, "Available range bandwidth: %f\n", bsp->sensor->B) ;
    fprintf(stdout, "Requested number of sub-bands: %d\n", bsp->subBands->Nsb) ;
    
	Nsb = bsp->subBands->Nsb ;
	deltaf= bsp->subBands->deltaf ;
    bsp->Fourier->fftDim = fftDim = ceil2ofIntVal(bsp->image->rangeDim) ;	/* Computes the FFT dimension as the smallest power of 2 greater or equal to rangeDim */
	dfmin = bsp->subBands->df = bsp->sensor->fs / (double)(fftDim - 1) ;		/* computes the range frequency bin width */

    if(Nsb > 3 && Nsb == 2 * (Nsb/2)) {
        fprintf(stdout, "Number of sub bands must be odd. Nsb converted to %d\n", ++Nsb) ;
    }
	
    if (!deltaf && !bsp->subBands->Bp) {
        printf("%d succesive sub-bands requested\n", Nsb) ;
        printf("Computing sub band bandwidth with a 5%% overlap\n") ;
        bsp->subBands->Bp = bsp->sensor->B / (1. + .95 * (Nsb - 1)) ;
    }
    
    if((bsp->subBands->Bp == 0.) || (bsp->sensor->B - bsp->subBands->Bp < 3 * dfmin)) {
		ase("Sub-bands bandwidth not correctly set") ;
    }
    
    /* If up and down splitting, set number of sub-bands to 2 */
    if (bsp->subBands->flag & _ADDITIONAL_DEMODULATION_ || Nsb == 2) {
        deltaf = bsp->sensor->B - bsp->subBands->Bp ;
        bsp->subBands->iDeltaf = divr((float)deltaf, (float)dfmin).q / 2 ;
    }
    else {
        if(!deltaf) {
            fprintf(stdout, "Priority given to number of requested sub-bands\n") ;
            deltaf = (bsp->sensor->B - bsp->subBands->Bp) / (Nsb - 1) ;    /* central frequencies shift calculation */
        }
        else {
            fprintf(stdout, "Requested sub-band frequency gap: %f\n", bsp->subBands->deltaf) ;
            deltaf = (double)divr((float)deltaf, (float)dfmin).q * dfmin ;    /* Conversion in unit of dfmin */
            if((Nsb - 1) * deltaf + bsp->subBands->Bp >= bsp->sensor->B) {
                fprintf(stdout, "Sub-bands parameters lead to total bandwidth exceeding available one\n Sub-band frequency shift recalculated to fit available bandwidth\n") ;
                deltaf = (bsp->sensor->B - bsp->subBands->Bp) / (Nsb - 1) ;
            }
        }
        bsp->subBands->iDeltaf = divr((float)deltaf, (float)dfmin).q ;
    }
    
    bsp->subBands->Nsb = Nsb ;
    bsp->subBands->deltaf = deltaf = bsp->subBands->iDeltaf * bsp->subBands->df ;
    

	bsp->subBands->fci = vectorDouble(0, Nsb - 1) ;				/* Allocation of the vector of central frequencies */
    if (bsp->subBands->flag & _ADDITIONAL_DEMODULATION_ || Nsb == 2) {
        bsp->subBands->fci[0] = bsp->sensor->fvo - deltaf ;
        bsp->subBands->fci[1] = bsp->subBands->fci[0] + 2 * deltaf ;
        bsp->subBands->deltaf = 2 * deltaf ;
    }
    else {
        bsp->subBands->fci[Nsb/2] = bsp->sensor->fvo ;				/* Fixing central frequency of central band to central frequency of the whole sensor bandwidth */
        for(i = Nsb/2 - 1; i >= 0; i--) bsp->subBands->fci[i] = bsp->subBands->fci[i+1] - deltaf ;
        for(i = Nsb/2 + 1; i < Nsb; i++) bsp->subBands->fci[i] = bsp->subBands->fci[i-1] + deltaf ;	/* Filling vector fci */
    }
    
    if (!(bsp->subBands->flag & _ADDITIONAL_DEMODULATION_)  && Nsb != 2) {
        fprintf(stdout, "Sub-bands characteristics:\nSub-bands bandwidth: %f\nNumber of sub-bands: %d\nSub-bands seperation: %f\n", bsp->subBands->Bp, Nsb, deltaf) ;
        fprintf(stdout, "Covered bandwidth: %f\n", bsp->subBands->Bp + (Nsb - 1) * deltaf) ;
    }
    else {
        printf("Splitting images in Low and High bands\n") ;
        if (bsp->subBands->flag & _ADDITIONAL_DEMODULATION_) {
            printf("\t---> with additional demodulation\n") ;
        }
        fprintf(stdout, "Sub-bands characteristics:\nSub-bands bandwidth: %f\nNumber of sub-bands: %d\nSub-bands seperation: %f\n", bsp->subBands->Bp, Nsb, 2 * deltaf) ;
        fprintf(stdout, "Covered bandwidth: %f\n", bsp->subBands->Bp + (Nsb - 1) * 2 * deltaf) ;        
    }
	fprintf(stdout, "\nSub-bands central frequencies:\n") ;
	for(i = 0; i < Nsb; i++) {
		if((i)  && (i == 6 * (i / 6))) printf("\n") ;
		fprintf(stdout, "%10.3e \t", bsp->subBands->fci[i]) ;
	}
	fprintf(stdout, "\n\n") ;
}

/* Filter generation */
/* rsf = range sampling frequency */
/* Bp = sub bands bandwidth */
float *genFilter(bandSplitStruct *bsp)
{
	int i, i1, i2, iBp, cosWidth, filterLength ;
	float *aFilter, dfmin ;
    
	dfmin = (float)(bsp->subBands->df) ;				/* dfmin = frequency sample */
	iBp = divr((float)bsp->subBands->Bp, dfmin).q ;		/* iBp = filter bandpass expressed in units of dfmin */
    iBp = bsp->subBands->iBp = 2 * (iBp / 2) + 1 ;
	filterLength = 	2 * bsp->Fourier->fftDim ;
	aFilter = vectorFloat(0, filterLength) ;			/* The filter is created on a vector twice longer than the total available bandwidth */
														/* deltaf being the sub-bands seperation */
	cosWidth = iBp/10 ;
	i1 = bsp->Fourier->fftDim - iBp/2 ;					/* The filter is null up to that index */
	i2 = i1 + iBp ;										/* The filter is then non-null up to that index and null afterwards */
	
    /* A first and logical possibility is to use a Hamming filter having the same characteristics than the one removed (deHamming) */
    /* But, since the Hamming filter does not goes to zero, it must be set to zero outside of the sub-band and smoothed on the borders.  */
#if defined (SPLITINGWITHAPODIZATION)
    for(i = 0; i < i1; i++) aFilter[i] = 0. ;
	for(; i < i2; i++) aFilter[i] = (float)(bsp->sensor->apodizationCoef - (1. - bsp->sensor->apodizationCoef) * cos(TWOPI * (i - i1)/(iBp - 1))) ;
	for(; i < filterLength; i++) aFilter[i] = 0. ;
#else
    /* Another possibility is to use a simple cosine smoothed filter */
	for(i = 0; i < i1; i++) aFilter[i] = 0. ;
	for(; i < i2; i++) aFilter[i] = 1. ;
	for(; i < filterLength; i++) aFilter[i] = 0. ;
#endif
    
	/* Now, we will smooth filter borders with cosines */
	/* For the moment, we fix the smothed width to a thenth of the filter bandpass Bp with a max of 8 pixels */
	cosWidth = (cosWidth > 8)? 8 : cosWidth ;
	for(i = i1 - 1; i < i1 + cosWidth; i++) aFilter[i] *= (float)((1. - cos(PI * (i - i1)/cosWidth))/ 2.) ;
	for(i = i2 - cosWidth; i < i2; i++) aFilter[i] *= (float)((1. - cos(PI * (i2 - i)/cosWidth))/ 2.) ;
    
	return(aFilter) ;
}

void freeSubBandFilter(float *aFilter)
{
	freeVectorFloat(aFilter, 0) ;
}


/* Generate de-Hamming filter */
float *genDeHammingFilter(bandSplitStruct *bsp)
{
    int i, i1, iB ;
    float *aFilter ;
    
    iB = bsp->Fourier->fftDim ;
    i1 = 0 ;
    if(bsp->sensor->fs > bsp->sensor->B) {
        iB = divr((float)bsp->sensor->B, bsp->subBands->df).q ;    /* iB = signal bandpass expressed in units of df */
        i1 = (bsp->Fourier->fftDim - iB)/2 ;                    /* Border index to center the dehamming filter on to the available bandwidth */
    }
    
    aFilter = vectorFloat(0, bsp->Fourier->fftDim) ;            /* The de-Hamming filter is created on a vector as long as the FFT range dimension */
    
    /* We calculate the inverse apodization factors */
    /* The filter must be calculated on the effective signal bandwidth */
    /* If the sampling rate leads to a larger bandwidth, the filter must be extended on both sides with a constant value */
    for(i = 0; i < i1; i++) aFilter[i] = (float)(1. / ((bsp->sensor->apodizationCoef - (1. - bsp->sensor->apodizationCoef)))) ;
    for(; i < i1 + iB; i++) aFilter[i] = (float)(1. / ((bsp->sensor->apodizationCoef - (1. - bsp->sensor->apodizationCoef) * cos(TWOPI * (i - i1)/(iB - 1))))) ;
    for(; i < bsp->Fourier->fftDim; i++) aFilter[i] = (float)(1. / ((bsp->sensor->apodizationCoef - (1. - bsp->sensor->apodizationCoef)))) ;
    
    return(aFilter) ;
}

/* Generate de-Hamming filter */
float *genReHammingFilter(bandSplitStruct *bsp)
{
    int i, i1, i2, iBp, cosWidth ;
    float *aFilter ;
    
    iBp = bsp->subBands->iBp ;                  /* iB = sub-band bandwidth expressed in units of df */
    i1 = (bsp->Fourier->fftDim - iBp)/2 ;       /* Border index to center the rehamming filter on to the available bandwidth */
    i2 = i1 + iBp ;                             /* End index of reHamming filter */
    
    aFilter = vectorFloat(0, bsp->Fourier->fftDim) ;            /* The re-Hamming filter is created on a vector as long as the FFT range dimension */
    
    /* We calculate the apodization factors */
    /* The filter must be calculated on the effective signal bandwidth */
    /* If the sampling rate leads to a larger bandwidth, the filter must be extended on both sides with a constant value */
    for(i = 0; i < i1; i++) aFilter[i] = 0. ;
    for(; i < i1 + iBp; i++) aFilter[i] = (float)((bsp->sensor->apodizationCoef - (1. - bsp->sensor->apodizationCoef) * cos(TWOPI * (i - i1)/(iBp - 1)))) ;
    for(; i < bsp->Fourier->fftDim; i++) aFilter[i] = 0. ;
    
    /* We smooth filter border with cosine */
    cosWidth = iBp/10 ;
    cosWidth = (cosWidth > 8)? 8 : cosWidth ;
    for(i = i1 - 1; i < i1 + cosWidth; i++) aFilter[i] *= (float)((1. - cos(PI * (i - i1)/cosWidth))/ 2.) ;
    for(i = i2 - cosWidth; i < i2; i++) aFilter[i] *= (float)((1. - cos(PI * (i2 - i)/cosWidth))/ 2.) ;

    return(aFilter) ;
}

void freeHammingFilter(float *aFilter)
{
	freeVectorFloat(aFilter, 0) ;
}


/* Initialize slave data coregistration struct to take coregistration into account during splitting process */
dataCoregistrationStruct *initBSCoregistrationStruct(InSARParametersStruct *pInSAR, keyValue *p)
{
    dataCoregistrationStruct *coreg ;
    
    coreg = malloc(sizeof(coreg)) ;
    
    coreg->isGrid = ((coreg->rangeCoregistrationGrid = TDXSpecificCase(pInSAR, p)) != NULL) ;
    if (!coreg->isGrid) {
        coreg->T = pInSAR->slaveAffineTransform ;
    }
    return(coreg) ;
}

