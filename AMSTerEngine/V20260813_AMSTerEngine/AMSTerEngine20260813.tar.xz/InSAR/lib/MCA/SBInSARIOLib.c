
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  ioLib.c
 *  rangeSubViewsSplitting
 *
 *  Created by Dominique Derauw on 13/11/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#include "SBInSARIOLib.h"


/* If data exceed a given amount of bytes (_DATA_STRUCT_MAX_BLOC_SIZE_), it may be read sequentially per bloc. */
/* A bloc being a window having the range length as X dimension and given number of rows computed to fit within _DATA_STRUCT_MAX_BLOC_SIZE_ bytes */
void readBlocOfData(dataStruct *input)
{
	long seekVal ; 
	size_t numberOfLinesToRead ;
	
	seekVal = 0L ;
	if(input->numberOfBlocs > 1) {
		input->firstLineIndex = (input->currentBlocIndex) * input->numberOfLinesPerBloc ;
		seekVal = input->rangeDim *sizeof(complexFloat) * input->firstLineIndex ;
	}
	
	numberOfLinesToRead = (input->currentBlocIndex < input->numberOfBlocs - 1)? input->numberOfLinesPerBloc : input->azimuthDim - input->firstLineIndex ;
	fseek(input->file->f, seekVal, SEEK_SET) ;
	if((fread(input->data, sizeof(complexFloat), input->rangeDim * numberOfLinesToRead, input->file->f)) != input->rangeDim * numberOfLinesToRead)
		ase("Failed to read input data") ;
}

void writeBlocOfData(dataStruct *output)
{
	long seekVal ;
	size_t numberOfLinesToWrite ;
	
	output->firstLineIndex = (output->currentBlocIndex) * output->numberOfLinesPerBloc ;
	seekVal = output->firstLineIndex * output->rangeDim * sizeof(complexFloat) ;
	fseek(output->file->f, seekVal, SEEK_SET) ;
	
	numberOfLinesToWrite = (output->currentBlocIndex < output->numberOfBlocs - 1)? output->numberOfLinesPerBloc : output->azimuthDim - output->firstLineIndex ;
	if((fwrite(output->data, sizeof(complexFloat), numberOfLinesToWrite * output->rangeDim, output->file->f)) !=  numberOfLinesToWrite * output->rangeDim)
		ase("Failed to write output data") ;
    
    fflush(output->file->f) ;
}

