
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  MCRegLin.c
 *  MCA
 *
 *  Created by Dominique Derauw on 15/05/09.
 *  Copyright 2009 Dominique Derauw. All rights reserved.
 *
 */

#include "MCRegLin.h"
#include "matrixPile.h"

void multiChromaticPhaseLinearRegression(keyValue *p, InSARParametersStruct *pInSAR, bandSplitStruct *bsp)
{
    char *aPath ;
	int	i, j, k, i0, jj0 ;
    int numberOfLinesPerBloc ;
	long blocSize, numberOfBlocs ;
	size_t numberOfProcessedLines, l ;
	long ldec ;
	float ***interf, ***sigmaPhi, ***coh, ***masterAmplitude, ***slaveAmplitude ;
	float **slopes, **intercepts, **R2, **sigma, **regPhase, **sigmaIntercept, **orbitalPhase ;
	float aValue, phase ;
	double xi, Sx2, Sx, SN, Sxy, Sy, Sy2, Se2, weight ;
	double xMean, xVariance, yMean, yVariance, covXY ;
	double det ;
	double a, b, dPhir0 ;
    float avgI1, avgI2, **spectralCoh ;
    complexFloat complexCoh, complexInterf ;
    coord2D P0, P1 ;
	mcaLinReg *mca ;
	div_t qr ;
    rawFileDescriptor *orbitalPhaseFile ;
	
	/* Initialization */
	mca = allocAndInitMCALinReg(p, pInSAR) ;
    aPath = initStringWith2Strings(mca->mcaPhase->directoryPath, "/orbitalPhase") ;
    orbitalPhaseFile = openRawFileForWritingAtPath(aPath) ;
    free(aPath) ;
    
    /* compute the number of line a bloc of blocSize size could contain */
	blocSize = 64 * 1024 * 1024 / mca->Nsb ;				/* We limit pile of data to 64Mb memory */
	numberOfLinesPerBloc = (int)ldiv(blocSize, mca->xDim * sizeof(float)).quot ;
	
	/* If image fit in a single bloc, consider only image number of lines */
	numberOfLinesPerBloc = (numberOfLinesPerBloc > mca->yDim)? mca->yDim : numberOfLinesPerBloc ;
	
	/* Compute number of blocs to be read, including the last one that can be incomplete */
	qr = div(mca->yDim, numberOfLinesPerBloc) ;
	numberOfBlocs = (qr.rem)? qr.quot + 1 : qr.quot ;
	
	/* Compute the corresponding bloc size */
	blocSize = mca->xDim * sizeof(float) * numberOfLinesPerBloc ;
	
	
	interf = matrixPileFloat(0, mca->Nsb - 1, 0, numberOfLinesPerBloc - 1, 0, mca->xDim - 1) ;
	masterAmplitude = matrixPileFloat(0, mca->Nsb - 1, 0, numberOfLinesPerBloc - 1, 0, mca->xDim - 1) ;
	slaveAmplitude = matrixPileFloat(0, mca->Nsb - 1, 0, numberOfLinesPerBloc - 1, 0, mca->xDim - 1) ;
	sigmaPhi = matrixPileFloat(0, mca->Nsb - 1, 0, numberOfLinesPerBloc - 1, 0, mca->xDim - 1) ;
	coh = matrixPileFloat(0, mca->Nsb - 1, 0, numberOfLinesPerBloc - 1, 0, mca->xDim - 1) ;
	slopes = matrixFloat(0, numberOfLinesPerBloc - 1,0, mca->xDim - 1) ;
	regPhase = matrixFloat(0, numberOfLinesPerBloc - 1,0, mca->xDim - 1) ;
	intercepts = matrixFloat(0, numberOfLinesPerBloc - 1,0, mca->xDim - 1) ;
	R2 = matrixFloat(0, numberOfLinesPerBloc - 1,0, mca->xDim - 1) ;
	sigma = matrixFloat(0, numberOfLinesPerBloc - 1,0, mca->xDim - 1) ;
	sigmaIntercept = matrixFloat(0, numberOfLinesPerBloc - 1,0, mca->xDim - 1) ;
    spectralCoh = matrixFloat(0, numberOfLinesPerBloc - 1,0, mca->xDim - 1) ;
    orbitalPhase = matrixFloat(0, numberOfLinesPerBloc - 1,0, mca->xDim - 1) ;
	i0 = mca->Nsb / 2 ;
	a = TWOPI * (mca->Ax - 1.) / bsp->sensor->fs ;
    dPhir0 = 2 * TWOPI * (pInSAR->ima2.z0 - pInSAR->ima1.z0)/c0 ;
	dPhir0 = (mca->isTDX)? dPhir0/2. : dPhir0 ;
    
	for(k = 0; k < numberOfBlocs; k++) {
		numberOfProcessedLines = (k < numberOfBlocs - 1)? numberOfLinesPerBloc : mca->yDim - ((numberOfBlocs - 1) * numberOfLinesPerBloc) ;
		for(i = 0; i < mca->Nsb; i++) {
			if(fread(interf[i][0], sizeof(float), mca->xDim * numberOfProcessedLines, mca->interf[i]->f) != mca->xDim * numberOfProcessedLines)
				ase("Failed to read interferogram file (MCRegLin.c)") ;
            
			if(fread(masterAmplitude[i][0], sizeof(float), mca->xDim * numberOfProcessedLines, mca->masterAmplitude[i]->f) != mca->xDim * numberOfProcessedLines)
				ase("Failed to read interferogram file (MCRegLin.c)") ;
            
			if(fread(slaveAmplitude[i][0], sizeof(float), mca->xDim * numberOfProcessedLines, mca->slaveAmplitude[i]->f) != mca->xDim * numberOfProcessedLines)
				ase("Failed to read interferogram file (MCRegLin.c)") ;
            
			if(mca->withWeighting) {
				if(fread(sigmaPhi[i][0], sizeof(float), mca->xDim * numberOfProcessedLines, mca->sigmaPhi[i]->f) != mca->xDim * numberOfProcessedLines)
					ase("Failed to read phase standard deviation file (MCRegLin.c)") ;
			}
			if(fread(coh[i][0], sizeof(float), mca->xDim * numberOfProcessedLines, mca->coh[i]->f) != mca->xDim * numberOfProcessedLines)
				ase("Failed to read coherence file (MCRegLin.c)") ;
		}
		
		for(l = 0; l < numberOfProcessedLines; l++) {
            P0.y = P1.y = (double)(mca->azimuthReductionFactor * (k * numberOfLinesPerBloc + l) + mca->iY0) ;
			
			for(j = 0; j < mca->xDim; j++) {
				/* Initialisation for this point of coordinate (j ; k) */
				Sx2 = Sx = SN = Sxy = Sy = Sy2 = Se2 = 0. ;

                /* Phase unwrapping between sub-bands */
				for(i = 1; i <= mca->Nsb / 2; i++) {
					interf[i0 + i][l][j] = interf[i0 + i - 1][l][j] + dephi(&(interf[i0 + i][l][j]), &(interf[i0 + i - 1][l][j])) ;
					interf[i0 - i][l][j] = interf[i0 - i + 1][l][j] + dephi(&(interf[i0 - i][l][j]), &(interf[i0 - i + 1][l][j])) ;
				}
				
				/* Affine relationship calculation by Chi2 or mean square */
				if(mca->withWeighting) {
					for(i = 0; i < mca->Nsb; i++) {
						xi = (double)(- bsp->subBands->Nsb / 2 + i) ;
						weight = 1. / pow(sigmaPhi[i][l][j], 2.) ;
						Sx  += weight * xi ;
						Sx2 += weight * pow(xi, 2.) ;
						SN  += weight ;
						Sxy += weight * xi * interf[i][l][j] ;
						Sy += weight * interf[i][l][j] ;
						Sy2 += weight * pow(interf[i][l][j], 2) ;
					}
				}
				else {
					for(i = 0; i < mca->Nsb; i++) {
						xi = (double)(- bsp->subBands->Nsb / 2 + i) ;
						Sx  += xi ;
						Sx2 += pow(xi, 2.) ;
						SN++ ;
						Sxy += xi * interf[i][l][j] ;
						Sy  += interf[i][l][j] ;
						Sy2 += pow(interf[i][l][j], 2) ;
					}
				}
				det = (Sx2 * SN - pow(Sx, 2.)) ;
				slopes[l][j] = (float)((SN * Sxy - Sx * Sy) / det) ;
				intercepts[l][j] = (float)((-Sx * Sxy + Sx2 * Sy) / det) ;
                
//				sigmaSlope[l][j] = SN/det ;
				sigmaIntercept[l][j] = Sx2/det ;
//				sigmaSlope[l][j] = sqrt(sigmaSlope[l][j]) / bsp->subBands->deltaf ;
				sigmaIntercept[l][j] = sqrt(sigmaIntercept[l][j] + 2. * bsp->sensor->f0 / bsp->subBands->deltaf * Sx / det + pow(bsp->sensor->f0 / bsp->subBands->deltaf, 2.) * SN / det) ;
//                sigmaIntercept[l][j] = sqrtf(SN/det) * bsp->sensor->f0 / bsp->subBands->deltaf ;
				
                /* Spectral Coherence computation */
                avgI1 = avgI2 = complexCoh.r = complexCoh.i = 0.0 ;
                for (i = 0; i < mca->Nsb; i++) {
                    xi = (double)(- bsp->subBands->Nsb / 2 + i) ;
                    avgI1 += powf(masterAmplitude[i][l][j], 2.) ;
                    avgI2 += powf(slaveAmplitude[i][l][j], 2.) ;
                    phase = interf[i][l][j] - slopes[l][j] * xi - intercepts[l][j] ;
                    complexInterf.r = masterAmplitude[i][l][j] * slaveAmplitude[i][l][j] * cosf(phase) ;
                    complexInterf.i = masterAmplitude[i][l][j] * slaveAmplitude[i][l][j] * sinf(phase) ;
                    complexCoh = aC(complexCoh, complexInterf) ;
                }
                spectralCoh[l][j] = modC(complexCoh) / sqrtf(avgI1 * avgI2) ;
//                spectralCoh[l][j] = -log(1. - spectralCoh[l][j]) ;
                
				/* Correlation coefficient calculation */
				if(mca->withWeighting) Sx2 = Sx = Sxy = 0. ;
				Sy = Sy2 = Se2 = 0. ;
				for(i = 0; i < mca->Nsb; i++) {
					xi = (double)(- bsp->subBands->Nsb / 2 + i) ;
					Sy  += interf[i][l][j] ;
					Sy2 += pow(interf[i][l][j], 2) ;
					if(mca->withWeighting) {
						Sx  += xi ;
						Sx2 += pow(xi, 2.) ;
						Sxy += xi * interf[i][l][j] ;
					}
					
					Se2 += pow(interf[i][l][j] - slopes[l][j] * xi - intercepts[l][j], 2.) ;
				}
				xMean = Sx/mca->Nsb ;
				yMean = Sy/mca->Nsb ;
				covXY = Sxy/mca->Nsb - xMean * yMean ;
				xVariance = Sx2/mca->Nsb - pow(xMean, 2.) ;
				yVariance = Sy2/mca->Nsb - pow(yMean, 2.) ;
				sigma[l][j] = sqrt(Se2 / (mca->Nsb - 2)) ;
				if(!mca->withWeighting) {
//					sigmaSlope[l][j] *= sigma[l][j] ;
					sigmaIntercept[l][j] *= sigma[l][j] ;
				}
//				R2[l][j] = 1 - Se2 / mca->Nsb / yVariance ;
				R2[l][j] = pow(covXY, 2.)/(xVariance * yVariance) ;
				slopes[l][j] /= bsp->subBands->deltaf ;
				
				/* We add the slope due to registration */
                P0.x = P1.x = (double)(mca->rangeReductionFactor * j + mca->iX0) ;
                if (mca->isMasterTransformActive) {
                    planeAffineTransformOfPoint((double *)&P0, (double *)&P1, mca->T13) ;
                }
                if (mca->rangeCoregistrationGrid) {
                    b = weightedExtrapolationOfGridForImageCoordinate(mca->rangeCoregistrationGrid, P1.x, P1.y) ;
                    regPhase[l][j] = dPhir0 + TWOPI / bsp->sensor->fs * weightedExtrapolationOfGridForImageCoordinate(mca->rangeCoregistrationGrid, P1.x, P1.y) ;
                    
                    if (!(bsp->subBands->flag & _ADDITIONAL_DEMODULATION_)) {
                        slopes[l][j] += regPhase[l][j] ;
                    }
                    regPhase[l][j] *= bsp->sensor->f0 ;
                }
                else {
                    b = TWOPI * (mca->Bx * P1.y + mca->Cx) / bsp->sensor->fs ;
                    regPhase[l][j] = dPhir0 + a * P1.x + b ;
                    if (!(bsp->subBands->flag & _ADDITIONAL_DEMODULATION_)) {
                        slopes[l][j] += regPhase[l][j] ;
                    }
                    regPhase[l][j] *= bsp->sensor->f0 ;
                }
                
                intercepts[l][j] -= slopes[l][j] * bsp->sensor->f0 ;
				
				/* We convert slopes in phase values */
				slopes[l][j] *= bsp->sensor->f0 ;
                slopes[l][j] -= orbitalPhaseAtPoint(P1.x, P1.y, pInSAR) ;
                orbitalPhase[l][j] = orbitalPhaseAtPoint(P1.x, P1.y, pInSAR) ;
			}
		}
        
        ldec = k * numberOfLinesPerBloc * mca->xDim ;
/*		for(i = 0; i < mca->Nsb; i++) {
            fseek(mca->interf[i]->f, ldec, SEEK_SET) ;
			if(fwrite(interf[i][0], sizeof(float), mca->xDim * numberOfProcessedLines, mca->interf[i]->f) != mca->xDim * numberOfProcessedLines)
				ase("Failed to write frequency-unwrapped interferogram file (MCRegLin.c)") ;
        }
 */
		fwrite(slopes[0], sizeof(float), numberOfProcessedLines * mca->mcaPhase->xDim, mca->mcaPhase->f) ;
		fwrite(regPhase[0], sizeof(float), numberOfProcessedLines * mca->registrationPhase->xDim, mca->registrationPhase->f) ;
		fwrite(intercepts[0], sizeof(float), numberOfProcessedLines * mca->intercepts->xDim, mca->intercepts->f) ;
		fwrite(R2[0], sizeof(float), numberOfProcessedLines * mca->R2->xDim, mca->R2->f) ;
		fwrite(sigma[0], sizeof(float), numberOfProcessedLines * mca->sigma->xDim, mca->sigma->f) ;
		fwrite(spectralCoh[0], sizeof(float), numberOfProcessedLines * mca->spectralCoh->xDim, mca->spectralCoh->f) ;
        fwrite(sigmaIntercept[0], sizeof(float), numberOfProcessedLines * mca->sigmaIntercept->xDim, mca->sigmaIntercept->f) ;
        fwrite(orbitalPhase[0], sizeof(float), numberOfProcessedLines * mca->sigmaIntercept->xDim, orbitalPhaseFile->f) ;
	}
    freeRawFileDescriptor(orbitalPhaseFile) ;
	
	/* Sorting results */
	jj0 = mca->sortDim - mca->xDim + 1 ;
	fseek(mca->R2->f, 0L, SEEK_SET) ;
	fseek(mca->spectralCoh->f, 0L, SEEK_SET) ;
	fseek(mca->sigma->f, 0L, SEEK_SET) ;
//	fseek(mca->sigmaSlope->f, 0L, SEEK_SET) ;
	fseek(mca->sigmaIntercept->f, 0L, SEEK_SET) ;
	for(k = 0; k < mca->yDim; k++) {
		if(mca->criterion == 0) {
			if(fread(&mca->sortedCriterion[jj0], sizeof(float), (size_t)mca->xDim, mca->R2->f) != (size_t)mca->xDim)
				ase("Failed to read R2 file (MCRegLin.c)") ;
		}
		if(mca->criterion == 1) {
			if(fread(&mca->sortedCriterion[jj0], sizeof(float), (size_t)mca->xDim, mca->spectralCoh->f) != (size_t)mca->xDim)
				ase("Failed to read prodCoh file (MCRegLin.c)") ;
		}
		if(mca->criterion == 2) {
			if(fread(&mca->sortedCriterion[jj0], sizeof(float), (size_t)mca->xDim, mca->sigma->f) != (size_t)mca->xDim)
				ase("Failed to read sigma file (MCRegLin.c)") ;
		}
/*		
		if(mca->criterion == 3) {
			if(fread(&mca->sortedCriterion[jj0], sizeof(float), mca->xDim, mca->sigmaSlope->f) != mca->xDim)
				ase("Failed to read sigmaSlope file (MCRegLin.c)") ;
		}
*/
		if(mca->criterion == 4) {
			if(fread(&mca->sortedCriterion[jj0], sizeof(float), (size_t)mca->xDim, mca->sigmaIntercept->f) != (size_t)mca->xDim)
				ase("Failed to read sigmaIntercept file (MCRegLin.c)") ;
		}
		
		for(j = 0; j < mca->xDim; j++) {
			mca->xSort[jj0 + j] = j ;
			mca->ySort[jj0 + j] = k ;
		}
		if(mca->criterion > 1) ascendingSort3(mca->sortDim, mca->sortedCriterion, mca->xSort, mca->ySort) ;
		else descendingSort3(mca->sortDim, mca->sortedCriterion, mca->xSort, mca->ySort) ;
	}
	
	/* Printing sorted results to file */
	fprintf(mca->mcaTxt->f, "   X  \t   Y  \t") ;
	for(i = 0; i < mca->Nsb; i++) {
		sprintf(aComment, "Phase %2d", i) ;
		fprintf(mca->mcaTxt->f, "%8s\t", aComment) ;
	}
	fprintf(mca->mcaTxt->f, "Abs. Phi\tIntercept\t Ncycles\t   R2   \t Sigma_B\t Sigma  \t specCoh\n") ;

	for(k = 1; k <= mca->NBest; k++) {
		fprintf(mca->mcaTxt->f, "%6d\t%6d\t", mca->xSort[k], mca->ySort[k]) ;
        ldec = (mca->ySort[k] * mca->xDim + mca->xSort[k]) * sizeof(float) ;
		for(i = 0; i < mca->Nsb; i++) {
			fseek(mca->interf[i]->f, ldec, SEEK_SET) ;
			fread(&aValue, sizeof(float), 1, mca->interf[i]->f) ;
			fprintf(mca->mcaTxt->f, "%8.3f\t", aValue) ;
		}
		fseek(mca->mcaPhase->f, ldec, SEEK_SET) ;
		fread(&aValue, sizeof(float), 1, mca->mcaPhase->f) ;
		fprintf(mca->mcaTxt->f, "%8.3e\t", aValue) ;
		fseek(mca->intercepts->f, ldec, SEEK_SET) ;
		fread(&aValue, sizeof(float), 1, mca->intercepts->f) ;
		fprintf(mca->mcaTxt->f, "%9.3f\t%12ld\t", aValue, lroundf(aValue/TWOPI)) ;
		fseek(mca->R2->f, ldec, SEEK_SET) ;
		fread(&aValue, sizeof(float), 1, mca->R2->f) ;
		fprintf(mca->mcaTxt->f, "%8.3f\t", aValue) ;
//		fseek(mca->sigmaSlope->f, ldec, SEEK_SET) ;
//		fread(&aValue, sizeof(float), 1, mca->sigmaSlope->f) ;
//		fprintf(mca->mcaTxt->f, "%8.3e\t", aValue) ;
		fseek(mca->sigmaIntercept->f, ldec, SEEK_SET) ;
		fread(&aValue, sizeof(float), 1, mca->sigmaIntercept->f) ;
		fprintf(mca->mcaTxt->f, "%8.3f\t", aValue) ;
		fseek(mca->sigma->f, ldec, SEEK_SET) ;
		fread(&aValue, sizeof(float), 1, mca->sigma->f) ;
		fprintf(mca->mcaTxt->f, "%8.3f\t", aValue) ;
		fseek(mca->spectralCoh->f, ldec, SEEK_SET) ;
		fread(&aValue, sizeof(float), 1, mca->spectralCoh->f) ;
		fprintf(mca->mcaTxt->f, "%8.3f\n", aValue) ;
	}
	
	for(i = 0; i < mca->Nsb; i++) {
		freeRawFileDescriptor(mca->interf[i]) ;
		freeRawFileDescriptor(mca->coh[i]) ;
	}
		
	freeMatrixPileFloat(interf, 0, 0, 0) ;
	freeMatrixPileFloat(masterAmplitude, 0, 0, 0) ;
	freeMatrixPileFloat(slaveAmplitude, 0, 0, 0) ;
	freeMatrixPileFloat(sigmaPhi, 0, 0, 0) ;
	freeMatrixPileFloat(coh, 0, 0, 0) ;
	freeMatrixFloat(slopes, 0, 0) ;
	freeMatrixFloat(regPhase, 0, 0) ;
	freeMatrixFloat(intercepts, 0, 0) ;
	freeMatrixFloat(R2, 0, 0) ;
	freeMatrixFloat(sigma, 0, 0) ;
	freeMatrixFloat(sigmaIntercept, 0, 0) ;
	freeRawFileDescriptor(mca->mcaPhase) ;
	freeRawFileDescriptor(mca->registrationPhase) ;
	freeRawFileDescriptor(mca->intercepts) ;
	freeRawFileDescriptor(mca->sigma) ;
	freeRawFileDescriptor(mca->sigmaIntercept) ;
	freeRawFileDescriptor(mca->R2) ;
	freeRawFileDescriptor(mca->spectralCoh) ;
    if (mca->rangeCoregistrationGrid != NULL) {
        freeGridMap(mca->rangeCoregistrationGrid) ;
    }
    free(mca) ;
}

/* Alloc and init structure bearing all required informations for performing chromatic phase linear regression through sub-bands interferograms */
mcaLinReg *allocAndInitMCALinReg(keyValue *p, InSARParametersStruct *pInSAR)
{
	char *aFilename, *aString ;
    char *aDir ;
	int i, spiralSize, coa, cor ;
	mcaLinReg *pMCA ;
	
	/* Allocate structure */
	if((pMCA = malloc(sizeof(mcaLinReg))) == NULL)
		ase("Failed to allocate mcaLinReg structure (MCRegLin.c)") ;
	pMCA->withWeighting = 0 ;
	
	/* Read number of processed sub-bands */
	pMCA->Nsb = getIntValForKeyIn(p, "Sub-bands number") ;
	if(plError == KEY_VALUE_NOT_FOUND) 
		ase("keword: \"Sub-bands number\" not found in parameter file (MCRegLin.c)") ;
	
	/* Allocating vector of rawFile descriptors for interferogram files */
	if((pMCA->interf = malloc(pMCA->Nsb * sizeof(rawFileDescriptor *))) == NULL)
		ase("Failed to allocate vector of rawFileDescriptors (MCRegLin.c)") ;
	
	/* Opening interferogram files for reading */
    aDir = initStringWith2Strings(pInSAR->SBInSARRootDirectory, "/SBInSAR") ;
    aFilename = getFileNameFromPath(pInSAR->interf.filePath) ;
    pMCA->xDim = pInSAR->interf.lenr ;
    pMCA->yDim = pInSAR->interf.lena ;
		
	for(i = 0; i < pMCA->Nsb; i++) {
		sprintf(accessPath, "%s/%s.%d", aDir, aFilename, i) ;
		if((pMCA->interf[i] = openRawFileForReadingAndWritingAtPath(accessPath)) == NULL) {
			sprintf(ertex, "Failed to open %dth interferogram file (MCRegLin.c)\n", i) ;
			ase(ertex) ;
		}
		
		pMCA->interf[i]->xDim = pMCA->xDim ;
		pMCA->interf[i]->yDim = pMCA->yDim ;
	}
    free(aFilename) ;
    
    /* Allocating vector of rawFile descriptors for amplitude files */
	if((pMCA->masterAmplitude = malloc(pMCA->Nsb * sizeof(rawFileDescriptor *))) == NULL)
		ase("Failed to allocate vector of rawFileDescriptors (MCRegLin.c)") ;
	if((pMCA->slaveAmplitude = malloc(pMCA->Nsb * sizeof(rawFileDescriptor *))) == NULL)
		ase("Failed to allocate vector of rawFileDescriptors (MCRegLin.c)") ;
    
	/* Opening amplitude files for reading */
	for(i = 0; i < pMCA->Nsb; i++) {
        aFilename = getFileNameFromPath((pInSAR->mod1).filePath) ;
        sprintf(accessPath, "%s/%s.%d", aDir, aFilename, i) ;
        pMCA->masterAmplitude[i] = openRawFileForReadingAtPath(accessPath) ;
        aFilename = getFileNameFromPath((pInSAR->mod2).filePath) ;
        sprintf(accessPath, "%s/%s.%d", aDir, aFilename, i) ;
        pMCA->slaveAmplitude[i] = openRawFileForReadingAtPath(accessPath) ;
    }
    
	/* Allocating vector of rawFile descriptors for phase standard deviation files */
	if((pMCA->sigmaPhi = malloc(pMCA->Nsb * sizeof(rawFileDescriptor *))) == NULL)
		ase("Failed to allocate vector of rawFileDescriptors (MCRegLin.c)") ;
	
	/* Opening phase standard deviation files for reading */
	if((aString = getStringValForKeyIn(p, "Weighting linear regression")) == NULL)
		ase("keword: \"Weighting linear regression\" not found  in parameter file(MCRegLin.c)") ;
	
	pMCA->withWeighting = (!strncmp(aString, "YES", 3))? 1 : 0 ;
	
	for(i = 0; i < pMCA->Nsb; i++) {
		sprintf(accessPath, "%s/sigmaPhi.%d", aDir, i) ;
		if((pMCA->sigmaPhi[i] = openRawFileForReadingAtPath(accessPath)) == NULL) {
			sprintf(ertex, "Failed to open %dth phase standard deviation file (MCRegLin.c)\n", i) ;
			ase(ertex) ;
		}			
		
		pMCA->sigmaPhi[i]->xDim = pMCA->xDim ;
		pMCA->sigmaPhi[i]->yDim = pMCA->yDim ;
	}
	
	
	/* Allocating vector of rawFile descriptors for coherence files */
	if((pMCA->coh = malloc(pMCA->Nsb * sizeof(rawFileDescriptor *))) == NULL)
		ase("Failed to allocate vector of rawFileDescriptors (MCRegLin.c)") ;
	
	/* Opening coherence files for reading */ 
    aFilename = getFileNameFromPath(pInSAR->coh.filePath) ;
	
	for(i = 0; i < pMCA->Nsb; i++) {
		sprintf(accessPath, "%s/%s.%d", aDir, aFilename, i) ;
		if((pMCA->coh[i] = openRawFileForReadingAtPath(accessPath)) == NULL) {
			sprintf(ertex, "Failed to open %dth coherence file (MCRegLin.c)\n", i) ;
			ase(ertex) ;
		}
		
		pMCA->coh[i]->xDim = pMCA->xDim ;
		pMCA->coh[i]->yDim = pMCA->yDim ;
	}
	

	/* Opening results files for writing */
    free(aDir) ;
    aDir = initStringWith2Strings(pInSAR->SBInSARRootDirectory, "/MCA") ;
	
	if((aFilename = getStringValForKeyIn(p, "MCA phase data filename")) == NULL)
		ase("keword: \"Slopes data filename\" not found  in parameter file (MCRegLin.c)") ;
	sprintf(accessPath, "%s/%s", aDir, aFilename) ;
    if ((pMCA->mcaPhase = openRawFileForReadingAndWritingAtPath(accessPath))== NULL) {
        ase("Failed to create MCA phase output file") ;
    }
	pMCA->mcaPhase->xDim = pMCA->interf[0]->xDim ;
	pMCA->mcaPhase->yDim = pMCA->interf[0]->yDim ;
	
	if((aFilename = getStringValForKeyIn(p, "Registration phase data filename")) == NULL)
		ase("keword: \"Registration data filename\" not found  in parameter file (MCRegLin.c)") ;
	sprintf(accessPath, "%s/%s", aDir, aFilename) ;
	pMCA->registrationPhase = openRawFileForReadingAndWritingAtPath(accessPath) ;
	pMCA->registrationPhase->xDim = pMCA->interf[0]->xDim ;
	pMCA->registrationPhase->yDim = pMCA->interf[0]->yDim ;
	
	if((aFilename = getStringValForKeyIn(p, "Intercepts data filename")) == NULL)
		ase("keword: \"Intercepts data filename\" not found  in parameter file (MCRegLin.c)") ;
	sprintf(accessPath, "%s/%s", aDir, aFilename) ;
	pMCA->intercepts = openRawFileForReadingAndWritingAtPath(accessPath) ;
	pMCA->intercepts->xDim = pMCA->interf[0]->xDim ;
	pMCA->intercepts->yDim = pMCA->interf[0]->yDim ;
	
	if((aFilename = getStringValForKeyIn(p, "R2")) == NULL)
		ase("keword: \"R2\" not found  in parameter file (MCRegLin.c)") ;
	sprintf(accessPath, "%s/%s", aDir, aFilename) ;
	pMCA->R2 = openRawFileForReadingAndWritingAtPath(accessPath) ;
	pMCA->R2->xDim = pMCA->interf[0]->xDim ;
	pMCA->R2->yDim = pMCA->interf[0]->yDim ;
	
	if((aFilename = getStringValForKeyIn(p, "Sigma")) == NULL)
		ase("keword: \"Sigma\" not found  in parameter file (MCRegLin.c)") ;
	sprintf(accessPath, "%s/%s", aDir, aFilename) ;
	pMCA->sigma = openRawFileForReadingAndWritingAtPath(accessPath) ;
	pMCA->sigma->xDim = pMCA->interf[0]->xDim ;
	pMCA->sigma->yDim = pMCA->interf[0]->yDim ;
/*	
	if((aFilename = getStringValForKeyIn(p, "Sigma")) == NULL)
		ase("keword: \"Sigma\" not found  in parameter file (MCRegLin.c)") ;
	sprintf(acces, "%s/%s.slope", aPath, aFilename) ;
	pMCA->sigmaSlope = openRawFileForReadingAndWritingAtPath(acces) ;
	pMCA->sigmaSlope->xDim = pMCA->interf[0]->xDim ;
	pMCA->sigmaSlope->yDim = pMCA->interf[0]->yDim ;
*/	
	if((aFilename = getStringValForKeyIn(p, "Sigma")) == NULL)
		ase("keword: \"Sigma\" not found  in parameter file (MCRegLin.c)") ;
	sprintf(accessPath, "%s/%s.intercept", aDir, aFilename) ;
	pMCA->sigmaIntercept = openRawFileForReadingAndWritingAtPath(accessPath) ;
	pMCA->sigmaIntercept->xDim = pMCA->interf[0]->xDim ;
	pMCA->sigmaIntercept->yDim = pMCA->interf[0]->yDim ;
	
	if((aFilename = getStringValForKeyIn(p, "Spectral coherence data file name")) == NULL)
		ase("keword: \"Spectral coherence data file name\" not found  in parameter file (MCRegLin.c)") ;
	sprintf(accessPath, "%s/%s", aDir, aFilename) ;
	pMCA->spectralCoh = openRawFileForReadingAndWritingAtPath(accessPath) ;
	pMCA->spectralCoh->xDim = pMCA->interf[0]->xDim ;
	pMCA->spectralCoh->yDim = pMCA->interf[0]->yDim ;
	
	/* Allocating required ressources, for sorting and extracting best points */
	if((aFilename = getStringValForKeyIn(p, "Text file")) == NULL)
		ase("keword: \"Text file gathering results for best points\" not found  in parameter file (MCRegLin.c)") ;
	sprintf(accessPath, "%s/%s", aDir, aFilename) ;
	pMCA->mcaTxt = openRawFileForWritingAtPath(accessPath) ;

	pMCA->NBest = getIntValForKeyIn(p, "Number of bests points extracted") ;
	if((aString = getStringValForKeyIn(p, "Used criterion")) == NULL)
		ase("keword: \"Used criterion\" not found  in parameter file(MCRegLin.c)") ;
	pMCA->criterion = 0 ;
	if(!strncmp(aString, "R2", 2)) pMCA->criterion = 0 ;
	if(!strncmp(aString, "spectralCoh", 7)) pMCA->criterion = 1 ;
	if(!strncmp(aString, "sigma", 5)) pMCA->criterion = 2 ;
	if(!strncmp(aString, "sigmaSlope", 10)) pMCA->criterion = 3 ;
	if(!strncmp(aString, "sigmaIntercept", 14)) pMCA->criterion = 4 ;

	pMCA->sortDim = (div(pMCA->NBest, pMCA->interf[0]->xDim).quot + 2) * pMCA->interf[0]->xDim ;
	pMCA->sortedCriterion = vectorFloat(1, pMCA->sortDim + 1) ;
	pMCA->xSort = vectorInt(1, pMCA->sortDim + 1) ;
	pMCA->ySort = vectorInt(1, pMCA->sortDim + 1) ;
	if(pMCA->criterion > 1)
		for(i = 1; i < pMCA->sortDim + 1; i++) pMCA->sortedCriterion[i] = 1.0e+8 ;
	else
		for(i = 1; i < pMCA->sortDim - pMCA->xDim + 1; i++) pMCA->sortedCriterion[i] = 0. ;

	pMCA->Ax = pInSAR->slaveAffineTransform[0][0] ;
	pMCA->Bx = pInSAR->slaveAffineTransform[0][1] ;
	pMCA->Cx = pInSAR->slaveAffineTransform[0][2] ;
    
    pMCA->isMasterTransformActive = pInSAR->masterInterpolation ;
    pMCA->T13 = pInSAR->masterAffineTransform ;
    
    pMCA->rangeReductionFactor = pInSAR->red.Fra ;
    pMCA->azimuthReductionFactor = pInSAR->red.Faz ;
    cor = pInSAR->coh.cor ;
    coa = pInSAR->coh.coa ;
	spiralSize = pInSAR->coh.spi ;

    pMCA->iX0 = pInSAR->sup.Sgra + pMCA->rangeReductionFactor * (cor/2 + spiralSize/2) ;
    pMCA->iY0 = pInSAR->sup.Sbaz + pMCA->azimuthReductionFactor * (coa/2 + spiralSize/2) ;
    
    pMCA->iX0 = pInSAR->sup.Sgra  ;
    pMCA->iY0 = pInSAR->sup.Sbaz ;
    
    pMCA->rangeCoregistrationGrid = TDXSpecificCase(pInSAR, p) ;
    if (pMCA->rangeCoregistrationGrid != NULL) {
        pMCA->isTDX = 1 ;
    }
    
	return(pMCA) ;
}
