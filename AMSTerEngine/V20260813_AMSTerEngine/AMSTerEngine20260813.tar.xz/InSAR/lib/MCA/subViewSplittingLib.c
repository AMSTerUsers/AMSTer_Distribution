
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  subViewSplittingLib.c
 *  rangeSubViewsSplitting
 *
 *  Created by Dominique Derauw on 14/11/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#include "subViewSplittingLib.h"

void subViewsSplitting(bandSplitStruct *bsp)
{
	int i, j, k, l, dj, kj, dk ;
	float dfmin ;
	progressCounter *theCounter ;

	/* Initialize a counter to display processing status */
	theCounter = initProgressCounterWithMinMaxValue(bsp->image->firstLineIndex, bsp->image->firstLineIndex + bsp->image->azimuthDim - 1) ;
	
	/* Compute frequency sampling */
	dfmin = (float)(bsp->subBands->df) ;
	
	bsp->image->currentBlocIndex = 0 ;
	for(l = 0; l < bsp->image->numberOfBlocs; l++) {
		/* Read bloc of data */
		readBlocOfData(bsp->image) ;
		transferBlocToFourierDataSpace(bsp) ;

		fftX(FORWARD_FFT, bsp->Fourier->data, bsp->Fourier->rangeFFT) ;
        if (bsp->sensor->apodizationCoef < 1.) {
            deHamming(bsp->Fourier) ;
        }

        
		/* Now, for each subview ... */
		for(k = 0; k < bsp->subBands->Nsb; k++) {
			if(k) bsp->image->currentLineIndex -= bsp->image->numberOfLinesPerBloc ; /* image->currentLineIndex is re-initialized to avoid being icremented k times */
			
			/* Compute the filter shift to center it on the sub-band central frequency */
            kj = (bsp->subBands->Nsb == 2)? 2 * k - 1 : (k - bsp->subBands->Nsb / 2) ;     /* kj is the index of the sub-band in the interval [-Nsb/2 ; Nsb/2] */
            dk = kj * bsp->subBands->iDeltaf ;      /* dk is the index of the sub-band central frequency */
			dk = (bsp->subBands->Nsb == 2)? dk / 2 : dk ;
            dj = bsp->Fourier->rangeFFT->dimX / 2 - dk ;    /* dj is the shift between the sub-band central frequency and the baseband */

			/* Then for each line of the bloc ... */
			for(i = 0 ; i <  bsp->image->numberOfLinesPerBloc; i++) {
				/* The line is filtered */ 
                memcpy(bsp->Fourier->indexedFilteredData[i], bsp->Fourier->aNullLine, bsp->Fourier->rangeFFT->dimX * sizeof(complexFloat)) ;
                for(j = 0; j < bsp->Fourier->rangeFFT->dimX; j++) {
                    if (!(bsp->subBands->flag & _ADDITIONAL_DEMODULATION_)) {
                        bsp->Fourier->indexedFilteredData[i][j] = mRC(bsp->Fourier->indexedData[i][j], bsp->Fourier->filter[j + dj]) ;
                    }
                    else {
                        /* If additional demod is requested, additional shift is applied to center filtered spectrum on baseband */
                        if (j + dk >= 0) {
                            bsp->Fourier->indexedFilteredData[i][j] = mRC(bsp->Fourier->indexedData[i][j + dk], bsp->Fourier->filter[j + dk + dj]) ;
                        }
                    }
                }
				
				/* Then increment line indexes (might be usefull in the future) */
				bsp->image->currentLineIndex ++ ;
				bsp->subImage[k]->currentLineIndex ++ ;
                
                if (!k) updatePointProgressCounterForIndex(theCounter, bsp->subImage[0]->currentLineIndex) ;
			}
            
            /* Since all lines of the bloc have been processed for the k-th subview, save the filtered bloc */
			fftX(INVERSE_FFT, bsp->Fourier->filteredData, bsp->Fourier->rangeFFT) ;
			
			/* Now, we transfer the filtered data back into the subImage data block, taking sub-band central frequency shift into account */
			/* If not willing to take sub-band central frequency shift into account use this : */
            if (!(bsp->subBands->flag & _ADDITIONAL_DEMODULATION_)) {
                dj = divr((float)(bsp->sensor->fs/2.), dfmin).q ;
            }
            
			transferFourierFilteredDataSpaceToBloc(bsp, k, dj) ;
			writeBlocOfData(bsp->subImage[k]) ;
			bsp->subImage[k]->currentBlocIndex++ ;
		}
        
		/* Increment bloc index to read next one */
		bsp->image->currentBlocIndex++ ;
	}
	updatePointProgressCounterForIndex(theCounter, bsp->subImage[0]->currentLineIndex) ;
	fprintf(stdout, "\n") ;
	
	freeProgressCounter(theCounter) ;
}


void transferBlocToFourierDataSpace(bandSplitStruct *bsp)
{
	int i, j, centringShift ;
	float c ;
	double aPhase, aConstant ;
    complexFloat aComplex, *zeroLine ; ;
	dataStruct *anImage ;
	FourierWorld *Fourier ;
	
	anImage = bsp->image ;
	Fourier = bsp->Fourier ;
	centringShift = (Fourier->rangeFFT->dimX - anImage->rangeDim)/2 ;
    zeroLine = vectorComplexFloat(0, Fourier->rangeFFT->dimX) ;
    
	for(i = 0; i < anImage->numberOfLinesPerBloc; i++) {
        memcpy(Fourier->indexedData[i], zeroLine, Fourier->rangeFFT->dimX * sizeof(complexFloat)) ;
		memcpy(&Fourier->indexedData[i][centringShift], anImage->indexedData[i], anImage->rangeDim * sizeof(complexFloat)) ;
		
        /* Either, we circularize image on border to avoid aliasing */
/*       for(j = 0; j < centringShift; j++) Fourier->indexedData[i][j] = Fourier->indexedData[i][anImage->rangeDim + j] ;
         i0 = centringShift + anImage->rangeDim ;
         for(j = 0; j < centringShift; j++) Fourier->indexedData[i][i0 + j] = Fourier->indexedData[i][centringShift + j] ;
*/
        /* Or, we mirror the data on borders to avoid aliasing */
/*        for(j = 1; j <= centringShift; j++) Fourier->indexedData[i][centringShift - j] = Fourier->indexedData[i][centringShift + j] ;
        i0 = centringShift + anImage->rangeDim - 1 ;
        for(j = 1; j <= centringShift; j++) Fourier->indexedData[i][i0 + j] = Fourier->indexedData[i][i0 - j] ;
*/
		/* We multiply the data by a phase ramp equal to iPI * j in order to center the spectrum in the Fourier space */
		/* Phase ramp should be adapted to allow taking into account non-demodulated data */
		/* In that case, the phase ramp should be : iPI ( 1 - 2 * fvo/fs) * j */
		
		if(bsp->sensor->fvo) {
			aConstant = PI * (1. - 2 * bsp->sensor->fvo / bsp->sensor->fs) ;
			for(j = 0; j < Fourier->rangeFFT->dimX; j++) {
				aPhase = j * aConstant ;
				aComplex.r = cos(aPhase) ;
				aComplex.i = sin(aPhase) ;
				Fourier->indexedData[i][j] = mC(Fourier->indexedData[i][j], aComplex) ;
			}
			
		} else {
			c = -1. ;
			for(j = 0; j < Fourier->rangeFFT->dimX; j++) {
				c *= -1. ;
				Fourier->indexedData[i][j] = mRC(Fourier->indexedData[i][j], c) ;
			}
		}
	}
    
    freeVectorComplexFloat(zeroLine, 0) ;
}


void transferFourierDataSpaceToBloc(FourierWorld *Fourier, dataStruct *anImage)
{
	int i, j, centringShift ;
	float c ;
	
	centringShift = (Fourier->rangeFFT->dimX - anImage->rangeDim)/2 ;
	for(i = 0; i < anImage->numberOfLinesPerBloc; i++) {
/* Phase ramp should be adapted to correct for the applied one in the transfer to Fourier data space */
/* but also to correct for the filtering that displaced the central frequency of the new image */
		c = -1. ;
		for(j = 0; j < Fourier->rangeFFT->dimX; j++) {
			c *= -1. ;
			Fourier->indexedData[i][j] = mRC(Fourier->indexedData[i][j], c) ;
		}
		memcpy(anImage->indexedData[i], &Fourier->indexedData[i][centringShift], anImage->rangeDim * sizeof(complexFloat)) ;
	}
}


void transferFourierFilteredDataSpaceToBloc(bandSplitStruct *bsp, int k, int dj)
{
	int i, j, centringShift ;
	float phaseShift, dphi ;
    complexFloat *demodulationPhase = NULL ;
	complexFloat aComplex, **indexedData ;
	FourierWorld *Fourier ;
	dataStruct *anImage ;
    
    Fourier = bsp->Fourier ;
    anImage = bsp->subImage[k] ;
    
    centringShift = (Fourier->rangeFFT->dimX - anImage->rangeDim)/2 ;
    

//	dphi = -TWOPI * (float)dj/Fourier->rangeFFT->dimX ;
    dphi = -PI ;
    
    indexedData = (complexFloat **)anImage->indexedData ;
	for(i = 0; i < anImage->numberOfLinesPerBloc; i++) {
		for(j = 0; j < Fourier->rangeFFT->dimX; j++) {
			phaseShift = j * dphi ;
			aComplex.r = (float)cosf(phaseShift) ;
			aComplex.i = (float)sinf(phaseShift) ;
			Fourier->indexedFilteredData[i][j] = mC(Fourier->indexedFilteredData[i][j], aComplex) ;
		}
		memcpy(anImage->indexedData[i], &Fourier->indexedFilteredData[i][centringShift], anImage->rangeDim * sizeof(complexFloat)) ;
        
	}
    
    freeVectorComplexFloat(demodulationPhase, 0) ;
}

/*
void transferFourierFilteredDataSpaceToBloc(FourierWorld *Fourier, dataStruct *anImage)
{
	int i, j, centringShift ;
	float c ;
	
	centringShift = (Fourier->rangeFFT->dimX - anImage->rangeDim)/2 ;
	for(i = 0; i < anImage->numberOfLinesPerBloc; i++) {
//		c = -1. ;
		c = -1. ;
		for(j = 0; j < Fourier->rangeFFT->dimX; j++) {
			c *= -1. ;
			Fourier->indexedFilteredData[i][j] = mRC(Fourier->indexedFilteredData[i][j], c) ;
		}
		memcpy(anImage->indexedData[i], &Fourier->indexedFilteredData[i][centringShift], anImage->rangeDim * sizeof(complexFloat)) ;
	}
}
*/

void deHamming(FourierWorld *Fourier) 
{
	int i, j ;
	
	for(i = 0; i < Fourier->rangeFFT->dimY; i++) {
		for(j = 0; j < Fourier->rangeFFT->dimX; j++) {
			Fourier->indexedData[i][j] = mRC(Fourier->indexedData[i][j], Fourier->deHammingFilter[j]) ;
		}
	}
}
