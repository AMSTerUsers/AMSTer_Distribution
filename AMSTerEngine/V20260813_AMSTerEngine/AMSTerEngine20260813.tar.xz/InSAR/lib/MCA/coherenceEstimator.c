
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/



/*
 *  incohmod.c
 *  MCA
 *
 *  Created by Dominique Derauw on April 29, 2009
 *  Copyright 2009 Dominique Derauw. All rights reserved.
 *
 */

#include "MCA.h"
#include "incomod.h"


/* Interferogram, coherence and module images generation from a Master and Slave interferometric pair */
void coherenceEstimator(InSARParametersStruct *p, int saveIntensityImage)
{
	/* local variables declaration */
	int i, is, j, k, l, lenr, lena, cor, coa, Ncote ;
	int		Dresa, Dresr ;
	int		Faz, Fra, IndiceColonne, IndiceLigneBI, IndiceLigne ;
    int xDim, yDim ;
	long	Ldec ;
	float	Norme ;
	float	*Coherence ;
	float	*intensityImage1 = NULL ;
	float	*intensityImage2 = NULL ;
	float	**MA1, **MA2, *tMA1, *tMA2, *MA10, *MA20 ;
	double	*scd1, *scd2, sn1, sld1, sld2 ;
	complexFloat		**Mphi, *tMphi, *Mphi0 ;
	complexDouble		*scn, sln ;
	struct BlocInSAR	BI ;
	progressCounter *aCounter ;

/*----------------------------------  INITIALISATION  -----------------------------------*/

	/* copying parameters to local variables */
	coa = p->coh.coa ;
	cor = p->coh.cor ;
	Fra = p->red.Fra ;
	Faz = p->red.Faz ;
	
	/* Verifying Ncote is odd */
	Ncote = p->coh.spi = 1 ;
	Ncote = 2 * (Ncote / 2) + 1 ;
    
	
	/* Calculating dimension of working area of input data */
	lenr = p->sup.Sdra - p->sup.Sgra - Ncote + 2 ;
	lena = p->sup.Shaz - p->sup.Sbaz - Ncote + 2 ;
	
	/* Calculating normalization factors for moving average and box average */
	Norme = (float)(p->red.Faz * p->red.Fra) ;

	/* Calculating dimension of output product */
	p->coherenceFile->xDim = Dresr = (lenr - p->coh.cor + 1)/p->red.Fra ;
	p->coherenceFile->yDim = Dresa = (lena - p->coh.coa + 1)/p->red.Faz ;
	
	
	/* We will work on memory blocks of 64Mb max when considering complexFloat blocks of data (8 bytes per pixels) */
    xDim =  MIN(p->masterImageFile->xDim, p->slaveImageFile->xDim) ;
    yDim =  MIN(p->masterImageFile->yDim, p->slaveImageFile->yDim) ;
	BI.Dima = 8 * 1024 * 1024 / xDim ;
    BI.Dima = (BI.Dima > yDim)? yDim : BI.Dima ;
	/* We limit azimuth size of blocks to 1920 lines for filtering reasons */
	BI.Dima = (BI.Dima > 1920)? 1920 : BI.Dima ;
	BI.IndiceLigne = p->sup.Sbaz ;

	/* InSAR data blocks and filter initialization */
	AllocBlocInSAR(&BI, p) ;
	BI.f1 = p->masterImageFile->f ;
	BI.f2 = p->slaveImageFile->f ;
	initFiltering(&BI, p) ;

	/* ------------------- Initialisation ------------------- */
	Coherence = vectorFloat(0, Dresr-1) ;
	if(saveIntensityImage) 
		intensityImage1 = vectorFloat(0, Dresr-1) ;
	if(saveIntensityImage == 2) 
		intensityImage2 = vectorFloat(0, Dresr-1) ;
	scd1 = vectorDouble(0, lenr-1) ;
	scd2 = vectorDouble(0, lenr-1) ;
	scn = vectorComplexDouble(0, lenr-1) ;
	MA1 = matrixFloat(-1, coa-1, 0, lenr-1) ;
	MA10 = MA1[-1] ;
	MA2 = matrixFloat(-1, coa-1, 0, lenr-1) ;
	MA20 = MA2[-1] ;
	Mphi = matrixComplexFloat(-1, coa-1, 0, lenr-1) ;
	Mphi0 = Mphi[-1] ;
	
	for(i=0; i<lenr; i++) {
		scn[i].r = scn[i].i = scd1[i] = scd2[i] = 0.0 ;
		Mphi[-1][i].r = Mphi[-1][i].i = 0.0 ;
		MA1[-1][i] = MA2[-1][i] = 0.0 ;
	}

	IndiceLigneBI = 0 ;
	IndiceLigne = 0 ;
	GenPhi(&BI, p) ;

	IndiceLigneBI = 0 ;
	for(i=0; i<coa-1; i++) {
        TransfertPhi(Mphi[i], &BI, IndiceLigneBI, Ncote/2) ;
		TransfertMod(MA1[i], MA2[i], &BI, IndiceLigneBI, Ncote/2) ;
		IndiceLigneBI++ ;
		IndiceLigne++ ;
		for(j=0; j<lenr; j++)
		{
			scn[j].r += (double)Mphi[i][j].r ;
			scn[j].i += (double)Mphi[i][j].i ;
			scd1[j] += (double)MA1[i][j] ;
			scd2[j] += (double)MA2[i][j] ;
		}
	}

	/* ------------------- Calcul de la cohérence ------------------- */

	is = coa - 1 ;
	aCounter = initProgressCounterWithMinMaxValue(0, Dresa) ;
	for(i=0; i<Dresa; i++)
	{
		for(j=0; j<Dresr; j++) {
			Coherence[j] = 0.0 ;
            if(saveIntensityImage) 
                intensityImage1[j] = 0.0 ;
            if(saveIntensityImage == 2) 
                intensityImage2[j] = 0.0 ;
		}

		for(l=0; l<Faz; l++) {
			if(IndiceLigneBI == BI.Dima - Ncote + 1) {
                GenPhi(&BI, p) ;
				IndiceLigneBI = 0 ;
			}
			TransfertPhi(Mphi[is], &BI, IndiceLigneBI, Ncote/2) ;
			TransfertMod(MA1[is], MA2[is], &BI, IndiceLigneBI, Ncote/2) ;
			IndiceLigneBI++ ;
			IndiceLigne++ ;
			for(j=0; j<lenr; j++)
			{
				scn[j].r += (double)Mphi[is][j].r - (double)Mphi[-1][j].r ;
				scn[j].i += (double)Mphi[is][j].i - (double)Mphi[-1][j].i ;
				scd1[j] += (double)MA1[is][j] - (double)MA1[-1][j] ;
				scd2[j] += (double)MA2[is][j] - (double)MA2[-1][j] ;
			}
	
			sln.r = sln.i = sld1 = sld2 = 0.0 ;
			for(j=0; j<cor-1; j++)
			{
				sln.r += scn[j].r ;
				sln.i += scn[j].i ;
				sld1 += scd1[j] ;
				sld2 += scd2[j] ;
			}

			for(j=0; j<Dresr; j++)
			{
				for(k=0; k<Fra; k++){
					IndiceColonne = j * Fra + k + cor-1 ;
					sln.r += scn[IndiceColonne].r ;
					sln.i += scn[IndiceColonne].i ;
					sld1 += scd1[IndiceColonne] ;
					sld2 += scd2[IndiceColonne] ;
                    
					sn1 = sld1*sld2 ;
					Coherence[j] += (sn1 > Chouillat)? (float)(sqrt((sln.r * sln.r + sln.i * sln.i)/sn1)) : 0 ;
					if(saveIntensityImage) intensityImage1[j] += sld1 ;
					if(saveIntensityImage == 2) intensityImage2[j] += sld2 ;

					IndiceColonne = j * Fra + k ;
					sln.r -= scn[IndiceColonne].r ;
					sln.i -= scn[IndiceColonne].i ;
					sld1 -= scd1[IndiceColonne] ;
					sld2 -= scd2[IndiceColonne] ;
				}
			}
	
			tMphi = Mphi[-1] ; tMA1 = MA1[-1] ; tMA2= MA2[-1] ;
			for(j=-1; j<is; j++)
			{
				Mphi[j] = Mphi[j+1] ;
				MA1[j] = MA1[j+1] ;
				MA2[j] = MA2[j+1] ;
			}
			Mphi[is] = tMphi ; MA1[is] = tMA1 ; MA2[is] = tMA2 ;
		}

		for(j=0; j<Dresr; j++) {
			Coherence[j] /= Norme ;
			if(saveIntensityImage) intensityImage1[j] /= Norme ;
			if(saveIntensityImage == 2) intensityImage2[j] /= Norme ;
		}

		Ldec = (long)i*Dresr*sizeof(float) ;
		if(fseek(p->coherenceFile->f, Ldec, 0))
			ase("coherenceEstimator.c : Failed to fseek in coherence file") ;
		if(fwrite((float *)Coherence, sizeof(float), (size_t)Dresr, p->coherenceFile->f) != (size_t)Dresr) {
			ase("coherenceEstimator.c : Failed to write in coherence file") ;
		}
		
		if(saveIntensityImage) {
			if(fseek(p->masterAmplitudeImageFile->f, Ldec, 0))
				ase("coherenceEstimator.c : Failed to fseek in intensity file") ;
			if(fwrite((float *)intensityImage1, sizeof(float), (size_t)Dresr, p->masterAmplitudeImageFile->f) != (size_t)Dresr) {
				ase("coherenceEstimator.c : Failed to write in intensity file") ;
			}
		}
		
		if(saveIntensityImage == 2) {
			if(fseek(p->slaveAmplitudeImageFile->f, Ldec, 0))
				ase("coherenceEstimator.c : Failed to fseek in intensity file") ;
			if(fwrite((float *)intensityImage2, sizeof(float), (size_t)Dresr, p->slaveAmplitudeImageFile->f) != (size_t)Dresr) {
				ase("coherenceEstimator.c : Failed to write in intensity file") ;
			}
		}
		
		updatePointProgressCounterForIndex(aCounter, i) ;
	}

	freeVectorFloat(Coherence, 0) ;
	if(saveIntensityImage) {
		freeVectorFloat(intensityImage1, 0) ;
		fclose(p->masterAmplitudeImageFile->f) ;
	}
	if(saveIntensityImage == 2) {
		freeVectorFloat(intensityImage2, 0) ;
		fclose(p->slaveAmplitudeImageFile->f) ;
	}

	freeVectorComplexDouble(scn, 0) ;
	freeVectorDouble(scd1, 0) ;
	freeVectorDouble(scd2, 0) ;
	free(Mphi0) ;
	free(--Mphi) ;
	free(MA10) ;
	free(--MA1) ;
	free(MA20) ;
	free(--MA2) ;
	LibBlocInSAR(&BI) ;

	return ;
}



