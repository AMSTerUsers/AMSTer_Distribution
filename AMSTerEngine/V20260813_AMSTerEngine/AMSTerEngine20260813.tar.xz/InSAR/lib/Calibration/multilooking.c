
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  multilooking.c
//  SLC2MDG
//
//  Created by Dominique Derauw on 25/03/13.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "multilooking.h"



void multilooking(tileTool *inputDataTile, MLStruct *ml )
{
    if (ml->NLooks > 1) {
        DCCentringOfTile(inputDataTile, ml) ;
        applyDeHammingFilter(inputDataTile, ml) ;
    }
    transferDataToSubLooks(inputDataTile, ml) ;
    sublookZoom(ml) ;
    multilookDetection(ml) ;
}

MLStruct *allocMLStruct()
{
    MLStruct *ml ;
    
    if((ml = malloc(sizeof(MLStruct))) == NULL)
        ase("Failed to allocate multilooking structure") ;
    
    return (ml) ;
}

void initMLTileTools(MLStruct *ml, rawFileDescriptor *inputFile)
{
    int iX, iY, lookIndex ;
    complexFloat *aNullVector ;
    
    /* Init processing values */
    if(ml->SLCInfo != NULL) {
        ml->prf = ml->SLCInfo->prf ;
        ml->azimuthBandwidth = ml->SLCInfo->azimuthBandwidth ;
        ml->fdc = allocXPolynomialOfOrder(2) ;
        ml->fdc->coefs = ml->SLCInfo->fdc ;
        ml->rangeSampling = ml->SLCInfo->rangeResolutionCell ;
    }
    
    /* Initialize sublooks tile sizes */
    ml->rangeZoomFactor = RANGE_ZOOM_FACTOR ;
    ml->sublookAzimuthTileSize = ceil2ofIntVal(ml->singleLookAzimuthTileSize / ml->NLooks) ;
    ml->sublookRangeTileSize = ml->singleLookRangeTileSize * ml->rangeZoomFactor ;
    ml->azimuthScalingFactor = (double)ml->singleLookAzimuthTileSize / ml->sublookAzimuthTileSize ;
    ml->sublookRangeTileBorder = ml->singleLookRangeTileBorder * ml->rangeZoomFactor ;
    ml->sublookAzimuthTileBorder = (int)(ml->singleLookAzimuthTileBorder / ml->azimuthScalingFactor) ;
    ml->rangeScalingFactor = 1. / ml->rangeZoomFactor ;
    ml->azimuthZoomFactor = 1. / ml->azimuthScalingFactor ;
    
    /* Adapt xBoxAveragingSize to cope with range zoom factor */
    ml->xBoxAveragingSize *= RANGE_ZOOM_FACTOR ;
    
    /* Allocate and initialize sublook tile tools */
    ml->sublook = malloc(ml->NLooks * sizeof(tileTool *)) ;
    aNullVector = vectorComplexFloat(0, ml->sublookRangeTileSize - 1) ;
    for (iX = 0; iX < ml->sublookRangeTileSize; iX++) {
        aNullVector[iX].i = aNullVector[iX].r = 0. ;
    }
    for (lookIndex = 0; lookIndex < ml->NLooks; lookIndex++) {
        ml->sublook[lookIndex] = allocTileToolForFilesOfType(NULL, NULL, "complexFloat") ;
        ml->sublook[lookIndex]->xDimIn = ml->sublookRangeTileSize ;
        ml->sublook[lookIndex]->yDimIn = ml->sublookAzimuthTileSize ;
        initTileToolWithSizes(ml->sublook[lookIndex], ml->sublookRangeTileSize, ml->sublookAzimuthTileSize, ml->sublookRangeTileBorder, ml->sublookAzimuthTileBorder) ;
        
        for (iY = 0; iY < ml->sublookAzimuthTileSize; iY++) {
            memcpy(ml->sublook[lookIndex]->tile[iY], aNullVector, ml->sublookRangeTileSize * sizeof(complexFloat)) ;
        }
    }
    
    /* Allocate tile tool for detected multilooked tile */
    ml->detectedMultilookedImage = allocTileToolForFilesOfType(NULL, NULL, "float") ;
    if (ml->NLooks > 1) {
        ml->detectedRangeTileSize = ml->sublookRangeTileSize ;
        ml->detectedRangeTileBorder = ml->sublookRangeTileBorder ;
        ml->detectedAzimuthTileSize = ml->sublookAzimuthTileSize ;
        ml->detectedAzimuthTileBorder = ml->sublookAzimuthTileBorder ;
        ml->detectedMultilookedImage->xDimIn = inputFile->xDim * ml->rangeZoomFactor ;
        ml->detectedMultilookedImage->yDimIn = inputFile->yDim / ml->azimuthScalingFactor ;
    }
    else {
        ml->detectedRangeTileSize = ml->sublook[0]->xDimEA / ml->xBoxAveragingSize ;
        ml->detectedRangeTileBorder = 0 ;
        ml->detectedAzimuthTileSize = ml->sublook[0]->yDimEA / ml->yBoxAveragingSize ;
        ml->detectedAzimuthTileBorder = 0 ;
        ml->detectedMultilookedImage->xDimIn = inputFile->xDim * ml->rangeZoomFactor / ml->xBoxAveragingSize ;
        ml->detectedMultilookedImage->yDimIn = inputFile->yDim / ml->yBoxAveragingSize ;
    }
    initTileToolWithSizes(ml->detectedMultilookedImage, ml->detectedRangeTileSize, ml->detectedAzimuthTileSize, ml->detectedRangeTileBorder, ml->detectedAzimuthTileBorder) ;

    freeVectorComplexFloat(aNullVector, 0) ;
}

void initMLTemporaryDataFileAtPath(MLStruct *ml, char *directoryPath)
{
    char *aPath ;
    
    aPath = initStringWith2Strings(directoryPath, "/MLData") ;
    ml->mlData = openRawFileForReadingAndWritingAtPath(aPath) ;
    ml->mlData->xDim = ml->detectedMultilookedImage->xDimOut ;
    ml->mlData->yDim = ml->detectedMultilookedImage->yDimOut ;
    free(aPath) ;
}

void initMultilooking(MLStruct *ml)
{
    int iY ;
    int lowerIndex, upperIndex, filterOverlap ;
    double dnu ;
    
    /* Initialization of azimuth FFTs for multilooking process */
    ml->azimuthFFTOfinputTile = initFFT(ml->singleLookRangeTileSize, ml->singleLookAzimuthTileSize, ALONGY) ;
    ml->azimuthFFTOfSublookTile = initFFT(ml->sublookRangeTileSize, ml->sublookAzimuthTileSize, ALONGY) ;
    
    /* de-Hamming filter allocation */
    ml->deHammingFilter = vectorDouble(0, ml->singleLookAzimuthTileSize - 1) ;

    /* re-Hamming filter allocation */
    ml->hammingFilter = vectorDouble(0, ml->sublookAzimuthTileSize - 1) ;
    
    /* Pass band filter allocation */
    ml->passBandFilter = vectorDouble(0, ml->sublookAzimuthTileSize - 1) ;

    /* de-Hamming filter generation */
    dnu = ml->prf / ml->singleLookAzimuthTileSize ;
    
    lowerIndex = divr(ml->prf - ml->azimuthBandwidth, 2. * dnu).q ;
    upperIndex = lowerIndex + divr(ml->azimuthBandwidth, dnu).q ;
    
    /* Full bandwidth test */
    lowerIndex = divr(ml->prf - ml->prf, 2. * dnu).q ;
    upperIndex = lowerIndex + divr(ml->prf, dnu).q - 1 ;
    
    for (iY = 0; iY <= lowerIndex; iY++) {
        ml->deHammingFilter[iY] = ml->deHammingFilter[ml->singleLookAzimuthTileSize - iY - 1] = 1. / (2. * ml->hammingFactor - 1.) ;
    }
    for (iY = lowerIndex; iY <= upperIndex; iY++) {
        ml->deHammingFilter[iY] = 1. / (ml->hammingFactor - (1. - ml->hammingFactor) * cos(TWOPI / (upperIndex - lowerIndex) * (iY - lowerIndex))) ;
    }
    /* de-Hamming filter normalization */
    /*
    norm = 0. ;
    for(iY = 0; iY < ml->singleLookAzimuthTileSize; iY++) norm += ml->deHammingFilter[iY] ;
    norm /= ml->singleLookAzimuthTileSize ;
    for(iY = 0; iY < ml->singleLookAzimuthTileSize; iY++) ml->deHammingFilter[iY] /= norm ;
    */
    
    /* Pass-band and re-Hamming filter generation */
    /* filterOverlap is a slight overlapping of band-pas filters decreasing from 1 to 0 along a cosine low to keep FFT signifiance */
    filterOverlap = ml->sublookAzimuthTileSize / 100 ;
    lowerIndex /= ml->azimuthScalingFactor ;
    upperIndex /= ml->azimuthScalingFactor ;
    for (iY = 0; iY <= lowerIndex; iY++) {
        ml->hammingFilter[iY] = ml->hammingFilter[ml->sublookAzimuthTileSize - iY - 1] = (2. * ml->hammingFactor - 1.) ;
        ml->passBandFilter[iY] = 0. ;
    }
    for (iY = lowerIndex; iY <= upperIndex; iY++) {
        ml->hammingFilter[iY] = (ml->hammingFactor - (1. - ml->hammingFactor) * cos(TWOPI / (upperIndex - lowerIndex) * (iY - lowerIndex))) ;
        ml->passBandFilter[iY] = 1. ;
    }
    for (iY = 0; iY < filterOverlap; iY++) {
        ml->passBandFilter[lowerIndex - iY] = ml->passBandFilter[upperIndex + iY] = (1. + cos(PI * (double)iY / (double)filterOverlap))/2. ;
    }
 
    /* re-Hamming filter normalization */
    /*
    norm = 0. ;
    for(iY = 0; iY < ml->sublookAzimuthTileSize; iY++) norm += ml->hammingFilter[iY] ;
    norm /= ml->sublookAzimuthTileSize ;
    for(iY = 0; iY < ml->sublookAzimuthTileSize; iY++) ml->hammingFilter[iY] /= norm ;
    */
    
    /* If performing box averaging, the rangeScaling factor and azimuthScalingFactor must be restored to box averaging sizes */
    if (ml->NLooks == 1) {
        ml->rangeScalingFactor = ml->xBoxAveragingSize / ml->rangeZoomFactor ;
        ml->azimuthScalingFactor = ml->yBoxAveragingSize ;
    }
}


void freeMultilook(MLStruct *ml)
{
    int lookIndex ;
    
    for (lookIndex = 0; lookIndex < ml->NLooks; lookIndex++) {
        freeTileTool(ml->sublook[lookIndex]) ;
    }
    freeTileTool(ml->detectedMultilookedImage) ;
    freeFFT(ml->azimuthFFTOfinputTile) ;
    freeFFT(ml->azimuthFFTOfSublookTile) ;
    
    freeVectorDouble(ml->deHammingFilter, 0) ;
    freeVectorDouble(ml->hammingFilter, 0) ;
    freeVectorDouble(ml->passBandFilter, 0) ;
}



/* ********************************** */
void	DCCentringOfTile(tileTool *inputDataTile, MLStruct *ml)
{
    size_t		iX, iY ;
    float	DCShift, Dt ;
    complexFloat **data, phaseShift ;
    
    
    data = (complexFloat **)inputDataTile->tile ;
    
    for(iX = 0 ; iX < inputDataTile->xTileSize; iX++) {
        Dt = 2. * ml->rangeSampling / c0  * (double)(iX + inputDataTile->x0In) ;
        DCShift = 0.5 - yValForPolynomial(ml->fdc, Dt) / ml->prf ;
        for(iY = 0; iY < inputDataTile->yTileSize; iY++) {
            phaseShift.r = cosf(PI*2. * DCShift * iY) ;
            phaseShift.i = sinf(PI*2. * DCShift * iY) ;
            data[iY][iX] = mC(data[iY][iX], phaseShift) ;
        }
    }    
}


void applyDeHammingFilter(tileTool *inputDataTile, MLStruct *ml)
{
    size_t iX, iY ;
    complexFloat **data ;
    
    data = (complexFloat **)inputDataTile->tile ;
    /* First, go into Fourier space */
    fftY(FORWARD_FFT, data[0], ml->azimuthFFTOfinputTile) ;
    
    /* Then apply deHamming filter */
    for(iX = 0 ; iX < inputDataTile->xTileSize; iX++) {
        for(iY = 0; iY < inputDataTile->yTileSize; iY++) {
            data[iY][iX] = mRC(data[iY][iX], ml->deHammingFilter[iY]) ;
        }
    }
}


void transferDataToSubLooks(tileTool *inputDataTile, MLStruct *ml)
{
    int iX, iY, lookIndex, lowerIndex, inputIndex ;
    int ABW ;
    float filterVal ;
    complexFloat **data, **sublook ;
    
    /* We compute the azimuth bandWidth in terms of samples in the Fourier domain */
    ABW = (int)ceil(ml->azimuthBandwidth / ml->prf * ml->singleLookAzimuthTileSize) ;
    
    data = (complexFloat **)inputDataTile->tile ;

    /* Save tile indexes */
    ml->xTileIndex = inputDataTile->xTileIndex ;
    ml->yTileIndex = inputDataTile->yTileIndex ;
    
    /* For each sublook...*/
    for (lookIndex = 0; lookIndex < ml->NLooks; lookIndex++) {
        sublook = (complexFloat **)ml->sublook[lookIndex]->tile ;
        if (ml->NLooks > 1) {
//            lowerIndex = -(ABW / 2 * (1. - (2. * lookIndex +  1.)/ml->NLooks)) + ml->singleLookAzimuthTileSize / 2 - ml->sublookAzimuthTileSize / 2 ;
            lowerIndex = (ml->singleLookAzimuthTileSize - (ABW * (ml->NLooks - (2 * lookIndex +  1)) / ml->NLooks) - ml->sublookAzimuthTileSize) / 2 ;
            
            /* Transfer data */
            for (iX = 0; iX < ml->singleLookRangeTileSize; iX++) {
                inputIndex = lowerIndex ;
                for (iY = 0; iY < ml->sublookAzimuthTileSize; iY++, inputIndex++) {
                    if ((inputIndex >= 0) && (inputIndex < ml->singleLookAzimuthTileSize)) {
                        filterVal = (float)(ml->passBandFilter[iY] * ml->hammingFilter[iY]);
                        sublook[iY][iX] = mRC(data[inputIndex][iX], filterVal) ;
                    }
                }
            }
            
            /* Then come back to image space */
            fftY(INVERSE_FFT, sublook[0], ml->azimuthFFTOfSublookTile) ;

        }
        else {
            /* Transfer data */
            for (iX = 0; iX < ml->singleLookRangeTileSize; iX++) {
                for (iY = 0; iY < ml->sublookAzimuthTileSize; iY++) {
                    sublook[iY][iX] = data[iY][iX] ;
                }
            }
        }
        
        /* Transfer input tile values to sublook tiles */
        updateTileToolForIndexes(ml->sublook[lookIndex], ml->xTileIndex, ml->yTileIndex) ;
    }
}


void sublookZoom(MLStruct *ml)
{
    int iX, iY, lookIndex ;
    double zoomFactor ;
    complexFloat *aLine, phaseShift ;
    CZTInterpolator *rangeZoom ;
    
    zoomFactor = 1. / ml->rangeZoomFactor ;
    rangeZoom = initInterpolator(ml->sublookRangeTileSize, zoomFactor) ;
    
    for (lookIndex = 0; lookIndex < ml->NLooks; lookIndex++) {
        for (iY = 0; iY < ml->sublookAzimuthTileSize; iY++) {
            aLine = (complexFloat *)ml->sublook[lookIndex]->tile[iY] ;
            
            /* Apply a phase shift to center the range spectrum before interpolation */
            phaseShift.r = 1. ;
            phaseShift.i = 0. ;
            for (iX = 0; iX < ml->sublookRangeTileSize; iX++) {
                aLine[iX] = mC(aLine[iX], phaseShift) ;
                phaseShift.r *= -1. ;
            }
            
            CZTInterpolation(aLine, zoomFactor, 0., rangeZoom) ;
            
            /* Apply reverse phase shift (not very useful since we will detect the produxt...) */
            for (iX = 0; iX < ml->sublookRangeTileSize; iX++) {
                phaseShift.r = (float)cos(-PI * iX * zoomFactor) / ml->sublookRangeTileSize ;
                phaseShift.i = (float)sin(-PI * iX * zoomFactor) / ml->sublookRangeTileSize ;
                aLine[iX] = mC(aLine[iX], phaseShift) ;
            }
        }
    }
}



void multilookDetection(MLStruct *ml)
{
    int iX, iY, lookIndex, k, l, xIndex, yIndex ;
    float **detectedImage ;
    float norm ;
    complexFloat **sublook ;
    
    detectedImage = (float **)ml->detectedMultilookedImage->tile ;
    
    /* If multilooking was performed, detection is made by averaging detected looks */
    if (ml->NLooks > 1) {
        norm = (float)(ml->azimuthScalingFactor * ml->NLooks) ;
        lookIndex = 0 ;
         for (lookIndex = 0; lookIndex < ml->NLooks; lookIndex++) {
            sublook = (complexFloat **)ml->sublook[lookIndex]->tile ;
            for (iY = 0; iY < ml->sublookAzimuthTileSize; iY++) {
                for (iX = 0; iX < ml->sublookRangeTileSize; iX++) {
                    detectedImage[iY][iX] += sqmC(sublook[iY][iX]) ;
                }
            }
        }
        /* Compute the average detected value and convert it in db if required */
        for (iY = 0; iY < ml->sublookAzimuthTileSize; iY++) {
            for (iX = 0; iX < ml->sublookRangeTileSize; iX++) {
                detectedImage[iY][iX] /= norm ;
                if (ml->expressInDB) {
                    detectedImage[iY][iX] = 10. * log10f(detectedImage[iY][iX]) ;
                }
            }
        }
    }
    /* If box averaging must be performed, do it now */
    else {
        sublook = (complexFloat **)ml->sublook[0]->tile ;
        for (iY = 0; iY < ml->detectedAzimuthTileSize; iY++) {
            for (iX = 0; iX < ml->detectedRangeTileSize; iX++) {
                detectedImage[iY][iX] = 0 ;
                xIndex = ml->sublook[0]->xTileBorderSize + iX * ml->xBoxAveragingSize ;
                for (k = 0; k < ml->xBoxAveragingSize; k++, xIndex++) {
                    yIndex = ml->sublook[0]->yTileBorderSize + iY * ml->yBoxAveragingSize ;
                    for (l = 0; l < ml->yBoxAveragingSize; l++, yIndex++) {
                        detectedImage[iY][iX] += sqmC(sublook[yIndex][xIndex]) ;
                    }
                }
            }
        }
        /* Compute the average detected value and convert it in db if required */
        norm = (float)(ml->xBoxAveragingSize * ml->yBoxAveragingSize) ;
        for (iY = 0; iY < ml->detectedAzimuthTileSize; iY++) {
            for (iX = 0; iX < ml->detectedRangeTileSize; iX++) {
                detectedImage[iY][iX] /= norm ;
                if (ml->expressInDB) {
                    detectedImage[iY][iX] = 10. * log10f(detectedImage[iY][iX]) ;
                }
            }
        }
    }

    updateTileToolForIndexes(ml->detectedMultilookedImage, ml->xTileIndex, ml->yTileIndex) ;    
    writeTileToOutputFile(ml->detectedMultilookedImage, ml->mlData) ;

}


void cleanAllTiles(tileTool *inputDataTile, MLStruct *ml)
{
    int lookIndex ;
    
    resetTileToZero(inputDataTile) ;
    for (lookIndex = 0; lookIndex < ml->NLooks; lookIndex++) {
        resetTileToZero(ml->sublook[lookIndex]) ;
    }
    resetTileToZero(ml->detectedMultilookedImage) ;
}



