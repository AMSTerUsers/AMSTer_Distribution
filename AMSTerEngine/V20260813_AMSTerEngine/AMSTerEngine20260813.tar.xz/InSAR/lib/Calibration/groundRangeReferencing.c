
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  groundRangeReferencing.c
//  SLC2MDG
//
//  Created by Dominique Derauw on 26/03/13.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "groundRangeReferencing.h"


void unlinkS2GTemporaryFiles(geoRef *gR)
{
    char *aPath ;
    
    aPath = initStringWithString(gR->files->xRef->accessPath) ;
    freeRawFileDescriptor(gR->files->xRef) ;
    gR->files->xRef = NULL ;
    unlink(aPath) ;
    free(aPath) ;
    aPath = initStringWithString(gR->files->yRef->accessPath) ;
    freeRawFileDescriptor(gR->files->yRef) ;
    gR->files->yRef = NULL ;
    unlink(aPath) ;
    free(aPath) ;
}
    


void groundRangeReferencingOfTile(tileTool *inputTileTool, geoRef *gR, gridMap *s2gGrid)
{
    char isFrameInitialized ;
    size_t iX, iY ;
    float **inputTile, **xReferencing, **yReferencing ;
    double rangePosition, azimuthPosition ;
    double azimuthCoordinate ;
    
    xReferencing = matrixFloat(0, inputTileTool->yTileSize - 1, 0, inputTileTool->xTileSize - 1) ;
    yReferencing = matrixFloat(0, inputTileTool->yTileSize - 1, 0, inputTileTool->xTileSize - 1) ;

    isFrameInitialized = 1 ;
    if (!gR->frame->xMin && !gR->frame->xMax && !gR->frame->yMin && !gR->frame->yMax) {
        isFrameInitialized = 0 ;
    }
	
    inputTile = (float **)inputTileTool->tile ;
    for (iY = inputTileTool->y0EA; iY < inputTileTool->y0EA + inputTileTool->yDimEA; iY++) {
        azimuthPosition = (inputTileTool->y0In + iY - (int)inputTileTool->y0Tile) * gR->params->yReductionFactor ;
        azimuthCoordinate = azimuthPosition * gR->params->ySampling ;
        for (iX = inputTileTool->x0EA; iX < inputTileTool->x0EA + inputTileTool->xDimEA; iX++) {
            rangePosition = (inputTileTool->x0In + iX - (int)inputTileTool->x0Tile) * gR->params->xReductionFactor ;
            xReferencing[iY][iX] = (float)interpolGridForImageCoordinate(s2gGrid, rangePosition, azimuthPosition) ;
            yReferencing[iY][iX] = (float)azimuthCoordinate ;
            
            if(!isFrameInitialized) {
                /* georeferencing of first point will be used as initialization for the georeferencing frame */
                if (inputTile[iY][iX]) {
                    gR->frame->xMin = gR->frame->xMax = xReferencing[iY][iX] ;
                    gR->frame->yMin = gR->frame->yMax = yReferencing[iY][iX] ;
                    isFrameInitialized = 1 ;
                }
            }
            else {
                if (inputTile[iY][iX]) {
                    gR->frame->xMax = (xReferencing[iY][iX] > gR->frame->xMax)? xReferencing[iY][iX] : gR->frame->xMax ;
                    gR->frame->xMin = (xReferencing[iY][iX] < gR->frame->xMin)? xReferencing[iY][iX] : gR->frame->xMin ;
                    gR->frame->yMax = (yReferencing[iY][iX] > gR->frame->yMax)? yReferencing[iY][iX] : gR->frame->yMax ;
                    gR->frame->yMin = (yReferencing[iY][iX] < gR->frame->yMin)? yReferencing[iY][iX] : gR->frame->yMin ;
                }
			}
        }
    }
    
    /* In case of ground range projection, the frame lower corner cannot be negative */
    gR->frame->xMin = (gR->frame->xMin < 0)? 0. : gR->frame->xMin ;
    
    /* Save referencing */
    inputTile = (float **)inputTileTool->tile ;
    inputTileTool->tile = (void **)xReferencing ;
    writeTileToOutputFile(inputTileTool, gR->files->xRef) ;
    inputTileTool->tile = (void **)yReferencing ;
    writeTileToOutputFile(inputTileTool, gR->files->yRef) ;
    inputTileTool->tile = (void **)inputTile ;
    
    freeMatrixFloat(xReferencing, 0, 0) ;
    freeMatrixFloat(yReferencing, 0, 0) ;
}

gridMap *computeGroundRangeReferencingGrid(geoRef *gR)
{
    int iX, iY ;
    int xGridSpacing, yGridSpacing ;
    double rangePosition, azimuthPosition ;
    double groundRange, groundRange0 ;
    double rT00, rT0, rT, aT00, aT0, aT ;
    coord2D aPoint ;
    gridMap *groundRangReferencingGrid ;
    
    /* Create a grid with a point every 20 pixels in both dimensions */
    xGridSpacing = yGridSpacing = 20 ;
    groundRangReferencingGrid = createGridWithXYSpacing(gR->params->xDimInputData, gR->params->yDimInputData, xGridSpacing, yGridSpacing) ;
    
    /* Compute ground range grid values */
    for (iY = 0; iY < groundRangReferencingGrid->Ny; iY++) {
        aPoint = imageCoordinateForGridPoint(groundRangReferencingGrid, 0, iY) ;
        rangePosition = (double)(gR->params->x0) + aPoint.x ;
        azimuthPosition = (double)(gR->params->y0) + aPoint.y ;
        
        rT0 = earthRadiusAtPoint(rangePosition, azimuthPosition, 0., gR) ;
        aT0 = gR->solving->at ;
        
        rT00 = earthRadiusAtPoint(0., azimuthPosition, 0., gR) ;
        aT00 = gR->solving->at ;
        groundRange0 = (rT0 + rT00)/2. * (aT0 - aT00) ; ;
        
        for (iX = 0; iX < groundRangReferencingGrid->Nx; iX++) {
            aPoint = imageCoordinateForGridPoint(groundRangReferencingGrid, iX, iY) ;
            rangePosition = (double)(gR->params->x0) + aPoint.x ;
            azimuthPosition = (double)(gR->params->y0) + aPoint.y ;
            
            rT = earthRadiusAtPoint(aPoint.x, aPoint.y, 0., gR) ;
            aT = gR->solving->at ;
            
            groundRange = groundRange0 + (rT + rT0)/2. * (aT - aT0) ;
            groundRangReferencingGrid->val[iX][iY] = groundRange ;
            
            groundRange0 = groundRange ;
            rT0 = rT ;
            aT0 = aT ;
        }
    }
    
    return (groundRangReferencingGrid) ;
}

void computeGroundRangeReferencingTransform(grRef *grRefTool, SLCImageInfo *SLCInfo)
{
    int iX, iY, k, numberOfGridPoints, xOrder, yOrder, matrixDim, *index ;
    int xGridSpacing, yGridSpacing ;
    double rangePosition, azimuthPosition ;
    double groundRange, groundRange0 ;
    double rT0, rT, aT0, aT, val, rT00, aT00 ;
    double **M, sign, *SP ;
    geoRef *gR ;
    
    /* Test if input data size were set. If not, use full scene size */
    if (!grRefTool->xDimInputImage) {
        grRefTool->xDimInputImage = SLCInfo->rangeDimension ;
    }
    if (!grRefTool->yDimInputImage) {
        grRefTool->yDimInputImage = SLCInfo->azimuthDimension ;
    }
    
    /* Allocate slant to ground range transform */
    /* The slant to ground range transform we will compute is a polynomial of order 4 in range (x) with a second order dependence in azimuth */
    /* The second order dependence in azimuth is saved in the last polynomial coefficients */
    /* Rem : Several tests were performed. This transform allows getting a ground range with a precision beter than +/-3m for a Strip Map CSK image */
    xOrder = 4 ;
    yOrder = 2 ;
    grRefTool->s2gTransform = vectorDouble(0, xOrder + yOrder) ;
    
    /* Allocate matrix for mean square calculation */
    matrixDim = xOrder + yOrder + 1;
    M = matrixDouble(1, matrixDim, 1, matrixDim) ;
    index = vectorInt(1, matrixDim) ;
    for(iY = 1; iY <= matrixDim; iY++) {
        grRefTool->s2gTransform[iY - 1] = 0. ;
        for(iX = 1; iX <= matrixDim; iX++)
            M[iY][iX] = 0. ;
    }
    SP = vectorDouble(0, 8) ;
    for(iX = 0; iX < 8; iX++) 
        SP[iX] = 0 ;
    
    /* Allocate georeferencing structure */
    orbitInterpolation(SLCInfo) ;
    gR = allocAndInitGeorefStructureForTargetEllipsoid(SLCInfo, SLCInfo->ellRef) ;
    
    numberOfGridPoints = 100 ;
    xGridSpacing = grRefTool->xDimInputImage / numberOfGridPoints - 1 ; 
    yGridSpacing = grRefTool->yDimInputImage / numberOfGridPoints - 1 ; 
    
    for (iY = 0; iY < numberOfGridPoints; iY++) {
        azimuthPosition = (double)(grRefTool->y0InputImage + iY * yGridSpacing) ;
        rangePosition = (double)(grRefTool->x0InputImage) ;
        rT00 = rT0 = earthRadiusAtPoint(rangePosition, azimuthPosition, 0., gR) ;
        aT00 = aT0 = gR->solving->at ;
        groundRange0 = 0. ;
        for (iX = 0; iX < numberOfGridPoints; iX++) {
            rangePosition = (double)(grRefTool->x0InputImage + iX * xGridSpacing) ;
            rT = earthRadiusAtPoint(rangePosition, azimuthPosition, 0., gR) ;
            aT = gR->solving->at ;
            val = (rT + rT00)/2. * (aT - aT00) ;
            groundRange = groundRange0 + (rT + rT0)/2. * (aT - aT0) ;
            
            val -=groundRange ;
            for(k = 1; k <= 8; k++) SP[k] += pow(rangePosition, (double)k) ;
            
            M[1][1]++ ;
            M[1][matrixDim - 1] += azimuthPosition ;
            M[2][matrixDim - 1] += rangePosition * azimuthPosition ;
            M[3][matrixDim - 1] += pow(rangePosition, 2.) * azimuthPosition ;
            M[4][matrixDim - 1] += pow(rangePosition, 3.) * azimuthPosition ;
            M[5][matrixDim - 1] += pow(rangePosition, 4.) * azimuthPosition ;
            M[6][matrixDim - 1] += pow(azimuthPosition, 2.) ;
            M[7][matrixDim - 1] += pow(azimuthPosition, 3.) ;
            
            M[1][matrixDim] += pow(azimuthPosition, 2.) ;
            M[2][matrixDim] += rangePosition * pow(azimuthPosition, 2.) ;
            M[3][matrixDim] += pow(rangePosition, 2.) * pow(azimuthPosition, 2.) ;
            M[4][matrixDim] += pow(rangePosition, 3.) * pow(azimuthPosition, 2.) ;
            M[5][matrixDim] += pow(rangePosition, 4.) * pow(azimuthPosition, 2.) ;
            M[6][matrixDim] += pow(azimuthPosition, 3.) ;
            M[7][matrixDim] += pow(azimuthPosition, 4.) ;


            grRefTool->s2gTransform[0] += groundRange ;
            grRefTool->s2gTransform[1] += rangePosition * groundRange ;
            grRefTool->s2gTransform[2] += pow(rangePosition, 2.) * groundRange ;
            grRefTool->s2gTransform[3] += pow(rangePosition, 3.) * groundRange ;
            grRefTool->s2gTransform[4] += pow(rangePosition, 4.) * groundRange ;
            grRefTool->s2gTransform[5] += azimuthPosition * groundRange ;
            grRefTool->s2gTransform[6] += pow(azimuthPosition, 2.) * groundRange ;
            
            groundRange0 = groundRange ;
            rT0 = rT ;
            aT0 = aT ;
        }
        
    }
    
    SP[0] = M[1][1] ;
    for(iY = 1; iY <= xOrder + 1; iY++) {
        for(iX = 1; iX <= xOrder + 1; iX++) {
            M[iY][iX] = SP[iY + iX - 2] ;
        }
        M[iX][iY] = M[iY][iX] ;
        M[iX + 1][iY] = M[iY][iX + 1] ;
    }
    
    ludcmp(M, matrixDim, index, &sign) ;
    lubksb(M, matrixDim, index, &grRefTool->s2gTransform[-1]) ;
    
/*    
    brol = openRawFileForWritingAtPath("/DATA/gr.txt") ;
    for (iY = 0; iY < numberOfGridPoints; iY++) {
        azimuthPosition = (double)(grRefTool->y0InputImage + iY * yGridSpacing) ;
        rangePosition = (double)(grRefTool->x0InputImage) ;
        rT0 = earthRadiusAtPoint(rangePosition, azimuthPosition, 0., gR) ;
        aT0 = gR->solving->at ;
        groundRange0 = 0. ;
        for (iX = 0; iX < numberOfGridPoints; iX++) {
            rangePosition = (double)(grRefTool->x0InputImage + iX * xGridSpacing) ;
            rT = earthRadiusAtPoint(rangePosition, azimuthPosition, 0., gR) ;
            aT = gR->solving->at ;
            groundRange = groundRange0 + (rT + rT0)/2. * (aT - aT0) ;
            
            val = 0. ;
            for (k = 0; k <= xOrder; k++) {
                val += grRefTool->s2g[k] * pow(rangePosition, k) ;
            }
            val += grRefTool->s2g[k] * azimuthPosition ;
            val += grRefTool->s2g[k + 1] * pow(azimuthPosition, 2.) ;
            
            fprintf(brol->f, "%d\t%d\t%lf\n", iX, iY, val - groundRange) ;

            groundRange0 = groundRange ;
            rT0 = rT ;
            aT0 = aT ;
        }
    }
*/    
    freeMatrixDouble(M, 1, 1) ;
    freeVectorDouble(SP, 0) ;
}



