
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  geoReferencing.c
//  SLC2MDG
//
//  Created by Dominique Derauw on 10/05/13.
//  Copyright (c) 2013 Dominique Derauw. All rights reserved.
//

#include <stdio.h>
#include "geoReferencing.h"

void georeferencingOfTile(tileTool *inputTileTool, geoRef *gR, gridMap *DEMGrid)
{
	int rangeIndex, azimuthIndex ;
    float **inputTile ;
    double xSampling, xMaxSampling, xAverageSampling ;
    double ySampling, yMaxSampling, yAverageSampling ;
	double *onEllipsoidPoint ;
	double longitude, latitude, H ;
    double *P1, *P2 ;
	geoRefSolving *gRSolving ;
	
    char isFrameInitialized ;
    size_t iX, iY ;
    float **aFloatMatrix, **xReferencing, **yReferencing, **externalDEM ;
    
    inputTile = (float **)inputTileTool->tile ;
    
    xReferencing = matrixFloat(0, inputTileTool->yTileSize - 1, 0, inputTileTool->xTileSize - 1) ;
    yReferencing = matrixFloat(0, inputTileTool->yTileSize - 1, 0, inputTileTool->xTileSize - 1) ;
    
    externalDEM = NULL ;
    if (DEMGrid != NULL) {
        externalDEM = matrixFloat(0, inputTileTool->yTileSize - 1, 0, inputTileTool->xTileSize - 1) ;
    }
    
    isFrameInitialized = 1 ;
    if (!gR->frame->xMin && !gR->frame->xMax && !gR->frame->yMin && !gR->frame->yMax) {
        isFrameInitialized = 0 ;
    }
    	
    /* Initialize required vectors */
	onEllipsoidPoint = vectorDouble(0, 2) ;
    P1 = vectorDouble(0, 1) ;
    P2 = vectorDouble(0, 1) ;
    
    /* Initialize UTM transform if required */
	gRSolving = gR->solving ;
	if(gR->params->isUTM && !gR->params->UTMZone) {
		gR->params->UTMZone = initUTMReferencingOnEllipsoid(gR->params->ellProj) ;
		updateUTMZoneForSLCImage(gR, gR->params->UTMZone) ;
	}
	
    /* Initialize local height to average scene altitude */
    H = gR->params->info->sceneAverageHeight ;
    
    aFloatMatrix = (float **)inputTileTool->tile ;
    xMaxSampling = yMaxSampling = xAverageSampling = yAverageSampling = 0 ;
    for (iY = inputTileTool->y0EA; iY < inputTileTool->y0EA + inputTileTool->yDimEA; iY++) {
        azimuthIndex = (inputTileTool->y0In + (iY - (int)inputTileTool->y0Tile)) * gR->params->yReductionFactor ;
        for (iX = inputTileTool->x0EA; iX < inputTileTool->x0EA + inputTileTool->xDimEA; iX++) {
            rangeIndex = (inputTileTool->x0In + (iX - (int)inputTileTool->x0Tile)) * gR->params->xReductionFactor ;
            
            P2[0] = rangeIndex ;
            P2[1] = azimuthIndex ;
            /* If an additional affine transform is required, apply it */
            if (gR->params->affineTransform != NULL) {
                P1[0] = P2[0] ;
                P1[1] = P2[1] ;
                planeAffineTransformOfPoint(P1, P2, gR->params->affineTransform) ;
            }
            /* Compute state vector at azimuth coordinate */
            if(P2[1] != gRSolving->S->azimuthPosition) {
                calcStateVect(gRSolving->S, P2[1], gR->params->info) ;
                initOnSphereSolving(gRSolving) ;
            }
            
            /* Update height if required */
            if (DEMGrid != NULL) {
                H = interpolFloatGridForImageCoordinate(DEMGrid, P2[0], P2[1]) ;
            }
            
            /* Compute referencing */
            earthRadiusAtPoint(P2[0], P2[1], H, gR) ;
            onEllipsoidPoint = gRSolving->Pg ;
			XYZ2LonLat(&longitude, &latitude, onEllipsoidPoint, gRSolving) ;
			if(gR->params->isUTM) {
				lonLat2UTMOnEllipsoid(&longitude, &latitude, gR->params->UTMZone) ;
			}
            else {
                longitude *= 180./PI ;
                latitude *= 180./PI ;
            }

            xReferencing[iY][iX] = longitude ;
            yReferencing[iY][iX] = latitude ;
            if (DEMGrid != NULL) {
                externalDEM[iY][iX] = H ;
            }
            
            /* Measure max ySampling */
            if (iY > inputTileTool->y0EA) {
                ySampling = fabs(yReferencing[iY - 1][iX] - yReferencing[iY][iX]) ;
                yAverageSampling += ySampling ;
                yMaxSampling = (yMaxSampling < ySampling)? ySampling : yMaxSampling ;
            }
            
            /* Measure max X sampling */
            if (iX > inputTileTool->x0EA) {
                xSampling = fabs(xReferencing[iY][iX] - xReferencing[iY][iX - 1]) ;
                xAverageSampling += xSampling ;
                xMaxSampling = (xMaxSampling < xSampling)? xSampling : xMaxSampling ;
            }
            
            if(!isFrameInitialized) {
                /* georeferencing of first point will be used as initialization for the georeferencing frame */
                if (inputTile[iY][iX]) {
                    gR->frame->xMin = gR->frame->xMax = xReferencing[iY][iX] ;
                    gR->frame->yMin = gR->frame->yMax = yReferencing[iY][iX] ;
                    isFrameInitialized = 1 ;
                }
            }
            else {
                if (inputTile[iY][iX]) {
                    gR->frame->xMax = (xReferencing[iY][iX] > gR->frame->xMax)? xReferencing[iY][iX] : gR->frame->xMax ;
                    gR->frame->xMin = (xReferencing[iY][iX] < gR->frame->xMin)? xReferencing[iY][iX] : gR->frame->xMin ;
                    gR->frame->yMax = (yReferencing[iY][iX] > gR->frame->yMax)? yReferencing[iY][iX] : gR->frame->yMax ;
                    gR->frame->yMin = (yReferencing[iY][iX] < gR->frame->yMin)? yReferencing[iY][iX] : gR->frame->yMin ;
                }
			}
        }
    }
    
    /* Save max and average samplings */
    gR->params->xAverageSampling += xAverageSampling /= inputTileTool->xDimEA * inputTileTool->yDimEA ;
    gR->params->yAverageSampling += yAverageSampling /= inputTileTool->xDimEA * inputTileTool->yDimEA ;
    gR->params->xMaxSampling = (xMaxSampling > gR->params->xMaxSampling)? xMaxSampling : gR->params->xMaxSampling ;
    gR->params->yMaxSampling = (yMaxSampling > gR->params->yMaxSampling)? yMaxSampling : gR->params->yMaxSampling ;

    /* Save referencing */
    aFloatMatrix = (float **)inputTileTool->tile ;
    inputTileTool->tile = (void **)xReferencing ;
    writeTileToOutputFile(inputTileTool, gR->files->xRef) ;
    inputTileTool->tile = (void **)yReferencing ;
    writeTileToOutputFile(inputTileTool, gR->files->yRef) ;
    if (DEMGrid != NULL) {
        inputTileTool->tile = (void **)externalDEM ;
        writeTileToOutputFile(inputTileTool, gR->files->DEM) ;
    }
   
    inputTileTool->tile = (void **)aFloatMatrix ;
    
    freeMatrixFloat(xReferencing, 0, 0) ;
    freeMatrixFloat(yReferencing, 0, 0) ;
    if (DEMGrid != NULL) {
        freeMatrixFloat(externalDEM, 0, 0) ;
    }
    
	freeVectorDouble(P1, 0) ;
	freeVectorDouble(P2, 0) ;
	freeVectorDouble(onEllipsoidPoint, 0) ;
}


void flatEarthGeoreferencing(geoRef *pGeoRef)
{
    char isFrameInitialized ; 
	int iX, iY, xDim, yDim, iX0, iY0 ;
	int rangeIndex, azimuthIndex ;
//	float *InSARHeight ;
	float *xRef, *yRef ;
	double *onSpherePoint, *onEllipsoidPoint ;
	double longitude, latitude ;
    double *P1, *P2 ;
	geoRefSolving *gRSolving ;
//	progressCounter *aCounter ;
	
	xDim = pGeoRef->params->xDimInputData ;
	yDim = pGeoRef->params->yDimInputData ;
	pGeoRef->files->xRef->xDim = xDim ;
	pGeoRef->files->xRef->yDim = yDim ;
	pGeoRef->files->yRef->xDim = xDim ;
	pGeoRef->files->yRef->yDim = yDim ;
    
    isFrameInitialized = 1 ;
    if (!pGeoRef->frame->xMin && !pGeoRef->frame->xMax && !pGeoRef->frame->yMin && !pGeoRef->frame->yMax) {
        isFrameInitialized = 0 ;
    }
	
	gRSolving = pGeoRef->solving ;
	if(pGeoRef->params->isUTM) {
		pGeoRef->params->UTMZone = initUTMReferencingOnEllipsoid(gRSolving->ellProj) ;
		updateUTMZoneForSLCImage(pGeoRef, pGeoRef->params->UTMZone) ;
	}
	
//	InSARHeight = vectorFloat(0, xDim) ;
	xRef = vectorFloat(0, xDim) ;
	yRef = vectorFloat(0, xDim) ;
	onEllipsoidPoint = vectorDouble(0, 2) ;
    P1 = vectorDouble(0, 1) ;
    P2 = vectorDouble(0, 1) ;
	
//	printf("Flat Earth georeferencing\n") ;
//	aCounter = initProgressCounterWithMinMaxValue(0, yDim - 1) ;
//	fseek(pGeoRef->files->DEM->f, 0, SEEK_SET) ;
	iX0 = pGeoRef->params->x0 ;
	iY0 = pGeoRef->params->y0 ;
	for(iY = 0; iY < yDim; iY++) {
		/* Update state vect and georeferencing for this azimuth line */
		azimuthIndex = (double)(iY0 + iY * pGeoRef->params->yReductionFactor) ;
		/* read a line of InSAR height */
//		fread(InSARHeight, sizeof(float), xDim, pGeoRef->files->DEM->f) ;
		
		for(iX = 0; iX < xDim; iX++) {
			rangeIndex = (double)(iX0 + iX * pGeoRef->params->xReductionFactor) ;
            P2[0] = rangeIndex ;
            P2[1] = azimuthIndex ;
            if (pGeoRef->params->affineTransform != NULL) {
                P1[0] = P2[0] ;
                P1[1] = P2[1] ;
                planeAffineTransformOfPoint(P1, P2, pGeoRef->params->affineTransform) ;
            }
            if(P2[1] != gRSolving->S->azimuthPosition) {
                calcStateVect(gRSolving->S, P2[1], pGeoRef->params->info) ;
                initOnSphereSolving(gRSolving) ;
            }
            
//			onSpherePoint = onSphereSolvingForPoint(P2[0], P2[1], InSARHeight[iX], pGeoRef) ;
			onSpherePoint = onSphereSolvingForPoint(P2[0], P2[1], 0., pGeoRef) ;
			onEllipsoidProjection(onEllipsoidPoint, onSpherePoint, gRSolving) ;
			XYZ2LonLat(&longitude, &latitude, onEllipsoidPoint, gRSolving) ;
			if(pGeoRef->params->isUTM) {
				lonLat2UTMOnEllipsoid(&longitude, &latitude, pGeoRef->params->UTMZone) ;
			}
			xRef[iX] = longitude ;
			yRef[iX] = latitude ;
            
			if(!isFrameInitialized) {
				pGeoRef->frame->xMax = pGeoRef->frame->xMin = longitude ;
				pGeoRef->frame->yMax = pGeoRef->frame->yMin = latitude ;
                isFrameInitialized = 1 ;
			}
			else {
				pGeoRef->frame->xMax = (longitude > pGeoRef->frame->xMax)? longitude : pGeoRef->frame->xMax ;
				pGeoRef->frame->xMin = (longitude < pGeoRef->frame->xMin)? longitude : pGeoRef->frame->xMin ;
				pGeoRef->frame->yMax = (latitude > pGeoRef->frame->yMax)? latitude : pGeoRef->frame->yMax ;
				pGeoRef->frame->yMin = (latitude < pGeoRef->frame->yMin)? latitude : pGeoRef->frame->yMin ;
			}
		}
		fwrite(xRef, sizeof(float), xDim, pGeoRef->files->xRef->f) ;
		fwrite(yRef, sizeof(float), xDim, pGeoRef->files->yRef->f) ;
//		updateProgressCounterForIndex(aCounter, iY) ;
	}
//	updateProgressCounterForIndex(aCounter, iY) ;
	
	
	freeVectorDouble(P1, 0) ;
	freeVectorDouble(P2, 0) ;
	freeVectorDouble(onEllipsoidPoint, 0) ;
//	freeVectorFloat(InSARHeight, 0) ;
	freeVectorFloat(xRef, 0) ;
	freeVectorFloat(yRef, 0) ;
}

