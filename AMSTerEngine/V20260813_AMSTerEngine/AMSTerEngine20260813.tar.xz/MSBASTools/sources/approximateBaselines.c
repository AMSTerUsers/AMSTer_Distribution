
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  approximateBaselines
//
//  Created by Ludivine Libert on 20/08/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#include <stdio.h>
#include "fileAccessLib.h"
#include "vectors.h"
#include "paramLib.h"

void usage(void) ;


int main(int argc, const char * argv[])
{
    
    int i, j ;
    int N ;
    int *delay, *ti ;
    int delayij ;
    int t0 = 0 ;
    double *Bperp, Bperpij ;
    char *initBaselinesPath, *approximateBaselinesFilePath ;
    
    keyValue *setParametersList ;
    
    FILE *f1, *ftriangle ;
    

    if (argc == 1 || argc > 3)
        usage();
    
    if (isArgumentPresent(argc, argv, "help"))
        usage() ;
        
    /* The number of images and the path to the different are read from set parameters file */
    /* The number of images determines the dimension of the triangle table */
    setParametersList = readParameterFileAtPath((char *)argv[1]) ;
    N = getIntValForKeyIn(setParametersList, "Number of images") ;
    initBaselinesPath = initStringWithString(getStringValForKeyIn(setParametersList, "Path to initial baselines")) ;
    approximateBaselinesFilePath = initStringWith2Strings(getDirectoryPathFromPath((char *)argv[1]), "approximateBaselinesTable.txt") ;
    
    
    if (!fileExistsAtPath(initBaselinesPath))
        ase("The file does not exist !\n") ;
    
    /* Reading slave and master dates, baseline values and temporal delays from file in input */
    /* The input file must contain : to ti Bperp delay */
    /* i = 1, ... ,N but in practice the indices of the array will be from 0 to N-1 */
    f1 = fopen(initBaselinesPath, "r") ;
    
    Bperp = vectorDouble(0, N-2) ;
    delay = vectorInt(0, N-2) ;
    ti = vectorInt(0, N-2) ;
    
    
    for (i = 0 ; i < N-1 ; i++)
        fscanf(f1, "%8d\t%8d\t%lf\t%d\n", &t0, &ti[i], &Bperp[i], &delay[i]) ;

    fclose(f1) ;
    
    /* If you add an image to the set, the whole set won't be re-processed.*/
    /* Assuming the added image is the last one considered in the file, */
    /* there is only one line added at the end of the "triangular file" */
    /* Careful ! The number of images must be update to consider the last image */
    if (isArgumentPresent(argc, argv, "-oneImage"))
    {
        ftriangle = fopen(approximateBaselinesFilePath, "a") ;
        fprintf(ftriangle, "%d_%d_%d_%d\t", t0, ti[N-2], (int)Bperp[N-2], delay[N-2]) ;
        
        for (i = 0 ; i < N-2 ; i++)
        {
            Bperpij = Bperp[N-2] - Bperp[i] ;
            delayij = delay[N-2] - delay[i] ;

            fprintf(ftriangle, "%d_%d_%d_%d\t", ti[i], ti[N-2], (int)Bperpij, delayij) ;
        }
        
        fprintf(ftriangle, "\n\n") ;
        
        fclose(ftriangle) ;
    }
    
    else
    {
        ftriangle = fopen(approximateBaselinesFilePath, "w") ;

        for (j = 0 ; j < N-1 ; j++) {
            fprintf(ftriangle, "%d_%d_%d_%d\t", t0, ti[j], (int)Bperp[j], delay[j]) ;
            
            for (i = 0 ; i < j ; i++) {
                /* Bij = B0j - B0i (approximately) */
                Bperpij = Bperp[j] - Bperp[i] ;
                delayij = delay[j] - delay[i] ;
                
                fprintf(ftriangle, "%d_%d_%d_%d\t", ti[i], ti[j], (int)Bperpij, delayij) ;
            }
            fprintf(ftriangle, "\n\n") ;
        }
        
        fclose(ftriangle) ;
    }

    freeVectorDouble(Bperp, 0) ;
    freeVectorInt(delay, 0) ;
    freeVectorInt(ti, 0) ;
    free(setParametersList) ;
    
    return 0;
}


void usage(void)
{
    printf("\nUsage : \n\n\t approximateBaselines /pathTo/setParametersFile.txt [-oneImage] \n\n") ;
    printf("\tThe routine will read the \"initBaselines.txt\" file containing the perpendicular baseline and delay values for each pair of acquisitions at times (t0,ti) (i = 1,..., numberOfImages). ") ;
    printf("The perpendicular baselines and delays for pairs at times (ti,tj) will be approximated as Bij=B0j-B0i and recorded in a file \"approximateBaselinesTable.txt\".\n") ;
    printf("In this file, informations are given in a triangle table according the \"master_slave_Bperp_delay\" format.\n\n") ;
    printf("\tIf adding the keyword \"-oneImage\", then you can add the last image considered in the \"initBaselines\" text file without reprocessing the all dataset. In this case, information about the pairs formed with this image are added in a line at the end of the file \"approximateBaselinesTable.txt\".\n ") ;
    
    exit(0) ;
}
