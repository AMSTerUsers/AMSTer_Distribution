
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  fillGapsInImage
//
//  Created by Ludivine Libert on 21/03/17.
//  Copyright © 2017 Ludivine Libert. All rights reserved.
//

#include <stdio.h>
#include "interpolationLib.h" 

void usage() ;

/* Given an input image - typically a deformation map - the routine attempts to fill the pixels with NaN using basic interpolation */
/* Three conditions are explored based on the availability of data in the nearest neighbours. In the three cases, the interpolation */
/* comes down to an averaging of the values at the nearest neighbours. */

int main(int argc, const char * argv[]) {
    
    int dimx, dimy ;
    float **defo, **interpolatedDefo ;
    char excludingValueIsZero ;
    char *filePath, *outputFilePath ;
    rawFileDescriptor *file, *outputFile ;
    time_t startTime, endTime ;
    
    if (isArgumentPresent(argc, argv, "-h") || isArgumentPresent(argc, argv, "help"))
        usage() ;
    
    if (argc < 4 || argc > 5)
        usage() ;
    
    /* If argument "-zero" is present, then zero is considered as the excluding value instead of NaN */
    if (isArgumentPresent(argc, argv, "-zero"))
        excludingValueIsZero= 1 ;
    else
        excludingValueIsZero = 0 ;
    
    /* Image dimensions */
    dimx = atoi(argv[2]) ;
    dimy = atoi(argv[3]) ;
    
    /* Paths */
    filePath = (char *) argv[1] ;
    outputFilePath = initStringWith2Strings(filePath, ".interpolated") ;
    
    time(&startTime) ;
    
    /* Opening files */
    if((file = openRawFileForReadingAtPath(filePath)) == NULL)
        ase("Failed to open the input file.\n") ;
    
    if((outputFile = openRawFileForWritingAtPath(outputFilePath)) == NULL)
        ase("Failed to open the output file.\n") ;
    
    /* Matrices declaration*/
    defo = matrixFloat(0, dimy-1, 0, dimx-1) ;
    interpolatedDefo = matrixFloat(0, dimy-1, 0, dimx-1) ;
    
    /* Reading the image to be interpolated */
    if((fread(defo[0], sizeof(float), dimx * dimy, file->f)) != dimx * dimy)
        ase("Failed to read the image.\n") ;
    
    if (excludingValueIsZero)
        fillGapsWithInterpolationInImageExcludingZeros(defo, interpolatedDefo, dimx, dimy) ;
    else
        fillGapsWithInterpolationInImage(defo, interpolatedDefo, dimx, dimy) ;
    
    fwrite(interpolatedDefo[0], sizeof(float), dimx * dimy, outputFile->f) ;
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    
    freeMatrixFloat(interpolatedDefo, 0, 0) ;
    freeMatrixFloat(defo, 0, 0) ;
    freeRawFileDescriptor(file) ;
    freeRawFileDescriptor(outputFile) ;
    free(outputFilePath) ;
    
    return 0;
}


void usage()
{
    printf("\n\t fillGapsInImage\t\t pathTo/image \t xDim \t yDim \t [-zero]\n\n") ;
    printf("The routine attempts to assign a value to the NaN/zeros pixels in the input image using basic interpolation. ") ;
    printf("Three configurations are considered based on the defined nearest neighbours. ") ;
    printf("If the pixel verifies one of the configurations, then the pixel's value is interpolated.") ;
    printf("In the three cases, the interpolation comes down to an averaging of the values at the nearest neighbours.\n\n") ;
    exit (0) ;
}
