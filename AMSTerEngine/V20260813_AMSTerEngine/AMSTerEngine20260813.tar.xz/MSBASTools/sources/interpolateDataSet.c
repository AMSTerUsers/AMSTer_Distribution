
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  interpolateDataSet
//
//  Created by Ludivine Libert on 21/03/17.
//  Copyright © 2017 Ludivine Libert. All rights reserved.
//
// This routine is meant to fill gaps in images using interpolation. The considered interpolation scheme is a bilinear/linear interpolation based on nearest neighbours.
// This routine is meant the intersection of the pixels defined in all images of a stack. Since we don't want to create too much information,
// the pixel is interpolated only if it is defined in a given portion of the stack.
// It considers different configurations of the neighbours to interpolate a given pixel : in a first time, the four directly neighbouring pixels (cross),
// second the four edges of the square with the pixel at the center and then the two direct neighbours along one direction or another (linear interpolation).
// If the neighbours of a given case are not all defined, then the next case is considered. For the two first cases, we use bilinear interpolation.

#include <stdio.h>
#include "interpolationLib.h"
#include "matrixPile.h"

void usage() ;
void createInterpolateDataSetParametersFileAtPath(char *filePath) ;
void interpolateDataSet(keyValue *paramsList, int numberOfImages, char **imagesInDirectory) ;
void interpolatePixelInImage(float **image, float **interpolatedImage, int i, int j) ;
void interpolatePixelInImageExcludingZeros(float **image, float **interpolatedImage, int i, int j) ;
void interpolatePixelAlongY(float **image, float **interpolatedImage, int i, int j) ;
void interpolatePixelAlongYExcludingZeros(float **image, float **interpolatedImage, int i, int j) ;
void interpolatePixelAlongX(float **image, float **interpolatedImage, int i, int j) ;
void interpolatePixelAlongXExcludingZeros(float **image, float **interpolatedImage, int i, int j) ;



int main(int argc, const char * argv[]) {

    int i, j ;
    int numberOfEntries, numberOfImages ;
    char *path, *directoryPath, *extension ;
    char **directoryContent, **imagesInDirectory ;
    keyValue *paramsList ;
    time_t startTime, endTime ;
    
    
    if (argc < 2 || argc > 3)
        usage() ;
    
    path = (char *)argv[1] ;
    
    /* Create a parameter file */
    if (isArgumentPresent(argc, argv, "-create"))
        createInterpolateDataSetParametersFileAtPath(path) ;
    
    time(&startTime) ;
    
    paramsList = readParameterFileAtPath(path) ;
    
    /* Assigning parameters values */
    directoryPath = getStringValForKeyIn(paramsList, "Directory of images to interpolate") ;
    extension = getStringValForKeyIn(paramsList, "Images extensions") ;


    /* Get directory's entries */
    numberOfEntries = getNumberOfDirectoryEntriesAtPath(directoryPath) ;
    directoryContent = getDirectoryContentAtPath(directoryPath, &numberOfEntries) ;
    numberOfImages = j = 0 ;
    
    for (i = 0 ; i < numberOfEntries; i++)
        if(fileExistsAtPath(initStringWith3Strings(directoryPath, "/", directoryContent[i])))
            if (!strcmp(getFileExtensionFromPath(directoryContent[i]), extension))
                numberOfImages ++ ;

    /* Keep only images in the directory's entries */
    /* This is done based on the indicated extension */
    printf("\n\nImages in the directory : \n\n") ;
    imagesInDirectory = (char **)calloc(numberOfImages, sizeof(char *)) ;
    for (i = 0 ; i < numberOfEntries; i++)
        if(fileExistsAtPath(initStringWith3Strings(directoryPath, "/", directoryContent[i])))
            if (!strcmp(getFileExtensionFromPath(directoryContent[i]), extension))
            {
                imagesInDirectory[j] = directoryContent[i] ;
                printf("%s\n", imagesInDirectory[j]) ;
                j++ ;
            }
    
    printf("\n\n");

    /* Create a directory for output interpolated products */
    path = initStringWith3Strings(directoryPath, "/", "interpolated") ;
    if(mkdir((const char *) path, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH))
    {
        if(errno != EEXIST) {
            sprintf(ertex, "Failed to create directory at path %s\n", path) ;
            ase(ertex) ;
        }
    }
    
    interpolateDataSet(paramsList, numberOfImages, imagesInDirectory) ;
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    
    freeKeyValueList(paramsList) ;
    free(path) ;
    free(directoryContent) ;
    free(imagesInDirectory) ;
    
    return 0;
}



void usage()
{
    printf("\n\n\t interpolateDataSet \t\t pathTo/parametersFile.txt \t [-create]\n\n") ;
    printf("This routine is meant to improve the spatial coverage of a stack of images. In MSBAS, if a pixel is not defined in only one image of the stack, ") ;
    printf("then this pixel is rejected by the MSBAS routine. If information on this pixel can be recovered using interpolation, then the spatial coverage will be improved.\n") ;
    printf("This routine considers images identified by an given extension in a given directory. ") ;
    printf("Pixels are considered for interpolation only if they are defined in a given portion of the stack. ") ;
    printf("In this case, the routine searches for the nearest neighbours in order to apply bilinear or linear interpolation, if possible. \n") ;
    printf("A parameters file is created at the given path using the keyword \"-create\". ") ;
    printf("Let us stress that all input images must be projected on a common grid and have the same dimensions. ") ;
    printf("Interpolated images are saved in a new \"interpolated\" subdirectory.\n") ;
    printf("Default excluding value is NaN, but zeros can also be supported if indicated in the parameters file.\n\n") ;
    exit(0) ;
}



void createInterpolateDataSetParametersFileAtPath(char *filePath)
{
    keyValue *parameterList ;
    
    parameterList = allocAKeyValuePair() ;
    setStringValForKeyIn(parameterList, "Interpolate Data Set parameters file", "") ;
    setStringValForKeyIn(parameterList, "************************************", "") ;

    setStringValForKeyIn(parameterList, "pathTo/directory", "Directory of images to interpolate") ;
    setStringValForKeyIn(parameterList, "rev", "Images extensions [without .]") ;
    setIntValForKeyIn(parameterList, 0, "xDim") ;
    setIntValForKeyIn(parameterList, 0, "yDim") ;
    setDoubleValForKeyIn(parameterList, 0, "Fraction of images with defined value of the pixel [%]") ;
    setStringValForKeyIn(parameterList, "NaN", "Excluding value [NaN/zero]") ;

    writeParameterFileAtPath(parameterList, filePath) ;
}


void interpolateDataSet(keyValue *paramsList, int numberOfImages, char **imagesInDirectory)
{
    int i, j, k, l ;
    int xdim, ydim ;
    int numberOfLinesPerBlock, count ;
    char excludingValueIsZero ;
    long seekValue ;
    long blockSize, numberOfBlocks, numberOfLinesToProcess ;
    float ***images, ***interpolatedImages ;
    double definedPercent ;
    char *path, *directoryPath ;
    rawFileDescriptor **imagesFiles, **interpolatedFiles ;
    div_t qr ;
    
    genFloatNaN() ;

    /* Definition of parameters */
    
    directoryPath = getStringValForKeyIn(paramsList, "Directory of images to interpolate") ;
    xdim = getIntValForKeyIn(paramsList, "xDim") ;
    ydim = getIntValForKeyIn(paramsList, "yDim") ;
    definedPercent = getDoubleValForKeyIn(paramsList, "Fraction of images with defined value") ;
    
    /* Default excluding value is NaN, but zero can also be taken into account */
    if (!strcmp(getStringValForKeyIn(paramsList,"Excluding value"), "zero"))
        excludingValueIsZero = 1 ;
    else
        excludingValueIsZero = 0 ;

    /* Images will be read per block of dimensions y numberOfLinesPerBlock * ydim */
    /* We limit pile of data to 64Mb of memory */
    blockSize = 64 * 1024 * 1024 / numberOfImages ;
    numberOfLinesPerBlock = (int)ldiv(blockSize, xdim * sizeof(float)).quot ;
    if(numberOfLinesPerBlock <3)
        ase("Impossible to treat all images in one time") ;
    
    /* If an image fits in a single block, consider only the image number of lines */
    numberOfLinesPerBlock = (numberOfLinesPerBlock > ydim) ? ydim : numberOfLinesPerBlock ;

    /* Compute number of blocks to be read, including the last one that can be incomplete */
    /* Each block must overlap the previous one on the last two lines */
    qr = div(ydim - 2, numberOfLinesPerBlock - 2) ;
    numberOfBlocks = (qr.rem)? qr.quot + 1 : qr.quot ;
    
    /* Compute the corresponding block size */
    blockSize = xdim * sizeof(float) * numberOfLinesPerBlock ;
    
    /* Pile of images declaration */
    images = matrixPileFloat(0, numberOfImages - 1, 0, numberOfLinesPerBlock - 1, 0, xdim - 1) ;
    interpolatedImages = matrixPileFloat(0, numberOfImages - 1, 0, numberOfLinesPerBlock - 1, 0, xdim - 1) ;
    
    /* Opening images files */
    imagesFiles = (rawFileDescriptor **)calloc(numberOfImages, sizeof(rawFileDescriptor *)) ;
    interpolatedFiles = (rawFileDescriptor **)calloc(numberOfImages, sizeof(rawFileDescriptor *)) ;

    printf("Output files :\n\n") ;
    
    for (l = 0 ; l < numberOfImages ; l++)
    {
        /* input files */
        path = initStringWith3Strings(directoryPath, "/", imagesInDirectory[l]) ;
        if((imagesFiles[l] = openRawFileForReadingAtPath(path)) == NULL)
            ase("Failed top open the images files for reading.\n") ;
        free(path) ;
        
        /* output files */
        path = initStringWith4Strings(directoryPath, "/interpolated/", imagesInDirectory[l], ".interpolated");
        printf("%s\n", path) ;
        if((interpolatedFiles[l] = openRawFileForWritingAtPath(path)) == NULL)
            ase("Failed to open output files for writing. \n") ;
        free(path) ;
    }
    
    
    /* Zero is the excluding value in this case */
    if (excludingValueIsZero)
    {
        /* Reading images */
        for (k = 0 ; k < numberOfBlocks ; k++)
        {
            seekValue = (long) (k * (numberOfLinesPerBlock - 2)) * xdim * sizeof(float) ;
            numberOfLinesToProcess = (k < numberOfBlocks - 1) ? numberOfLinesPerBlock : ydim - (numberOfBlocks - 1) * (numberOfLinesPerBlock - 2) ;
            
            for (l = 0 ; l < numberOfImages ; l++)
            {
                fseek(imagesFiles[l]->f, seekValue, SEEK_SET) ;
                if(fread(images[l][0], sizeof(float), xdim * numberOfLinesToProcess, imagesFiles[l]->f) != xdim * numberOfLinesToProcess)
                    ase("Failed to read images files. \n") ;
            }
            
            for (j = 1 ; j < xdim - 1 ; j++)
            {
                for (i = 1 ; i < numberOfLinesToProcess - 1 ; i++)
                {
                    count = 0 ;
                    for (l = 0 ; l < numberOfImages ; l++)
                    {
                        /* initialize the values of the interpolated images */
                        interpolatedImages[l][i][j] = images[l][i][j] ;
                        if (!images[l][i][j])
                            count ++ ;
                    }
                    /* If the pixel has a value in n% of the images or more, then we interpolate */
                    /* It is similar to : if the pixel has a zero value in (100 - n)% of the images or less, then we interpolate */
                    if (count <= (numberOfImages * (100 - definedPercent) / 100))
                    {
                        for (l = 0 ; l < numberOfImages ; l++)
                            if (!images[l][i][j])
                                interpolatePixelInImageExcludingZeros(images[l], interpolatedImages[l], i, j) ;
                    }
                }
            }
            
            /* Edges in the y-direction */
            /* Linear interpolation along y */
            for (i = 1 ; i < numberOfLinesToProcess - 1 ; i++)
            {
                /* Left edge */
                count = 0 ;
                for (l = 0 ; l < numberOfImages ; l++)
                {
                    /* initialize the values of the interpolated images */
                    interpolatedImages[l][i][0] = images[l][i][0] ;
                    if (!images[l][i][0])
                        count ++ ;
                }
                
                if (count <= (numberOfImages * (100 - definedPercent) / 100))
                {
                    for (l = 0 ; l < numberOfImages ; l++)
                        if (!images[l][i][0])
                            interpolatePixelAlongYExcludingZeros(images[l], interpolatedImages[l], i, 0) ;
                }
                
                /* Right edge */
                count = 0 ;
                for (l = 0 ; l < numberOfImages ; l++)
                {
                    /* initialize the values of the interpolated images */
                    interpolatedImages[l][i][xdim-1] = images[l][i][xdim-1] ;
                    if (!images[l][i][xdim-1])
                        count ++ ;
                }
                
                if (count <= (numberOfImages * (100 - definedPercent) / 100))
                {
                    for (l = 0 ; l < numberOfImages ; l++)
                        if (!images[l][i][xdim-1])
                            interpolatePixelAlongYExcludingZeros(images[l], interpolatedImages[l], i, xdim-1) ;
                }
            }
            
            /* In the first block, we have to consider to upper edge an corners */
            if (!k)
            {
                /* Upper right and left corners */
                for (l = 0 ; l < numberOfImages ; l++)
                {
                    interpolatedImages[l][0][0] = images[l][0][0] ;
                    interpolatedImages[l][0][xdim-1] = images[l][0][xdim-1] ;
                }
                /* Upper edge*/
                for (j = 1 ; j < xdim - 1 ; j++)
                {
                    count = 0 ;
                    for (l = 0 ; l < numberOfImages ; l++)
                    {
                        /* initialize the values of the interpolated images */
                        interpolatedImages[l][0][j] = images[l][0][j] ;
                        if (!images[l][0][j])
                            count ++ ;
                    }
                    
                    if (count <= (numberOfImages * (100 - definedPercent) / 100))
                    {
                        for (l = 0 ; l < numberOfImages ; l++)
                            if (!images[l][0][j])
                                interpolatePixelAlongXExcludingZeros(images[l], interpolatedImages[l], 0, j) ;
                    }
                }
            }
            
            /* In the last block, we have to consider to lower edge and corners */
            if (k == numberOfBlocks - 1)
            {
                /* Lower right and left corners */
                for (l = 0 ; l < numberOfImages ; l++)
                {
                    interpolatedImages[l][numberOfLinesToProcess-1][0] = images[l][numberOfLinesToProcess-1][0] ;
                    interpolatedImages[l][numberOfLinesToProcess-1][xdim-1] = images[l][numberOfLinesToProcess-1][xdim-1] ;
                }
                /* Upper edge*/
                for (j = 1 ; j < xdim - 1 ; j++)
                {
                    count = 0 ;
                    for (l = 0 ; l < numberOfImages ; l++)
                    {
                        /* initialize the values of the interpolated images */
                        interpolatedImages[l][numberOfLinesToProcess-1][j] = images[l][numberOfLinesToProcess-1][j] ;
                        if (!images[l][numberOfLinesToProcess-1][j])
                            count ++ ;
                    }
                    
                    if (count <= (numberOfImages * (100 - definedPercent) / 100))
                    {
                        for (l = 0 ; l < numberOfImages ; l++)
                            if (!images[l][numberOfLinesToProcess-1][j])
                                interpolatePixelAlongXExcludingZeros(images[l], interpolatedImages[l], (int)numberOfLinesToProcess-1, j) ;
                    }
                }
            }
            
            
            /* Save the interpolated images */
            for (l = 0 ; l < numberOfImages ; l++)
            {
                fseek(interpolatedFiles[l]->f, seekValue, SEEK_SET) ;
                fwrite(interpolatedImages[l][0], sizeof(float), (numberOfLinesToProcess - 2) * xdim, interpolatedFiles[l]->f) ;
                for (j = 0 ; j < xdim ; j ++)
                    interpolatedImages[l][0][j] = interpolatedImages[l][numberOfLinesToProcess-2][j] ;
                
                if (k == numberOfBlocks - 1)
                    fwrite(interpolatedImages[l][numberOfLinesToProcess - 2], sizeof(float), 2 * xdim, interpolatedFiles[l]->f) ;
            }
            seekValue = (long)(numberOfLinesToProcess - 2) * xdim * sizeof(float) ;
        }

    }
    
    
    
    /* NaN is the excluding value in this case */
    else
    {
    
        /* Reading images */
        for (k = 0 ; k < numberOfBlocks ; k++)
        {
            seekValue = (long) (k * (numberOfLinesPerBlock - 2)) * xdim * sizeof(float) ;
            numberOfLinesToProcess = (k < numberOfBlocks - 1) ? numberOfLinesPerBlock : ydim - (numberOfBlocks - 1) * (numberOfLinesPerBlock - 2) ;
            
            for (l = 0 ; l < numberOfImages ; l++)
            {
                fseek(imagesFiles[l]->f, seekValue, SEEK_SET) ;
                if(fread(images[l][0], sizeof(float), xdim * numberOfLinesToProcess, imagesFiles[l]->f) != xdim * numberOfLinesToProcess)
                    ase("Failed to read images files. \n") ;
            }
            
            for (j = 1 ; j < xdim - 1 ; j++)
            {
                for (i = 1 ; i < numberOfLinesToProcess - 1 ; i++)
                {
                    count = 0 ;
                    for (l = 0 ; l < numberOfImages ; l++)
                    {
                        /* initialize the values of the interpolated images */
                        interpolatedImages[l][i][j] = images[l][i][j] ;
                        if (isnan(images[l][i][j]))
                            count ++ ;
                    }
                    /* If the pixel has a value in n% of the images or more, then we interpolate */
                    /* It is similar to : if the pixel has a NaN value in (100 - n)% of the images or less, then we interpolate */
                    if (count <= (numberOfImages * (100 - definedPercent) / 100))
                    {
                        for (l = 0 ; l < numberOfImages ; l++)
                            if (isnan(images[l][i][j]))
                                interpolatePixelInImage(images[l], interpolatedImages[l], i, j) ;
                    }
                }
            }
            
            /* Edges in the y-direction */
            /* Linear interpolation along y */
            for (i = 1 ; i < numberOfLinesToProcess - 1 ; i++)
            {
                /* Left edge */
                count = 0 ;
                for (l = 0 ; l < numberOfImages ; l++)
                {
                    /* initialize the values of the interpolated images */
                    interpolatedImages[l][i][0] = images[l][i][0] ;
                    if (isnan(images[l][i][0]))
                        count ++ ;
                }
                
                if (count <= (numberOfImages * (100 - definedPercent) / 100))
                {
                    for (l = 0 ; l < numberOfImages ; l++)
                        if (isnan(images[l][i][0]))
                            interpolatePixelAlongY(images[l], interpolatedImages[l], i, 0) ;
                }
                
                /* Right edge */
                count = 0 ;
                for (l = 0 ; l < numberOfImages ; l++)
                {
                    /* initialize the values of the interpolated images */
                    interpolatedImages[l][i][xdim-1] = images[l][i][xdim-1] ;
                    if (isnan(images[l][i][xdim-1]))
                        count ++ ;
                }
                
                if (count <= (numberOfImages * (100 - definedPercent) / 100))
                {
                    for (l = 0 ; l < numberOfImages ; l++)
                        if (isnan(images[l][i][xdim-1]))
                            interpolatePixelAlongY(images[l], interpolatedImages[l], i, xdim-1) ;
                }
            }
            
            /* In the first block, we have to consider to upper edge an corners */
            if (!k)
            {
                /* Upper right and left corners */
                for (l = 0 ; l < numberOfImages ; l++)
                {
                    interpolatedImages[l][0][0] = images[l][0][0] ;
                    interpolatedImages[l][0][xdim-1] = images[l][0][xdim-1] ;
                }
                /* Upper edge*/
                for (j = 1 ; j < xdim - 1 ; j++)
                {
                    count = 0 ;
                    for (l = 0 ; l < numberOfImages ; l++)
                    {
                        /* initialize the values of the interpolated images */
                        interpolatedImages[l][0][j] = images[l][0][j] ;
                        if (isnan(images[l][0][j]))
                            count ++ ;
                    }
                    
                    if (count <= (numberOfImages * (100 - definedPercent) / 100))
                    {
                        for (l = 0 ; l < numberOfImages ; l++)
                            if (isnan(images[l][0][j]))
                                interpolatePixelAlongX(images[l], interpolatedImages[l], 0, j) ;
                    }
                }
            }
            
            /* In the last block, we have to consider to lower edge and corners */
            if (k == numberOfBlocks - 1)
            {
                /* Lower right and left corners */
                for (l = 0 ; l < numberOfImages ; l++)
                {
                    interpolatedImages[l][numberOfLinesToProcess-1][0] = images[l][numberOfLinesToProcess-1][0] ;
                    interpolatedImages[l][numberOfLinesToProcess-1][xdim-1] = images[l][numberOfLinesToProcess-1][xdim-1] ;
                }
                /* Upper edge*/
                for (j = 1 ; j < xdim - 1 ; j++)
                {
                    count = 0 ;
                    for (l = 0 ; l < numberOfImages ; l++)
                    {
                        /* initialize the values of the interpolated images */
                        interpolatedImages[l][numberOfLinesToProcess-1][j] = images[l][numberOfLinesToProcess-1][j] ;
                        if (isnan(images[l][numberOfLinesToProcess-1][j]))
                            count ++ ;
                    }
                    
                    if (count <= (numberOfImages * (100 - definedPercent) / 100))
                    {
                        for (l = 0 ; l < numberOfImages ; l++)
                            if (isnan(images[l][numberOfLinesToProcess-1][j]))
                                interpolatePixelAlongX(images[l], interpolatedImages[l], (int)numberOfLinesToProcess-1, j) ;
                    }
                }
            }
            
            
            /* Save the interpolated images */
            for (l = 0 ; l < numberOfImages ; l++)
            {
                fseek(interpolatedFiles[l]->f, seekValue, SEEK_SET) ;
                fwrite(interpolatedImages[l][0], sizeof(float), (numberOfLinesToProcess - 2) * xdim, interpolatedFiles[l]->f) ;
                for (j = 0 ; j < xdim ; j ++)
                    interpolatedImages[l][0][j] = interpolatedImages[l][numberOfLinesToProcess-2][j] ;
                
                if (k == numberOfBlocks - 1)
                    fwrite(interpolatedImages[l][numberOfLinesToProcess - 2], sizeof(float), 2 * xdim, interpolatedFiles[l]->f) ;
            }
            seekValue = (long)(numberOfLinesToProcess - 2) * xdim * sizeof(float) ;
        }
    }
    
    for (l = 0 ; l < numberOfImages ; l++)
    {
        freeRawFileDescriptor(imagesFiles[l]) ;
        freeRawFileDescriptor(interpolatedFiles[l]) ;
    }
    
    free(imagesFiles) ;
    freeMatrixPileFloat(images, 0, 0, 0) ;
    freeMatrixPileFloat(interpolatedImages, 0, 0, 0) ;
    
}



void interpolatePixelInImage(float **image, float **interpolatedImage, int i, int j)
{
    genFloatNaN() ;
    
    /* Case 1: if the 4 direct neighbours along x and y are defined, the pixel is assigned with the mean value of the four */
    if (!isnan(image[i-1][j]) && !isnan(image[i+1][j]) && !isnan(image[i][j-1]) && !isnan(image[i][j+1]))
        interpolatedImage[i][j] = (image[i-1][j] + image[i+1][j] + image[i][j-1] + image[i][j+1]) / 4. ;
    
    /* Case 2 : if at least one of the direct neighbours is not defined, then we look after the second nearest neighbours */
    /* These are the summit of a square with the pixel at the center. We use a bilinear interpolation in this case */
    /* In this particular case, the bilinear interpolation is just an average of the image values at the four points */
    else if (!isnan(image[i-1][j-1]) && !isnan(image[i-1][j+1]) && !isnan(image[i+1][j-1]) && !isnan(image[i+1][j+1]))
        interpolatedImage[i][j] = (image[i-1][j-1] + image[i-1][j+1] + image[i+1][j-1] + image[i+1][j+1]) / 4. ;
    
    /* Case 3 : Finally, if none of the previous case is adequate, then we look for two direct neighbours on the same line */
    /* i.e. along x or along y, and we apply a linear interpolation along this dimensions. It is actually the mean of both values */

    /* Linear interpolation along y */
    else if (!isnan(image[i-1][j]) && !isnan(image[i+1][j]))
        interpolatedImage[i][j] = (image[i-1][j] + image[i+1][j]) / 2. ;

    /* Linear interpolation along x */
    else if (!isnan(image[i][j-1]) && !isnan(image[i][j+1]))
        interpolatedImage[i][j] = (image[i][j-1] + image[i][j+1]) / 2. ;

    /* Finally, if none of these configurations can be applied, the pixels is not interpolated */
    else
        interpolatedImage[i][j] = floatNaN ;

}

void interpolatePixelInImageExcludingZeros(float **image, float **interpolatedImage, int i, int j)
{
    genFloatNaN() ;
    
    /* Case 1: if the 4 direct neighbours along x and y are defined, the pixel is assigned with the mean value of the four */
    if (image[i-1][j] && image[i+1][j] && image[i][j-1] && image[i][j+1])
        interpolatedImage[i][j] = (image[i-1][j] + image[i+1][j] + image[i][j-1] + image[i][j+1]) / 4. ;
    
    /* Case 2 : if at least one of the direct neighbours is not defined, then we look after the second nearest neighbours */
    /* These are the summit of a square with the pixel at the center. We use a bilinear interpolation in this case */
    /* In this particular case, the bilinear interpolation is just an average of the image values at the four points */
    else if (image[i-1][j-1] && image[i-1][j+1] && image[i+1][j-1] && image[i+1][j+1])
        interpolatedImage[i][j] = (image[i-1][j-1] + image[i-1][j+1] + image[i+1][j-1] + image[i+1][j+1]) / 4. ;
    
    /* Case 3 : Finally, if none of the previous case is adequate, then we look for two direct neighbours on the same line */
    /* i.e. along x or along y, and we apply a linear interpolation along this dimensions. It is actually the mean of both values */
    
    /* Linear interpolation along y */
    else if (image[i-1][j] && image[i+1][j])
        interpolatedImage[i][j] = (image[i-1][j] + image[i+1][j]) / 2. ;
    
    /* Linear interpolation along x */
    else if (image[i][j-1] && image[i][j+1])
        interpolatedImage[i][j] = (image[i][j-1] + image[i][j+1]) / 2. ;
    
    /* Finally, if none of these configurations can be applied, the pixels is not interpolated */
    else
        interpolatedImage[i][j] = 0. ;
    
}

void interpolatePixelAlongY(float **image, float **interpolatedImage, int i, int j)
{
    genFloatNaN() ;
    
    if (!isnan(image[i-1][j]) && !isnan(image[i+1][j]))
        interpolatedImage[i][j] = (image[i-1][j] + image[i+1][j]) / 2. ;

    else
        interpolatedImage[i][j] = floatNaN ;
}


void interpolatePixelAlongYExcludingZeros(float **image, float **interpolatedImage, int i, int j)
{
    genFloatNaN() ;
    
    if (image[i-1][j] && image[i+1][j])
        interpolatedImage[i][j] = (image[i-1][j] + image[i+1][j]) / 2. ;
    
    else
        interpolatedImage[i][j] = 0. ;
}



void interpolatePixelAlongX(float **image, float **interpolatedImage, int i, int j)
{
    genFloatNaN() ;
    
    if (!isnan(image[i][j-1]) && !isnan(image[i][j+1]))
        interpolatedImage[i][j] = (image[i][j-1] + image[i][j+1]) / 2. ;
    
    else
        interpolatedImage[i][j] = floatNaN ;
}


void interpolatePixelAlongXExcludingZeros(float **image, float **interpolatedImage, int i, int j)
{
    genFloatNaN() ;
    
    if (image[i][j-1] && image[i][j+1])
        interpolatedImage[i][j] = (image[i][j-1] + image[i][j+1]) / 2. ;
    
    else
        interpolatedImage[i][j] = 0. ;
}


