
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  globalMaster
//
//  Created by Ludivine Libert on 28/08/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#include <stdio.h>
#include "pourtous.h"
#include "paramLib.h"
#include "interferometricPairsforMSBAS.h"


void usage() ;
int minBaseline(double *baselines, int dim) ;


int main(int argc, const char * argv[]) {
   
    int i, j, N ;
    int minIndex, numberOfEntries, numberOfImages ;
    double Bperpij ;
    double *averageBaselines ;
    char *pathToTriangleFile, *setPath ;
    char *setParametersPath, *globalMasterPath ;
    char **directoryContent, **imagesContent ;
    
    keyValue *setParamsList ;
    setParameters *setParams ;
    
    FILE *ftriangle ;
    time_t startTime, endTime ;

    
    if (argc == 1 || argc > 2)
        usage() ;
    
    if (isArgumentPresent(argc, argv, "-help"))
        usage() ;
    
    
    time(&startTime) ;
    
    pathToTriangleFile = (char *)argv[1] ;
    
    /* Reading set parameters file */
    setPath = initStringWithString(getDirectoryPathFromPath(pathToTriangleFile)) ;
    setParametersPath = initStringWith2Strings(setPath, "setParametersFile.txt") ;
    setParamsList = readParameterFileAtPath(setParametersPath) ;
    setParams = allocAndInitSetParametersStructure(setParamsList) ;
    N = getIntValForKeyIn(setParamsList, "Number of images") ;
    
    /* What appears in the console */
    printf("\nAverage baseline computation...\n\n") ;
    
    /* Allocation and initialization of the average baselines vector */
    averageBaselines = vectorDouble(0, N-1) ;
    for (i = 0 ; i < N ; i++)
        averageBaselines[i] = 0. ;
    
    /* Open triangle table */
    ftriangle = fopen(pathToTriangleFile, "r") ;
    fseek(ftriangle, 0, SEEK_SET) ;
    
    /* Reading baselines for each pair and computation of average baselines */
    for (i = 1 ; i < N ; i++)
    {
        for (j = 0 ; j < i ; j++ )
        {
            fscanf(ftriangle, "%*8d_%*8d_%lf_%*d\t", &Bperpij) ;
            averageBaselines[i] += Bperpij ;
            averageBaselines[j] += Bperpij ;
        }
        
        fscanf(ftriangle, "\n\n") ;
    }
    
    /* Close triangle table */
    fclose(ftriangle) ;
    
    
    for (i = 0 ; i < N ; i++) {
        averageBaselines[i] /= N-1 ;
    }
    
    /* And find the corresponding image */
    numberOfEntries = getNumberOfDirectoryEntriesAtPath(setPath) ;
    directoryContent = getDirectoryContentAtPath(setPath, &numberOfEntries) ;
    numberOfImages = 0 ;
    imagesContent = (char **)malloc(N*sizeof(char*)) ;
    
    for (i = 0 ; i < numberOfEntries ; i++)
    {
        if(strstr(directoryContent[i], ".csl") != NULL)
        {
            imagesContent[numberOfImages] = initStringWithString(directoryContent[i]) ;
            numberOfImages ++ ;
        }
    }
    
    for (i = 0 ; i < N ; i++) {
        printf("%s :\t %lf m\n", imagesContent[i], averageBaselines[i]) ;
    }
    
    
  //  if (numberOfImages != N)
  //      ase("Problem with the number of images !") ;
    
    
    /* What appears in the console */
    printf("\nSearch for the global master...\n") ;
    
    /* Search for the minimum average baseline */
    minIndex = minBaseline(averageBaselines, N) ;
    
    /* determine global master path and save it in the set parameters file */
    globalMasterPath = initStringWith2Strings(setPath, imagesContent[minIndex]) ;
    saveSetParametersFileAtPath(setParametersPath, globalMasterPath, setParams) ;
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    
    freeVectorDouble(averageBaselines, 0) ;
    freeKeyValueList(setParamsList) ;
    free(setParams) ;
    free(imagesContent) ;
    
    return 0;
}


void usage()
{
    printf("\nUsage:\n\n\t globalMaster /pathTo/approximateBaselinesTable.txt\n\n") ;
    printf("The global master image for coregistration is determined as the one with the smaller average baseline. For a given image, the average baseline is the sum of baselines with every other images of the set, divided by the number of baselines.\n\n") ;
    exit(0) ;
}



int minBaseline(double *baselines, int dim)
{
    int minIndex, i ;
    
    minIndex = 0 ;
    
    for (i = 1 ; i < dim ; i++)
    {
        if (fabs(baselines[i]) < fabs(baselines[minIndex]))
            minIndex = i ;
    }
    
    return minIndex ;
}
