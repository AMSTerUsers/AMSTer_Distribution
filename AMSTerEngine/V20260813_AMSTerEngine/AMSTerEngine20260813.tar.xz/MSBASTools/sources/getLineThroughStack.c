
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  getLineThroughStack
//
//  Created by Dominique Derauw on 26/06/2018.

//
//  Modified 30/07/2026 by Quentin Glaude & Nicolas d'Oreye
//                        (Geo)TIFF layers are now handled in addition to ENVI raw files.
//                        MSBAS (Geo)TIFF layers are grouped by component, one time line
//                        being written per component. Layers are always ordered
//                        chronologically.
//  Modified 31/07/2026 by Quentin Glaude & Nicolas d'Oreye
//                        Layers are no longer searched by file name extension but by
//                        opening every file found in the directory tree: a file that
//                        opens as a TIFF is a layer, whatever its name. The MSBAS
//                        component is now looked for as a whole token of the file name,
//                        so that ".LOS", "_LOS" and ".LOS.bin.tif" flavours are all
//                        recognised and hence grouped in separate time lines.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <stdint.h>
#include <ctype.h>
#include <tiffio.h>
#include <xtiffio.h>
#include "pourtous.h"
#include "rawFileLib.h"
#include "paramLib.h"
#include "ENVIHeaderManagement.h"
#include "matrixObjects.h"
#include "ieeehalfprecision.h"

#define _MAX_COMPONENT_LENGTH_ 8

/* Characters separating the tokens of a layer file name. MSBAS components are searched
   as whole tokens, so that MSBAS_20161120T000000.vLOS, MSBAS_20161120T000000_vLOS.tif and
   MSBAS_20161120T000000.vLOS.bin.tif are all recognised as the vLOS component, while
   nothing inside a longer word can be taken for one. */
#define _TOKEN_SEPARATORS_ "._-"

/* MSBAS components, displacement and velocity ("v") flavours */
#define _NUMBER_OF_MSBAS_COMPONENTS_ 8
static char *msbasComponents[_NUMBER_OF_MSBAS_COMPONENTS_] = {"LOS", "UD", "EW", "NS",
                                                              "vLOS", "vUD", "vEW", "vNS"} ;

/* One layer of the stack */
struct stackLayer {
    char *path ;                            /* path to the data file */
    char *fileName ;                        /* points inside path */
    char  ownsPath ;                        /* path has to be freed */
    char  isTiff ;                          /* data file is a (Geo)TIFF */
    char  hasDate ;                         /* an MSBAS date was decoded */
    int   date, dTime ;                     /* yyyymmdd and hhmmss */
    char  group[_MAX_COMPONENT_LENGTH_] ;   /* MSBAS component, empty if none */
    int   xDim, yDim ;
} ;
typedef struct stackLayer stackLayer ;

void usage(void) ;
static CSVStruct *recursiveListOfFilesInDir(char *dir, CSVStruct *csvOut) ;
static char getTiffDimensionsAtPath(char *aPath, int *xDim, int *yDim) ;
static char getWindowInTiffAtPath(char *aPath, int x0, int y0, int windowSize, int xDimRef, int yDimRef, float *outValues) ;
static float tiffSampleAsFloat(unsigned char *aSample, uint16_t bitsPerSample, uint16_t sampleFormat) ;
static char parseMSBASNameWithComponent(char *fileName, int *date, int *dTime, char *component) ;
static char getDateInMSBASName(char *fileName, int *date, int *dTime) ;
static int compareStackLayers(const void *layer1, const void *layer2) ;

int main(int argc, const char * argv[]) {
    char *directory, *outputDirectory, *filePath, *fileName, *anExtension ;
    char anyDatedLayer = 0, currentGroup[_MAX_COMPONENT_LENGTH_] ;
    int i, j, k, numberOfLayers = 0, xDim = 0, yDim = 0 ;
    int iX, iY, dXY = 1, windowSize = 1 ;
    int date, dTime, layerXDim, layerYDim, tifXDim, tifYDim ;
    long seekVal, seekShift ;
    float aValue, *tiffValues = NULL ;
    floatMatrix *window = NULL ;
    stackLayer *layers = NULL ;
    
    rawFileDescriptor *outputFile = NULL, *inputFile ;
    CSVStruct *fileList = NULL ;
    keyValue *header ;
    
    if (argc == 1 || argc < 4) {
        usage() ;
    }
    if (!isDir((char *)argv[1])) {
        usage() ;
    }

    sscanf(argv[2], "%d", &iX) ;
    sscanf(argv[3], "%d", &iY) ;
    if (argc > 4) {
    	sscanf(argv[4], "%d", &windowSize) ;
        windowSize = (windowSize < 1)? 1 : 2 * (windowSize / 2) + 1 ;
        window = (windowSize > 2)? allocFloatMatrixWithIndexes(0, windowSize - 1, 0, windowSize - 1) : NULL ;
    }
	dXY = windowSize / 2 ;
    /* Buffer used to read a window out of a TIFF layer */
    tiffValues = (float *)malloc(windowSize * windowSize * sizeof(float)) ;

    directory = initStringWithString((char *)argv[1]) ;

    /* Opening a file as a TIFF is used to tell TIFF layers from other files, so libtiff
       must not complain about the ones that are not. We report what matters ourselves. */
    TIFFSetWarningHandler(NULL) ;
    TIFFSetErrorHandler(NULL) ;

    /* ---------------------------------------------------------------------------------
       1. List every file present in the directory tree. Layers used to be searched by
       extension, which proved too fragile: depending on how they were produced, MSBAS
       (Geo)TIFF layers are named MSBAS_20161120T000000.LOS, MSBAS_20161120T000000.LOS.tif,
       MSBAS_20161120T000000_LOS.tif or even MSBAS_20161120T000000.LOS.bin.tif. What each
       file really is gets sorted out below by opening it, not by reading its name.
       --------------------------------------------------------------------------------- */
    fileList = recursiveListOfFilesInDir(directory, NULL) ;
    if (!fileList || !fileList->numberOfEntries) {
        ase("\t-/-> No file found in given directory") ;
    }
    layers = (stackLayer *)calloc(fileList->numberOfEntries, sizeof(stackLayer)) ;

    /* ---------------------------------------------------------------------------------
       2. Sort out what each candidate is and keep the readable layers only
       --------------------------------------------------------------------------------- */
    for (i = 0; i < fileList->numberOfEntries; i++) {
        fileName = getPointerToFileNameInPath(fileList->stringVal[i]) ;
        if (!fileExistsAtPath(fileList->stringVal[i])) {
            continue ;
        }

        /* Any file that opens as a TIFF is a layer, whatever its name, and the file found
           is the data file itself. Probing the file is also what discards, at no cost in
           name conventions, all the other files an MSBAS directory holds. */
        if (getTiffDimensionsAtPath(fileList->stringVal[i], &layerXDim, &layerYDim)) {
            layers[numberOfLayers].path = fileList->stringVal[i] ;
            layers[numberOfLayers].isTiff = 1 ;
            layers[numberOfLayers].xDim = layerXDim ;
            layers[numberOfLayers].yDim = layerYDim ;
            /* MSBAS layers carry both a date and a component, e.g. *20161120*.vLOS */
            layers[numberOfLayers].group[0] = '\0' ;
            if (parseMSBASNameWithComponent(fileName, &date, &dTime, layers[numberOfLayers].group)) {
                layers[numberOfLayers].hasDate = 1 ;
                layers[numberOfLayers].date = date ;
                layers[numberOfLayers].dTime = dTime ;
                anyDatedLayer = 1 ;
            }
            /* An MSBAS layer may also come without any component, as MSBAS ENVI layers
               do, e.g. MSBAS_20161120T000000.tif. It then goes in the componentless
               group, exactly as its ENVI counterpart would. */
            else if (!strncmp(fileName, "MSBAS_", 6) && getDateInMSBASName(fileName, &date, &dTime)) {
                layers[numberOfLayers].group[0] = '\0' ;
                layers[numberOfLayers].hasDate = 1 ;
                layers[numberOfLayers].date = date ;
                layers[numberOfLayers].dTime = dTime ;
                anyDatedLayer = 1 ;
            }
            layers[numberOfLayers].fileName = getPointerToFileNameInPath(layers[numberOfLayers].path) ;
            numberOfLayers++ ;
            continue ;
        }

        /* Among the files left, only ENVI headers are of any interest */
        if (!(anExtension = strrchr(fileName, '.')) || strcasecmp(anExtension + 1, "hdr")) {
            continue ;
        }
        /* An ENVI header: read the dimensions and locate the data file */
        if (!(header = readENVIHeader(fileList->stringVal[i]))) {
            continue ;
        }
        layerXDim = getIntValForKeyIn(header, "samples") ;
        layerYDim = getIntValForKeyIn(header, "lines") ;
        freeKeyValueList(header) ;
        if (!layerXDim || !layerYDim) {
            continue ;
        }

        if (!strncmp(fileName, "MSBAS_", 6)) {
            /* MSBAS ENVI layer: the data file is the header path without its extension */
            stripExtensionAtEndOfPath(fileList->stringVal[i]) ;
            if (!fileExistsAtPath(fileList->stringVal[i])) {
                printf("\t-/-> ENVI header present while corresponding MSBAS layer doesn't\n\t\t%s\n\n", getPointerToFileNameInPath(fileList->stringVal[i])) ;
                continue ;
            }
            filePath = fileList->stringVal[i] ;
            /* An ENVI header may sit next to a GeoTIFF, as produced e.g. by
               Envi2msbastif.sh. Such a layer is read through the TIFF reader and is
               already listed above: skip it here. */
            if (getTiffDimensionsAtPath(filePath, &tifXDim, &tifYDim)) {
                continue ;
            }
            if (!getDateInMSBASName(getPointerToFileNameInPath(filePath), &date, &dTime)) {
                printf("\t---> File %s discarded. No date found in MSBAS file name.\n", getPointerToFileNameInPath(filePath)) ;
                continue ;
            }
            layers[numberOfLayers].path = filePath ;
            layers[numberOfLayers].hasDate = 1 ;
            layers[numberOfLayers].date = date ;
            layers[numberOfLayers].dTime = dTime ;
            anyDatedLayer = 1 ;
        }
        else {
            if (!(filePath = getENVIFileCorrespondingToHeader(fileList->stringVal[i]))) {
                continue ;
            }
            if (getTiffDimensionsAtPath(filePath, &tifXDim, &tifYDim)) {
                free(filePath) ;
                continue ;
            }
            layers[numberOfLayers].path = filePath ;
            layers[numberOfLayers].ownsPath = 1 ;
        }
        layers[numberOfLayers].xDim = layerXDim ;
        layers[numberOfLayers].yDim = layerYDim ;
        layers[numberOfLayers].fileName = getPointerToFileNameInPath(layers[numberOfLayers].path) ;
        numberOfLayers++ ;
    }

    /* As soon as one MSBAS layer is present we are dealing with an MSBAS directory, and
       every other file has to be ignored. */
    if (anyDatedLayer) {
        for (i = 0, j = 0; i < numberOfLayers; i++) {
            if (layers[i].hasDate) {
                if (i != j) {
                    layers[j] = layers[i] ;
                }
                j++ ;
            }
            else if (layers[i].ownsPath) {
                free(layers[i].path) ;
            }
        }
        numberOfLayers = j ;
    }
    if (!numberOfLayers) {
        ase("Failed to read any ENVI header file nor any TIFF layer") ;
    }

    /* ---------------------------------------------------------------------------------
       3. Group by component and order chronologically
       --------------------------------------------------------------------------------- */
    qsort(layers, numberOfLayers, sizeof(stackLayer), compareStackLayers) ;

    /* ---------------------------------------------------------------------------------
       4. Stack dimensions and basic verifications. Dimensions are taken on the first
       layer once sorted, so that they do not depend on the order the file system
       happens to return the files in.
       --------------------------------------------------------------------------------- */
    xDim = layers[0].xDim ;
    yDim = layers[0].yDim ;
    if ((iX > xDim) || (iY > yDim) || (iX * iY > xDim * yDim)) {
        ase("Requested point outside of image frame") ;
    }
    /* Adapt iX and iY to cope with the size of requested window dXY */
    iX = (iX < dXY)? dXY : iX ;
    iX = (iX > xDim - 1 - dXY)? xDim - 1 - dXY : iX ;
    iY = (iY < dXY)? dXY : iY ;
    iY = (iY > yDim - 1 - dXY)? yDim - 1 - dXY : iY ;

    /* Time lines are written in the directory given on the command line, whatever
       subdirectory the layers themselves were found in. */
    outputDirectory = expandEnvironmentVariablesInPath(directory) ;
    if (!outputDirectory) {
        outputDirectory = initStringWithString(directory) ;
    }

    /* ---------------------------------------------------------------------------------
       5. Extract the time lines, one output file per component
       --------------------------------------------------------------------------------- */
    seekVal = ((long)(iY - dXY) * xDim + (iX - dXY)) * sizeof(float) ;
    seekShift = (long)(xDim - windowSize) * sizeof(float) ;
    currentGroup[0] = '\0' ;
    for (i = 0; i < numberOfLayers; i++) {
        /* Open a new output file whenever the component changes */
        if (!outputFile || strcmp(layers[i].group, currentGroup)) {
            if (outputFile) {
                freeRawFileDescriptor(outputFile) ;
            }
            snprintf(currentGroup, sizeof(currentGroup), "%s", layers[i].group) ;
            if (currentGroup[0]) {
                sprintf(accessPath, "%s/timeLine%d_%d_%s.txt", outputDirectory, iX, iY, currentGroup) ;
            }
            else {
                sprintf(accessPath, "%s/timeLine%d_%d.txt", outputDirectory, iX, iY) ;
            }
            if (!(outputFile = openRawFileForWritingAtPath(accessPath))) {
                sprintf(ertex, "\t-/-> Failed to open output file %s\n", accessPath) ;
                ase(ertex) ;
            }
        }

        /* Layers not sharing the stack dimensions do not sample the same ground */
        if (layers[i].xDim != xDim || layers[i].yDim != yDim) {
            printf("\t-/-> %s is %d x %d while stack is %d x %d. Layer discarded.\n", layers[i].fileName, layers[i].xDim, layers[i].yDim, xDim, yDim) ;
            continue ;
        }

        if (layers[i].isTiff) {
            if (!getWindowInTiffAtPath(layers[i].path, iX - dXY, iY - dXY, windowSize, xDim, yDim, tiffValues)) {
                continue ;
            }
            if (!window) {
                aValue = tiffValues[0] ;
            }
            else {
                for (j = 0; j < windowSize; j++) {
                    for (k = 0; k < windowSize; k++) {
                        window->mf[j][k] = tiffValues[j * windowSize + k] ;
                    }
                }
                statMatWithHistoInterval(window, 0, 0 ,0) ;
                aValue = window->average ;
            }
        }
        else {
            if (!(inputFile = openRawFileForReadingAtPath(layers[i].path))) {
                printf("\t-/-> Failed to open raw file at path %s\n", layers[i].path) ;
                continue ;
            }
            fseek(inputFile->f, seekVal, SEEK_SET) ;
            if (!window) {
                fread(&aValue, sizeof(float), 1, inputFile->f) ;
            }
            else {
                for (j = 0; j < windowSize; j++) {
                    fread(window->mf[j], sizeof(float), windowSize, inputFile->f) ;
                    fseek(inputFile->f, seekShift, SEEK_CUR) ;
                }
                statMatWithHistoInterval(window, 0, 0 ,0) ;
                aValue = window->average ;
            }
            freeRawFileDescriptor(inputFile) ;
        }

        if (layers[i].hasDate) {
            fprintf(outputFile->f, "%.6d\t%.6d\t%f\n", layers[i].date, layers[i].dTime, aValue) ;
        }
        else {
            fprintf(outputFile->f, "%s\t%f\n", layers[i].fileName, aValue) ;
        }
    }
    
    if (outputFile) {
        freeRawFileDescriptor(outputFile) ;
    }
    for (i = 0; i < numberOfLayers; i++) {
        if (layers[i].ownsPath) {
            free(layers[i].path) ;
        }
    }
    free(layers) ;
    free(outputDirectory) ;
    freeCSVStruct(fileList) ;
    free(directory) ;
    if (window) {
        freeFloatMatrix(window) ;
    }
    if (tiffValues) {
        free(tiffValues) ;
    }

    return 0;
}


/*----------------------------------------------------------------------------------------
 Orders the layers by component first, then chronologically. Layers holding no date are
 ordered alphabetically, which is all the ordering their names allow.
 ----------------------------------------------------------------------------------------*/
static int compareStackLayers(const void *layer1, const void *layer2)
{
    const stackLayer *l1 = (const stackLayer *)layer1 ;
    const stackLayer *l2 = (const stackLayer *)layer2 ;
    int aComparison ;

    if ((aComparison = strcmp(l1->group, l2->group))) {
        return (aComparison) ;
    }
    if (l1->hasDate && l2->hasDate) {
        if (l1->date != l2->date) {
            return ((l1->date < l2->date)? -1 : 1) ;
        }
        if (l1->dTime != l2->dTime) {
            return ((l1->dTime < l2->dTime)? -1 : 1) ;
        }
        return (0) ;
    }

    return (strcmp(l1->fileName, l2->fileName)) ;
}


/*----------------------------------------------------------------------------------------
 Recursively lists every regular file found in dir. csvOut is the list being built and
 must be NULL on the first call. Returns the resulting list, NULL when dir holds no file.
 Written here rather than reusing recursiveSearchOfFilesWithExtensionInDir() because the
 layers looked for cannot be told from their extension. Hidden entries are skipped by
 getDirectoryContentAtPath(), hence "." and ".." are too.
 ----------------------------------------------------------------------------------------*/
static CSVStruct *recursiveListOfFilesInDir(char *dir, CSVStruct *csvOut)
{
    char *aPath, **directoryContent ;
    int i, numberOfEntries = 0 ;

    if (!isDir(dir)) {
        return (csvOut) ;
    }
    if (!(directoryContent = getDirectoryContentAtPath(dir, &numberOfEntries))) {
        return (csvOut) ;
    }
    for (i = 0; i < numberOfEntries; i++) {
        aPath = initStringWith3Strings(dir, "/", directoryContent[i]) ;
        if (isDir(aPath)) {
            csvOut = recursiveListOfFilesInDir(aPath, csvOut) ;
        }
        else {
            csvOut = addStringValInCSVStruct(aPath, csvOut) ;
        }
        free(directoryContent[i]) ;
        free(aPath) ;
    }
    free(directoryContent) ;

    return (csvOut) ;
}


/*----------------------------------------------------------------------------------------
 Looks for a yyyymmdd date, optionally followed by Thhmmss, anywhere in fileName.
 Returns 1 together with the date as yyyymmdd and the time as hhmmss when one is found.
 ----------------------------------------------------------------------------------------*/
static char getDateInMSBASName(char *fileName, int *date, int *dTime)
{
    int i, j, aYear, aMonth, aDay, aLength ;

    aLength = (int)strlen(fileName) ;
    for (i = 0; i <= aLength - 8; i++) {
        for (j = 0; j < 8; j++) {
            if (!isdigit((unsigned char)fileName[i + j])) {
                break ;
            }
        }
        if (j < 8) {
            continue ;
        }
        if (sscanf(fileName + i, "%4d%2d%2d", &aYear, &aMonth, &aDay) != 3) {
            continue ;
        }
        if (aYear < 1990 || aYear > 2100 || aMonth < 1 || aMonth > 12 || aDay < 1 || aDay > 31) {
            continue ;
        }
        *date = aYear * 10000 + aMonth * 100 + aDay ;
        *dTime = 0 ;
        /* An hhmmss time may follow, as in 20161120T061024 */
        if (fileName[i + 8] == 'T') {
            for (j = 0; j < 6; j++) {
                if (!isdigit((unsigned char)fileName[i + 9 + j])) {
                    break ;
                }
            }
            if (j == 6) {
                sscanf(fileName + i + 9, "%6d", dTime) ;
            }
        }
        return (1) ;
    }

    return (0) ;
}


/*----------------------------------------------------------------------------------------
 Decodes an MSBAS layer name, that is a name holding both a yyyymmdd date and an MSBAS
 component. Both are looked for as whole tokens, tokens being delimited by any of
 _TOKEN_SEPARATORS_, so that neither the separator used before the component nor whatever
 follows it matters. MSBAS_20161120T000000.vLOS, MSBAS_20161120T000000.vLOS.tif,
 MSBAS_20161120T000000_vLOS.tif, MSBAS_20161120.vLOS.bin.tif and MSBAS_vLOS_20161120.tif
 hence all qualify, and matching whole tokens is what tells vLOS from LOS.
 Returns 1 together with the date, the time and the component.
 ----------------------------------------------------------------------------------------*/
static char parseMSBASNameWithComponent(char *fileName, int *date, int *dTime, char *component)
{
    char aName[_MAX_PATH_LENGTH_], *aToken ;
    int i ;

    component[0] = '\0' ;
    snprintf(aName, sizeof(aName), "%s", fileName) ;

    /* strtok cuts aName up, which is why it is a copy. The last component found wins,
       there being no reason for a name to hold two. */
    for (aToken = strtok(aName, _TOKEN_SEPARATORS_) ; aToken ; aToken = strtok(NULL, _TOKEN_SEPARATORS_)) {
        for (i = 0; i < _NUMBER_OF_MSBAS_COMPONENTS_; i++) {
            if (!strcmp(aToken, msbasComponents[i])) {
                snprintf(component, _MAX_COMPONENT_LENGTH_, "%s", msbasComponents[i]) ;
                break ;
            }
        }
    }
    if (!component[0]) {
        return (0) ;
    }

    /* And the name must hold a date, which rules out MSBAS_LINEAR_RATE.LOS and the like */
    return (getDateInMSBASName(fileName, date, dTime)) ;
}


/*----------------------------------------------------------------------------------------
 Reads the raster dimensions in the TIFF tags. Returns 1 on success. Failing to open the
 file as a TIFF is not reported: this function is also used to tell TIFF layers apart
 from same named files that would not be ones.
 ----------------------------------------------------------------------------------------*/
static char getTiffDimensionsAtPath(char *aPath, int *xDim, int *yDim)
{
    TIFF *tifImage ;
    uint32_t xTiffDim = 0, yTiffDim = 0 ;

    if ((tifImage = XTIFFOpen(aPath, "r")) == NULL) {
        return (0) ;
    }
    if (!TIFFGetField(tifImage, TIFFTAG_IMAGEWIDTH, &xTiffDim) || !TIFFGetField(tifImage, TIFFTAG_IMAGELENGTH, &yTiffDim)) {
        printf("\t-/-> Image dimension fields not defined in %s.\n", aPath) ;
        XTIFFClose(tifImage) ;
        return (0) ;
    }
    XTIFFClose(tifImage) ;

    *xDim = (int)xTiffDim ;
    *yDim = (int)yTiffDim ;

    return (1) ;
}


/*----------------------------------------------------------------------------------------
 Converts one TIFF sample into a float, whatever its storage type.
 ----------------------------------------------------------------------------------------*/
static float tiffSampleAsFloat(unsigned char *aSample, uint16_t bitsPerSample, uint16_t sampleFormat)
{
    switch (sampleFormat) {
        case SAMPLEFORMAT_IEEEFP:
            if (bitsPerSample == 32) {
                return (*((float *)aSample)) ;
            }
            if (bitsPerSample == 64) {
                return ((float)(*((double *)aSample))) ;
            }
            if (bitsPerSample == 16) {
                return (half2SinglePrecision((void *)aSample)) ;
            }
            break ;

        case SAMPLEFORMAT_INT:
            if (bitsPerSample == 8) {
                return ((float)(*((int8_t *)aSample))) ;
            }
            if (bitsPerSample == 16) {
                return ((float)(*((int16_t *)aSample))) ;
            }
            if (bitsPerSample == 32) {
                return ((float)(*((int32_t *)aSample))) ;
            }
            if (bitsPerSample == 64) {
                return ((float)(*((int64_t *)aSample))) ;
            }
            break ;

        /* SAMPLEFORMAT_UINT and anything else is read as unsigned integer */
        default:
            if (bitsPerSample == 8) {
                return ((float)(*((uint8_t *)aSample))) ;
            }
            if (bitsPerSample == 16) {
                return ((float)(*((uint16_t *)aSample))) ;
            }
            if (bitsPerSample == 32) {
                return ((float)(*((uint32_t *)aSample))) ;
            }
            if (bitsPerSample == 64) {
                return ((float)(*((uint64_t *)aSample))) ;
            }
            break ;
    }

    return (floatNaN) ;
}


/*----------------------------------------------------------------------------------------
 Reads a windowSize x windowSize window whose upper left corner is (x0, y0) out of the
 TIFF layer at aPath. Values are stored row wise in outValues[j * windowSize + k] and
 converted to float whatever the TIFF sample format is. Only the first band is read.
 Both stripped and tiled (e.g. COG) organisations are handled.
 The layer dimensions must match those of the stack (xDimRef, yDimRef), otherwise the
 same pixel coordinates would not point at the same ground location.
 Returns 1 on success, 0 if the layer has to be discarded.
 ----------------------------------------------------------------------------------------*/
static char getWindowInTiffAtPath(char *aPath, int x0, int y0, int windowSize, int xDimRef, int yDimRef, float *outValues)
{
    TIFF *tifImage ;
    uint32_t xTiffDim = 0, yTiffDim = 0, tileWidth = 0, tileLength = 0 ;
    uint16_t bitsPerSample = 32, samplesPerPixel = 1, sampleFormat = SAMPLEFORMAT_UINT, planarConfig = PLANARCONFIG_CONTIG ;
    int j, k, x, y, sampleSize, pixelSize ;
    long tileX, tileY, cachedTileX = -1, cachedTileY = -1 ;
    unsigned char *buffer = NULL ;
    char isOk = 1 ;

    if ((tifImage = XTIFFOpen(aPath, "r")) == NULL) {
        printf("\t-/-> Failed to open tiff file at path %s\n", aPath) ;
        return (0) ;
    }

    if (!TIFFGetField(tifImage, TIFFTAG_IMAGEWIDTH, &xTiffDim) || !TIFFGetField(tifImage, TIFFTAG_IMAGELENGTH, &yTiffDim)) {
        printf("\t-/-> Image dimension fields not defined in %s. Layer discarded.\n", aPath) ;
        XTIFFClose(tifImage) ;
        return (0) ;
    }
    TIFFGetFieldDefaulted(tifImage, TIFFTAG_BITSPERSAMPLE, &bitsPerSample) ;
    TIFFGetFieldDefaulted(tifImage, TIFFTAG_SAMPLESPERPIXEL, &samplesPerPixel) ;
    TIFFGetFieldDefaulted(tifImage, TIFFTAG_SAMPLEFORMAT, &sampleFormat) ;
    TIFFGetFieldDefaulted(tifImage, TIFFTAG_PLANARCONFIG, &planarConfig) ;

    /* Verify that this layer is consistent with the rest of the stack */
    if ((int)xTiffDim != xDimRef || (int)yTiffDim != yDimRef) {
        printf("\t-/-> %s is %d x %d while stack is %d x %d. Layer discarded.\n", getPointerToFileNameInPath(aPath), (int)xTiffDim, (int)yTiffDim, xDimRef, yDimRef) ;
        XTIFFClose(tifImage) ;
        return (0) ;
    }

    /* Verify that the requested window lies within that layer */
    if (x0 < 0 || y0 < 0 || (x0 + windowSize) > (int)xTiffDim || (y0 + windowSize) > (int)yTiffDim) {
        printf("\t-/-> Requested window outside of frame of %s (%d x %d). Layer discarded.\n", getPointerToFileNameInPath(aPath), (int)xTiffDim, (int)yTiffDim) ;
        XTIFFClose(tifImage) ;
        return (0) ;
    }

    /* Only sample sizes that are a whole number of bytes are handled */
    if (bitsPerSample % 8) {
        printf("\t-/-> %d bits per sample not handled in %s. Layer discarded.\n", (int)bitsPerSample, getPointerToFileNameInPath(aPath)) ;
        XTIFFClose(tifImage) ;
        return (0) ;
    }
    sampleSize = bitsPerSample / 8 ;
    /* In contiguous configuration, bands are interleaved by pixel. We read the first band. */
    pixelSize = (planarConfig == PLANARCONFIG_CONTIG)? sampleSize * samplesPerPixel : sampleSize ;

    if (TIFFIsTiled(tifImage)) {
        if (!TIFFGetField(tifImage, TIFFTAG_TILEWIDTH, &tileWidth) || !TIFFGetField(tifImage, TIFFTAG_TILELENGTH, &tileLength)) {
            printf("\t-/-> Tile dimension fields not defined in %s. Layer discarded.\n", aPath) ;
            XTIFFClose(tifImage) ;
            return (0) ;
        }
        if ((buffer = (unsigned char *)_TIFFmalloc(TIFFTileSize(tifImage))) == NULL) {
            printf("\t-/-> Failed to allocate tiff tile buffer for %s. Layer discarded.\n", aPath) ;
            XTIFFClose(tifImage) ;
            return (0) ;
        }
        for (j = 0; j < windowSize && isOk; j++) {
            y = y0 + j ;
            for (k = 0; k < windowSize; k++) {
                x = x0 + k ;
                tileX = (long)(x / (int)tileWidth) * (long)tileWidth ;
                tileY = (long)(y / (int)tileLength) * (long)tileLength ;
                if (tileX != cachedTileX || tileY != cachedTileY) {
                    if (TIFFReadTile(tifImage, buffer, (uint32_t)tileX, (uint32_t)tileY, 0, 0) == -1) {
                        printf("\t-/-> Failed to read tile (%ld, %ld) in tiff file %s. Layer discarded.\n", tileX, tileY, aPath) ;
                        isOk = 0 ;
                        break ;
                    }
                    cachedTileX = tileX ;
                    cachedTileY = tileY ;
                }
                outValues[j * windowSize + k] = tiffSampleAsFloat(buffer + (((long)(y - tileY) * (long)tileWidth + (long)(x - tileX)) * pixelSize), bitsPerSample, sampleFormat) ;
            }
        }
    }
    else {
        if ((buffer = (unsigned char *)_TIFFmalloc(TIFFScanlineSize(tifImage))) == NULL) {
            printf("\t-/-> Failed to allocate tiff scanline buffer for %s. Layer discarded.\n", aPath) ;
            XTIFFClose(tifImage) ;
            return (0) ;
        }
        for (j = 0; j < windowSize; j++) {
            if (TIFFReadScanline(tifImage, buffer, (uint32_t)(y0 + j), 0) == -1) {
                printf("\t-/-> Failed to read line %d in tiff file %s. Layer discarded.\n", y0 + j, aPath) ;
                isOk = 0 ;
                break ;
            }
            for (k = 0; k < windowSize; k++) {
                outValues[j * windowSize + k] = tiffSampleAsFloat(buffer + ((long)(x0 + k) * pixelSize), bitsPerSample, sampleFormat) ;
            }
        }
    }

    _TIFFfree(buffer) ;
    XTIFFClose(tifImage) ;

    return (isOk) ;
}


void usage(void) {
    printf("Usage:\ngetLineThroughStack MSBASDirectoryPath xCoordinate yCoordinate [windowSize]\n\n") ;
    printf("Extracts the time line of the pixel at (xCoordinate, yCoordinate) through all the\n") ;
    printf("layers found recursively in MSBASDirectoryPath. Layers are always ordered\n") ;
    printf("chronologically.\n\n") ;
    printf("Layers may be ENVI raw files (float32, described by their .hdr file) and/or\n") ;
    printf("(Geo)TIFF files (any sample format, stripped or tiled, first band). (Geo)TIFF\n") ;
    printf("layers are recognised by opening them, whatever their name or extension.\n\n") ;
    printf("MSBAS layers are recognised by a yyyymmdd date together with a component name,\n") ;
    printf("i.e. LOS, UD, EW, NS and their velocity flavours vLOS, vUD, vEW, vNS. Both are\n") ;
    printf("read as whole '.', '_' or '-' delimited tokens of the file name, hence e.g.\n") ;
    printf("MSBAS_20161120T000000.vLOS, MSBAS_20161120T000000_vLOS.tif and\n") ;
    printf("MSBAS_20161120T000000.vLOS.bin.tif are all read as the vLOS component.\n") ;
    printf("One time line is written per component, as timeLineX_Y_COMPONENT.txt, and every\n") ;
    printf("other file present in the directory is ignored.\n\n") ;
    printf("If windowSize is provided, the average value over a windowSize x windowSize window\n") ;
    printf("centred on the requested pixel is output instead of the single pixel value.\n") ;
    exit(0) ;
}
