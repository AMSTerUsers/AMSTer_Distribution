
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  getStatForZoneInFile
//
//  Created by Dominique Derauw on 04/12/2018.
//  Copyright © 2018 Dominique Derauw - SAREOS. All rights reserved.
//

// This routine gets stats and display average of a given float file on a predefine area of interest provided as a kml zone.
// The input file must have an ENVI header associated to it in the same dir (.hdr)
// The kml zone must contain vertex coordinates in longitude latitude (decimal values)


#include <stdio.h>
#include "pourtous.h"
#include "rawFileLib.h"
#include "paramLib.h"
#include "ENVIHeaderManagement.h"
#include "aoiHandling.h"
#include "projUTM.h"
#include "ellipsoid.h"
#include "matrixObjects.h"

void usage(void) ;

int main(int argc, const char * argv[]) {
    char *filePath, *headerPath, *kmlPath ;
    int i ;
    int xDim, yDim ;
    int dx, dy, xDimZone, yDimZone ;
    int UTMLongitudeIndex ;
    long seekVal ;
    float theValue ;
    double xSampling, ySampling, refEasting, refNorthing ;
    polygon *aoi ;
    keyValue *ENVIHeader ;
    UTMZoneStruct *UTMZone ;
    ellipsoid *WGS84Ellipsoid ;
    point2D aPoint ;
    rawFileDescriptor *theFile ;
    floatMatrix *theZone ;
    
    if (argc == 1 || argc > 3) {
        usage() ;
    }
    if (!fileExistsAtPath((char *)argv[1]) || !fileExistsAtPath((char *)argv[2])) {
        usage() ;
    }
    
    /* Init WGS84 ellipsoid */
    if((WGS84Ellipsoid = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL) {
        perror("Failed to allocate WGS84 reference ellipsoid\n") ;
        exit(-1) ;
    }
    WGS84Ellipsoid->a = 6.378137000000000e+06 ;
    WGS84Ellipsoid->b = 6.356752314245000e+06 ; // Predefined as WGS84
    WGS84Ellipsoid->f_1 = WGS84Ellipsoid->a / (WGS84Ellipsoid->a  - WGS84Ellipsoid->b) ;
    WGS84Ellipsoid->e2 = (pow(WGS84Ellipsoid->a, 2.) - pow(WGS84Ellipsoid->b, 2.)) / pow(WGS84Ellipsoid->a, 2.) ;
    WGS84Ellipsoid->X0 = WGS84Ellipsoid->Y0 = WGS84Ellipsoid->Z0 = 0. ;

    filePath = initStringWithString((char *)argv[1]) ;
    headerPath = getENVIHeaderPathOfFile(filePath) ;
    
    if((ENVIHeader = readENVIHeader(headerPath)) == NULL) {
        perror("Failed to read ENVI header") ;
        return (0) ;
    }
    xDim = getIntValForKeyIn(ENVIHeader, "samples") ;
    yDim = getIntValForKeyIn(ENVIHeader, "lines") ;
    xSampling = getDoubleValForKeyIn(ENVIHeader, "X sampling") ;
    ySampling = getDoubleValForKeyIn(ENVIHeader, "Y sampling") ;
    refEasting = getDoubleValForKeyIn(ENVIHeader, "Easting") ;
    refNorthing = getDoubleValForKeyIn(ENVIHeader, "Northing") ;
    UTMLongitudeIndex = getIntValForKeyIn(ENVIHeader, "UTMZone") ;
    if (!xDim || !yDim || !xSampling || !ySampling || !refEasting || !refNorthing) {
        perror("Failed to read values in ENVI header \n") ;
        return (0) ;
    }
    kmlPath = initStringWithString((char *)argv[2]) ;
    if((aoi = getRectangularAoIFromKMLFile(kmlPath)) == NULL) {
        perror("Failed to derive rectangular area of interest from kml file") ;
        return (0) ;
    }
    convertAoIFromDeg2Rad(aoi) ;
    
    UTMZone = initUTMReferencingOnEllipsoid(WGS84Ellipsoid) ;
    aPoint.p.x = aoi->P[0].x ;
    aPoint.p.y = aoi->P[0].y ;
    UTMZoneForLonLatPoint(&aPoint, UTMZone) ;
    if (UTMLongitudeIndex && UTMZone->indiceZoneLonUTM != UTMLongitudeIndex) {
        printf("\t---> Warning: Given kml is located in UTM zone %d%.1s while given image has UTM longitude zone index %d\n", UTMZone->indiceZoneLonUTM, UTMZone->zoneLatUTM, UTMLongitudeIndex) ;
        printf("\t---> kml UTM longitude index is forced to image one\n") ;
        UTMZone->indiceZoneLonUTM = UTMLongitudeIndex ;
        UTMZoneForLonLatPoint(&aPoint, UTMZone) ;
    }
    
    for (i = 0; i < aoi->N; i++) {
        lonLat2UTMOnEllipsoid(aoi->V[i], aoi->V[i] + 1, UTMZone) ;
    }
    
    dx = (int)round((aoi->P[0].x - refEasting) / xSampling) ;
    dy = (int)round((aoi->P[0].y - refNorthing) / ySampling) + yDim ;
    dx = (dx < 0)? 0 : ((dx > xDim)? 0 : dx) ;
    dy = (dy < 0)? 0 : ((dy > yDim)? 0 : dy) ;
    xDimZone = (int)round((aoi->P[2].x - refEasting) / xSampling) - dx + 1 ;
    yDimZone = (int)round((aoi->P[2].y - refNorthing) / ySampling) + yDim - dy + 1 ;
    xDimZone = (xDimZone > xDim)? xDim : xDimZone ;
    yDimZone = (yDimZone > yDim)? yDim : yDimZone ;
    
    if((theFile = openRawFileForReadingAtPath(filePath)) == NULL) {
        perror("Failed to open input file") ;
        return (0) ;
    }
    if (theFile->fileLength != xDim * yDim *sizeof(float)) {
        perror("Wrong file dimensions") ;
        return (0) ;
    }
    theZone = allocFloatMatrixWithIndexes(0, yDimZone - 1, 0, xDimZone - 1) ;
    
    for (i = 0; i < yDimZone; i++) {
        seekVal = ((yDim - i - dy) * xDim + dx) * sizeof(float) ;
        fseek(theFile->f, seekVal, SEEK_SET) ;
        fread(theZone->m[i], sizeof(float), xDimZone, theFile->f) ;
    }
    statMat(theZone) ;
    theValue = theZone->average ;
    fprintf(stdout, "%f\n", theValue) ;
    
    freeFloatMatrix(theZone) ;
    freeRawFileDescriptor(theFile) ;
    freeKeyValueList(ENVIHeader) ;
    free(headerPath) ;
    free(filePath) ;

    return (0);
}


void usage(void) {
    printf("Usage:\ngetStatForZoneInFile filePath zone.kml\n") ;
    exit(0) ;
}
