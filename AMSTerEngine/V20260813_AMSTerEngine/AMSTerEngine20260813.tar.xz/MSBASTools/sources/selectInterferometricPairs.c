
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  selectInterferometricPairs
//
//  Created by Ludivine Libert on 20/08/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fileAccessLib.h"
#include "paramLib.h"


void usage(void) ;


int main(int argc, const char * argv[]) {
    
    int i, j, N ;
    int maxDelay, minDelay ;
    double Bmax, Bmin ;
    
    int slaveName, masterName, delay, Bperp ;

    char *pathToSetParams, *pathToApproximateBaselinesFile ;
    char *pathToSelectedPairsFile, *fileName ;
    
    keyValue *setParametersList ;
    
    FILE *ftriangle, *fpairs ;
    time_t startTime, endTime ;
    

    if (argc == 1 || argc > 2)
        usage() ;
    
    if (isArgumentPresent(argc, argv, "-help"))
        usage() ;
    
    time(&startTime) ;
    
    /* Reading parameter file */
    pathToSetParams = (char *)argv[1] ;
    setParametersList = readParameterFileAtPath(pathToSetParams) ;

    /* Parameters initialization */
    pathToApproximateBaselinesFile = initStringWithString(getStringValForKeyIn(setParametersList, "Path to triangle")) ;
    N = getIntValForKeyIn(setParametersList, "Number of images") ;
    
    maxDelay = getIntValForKeyIn(setParametersList, "Maximum temporal delay") ;
    minDelay = getIntValForKeyIn(setParametersList, "Minimum temporal delay") ;
    Bmax = getDoubleValForKeyIn(setParametersList, "Maximum baseline") ;
    Bmin = getDoubleValForKeyIn(setParametersList, "Minimum baseline") ;
    
    fileName = allocStringOfLength(MAXNAMLEN) ;
    
    /* Selected pairs will be saved in a text file called "table_Bmin_Bmax_minDelay_maxDelay.txt" */
    sprintf(fileName, "table_%d_%d_%d_%d.txt",(int)Bmin, (int)Bmax, minDelay, maxDelay) ;
    pathToSelectedPairsFile = initStringWith2Strings(getDirectoryPathFromPath(pathToApproximateBaselinesFile), fileName) ;
    fpairs = fopen(pathToSelectedPairsFile, "w") ;
    fprintf(fpairs, "   Master\t   Slave\t Bperp\t Delay\n\n") ;
    fclose(fpairs) ;
    
    ftriangle = fopen(pathToApproximateBaselinesFile, "r") ;
    fseek(ftriangle, 0, SEEK_SET) ;

    printf("Interferometric pairs selection : \n\n") ;
    printf("   Master\t   Slave\t Bperp\t Delay\n") ;
    printf("--------------------------------------------------------\n\n") ;
    
    for (i = 1 ; i < N ; i ++)
    {
        for (j = 0 ; j <i ; j++)
        {
            fscanf(ftriangle, "%8d_%8d_%d_%d\t", &masterName, &slaveName, &Bperp, &delay) ;
            
            if (fabs(Bperp) < fabs(Bmax) && fabs(Bperp) > fabs(Bmin) && fabs(delay) < maxDelay && fabs(delay) > minDelay)
            {
                printf("%8d\t%8d\t%6d\t%6d\n", masterName, slaveName, Bperp, delay) ;
                fpairs = fopen(pathToSelectedPairsFile, "a") ;
                fprintf(fpairs, "%8d\t%8d\t%6d\t%6d\n", masterName, slaveName, Bperp, delay) ;
                fclose(fpairs) ;
            }
            
        }
        fscanf(ftriangle, "\n\n") ;
    }
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    
    fclose(ftriangle) ;
    free(fileName) ;
    
    return 0;
}


void usage()
{
    printf("\nUsage: \n\n\tselectInterferometricPairs /pathTo/setParametersFile.txt\n\n") ;
    printf("The routine considers each pair of the triangle table given in the set parameters file and records the pairs selected for processing in a file \"table_Bmin_Bmax_minDelay_maxDelay.txt\". ") ;
    printf("An interferometric pair is selected if its perpendicular baseline and its delay are between the minimum and maximum values.\n\n") ;
    
    exit(0) ;
}
