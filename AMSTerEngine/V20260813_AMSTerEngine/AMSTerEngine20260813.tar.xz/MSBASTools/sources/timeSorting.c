
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  timeSorting
//
//  Created by Ludivine Libert on 15/06/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#include <stdio.h>
#include "timeSorting.h"


int main(int argc, const char * argv[]) {
    
    char *directoryPath ;
    time_t startTime, endTime ;
    
    
    if(argc == 1 || argc > 3)
        usage() ;
    
    if(isArgumentPresent(argc, argv, "help"))
        usage() ;
    
    
    time(&startTime) ;
    
    directoryPath = (char *)argv[1] ;
    
    if (isDir(directoryPath))
        renameCSLFilesInDirectoryAtPath(directoryPath) ;
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    
    
    return 0;
}


void usage()
{
    printf("\nUsage : \n\n\t timeSorting /pathTo/directory [-help] \n\n");
    printf("The routine will rename the CSL files in the indicated directory according to a <YYYY><MM><DD> format, based on their acquisition date.\n") ;
    
    exit(0) ;    
}


/* The files contained in directory indicated by the path are renamed according to a YYYYMMDD format */
void renameCSLFilesInDirectoryAtPath(char *directoryPath)
{
    int i, numberOfEntries ;
    char **directoryContent ;
    char *SLCImageInfoFilePath, *newName, *oldName ;
    
    SLCImageInfo *infoImage ;
    
    numberOfEntries = getNumberOfDirectoryEntriesAtPath(directoryPath) ;
    directoryContent = getDirectoryContentAtPath(directoryPath, &numberOfEntries) ;
    
    for (i = 0 ; i < numberOfEntries; i++)
    {
        if ((strstr(directoryContent[i], ".csl")) != NULL) {
            
            SLCImageInfoFilePath = initStringWith4Strings(directoryPath,"/", directoryContent[i], "/Info/SLCImageInfo.txt") ;
            infoImage = readInfoImageFromTextFile(SLCImageInfoFilePath) ;
            oldName = initStringWith3Strings(directoryPath, "/", directoryContent[i]) ;
            newName = initStringWith4Strings(directoryPath, "/", infoImage->acquisitionDate, ".csl") ;
            
            if (rename(oldName, newName))
                printf("Failed to rename %s \n", directoryContent[i]) ;
            
            
        /* No need anymore since the acquisition date in a format YYYYMMDD has been integrated in for all readers */
            
        /*    if (!strncmp(infoImage->sensor_id, "ERS", 3))
            {
                newName = initStringWith4Strings(directoryPath, "/", renameCSLFileWithDateForERS(infoImage->acquisitionDate), ".csl") ;
                if (rename(oldName, newName))
                    printf("Failed to rename %s \n", directoryContent[i]) ;
            }
            else if(!strncmp(infoImage->sensor_id, "CSK", 3))
            {
                newName = initStringWith4Strings(directoryPath, "/", renameCSLFileWithDateForCSK(infoImage->scene_id), ".csl") ;
                if (rename(oldName, newName))
                    printf("Failed to rename %s \n", directoryContent[i]) ;
            }
            else if(!strncmp(infoImage->sensor_id, "ENVISAT", 7))
            {
                newName = initStringWith4Strings(directoryPath, "/", renameCSLFileWithDateForEnviSAT(infoImage->scene_id), ".csl") ;
                if (rename(oldName, newName))
                    printf("Failed to rename %s \n", directoryContent[i]) ;
            }
            else if (!strncmp(infoImage->sensor_id, "S1", 2))
            {
                newName = initStringWith4Strings(directoryPath, "/", renameCSLFileWithDateForS1(infoImage->scene_id), ".csl") ;
                if (rename(oldName, newName))
                    printf("Failed to rename %s \n", directoryContent[i]) ;
            }
            else if (!strncmp(infoImage->sensor_id, "TSX", 3) || !strncmp(infoImage->sensor_id, "TDX", 3))
            {
                newName = initStringWith4Strings(directoryPath, "/", renameCSLFileWithDateForTSX(infoImage->scene_id), ".csl") ;
                if (rename(oldName, newName))
                    printf("Failed to rename %s \n", directoryContent[i]) ;
            }
            else
            {
                printf("The routine does not support this sensor.\n") ;
            }*/
        
        }
    }
}


/* FOR CSK sceneID format */
char *renameCSLFileWithDateForCSK(char *sceneID)
{
    char *newName ;
    
    if((newName = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for newName \n") ;
    sscanf(sceneID, "%*5s_%*3s_%*1s_%*2s_%*2s_%*2s_%*2s_%*2s_%8s", newName) ;

    return newName ;
}


/* FOR EnviSAT sceneID format */
char *renameCSLFileWithDateForEnviSAT(char *sceneID)
{
    char *newName, *YYYY, *MMM, *DD ;
    
    if((YYYY = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Year \n") ;
    if((MMM = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Month \n") ;
    if((DD = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Day \n") ;
    
    sscanf(sceneID, "%*5s %*6s %2s-%3s-%4s", DD, MMM, YYYY) ;
    monthConversion(MMM) ;
    newName = initStringWith3Strings(YYYY, MMM, DD) ;
    
    
    free(YYYY) ;
    free(MMM) ;
    free(DD) ;
    
    return newName ;
}


/* FOR Sentinel1 sceneID format */
char *renameCSLFileWithDateForS1(char *sceneID)
{
    char *newName, *DD, *MM, *YYYY ;

    if((YYYY = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Year \n") ;
    if((MM = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Month \n") ;
    if((DD = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Day \n") ;
    
    sscanf(sceneID, "Acquisition date = %4s-%2s-%2s", YYYY, MM, DD) ;
    newName = initStringWith3Strings(YYYY, MM, DD) ;
    
    free(YYYY) ;
    free(MM) ;
    free(DD) ;
    
    return newName ;
}


/* FOR TerraSAR-X and Tandem-X sceneID format */
char *renameCSLFileWithDateForTSX(char *sceneID)
{
    char *newName, *DD, *MM, *YYYY ;
    
    if((YYYY = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Year \n") ;
    if((MM = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Month \n") ;
    if((DD = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Day \n") ;
    
    sscanf(sceneID, "%*25s_%4s-%2s-%2s", YYYY, MM, DD) ;
    newName = initStringWith3Strings(YYYY, MM, DD) ;
    
    free(YYYY) ;
    free(MM) ;
    free(DD) ;
    
    return newName ;
}


/* FOR ERS sceneID format */
char *renameCSLFileWithDateForERS(char *sceneID)
{
    char *newName, *DD, *MMM, *YYYY ;
    
    if((YYYY = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Year \n") ;
    if((MMM = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Month \n") ;
    if((DD = (char *)malloc(sizeof(char))) == NULL)
        ase("Failed to allocate a char array for scene ID Day \n") ;
    
    sscanf(sceneID, "%2s-%3s-%4s", DD, MMM, YYYY) ;
    monthConversion(MMM) ;
    newName = initStringWith3Strings(YYYY, MMM, DD) ;

    free(YYYY) ;
    free(MMM) ;
    free(DD) ;
    
    return newName ;

}


void monthConversion(char *MMM)
{
    
    if (!strncmp(MMM, "JAN", 3) || !strncmp(MMM, "Jan", 3)) {
        strcpy(MMM, "01") ;
    }
    else if (!strncmp(MMM, "FEB",3) || !strncmp(MMM, "Feb", 3)){
        strcpy(MMM, "02") ;
    }
    else if (!strncmp(MMM, "MAR", 3) || !strncmp(MMM, "Mar", 3)){
        strcpy(MMM, "03") ;
    }
    else if (!strncmp(MMM, "APR", 3) || !strncmp(MMM, "Apr", 3)){
        strcpy(MMM, "04") ;
    }
    else if (!strncmp(MMM, "MAY", 3) || !strncmp(MMM, "May", 3)){
        strcpy(MMM, "05") ;
    }
    else if (!strncmp(MMM, "JUN", 3) || !strncmp(MMM, "Jun", 3)){
        strcpy(MMM, "06") ;
    }
    else if (!strncmp(MMM, "JUL", 3) || !strncmp(MMM, "Jul", 3)){
        strcpy(MMM, "07") ;
    }
    else if (!strncmp(MMM, "AUG", 3) || !strncmp(MMM, "Aug", 3)){
        strcpy(MMM, "08") ;
    }
    else if (!strncmp(MMM, "SEP", 3) || !strncmp(MMM, "Sep", 3)){
        strcpy(MMM, "09") ;
    }
    else if (!strncmp(MMM, "OCT", 3) || !strncmp(MMM, "Oct", 3)){
        strcpy(MMM, "10") ;
    }
    else if (!strncmp(MMM, "NOV", 3) || !strncmp(MMM, "Nov", 3)){
        strcpy(MMM, "11") ;
    }
    else if (!strncmp(MMM, "DEC", 3) || !strncmp(MMM, "Dec", 3)){
        strcpy(MMM, "12") ;
    }
    else{
        ase("Month in the scene ID cannot be converted \n");
    }
    
}