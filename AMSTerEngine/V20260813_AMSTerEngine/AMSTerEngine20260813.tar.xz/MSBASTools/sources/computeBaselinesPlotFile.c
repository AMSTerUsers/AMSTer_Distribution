
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  computeBaselinesPlotFile
//
//  Created by Ludivine Libert on 14/09/16.
//  Copyright (c) 2016 Ludivine Libert. All rights reserved.
//
// This routine is meant to compute a file with the necessary information to build a baseline plot.
// The baseline plot is done with a script using gnuplot.

#include <stdio.h>
#include "fileAccessLib.h"


void usage(void) ;



int main(int argc, const char * argv[]) {
    
    int delay, Bsm, ti, t0 ;
    int slaveName, masterName ;
    double Boi, Bos ;
    char *pathToSelectedPairs, *pathToInitBaselines, *pathToPlotFile ;
    
    FILE *selectedPairs, *initBaselines, *plotFile ;
    time_t startTime, endTime;
    
    if (argc == 1 || argc > 2)
        usage() ;
    
    if (isArgumentPresent(argc, argv, "-help"))
        usage() ;
    
    
    time(&startTime) ;
    
    /* Path to the file with the selected pairs */
    pathToSelectedPairs = (char *)argv[1] ;
    /* Path to the file with the baselines for pairs t0-ti */
    pathToInitBaselines = initStringWith2Strings(getDirectoryPathFromPath(pathToSelectedPairs), "initBaselines.txt") ;
    /* Output file path */
    pathToPlotFile = initStringWith2Strings(getDirectoryPathFromPath(pathToSelectedPairs), "dataBaselinesPlot.txt") ;
    /* Opening the files */
    selectedPairs = fopen(pathToSelectedPairs, "r") ;
    initBaselines = fopen(pathToInitBaselines, "r") ;
    plotFile = fopen(pathToPlotFile, "w") ;
    
    
    fseek(initBaselines, 0, SEEK_SET) ;
    fscanf(initBaselines, "%d ", &t0) ;
    fgets(aComment, _MAX_COMMENT_LENGTH_, selectedPairs) ;
    fgets(aComment, _MAX_COMMENT_LENGTH_, selectedPairs) ;

    /* Every interferometric pair of the given table is considered */
    while (fgets(aComment, _MAX_COMMENT_LENGTH_, selectedPairs)) {
        sscanf(aComment, "%d %d %d %d", &slaveName, &masterName, &Bsm, &delay) ;
        if (slaveName == t0)
            Bos = 0 ;
        
        else {
            /* Initialization */
            ti = 0 ;
            Boi = Bos = 0 ;
            
            /* For each pair, the initBaselines.txt file must be read from the begining */
            fseek(initBaselines, 0, SEEK_SET) ;
            
            /* The initBaselines.txt file is scanned to find the Bos value corresponding to the slave acquisition */
            while (fgets(aComment, _MAX_COMMENT_LENGTH_, initBaselines)) {
                sscanf(aComment, "%*d %d %lf", &ti, &Boi) ;
                if (ti == slaveName) {
                    Bos = Boi ;
                    break ;
                }
            }
            if (!ti) {
                sprintf(ertex, "Can't find corresponding pair for acquisition %d in initBaselines.txt !\n", slaveName) ;
                ase(ertex) ;
            }
        }
        
        
        /* Information needed for a "with vectors" plot are saved for each pair in the same file*/
        /* (t, x, dt, dx ) */
        /* x = 0 for the t0 acquisitions and Bos for the other acquisitions (baseline between acquisitions at time t0 and ti)*/
        fprintf(plotFile, "%d\t\t%lf\t\t%d\t\t%d\n", slaveName, Bos, delay * 86400, Bsm) ;
    }
    
    fclose(plotFile) ;
    fclose(initBaselines) ;
    fclose(selectedPairs) ;
    time(&endTime) ;
    duration(startTime, endTime) ;
    
    return 0;
}


void usage(void)
{
    printf("\nUsage:\n\n\t computeBaselinesPlotFile \t /pathTo/table_Bmax_maxDelay.txt\n\n") ;
    printf("If the path to the table of selected interferometric pairs is given, the routine will create a data file for a \"Baseline vs Time\" graph with gnuplot script using vector plot. The table and the initBaselines.txt file must be in the same directory.\n\n") ;
    
    exit(0) ;
}
