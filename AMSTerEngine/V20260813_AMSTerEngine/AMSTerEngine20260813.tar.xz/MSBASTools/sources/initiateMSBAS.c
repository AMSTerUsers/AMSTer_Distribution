
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  initMSBAS
//
//  Created by Ludivine Libert on 10/07/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#include <stdio.h>
#include "initMSBAS.h"

int main(int argc, const char * argv[]) {
    
    keyValue *parametersList ;
    
    char *directoryPath, *path, *buffer ;
    int numberOfSets, numberOfNewSets, totalNumberOfImages ;
    
    
    if(argc == 1 || argc > 4)
        usage() ;
    
    if (isArgumentPresent(argc, argv, "-help"))
        usage() ;
    
    if (isArgumentPresent(argc, argv, "-create"))
    {
        createMSBASParametersFileAtPath((char *)argv[1]) ;
        exit(0) ;
    }
    
    parametersList = readParameterFileAtPath((char *)argv[1]) ;
    numberOfSets = getIntValForKeyIn(parametersList, "Number of sets") ;
    totalNumberOfImages = getIntValForKeyIn(parametersList, "Total") ;
    path = getStringValForKeyIn(parametersList, "Path") ;
    directoryPath = initStringWith2Strings(path, "/MSBAS") ;
    
    
    if (isArgumentPresent(argc, argv, "-newSet"))
    {
        if(argc == 4){
            buffer = (char *)argv[3] ;
            sscanf(buffer, "%d", &numberOfNewSets) ;
        }

        else if (argc == 3)
            numberOfNewSets = 1 ;
        
        else
            ase("Check your arguments !") ;
        
        addNewSetsDirectories(directoryPath, numberOfSets, numberOfNewSets) ;
        numberOfSets += numberOfNewSets ;
        updateMSBASParametersFileAtPath((char *)argv[1], path, numberOfSets, totalNumberOfImages) ;
    }
    else
        createMSBASDirectoryStructureAtPath(directoryPath, numberOfSets) ;

    return 0;
}


void usage()
{

    printf("\nUsage : \n\n\tinitMSBAS /pathTo/MSBASParametersFile.txt [-create] [-newSet numberOfNewSets] \n\n") ;
    printf("A MSBAS directory structure will be created at the path indicated in the parameters file according to the number of datasets.\n") ;
    printf("If adding the keyword \"-create\", a MSBAS parameters file will be created at the given path.\n") ;
    printf("Directories for new datasets can be created by adding the keyword \"-newSet\". The number of new sets can be given after the keyword. If not given, the default value is 1.\n\n") ;
    
    exit(0) ;
}


