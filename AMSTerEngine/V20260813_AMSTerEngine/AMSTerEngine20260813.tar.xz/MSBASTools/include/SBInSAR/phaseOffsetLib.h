
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  phaseOffsetLib.h
//  phaseOffsetUsingSBInSAR
//
//  Created by Ludivine Libert on 25/01/16.
//  Copyright (c) 2016 Ludivine Libert. All rights reserved.
//

#ifndef __phaseOffsetUsingSBInSAR__phaseOffsetLib__
#define __phaseOffsetUsingSBInSAR__phaseOffsetLib__

#include <stdio.h>
#include "paramLib.h"

typedef struct {
    
    char *specCohPath ;
    char *sigmaPath ;
    char *sigmaInterceptPath ;
    char *sigmaSlopePath ;
    char *R2Path ;
    char *QPath ;
    char *chi2Path ;
    char *mcaPhasePath ;
    rawFileDescriptor *specCohFile ;
    rawFileDescriptor *sigmaFile ;
    rawFileDescriptor *sigmaInterceptFile ;
    rawFileDescriptor *sigmaSlopeFile ;
    rawFileDescriptor *R2File ;
    rawFileDescriptor *QFile ;
    rawFileDescriptor *chi2File ;
    rawFileDescriptor *mcaPhaseFile ;
    
} MCAFiles ;


typedef struct {
    
    double minSpecCoh ;
    double maxSpecCoh ;
    double minSigma ;
    double maxSigma ;
    double minSigmaInt ;
    double maxSigmaInt ;
    double minSigmaSlope ;
    double maxSigmaSlope ;
    double minR2 ;
    double maxR2 ;
    double minReducedChi2 ;
    double maxReducedChi2 ;
    double minQ ;
    double maxQ ;
    
} mcaEstimatorsBounds;


void usage() ;
MCAFiles *allocAndInitMCAFilesStruct(char *directoryPath, keyValue *parametersList) ;
void freeMCAFilesStruct(MCAFiles *MCA) ;
int findZoneMax(unsigned int **zoneMap, int lena, int lenr) ;
void createPhaseOffsetFileAtPath(char *path) ;
mcaEstimatorsBounds *allocAndInitmcaEstimatorsBoundsStruct(keyValue *params) ;

#endif /* defined(__phaseOffsetUsingSBInSAR__phaseOffsetLib__) */
