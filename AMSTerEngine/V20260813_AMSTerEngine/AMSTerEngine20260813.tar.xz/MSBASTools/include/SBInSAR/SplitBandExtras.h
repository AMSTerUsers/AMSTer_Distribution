
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  SplitBandExtras.h
//  SBInSARbis
//
//  Created by Ludivine Libert on 16/12/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#ifndef __SBInSARbis__SplitBandExtras__
#define __SBInSARbis__SplitBandExtras__

#include <stdio.h>
#include "initMCA.h"
#include "subViewSplittingLib.h"
#include "matrix.h"
#include "vectors.h"
#include "fileAccessLib.h"
#include "rawFileLib.h"
#include "planeGeometry.h"
#include "gridMapping.h"
#include "byteSwap.h"
#include "orbitalPhase.h"
#include "matrixPile.h"


#endif /* defined(__SBInSARbis__SplitBandExtras__) */



void createQualityEstimatorFileAtPath(char *path) ;
void multiChromaticPhaseLinearRegressionWithOptions(keyValue *p, InSARParametersStruct *pInSAR, bandSplitStruct *bsp, char *estimatorFilePath) ;
void multiChromaticPhaseLinearRegressionWithSigmaSlope(keyValue *p, InSARParametersStruct *pInSAR, bandSplitStruct *bsp) ;
