
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  referencePoints.h
//  AbsolutePhaseReferences
//
//  Created by Ludivine Libert on 1/12/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#ifndef __AbsolutePhaseReferences__referencePoints__
#define __AbsolutePhaseReferences__referencePoints__

#include <stdio.h>
#include "paramLib.h"
#include "paramInSAR.h"


typedef struct{
    
    int x ;
    int y ;
    int unsigned zone ;
    char Ok ;
    
} referencePoint ;


typedef struct {
    
    char *InSARParametersFilePath ;
    char *SBInSARParametersFilePath ;
    rawFileDescriptor *referenceFile ;
    rawFileDescriptor *absoluteUnwrappedPhase ;
    int numberOfReferencePoints ;
    referencePoint *points ;
    char DEMRemoval ;
    
} referenceFile;

referenceFile *readReferenceFileStructureAtPath(char *path) ;
void freeReferenceFileStructure(referenceFile *ref) ;
void createReferencePointsFileAtPath(char *path, char *InSARParametersFilePath, char *SBInSARParametersFilePath, int n) ;
void saveReferencePointsFileAtPath(char *path, referenceFile *ref) ;
float *getAbsoluteResidualPhaseAtReferencePoints(referenceFile *ref, InSARParametersStruct *pInSAR) ;
float *getAbsolutePhaseAtReferencePoint(referenceFile *ref, InSARParametersStruct *pInSAR) ;
void addPhaseShiftToUnwrappedPhase(float *referencePhase, referenceFile *ref, InSARParametersStruct *pInSAR) ;


#endif /* defined(__AbsolutePhaseReferences__referencePoints__) */
