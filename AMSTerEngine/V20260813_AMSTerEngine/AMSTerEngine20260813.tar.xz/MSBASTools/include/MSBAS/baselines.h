
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  baselines.h
//  initiateBaselinesComputation
//
//  Created by Ludivine Libert on 24/08/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#ifndef __initiateBaselinesComputation__baselines__
#define __initiateBaselinesComputation__baselines__

#include <stdio.h>
#include "initMSBAS.h"


void usage(void) ;
void baselinesComputationForSetAtPath(char *setPath, char **setImagesContent, int numberOfImages) ;
void baselinesComputationForOnePair(char *setPath, char *slave, char *master) ;






#endif /* defined(__initiateBaselinesComputation__baselines__) */
