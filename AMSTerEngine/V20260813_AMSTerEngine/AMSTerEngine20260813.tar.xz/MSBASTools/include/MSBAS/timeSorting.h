
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  timeSorting.h
//  timeSorting
//
//  Created by Ludivine Libert on 15/06/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#ifndef timeSorting_timeSorting_h
#define timeSorting_timeSorting_h

#include "pourtous.h"
#include "infoImage.h"

void usage() ;
void renameCSLFilesInDirectoryAtPath(char *directoryPath) ;
char *renameCSLFileWithDateForCSK(char *sceneID) ;
char *renameCSLFileWithDateForEnviSAT(char *sceneID) ;
char *renameCSLFileWithDateForS1(char *sceneID) ;
char *renameCSLFileWithDateForTSX(char *sceneID) ;
char *renameCSLFileWithDateForERS(char *sceneID) ;
void monthConversion(char *MMM) ;


#endif
