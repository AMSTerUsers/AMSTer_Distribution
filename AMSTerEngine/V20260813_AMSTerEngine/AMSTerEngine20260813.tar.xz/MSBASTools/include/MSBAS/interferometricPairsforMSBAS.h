
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  interferometricPairsforMSBAS.h
//  interferometricPairsSelectionForMSBAS
//
//  Created by Ludivine Libert on 13/08/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#ifndef __interferometricPairsSelectionForMSBAS__interferometricPairsforMSBAS__
#define __interferometricPairsSelectionForMSBAS__interferometricPairsforMSBAS__

#include <stdio.h>
#include "initInSARParams.h"
#include "satRef.h"


typedef struct {
    
    int isBistatic ;
    int maxTemporalDelay ;
    int minTemporalDelay ;
    double minBaseline ;
    double maxBaseline ;
    int numberOfCSLImages ;
    int numberOFInterferograms ;
    char *pathToTriangleFile ;
    char *pathToInitBaselinesFile ;
    
} setParameters ;


typedef struct {
    
    char *slavePath ;
    char *masterPath ;
    double baseline ;
    double perpendicularBaseline ;
    double Bx ;
    double By ;
    int isBistatic ;
    int temporalDelay ;
    int isInterferometricPairSelected ;
    int slaveIndex ;
    int masterIndex ;
    
} interferometricPairParameters ;


void usage(void) ;
interferometricPairParameters *allocAnInterferometricPairParametersStructure(void) ;
void freeInterferometricPairParametersStructure(interferometricPairParameters *pairParams) ;
void createSetParametersFile(char *aPath) ;
setParameters *allocAndInitSetParametersStructure(keyValue *parametersList) ;
void saveSetParametersFileAtPath(char *aPath, char *globalMasterPath, setParameters *setParams) ;
void createPairFileAtPath(char *aPath) ;
void savePairFileAtPath(char *aPath, interferometricPairParameters *pairParams) ;
void readPairFileInfoAtPath(char *filePath, interferometricPairParameters *pairParams) ;
void baselineValueAtSceneCenter(InSARParametersStruct *pInSAR, interferometricPairParameters *pairParams) ;
int computeTemporalDelay(char *slavePath, char *masterPath) ;
int numberOfDaysForMonth(int month, int year) ;
void recordInterferometricPairsAtPath(char *filePath, interferometricPairParameters *pairParams, char *slaveName, char *masterName) ;






#endif /* defined(__interferometricPairsSelectionForMSBAS__interferometricPairsforMSBAS__) */
