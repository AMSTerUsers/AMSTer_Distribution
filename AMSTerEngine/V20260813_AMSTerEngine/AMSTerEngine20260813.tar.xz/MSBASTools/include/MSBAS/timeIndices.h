
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  timeIndices.h
//  timeIndices
//
//  Created by Ludivine Libert on 18/08/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#ifndef __timeIndices__timeIndices__
#define __timeIndices__timeIndices__

#include <stdio.h>
#include "initMSBAS.h"
#include "interferometricPairsforMSBAS.h"


void usage() ;
void sort(int n, double *array) ;
int sortImagesByAcquisitionDate(char *MSBASPath, int numberOfSets, double *imageContent) ;
int getInterferometricFilesContentAtPath(char *setPath, char **interferometricFilesContent) ;
int getPositionIndexOfFileInVector(double date, double *vector, int vectorDimension) ;



#endif /* defined(__timeIndices__timeIndices__) */
