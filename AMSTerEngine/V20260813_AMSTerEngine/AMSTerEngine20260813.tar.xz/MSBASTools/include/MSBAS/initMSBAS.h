
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  initMSBAS.h
//  initMSBAS
//
//  Created by Ludivine Libert on 10/07/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#ifndef initMSBAS_initMSBAS_h
#define initMSBAS_initMSBAS_h

#include "infoImage.h"
#include "fileAccessLib.h"
#include "interferometricPairsforMSBAS.h"

void usage(void) ;
void createMSBASParametersFileAtPath (char *aPath) ;
void updateMSBASParametersFileAtPath (char *aPath, char *directoryPath, int numberOfSets, int totalNumberOfImages) ;
void createMSBASDirectoryStructureAtPath(char *path, int numberOfSets) ;
void addNewSetsDirectories(char *path, int numberOfSets, int numberOfNewSets) ;


#endif
