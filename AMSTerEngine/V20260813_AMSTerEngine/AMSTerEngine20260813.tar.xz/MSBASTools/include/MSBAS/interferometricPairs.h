
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  interferometricPairs.h
//  interfermetricPairsSelection
//
//  Created by Ludivine Libert on 10/07/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#ifndef __interfermetricPairsSelection__interferometricPairs__
#define __interfermetricPairsSelection__interferometricPairs__

#include <stdio.h>
#include "infoImage.h"
#include "baselines.h"
#include "initMSBAS.h"


typedef struct {
    
    double DEMPrecision ;
    double deformationMeasurementAccuracy ;
    int isBistatic ;
    int maxTemporalDelay ;
    double minBaseline ;
    double maxBaseline ;
    int numberOfCSLImages ;
    int numberOFInterferograms ;
    
} setParameters ;


void usage(void) ;
void createInterferometricPairsSelectionParametersFile(char *aPath) ;
baselineParameters *baselineValueAtSceneCenter(InSARParametersStruct *pInSAR) ;
void saveInterferometricPairsSelectionParametersFileAtPath(char *aPath, char *globalMasterPath, setParameters *setParams) ;
void sort(int n, double *array) ;
int getPositionIndexOfFileInVector(double date, double *vector, int vectorDimension) ;
int sortImagesByAcquisitionDate(char *path, int numberOfSets, double *allCSLImages) ;
void interferometricPairsSelectionAndRecording(int numberOfSets, char *MSBASPath, double *allCSLImages, int totalNumberOfCSLImages) ;
char *globalMasterSelection(int numberOfCSLImages, double *averageBaselines, char **CSLImagesInDirectory, char *setPath) ;



#endif /* defined(__interfermetricPairsSelection__interferometricPairs__) */
