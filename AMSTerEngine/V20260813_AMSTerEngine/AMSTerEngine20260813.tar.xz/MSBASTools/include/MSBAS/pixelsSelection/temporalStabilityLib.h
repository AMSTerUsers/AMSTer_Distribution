
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  temporalStabilityLib.h
//  temporalStability
//
//  Created by Ludivine Libert on 27/07/16.
//  Copyright (c) 2016 Ludivine Libert. All rights reserved.
//

#ifndef __temporalStability__temporalStabilityLib__
#define __temporalStability__temporalStabilityLib__

#include <stdio.h>

void usage() ;
int deltaTime(char *masterIndex, char *slaveIndex) ;
float temporalStabilityEstimatorForLinearDeformationModel(int dim, float *phi, float *lambda, int *deltaT, float *Bperp, float *range, float *incidenceAngle, float *v) ;
void derivatesForLinearDeformationModel(int dim, float *phi, float *lambda, int *deltaT, float *Bperp, float *range, float *incidenceAngle, float *v, float *df)
;

float func(int dim, float *phi, float *lambda, int *deltaT, float *Bperp, float *range, float *incidenceAngle, float v[]) ;
void dfunc(int dim, float *phi, float *lambda, int *deltaT, float *Bperp, float *range, float *incidenceAngle, float v[], float df[]) ;



#endif /* defined(__temporalStability__temporalStabilityLib__) */
