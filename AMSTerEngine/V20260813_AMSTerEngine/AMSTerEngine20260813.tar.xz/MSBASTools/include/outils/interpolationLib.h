
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  interpolationLib.h
//  interpolateDataSet
//
//  Created by Ludivine Libert on 21/03/17.
//  Copyright © 2017 Ludivine Libert. All rights reserved.
//

#ifndef interpolationLib_h
#define interpolationLib_h

#include <stdio.h>
#include "paramLib.h"


void fillGapsWithInterpolationInImage(float **image, float **interpolatedImage, int dimx, int dimy) ;
void fillGapsWithInterpolationInImageExcludingZeros(float **image, float **interpolatedImage, int dimx, int dimy) ;
void polin2(float *x1a, float *x2a, float **ya, int m, int n, float x1, float x2, float *y, float *dy) ;
void polint(float *xa,float  *ya, int n, float x, float *y, float *dy) ;






#endif /* interpolationLib_h */
