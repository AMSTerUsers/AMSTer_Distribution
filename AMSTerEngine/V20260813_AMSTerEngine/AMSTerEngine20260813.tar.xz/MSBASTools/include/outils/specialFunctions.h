
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  specialFunctions.h
//  SBInSARbis
//
//  Created by Ludivine Libert on 10/02/16.
//  Copyright (c) 2016 Ludivine Libert. All rights reserved.
//

#ifndef __SBInSARbis__specialFunctions__
#define __SBInSARbis__specialFunctions__

#include <stdio.h>
#include <math.h>

#define ITMAX 100
#define EPS 3.0e-7

float gammln(float xx) ;
void gcf(float *gammcf, float a, float x, float *gln) ;
void gser(float *gamser, float a, float x, float *gln) ;
float gammq(float a, float x) ;





#endif /* defined(__SBInSARbis__specialFunctions__) */
