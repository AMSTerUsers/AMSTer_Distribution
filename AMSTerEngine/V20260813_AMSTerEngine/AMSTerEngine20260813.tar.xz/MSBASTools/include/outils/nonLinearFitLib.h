
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  nonLinearFitLib.h
//  splitBandStatisticAnalysis
//
//  Created by Ludivine Libert on 31/08/16.
//  Copyright (c) 2016 Ludivine Libert. All rights reserved.
//
// This library contains the material to compute the
// Levenberg-Marquardt method for fitting non linear model
// All routines come from Numerical Recipes in C

#ifndef __splitBandStatisticAnalysis__nonLinearFitLib__
#define __splitBandStatisticAnalysis__nonLinearFitLib__

#include <stdio.h>

void covsrt(float **covar, int ma, int *ia, int mfit) ;
void gaussj(float **a, int n, float **b, int m) ;
void mrqcof(float *x, float *y, float *sig, int ndata, float *a, int *ia, int ma, float **alpha, float *beta, float *chisq, void (*funcs)(float, float *, float *, float *, int)) ;
void mrqmin(float *x, float *y, float *sig, int ndata, float *a, int *ia, int ma, float **covar, float **alpha, float *chisq, void (*funcs)(float, float *, float *, float *, int), float *alamda) ;




#endif /* defined(__splitBandStatisticAnalysis__nonLinearFitLib__) */
