
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  statistics.h
//  statisticAnalysisForSBInSAR
//
//  Created by Ludivine Libert on 8/01/16.
//  Copyright (c) 2016 Ludivine Libert. All rights reserved.
//

#ifndef __statisticAnalysisForSBInSAR__statistics__
#define __statisticAnalysisForSBInSAR__statistics__

#include <stdio.h>
#include "paramInSAR.h"
#include "matrixObjects.h"


int roundToInt(double x) ;
double min(float **distribution, int lena, int lenr) ;
double max(float **distribution, int lena, int lenr) ;
floatMatrix *distributionStat(float **distribution, int lena, int lenr, char histoYes, char *isMultimodal) ;
float normalLawFitAndRatioComputationForDistribution(floatMatrix *mat) ;



#endif 
