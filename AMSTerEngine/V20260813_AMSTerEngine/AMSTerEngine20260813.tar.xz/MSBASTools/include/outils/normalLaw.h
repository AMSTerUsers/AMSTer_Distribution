
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  normalLaw.h
//  splitBandStatisticAnalysis
//
//  Created by Ludivine Libert on 1/09/16.
//  Copyright (c) 2016 Ludivine Libert. All rights reserved.
//

#ifndef __splitBandStatisticAnalysis__normalLaw__
#define __splitBandStatisticAnalysis__normalLaw__

#include <stdio.h>
#include <math.h>
#include "pourtous.h"

void normalLaw(float x, float *a, float *y, float *dyda, int ma) ;



#endif /* defined(__splitBandStatisticAnalysis__normalLaw__) */
