
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  multiDimMinimizationLib.h
//  temporalStability
//
//  Created by Ludivine Libert on 28/07/16.
//  Copyright (c) 2016 Ludivine Libert. All rights reserved.
//

#ifndef __temporalStability__multiDimMinimizationLib__
#define __temporalStability__multiDimMinimizationLib__

void mnbrak(float *ax, float *bx, float *cx, float *fa, float *fb, float *fc, int n, float *phi, float *lambda, int *deltaT, float *Bperp, float *range, float *incidenceAngle, float (*func)(float, int, float *, float *, int *, float *, float *, float *)) ;
float brent (float ax, float bx, float cx, int n, float *phi, float *lambda, int *deltaT, float *Bperp, float *range, float *incidenceAngle, float (*f)(float, int, float *, float *, int *, float *, float *, float *), float tol, float *xmin) ;
void linmin(float *p, float *xi, int n, float *fret, float *phi, float *lambda, int *deltaT, float *Bperp, float *range, float *incidenceAngle, float (*func)(int, float *, float *, int *, float *, float *, float *, float *)) ;
float f1dim(float x, int n, float *phi, float *lambda, int *deltaT, float *Bperp, float *range, float *incidenceAngle) ;
void frprmn(float p[], int n, float ftol, int *iter, float *fret, float *phi, float *lambda, int *deltaT, float *Bperp, float *range, float *incidenceAngle, float (*func)(int, float *, float *, int *, float *, float *, float *, float *), void (*dfunc)(int, float *, float *, int *, float *, float *, float *, float *, float *)) ;
void powell (float *p, float **xi, int n, float ftol, int *iter, float *fret, float *phi, float *lambda, int *deltaT, float *Bperp, float *range, float *incidenceAngle, float (*func)(int, float *, float *, int *, float *, float *, float *, float *)) ;

#endif /* defined(__temporalStability__multiDimMinimizationLib__) */
