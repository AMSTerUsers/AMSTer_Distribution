
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  averageCoherenceLib.h
//  coherenceAverage
//
//  Created by Ludivine Libert on 13/07/16.
//  Copyright (c) 2016 Ludivine Libert. All rights reserved.
//

#ifndef __coherenceAverage__averageCoherenceLib__
#define __coherenceAverage__averageCoherenceLib__

#include <stdio.h>
#include "paramInSAR.h"


void averageCoherenceThreshold(InSARParametersStruct *pInSAR) ;


#endif /* defined(__coherenceAverage__averageCoherenceLib__) */



