
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  miscellaneous.h
//  pointsCoordinatesInGeoprojectionFrame
//
//  Created by Ludivine Libert on 2/06/17.
//  Copyright © 2017 Ludivine Libert. All rights reserved.
//

#ifndef miscellaneous_h
#define miscellaneous_h

#include <stdio.h>

int countLinesInTextFile(FILE *textfile) ;


#endif /* miscellaneous_h */
