
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  interpolationLib.c
//  interpolateDataSet
//
//  Created by Ludivine Libert on 21/03/17.
//  Copyright © 2017 Ludivine Libert. All rights reserved.
//

#include "interpolationLib.h"

/* Given an input image - typically a deformation map - the routine attempts to fill the pixels with NaN using basic interpolation */
/* Three conditions are explored based on the availability of data in the nearest neighbours. In the three cases, the interpolation */
/* comes down to an averaging of the values at the nearest neighbours. */
void fillGapsWithInterpolationInImage(float **image, float **interpolatedImage, int dimx, int dimy)
{
    int i, j ;
    int countCase1, countCase2, countCase3 ;
    
    genFloatNaN() ;
    
    countCase1 = countCase2 = countCase3 = 0 ;
    
    /* Corners can never be interpolated */
    interpolatedImage[0][0] = interpolatedImage[0][dimx-1] = interpolatedImage[dimy-1][0] = interpolatedImage[dimy-1][dimx-1] =floatNaN ;
    
    /* The edges are considered after */
    for (i = 1 ; i < dimy-1 ; i++)
    {
        for (j = 1 ; j < dimx-1 ; j++)
        {
            /* if the pixel in the image has a NaN value, then we attempt to interpolate it */
            if (isnan(image[i][j]))
            {
                /* Case 1: if the 4 direct neighbours along x and y are defined, the pixel is assigned with the mean value of the four */
                if (!isnan(image[i-1][j]) && !isnan(image[i+1][j]) && !isnan(image[i][j-1]) && !isnan(image[i][j+1]))
                {
                    interpolatedImage[i][j] = (image[i-1][j] + image[i+1][j] + image[i][j-1] + image[i][j+1]) / 4. ;
                    countCase1 ++ ;
                }
                
                /* Case 2 : if at least one of the direct neighbours is not defined, then we look after the second nearest neighbours */
                /* These are the summit of a square with the pixel at the center. We use a bilinear interpolation in this case */
                /* In this particular case, the bilinear interpolation is just an average of the image values at the four points */
                else if (!isnan(image[i-1][j-1]) && !isnan(image[i-1][j+1]) && !isnan(image[i+1][j-1]) && !isnan(image[i+1][j+1]))
                 {
                     interpolatedImage[i][j] = (image[i-1][j-1] + image[i-1][j+1] + image[i+1][j-1] + image[i+1][j+1]) / 4. ;
                     countCase2 ++ ;
                 }
                
                /* Case 3 : Finally, if none of the previous case is adequate, then we look for two direct neighbours on the same line */
                /* i.e. along x or along y, and we apply a linear interpolation along this dimensions. It is actually the mean of both values */
                /* Linear interpolation along y */
                else if (!isnan(image[i-1][j]) && !isnan(image[i+1][j]))
                {
                    interpolatedImage[i][j] = (image[i-1][j] + image[i+1][j]) / 2. ;
                    countCase3 ++ ;
                }
                /* Linear interpolation along x */
                else if (!isnan(image[i][j-1]) && !isnan(image[i][j+1]))
                {
                    interpolatedImage[i][j] = (image[i][j-1] + image[i][j+1]) / 2. ;
                    countCase3 ++ ;
                }
                /* Finally, if none of these configurations can be applied, the pixel is not interpolated */
                else
                    interpolatedImage[i][j] = floatNaN ;
                
                
            }
            else
                interpolatedImage[i][j] = image[i][j] ;
            
        }
    }
    
    /* Pixels on the edges can only be interpolated using the third case in the direction parallel to the edge */
    /* Edges in the y direction */
    for (i = 1 ; i < dimy-1 ; i ++)
    {
        if (isnan(image[i][0]))
        {
            if (!isnan(image[i-1][0]) && !isnan(image[i+1][0]))
            {
                interpolatedImage[i][0] = (image[i-1][0] + image[i+1][0]) / 2. ;
                countCase3 ++ ;
            }
            else
                interpolatedImage[i][0] = floatNaN ;
        }
        else
            interpolatedImage[i][0] = image[i][0] ;
        
        if (isnan(image[i][dimx-1]))
        {
            if (!isnan(image[i-1][dimx-1]) && !isnan(image[i+1][dimx-1]))
            {
                interpolatedImage[i][dimx-1] = (image[i-1][dimx-1] + image[i+1][dimx-1]) / 2. ;
                countCase3 ++ ;
            }
            else
                interpolatedImage[i][dimx-1] = floatNaN ;
        }
        else
            interpolatedImage[i][dimx-1] = image[i][dimx-1] ;
    }
    
    /* Edges in the x direction */
    for (j = 1 ; j < dimx-1 ; j ++)
    {
        if (isnan(image[0][j]))
        {
            if (!isnan(image[0][j-1]) && !isnan(image[0][j+1]))
            {
                interpolatedImage[0][j] = (image[0][j-1] + image[0][j+1]) / 2. ;
                countCase3 ++ ;
            }
            else
                interpolatedImage[0][j] = floatNaN ;
        }
        else
            interpolatedImage[0][j] = image[0][j] ;

        if (isnan(image[dimy-1][j]))
        {
            if (!isnan(image[dimy-1][j-1]) && !isnan(image[dimy-1][j+1]))
            {
                interpolatedImage[dimy-1][j] = (image[dimy-1][j-1] + image[dimy-1][j+1]) / 2. ;
                countCase3 ++ ;
            }
            else
                interpolatedImage[dimy-1][j] = floatNaN ;
        }
        else
            interpolatedImage[dimy-1][j] = image[dimy-1][j] ;
    }
    
//    printf("Case 1 : %d pixels \n", countCase1) ;
//    printf("Case 2 : %d pixels \n", countCase2) ;
//    printf("Case 3 : %d pixels \n", countCase3) ;
    printf("%d interpolated pixels \n", countCase1+countCase2+countCase3) ;
}



void fillGapsWithInterpolationInImageExcludingZeros(float **image, float **interpolatedImage, int dimx, int dimy)
{
    int i, j ;
    int countCase1, countCase2, countCase3 ;
    
    genFloatNaN() ;
    
    countCase1 = countCase2 = countCase3 = 0 ;
    
    /* Corners can never be interpolated */
    interpolatedImage[0][0] = interpolatedImage[0][dimx-1] = interpolatedImage[dimy-1][0] = interpolatedImage[dimy-1][dimx-1] = 0. ;
    
    /* The edges are considered after */
    for (i = 1 ; i < dimy-1 ; i++)
    {
        for (j = 1 ; j < dimx-1 ; j++)
        {
            /* if the pixel in the image has a zero value, then we attempt to interpolate it */
            if (!image[i][j])
            {
                /* Case 1: if the 4 direct neighbours along x and y are defined, the pixel is assigned with the mean value of the four */
                if (image[i-1][j] && image[i+1][j] && image[i][j-1] && image[i][j+1])
                {
                    interpolatedImage[i][j] = (image[i-1][j] + image[i+1][j] + image[i][j-1] + image[i][j+1]) / 4. ;
                    countCase1 ++ ;
                }
                
                /* Case 2 : if at least one of the direct neighbours is not defined, then we look after the second nearest neighbours */
                /* These are the summit of a square with the pixel at the center. We use a bilinear interpolation in this case */
                /* In this particular case, the bilinear interpolation is just an average of the image values at the four points */
                else if (image[i-1][j-1] && image[i-1][j+1] && image[i+1][j-1] && image[i+1][j+1])
                {
                    interpolatedImage[i][j] = (image[i-1][j-1] + image[i-1][j+1] + image[i+1][j-1] + image[i+1][j+1]) / 4. ;
                    countCase2 ++ ;
                }
                
                /* Case 3 : Finally, if none of the previous case is adequate, then we look for two direct neighbours on the same line */
                /* i.e. along x or along y, and we apply a linear interpolation along this dimensions. It is actually the mean of both values */
                /* Linear interpolation along y */
                else if (image[i-1][j] && image[i+1][j])
                {
                    interpolatedImage[i][j] = (image[i-1][j] + image[i+1][j]) / 2. ;
                    countCase3 ++ ;
                }
                /* Linear interpolation along x */
                else if (image[i][j-1] && image[i][j+1])
                {
                    interpolatedImage[i][j] = (image[i][j-1] + image[i][j+1]) / 2. ;
                    countCase3 ++ ;
                }
                /* Finally, if none of these configurations can be applied, the pixel is not interpolated */
                else
                    interpolatedImage[i][j] = 0. ;
                
                
            }
            else
                interpolatedImage[i][j] = image[i][j] ;
            
        }
    }
    
    /* Pixels on the edges can only be interpolated using the third case in the direction parallel to the edge */
    /* Edges in the y direction */
    for (i = 1 ; i < dimy-1 ; i ++)
    {
        if (image[i][0])
        {
            if (image[i-1][0] && image[i+1][0])
            {
                interpolatedImage[i][0] = (image[i-1][0] + image[i+1][0]) / 2. ;
                countCase3 ++ ;
            }
            else
                interpolatedImage[i][0] = 0. ;
        }
        else
            interpolatedImage[i][0] = image[i][0] ;
        
        if (image[i][dimx-1])
        {
            if (image[i-1][dimx-1] && image[i+1][dimx-1])
            {
                interpolatedImage[i][dimx-1] = (image[i-1][dimx-1] + image[i+1][dimx-1]) / 2. ;
                countCase3 ++ ;
            }
            else
                interpolatedImage[i][dimx-1] = 0. ;
        }
        else
            interpolatedImage[i][dimx-1] = image[i][dimx-1] ;
    }
    
    /* Edges in the x direction */
    for (j = 1 ; j < dimx-1 ; j ++)
    {
        if (image[0][j])
        {
            if (image[0][j-1] && image[0][j+1])
            {
                interpolatedImage[0][j] = (image[0][j-1] + image[0][j+1]) / 2. ;
                countCase3 ++ ;
            }
            else
                interpolatedImage[0][j] = 0. ;
        }
        else
            interpolatedImage[0][j] = image[0][j] ;
        
        if (image[dimy-1][j])
        {
            if (image[dimy-1][j-1] && image[dimy-1][j+1])
            {
                interpolatedImage[dimy-1][j] = (image[dimy-1][j-1] + image[dimy-1][j+1]) / 2. ;
                countCase3 ++ ;
            }
            else
                interpolatedImage[dimy-1][j] = 0. ;
        }
        else
            interpolatedImage[dimy-1][j] = image[dimy-1][j] ;
    }
    
    printf("%d interpolated pixels \n", countCase1+countCase2+countCase3) ;
}





/* !!! Not tested !!! */
/* Bilinear interpolation in two dimensions */
/* From Numerical Recipes in C, p. 106 */
/* Given x1a[0...m-1] and x2a[0...n-1] vectors of independent variables, and a submatrix of function value ya[0...m-1][0...n-1] */
/* and given the values x1 and x2 of the dependent variables, this routine returns an interpolated function y and an accuracy iindication dy. */
void polin2(float *x1a, float *x2a, float **ya, int m, int n, float x1, float x2, float *y, float *dy)
{
    int j ;
    float *ymtmp ;
    
    ymtmp = vectorFloat(0, m-1) ;
    for (j = 0 ; j < m ; j++)
        polint(x2a, ya[j], n, x2, &ymtmp[j], dy) ;

    polint(x1a, ymtmp, m, x1, y, dy) ;

    freeVectorFloat(ymtmp, 0) ;
}


/* !!! Not tested !!! */
/* Polynomial interpolation */
/* From Numerical Recipes in C, p. 90 */
/* Given xa[0...n-1] and ya[0...n-1] and given a value x, this routine returns a value y and an error estimate dy. */
/* If P(x) is the polynomial of degree n-1 such that P(xa[i]) = ya[i], then the returned value is y = P(x)  */
void polint(float *xa,float  *ya, int n, float x, float *y, float *dy)
{
    int i, m, ns ;
    float den, dif, dift, ho, hp, w ;
    float *c, *d ;
    
    ns = 0 ;
    
    /* Vectors declaration */
    c = vectorFloat(0, n-1) ;
    d = vectorFloat(0, n-1) ;
    
    dif = fabs(x - xa[0]) ;

    for (i = 0 ; i < n ; i++)
    {
        /* Find the index ns of the nearest neighbour */
        dift = fabs(x - xa[i]) ;
        if (dift < dif)
        {
            ns = i ;
            dif = dift ;
        }
        /* Initialize c and d vectors */
        c[i] = ya[i] ;
        d[i] = ya[i] ;
        
    }
    
    /* Initial approximation to y */
    *y = ya[ns--] ;
    
    for (m = 0 ; m < n ; m++)
    {
        for (i = 0 ; i <= n - m ; i++)  /* ????????????????????????? */
        {
            ho = xa[i] - x ;
            hp = xa[i+m] - x ;
            w = c[i+1] - d[i] ;
            den = ho - hp ;
            /* Happens if two xa's entries are identical */
            if (den == 0.0)
                ase("Error in routine POLINT.\n") ;
            den = w / den ;
            /* update of c and d */
            d[i] = hp * den ;
            c[i] = ho * den ;
            
        }
        *dy = (2 * ns < (n-m) ? c[ns+1] : d[ns--]) ;
        *y += *dy ;
    }
    
    freeVectorFloat(c, 0) ;
    freeVectorFloat(d, 0) ;
}
