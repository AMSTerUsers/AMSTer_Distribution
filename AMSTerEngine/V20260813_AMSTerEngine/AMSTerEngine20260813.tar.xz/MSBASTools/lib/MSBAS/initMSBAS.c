
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  initMSBAS.c
//  initMSBAS
//
//  Created by Ludivine Libert on 10/07/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#include <stdio.h>
#include "initMSBAS.h"

void createMSBASParametersFileAtPath (char *aPath)
{
    keyValue *parametersList ;
    
    parametersList = allocAKeyValuePair() ;
    
    setStringValForKeyIn(parametersList, "MSBAS Initialization parameter file", "") ;
    setStringValForKeyIn(parametersList, "***********************************", "") ;
    setStringValForKeyIn(parametersList, "directoryPath", "Path to MSBAS directory") ;
    setIntValForKeyIn(parametersList, 0, "Number of sets for MSBAS processing") ;
    setIntValForKeyIn(parametersList, 0, "Total number of CSL images in all sets") ;
    setStringValForKeyIn(parametersList, "", "") ;
    setStringValForKeyIn(parametersList, "The total number of CSL images can be replaced by a maximum number of images", "") ;
    
    writeParameterFileAtPath(parametersList, aPath) ;
    freeKeyValueList(parametersList) ;
}


void updateMSBASParametersFileAtPath (char *aPath, char *directoryPath, int numberOfSets, int totalNumberOfImages)
{
    keyValue *parametersList ;
    
    parametersList = allocAKeyValuePair() ;
    
    setStringValForKeyIn(parametersList, "MSBAS Initialization parameter file", "") ;
    setStringValForKeyIn(parametersList, "***********************************", "") ;
    setStringValForKeyIn(parametersList, directoryPath , "Path to MSBAS directory") ;
    setIntValForKeyIn(parametersList, numberOfSets, "Number of sets for MSBAS processing") ;
    setIntValForKeyIn(parametersList, totalNumberOfImages, "Total number of CSL images in all sets") ;
    setStringValForKeyIn(parametersList, "", "") ;
    setStringValForKeyIn(parametersList, "The total number of CSL images can be replaced by a maximum number of images", "") ;
    
    writeParameterFileAtPath(parametersList, aPath) ;
    freeKeyValueList(parametersList) ;
}


void createMSBASDirectoryStructureAtPath(char *path, int numberOfSets)
{
    char subDirectoryPath[_MAX_PATH_LENGTH_], *aDir, *filePath ;
    int i ;
    
    if(isValidDirectoryForPath(path)) {
        if(!isWriteAccessGrantedAtPath(path)) {
            sprintf(ertex, "Write access denied at path %s", path) ;
            ase(ertex) ;
        }
    }
    else {
        aDir = getDirectoryPathFromPath(path) ;
        if(!isWriteAccessGrantedAtPath(aDir)) {
            sprintf(ertex, "Write access denied at path %s", aDir) ;
            ase(ertex) ;
        }
        free(aDir) ;
        
        if(mkdir((const char *)path, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            sprintf(ertex, "Failed to create directory at path %s\n", path) ;
            ase(ertex) ;
        }
    }
    
    for (i = 1 ; i <= numberOfSets; i++) {
        
        sprintf(subDirectoryPath, "%s/set%d", path, i) ;
        if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
            if(errno != EEXIST) {
                sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
                ase(ertex) ;
            }
        }
        
        filePath = initStringWith2Strings(subDirectoryPath, "/setParametersFile.txt") ;
        createSetParametersFile(filePath) ;
    }
}


void addNewSetsDirectories(char *path, int numberOfSets, int numberOfNewSets)
{
    char subDirectoryPath[_MAX_PATH_LENGTH_], *filePath ;
    int i ;
    
    
    for (i = numberOfSets + 1 ; i <= numberOfSets + numberOfNewSets ; i++)
    {
        sprintf(subDirectoryPath, "%s/set%d", path, i) ;
        if(mkdir((const char *)subDirectoryPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH))
        {
            if(errno != EEXIST)
            {
                sprintf(ertex, "Failed to create directory at path %s\n", subDirectoryPath) ;
                ase(ertex) ;
            }
        }
        
        filePath = initStringWith2Strings(subDirectoryPath, "/setParametersFile.txt") ;
        createSetParametersFile(filePath) ;
    }
}







