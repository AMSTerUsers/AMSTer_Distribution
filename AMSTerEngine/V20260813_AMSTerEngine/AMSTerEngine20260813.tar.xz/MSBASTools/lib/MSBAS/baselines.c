
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  baselines.c
//  initiateBaselinesComputation
//
//  Created by Ludivine Libert on 24/08/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#include "baselines.h"

void baselinesComputationForSetAtPath(char *setPath, char **setImagesContent, int numberOfImages)
{
    int i ;
    
    char *slavePath, *masterPath, *aFilePath ;
    char *setParametersFilePath ;
    char *slaveName, *masterName ;
    char *globalMasterPath ;
    
    interferometricPairParameters *pairParams ;
    CSLImage *slaveImage, *masterImage ;
    keyValue *setParametersList ;
    InSARParametersStruct *pInSAR ;
    setParameters *setParams ;
    struct infoImage *infoList ;

    
    setParametersFilePath = initStringWith2Strings(setPath, "/setParametersFile.txt") ;
    setParametersList = readParameterFileAtPath(setParametersFilePath) ;
    setParams = allocAndInitSetParametersStructure(setParametersList) ;
    setParams->pathToInitBaselinesFile = initStringWith2Strings(setPath, "/initBaselines.txt") ;

    
    printf("Baselines computation :\n\n") ;
    printf("  Master\t   Slave\t Bperp\t Delay\n") ;
    printf("-----------------------------------------------\n\n") ;
    
    /* We consider all the pairs t0 - ti */
    /* In this case, t0 corresponds always to the slave image */
    
    /* master image */
    masterPath = initStringWith3Strings(setPath, "/", setImagesContent[0]) ;
    masterImage = getCSLImageStructureAtPath(masterPath) ;
    masterName = getFileNameFromPath(masterPath) ;
    stripExtensionAtEndOfPath(masterName);
    
    /* No prefered polarization. Looking for master default polarization */
    aFilePath = initStringWith2Strings(masterPath, "/Info/SLCImageInfo.txt") ;
    infoList = readInfoImageFromTextFile(aFilePath) ;
    free(aFilePath) ;
    
    for (i = 1 ; i < numberOfImages ; i++)
    {
        /* slave image */
        slavePath = initStringWith3Strings(setPath, "/", setImagesContent[i]) ;
        slaveImage = getCSLImageStructureAtPath(slavePath) ;
        slaveName = getFileNameFromPath(slavePath) ;
        stripExtensionAtEndOfPath(slaveName) ;
        
        pInSAR = allocAndinitInSARParametersStructAtPathForImages(setPath, masterImage, slaveImage, NULL, setParams->isBistatic, infoList->polMode) ;
        
        /* Allocation and initialization of a georeference structure */
        pInSAR->geo = allocAndInitGeorefStructureForTargetEllipsoid(pInSAR->masterInfo, pInSAR->masterInfo->ellRef) ;
        orbitInterpolation(pInSAR->masterInfo) ;
        orbitInterpolation(pInSAR->slaveInfo) ;
        
        approxRt(pInSAR->masterInfo) ;
        geolocateSceneOnEllipsoid(pInSAR->masterInfo, pInSAR->masterInfo->ellRef) ;
        
        /* Baseline computation */
        computeBaseLine(pInSAR) ;
        
        /* Allocation of an interferometric pair structure */
        pairParams = allocAnInterferometricPairParametersStructure() ;
        baselineValueAtSceneCenter(pInSAR, pairParams);
        
        pairParams->temporalDelay = computeTemporalDelay(slavePath, masterPath) ;
        
        /* Baselines values for each pair are recorded as a table in a text file */
        printf("%8s\t%8s\t%6d\t%6d\n", masterName, slaveName, (int)pairParams->perpendicularBaseline, pairParams->temporalDelay) ;
        recordInterferometricPairsAtPath(setParams->pathToInitBaselinesFile , pairParams, masterName, slaveName) ;
        
        free(slavePath) ;
        freeInterferometricPairParametersStructure(pairParams) ;
        freeInSARParametersStruct(pInSAR) ;
        freeCSLImageStructure(slaveImage) ;
    }
    
    printf("\n") ;
    
    setParams->numberOfCSLImages = numberOfImages ;
    globalMasterPath = initStringWithString(getStringValForKeyIn(setParametersList, "Path to global master")) ;
    saveSetParametersFileAtPath(setParametersFilePath, globalMasterPath, setParams) ;
    
    free(setParams) ;
    free(setParametersFilePath) ;
    free(masterPath) ;
    freeCSLImageStructure(masterImage) ;
    freeKeyValueList(setParametersList) ;
    freeInfoImage(infoList) ;
}


void baselinesComputationForOnePair(char *setPath, char *slave, char *master)
{
    int isBistatic ;
    
    char *slavePath, *masterPath, *globalMasterPath ;
    char *setParametersFilePath ;
    char *aFilePath ;
    
    interferometricPairParameters *pairParams ;
    CSLImage *slaveImage, *masterImage ;
    keyValue *setParametersList ;
    InSARParametersStruct *pInSAR ;
    setParameters *setParams ;
    struct infoImage *infoList ;

    
    /* The set parameters file has to be in the same directory than the new image */
    setParametersFilePath = initStringWith2Strings(setPath, "setParametersFile.txt") ;
    setParametersList = readParameterFileAtPath(setParametersFilePath) ;
    setParams = allocAndInitSetParametersStructure(setParametersList) ;

    printf("Baselines computation for one pair :\n\n") ;
    printf("  Master\t   Slave\t Bperp\t Delay\n") ;
    printf("-----------------------------------------------\n\n") ;
    
    
    slavePath = initStringWith2Strings(setPath, slave) ;
    masterPath = initStringWith2Strings(setPath, master) ;
    
    slaveImage = getCSLImageStructureAtPath(slavePath) ;
    masterImage = getCSLImageStructureAtPath(masterPath) ;
    
    stripExtensionAtEndOfPath(slave) ;
    stripExtensionAtEndOfPath(master) ;
    
    /* No prefered polarization. Looking for master default polarization */
    aFilePath = initStringWith2Strings(masterPath, "/Info/SLCImageInfo.txt") ;
    infoList = readInfoImageFromTextFile(aFilePath) ;
    free(aFilePath) ;
    
    
    isBistatic = 0 ;
    if (isKeyValPresent(setParametersList, "Bistatic"))
        isBistatic = !strncmp(getStringValForKeyIn(setParametersList, "Bistatic"), "YES", 3) ;
    
    pInSAR = allocAndinitInSARParametersStructAtPathForImages(setPath, masterImage, slaveImage, NULL, isBistatic, infoList->polMode) ;
    
    /* Allocation and initialization of a georeference structure */
    pInSAR->geo = allocAndInitGeorefStructureForTargetEllipsoid(pInSAR->masterInfo, pInSAR->masterInfo->ellRef) ;
    orbitInterpolation(pInSAR->masterInfo) ;
    orbitInterpolation(pInSAR->slaveInfo) ;
    
    approxRt(pInSAR->masterInfo) ;
    geolocateSceneOnEllipsoid(pInSAR->masterInfo, pInSAR->masterInfo->ellRef) ;
    
    /* Baseline computation */
    computeBaseLine(pInSAR) ;

    /* Allocation of an interferometric pair structure */
    pairParams = allocAnInterferometricPairParametersStructure() ;
    baselineValueAtSceneCenter(pInSAR, pairParams);
    
    pairParams->temporalDelay = computeTemporalDelay(slavePath, masterPath) ;
    
    /* Baselines values for each pair are recorded as a table in a text file */
    printf("%8s\t%8s\t%6d\t%6d\n", master, slave, (int)pairParams->perpendicularBaseline, pairParams->temporalDelay) ;
    printf("\n") ;
    setParams->pathToInitBaselinesFile  = initStringWith2Strings(setPath, "initBaselines.txt") ;
    recordInterferometricPairsAtPath(setParams->pathToInitBaselinesFile , pairParams, master , slave) ;
    
    /* We need to add 1 to number of image in order to take the new image into account */
    setParams->numberOfCSLImages ++ ;
    globalMasterPath = initStringWithString(getStringValForKeyIn(setParametersList, "Path to global master")) ;
    saveSetParametersFileAtPath(setParametersFilePath, globalMasterPath, setParams) ;
    
    free(setParams) ;
    freeInterferometricPairParametersStructure(pairParams) ;
    freeInSARParametersStruct(pInSAR) ;
    freeKeyValueList(setParametersList) ;
    freeCSLImageStructure(masterImage) ;
}

