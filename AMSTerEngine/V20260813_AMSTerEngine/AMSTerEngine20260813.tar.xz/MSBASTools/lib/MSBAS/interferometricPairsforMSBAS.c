
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  interferometricPairsforMSBAS.c
//  interferometricPairsSelectionForMSBAS
//
//  Created by Ludivine Libert on 13/08/15.
//  Copyright (c) 2015 Ludivine Libert. All rights reserved.
//

#include "interferometricPairsforMSBAS.h"


interferometricPairParameters *allocAnInterferometricPairParametersStructure()
{
    interferometricPairParameters *pairParams ;
    
    if ((pairParams = (interferometricPairParameters *)calloc (1, sizeof(interferometricPairParameters))) == NULL) {
        sprintf (ertex, "Failed to allocated interferometric pair parameters structure") ;
        perror (ertex) ;
        exit(-1) ;
    }
    
    pairParams->slavePath = (char *)malloc(sizeof(char)) ;
    pairParams->masterPath = (char *)malloc(sizeof(char)) ;
    
    return pairParams ;
}


void freeInterferometricPairParametersStructure(interferometricPairParameters *pairParams)
{
    free(pairParams->slavePath) ;
    free(pairParams->masterPath) ;
    free(pairParams) ;
}


/* One for each data set */
void createSetParametersFile(char *aPath)
{
    keyValue *parameterList ;
    
    parameterList = allocAKeyValuePair() ;
    setStringValForKeyIn(parameterList, "MSBAS set parameters file", "") ;
    setStringValForKeyIn(parameterList, "*************************", "") ;
    /*
     setDoubleValForKeyIn(parameterList, 0, "DEM precision [m]");
     setDoubleValForKeyIn(parameterList, 0, "Required accuracy on the deformation measurement [m]");
     */
    setDoubleValForKeyIn(parameterList, 0, "Minimum baseline [m]") ;
    setDoubleValForKeyIn(parameterList, 0, "Maximum baseline [m]") ;
    setDoubleValForKeyIn(parameterList, 0, "Minimum temporal delay [days]") ;
    setDoubleValForKeyIn(parameterList, 0, "Maximum temporal delay [days]") ;
    setStringValForKeyIn(parameterList, "NO", "Bistatic acquisition [YES/NO]") ;
    setStringValForKeyIn(parameterList, "Global Master Path", "Path to global master") ;
    setIntValForKeyIn(parameterList, 0, "Number of images") ;
    setIntValForKeyIn(parameterList, 0, "Number of interferograms") ;
    setStringValForKeyIn(parameterList, "PathTo Triangle.txt", "Path to triangle table containing baseline and delay values") ;
    setStringValForKeyIn(parameterList, "PathTo initBaselines.txt", "Path to initial baselines values table") ;

    
    writeParameterFileAtPath(parameterList, aPath) ;
}

setParameters *allocAndInitSetParametersStructure(keyValue *parametersList)
{
    setParameters *setParams;
    
    setParams = (setParameters *)calloc(1, sizeof(setParameters)) ;
    
    setParams->minBaseline = getDoubleValForKeyIn(parametersList, "Minimum baseline") ;
    setParams->maxBaseline = getDoubleValForKeyIn(parametersList, "Maximum baseline") ;
    setParams->maxTemporalDelay = getIntValForKeyIn(parametersList, "Maximum temporal delay") ;
    setParams->minTemporalDelay = getIntValForKeyIn(parametersList, "Minimum temporal delay") ;

    if (!strncmp(getStringValForKeyIn(parametersList, "Bistatic"), "YES", 3))
        setParams->isBistatic = 1 ;
    else
        setParams->isBistatic = 0 ;
    
    setParams->numberOfCSLImages = getIntValForKeyIn(parametersList, "Number of images") ;
    setParams->numberOFInterferograms = getIntValForKeyIn(parametersList, "Number of interferograms") ;
    setParams->pathToTriangleFile = initStringWithString(getStringValForKeyIn(parametersList, "Path to triangle table")) ;
    setParams->pathToInitBaselinesFile = initStringWithString(getStringValForKeyIn(parametersList, "Path to initial")) ;
    
    return setParams ;
}


void saveSetParametersFileAtPath(char *aPath, char *globalMasterPath, setParameters *setParams)
{
    keyValue *parameterList ;
    
    parameterList = allocAKeyValuePair() ;
    setStringValForKeyIn(parameterList, "MSBAS set parameters file", "") ;
    setStringValForKeyIn(parameterList, "*************************", "") ;
    /*
     setDoubleValForKeyIn(parameterList, bParams->DEMPrecision, "DEM precision [m]") ;
     setDoubleValForKeyIn(parameterList, bParams->deformationPrecision, "Required accuracy on the deformation measurement [m]") ;
     */
    setDoubleValForKeyIn(parameterList, setParams->minBaseline, "Minimum baseline [m]");
    setDoubleValForKeyIn(parameterList, setParams->maxBaseline, "Maximum baseline [m]") ;
    setDoubleValForKeyIn(parameterList, setParams->minTemporalDelay, "Minimum temporal delay [days]") ;
    setDoubleValForKeyIn(parameterList, setParams->maxTemporalDelay, "Maximum temporal delay [days]") ;
    
    if (setParams->isBistatic)
        setStringValForKeyIn(parameterList, "YES", "Bistatic acquisitions [YES/NO]") ;
    
    else
        setStringValForKeyIn(parameterList, "NO", "Bistatic acquisitions [YES/NO]") ;
    
    setStringValForKeyIn(parameterList, globalMasterPath, "Path to global master") ;
    setIntValForKeyIn(parameterList, setParams->numberOfCSLImages, "Number of images") ;
    setIntValForKeyIn(parameterList, setParams->numberOFInterferograms, "Number of interferograms") ;
    setStringValForKeyIn(parameterList, setParams->pathToTriangleFile, "Path to triangle table containing baseline and delay values") ;
    setStringValForKeyIn(parameterList, setParams->pathToInitBaselinesFile, "Path to initial baselines values table") ;
    
    writeParameterFileAtPath(parameterList, aPath) ;
}

/* One for each data pair */
void createPairFileAtPath(char *aPath)
{
    keyValue *parameterList ;
    
    parameterList = allocAKeyValuePair() ;
    setStringValForKeyIn(parameterList, "Interferometric pair info file", "") ;
    setStringValForKeyIn(parameterList, "***********************************", "") ;
    setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, "masterImagePath", "Master: Path to master image file in CSL format") ;
    setStringValForKeyIn(parameterList, "slaveImagePath", "Slave: Path to slave image file in CSL format") ;
    setStringValForKeyIn(parameterList, "NO", "Bistatic interferometric pair [YES/NO]") ;
    setStringValForKeyIn(parameterList, "", "") ;
    setDoubleValForKeyIn(parameterList, 0, "Perpendicular baseline value [m]") ;
    setDoubleValForKeyIn(parameterList, 0, "Temporal delay between the two acquisitions [days]") ;
    setStringValForKeyIn(parameterList, "YES", "Interferometric pair selected for MSBAS processing ?[YES/NO]") ;
    setStringValForKeyIn(parameterList, "", "") ;
    setIntValForKeyIn(parameterList, 0, "Slave temporal index") ;
    setIntValForKeyIn(parameterList, 0, "Master temporal index") ;
    
    writeParameterFileAtPath(parameterList, aPath) ;
}


void savePairFileAtPath(char *aPath, interferometricPairParameters *pairParams)
{
    keyValue *parameterList ;
    
    parameterList = allocAKeyValuePair() ;
    setStringValForKeyIn(parameterList, "Interferometric pair info file", "") ;
    setStringValForKeyIn(parameterList, "***********************************", "") ;
    setStringValForKeyIn(parameterList, "", "") ;
    setStringValForKeyIn(parameterList, pairParams->masterPath, "Master: Path to master image file in CSL format") ;
    setStringValForKeyIn(parameterList, pairParams->slavePath, "Slave: Path to slave image file in CSL format") ;
    
    if(pairParams->isBistatic)
        setStringValForKeyIn(parameterList, "YES", "Bistatic interferometric pair") ;
    else
        setStringValForKeyIn(parameterList, "NO", "Bistatic interferometric pair") ;

    setStringValForKeyIn(parameterList, "", "") ;
    setDoubleValForKeyIn(parameterList, pairParams->perpendicularBaseline, "Perpendicular baseline value [m]") ;
    setDoubleValForKeyIn(parameterList, pairParams->temporalDelay, "Temporal delay between the two acquisitions [days]") ;

    if(pairParams->isInterferometricPairSelected)
        setStringValForKeyIn(parameterList, "YES", "Interferometric pair selected for MSBAS processing ?[YES/NO]") ;
    else
        setStringValForKeyIn(parameterList, "NO", "Interferometric pair selected for MSBAS processing ?[YES/NO]") ;

    setStringValForKeyIn(parameterList, "", "") ;
    setIntValForKeyIn(parameterList, pairParams->slaveIndex, "Slave temporal index") ;
    setIntValForKeyIn(parameterList, pairParams->masterIndex, "Master temporal index") ;
    
    writeParameterFileAtPath(parameterList, aPath) ;
}


void readPairFileInfoAtPath(char *filePath, interferometricPairParameters *pairParams)
{
    keyValue *parametersList ;
    
    parametersList = readParameterFileAtPath(filePath) ;

    pairParams->temporalDelay = getDoubleValForKeyIn(parametersList, "Temporal delay") ;
    pairParams->perpendicularBaseline = getDoubleValForKeyIn(parametersList, "Perpendicular baseline") ;
    pairParams->masterPath = getStringValForKeyIn(parametersList, "Master") ;
    pairParams->slavePath = getStringValForKeyIn(parametersList, "Slave") ;
    
    if (strcmp(getStringValForKeyIn(parametersList, "Interferometric pair selected"), "YES"))
        pairParams->isBistatic = 1;
    else
        pairParams->isBistatic = 0 ;
    
    if (strcmp(getStringValForKeyIn(parametersList, "Bistatic"), "YES"))
        pairParams->isInterferometricPairSelected = 1 ;
    else
        pairParams->isInterferometricPairSelected = 0 ;
}


void baselineValueAtSceneCenter(InSARParametersStruct *pInSAR, interferometricPairParameters *pairParams)
{
    satRef *satRefMaster ;
    
    double azimuthMin, azimuthMax, rangeMin, rangeMax ;
    double deltaAzimuth, deltaRange, azimuthPosition, rangePosition ;
    double Rt, gamma ;
    
    /* The baseline is computed by a first order least square */
    /* The size of the baseline is given in first aprproximation by the constant term */
    /* The terms of higher order can be neglected in first approximation */
    /* However, in order to have a good accuracy on the baseline and */
    /* to be consistent with the maximum baseline value */
    /* we compute the value in the centre of the image */
    
    satRefMaster = allocAndInitSatRefWithGeoRefStructure(pInSAR->geo) ;
    
    azimuthMin = 0. ;
    rangeMin = 0. ;
    azimuthMax = (double)satRefMaster->params->info->azimuthDimension - 1. ;
    rangeMax = (double)satRefMaster->params->info->rangeDimension - 1. ;
    
    deltaAzimuth = (azimuthMax - azimuthMin) / 2. ;
    deltaRange = (rangeMax - rangeMin) / 2. ;
    
    azimuthPosition = azimuthMin + deltaAzimuth ;
    rangePosition = rangeMin + deltaRange ;
    
    Rt = earthRadiusAtPoint(rangePosition, azimuthPosition, 0, pInSAR->geo) ;
    gamma = (pInSAR->B).theta - pInSAR->geo->solving->alpha_at ;
    
    pairParams->Bx = pInSAR->B.T[0][2] + pInSAR->B.T[0][0] * rangePosition + pInSAR->B.T[0][1] * azimuthPosition ;
    pairParams->By = pInSAR->B.T[1][2] + pInSAR->B.T[1][0] * rangePosition + pInSAR->B.T[1][1] * azimuthPosition ;

    /* Pythagore */
    pairParams->baseline = (sqrt(pow(pairParams->Bx,2) + pow(pairParams->By, 2))) ;
    pairParams->perpendicularBaseline = pairParams->baseline * cos(gamma) ;
    
    /*    printf("Horizontal baseline component constant term : \t %f m\n",bParams->Bx) ;
     printf("Vertical baseline component constant term: \t %f m\n", bParams->By) ;
     printf("Baseline at scene centre : \t %f m\n", bParams->baseline) ;
     */
}


int computeTemporalDelay(char *slavePath, char *masterPath)
{
    int slaveYYYY, masterYYYY, slaveMM, masterMM, slaveDD, masterDD ;
    int delay, numberOfDaysInSlaveYYYY, numberOfDaysInMasterYYYY ;
    int numberOfDaysInSlaveMM, numberOfDaysInMasterMM ;
    char *slaveFileName, *masterFileName ;
    
    /* Value of the day, month and year for the slave and master image (from the name of the CSL directory) */
    slaveFileName = getFileNameFromPath(slavePath) ;
    sscanf(slaveFileName, "%4d%2d%2d.csl", &slaveYYYY, &slaveMM, &slaveDD) ;
    masterFileName = getFileNameFromPath(masterPath) ;
    sscanf(masterFileName, "%4d%2d%2d.csl", &masterYYYY, &masterMM, &masterDD) ;

    numberOfDaysInSlaveYYYY = (slaveYYYY - 1) * 365 + (slaveYYYY - 1)/4 ;
    numberOfDaysInMasterYYYY = (masterYYYY - 1) * 365 + (masterYYYY - 1)/4 ;
    
    /* Problem with the number of days per month */
    numberOfDaysInSlaveMM = numberOfDaysForMonth(slaveMM, slaveYYYY) ;
    numberOfDaysInMasterMM = numberOfDaysForMonth(masterMM, masterYYYY) ;
    
    delay = (numberOfDaysInMasterYYYY + numberOfDaysInMasterMM + masterDD) - (numberOfDaysInSlaveYYYY + numberOfDaysInSlaveMM + slaveDD) ;
    
    return (delay) ;
}


int numberOfDaysForMonth(int month, int year)
{
    int cumulatedNumberOfDays, i ;
    int *daysInMonth ;
    
    daysInMonth = vectorInt(0, 10) ;
    
    daysInMonth[1] = 28 ;
    daysInMonth[0] = daysInMonth[2] = daysInMonth[4] = daysInMonth[6] = daysInMonth[7] = daysInMonth[9] = 31 ;
    daysInMonth[3] = daysInMonth[5] = daysInMonth[8] = daysInMonth[10] = 30 ;
    
    i = 0 ;
    cumulatedNumberOfDays = 0 ;
    
    while((i+1) != month)
    {
        cumulatedNumberOfDays += daysInMonth[i] ;
        i++ ;
    }
    
    if(year%4 == 0 && month > 2)
        cumulatedNumberOfDays += 1 ;
    
    freeVectorInt(daysInMonth, 0) ;
    
    return (cumulatedNumberOfDays) ;
}


void recordInterferometricPairsAtPath(char *filePath, interferometricPairParameters *pairParams, char *slaveName, char *masterName)
{
    FILE *listOfInterferometricPairs ;
    
    listOfInterferometricPairs = fopen(filePath, "a+") ;
    
    if (listOfInterferometricPairs == NULL)
        ase("Failed to open a text file to record interferometric pairs info\n") ;
    
    fprintf(listOfInterferometricPairs, "%s\t%s\t%lf\t%d\n", slaveName, masterName, pairParams->perpendicularBaseline, pairParams->temporalDelay) ;
    
    fclose(listOfInterferometricPairs) ;
}
