
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  main.c
//  convertNaNToZeros
//
//  Created by Ludivine Libert on 3/10/17.
//  Copyright © 2017 Ludivine Libert. All rights reserved.
//

#include <stdio.h>
#include "paramLib.h"


void usage(void) ;

int main(int argc, const char * argv[])
{
    int i, j ;
    int dimx, dimy ;
    float **image ;
    char zeroToNaN, inplace ;
    char *filePath, *outputFilePath ;
    rawFileDescriptor *file, *outputFile ;
    
    if (isArgumentPresent(argc, argv, "-h") || isArgumentPresent(argc, argv, "help"))
        usage() ;
    
    if (argc < 4 || argc > 6)
        usage() ;

    zeroToNaN = inplace = 0 ;
    
    if (isArgumentPresent(argc, argv, "-NaN"))
        zeroToNaN = 1 ;
    else
        zeroToNaN = 0 ;
    
    if (isArgumentPresent(argc, argv, "-inplace"))
        inplace = 1 ;
    else
        inplace = 0 ;

    genFloatNaN() ;
    
    /* Image dimensions */
    dimx = atoi(argv[2]) ;
    dimy = atoi(argv[3]) ;
    
    /* Paths */
    filePath = (char *) argv[1] ;
    
    if (!inplace)
    {
        if (zeroToNaN)
            outputFilePath = initStringWith2Strings(filePath, ".NaN") ;
        else
            outputFilePath = initStringWith2Strings(filePath, ".zeros") ;
    }
    
    else outputFilePath = initStringWithString(filePath) ;


    /* Opening files */
    if((file = openRawFileForReadingAtPath(filePath)) == NULL)
        ase("Failed to open the input file.\n") ;    

    /* Matrices declaration*/
    image = matrixFloat(0, dimy-1, 0, dimx-1) ;
    
    /* Reading the image to be interpolated */
    if((fread(image[0], sizeof(float), dimx * dimy, file->f)) != dimx * dimy)
        ase("Failed to read the image.\n") ;
    
    freeRawFileDescriptor(file) ;

    if (zeroToNaN)
    {
        for (i = 0 ; i < dimy ; i++)
            for (j = 0 ; j < dimx ; j ++)
                if (!image[i][j])
                    image[i][j] = floatNaN ;
    }
    
    else
    {
        for (i = 0 ; i < dimy ; i++)
            for (j = 0 ; j < dimx ; j ++)
                if (isnan(image[i][j]))
                    image[i][j] = 0. ;
    }

    if((outputFile = openRawFileForWritingAtPath(outputFilePath)) == NULL)
        ase("Failed to open the output file.\n") ;
    fwrite(image[0], sizeof(float), dimx * dimy, outputFile->f) ;
    freeRawFileDescriptor(outputFile) ;

    
    freeMatrixFloat(image, 0, 0) ;
    free(outputFilePath) ;
    
    return 0;
}


void usage()
{
    printf("\n\n\tconvertNaNToZeros\t pathTo/image xDim yDim\n\n") ;
    printf("This routine converts the NaN values in an image into zeros.\n") ;
    printf("If the keyword \"-NaN\" is set, then the work is done in the reverse way and zero values are replaced by NaN.\n") ;
    printf("If the keyword \"-inplace\" is set, then the new version of the image is recorded in place of the old one.\n\n") ;
    exit(0) ;
}
