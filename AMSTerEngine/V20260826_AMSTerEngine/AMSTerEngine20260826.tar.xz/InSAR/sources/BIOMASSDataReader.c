/* 
*  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version. 
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 * 
 *  You should have received a copy of the GNU Affero General Public License 
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**************************************************
 * File name : BIOMASSDataReader.c
 * Author : Dominique Derauw
 * Date : 2026-06-18
 * Copyright 2026 Dominique Derauw
 * Description : 
 **************************************************/


#include <stdio.h>
#include "BIOMASSDataReader.h"

int main(int argc, const char * argv[])
{
    int i ;
    CSVStruct *csv = NULL, *savedCSLImages = NULL ;
    
    for (i = 0; i < argc; i++) {
        csv = addStringValInCSVStruct((char *)argv[i], csv) ;
    }
    
    savedCSLImages = BIOMASSDataReader(csv) ;
    freeCSVStruct(csv) ;
    freeCSVStruct(savedCSLImages) ;
    
    return(0) ;
}

