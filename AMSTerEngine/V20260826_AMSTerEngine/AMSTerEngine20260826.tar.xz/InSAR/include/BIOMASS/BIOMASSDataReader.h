/* 
*  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version. 
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 * 
 *  You should have received a copy of the GNU Affero General Public License 
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**************************************************
 * File name : BIOMASSDataReader.h
 * Author : Dominique Derauw
 * Date : 2026-06-18
 * Copyright 2026 Dominique Derauw
 * Description : 
 **************************************************/



#if !defined(__BIOMASSDataReader__)
#define __BIOMASSDataReader__

#include <stdio.h>
#include <stdlib.h>
#include <tiffio.h>
#include <stdint.h>

#include <Lerc_c_api.h>
#include <zstd.h>

#include "pourtous.h"
#include "stringLib.h"
#include "fileAccessLib.h"
#include "rawFileLib.h"
#include "basicTiffLib.h"
#include "infoImageBIOMASS.h"
#include "tileToolLib.h"

#ifndef TIFF_NO_DEFLATE
#  include <zlib.h>
#endif

#define _SAVE_MOD_PHI_LAYERS_   0x00000001
#define _FORCE_READING_         0x00000002
typedef struct _lercTiffTileDecoder
{
    char unsigned *compressedTile, *buffer, *lercMask ;
    char *GDAL, *noVal ;
    int unsigned *lercInfo, lercMaskNumber ;
    int xDim, yDim, xDimTile, yDimTile ;
    int xTileNumber, yTileNumber, tileShift ;
    int iXTile, iYTile, tileIndex, layerIndex ;
    int *tileOffset, *tileByteCount, *sampleFormat ;
    int *lercParameters, zRet ;
    size_t tileByteSize, offset, byteCount ;
    size_t lercSize ;
    unsigned long long zstdDecompressedSize ;
    float *outputTile ; 
    tileTool *aTileTool ;
    tiffFileDescriptor *desc ;
    z_stream zs ;
    lerc_status lercStatus ;
} lercTiffTileDecoder ;


//#pragma once

static const char polScheme[4][3] = {"HH", "HV", "VH", "VV"} ;

CSVStruct *BIOMASSDataReader(CSVStruct *csv) ; 
void biomassDataReaderHelp(void) ;
void readBIOMASSData(char *inputDirectory, CSLImage *thisImage, int polIndex, int flag) ;
lercTiffTileDecoder *allocAndInitLERCTileDecoder(char *tiffFilePath)  ;
void freeLERCDecoder(lercTiffTileDecoder *dec) ;
float *decodeLERCTileAtIndex(lercTiffTileDecoder *dec, int ixTile, int iYtile, int layerIndex) ;


#endif