/* 
*  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version. 
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 * 
 *  You should have received a copy of the GNU Affero General Public License 
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**************************************************
 * File name : infoImageBIOMASS.h
 * Author : Dominique Derauw
 * Date : 2026-08-17
 * Copyright 2026 Dominique Derauw
 * Description : 
 **************************************************/



#if !defined(__infoImageBIOMASS__)
#define __infoImageBIOMASS__

#include <stdio.h>
#include "CSLImageFormat.h"
#include "infoImage.h"
#include "geoRef.h"
#include "basicXMLHandlingLib.h"
#include "fileAccessLib.h"

struct infoImage *createSLCImageInfoForBIOMASSData(char *aPath, char *polarization) ;
double *approxBIOMASSFDC(SLCImageInfo *info, xmlDocPtr ADSXMLDoc) ;
struct stateVect *readAndSelectBIOMASSStateVectors(xmlDocPtr ORBXMLDoc, struct infoImage *info) ;

#endif