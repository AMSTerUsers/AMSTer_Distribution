
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  dataTypeID.h
//  S1InSARDataReader
//
//  Created by Dominique Derauw on 3/11/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#ifndef S1InSARDataReader_dataTypeID_h
#define S1InSARDataReader_dataTypeID_h

#define __ERS1__        1
#define __ERS2__        2
#define __ENVISAT__     3
#define __SENTINEL1__   4
#define __BIOMASS1__    5

#define __ALOS__        10
#define __CSK__         11
#define __TSX__         12
#define __TDX__         13
#define __RSAT2__       14
#define __ALOS2__       15
#define __K5__          16
#define __PAZ1__        17
#define __SAOCOM1A__    18
#define __SAOCOM1B__    19
#define __TDM__         20
#define __CSG__         21          /* CSK second generation */
#define __NISAR__       22

#define __ICEYE__       100

#endif
