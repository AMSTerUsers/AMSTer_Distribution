/* 
*  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version. 
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 * 
 *  You should have received a copy of the GNU Affero General Public License 
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**************************************************
 * File name : infoImageBIOMASS.c
 * Author : Dominique Derauw
 * Date : 2026-08-17
 * Copyright 2026 Dominique Derauw
 * Description : 
 **************************************************/


#include <stdio.h>
#include "infoImageBIOMASS.h"

struct infoImage *createSLCImageInfoForBIOMASSData(char *aPath, char *polarization)
{
    char *annotationDir, *aString ;
    float lat, lon ;
    double aDouble ;
    polygon *aoi ;
    SLCImageInfo *info ;
    CSVStruct *csv ;
    xmlDocPtr ADSXMLDoc, ORBXMLDoc ;

    /* Get ADS xml doc */
    annotationDir = initStringWith2Strings(aPath, "/annotation") ;
    if (!(csv = listFilesWithNameInDir("_annot", annotationDir))) {
        ase("\t-/-> No annotationdata file found in BIOMASS directory structure.\n") ;
    }
    ADSXMLDoc = getdoc(csv->stringVal[0]) ;
    freeCSVStruct(csv) ;
    free(annotationDir) ;

    /* Get orbit xml doc */
    annotationDir = initStringWith2Strings(aPath, "/annotation/navigation") ;
    if (!(csv = listFilesWithNameInDir("_orb.xml", annotationDir))) {
        ase("\t-/-> No orbit file found in BIOMASS directory structure.\n") ;
    }
    ORBXMLDoc = getdoc(csv->stringVal[0]) ;
    freeCSVStruct(csv) ;
    free(annotationDir) ;
    
    /* Allocate infoImage structure */
    info = allocInfoImage() ;

    /* Satellite ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//mission", ADSXMLDoc))) {
        sprintf(info->platformName, "%s", csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
    }
    else {
        ase("\t-/-> No platform ID found. Are you sure we deal with BIOMASS data?\n\n") ;
    }

    /* Acquisition date */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//startTime", ADSXMLDoc))) {
        info->acquisitionDate = allocStringOfLength(10) ;
        sprintf(info->acquisitionDate, "%.10s", csv->stringVal[0]) ;
        removeAnyOccurrenceOfSubStringInString(info->acquisitionDate, "-") ;
        freeCSVStruct(csv) ;
    }
    else {
            ase("Failed to read start time\n") ;
    }

    /* Polarisation scheme */
    if (!(info->polScheme = readCSVInXMLFileForXPath((xmlChar*)"//polarisationList/polarisation", ADSXMLDoc))) {
        ase("\t-/-> Failed to read polarization scheme in ADS.\n") ;
    }
    info->numberOfLayers = info->polScheme->numberOfEntries ;
    aString = getCSVStringFromCSV(info->polScheme) ;
    sprintf(info->polMode, "%s", aString) ;
    free(aString) ;

    /* Relative orbit number */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//relativeOrbitNumber", ADSXMLDoc))) {
        sscanf(csv->stringVal[0], "%d", &info->relativeOrbitNumber) ;
        freeCSVStruct(csv) ;
    }
    
    /* Product ID */
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//productType", ADSXMLDoc))) {
        aString = initStringWithString(csv->stringVal[0]) ;
        freeCSVStruct(csv) ;
        if((csv = readCSVInXMLFileForXPath((xmlChar*)"//swath", ADSXMLDoc))) {
            sprintf(info->productID, "Swath: %s \tProduct type:", csv->stringVal[0], aString) ;
            sscanf(csv->stringVal[0], "S%d", &info->beamNumber) ;
            freeCSVStruct(csv) ;
        }
        free(aString) ;
    }
    
    /* Scene ID */
    sprintf(info->scene_id, "%s", getPointerToFileNameInPath(aPath)) ;

    /* Look direction defined as Right looking */
    info->lookDirection = LEFT_LOOKING ;

    /* PRF */
    csv = readCSVInXMLFileForXPath((xmlChar*)"//prf/value", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%lf", &(info->prf)) ;
    freeCSVStruct(csv) ;

    /* Line time interval */
    csv = readCSVInXMLFileForXPath((xmlChar*)"//sarImage/azimuthTimeInterval", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%lf", &(info->lineTimeInterval)) ;
    freeCSVStruct(csv) ;

    /* Image dimensions */
    csv = readCSVInXMLFileForXPath((xmlChar*)"//sarImage/numberOfSamples", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%d", &(info->rangeDimension)) ;
    freeCSVStruct(csv) ;
    csv = readCSVInXMLFileForXPath((xmlChar*)"//sarImage/numberOfLines", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%d", &(info->azimuthDimension)) ;
    freeCSVStruct(csv) ;

    /* First pixel Azimuth Time */
    csv = readCSVInXMLFileForXPath((xmlChar*)"//sarImage/firstLineAzimuthTime", ADSXMLDoc) ;
    info->FPAT =  getSecondsFromFormattedDate(csv->stringVal[0]) ;
    freeCSVStruct(csv) ;

    /* Last pixel Azimuth Time */
    csv = readCSVInXMLFileForXPath((xmlChar*)"//sarImage/lastLineAzimuthTime", ADSXMLDoc) ;
    info->LPAT =  getSecondsFromFormattedDate(csv->stringVal[0]) ;
    freeCSVStruct(csv) ;

    /* Radar carrier frequency */
    info->radarCarrierFrequency = 0. ;
    csv = readCSVInXMLFileForXPath((xmlChar*)"//radarCarrierFrequency", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%lf", &(info->radarCarrierFrequency)) ;
    freeCSVStruct(csv) ;

    /* Wavelength */
    info->wavelength = speedOfLight / info->radarCarrierFrequency ;

    /* Range sampling frequency */
    csv = readCSVInXMLFileForXPath((xmlChar*)"//sarImage/rangeTimeInterval", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%lf", &aDouble) ;
    freeCSVStruct(csv) ;
    info->rangeSamplingFrequency = 1. / aDouble ;

    /* Range resolution cell */
    csv = readCSVInXMLFileForXPath((xmlChar*)"//sarImage/rangePixelSpacing", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%lf", &(info->rangeResolutionCell)) ;
    freeCSVStruct(csv) ;

    /* Range bandwidth  */
    info->rangeBandwidth = 0. ;
    csv = readCSVInXMLFileForXPath((xmlChar*)"//rangeProcessingParameters/processingBandwidth", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%lf", &(info->rangeBandwidth)) ;
    freeCSVStruct(csv) ;

    /* Range apodization coefficient  */
    info->rangeApodizationCoefficient = 0. ;
    csv = readCSVInXMLFileForXPath((xmlChar*)"//rangeProcessingParameters/windowCoefficient", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%lf", &(info->rangeApodizationCoefficient)) ;
    freeCSVStruct(csv) ;

    /* Min and max slant range */
    info->twoWayRangeTime[0] = info->slantRange[0] = 0. ;
    csv = readCSVInXMLFileForXPath((xmlChar*)"//sarImage/firstSampleSlantRangeTime", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%lf", &(info->twoWayRangeTime[0])) ;
    freeCSVStruct(csv) ;
    info->slantRange[0] = c0 / 2. * info->twoWayRangeTime[0] ;
    info->slantRange[2] = info->slantRange[0] + info->rangeDimension * info->rangeResolutionCell ;
    info->slantRange[1] = (info->slantRange[0] + info->slantRange[2]) / 2. ;

    /* Azimuth Bandwith and resolution */
    info->azimuthBandwidth = 0. ;
    csv = readCSVInXMLFileForXPath((xmlChar*)"//azimuthProcessingParameters/processingBandwidth", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%lf", &(info->azimuthBandwidth)) ;
    freeCSVStruct(csv) ;

    info->azimuthResolutionCell = 0. ;
    csv = readCSVInXMLFileForXPath((xmlChar*)"//sarImage/azimuthPixelSpacing", ADSXMLDoc) ;
    sscanf(csv->stringVal[0], "%lf", &(info->azimuthResolutionCell)) ;
    freeCSVStruct(csv) ;

    /* Doppler centroid approximation */
    if (info->fdc != NULL) {
        freeVectorDouble(info->fdc, 0) ;
    }
    info->fdc = approxBIOMASSFDC(info, ADSXMLDoc) ;

    /* Read and select state vectors */
    info->orbitTypeID = initStringWithString("Prelimiary orbit") ;
    info->S = readAndSelectBIOMASSStateVectors(ORBXMLDoc, info) ;
    info->FVT = info->S[0].t ;
    info->Dt = -1 ; /* Delta T between state vectors not necessarily constant */
    info->aX = info->aY = info->aZ = info->aVx= info->aVy= info->aVz = NULL ;
	info->isOrbitInterpolationDone = 0 ;

    /* Reference ellipsoid defined as WGS84 as default */
    if((info->ellRef = (ellipsoid *)malloc(sizeof(ellipsoid))) == NULL) {
        ase("\t-/-> Failed to allocat datum") ;
    }
    sprintf(info->ellRef->ellipsoidID, "WGS84") ;
    info->ellRef->a = 6.378137000000000e+06 ; // Predefined as WGS84
    info->ellRef->b = 6.356752314245000e+06 ; // Predefined as WGS84

    info->ellRef->f_1 = info->ellRef->a / (info->ellRef->a  - info->ellRef->b) ;
    info->ellRef->e2 = (pow(info->ellRef->a, 2.) - pow(info->ellRef->b, 2.)) / pow(info->ellRef->a, 2.) ;
    info->ellRef->X0 = info->ellRef->Y0 = info->ellRef->Z0 = 0. ;

	/* Geolocate scene on reference ellipsoid */
    info->sceneAverageHeight = 0 ;
    info->polynomialOrder = MAX_POL_ORDER_FOR_ORBIT_INTERPOL ;
	info->EarthRadiusAtSceneCenter = 6371221. ;
    info->incidenceAngle[0] = 0. ;
	geolocateSceneOnEllipsoid(info, info->ellRef) ;

    /* Scene centre approxilmate location */
    aoi = circumscribedRectangleOfPolygon(info->loc) ;
    lat = 180./PI * (aoi->P[0].y + aoi->P[2].y) / 2. ;
    lon = 180./PI * (aoi->P[0].x + aoi->P[2].x) / 2. ;
    sprintf(info->scene_loc, "Center longitude: %.4g\tCenter latitude: %.4g", lon, lat) ;
    freePolygon(aoi) ;

    /* Reference range */
    info->referenceRange = 800000.0 ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//processingParameters/referenceRange", ADSXMLDoc))) {
        sscanf(csv->stringVal[0], "%lf", &(info->referenceRange)) ;
        freeCSVStruct(csv) ;
    }

    xmlFreeDoc(ADSXMLDoc) ;
    xmlFreeDoc(ORBXMLDoc) ;
    xmlCleanupParser();

    return (info);
}


/* Doppler polynomial with respect to range in [Hz]/[pixel] */
/* Remark: This is an approximation */
/* For BIOMASS, several order 4 range polynomials are given for different azimuth time in [Hz]/[s] */
/* The nowadays InSAR processor only uses a single order 2 polynomial supposed to ba valid for the whole image */
/* we thus compute an order 2 average polynomial */
double *approxBIOMASSFDC(SLCImageInfo *info, xmlDocPtr ADSXMLDoc)
{
    int i, N ;
    double *t0, d0, d1, d2, dt, *fdc ;
    CSVStruct *csv ; 

    csv = readCSVInXMLFileForXPath((xmlChar*)"//dcEstimate/t0", ADSXMLDoc) ;
    N = csv->numberOfEntries ;
    t0 = vectorDouble(0, N - 1) ;
    for (i = 0; i < N; i++) {
        sscanf(csv->stringVal[i], "%lf", t0 + i) ;
    }
    freeCSVStruct(csv) ;

    fdc = vectorDouble(0, 2) ;
    csv = readCSVInXMLFileForXPath((xmlChar*)"//dcEstimate/geometryDCPolynomial", ADSXMLDoc) ;
    for (i = 0; i < N; i++) {
        sscanf(csv->stringVal[i], "%lf %lf %lf ", &d0, &d1, &d2) ;
        dt = info->twoWayRangeTime[0] - t0[i] ;
        fdc[0] += d0 + d1 * dt + d2 * dt * dt ;
        fdc[1] += d1 - 2 * d2 * dt ;
        fdc[2] += d2 ;
    }
    freeCSVStruct(csv) ;
    fdc[0] /= N ;
    fdc[1] /= N * info->rangeSamplingFrequency ;
    fdc[2] /= N * pow(info->rangeSamplingFrequency, 2.) ;

    freeVectorDouble(t0, 0 ) ;

    return (fdc) ;
}



struct stateVect *readAndSelectBIOMASSStateVectors(xmlDocPtr ORBXMLDoc, struct infoImage *info)
{
    int i, numberOfStateVectors = 0, firstStateVectorIndex, currentStateVectorIndex ;
    double *timeStamp ;
    CSVStruct *csv, *csvX, *csvY, *csvZ, *csvVx, *csvVy, *csvVz ;
    struct stateVect *stateVectors ;

    if((csv = getAttributeInXMLDocForXPath((xmlChar *)"//List_of_OSVs[@count]", ORBXMLDoc)) == NULL) {
        perror("No orbitList found in annotation data set") ;
        exit(-1) ;
    }
    sscanf(csv->stringVal[0], "%d", &numberOfStateVectors) ;
    freeCSVStruct(csv) ;

    /* We will first extract state vectors time stamps to select those encompassing the image swath */
    timeStamp = vectorDouble(0, numberOfStateVectors - 1) ;
    if((csv = readCSVInXMLFileForXPath((xmlChar*)"//OSV/UTC", ORBXMLDoc)) == NULL) {
        perror("Something wrong in orbit file...\nNo time stamps for state vecors\n") ;
        exit(-1) ;
    }
    if (csv->numberOfEntries != numberOfStateVectors) {
        perror("Something wrong in orbit file...\nNumber of time stamps different from number of expected state vectors\n") ;
        exit(-1) ;
    }
    for (i = 0; i < numberOfStateVectors; i++) {
        timeStamp[i] = getSecondsFromFormattedDate(csv->stringVal[i] + 4) ;
    }
    freeCSVStruct(csv) ;
    /* No information is given in reference document for that, but for now, we will consider that state vectors are time ordered */
    i = 0 ;
    do {
        firstStateVectorIndex = i ;
        i++ ;
    } while ((timeStamp[i] < info->FPAT) && (i < numberOfStateVectors));
    while ((timeStamp[i] < info->LPAT) && (i < numberOfStateVectors)) {
        i++ ;
    }
    i -= (i == numberOfStateVectors) ;
    info->nVect = numberOfStateVectors = i - firstStateVectorIndex + 1 ;

//info->nVect = numberOfStateVectors = 5 ;

    /* Now that we have the number of required state vectors, we can allocate them */
    info->S = stateVectors = allocVectorOfStateVectorsOfLength(numberOfStateVectors) ;

    /* Now, we extract all state vectors from ADS[0] */
    if ((csvX = readCSVInXMLFileForXPath((xmlChar*)"//OSV/X", ORBXMLDoc)) == NULL) {
        perror("No valid state vector X positions found in ADS...\n") ;
        exit(-1) ;
    }
    if ((csvY = readCSVInXMLFileForXPath((xmlChar*)"//OSV/Y", ORBXMLDoc)) == NULL) {
        perror("No valid state vector Y positions found in ADS...\n") ;
        exit(-1) ;
    }
    if ((csvZ = readCSVInXMLFileForXPath((xmlChar*)"//OSV/Z", ORBXMLDoc)) == NULL) {
        perror("No valid state vector Z positions found in ADS...\n") ;
        exit(-1) ;
    }
    if ((csvVx = readCSVInXMLFileForXPath((xmlChar*)"//OSV/VX", ORBXMLDoc)) == NULL) {
        perror("No valid state vector Vx velocity found in ADS...\n") ;
        exit(-1) ;
    }
    if ((csvVy = readCSVInXMLFileForXPath((xmlChar*)"//OSV/VY", ORBXMLDoc)) == NULL) {
        perror("No valid state vector Vy velocity found in ADS...\n") ;
        exit(-1) ;
    }
    if ((csvVz = readCSVInXMLFileForXPath((xmlChar*)"//OSV/VZ", ORBXMLDoc)) == NULL) {
        perror("No valid state vector Vz velocity found in ADS...\n") ;
        exit(-1) ;
    }

    /* Lets transfer values to state vector structure */
    for (i = 0; i < numberOfStateVectors; i++) {
        currentStateVectorIndex = firstStateVectorIndex + i ;
        stateVectors[i].t = timeStamp[currentStateVectorIndex] ;
        sscanf(csvX->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].P) ;
        sscanf(csvY->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].P + 1) ;
        sscanf(csvZ->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].P + 2) ;
        sscanf(csvVx->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].V) ;
        sscanf(csvVy->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].V + 1) ;
        sscanf(csvVz->stringVal[currentStateVectorIndex], "%lf", stateVectors[i].V + 2) ;
    }

    freeCSVStruct(csvX) ;
    freeCSVStruct(csvY) ;
    freeCSVStruct(csvZ) ;
    freeCSVStruct(csvVx) ;
    freeCSVStruct(csvVy) ;
    freeCSVStruct(csvVz) ;
    freeVectorDouble(timeStamp, 0) ;

    return (stateVectors) ;
}
