
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  COPERNICUSAccessLib.c
 *  AMSTerEngine
 *
 *  Created by Dominique Derauw on 9/2/2024.
 *  Copyright 2024 SAREOS - Dominique Derauw. All rights reserved.
 *
 */


#include "COPERNICUSAccessLib.h"

CSVStruct *getCopernicusTokens() 
{
    char *tokenFile ;
    CSVStruct *tokens = NULL, *aCSV ;

    tokenFile = initStringWithString("${HOME}/.CopernicusServerAccess") ;
    if(fileExistsAtPath(tokenFile)) {
        tokens = getCSVForKeyInJsonFile(tokenFile, "access_token") ;
        if(tokens) {
            if((aCSV = getCSVForKeyInJsonFile(tokenFile, "refresh_token"))) {
                tokens = addStringValInCSVStruct(aCSV->stringVal[0], tokens) ;
            }
            freeCSVStruct(aCSV) ;
        }
    }
    free(tokenFile) ;

    return(tokens) ;
}

time_t connectToCopernicusServer(CSVStruct *credentials)
{
    char *command = NULL ;
    CSVStruct *csv ;
   
    printf("\t\t---> Trying to connect to COPERNICUS\n") ;
    /* Try to log in */
    csv = addStringValInCSVStruct("curl --silent --location --request POST ", NULL) ;
    csv = addStringValInCSVStruct("\"https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token\" ", csv) ;
    csv = addStringValInCSVStruct("--header \"Content-Type: application/x-www-form-urlencoded\" ", csv) ;
    csv = addStringValInCSVStruct("--data-urlencode \"grant_type=password\" ", csv) ;
    csv = addStringValInCSVStruct("--data-urlencode \"username=", csv) ;
    csv = addStringValInCSVStruct(credentials->stringVal[0], csv) ;
    csv = addStringValInCSVStruct("\" ", csv) ;
    csv = addStringValInCSVStruct("--data-urlencode \"password=", csv) ;
    csv = addStringValInCSVStruct(credentials->stringVal[1], csv) ;
    csv = addStringValInCSVStruct("\" ", csv) ;
    csv = addStringValInCSVStruct("--data-urlencode \"client_id=cdse-public\" ", csv) ;
    csv = addStringValInCSVStruct(" > ${HOME}/.CopernicusServerAccess", csv) ;
    command = getStringFromCSV(csv) ;
//    printf("%s\n", command) ;
    system(command) ;
    free(command) ;
    free(csv) ;

    return (time(NULL)) ;
}

/* Just waiting a given number of seconds displaying countdown */
void waitAWhile(int sleepTime)
{
    int min, sec ;

    while (sleepTime > 0) {
        min = sleepTime / 60 ;
        sec = sleepTime - 60 * min ;
        sleep(1) ;
        if ((sleepTime / 2) * 2 == sleepTime) {
            printf("/ %d:%d \r", min, sec) ;
        }
        else {
            printf("\\ %d:%d \r", min, sec) ;
        }
        fflush(stdout) ;
        
        sleepTime-- ;
    }
    printf("\n") ;
}




CSVStruct *getCopernicusCredentials()
{
    char *buffer, *aLine ; 
    int ii ;
    rawFileDescriptor *netrcFile ;
    CSVStruct *credentials = NULL ;
    CSVStruct *login = NULL ;
    CSVStruct *password = NULL ;

    netrcFile = openRawFileForReadingAtPath("${HOME}/.netrc") ;
    if (!netrcFile) {
        ase("COPERNICUS server credentials not found (.netrc file missing)\n") ;
    }

    buffer = allocStringOfLength(netrcFile->fileLength) ;
    while ((aLine = fgets(buffer, netrcFile->fileLength, netrcFile->f))) {
        if (isSubStringPresentInString(aLine, "identity.dataspace.copernicus.eu")) {
            if ((ii = locateSubStringInString(aLine, "login")) > 0) {
                sscanf(aLine + ii + 5, "%s ", aComment) ;
                login = addStringValInCSVStruct(aComment, login) ;
            }
            if ((ii = locateSubStringInString(aLine, "password")) > 0) {
                sscanf(aLine + ii + 8, "%s ", aComment) ;
                password = addStringValInCSVStruct(aComment, password) ;
            }
        }
    }

    ii = 0 ;
    if (login && password && login->numberOfEntries > 1 && login->numberOfEntries == password->numberOfEntries) {
        printf ("Several logins available in netrc file. Please select the one to use:\n") ;
        for ( ii = 0; ii < login->numberOfEntries; ii++) {
            printf("%d ---> %s\n", ii + 1, login->stringVal[ii]) ;
        }
        ii = 0 ;
        while (!ii) {
            if (fgets(buffer, netrcFile->fileLength, stdin) != NULL) {
                sscanf(buffer, "%d", &ii) ;
            }
            if (!ii || ii > login->numberOfEntries) {
                printf("Please select a number between 1 and %d.\n", login->numberOfEntries) ;
                ii = 0 ;
            }
        }
        ii-- ;
        printf ("Chosen login is %s\n", login->stringVal[ii]) ;
    }

    credentials = addStringValInCSVStruct(login->stringVal[ii], credentials) ;
    credentials = addStringValInCSVStruct(password->stringVal[ii], credentials) ;
    freeCSVStruct(login) ;
    freeCSVStruct(password) ;
    freeRawFileDescriptor(netrcFile) ;

    return (credentials) ;

}


time_t refreshConnection(CSVStruct *tokens, CSVStruct *credentials)
{
    char *command = NULL ;
    char *tokenPath ; 
    CSVStruct *csv ;

    tokenPath = expandEnvironmentVariablesInPath("${HOME}/.CopernicusServerAccess") ;
    if (fileExistsAtPath(tokenPath)) {
        unlink(tokenPath) ;
    }
    
    /* Try to refresh connection */
    csv = addStringValInCSVStruct("curl --silent --location --request POST ", NULL) ;
    csv = addStringValInCSVStruct("\"https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token\" ", csv) ;
    csv = addStringValInCSVStruct("--header \"Content-Type: application/x-www-form-urlencoded\" ", csv) ;
    csv = addStringValInCSVStruct("--data-urlencode \"grant_type=refresh_token\" ", csv) ;
    csv = addStringValInCSVStruct("--data-urlencode \"refresh_token=", csv) ;
    csv = addStringValInCSVStruct(tokens->stringVal[1], csv) ;
    csv = addStringValInCSVStruct("\" ", csv) ;
    csv = addStringValInCSVStruct("--data-urlencode \"client_id=cdse-public\" ", csv) ;
    csv = addStringValInCSVStruct(" > ${HOME}/.CopernicusServerAccess", csv) ;
    command = getStringFromCSV(csv) ;
//    printf("%s\n", command) ;
    system(command) ;
    free(command) ;
    free(csv) ;

    csv = getCopernicusTokens() ;
    if(csv) {
        freeCSVStruct(csv) ;
    }
    else {
        if(fileExistsAtPath(tokenPath)) {
            csv = getCSVForKeyInJsonFile(tokenPath, "error_description") ;
            if (csv && isSubStringPresentInString(csv->stringVal[0], "Token is not active")) {
                printf("COPERNICUS token not active anymore\n") ;
                printf("Will wait a while before trying to reconnect\n") ;
                waitAWhile(600) ;
                return(connectToCopernicusServer(credentials)) ;
            }
        }
    }
    free(tokenPath) ;

    return (time(NULL)) ;
 }

/* Build and return a string attribute request */
char *getCOPERNICUSStringAttributeRequest(char *attributeName, char *attributeValue)
{
    char *request ;
    CSVStruct *csv ;

    csv = addStringValInCSVStruct("Attributes/OData.CSC.StringAttribute/any(att:att/Name%20eq%20%27", NULL) ;
    csv = addStringValInCSVStruct(attributeName, csv) ;
    csv = addStringValInCSVStruct("%27%20and%20att/OData.CSC.StringAttribute/Value%20eq%20%27", csv) ;
    csv = addStringValInCSVStruct(attributeValue, csv) ;
    csv = addStringValInCSVStruct("%27)", csv) ;

    request = getStringFromCSV(csv) ;

    freeCSVStruct(csv) ;

    return(request) ;
}

 /* Build and return an int attribute request */
char *getCOPERNICUSIntegerAttributeRequest(char *attributeName, int attributeValue)
{
    char *request, stringVal[16] ;
    CSVStruct *csv ;

    sprintf(stringVal, "%d", attributeValue) ;
    csv = addStringValInCSVStruct("Attributes/OData.CSC.IntegerAttribute/any(att:att/Name%20eq%20%27", NULL) ;
    csv = addStringValInCSVStruct(attributeName, csv) ;
    csv = addStringValInCSVStruct("%27%20and%20att/OData.CSC.IntegerAttribute/Value%20eq%20", csv) ;
    csv = addStringValInCSVStruct(stringVal, csv) ;
    csv = addStringValInCSVStruct(")", csv) ;

    request = getStringFromCSV(csv) ;

    freeCSVStruct(csv) ;

    return(request) ;
}

char *getCOPERNICUSPolygonRequestFromKml(polygon *aoi)
{
    char request[192], *polygonRequest ;
    int i ;
    CSVStruct *csv = NULL ;

    sprintf(request, "OData.CSC.Intersects(area=geography%%27SRID=4326;POLYGON%%20((%-.3lf%%20%-.3lf", aoi->P[0].x, aoi->P[0].y) ;
    csv = addStringValInCSVStruct(request, csv) ;
    for (i = 1; i < aoi->N; i++) {
        sprintf(request, ",%-.3lf%%20%-.3lf", aoi->P[i].x, aoi->P[i].y) ;
        csv = addStringValInCSVStruct(request, csv) ;
    }
    sprintf(request, "))%%27)") ;
    csv = addStringValInCSVStruct(request, csv) ;
    polygonRequest = getStringFromCSV(csv) ;

    freeCSVStruct(csv) ;

    return(polygonRequest) ;
}