
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


/*
 *  stringLib.c
 *  trackDataReader
 *
 *  Created by Dominique Derauw on 3/02/05.
 *  Copyright 2005 Dominique Derauw. All rights reserved.
 *
 */

#include "stringLib.h"

char *allocStringOfLength(size_t length)
{
	char	*str ;

    length++ ;
    if((str = calloc(1, length)) == NULL) {
		perror("String allocation error ") ;
        exit(-1) ;
    }

	return str ;
}


/* Lecture de la première chaine de carractère d'une ligne de texte */
char *readFirstStringIn(char *aString)
{
    char	*firstString ;
	char	buffer[MAXSTRINGLENGTH] ;

	if(aString != NULL) {
		sscanf(aString, "%s ", buffer) ;
		if((firstString = (char *)calloc(1, strlen(buffer) + 1)) == NULL)
			perror("String allocation error\n") ;
		sprintf(firstString, "%s", buffer) ;
    }
    else {
        firstString = allocStringOfLength(0) ;
    }

    return firstString ;
}

char *getStringUpToDelimiter(char *aString, char *delimiter)
{
    char *readString = NULL ;
    int stringLength ;

    stringLength = locateSubStringInString(aString, delimiter) ;
    if(stringLength > 0) {
        readString = allocStringOfLength(stringLength) ;
        memcpy(readString, aString, stringLength) ;
    }

    return(readString) ;
}

char *getStringAfterDelimiter(char *aString, char *delimiter)
{
    char *readString = NULL ;
    int stringLength, i0 ;

    i0 = locateSubStringInString(aString, delimiter) ;
    if(i0 > 0) {
        stringLength = (int)strlen(aString) - i0++ ;
        readString = allocStringOfLength(stringLength) ;
        memcpy(readString, aString + i0, stringLength) ;
    }

    return(readString) ;
}


char *concatenateStrings(char *firstString, char *secondString)
{
    char *aString ;
    size_t stringLength1, stringLength2 ;

    if (firstString == NULL || secondString == NULL) {
        return (NULL) ;
    }
    stringLength1 = strlen(firstString) ;
    stringLength2 = strlen(secondString) ;

    aString = allocStringOfLength(stringLength1 + stringLength2) ;
    memcpy(aString, firstString, stringLength1) ;
    memcpy(aString + stringLength1, secondString, stringLength2) ;

    return(aString) ;
}

char isWhiteChar(char *aChar)
{
    return((*aChar == ' ') || (*aChar == '\n') || (*aChar == '\r') || (*aChar == '\t')) ;
}

/* Strip white characters at start of string */
void stripWhiteCharsAtStartOfString(char *aString)
{
    int i, i0, stringLength ;

    stringLength = (int)strlen(aString) ;
    if(!(i = stringLength)) return ;

    i = 0 ;
    while(i < stringLength) {
        if(strncmp(aString + i, " ", 1) && (aString[i] != '\n') && (aString[i] != '\r') && (aString[i] != '\t')) break ;
        i++ ;
    }
    if (i) {
        i0 = i ;
        stringLength -= i ;
        for (i = 0; i < stringLength; i++) {
            aString[i] = aString[i + i0] ;
        }
        aString[i] = '\0' ;
    }
}

/* Strip white chars in string */
void stripWhiteCharsInString(char *aString)
{
    int i, stringLength ;
        
    stripWhiteCharsAtStartOfString(aString) ;
    stringLength = (int)strlen(aString) ;
    if(!(i = stringLength)) return ;

    i = 0 ;
    while (i < stringLength) {
        while (!isWhiteChar(aString + i) && (i < stringLength)) {
            i++ ;
        }
        stripWhiteCharsAtStartOfString(aString + i) ;
        stringLength = (int)strlen(aString) ;
    }
}

/* Strip white characters at end of string */
void stripWhiteCharsAtEndOfString(char *aString)
{
    int i ;

    if(!(i = (int)strlen(aString))) return ;

    i-- ;
    while(i >= 0) {
        if(strncmp(&aString[i], " ", 1) && (aString[i] != '\n') && (aString[i] != '\r') && (aString[i] != '\t')) break ;
        i-- ;
    }
    aString[i + 1] = '\0' ;
}

/* Strip trailing zeros at end of string number */
void stripTrailingZerosAtEndOfStringNumber(char *aString)
{
    int i ;

    if(!(i = (int)strlen(aString))) return ;

    i-- ;
    while(i >= 0) {
        if(strncmp(&aString[i], "0", 1)) break ;
        i-- ;
    }
    if (!strncmp(&aString[i], ".", 1)) {
        aString[i] = '\0' ;
    }
    aString[i + 1] = '\0' ;
}

void replaceWhiteCharsInStringByChar(char *aString, char replacementChar)
{
    size_t i, stringLength ;

	if(!(stringLength = strlen(aString))) return ;
    for (i = 0; i < stringLength; i++) {
        if(!strncmp(&aString[i], " ", 1) || (aString[i] == '\n') || (aString[i] == '\r') || (aString[i] == '\t') || (aString[i] == 0x1a))
            strncpy(&aString[i], &replacementChar, 1);
    }
}

/* Replace subString with subString of same length in string */
char replaceSubStringInString(char *aString, char *subStringToFind, char *replacementString)
{
	int i ;
    size_t subStringLength, replacementStringLength ;

    subStringLength = strlen(subStringToFind) ;
    replacementStringLength = strlen(replacementString) ;
	if(subStringLength > replacementStringLength)
		return(SUBSTRINGTOOBIG) ;

	i = locateSubStringInString(aString, subStringToFind) ;
	if(i < 0) return i ;
    
	strncpy(aString + i, replacementString, subStringLength) ;

	return(0) ;
}

/* Replace subString with subString of same length in string */
char replaceNSubStringInString(char *aString, char *subStringToFind, char *replacementString)
{
    int err ;

	while ((err = replaceSubStringInString(aString, subStringToFind, replacementString)) >= 0) {
    }
	if (err == SUBSTRINGNOTFOUND) {
        return (0) ;
    }
	return(err) ;
}

/* Create a new string replacing any occurrence of substring in string */
/* If no occurences are found, a copy of input string is returned */
char *replaceSubStringsInString(char *aString, char *subStringToFind, char *replacementString)
{
    char *newString, *searchedString ;
    int i0, i ;
    size_t newStringLength = 0, subStringLength, replacementStringLength ;
    CSVStruct *csv = NULL ;
    
    searchedString = initStringWithString(aString) ;
    subStringLength = strlen(subStringToFind) ;
    replacementStringLength = strlen(replacementString) ;
    i0 = 0 ;
    while ((i = locateSubStringInString(searchedString + i0, subStringToFind)) >= 0) {
        searchedString[i + i0] = '\0' ;
        csv = addStringValInCSVStruct(searchedString + i0, csv) ;
        newStringLength += strlen(searchedString + i0) + replacementStringLength ;
        i0 += i + (int)subStringLength ;
    }

    if (newStringLength) {
        addStringValInCSVStruct(searchedString + i0, csv) ;
        newStringLength += strlen(searchedString + i0) ;
        
        newString = allocStringOfLength(newStringLength) ;
        i0 = 0 ;
        for (i = 0; i < csv->numberOfEntries - 1; i++) {
            sprintf(newString + i0, "%s%s", csv->stringVal[i], replacementString) ;
            i0 += strlen(csv->stringVal[i]) + replacementStringLength ;
        }
        sprintf(newString + i0, "%s", csv->stringVal[i]) ;
        freeCSVStruct(csv) ;
    }
    else {
        newString = initStringWithString(aString) ;
    }
    
    free(searchedString) ;
    
    return(newString) ;
}


/* Return the given string escaping characters (\) that need to be escaped */
char *escapeCharInString(char *aString, char *charToEscape)
{
    char escapedString[3] ;
    
    escapedString[0] = (char)(0x5C) ;
    memcpy(escapedString + 1, charToEscape, 1) ;
    escapedString[2] = (char)(0x0) ;

    return (replaceSubStringsInString(aString, charToEscape, escapedString)) ;
}



int isSubStringPresentInString(char *aString, char *subStringToFind)
{
    return(locateSubStringInString(aString, subStringToFind) >= 0) ;

}

/* This function points after first occurrence of sub-string in a given string */
char *getStringAfterSubStringInString(char *aString, char *aSubString)
{
    return(aString + locateSubStringInString(aString, aSubString) + strlen(aSubString)) ;
}

/* This function finds the first occurence of a substring within a given string and returns its start position */
int locateSubStringInString(char *aString, char *subStringToFind)
{
	size_t i, searchLength, subStringLength ;

    if (!aString) {
        return(SUBSTRINGNOTFOUND) ;
    }
	subStringLength = strlen(subStringToFind) ;
    if(!subStringLength) {
        return SUBSTRINGNOTFOUND ;
    }
    if(strlen(aString) < subStringLength) {
		return(STRINGTOOSMALL) ;
    }

    searchLength = (strlen(aString) - subStringLength + 1) ;
	i = 0 ;
	while(strncmp(aString + i, subStringToFind, subStringLength) && (i < searchLength)) {
		i++ ;
	}
    if(i == searchLength) {
		return(SUBSTRINGNOTFOUND) ;
    }

	return((int)i) ;
}

void removeStringInString(char *aString, char *stringToRemove)
{
    char *endString ;
    int i ;
    size_t subStringLength, endStringLength ;

    subStringLength = strlen(stringToRemove) ;

    if((i = locateSubStringInString(aString, stringToRemove)) < 0)
        return ;

    if ((endString = initStringWithString(&aString[i + subStringLength])) != NULL) {
        endStringLength = strlen(endString) ;
        memcpy(&aString[i], endString, endStringLength) ;
        aString[i + endStringLength] = '\0' ;
        free(endString)  ;
    }
    else
        aString[i] = '\0' ;
}

void removeAnyOccurrenceOfSubStringInString(char *aString, char *stringToRemove)
{
    char *endString ;
    int i ;
    size_t subStringLength, endStringLength ;

    subStringLength = strlen(stringToRemove) ;

    while ((i = locateSubStringInString(aString, stringToRemove)) >= 0) {
        if ((endString = initStringWithString(&aString[i + subStringLength])) != NULL) {
            endStringLength = strlen(endString) ;
            memcpy(&aString[i], endString, endStringLength) ;
            aString[i + endStringLength] = '\0' ;
            free(endString)  ;
        }
        else
            aString[i] = '\0' ;
    }

}

void convertStringToLowercase(char *aString)
{
    size_t i, stringLength ;

    if(aString == NULL)
       return ;

    stringLength = strlen(aString) ;
    for (i = 0; i < stringLength; i++) {
        if (aString[i] >= 65 && aString[i] <= 90) {
            aString[i] += 32 ;
        }
    }
}

void convertStringToUppercase(char *aString)
{
    size_t i, stringLength ;

    if(aString == NULL)
       return ;

    stringLength = strlen(aString) ;
    for (i = 0; i < stringLength; i++) {
        if (aString[i] >= 97 && aString[i] <= 122) {
            aString[i] -= 32 ;
        }
    }
}

char *initStringWithString(char *aString)
{
	char *aNewString ;
	long stringLength ;

    aNewString = NULL ;
    if(aString) {
        stringLength = strlen(aString) ;
        aNewString = allocStringOfLength(stringLength) ;
        if((stringLength)) {
            memcpy(aNewString, aString, stringLength) ;
        }
    }

	return(aNewString) ;
}

/* Initialize a new string with a non-null terminated string of known max length */
char *initStringWithStringOfLength(char *aString, size_t stringLength)
{
	char *aNewString ;

    aNewString = NULL ;
    if(aString && stringLength) {
        aNewString = allocStringOfLength(stringLength + 1) ;
        memcpy(aNewString, aString, stringLength) ;
        stripWhiteCharsAtEndOfString(aNewString) ;
    }

	return(aNewString) ;
}

char *initStringWith2Strings(char *string1, char *string2)
{
	char *aNewString ;
	long stringLength ;

    aNewString = NULL ;
    if(string1 && string2) {
        stringLength = strlen(string1) + strlen(string2) ;
        aNewString = allocStringOfLength(stringLength) ;
        sprintf(aNewString, "%s%s", string1, string2) ;
	}
    else {
        if (string1) {
            aNewString = initStringWithString(string1) ;
        }
        if (string2) {
            aNewString = initStringWithString(string2) ;
        }   
    }
    

	return(aNewString) ;
}

char *initStringWith3Strings(char *string1, char *string2, char *string3)
{
	char *aNewString ;
	long stringLength ;

    aNewString = NULL ;
    if(string1 && string2 && string3) {
        stringLength = strlen(string1) + strlen(string2) + strlen(string3) ;
        aNewString = allocStringOfLength(stringLength) ;
        sprintf(aNewString, "%s%s%s", string1, string2, string3) ;
	}
    else {
        if (!string1) {
            aNewString = initStringWith2Strings(string2, string3) ;
        }
        else {
            if (!string2) {
                aNewString = initStringWith2Strings(string1, string3) ;
            }
            else {
                aNewString = initStringWith2Strings(string1, string2) ;
            }   
        }        
    }

	return(aNewString) ;
}


char *initStringWith4Strings(char *string1, char *string2, char *string3, char *string4)
{
	char *aNewString ;
	long stringLength ;

    aNewString = NULL ;
    if(string1 && string2 && string3 && string4) {
        stringLength = strlen(string1) + strlen(string2) + strlen(string3) + strlen(string4) ;
        aNewString = allocStringOfLength(stringLength) ;
        sprintf(aNewString, "%s%s%s%s", string1, string2, string3, string4) ;
	}
    else {
        if (!string1) {
            aNewString = initStringWith3Strings(string2, string3, string4) ;
        }
        else {
           if (!string2) {
                aNewString = initStringWith3Strings(string1, string3, string4) ;
            }
            else {
                if (!string3) {
                    aNewString = initStringWith3Strings(string1, string2, string4) ;
                }
                else {
                    aNewString = initStringWith3Strings(string1, string2, string3) ;
                }
            }
        }        
    }
	return(aNewString) ;
}


void removeEmptyValsInCSV(CSVStruct *csv)
{
    char **stringVal ;
    int i, i2, numberOfEntries ;
    size_t stringValLength ;

    numberOfEntries = csv->numberOfEntries ;
    for (i = 0; i < csv->numberOfEntries; i++) {
        if (!csv->stringVal[i]) {
            numberOfEntries-- ;
        }
        else {
            if (!strlen(csv->stringVal[i])) {
                numberOfEntries-- ;
            }
        }
    }
    if (numberOfEntries) {
        if (numberOfEntries != csv->numberOfEntries) {
            stringVal = malloc(numberOfEntries * sizeof(char *)) ;
            for (i = i2 = 0; i < csv->numberOfEntries; i++) {
                stringValLength = 0 ;
                if (csv->stringVal[i]) {
                    stringValLength = strlen(csv->stringVal[i]) ;
                }
                
                if (stringValLength) {
                    stringVal[i2] = allocStringOfLength(stringValLength) ;
                    memcpy(stringVal[i2], csv->stringVal[i], stringValLength) ;
                    i2++ ;
                }
                free(csv->stringVal[i]) ;
            }
            free(csv->stringVal) ;
            csv->stringVal = stringVal ;
            csv->numberOfEntries = i2 ;
        }
    }
    else {
        /* we return an empty csv, not a NULL one */
        for(i = 0; i < csv->numberOfEntries; i++) {
            free(csv->stringVal[i]) ;
        }
        free(csv->stringVal) ;
        csv->stringVal = NULL ;
        csv->numberOfEntries = 0 ;
    }
}

/* Read Comma Separated Values in a String and returns a CSV structure */
CSVStruct *readCSVInString(char *aString)
{
	size_t i, i0, N ;
	CSVStruct *csv ;

    csv = allocCSVStruct() ;

	N = 0 ;
	for(i = 0; i < strlen(aString); i++) {
		if(!strncmp(&aString[i], ",", 1))
			N++ ;
	}
	csv->numberOfEntries = N + 1 ;
	csv->stringVal = malloc(csv->numberOfEntries * sizeof(char *)) ;

	N = i0 = 0 ;
	for(i = 0; i < strlen(aString); i++) {
		while (!strncmp(&aString[i0], " ", 1)) {
			i0++ ;
			i++ ;
		}
		if(!strncmp(&aString[i], ",", 1)) {
			csv->stringVal[N] = allocStringOfLength(i - i0) ;
			memcpy(csv->stringVal[N], &aString[i0], i - i0) ;
			i0 = i + 1 ;
			N++ ;
		}
	}
	csv->stringVal[N] = (aString[i0])? initStringWithString(&aString[i0]) : initStringWithString("") ;

	return(csv) ;
}

/* Read White Char Seperated Values in a String and returns a CSV structure */
/* White chars are blank space or tab */
CSVStruct *readWhiteCharSeperatedValuesInString(char *aString)
{
	size_t i, i0, N ;
	CSVStruct *csv ;

    csv = allocCSVStruct() ;

	N = i = 0 ;
    while (!strncmp(&aString[i++], " ", 1)) {
    }
	for(; i < strlen(aString); i++) {
		if(!strncmp(&aString[i], " ", 1) || !strncmp(&aString[i], "\t", 1))
			N++ ;
		while (!strncmp(&aString[i], " ", 1)) {
			i++ ;
		}
	}
	csv->numberOfEntries = N + 1 ;
	csv->stringVal = malloc(csv->numberOfEntries * sizeof(char *)) ;

	N = i0 = i = 0 ;
    while (!strncmp(&aString[i0], " ", 1)) {
        i0++ ;
        i++ ;
    }
	for(; i < strlen(aString); i++) {
		if(!strncmp(&aString[i], " ", 1) || !strncmp(&aString[i], "\t", 1)) {
			csv->stringVal[N] = allocStringOfLength(i - i0) ;
			memcpy(csv->stringVal[N], &aString[i0], i - i0) ;
            while (!strncmp(&aString[++i], " ", 1)) {
            }
			i0 = i ;
			N++ ;
		}
	}
	csv->stringVal[N] = initStringWithString(&aString[i0]) ;

	return(csv) ;
}


CSVStruct *addIntValInCSVStruct(int anInt, CSVStruct *csv)
{
    char aStringVal[40] ;

    sprintf(aStringVal, "%d", anInt) ;
    return (addStringValInCSVStruct(aStringVal, csv)) ;
}

CSVStruct *addLongValInCSVStruct(long aLong, CSVStruct *csv)
{
    char aStringVal[40] ;

    sprintf(aStringVal, "%ld", aLong) ;
    return (addStringValInCSVStruct(aStringVal, csv)) ;
}

CSVStruct *addFloatValInCSVStruct(float aFloat, CSVStruct *csv)
{
    char aStringVal[40] ;

    sprintf(aStringVal, "%f", aFloat) ;
    stripTrailingZerosAtEndOfStringNumber(aStringVal) ;
    return (addStringValInCSVStruct(aStringVal, csv)) ;
}

CSVStruct *addStringValInCSVStruct(char *aStringValue, CSVStruct *csv)
{
    char **stringValue ;
    int i ;

    if(csv == NULL) {
        csv = allocCSVStruct() ;
    }

    csv->numberOfEntries++ ;
    stringValue = malloc(csv->numberOfEntries * sizeof(char *)) ;
    for (i = 0; i < csv->numberOfEntries - 1; i++) {
        stringValue[i] = csv->stringVal[i] ;
    }
    stringValue[i] = initStringWithString(aStringValue) ;
    if(csv->stringVal) {
        free(csv->stringVal) ;
    }
    csv->stringVal = stringValue ;

    return (csv) ;
}

CSVStruct *concatenateCSVStructs(CSVStruct *csv1, CSVStruct *csv2)
{
    int i = 0, i2 ;
    CSVStruct *csv ;
    
    csv = allocCSVStruct() ;
    csv->numberOfEntries = (csv1) ? csv1->numberOfEntries : 0 ;
    csv->numberOfEntries += (csv2) ? csv2->numberOfEntries : 0 ;
    csv->stringVal = malloc(csv->numberOfEntries * sizeof(char *)) ;
    if (csv1) {
        for (i = 0; i < csv1->numberOfEntries; i++) {
            csv->stringVal[i] = initStringWithString(csv1->stringVal[i]) ;
        }
    }
    
    if(csv2) {
        for (i2 = 0; i2 < csv2->numberOfEntries; i++, i2++) {
            csv->stringVal[i] = initStringWithString(csv2->stringVal[i2]) ;
        }
    } 
    
    return (csv) ;
}

int isIntValPresentInCSV( int anInt, CSVStruct *csv)
{
    char aStringVal[40] ; 

    sprintf(aStringVal, "%d", anInt) ;
    return (isStringValPresentInCSV(aStringVal, csv)) ;
}

int isStringValPresentInCSV(char *aStringValue, CSVStruct *csv)
{
    int i, isPresent ;

    isPresent = 0 ;

    if (csv && aStringValue) {
        for (i = 0; i < csv->numberOfEntries; i++) {
            if (isSubStringPresentInString(csv->stringVal[i], aStringValue)) {
                isPresent = i + 1 ;
            }
        }
    }
    return (isPresent) ;
}

CSVStruct *removeStringValInCSVStruct(char *aStringValue, CSVStruct *csv)
{
    int i ;

    for (i = 0; i < csv->numberOfEntries; i++) {
        if (!strcmp(aStringValue, csv->stringVal[i])) {
            csv->stringVal[i][0] = '\0' ;
        }
    }
    removeEmptyValsInCSV(csv) ;

    return (csv) ;
}

CSVStruct *removeStringValAtIndexInCSVStruct(int i, CSVStruct *csv)
{
    if (i >= 0 && i < csv->numberOfEntries) {
        csv->stringVal[i][0] = '\0' ;
        removeEmptyValsInCSV(csv) ;
    }

    return (csv) ;
}

/* Allocate a Comma Separated Value structure */
CSVStruct *allocCSVStruct(void)
{
    CSVStruct *csv ;

    if((csv = malloc(sizeof(CSVStruct))) == NULL) {
		perror("Failed to allocate a CSV structure\n") ;
        exit(-1) ;
    }
    csv->numberOfEntries = 0;
    csv->stringVal = NULL ;

    return(csv) ;
}

/* Free a Comma Separated Value structure */
void freeCSVStruct(CSVStruct *csv)
{
	int i ;

    if(csv) {
        for(i = 0; i < csv->numberOfEntries; i++) {
            if (csv->stringVal[i]) {
                free(csv->stringVal[i]) ;
            }
        }

        if (csv->stringVal) {
            free(csv->stringVal) ;
        }

        free(csv) ;
 //       *(&csv) = NULL ;
    }
}

/* Search for a given key in a CSVStruct and returns the pointer to the next character considered as the pointer to the value */
char *getValForKeyInCSV(CSVStruct *csv, const char *key)
{
    char *val = NULL ;
    int i ;
    size_t len ;

    len = strlen(key) ;
    if ((i = isArgumentPresentInCSV(csv, key))) {
        val = csv->stringVal[i] + len ;
    }
    return (val) ;
}


/* ________________ Return non zero value if keyword is present in csv ________________ */
int isArgumentPresentInCSV(CSVStruct *csv, const char *searchedArgument)
{
    int i, isSearchedArgumentPresent = 0 ;
    
    i = 0 ;
    if (csv) {
        while(i < csv->numberOfEntries) {
            if (csv->stringVal[i]) {
                if (!strncmp(csv->stringVal[i], searchedArgument, strlen(searchedArgument))) {
                    break ;
                }
            }
                
            i++ ;
        }
        if(i < csv->numberOfEntries) {
            isSearchedArgumentPresent = i ;
        }
    }
    
    return isSearchedArgumentPresent ;
}

/* ________________ Return non zero value if flag is present in csv ________________ */
/* A flag being a single letter within a set preceeded by a single hyphen */
char isFlagPresentInCSV(CSVStruct *csv, const char *searchedFlag)
{
    char    isSearchedArgumentPresent = 0 ;
    int i, k ;
    size_t j, argLen ;
    
    if (csv) {
        i = 1 ;
        k = (strncmp(searchedFlag, "-", 1))? 0 : 1 ;
        while(i < csv->numberOfEntries) {
            argLen = strlen(csv->stringVal[i]) ;
            if (argLen > 1) {
                if(!strncmp(csv->stringVal[i], "-", 1) && strncmp(csv->stringVal[i], "--", 2)) {
                    j = 0 ;
                    while (j < argLen) {
                        if (csv->stringVal[i][j] == searchedFlag[k]) {
                            if (j < argLen - 1 && csv->stringVal[i][j + 1] == '=') {
                                isSearchedArgumentPresent = 0 ;
                            }
                            else
                                isSearchedArgumentPresent = 1 ;
                        }
                        j++ ;
                    }
                }
            }
            i++ ;
        }
    }
    
    return isSearchedArgumentPresent ;
}

CSVStruct *getCSVWithStringInCSV(char *stringToLookFor, CSVStruct *aCSV) 
{
    int anIndex ;
    CSVStruct *outputCSV = NULL ;

    if (aCSV) {
        for (anIndex = 0; anIndex < aCSV->numberOfEntries; anIndex++) {
            if (isSubStringPresentInString(aCSV->stringVal[anIndex], stringToLookFor)) {
                outputCSV = addStringValInCSVStruct(aCSV->stringVal[anIndex], outputCSV) ;
            }         
        }
    }
    
    return(outputCSV) ;
}

/* Concatenate csv in a single string (without spaces) */
char *getStringFromCSV(CSVStruct *csv)
{
    char *outputString ;
    int i ;
    size_t stringLength = 0 ;

    for (i = 0; i < csv->numberOfEntries; i++) {
        stringLength += strlen(csv->stringVal[i]) ;
    }
    outputString = allocStringOfLength(stringLength) ;

    stringLength = 0 ;
    for (i = 0; i < csv->numberOfEntries; i++) {
        sprintf(outputString + stringLength, "%s" , csv->stringVal[i]) ;
        stringLength += strlen(csv->stringVal[i]) ;
    }

    return (outputString) ;
}

/* Concatenate a csv in a single csv string (each value being seperated by ", ") */
char *getCSVStringFromCSV(CSVStruct *csv)
{
    char *outputString ;
    int i ;
    size_t stringLength = 0 ;

    for (i = 0; i < csv->numberOfEntries; i++) {
        stringLength += strlen(csv->stringVal[i]) + 2 ;
    }
    outputString = allocStringOfLength(stringLength) ;

    stringLength = 0 ;
    sprintf(outputString + stringLength, "%s" , csv->stringVal[0]) ;
    for (i = 1; i < csv->numberOfEntries; i++) {
        stringLength += strlen(csv->stringVal[i - 1]) ;
        sprintf(outputString + stringLength, ", %s" , csv->stringVal[i]) ;
        stringLength += 2 ;
    }

    return (outputString) ;
}


