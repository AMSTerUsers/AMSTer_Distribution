
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/



#include "basicTiffLib.h"


/* Read short in tiff file at given offset */
/* If offset is 0, tag is read at current file position */
short readShortInTiffFile(rawFileDescriptor *thisFile, long offset)
{
    short aShort ;

    if (offset) {
        fseek(thisFile->f, offset, SEEK_SET) ;
    }
    if (fread(&aShort, 2, 1, thisFile->f) != 1) {
        ase("Failed to read short val in tiff file\n") ;
    }
    if(thisFile->swapBytes) {
        swap2bytesStruct(&aShort) ;
    }

    return (aShort) ;
}

/* Read int in tiff file at given offset */
/* If offset is 0, tag is read at current file position */
int readIntInTiffFile(rawFileDescriptor *thisFile, long offset)
{
    int anInt ;

    if (offset) {
        fseek(thisFile->f, offset, SEEK_SET) ;
    }
    if (fread(&anInt, 4, 1, thisFile->f) != 1) {
        ase("Failed to read int val in tiff file\n") ;
    }
    if(thisFile->swapBytes) {
        swap4bytesStruct(&anInt) ;
    }

    return (anInt) ;
}

/* Read tiff tag at given offset */
/* If offset is 0, tag is read at current file position */
tiffTag readTagInTiffFile(rawFileDescriptor *thisFile, long offset)
{
    tiffTag thisTag ;

    if (offset) {
        fseek(thisFile->f, offset, SEEK_SET) ;
    }
    
    if (fread(&thisTag, 12, 1, thisFile->f) != 1) {
        ase("Failed to read int val in tiff file\n") ;
    }
    if(thisFile->swapBytes) {
        swap4bytesStruct(&thisTag.tagID) ;
        swap4bytesStruct(&thisTag.dataType) ;
        swap4bytesStruct(&thisTag.dataCount) ;
        swap4bytesStruct(&thisTag.offset) ;
    }
    thisTag.data = NULL ;

    return (thisTag) ;
}

tiffIFD *readIFDInTiffFile(rawFileDescriptor *thisFile, long offset)
{
    short nTags, i ;
    tiffIFD *ifd = NULL ;

    nTags = readShortInTiffFile(thisFile, offset) ;
    
    /* Alloc anr read ifd */
    if (!(ifd = malloc(sizeof(ifd[0])))) {
        ase("Failed to allocate image file directory.\n") ;
    }
    if (!(ifd->tag = malloc(nTags * sizeof(ifd->tag[0])))) {
        ase("Failed to allocate tags in image file directory.\n") ;
    }
    
    for (i = 0; i < nTags; i++) {
        ifd->tag[i] = readTagInTiffFile(thisFile, 0) ;
    }
    offset = ifd->offset = readIntInTiffFile(thisFile, 0) ;
    ifd->nTags = nTags ;
    ifd->nextOne = NULL ;

    return(ifd) ;
}


tiffFileDescriptor *parseTiffFileAtPath(char *aPath)
{
    int nTags, nIFD, offset, i ;
    tiffFileDescriptor *desc = NULL ;
    rawFileDescriptor *tiffFile ;
    tiffHeader *header ;
    tiffIFD *ifd ;

    if (!(tiffFile = openRawFileForReadingAtPath(aPath))) {
        ase("\t-/-> Failed to open input file for reading.\n") ;
    }
    if (!(header = malloc(sizeof(header[0])))) {
        ase("\t-/-> Failed to allocate tiff header.\n") ;
    }
    if (fread(header, sizeof(header[0]), 1, tiffFile->f) != 1) {
        ase("\t-/-> Failed to read file header.\n") ;
    }

    tiffFile->fileByteOrder = (header->tiffID == TIFF_BIGENDIAN)? 1 : (header->tiffID == TIFF_LITTLEENDIAN)? 0 : -1 ;
    if(tiffFile->fileByteOrder < 0) {
        ase("\t-/-> Tiff file magic number not recognized\n") ;
    }
    if (tiffFile->fileByteOrder != tiffFile->byteOrder) {
        tiffFile->swapBytes = 1 ;
        swapShort(&header->tiffVersion) ;
        swapInt(&header->ifdOffset) ;
    }
    
    if (header->tiffVersion == 43) {
        ase("Input file is a BigTiff files. stopping here.\n") ;
    }
    if (header->tiffVersion != 42) {
        ase("input file is not a tiff file, Stopping here.\n") ;
    }

    if (!(desc = malloc(sizeof(desc[0])))) {
        ase("\t-/-> Failed to allocate tiff file descriptor. \n") ;
    }
    
    if (!(offset = header->ifdOffset)) {
        ase("\t-/-> No image directory file in tiff file (first offset = 0).") ;
    }
    
    /* Read first IFD */
    desc->header = header ;
    desc->ifd = ifd = readIFDInTiffFile(tiffFile, offset) ;
    offset = ifd->offset ;
    
    /* Read IFD sequentially */
    nIFD = 1 ;
    while (offset) {
        nIFD++ ;
        nTags = readShortInTiffFile(tiffFile, offset) ;
        
        ifd->nextOne = readIFDInTiffFile(tiffFile, offset) ;
        ifd = ifd->nextOne ;
        offset = ifd->offset ;
    }
    desc->nIFD = nIFD ;
    
    if (!(desc->ifdVect = malloc(nIFD * sizeof(desc->ifdVect[0])))) {
        ase("\t-/-> Failed to allocate image data file vector.\n") ;
    }
    ifd = desc->ifd ;
    i = 0 ;
    do {
        desc->ifdVect[i] = ifd ;
        ifd = ifd->nextOne ;
        i++ ;
    } while (ifd->nextOne);
    desc->ifdVect[i] = ifd ;
    
    desc->tiffFile = tiffFile ;

    return(desc) ;
}


void freeTiffFileDescriptor(tiffFileDescriptor *desc)
{
    int i ;
    tiffIFD *ifd0, *ifd ;
    tiffTag thisTag ;

    ifd0 = ifd = desc->ifd ;
    do {
        for (i = 0; i < ifd->nTags; i++) {
            thisTag = ifd->tag[i] ;
            if (ifd->tag[i].data) {
                free(ifd0->tag[i].data) ;
            } 
        }
        
        free(ifd->tag) ;
        ifd0 = ifd ;
        ifd = ifd->nextOne ;
        free(ifd0) ;
    } while (ifd) ;

    free(desc->header) ;
    free(desc->ifdVect) ;
    freeRawFileDescriptor(desc->tiffFile) ;
    free(desc) ;
}

/* Return the pointer to tag in given IFD */
tiffTag *getTagInTiffIFD(tiffFileDescriptor *desc, int ifdIndex, int unsigned tag)
{
    int i ;
    size_t lDec;
    tiffTag *thisTag ;
    tiffIFD *thisIFD ;

    if (ifdIndex >= desc->nIFD) {
        errorCode = _IFD_NOT_DEFINED_ ;
        return (NULL) ;
    }
    thisIFD = desc->ifdVect[ifdIndex] ;
    i = 0 ;
    while (thisIFD->tag[i].tagID != tag && i < thisIFD->nTags) {
        i++ ;
    }
    if (i == thisIFD->nTags) {
        errorCode = _TAG_NOT_DEFINED_ ;
        return (NULL) ;
    }

    return(thisIFD->tag + i) ;
}

tiffTag *getTagInTiff(tiffFileDescriptor *desc, int unsigned tag)
{
    return(getTagInTiffIFD(desc, 0, tag)) ; 
}

/* Read the pointer to the data corresponding to tag ID in given IDF */
tiffTag *getDataForTagInTiffIFD(tiffFileDescriptor *desc, int ifdIndex, int unsigned tag, void *data)
{
    int i, dataSize ;
    size_t lDec;
    tiffTag *thisTag ;

    thisTag = getTagInTiffIFD(desc, ifdIndex, tag) ;
    if (thisTag)
    {
        dataSize = tiffTypeSize[thisTag->dataType] ;
        if (thisTag->dataCount * dataSize < 5) {
            thisTag->data = calloc(1, 4) ;
            memcpy(thisTag->data, &thisTag->offset, 4) ;
            memcpy(data, &thisTag->offset, 4) ;
        }
        else {
            lDec = ftell(desc->tiffFile->f) ;
            if (fseek(desc->tiffFile->f, thisTag->offset, SEEK_SET)) {
                ase ("\t-/-> Failed to seek into tiff file\n") ;
            }
            
            thisTag->data = calloc(thisTag->dataCount, dataSize) ;
            if (fread(thisTag->data, dataSize, thisTag->dataCount, desc->tiffFile->f) != thisTag->dataCount) {
                ase("\t-/-> Failed to read in tiff file\n") ;
            }
            
            if (fseek(desc->tiffFile->f, lDec, SEEK_SET)) {
                ase ("\t-/-> Failed to seek into tiff file\n") ;
            }
            
            if (desc->tiffFile->swapBytes  && dataSize > 1) {
                for (i = 0; i < thisTag->dataCount; i++) {
                    swapByteStructOfType(thisTag->data + i * dataSize, dataSize) ;
                }
            }

            *((char **)data )= thisTag->data ;
        }
    }
    
    
    return (thisTag) ;
}

tiffTag *getDataForTagInTiff(tiffFileDescriptor *desc, int unsigned tag, void *data)
{
    return(getDataForTagInTiffIFD(desc, 0, tag, data)) ;
}

