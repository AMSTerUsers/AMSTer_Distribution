
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  aoiHandling.c
//  S1DataReader
//
//  Created by Dominique Derauw on 17/10/2017.
//  Copyright © 2017 Dominique Derauw. All rights reserved.
//

#include "aoiHandling.h"

polygon *getRectangularAoIFromKMLFile(char *kmlFilePath)
{
    polygon *aoi = NULL, *kmlPolygon ;

    if ((kmlPolygon = getPolygonalAoIFromKMLFile(kmlFilePath))) {
        aoi = circumscribedRectangleOfPolygon(kmlPolygon) ;
        freePolygon(kmlPolygon) ;
    }

    return (aoi) ;
}

polygon *getPolygonalAoIFromKMLFile(char *kmlFilePath)
{
    int i, numberOfSummits, NDim = 1 ;
    polygon *kmlPolygon = NULL ;
    xmlDocPtr kmlDoc ;
    CSVStruct *csv, *csv2 ;
    
    if (!kmlFilePath) {
        return (kmlPolygon) ;
    }
    
    if (!getPointerToLastFileExtensionInPath(kmlFilePath)) {
        return (kmlPolygon) ;
    }
    if (strncmp(getPointerToLastFileExtensionInPath(kmlFilePath), "kml", 3)) {
        return (kmlPolygon) ;
    }
    
    if (fileExistsAtPath(kmlFilePath)) {
        kmlDoc = getdoc(kmlFilePath) ;
        
        csv = readCSVInXMLFileForXPath((xmlChar*)"//*[local-name()='coordinates']", kmlDoc) ;
        if(!csv) {
            ase("\t-/-> given kml file does not contains polygon summit coordinates\n\t\tSince you expect using a kml, a stop here.\n\n") ;
        }
        xmlFreeDoc(kmlDoc) ;
        xmlCleanupParser();

        stripWhiteCharsAtStartOfString(csv->stringVal[0]) ;
        stripWhiteCharsAtEndOfString(csv->stringVal[0]) ;
        replaceWhiteCharsInStringByChar(csv->stringVal[0], ',') ;
        csv2 = readCSVInString(csv->stringVal[0]) ;
        removeEmptyValsInCSV(csv2) ;

        i = 0 ;
        while (strcmp(csv2->stringVal[i], csv2->stringVal[csv2->numberOfEntries - 1]) && i < 3) {
            i++ ; 
            NDim++ ;
        }
        
        if (NDim != 2 && NDim != 3) {
            printf("\t\t-/-> kml %s not considered.\nFailed to read summits coordinates\n", kmlFilePath) ;
            freeCSVStruct(csv) ;
            freeCSVStruct(csv2) ;
            return(NULL) ;
        }
        
        numberOfSummits = csv2->numberOfEntries / NDim ;
        
        kmlPolygon = allocPolygon(numberOfSummits) ;
        for (i = 0; i < numberOfSummits; i++) {
            sscanf(csv2->stringVal[NDim * i], "%lf", &(kmlPolygon->P[i].x)) ;
            sscanf(csv2->stringVal[NDim * i + 1], "%lf", &(kmlPolygon->P[i].y)) ;
        }
        freeCSVStruct(csv) ;
        freeCSVStruct(csv2) ;
    }
    
    return (kmlPolygon) ;
}

void convertAoIFromDeg2Rad(polygon *aoi)
{
    int i ;

    for (i = 0; i < aoi->N; i++) {
        aoi->P[i].x *= PI / 180 ;
        aoi->P[i].y *= PI / 180 ;
    }
}


void genKMLForPolygonAtPath(polygon *aPolygon, char *aPath)
{
    char *aName ;
    int i ;
    point2D aPoint ;
    rawFileDescriptor *outputFile ;

    outputFile = openRawFileForWritingAtPath(aPath) ;
    if (!outputFile) {
        printf("\t-/-> Failed to save kml corresponding to given polygon") ;
    }
    aName = getFileNameFromPath(aPath) ;
    stripExtensionAtEndOfPath(aName) ;
    
    fprintf(outputFile->f, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n") ;
    fprintf(outputFile->f, "<kml>\n") ;
    fprintf(outputFile->f, "<Document>\n") ;
    fprintf(outputFile->f, "\t<Style id=\"burstStyle\">\n") ;
    fprintf(outputFile->f, "\t\t<LineStyle>\n") ;
    fprintf(outputFile->f, "\t\t\t<width>2</width>\n") ;
    fprintf(outputFile->f, "\t\t\t<color>ff00ffff</color>\n") ;
    fprintf(outputFile->f, "\t\t</LineStyle>\n") ;
    fprintf(outputFile->f, "\t\t<PolyStyle>\n") ;
    fprintf(outputFile->f, "\t\t\t<fill>1</fill>\n") ;
    fprintf(outputFile->f, "\t\t\t<color>0fffffff</color>\n") ;
    fprintf(outputFile->f, "\t\t</PolyStyle>\n") ;    
    fprintf(outputFile->f, "\t</Style>\n") ;
    fprintf(outputFile->f, "<Placemark>\n") ;
    fprintf(outputFile->f, "\t<name>%s</name>\n", aName) ;
    fprintf(outputFile->f, "\t\t<styleUrl>#burstStyle</styleUrl>\n") ;
    fprintf(outputFile->f, "\t\t<Polygon>\n") ;
    fprintf(outputFile->f, "\t\t<altitudeMode>clampToGround</altitudeMode>\n") ;
    fprintf(outputFile->f, "\t\t<outerBoundaryIs>\n\t\t<LinearRing>\n\t\t\t<coordinates>\n\t\t\t\t") ;
    for (i = 0; i < aPolygon->N; i++) {
        aPoint.p.x = 180./PI * aPolygon->P[i].x ;
        aPoint.p.y = 180./PI * aPolygon->P[i].y ;
        
        fprintf(outputFile->f, "%lf,%lf,0.0  ", aPoint.p.x, aPoint.p.y) ;
    }
    aPoint.p.x = 180./PI * aPolygon->P[0].x ;
    aPoint.p.y = 180./PI * aPolygon->P[0].y ;
    fprintf(outputFile->f, "%lf,%lf,0.0\n", aPoint.p.x, aPoint.p.y) ;
    fprintf(outputFile->f, "\t\t\t</coordinates>\n\t\t</LinearRing>\n\t\t</outerBoundaryIs>\n") ;
    fprintf(outputFile->f, "</Polygon>\n") ;
    fprintf(outputFile->f, "</Placemark>\n") ;
    fprintf(outputFile->f, "</Document>\n") ;
    fprintf(outputFile->f, "</kml>\n") ;
    
    free(aName) ;
    freeRawFileDescriptor(outputFile) ;
}



