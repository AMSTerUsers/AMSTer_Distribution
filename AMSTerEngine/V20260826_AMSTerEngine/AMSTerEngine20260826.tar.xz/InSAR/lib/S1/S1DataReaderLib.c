
/* 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License 
 *  as published by the Free Software Foundation, either version 3 
 *  of the License, or any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/


//
//  S1DataReaderLib.c
//  S1InSARDataReader
//
//  Created by Dominique Derauw on 25/09/14.
//  Copyright (c) 2014 Dominique Derauw. All rights reserved.
//

#include "S1DataReaderLib.h"

CSVStruct *S1DataReader(CSVStruct *csv)
{
    char *S1AccesPath, *outputDir = NULL ;
    char *logFilePath, *POEORB_Dir ;
    char *outputPath = NULL, *tempDir = NULL ;
    char *polarization ;
    char *aoiPath ;
    char *aCommandLine ;
    char *extension ;
    int unsigned flag, AoICoordinateSystem ;
    int i, j, letsGo ;
    keyValue *parametersList ;
    time_t startTime, endTime ;
    polygon *aoi = NULL, *rectangularAoI ;
    CSVStruct *S1FilePath = NULL, *savedCSLImages = NULL, *existingFrames ;
    CSVStruct *tempCSV = NULL, *tempCSV2 = NULL ;
    rawFileDescriptor *logFile ;
    
    
    time(&startTime) ;
    if(csv->numberOfEntries == 1)
        S1DataReaderHelp() ;
    if(isArgumentPresentInCSV(csv, "help")|| isArgumentPresentInCSV(csv, "-h"))
        S1DataReaderHelp() ;
    
    if(isArgumentPresentInCSV(csv, "-create"))
        createS1DataReaderParameterFileAtPath(csv->stringVal[1]) ;
    
    /* Define default AoI coordinate system */
    AoICoordinateSystem = _AOI_GEO_COORDINATE_SYSTEM_DEG_ ;
    
    flag = AoICoordinateSystem ;
    flag |= (isFlagPresentInCSV(csv, "s"))? _S1_TIFF_BURST_STITCHING_ : flag ;
    flag |= (isFlagPresentInCSV(csv, "w"))? _S1_SWATH_STITCHING_ : flag ;
    //    flag |= (isFlagPresent(argc, argv, "b"))? _S1_IMAGE_STITCHING_ : flag ;
    flag |= (isFlagPresentInCSV(csv, "n"))? _S1_READ_HEADERS_ONLY_ : flag ;
    flag |= (isFlagPresentInCSV(csv, "u"))? _S1_ORBIT_UPDATE_ : flag ;
    flag |= (isFlagPresentInCSV(csv, "o"))? _S1_READ_OVERWRITE_ : flag ;
    flag |= (isFlagPresentInCSV(csv, "t"))? _S1_TRASH_BURSTS_ : flag ;
    flag |= (isFlagPresentInCSV(csv, "p"))? _S1_READ_IF_ORBIT_UPDATE_ : flag ;
    flag |= (isFlagPresentInCSV(csv, "k"))? _S1_KEEP_AOI_AS_GIVEN_ : flag ;
    flag |= (isFlagPresentInCSV(csv, "r"))? _S1_DOWNLOAD_AND_READ_ : flag ;
    
    if (flag & _S1_ORBIT_UPDATE_) {
        /* Locate precise orbit directory */
        if ((POEORB_Dir = getenv("S1_ORBITS_DIR")) != NULL){
            printf("---> Updating orbits data base as requested\n") ;
            system("updateS1Orbits") ;
        }
        else {
            printf("-/-> Skipping update.\n\tPrecises orbit database directory not known\n\tS1_ORBITS_DIR environment variable not set.\n") ;
        }
    }
    
    printf("\nS1DataReader\n") ;
    polarization = initStringWithString(getValForKeyInCSV(csv, "P=")) ;
    if (!polarization) {
        polarization = initStringWithString("ALL") ;
    }

    extension = getPointerToLastFileExtensionInPath(csv->stringVal[1]) ;
    if (isSubStringPresentInString(extension, "zip")) {
        flag |= _S1_COMPRESSED_DATA_IN_INPUT_ ;
    }
    
    /* If parameter 1 is a CSL image, we will consider that image was already read and stitching only is requested */
    if (isCSLImageAtPath(csv->stringVal[1])) {
        flag |= _S1_IMAGE_STITCHING_ ;
        flag |= _S1_HEADER_STITCHING_ ;
        S1AccesPath = csv->stringVal[1] ;
        /* Stitch existing image */
        savedCSLImages = readS1Data(S1AccesPath, NULL, aoi, polarization, flag) ;
    }
    /* If parameter 1 is a directory, we will consider it contains one or more S1 files to be read. */
    /* Consequently, bulk processing must be considered */
    /* If parameter 1 is a single zipped file, we will consider it as a possible S1 zipped file to be read within the bulk processing */
    else if (isDir(csv->stringVal[1]) || flag & _S1_COMPRESSED_DATA_IN_INPUT_) {
        flag |= _S1_BULK_READING_ ;
        /* Read area of interest if present in command line parameters */
        for (i = 2; i < csv->numberOfEntries; i++) {
            if((aoi = getPolygonalAoIFromKMLFile(csv->stringVal[i]))) {
                if (!(flag & _S1_KEEP_AOI_AS_GIVEN_)) {
                    rectangularAoI = circumscribedRectangleOfPolygon(aoi) ;
                    freePolygon(aoi) ;
                    aoi = rectangularAoI ;
                }
                
                aoiPath = csv->stringVal[i] ;
                break ;
            }
        }
        
        /* Select output directory as the second directory given as parameter*/
        for (i = 2; i < csv->numberOfEntries; i++) {
            if (isDir(csv->stringVal[i])) {
                outputDir = initStringWithString(csv->stringVal[i]) ;
                break ;
            }
        }
        
        /* List all available S1 scene within input directory */
        if (isDir(csv->stringVal[1])) {
            printf("\t---> Will read data in %s\n", csv->stringVal[1]) ;
            S1FilePath = recursiveSearchOfDirInDir("_SLC__", csv->stringVal[1]);
            
            /* If no directories found, perhaps we still deal with compressed S1 images */
            if (!S1FilePath) {
                /* List all available compressed S1 scene within input directory */
                S1FilePath = recursiveSearchOfFileInDir("_SLC__", csv->stringVal[1]) ;
                if (S1FilePath) {
                    for (i = 0; i < S1FilePath->numberOfEntries; i++) {
                        /* if not a .zip file, remove it from listing */
                        if (strncmp(getPointerToLastFileExtensionInPath(S1FilePath->stringVal[i]), "zip", 3)) {
                            removeStringValAtIndexInCSVStruct(i, S1FilePath) ;
                            i-- ;
                        }
                    }
                    if (S1FilePath->numberOfEntries) {
                        flag |= _S1_COMPRESSED_DATA_IN_INPUT_ ;
                    }
                    else {
                        freeCSVStruct(S1FilePath) ;
                        S1FilePath = NULL ;
                    }
                }
            }
            /* If still nothing found, first parameter may be an image itself */
            if (!S1FilePath) {
                if (isSubStringPresentInString(csv->stringVal[1], "_SLC__")) {
                    S1FilePath = addStringValInCSVStruct(csv->stringVal[1], S1FilePath) ;
                    /* If output directory was not given in command line and if we deal with an uncompressed single image, select upper directory as output one */
                    if (!outputDir) {
                        outputDir = getDirectoryPathFromPath(csv->stringVal[1]) ;
                    }
                }
            }
        }
        
        /* If still nothing found, first parameter may be a zipped image */
        if (fileExistsAtPath(csv->stringVal[1])) {
            if (isSubStringPresentInString(csv->stringVal[1], "_SLC__")) {
                S1FilePath = addStringValInCSVStruct(csv->stringVal[1], S1FilePath) ;
                flag |= _S1_COMPRESSED_DATA_IN_INPUT_ ;
                if (!outputDir) {
                    outputDir = getDirectoryPathFromPath(csv->stringVal[1]) ;
                }
            }
        }
        if (!S1FilePath){
            ase("\t-/-> No SENTINEL1 SLC images found. Nothing to read\n") ;
        }
        S1FilePathTimeOrdering(S1FilePath) ;
        
        /* If output directory still not set, select it as the directory that contains the images to be read */
        if (!outputDir) {
            outputDir = initStringWithString(csv->stringVal[1]) ;
        }

        /* Verify write acces is granted at destination directory */
        if (!isWriteAccessGrantedAtPath(outputDir)) {
            ase("\t\t-/-> Write acces is not granted at destination directory; Stopping here.") ;
        }
        printf("\t---> Will save read data in %s\n", outputDir) ;

        if (flag & _S1_COMPRESSED_DATA_IN_INPUT_ && !(flag & _S1_DOWNLOAD_AND_READ_)) {
            /* List already read frames in destination directory */
            printf("\t---> Zipped file(s) given in input.\n") ;
            printf("\t\t---> First check if some zipped files were previously read to avoid useless unzip.\n") ;
            if ((existingFrames = listReadS1FramesInDir(outputDir))) {
                /* Clean listing of images to read */
                printf("\t---> %d existing frames(s) found\n", existingFrames->numberOfEntries) ;
                printf("\t---> Cleaning listing of S1 frame to be read\n") ;
                for (i = 0; i < S1FilePath->numberOfEntries; i++) {
                    for (j = 0; j < existingFrames->numberOfEntries; j++) {
                        if (isSubStringPresentInString(S1FilePath->stringVal[i], existingFrames->stringVal[j])) {
                            printf("\t\t---> Skipping frame %s\n", existingFrames->stringVal[j]) ;
                            printf("\t\t---> Frame already present in destination directory\n\n") ;
                            removeStringValAtIndexInCSVStruct(i, S1FilePath) ;
                            removeStringValAtIndexInCSVStruct(j, existingFrames) ;
                            i-- ;
                            j = existingFrames->numberOfEntries ;
                        }
                    }
                }
                freeCSVStruct(existingFrames) ;
            } 
        }
        
        if (!S1FilePath->numberOfEntries) {
            ase("\n-/-> Nothing to read\n") ;
        }
        
        /* If files must first be uncompressed, create temporary directory */
        if (flag & _S1_COMPRESSED_DATA_IN_INPUT_) {
            if (isWriteAccessGrantedAtPath("${HOME}")) {
                sprintf(accessPath, "${HOME}/.tempDir") ;
                tempDir = expandEnvironmentVariablesInPath(accessPath) ;
            }
            else if (isWriteAccessGrantedAtPath(csv->stringVal[1])) {
                tempDir = initStringWith2Strings(csv->stringVal[1], "/.tempDir") ;
            }
            else {
                tempDir = initStringWith2Strings(outputDir, "/.tempDir") ;
            }

            if (isDir(tempDir)) {
                removeDirectoryAtPath(tempDir) ;
            }
            
            if (!isDir(tempDir)) {
                if (mkdir(tempDir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)) {
                    printf("Failed to create temporary directory %s to uncompress zipped files\n", tempDir) ;
                    ase("") ;
                }
            }
        }
        
        /* Open log file */
        logFilePath = initStringWith2Strings(outputDir, "/S1DataReaderLog.txt") ;
        logFile = openRawFileForWritingAtPath(logFilePath) ;
        if (!logFile) {
            ase("\t-/-> Failed to write in destination path\n") ;
        }
        
        if (flag & _S1_DOWNLOAD_AND_READ_) {
            fseek(logFile->f, 0, SEEK_END) ;
        }
        free(logFilePath) ;

        
        /* Process each input for reading */
        writeToLog(logFile->f, "/* S1DataReader log */\n") ;
        writeToLog(logFile->f, "/* **************** */\n\n") ;
        sprintf(ertex, "Run time: %s\n", ctime(&startTime)) ;
        writeToLog(logFile->f, ertex) ;
        sprintf(ertex, "Requested polarization: %s\n", polarization) ;
        writeToLog(logFile->f, ertex) ;
        if (aoi) {
            sprintf(ertex,"\t---> Used kml: : %s\n", aoiPath) ;
            printf("%s", ertex) ;
            writeToLog(logFile->f, ertex) ;
            if (!(flag & _S1_KEEP_AOI_AS_GIVEN_)) {
                sprintf(ertex, "\t---> Circumscribed rectangle of given kml is considered as area of interest. \n") ;
                printf("%s", ertex) ;
                writeToLog(logFile->f, ertex) ;
            }
        }
        
        sprintf(ertex, "\nNumber of S1 image frames to read: %d\n", S1FilePath->numberOfEntries) ;
        printf("%s", ertex) ;
        writeToLog(logFile->f, ertex) ;
        printf("---------------------------------\n") ;
        for (i = S1FilePath->numberOfEntries - 1; i >= 0; i--) {
            fseek(logFile->f, 0, SEEK_END) ;
            sprintf(ertex, "\n\t---> Processing frame %d / %d\n", S1FilePath->numberOfEntries - i, S1FilePath->numberOfEntries) ;
            printf("%s", ertex) ;
            writeToLog(logFile->f, ertex) ;
            letsGo = !(flag & _S1_COMPRESSED_DATA_IN_INPUT_) ;
            if (!letsGo) {
                S1AccesPath = NULL ;
                sprintf(ertex, "\n\t---> Decompressing %s\n", S1FilePath->stringVal[i]) ;
                printf("%s", ertex) ;
                writeToLog(logFile->f, ertex) ;
                tempCSV = addStringValInCSVStruct("unzip -quo ", NULL) ;
                addStringValInCSVStruct(S1FilePath->stringVal[i], tempCSV) ;
                addStringValInCSVStruct(" -d ", tempCSV) ;
                addStringValInCSVStruct(tempDir, tempCSV) ;
//                addStringValInCSVStruct(" > /dev/null", tempCSV) ;
                aCommandLine = getStringFromCSV(tempCSV) ;
                if (system(aCommandLine) == 0) {
                    tempCSV2 = recursiveSearchOfDirInDir("_SLC__", tempDir);
                    S1AccesPath = tempCSV2->stringVal[0] ;
                    letsGo = 1 ;
                    free(tempCSV2) ;
                }
                else {
                    sprintf(ertex, "\n\t-/-> Something went wrong while decompressing frame %s\n\tSkipping frame.\n\n", getPointerToFileNameInPath(S1FilePath->stringVal[i])) ;
                    printf("%s", ertex) ;
                    writeToLog(logFile->f, ertex) ;
                }
                
                free(aCommandLine) ;
                freeCSVStruct(tempCSV) ;
            }
            else {
                S1AccesPath = S1FilePath->stringVal[i] ;
            }

            if (letsGo){
                /* First, reset flag concerning strip map reading */
                flag &= ~_S1_SM_READ_AND_SAVE_ ;
                fseek(logFile->f, 0, SEEK_END) ;
                
                /* Then detect if we deal with a strip map or with TopSAR data */
                if (isSubStringPresentInString(S1AccesPath, "_SLC__") && !isSubStringPresentInString(S1AccesPath, "_IW_SLC__") && !isSubStringPresentInString(S1AccesPath, "_EW_SLC__")) {
                    flag |= _S1_SM_READ_AND_SAVE_ ;
                    sprintf(ertex, "\n\t---> Start processing Strip Map data %s\n", getPointerToFileNameInPath(S1AccesPath)) ;
                }
                else {
                    sprintf(ertex, "\n\t---> Start processing TOPSAR frame %s\n", getPointerToFileNameInPath(S1AccesPath)) ;
                }
                printf("%s", ertex) ;
                writeToLog(logFile->f, ertex) ;
                    
                /* Read S1 data */
                if ((tempCSV = readS1Data(S1AccesPath, outputDir, aoi, polarization, flag))) {
                    fseek(logFile->f, 0, SEEK_END) ;
                    if (flag & _S1_SM_READ_AND_SAVE_) {
                        sprintf(ertex, "\t\t---> Strip map data saved in .csl image %s\n", tempCSV->stringVal[0]) ;
                    }
                    else{
                        sprintf(ertex, "\t\t---> Frame saved in .csl image %s\n", tempCSV->stringVal[0]) ;
                    }
                    printf("%s", ertex) ;
                    writeToLog(logFile->f, ertex) ;
                    
                    if (!isStringValPresentInCSV(tempCSV->stringVal[0], savedCSLImages)) {
                        savedCSLImages = addStringValInCSVStruct(tempCSV->stringVal[0], savedCSLImages) ;
                    }
                    freeCSVStruct(tempCSV) ;
                }
                writeToLog(logFile->f, "\n/* --------------------------------- */\n") ;
            }

            if (flag & _S1_COMPRESSED_DATA_IN_INPUT_) {
                removeDirectoryAtPath(S1AccesPath) ;
            }           
        }
        freeCSVStruct(S1FilePath) ;
        free(outputDir) ;
        freeRawFileDescriptor(logFile) ;
        if (flag & _S1_COMPRESSED_DATA_IN_INPUT_) {
            removeDirectoryAtPath(tempDir) ;
            free(tempDir) ;
        }
        
        /* Process each input for stitching frameInfo and images if requested */
        /* Normally, this is not necessary anymore. Left as comment waiting for full verification */
        //     if (savedImageList && !(flag & _S1_SM_READ_AND_SAVE_)) {
        //        flag |= _S1_HEADER_STITCHING_ ;
        //         for (i = savedImageList->numberOfEntries - 1; i >= 0; i--) {
        //                printf("\n") ;
        //                S1AccesPath = savedImageList->stringVal[i] ;
        
        /* Read S1 data */
        //                readS1Data(S1AccesPath, NULL, aoi, polarization, flag) ;
        //            }
        //            freeCSVStruct(savedImageList) ;
        //        }
        //    freeCSVStruct(savedImageList) ;
    }
    else {
        parametersList = readParameterFileAtPath(csv->stringVal[1]) ;
        free(polarization) ;
        polarization = initStringWithString(getStringValForKeyIn(parametersList, "Polarization")) ;
        
        S1AccesPath = getStringValForKeyIn(parametersList, "S1 data directory") ;
        if (!isManifestFilePresentAtPath(S1AccesPath)) {
            printf("No manifest.safe file present into directory") ;
        }

        /* Get area of interest */
        if (isCommentPresentIn(parametersList, "Area of interest")) {
            aoiPath = getStringValForKeyIn(parametersList, "kml") ;
            aoi = getPolygonalAoIFromKMLFile(aoiPath) ;
        }
        if (!aoi) {
            aoi = allocPolygon(4) ;
            aoi->P[0].x = aoi->P[3].x = getDoubleValForKeyIn(parametersList, "X0") ;
            aoi->P[2].x = aoi->P[1].x = getDoubleValForKeyIn(parametersList, "X2") ;
            aoi->P[0].y = aoi->P[1].y = getDoubleValForKeyIn(parametersList, "Y0") ;
            aoi->P[2].y = aoi->P[3].y = getDoubleValForKeyIn(parametersList, "Y2") ;
            
            if (!strncmp(getStringValForKeyIn(parametersList, "Coordinate"), "SRA", 3)) {
                flag &= ~AoICoordinateSystem ;
                AoICoordinateSystem = _AOI_SRA_COORDINATE_SYSTEM_ ;
                flag |= AoICoordinateSystem ;
            }
        }
        else {
            rectangularAoI = circumscribedRectangleOfPolygon(aoi) ;
            freePolygon(aoi) ;
            aoi = rectangularAoI ;
        }
        
        /* Init output name */
        outputPath = initStringWithString(getStringValForKeyIn(parametersList, "Path to output image in CSL format")) ;
        
        /* Then detect if we deal with a strip map or with TopSAR data */
        if (isSubStringPresentInString(S1AccesPath, "_SLC__") && !isSubStringPresentInString(S1AccesPath, "_IW_SLC__") && !isSubStringPresentInString(S1AccesPath, "_EW_SLC__")) {
            flag |= _S1_SM_READ_AND_SAVE_ ;
            printf("\nStart reading Strip Map data...\n") ;
        }
        else {
            printf("\nStart reading TOPSAR frame ...\n") ;
        }
        
        /* Read S1 data */
        if ((tempCSV = readS1Data(S1AccesPath, outputPath, aoi, polarization, flag))) {
            if (!isStringValPresentInCSV(tempCSV->stringVal[0], savedCSLImages)) {
                savedCSLImages = addStringValInCSVStruct(tempCSV->stringVal[0], savedCSLImages) ;
            }
            freeCSVStruct(tempCSV) ;
        }
        
        
        freeKeyValueList(parametersList) ;
    }
    free(polarization) ;
    if(aoi) {
        freePolygon(aoi) ;
    }
    
    time(&endTime) ;
    duration(startTime, endTime) ;
    
    return(savedCSLImages) ;
}

void S1DataReaderHelp()
{
    printf("\nUsage:") ;
    printf("\n-1-\tS1DataReader inputDir [outputDir] kmlFilePath [-swontup] [P=XX]\n") ;
    printf("\t---> Bulk data reading.\n\t     If no output dir is provided, read data are saved within input directory.\n") ;
    printf("\n-2-\tS1DataReader /pathToParameterFile [-create] [-swontup]\n") ;
    printf("\t---> Per image data reading using an imput parameter file\n") ;
    printf("\t     If adding \"-create\" command line parameter, \n\t     an example parameter file will be created at indicated path.\n") ;
    printf("\n\tThis routine will read SLC S1 Level 1 data and save it in CSL format.\n");
    printf("Default process reads and save bursts separately\n") ;
    printf("Options:\n") ;
    printf("-k : Keep given kml unchanged. Normal behavour is to consider the circumscribed rectangle as the requested area of interest.\n") ;
    printf("-s : Force burst stitching to issue a single frame\n") ;
    //    printf("-b : Do both stitching and bursts reading (image is read and saved twice...)\n") ;
    printf("-o : Force overwriting of already read frames\n") ;
    printf("-n : No data reading. Only headers reading\n") ;
    printf("-t : All burst are trashed after stitching\n") ;
    printf("-u : Local orbit data base is updated first\n") ;
    printf("-p : Read frame only and only if PRECISE or RESTITUDED orbit is available\n") ;
    printf("P=XX : Allows selecting the polarization layer to be read replacing XX by VV, VH, HV or HH\n") ;
    
    exit(0) ;
}

void createS1DataReaderParameterFileAtPath(char *aPath)
{
    keyValue *parameters ;
    char *S1PrecisesOrbitsDir ;
    
    
    parameters = allocAKeyValuePair() ;
    setStringValForKeyIn(parameters, "S1DataReader parameter file", "") ;
    setStringValForKeyIn(parameters, "****************************", "") ;
    setStringValForKeyIn(parameters, "PathToS1Directory", "S1 data directory path (directory containing the manifest.safe file).") ;
    setStringValForKeyIn(parameters, "outputFilePath", "Path to output image in CSL format") ;
    setStringValForKeyIn(parameters, "ALL", "Polarization to read (HH, VV, VH, HV or ALL)") ;
    setStringValForKeyIn(parameters, "", "") ;
    setStringValForKeyIn(parameters, "Area of interest (if all zeros, the whole input image is considered)", "") ;
    setStringValForKeyIn(parameters, "SRA", "Coordinate system [SRA / GEO]") ;
    setStringValForKeyIn(parameters, "0", "X0 = lower left corner X coordinate") ;
    setStringValForKeyIn(parameters, "0", "Y0 = lower left corner Y coordinate") ;
    setStringValForKeyIn(parameters, "0", "X2 = upper right corner X coordinate") ;
    setStringValForKeyIn(parameters, "0", "Y2 = upper right corner Y coordinate") ;
    setStringValForKeyIn(parameters, "pathToKMLFile", "kml file path (.kml polygon saved from Google Earth)") ;
    setStringValForKeyIn(parameters, "", "") ;
    setStringValForKeyIn(parameters, "", "") ;
    setStringValForKeyIn(parameters, "Do not modify, change names, remove or add any file within the predefined Sentinel1 directory structure!", "") ;
    
    if ((S1PrecisesOrbitsDir = getenv("S1_PRECISES_ORBITS_DIR")) == NULL) {
        setStringValForKeyIn(parameters, "S1_Precises_Orbits_DirectoryPath", "S1 precises orbits directory") ;
    }
    else {
        setStringValForKeyIn(parameters, S1PrecisesOrbitsDir, "S1 precises orbits directory") ;
    }
    
    writeParameterFileAtPath(parameters, aPath) ;
    
    exit(0) ;
}



char isManifestFilePresentAtPath(char *aPath)
{
    char returnedValue, **directoryEntry ;
    int i, numberOfEntries ;

    if (!isDir(aPath)) {
        sprintf(ertex, "Path %s to Sentinel1 data is not a valid directory\n", aPath) ;
        ase(ertex) ;
    }

    if (!(numberOfEntries = getNumberOfDirectoryEntriesAtPath(aPath))) {
        sprintf(ertex, "Directory %s to Sentinel1 data is empty\n", aPath) ;
        ase(ertex) ;
    }

    if((directoryEntry = getDirectoryEntriesAtPath(aPath)) == NULL) {
        sprintf(ertex, "Directory %s to Sentinel1 data is empty\n", aPath) ;
        ase(ertex) ;
        exit(-1) ;
    }

    returnedValue = 0 ;
    for (i = 0; i < numberOfEntries; i++) {
        if (!strncmp(directoryEntry[i], "manifest.safe", 13)) {
            returnedValue = 1 ;
        }
        free(directoryEntry[i]) ;
    }
    free(directoryEntry) ;

    return (returnedValue) ;
}

/* Just verify that slave image still contain bursts */
char isSlaveValid(CSLImage *slaveImage)
{
    char test ;
    int i ;
    CSVStruct *csv, *csv2 ;

    /* Old S1 data format verification first */
    csv = recursiveSearchOfFileInDir("SW", slaveImage->dataDirectoryPath) ;
    test = (csv)? 1 : 0 ;
    if(!csv) {
        /* If not old format, verify new one */
        csv = recursiveSearchOfDirInDir("SW", slaveImage->dataDirectoryPath) ;
        test = (csv)? 1 : 0 ;
        if (csv) {
            for (i = 0; i < csv->numberOfEntries; i++) {
                csv2 = recursiveSearchOfFileNamesInDir("SLCData", csv->stringVal[i]) ;
                test *= (csv2)? 1 : 0 ;
                if (!csv2) {
                    printf("\t-/-> Missing burst %s\n", getPointerToFileNameInPath(csv->stringVal[i])) ;
                }
                
                freeCSVStruct(csv2) ;
            }
        }
    }
    freeCSVStruct(csv) ;

    return (test) ;
}

int readS1DATALayersBurstsInto(CSLImage *thisImage, SLCImageInfo *info)
{
    char *polarization ;
    int unsigned swathIndex, layerIndex, MDSFilePathIndex ;
    int unsigned iX, iY, currentLineInMDS ;
    int xTiffDim ;
    size_t burstSize ;
    S1AdditionalInfo *S1Specific ;
    CSVStruct *csv ;
    TIFF *tifImage ;
//    GTIF *gtif=(GTIF*)0 ; /* GeoKey-level descriptor */
    complexShort *inputBurstLine ;
    complexFloat **outputBurst ;
    burstDescriptor *currentBurst ;
//    derampingStructType *deramping ;


    S1Specific = info->sensorSpecificInfo ;

    /* Read number of layers */
    csv = readCSVInString(info->polMode) ;

    /* loop on layers */
    for (layerIndex = 0; layerIndex < info->numberOfLayers; layerIndex++) {
        polarization = csv->stringVal[layerIndex] ;
        printf("\nReading bursts of Sentinel 1 %s data: %s polarization layer\n", info->productID, polarization) ;
        /* Loop on swath */
        for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
            printf("\tSwath %d\n", swathIndex) ;
            currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
            do {
                if (currentBurst->isSelected) {
                    /* Allocate input line */
                    inputBurstLine = vectorComplexShort(0, currentBurst->xDim - 1) ;
                    /* Allocate burst */
                    outputBurst = matrixComplexFloat(0, currentBurst->yDim - 1, 0, currentBurst->xDim - 1) ;

                    /* Open TIFF MDS corresponding to burst */
                    MDSFilePathIndex = layerIndex * S1Specific->numberOfSubSwaths + swathIndex ;
                    if ((tifImage = XTIFFOpen(S1Specific->MDSFilePath[MDSFilePathIndex], "r")) == NULL) {
                        printf("\t-/-> Failed to open tiff file at path %s\n", S1Specific->MDSFilePath[MDSFilePathIndex]) ;
                        printf("%s\n", getPointerToFileNameInPath(S1Specific->MDSFilePath[MDSFilePathIndex])) ;
                        freeCSVStruct(csv) ;
                        return (-1) ; ;
                    }
                    
                    /* Verify TIFF dimensions */
                    if (!TIFFGetField(tifImage, TIFFTAG_IMAGEWIDTH, &xTiffDim)) {
                        printf("\t-/-> TIFFTAG_IMAGEWIDTH dim field not defined in %s.\n", S1Specific->MDSFilePath[MDSFilePathIndex]) ;
                        freeCSVStruct(csv) ;
                        return (-1) ; ;
                    }
                    
                    if (xTiffDim != (int)currentBurst->xDim) {
                        printf("\t-/-> Something goes wrong...\n \t-/-> Tiff width does not correspond to image width read in ADS") ;
                        freeCSVStruct(csv) ;
                        return (-1) ; ;
                     }

                    /* Read burst */
                    printf("\t\tReading burst %d of swath %d\n", currentBurst->burstIndex, swathIndex) ;
                    for (iY = 0; iY < currentBurst->yDim; iY++) {
                        currentLineInMDS = currentBurst->burstIndex * currentBurst->yDim + iY ;
                        if (TIFFReadScanline(tifImage, inputBurstLine, currentLineInMDS, 0) == -1) {
                            printf("\t-/-> Failed to read line in tiff file %s.\n", S1Specific->MDSFilePath[MDSFilePathIndex]) ;
                            freeCSVStruct(csv) ;
                            return (-1) ; ;
                        }

                        for (iX = 0; iX < currentBurst->xDim; iX++) {
                            outputBurst[iY][iX].r = (float)inputBurstLine[iX].r ;
                            outputBurst[iY][iX].i = (float)inputBurstLine[iX].i ;
                        }
                    }

                    /* Save read burst */
                    burstSize = currentBurst->xDim * currentBurst->yDim ;
                    if (fwrite(outputBurst[0], sizeof(complexFloat), burstSize, currentBurst->file[layerIndex]->f) != burstSize) {
                        ase("Failed to save read burst") ;
                    }
                    fflush(currentBurst->file[layerIndex]->f) ;
                    rewind(currentBurst->file[layerIndex]->f) ;
                    XTIFFClose(tifImage) ;

                    freeVectorComplexShort(inputBurstLine, 0) ;
                    freeMatrixComplexFloat(outputBurst, 0, 0) ;
                }
                else
                    break ;
            } while ((currentBurst = currentBurst->nextBurst));
        }
    }

    freeCSVStruct(csv) ;

    return (0) ;
}




void copyS1HeadersToCSLImage(S1AdditionalInfo *S1Specific, CSLImage *anImage)
{
    char *inputFilePath, *outputFilePath, *annotationDir, *inputCalibrationDir, *outputCalibrationDir ;
    char **dirEntries ;
    int i, numberOfMDS, numberOfCalibrationEntries ;

    /* Copy MDS headers into CSL image */
    numberOfMDS = S1Specific->numberOfLayers * S1Specific->numberOfSubSwaths ;
    for (i = 0; i < numberOfMDS; i++) {
        outputFilePath = initStringWith3Strings(anImage->headersDirectoryPath, "/", getPointerToFileNameInPath(S1Specific->ADSFilePath[i])) ;
        copyFileAtPathToPath(S1Specific->ADSFilePath[i], outputFilePath) ;
        free(outputFilePath) ;
    }


    /* Copy calibration annotations into specific dir in CSL image */
    annotationDir = getDirectoryPathFromPath(S1Specific->ADSFilePath[0]) ;
    inputCalibrationDir = initStringWith2Strings(annotationDir, "calibration") ;
    dirEntries = getDirectoryContentAtPath(inputCalibrationDir, &numberOfCalibrationEntries) ;
    outputCalibrationDir = initStringWith2Strings(anImage->headersDirectoryPath, "/calibration") ;

    if (isDir(outputCalibrationDir)) {
        for (i = 0; i < numberOfCalibrationEntries; i++) {
            inputFilePath = initStringWith3Strings(inputCalibrationDir, "/", dirEntries[i]) ;
            outputFilePath = initStringWith3Strings(outputCalibrationDir, "/", dirEntries[i]) ;
            copyFileAtPathToPath(inputFilePath, outputFilePath) ;
            free(outputFilePath) ;
            free(inputFilePath) ;
        }  
    }

    freeDirectoryEntries(dirEntries, numberOfCalibrationEntries) ;
    free(annotationDir) ;
    free(inputCalibrationDir) ;
    free(outputCalibrationDir) ;
}



int readS1DATALayersInto(CSLImage *thisImage, SLCImageInfo *info)
{
    char *outputPath ;
    int unsigned i, j ;
    int unsigned layerIndex ;
    int unsigned xTiffDim, yTiffDim ;
    complexShort *TiffLineBuffer ;
    complexFloat *anOutputLine ;
    S1AdditionalInfo *S1Specific ;
    rawFileDescriptor *outputLayerFile = NULL ;
    CSVStruct *csv ;
    progressCounter *counter ;
    TIFF *tifImage ;

    S1Specific = info->sensorSpecificInfo ;
    csv = readCSVInString(info->polMode) ;
    for (layerIndex = 0; layerIndex < info->numberOfLayers; layerIndex++) {
        /* Create output file stream */
        outputPath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", csv->stringVal[layerIndex]) ;
        if((outputLayerFile = openRawFileForWritingAtPath(outputPath)) == NULL) {
            sprintf(ertex, "Failed to create output file at path %s", outputPath) ;
            ase(ertex) ;
            exit(-1) ;
        }
        free(outputPath) ;

        /* We deal with stripmap data so, simply read and convert tif measurement data set */
        printf("\nReading Sentinel 1 stripmap data: %s polarization layer\n", csv->stringVal[layerIndex]) ;

        /* Open tiff file */
        if ((tifImage = XTIFFOpen(S1Specific->MDSFilePath[layerIndex], "r")) == NULL) {
            printf("\t-/-> Failed to open tiff file at path %s\n", S1Specific->MDSFilePath[layerIndex]) ;
            printf("%s\n", getPointerToFileNameInPath(S1Specific->MDSFilePath[layerIndex])) ;
            freeCSVStruct(csv) ;
            return (-1) ; ;
        }

        /* Read TIFF file dimension and allocate buffers */
        if (!TIFFGetField(tifImage, TIFFTAG_IMAGEWIDTH, &xTiffDim)) {
            printf("\t-/-> TIFFTAG_IMAGEWIDTH dim field not defined in %s.\n", S1Specific->MDSFilePath[layerIndex]) ;
            freeCSVStruct(csv) ;
            return (-1) ; ;
        }
        if (!TIFFGetField(tifImage, TIFFTAG_IMAGELENGTH, &yTiffDim)) {
            printf("\t-/-> TIFFTAG_IMAGEWIDTH dim field not defined in %s.\n", S1Specific->MDSFilePath[layerIndex]) ;
            freeCSVStruct(csv) ;
            return (-1) ; ;
        }
        TiffLineBuffer = vectorComplexShort(0, xTiffDim - 1) ;
        anOutputLine = vectorComplexFloat(0, xTiffDim - 1) ;

        /* Read, convert and save data */
        counter = initProgressCounterWithMinMaxValue(0, yTiffDim - 1) ;
        for (i = 0; i < yTiffDim; i++) {
            if (TIFFReadScanline(tifImage, TiffLineBuffer, i, 0) == -1) {
                printf("\t-/-> Failed to read line in tiff file %s.\n", S1Specific->MDSFilePath[layerIndex]) ;
                freeCSVStruct(csv) ;
                return (-1) ; ;
            }
            for (j = 0; j < xTiffDim; j++) {
                anOutputLine[j].r = (float)TiffLineBuffer[j].r ;
                anOutputLine[j].i = (float)TiffLineBuffer[j].i ;
            }
            fwrite(anOutputLine, sizeof(complexFloat), xTiffDim, outputLayerFile->f) ;
            updateProgressCounterForIndex(counter, i) ;
        }
        updateProgressCounterForIndex(counter, i) ;

        freeVectorComplexShort(TiffLineBuffer, 0) ;
        freeVectorComplexFloat(anOutputLine, 0) ;
        freeProgressCounter(counter) ;
        XTIFFClose(tifImage) ;
    }

    freeRawFileDescriptor(outputLayerFile) ;
    freeCSVStruct(csv) ;

    return (0) ;
}


/* We allocate a structure containing all that is required to localise line components within MDS and built output line */
lineLocInMDS *initlineLocInMDS(SLCImageInfo *info)
{
    int unsigned swathIndex ;
    int unsigned iMin, iMax ;
    int rangeDimension ;
    lineLocInMDS *lineLoc ;
    S1AdditionalInfo *S1Specific ;

    if((lineLoc = malloc(sizeof(lineLocInMDS))) == NULL) {
        perror("Failed to allocate line localization in MDS") ;
        exit(-1) ;
    }

    rangeDimension = info->rangeDimension ;
    if (info->masterInfo) {
        rangeDimension = (rangeDimension < info->masterInfo->rangeDimension)? info->masterInfo->rangeDimension : rangeDimension ;
    }
    

    lineLoc->S1 = S1Specific = info->sensorSpecificInfo ;
    iMin = S1Specific->firstSwathIndex ;
    iMax = S1Specific->lastSwathIndex  ;

    lineLoc->firstValidSampleIndex = vectorInt(iMin, iMax) ;
    lineLoc->lastValidSampleIndex = vectorInt(iMin, iMax) ;
    lineLoc->firstRangePixelIndex = vectorInt(iMin, iMax) ;
    lineLoc->lastRangePixelIndex = vectorInt(iMin, iMax) ;
    lineLoc->currentLineInMDS = vectorInt(iMin, iMax) ;
    lineLoc->currentLineInBurst = vectorInt(iMin, iMax) ;
    lineLoc->burstRangeShift = vectorInt(iMin, iMax) ;
    lineLoc->MDSLine = malloc(S1Specific->numberOfSubSwaths * sizeof(complexShort *)) ;
    lineLoc->MDSLine -= iMin ;
    lineLoc->subswathLine = malloc(S1Specific->numberOfSubSwaths * sizeof(complexFloat *)) ;
    lineLoc->subswathLine -= iMin ;
    lineLoc->subswathLine2 = malloc(S1Specific->numberOfSubSwaths * sizeof(complexFloat *)) ;
    lineLoc->subswathLine2 -= iMin ;
    lineLoc->aFullLine = vectorComplexFloat(0, rangeDimension - 1) ;
    lineLoc->zeroLine = vectorComplexFloat(0, rangeDimension - 1) ;
    lineLoc->currentBurst = malloc(S1Specific->numberOfSubSwaths * sizeof(burstDescriptor *)) ;

    /* For each subswath ...*/
    for (swathIndex = iMin; swathIndex <= iMax; swathIndex++) {
        /* We initialize burst and line index */
        lineLoc->currentLineInMDS[swathIndex] = -S1Specific->burstList[swathIndex]->firstAzimuthIndex ;
        lineLoc->firstRangePixelIndex[swathIndex] = S1Specific->firstRangePixelIndexForSubSwath[swathIndex] ;
    }

    for (swathIndex = iMin; swathIndex <= iMax; swathIndex++) {
        lineLoc->MDSLine[swathIndex] = vectorComplexShort(0, S1Specific->swathXDim[swathIndex] - 1) ;
        lineLoc->subswathLine[swathIndex] = vectorComplexFloat(0, S1Specific->swathXDim[swathIndex] + 10) ; /* Adding some space to take potential global range shift between frame into account */
        lineLoc->subswathLine2[swathIndex] = vectorComplexFloat(0, S1Specific->swathXDim[swathIndex] + 10) ;
    }

    lineLoc->tiffMDS = NULL ;

    return (lineLoc) ;
}

void freelineLocInMDS(lineLocInMDS *lineLoc)
{
    int unsigned swathIndex ;
    int unsigned iMin, iMax ;
    S1AdditionalInfo *S1Specific ;

    S1Specific = lineLoc->S1 ;
    iMin = S1Specific->firstSwathIndex ;
    iMax = S1Specific->lastSwathIndex ;

    freeVectorInt(lineLoc->currentLineInBurst, iMin) ;
    freeVectorInt(lineLoc->currentLineInMDS, iMin) ;
    freeVectorInt(lineLoc->lastValidSampleIndex, iMin) ;
    freeVectorInt(lineLoc->firstValidSampleIndex, iMin) ;
    freeVectorInt(lineLoc->lastRangePixelIndex, iMin) ;
    freeVectorInt(lineLoc->firstRangePixelIndex, iMin) ;
    freeVectorInt(lineLoc->burstRangeShift, iMin) ;

    for (swathIndex = iMin; swathIndex <= iMax; swathIndex++) {
        freeVectorComplexShort(lineLoc->MDSLine[swathIndex], 0) ;
        freeVectorComplexFloat(lineLoc->subswathLine[swathIndex], 0) ;
        freeVectorComplexFloat(lineLoc->subswathLine2[swathIndex], 0) ;
    }
    free(lineLoc->MDSLine + iMin) ;
    free(lineLoc->subswathLine + iMin) ;
    free(lineLoc->subswathLine2 + iMin) ;

    freeVectorComplexFloat(lineLoc->aFullLine, 0) ;
    freeVectorComplexFloat(lineLoc->zeroLine, 0) ;
    free(lineLoc->currentBurst) ;

    if (lineLoc->tiffMDS != NULL) {
        for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
//        GTIFFree(lineLoc->gtiffMDS[i]) ;
//            TIFFClose(lineLoc->tiffMDS[i]) ;
            XTIFFClose(lineLoc->tiffMDS[swathIndex]) ;
        }
        free(lineLoc->tiffMDS) ;
//    free(lineLoc->gtiffMDS) ;
    }
    
    free(lineLoc) ;
}



complexFloat *swathLineAtAzimuthIndexFromTIFFMDS(int unsigned azimuthIndex, lineLocInMDS *lineloc, int unsigned swathIndex)
{
    int iX ;
    int burstIndex ;
    int unsigned currentLineInBurst ;
    S1AdditionalInfo *S1Specific ;
    complexFloat complexZero ;
    burstDescriptor *currentBurst ;

    S1Specific = lineloc->S1 ;
    complexZero.r = complexZero.i = 0.0 ;

    lineloc->currentLineInBurst[swathIndex] = 0 ;
    lineloc->currentLineInMDS[swathIndex] = 0 ;

    /* We look for the burst index to which belongs the azimuth line we are looking for */
    lineloc->currentBurst[swathIndex] = currentBurst = getBurstForAzimuthLineInBurstList(S1Specific->burstList[swathIndex], azimuthIndex) ;
    /* If azimuth line lies outside of burst coverage, zero fill */
    if (!currentBurst) {
        lineloc->firstValidSampleIndex[swathIndex] = -1 ;        /* This will prevent burst line to be copied into image line */
    }
    else {
        /* We compute line azimuth index within burst */
        lineloc->currentLineInBurst[swathIndex] = currentLineInBurst = azimuthIndex - currentBurst->firstAzimuthIndex ;
        lineloc->currentLineInMDS[swathIndex] = currentBurst->firstAzimuthIndexInMDS + lineloc->currentLineInBurst[swathIndex] ;

        /* If line azimuth index within burst is outside valid line interval, put firstValidPixelIndex at -1 to prevent line to be copied */
        if (currentLineInBurst < currentBurst->firstValidLine || currentLineInBurst > currentBurst->lastValidLine) {
            lineloc->firstValidSampleIndex[swathIndex] = -1 ;
        }

        /* We determine if we are in a zone of azimuth burst superposition */
        if (azimuthIndex >= currentBurst->midSuperpositionAzimuthIndex) {
            currentBurst = currentBurst->nextBurst ;
        }
        burstIndex = currentBurst->burstIndex ;

        /* !!! We consider here that each burst are saved sequencially, without any gap. byteOffset might be considered in the future for full comaptibility!!!  */

        /* We read tiff line in MDS and convert it in complexFloat */
        if (TIFFReadScanline(lineloc->tiffMDS[swathIndex], lineloc->MDSLine[swathIndex], lineloc->currentLineInMDS[swathIndex], 0) == -1) {
            printf("\t-/-> TIFF read error in MDS swath %d burst %d", swathIndex, burstIndex) ;
            return (NULL) ;
        }
        for (iX = 0; iX < currentBurst->rangeShift; iX++) {
            lineloc->subswathLine[swathIndex][iX] = complexZero ;
        }
        for (; iX < (int)currentBurst->xDim; iX++) {
            lineloc->subswathLine[swathIndex][iX].r = (float)lineloc->MDSLine[swathIndex][iX].r ;
            lineloc->subswathLine[swathIndex][iX].i = (float)lineloc->MDSLine[swathIndex][iX].i ;
        }

        /* We will consider first and last valid pixel of burst in place of per line info */
        lineloc->firstValidSampleIndex[swathIndex] = currentBurst->firstValidSample ;
        lineloc->lastValidSampleIndex[swathIndex] = currentBurst->lastValidSample ;
    }

    return (lineloc->subswathLine[swathIndex]) ;
}


complexFloat *wideSwathLineAtAzimuthIndexFromTIFFMDS(int unsigned azimuthIndex, lineLocInMDS *lineloc)
{
    int j ;
    int unsigned swathIndex, firstSwathIndex, lastSwathIndex ;
    int superpositionStartIndex, superpositionEndIndex, superpositionWidth, iX1 ;
    S1AdditionalInfo *S1Specific ;

    S1Specific = lineloc->S1 ;
    firstSwathIndex = (int)S1Specific->firstSwathIndex ;
    lastSwathIndex = (int)S1Specific->lastSwathIndex ;
    for (swathIndex = firstSwathIndex; swathIndex <= lastSwathIndex; swathIndex++) {
        if ((swathLineAtAzimuthIndexFromTIFFMDS(azimuthIndex, lineloc, swathIndex)) == NULL) {
            return (NULL) ;
        }
    }

    /* We combine all subswath line in a full line for output product */
    /* Init outputline to zero */
    memcpy(lineloc->aFullLine, lineloc->zeroLine, S1Specific->rangeDimension * sizeof(complexFloat)) ;

    for (swathIndex = firstSwathIndex; swathIndex <= lastSwathIndex; swathIndex++) {
        /* We first verify there is something to copy */
        if (lineloc->firstValidSampleIndex[swathIndex] != -1) {

            if(swathIndex == firstSwathIndex) {
                memcpy(&lineloc->aFullLine[0], lineloc->subswathLine[swathIndex], sizeof(complexFloat) * lineloc->currentBurst[swathIndex]->xDim) ;
            }
            /* In range superposition areas... */
            else {
                /* We compute the start and end index of the superposition as also its width */
                superpositionStartIndex = S1Specific->firstRangePixelIndexForSubSwath[swathIndex] + lineloc->firstValidSampleIndex[swathIndex] ;
                superpositionEndIndex = S1Specific->firstRangePixelIndexForSubSwath[swathIndex - 1] + lineloc->lastValidSampleIndex[swathIndex - 1] ;
                superpositionWidth = superpositionEndIndex - superpositionStartIndex + 1 ;
                superpositionStartIndex -= S1Specific->firstRangePixelIndexForSubSwath[firstSwathIndex] ;

                /* We copy next swath line */
                memcpy(&lineloc->aFullLine[superpositionStartIndex], lineloc->subswathLine[swathIndex] + lineloc->firstValidSampleIndex[swathIndex], sizeof(complexFloat) * (lineloc->currentBurst[swathIndex]->xDim - lineloc->currentBurst[swathIndex]->firstValidSample)) ;

                /* If previous subswath is not empty... */
                if (lineloc->firstValidSampleIndex[swathIndex - 1] != -1) {
                    /* We compute the start index in first sub swaths */
                    iX1 = lineloc->lastValidSampleIndex[swathIndex - 1] - superpositionWidth + 1 ;
                    /* And we join subswaths at mid superposition */
                    superpositionWidth /= 2 ;
                    for (j = 0; j < superpositionWidth; j++, iX1++) {
                        lineloc->aFullLine[superpositionStartIndex + j] = lineloc->subswathLine[swathIndex - 1][iX1] ;
                    }
                }
            }
        }
    }

    return lineloc->aFullLine ;
}

complexFloat *swathLineAtAzimuthIndexFromReadBursts(int unsigned azimuthIndex, lineLocInMDS *lineloc, int unsigned layerIndex, int unsigned swathIndex)
{
    int iX ;
    int unsigned  currentLineInBurst ;
    long seekVal ;
    size_t shortCount ;
    S1AdditionalInfo *S1Specific ;
    complexFloat complexZero ;
    burstDescriptor *currentBurst ;

    S1Specific = lineloc->S1 ;
    complexZero.r = complexZero.i = 0.0 ;

    lineloc->lastValidSampleIndex[swathIndex] = lineloc->firstValidSampleIndex[swathIndex] = lineloc->currentLineInBurst[swathIndex] = 0 ;

    /* We look for the burst index to which belongs the azimuth line we are looking for */
    lineloc->currentBurst[swathIndex] = currentBurst = getBurstForAzimuthLineInBurstList(S1Specific->burstList[swathIndex], azimuthIndex) ;
    /* If azimuth line lies outside of burst coverage, zero fill */
    if (!currentBurst) {
        lineloc->firstValidSampleIndex[swathIndex] = -1 ;        /* This will prevent burst line to be copied into image line */
    }
    else {
        /* We determine if we are in a zone of azimuth burst superposition */
        if (azimuthIndex >= currentBurst->midSuperpositionAzimuthIndex) {
            currentBurst = currentBurst->nextBurst ;
        }

        /* We compute line azimuth index within burst */
        lineloc->currentLineInBurst[swathIndex] = currentLineInBurst = azimuthIndex - currentBurst->firstAzimuthIndex ;

        /* If line azimuth index within burst is outside valid line interval, put firstValidPixelIndex at -1 to prevent line to be copied */
        if (currentLineInBurst < currentBurst->firstValidLine || currentLineInBurst > currentBurst->lastValidLine) {
            lineloc->firstValidSampleIndex[swathIndex] = -1 ;
            return (lineloc->subswathLine[swathIndex]) ;
        }

        /* We compute the shift that may exists between swath border and burst in case of frame stitching. RangeShift = 0 for a single frame */
        for (iX = 0; iX < currentBurst->rangeShift; iX++) {
            lineloc->subswathLine[swathIndex][iX] = complexZero ;
        }

        /* And We read corresponding line in corresponding burst */
        seekVal = currentLineInBurst * currentBurst->xDim * sizeof(complexFloat) ;
        if(fseek(currentBurst->file[layerIndex]->f, seekVal, SEEK_SET)) {
            ase("failed to seek into burst file") ;
        }

        if ((shortCount = fread(lineloc->subswathLine[swathIndex] + currentBurst->rangeShift, sizeof(complexFloat), currentBurst->xDim, currentBurst->file[layerIndex]->f)) != currentBurst->xDim) {
            printf("Failed to read line in burst: \nCurrent line in burst: %d\nBurst location: %s\n", currentLineInBurst, currentBurst->file[layerIndex]->accessPath) ;
            printf("Burst size: %ld\n", currentBurst->file[layerIndex]->fileLength) ;
            printf("Read failed when trying to read %ld bytes from byte %ld\n", currentBurst->xDim * sizeof(complexFloat), seekVal) ;
            printf("Number of bytes read: %ld\n", shortCount) ;
            ase("Failed to read line in burst") ;
        }
        /* We will consider first and last valid pixel of burst in place of per line info */
        lineloc->firstValidSampleIndex[swathIndex] = currentBurst->firstValidSample ;
        lineloc->lastValidSampleIndex[swathIndex] = currentBurst->lastValidSample ;
        lineloc->burstRangeShift[swathIndex] = (int)(currentBurst->rangeTransformConstantTerm) + currentBurst->rangeShift ;
        lineloc->firstRangePixelIndex[swathIndex] = currentBurst->firstRangeIndex ;
        lineloc->lastRangePixelIndex[swathIndex] = currentBurst->lastRangeIndex ;
    }

    return (lineloc->subswathLine[swathIndex]) ;
}




complexFloat *wideSwathLineAtAzimuthIndexFromReadBursts(int unsigned azimuthIndex, lineLocInMDS *lineloc, int unsigned layerIndex)
{
    int unsigned swathIndex ;
    int superpositionWidth ;
    int srcFirstSample ;
    size_t destFirstSample, numberOfPixelsToCopy ;
    S1AdditionalInfo *S1Specific ;
    complexFloat complexZero ;

    S1Specific = lineloc->S1 ;
    complexZero.r = complexZero.i = 0.0 ;

    lineloc->isBlackLine = 1 ;
    for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
        swathLineAtAzimuthIndexFromReadBursts(azimuthIndex, lineloc, layerIndex, swathIndex) ;
    }

    /* We combine all subswath line in a full line for output product */
    /* Init outputline to zero */
    memcpy(lineloc->aFullLine, lineloc->zeroLine, S1Specific->rangeDimension * sizeof(complexFloat)) ;
//memset(lineloc->aFullLine, 0, S1Specific->rangeDimension * sizeof(complexFloat)) ;

    for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
        /* We first verify there is something to copy */
        if (lineloc->firstValidSampleIndex[swathIndex] != -1) {
            lineloc->isBlackLine = 0 ;
            numberOfPixelsToCopy = S1Specific->numberOfValidSamples[swathIndex] ;
            destFirstSample = S1Specific->superpositionStartIndex[swathIndex] - S1Specific->firstRangePixelIndexForSubSwath[S1Specific->firstSwathIndex];
            srcFirstSample = S1Specific->firstValidSampleForSubSwath[swathIndex] + lineloc->burstRangeShift[swathIndex] ;
            /* In range superposition areas... */
            if(swathIndex != S1Specific->firstSwathIndex) {
                /* If previous subswath is not empty... */
                if (lineloc->firstValidSampleIndex[swathIndex - 1] != -1) {
                    superpositionWidth = S1Specific->superpositionWidth[swathIndex] ;
                    srcFirstSample += superpositionWidth / 2 ;
                    destFirstSample += superpositionWidth / 2 ;
                    numberOfPixelsToCopy -= superpositionWidth / 2 ;
                }
            }
            if (srcFirstSample < 0) {
                destFirstSample -= srcFirstSample ;
                numberOfPixelsToCopy += srcFirstSample ;
                srcFirstSample = 0 ;
            }
            if (destFirstSample + numberOfPixelsToCopy >= S1Specific->rangeDimension) {
                numberOfPixelsToCopy = S1Specific->rangeDimension - destFirstSample - 1 ;
            }
            
            memcpy(lineloc->aFullLine + destFirstSample, lineloc->subswathLine[swathIndex] + srcFirstSample, sizeof(complexFloat) * numberOfPixelsToCopy) ;
        }
    }

    return lineloc->aFullLine ;
}

void concatenateBurstsIntoWideSwathImage(CSLImage *thisImage, SLCImageInfo *info, char trashBursts)
{
    char *outputPath ;
    int unsigned iY ;
    int unsigned layerIndex ;
    lineLocInMDS *lineLoc ;
    CSVStruct *csv ;
    S1AdditionalInfo *S1Specific ;
    progressCounter *counter ;
    rawFileDescriptor *outputLayerFile = NULL ;
    complexFloat *anOutputLine ;

    S1Specific = info->sensorSpecificInfo ;
    csv = readCSVInString(info->polMode) ;

    for (layerIndex = 0; layerIndex < info->numberOfLayers; layerIndex++) {
        /* Create output file stream */
        outputPath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", csv->stringVal[layerIndex]) ;
        if((outputLayerFile = openRawFileForWritingAtPath(outputPath)) == NULL) {
            sprintf(ertex, "Failed to create output file at path %s", outputPath) ;
            perror(ertex) ;
            exit(-1) ;
        }
        free(outputPath) ;

        printf("\nConcatenate bursts of Sentinel 1 %d data: %s polarization layer\n", info->relativeOrbitNumber, csv->stringVal[layerIndex]) ;
        lineLoc = initlineLocInMDS(info) ;
        counter = initProgressCounterWithMinMaxValue(S1Specific->azimuthIndexStart, S1Specific->azimuthIndexEnd) ;
        for (iY = S1Specific->azimuthIndexStart; iY <= S1Specific->azimuthIndexEnd; iY++) {
            anOutputLine = wideSwathLineAtAzimuthIndexFromReadBursts(iY, lineLoc, layerIndex) ;
/*
            seekVal = (iY - S1Specific->azimuthIndexStart) * info->rangeDimension * sizeof(complexFloat) ;
            if (fseeko(outputLayerFile->f, seekVal, SEEK_SET)) {
                ase("Failed to seek into output data file\n") ;
            }
*/
            if ((info->rangeDimension != (int)fwrite(anOutputLine, sizeof(complexFloat), info->rangeDimension, outputLayerFile->f))) {
                ase("Failed to write line into data file\n") ;
            }
            fflush(outputLayerFile->f) ;

            updateProgressCounterForIndex(counter, iY) ;
        }
        updateProgressCounterForIndex(counter, iY) ;

        freelineLocInMDS(lineLoc) ;
        freeRawFileDescriptor(outputLayerFile) ;
        freeProgressCounter(counter) ;
    }

    if (trashBursts) {
        trashSelectedBursts(info) ;
    }

    freeCSVStruct(csv) ;
}

/* Trash bursts */
void trashSelectedBursts(SLCImageInfo *info)
{
    int unsigned layerIndex, swathIndex ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst ;

    S1Specific = info->sensorSpecificInfo ;
    for (layerIndex = 0; layerIndex < info->numberOfLayers; layerIndex++) {
        for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
            currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
            while (currentBurst->isSelected) {
                closeRawFile(currentBurst->file[layerIndex]) ;
                unlink(currentBurst->file[layerIndex]->accessPath) ;
                if (!(currentBurst = currentBurst->nextBurst)) {
                    break ;
                }
            }
        }
    }
}

void trashAllBursts(CSLImage *thisImage)
{
    int i ;
    CSVStruct *burstList ;

    if((burstList = recursiveSearchOfFileInDir("SW", thisImage->dataDirectoryPath))) {
        for (i = 0; i < burstList->numberOfEntries; i++) {
            unlink(burstList->stringVal[i]) ;
        }
    }
}

/* Create requested burst files for reading and writing */
void createBurstFilesForReadingAndWriting(CSLImage *thisImage, SLCImageInfo *info)
{
    info->flag |= _S1_CREATE_BURST_FILES_ ;
    openBurstFilesForReadingAndWriting(thisImage, info) ;
}


/* Open existing burst files for reading and writing or create them if requested through info->flag */
void openBurstFilesForReadingAndWriting(CSLImage *thisImage, SLCImageInfo *info)
{
    char *outputPath, fileName[_MAX_PATH_LENGTH_] ;
    char *perBurstImagePath ;
    int unsigned layerIndex, swathIndex ;
    S1AdditionalInfo *S1Specific ;
    CSVStruct *csv ;
    burstDescriptor *currentBurst ;

    S1Specific = info->sensorSpecificInfo ;
    /* Read number of layers */
    csv = info->polScheme ;

    /* loop on layers */
    for (layerIndex = 0; layerIndex < S1Specific->numberOfLayers; layerIndex++) {
        /* Loop on swath */
        for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
            /* Loop on bursts */
            currentBurst = getFirstSelectedBurstInList(S1Specific->burstList[swathIndex]) ;
            if (currentBurst) {
                do {
                    if (!currentBurst->file[layerIndex]) {
                        /* Detect if we are dealing with former S1 .csl image format */
                        /* In which case, selected bursts already exists */
                        sprintf(fileName, "SW%1d.b%d.%s", swathIndex, currentBurst->burstIndex, csv->stringVal[layerIndex]) ;
                        outputPath = initStringWith3Strings(thisImage->dataDirectoryPath, "/", fileName) ;
                        if (fileExistsAtPath(outputPath)) {
                            if((currentBurst->file[layerIndex] = openRawFileForReadingAndWritingAtPath(outputPath)) == NULL) {
                                sprintf(ertex, "Failed to create/open S1 burst file at path %s", outputPath) ;
                                ase(ertex) ;
                                exit(-1) ;
                            }
                        }
                        else {
                            if (!layerIndex) {
                                sprintf(fileName, "SW%1db%d.csl", swathIndex, currentBurst->burstIndex) ;
                                perBurstImagePath = initStringWith3Strings(thisImage->dataDirectoryPath, "/", fileName) ;
                                if (!isDir(perBurstImagePath)) {
                                    currentBurst->burstImage = createCSLDirectoryStructureAtPath(perBurstImagePath, __SENTINEL1__) ;
                                }
                                else {
                                    currentBurst->burstImage = getCSLImageStructureAtPath(perBurstImagePath) ;
                                }
                                free(perBurstImagePath) ;
                            }
                            
                            free(outputPath) ;
                            outputPath = initStringWith3Strings(currentBurst->burstImage->dataDirectoryPath, "/SLCData.", csv->stringVal[layerIndex]) ;
                            if (fileExistsAtPath(outputPath) || info->flag & _S1_CREATE_BURST_FILES_) {
                                if((currentBurst->file[layerIndex] = openRawFileForReadingAndWritingAtPath(outputPath)) == NULL) {
                                    sprintf(ertex, "Failed to create/open S1 burst file at path %s", outputPath) ;
                                    ase(ertex) ;
                                    exit(-1) ;
                                }
                            }
                        }
                        free(outputPath) ;
                    }
                    if (currentBurst->file[layerIndex]) {
                        rewind(currentBurst->file[layerIndex]->f) ;
                    }
                    currentBurst = currentBurst->nextBurst ;
                } while (currentBurst && currentBurst->isSelected);
            }
        }
    }
}



void closeAndReleasBurstFiles(SLCImageInfo *info)
{
    int unsigned layerIndex, swathIndex ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst ;

    S1Specific = info->sensorSpecificInfo ;

    /* loop on layers */
    for (layerIndex = 0; layerIndex < info->numberOfLayers; layerIndex++) {
        /* Loop on swath */
        for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
            /* Loop on bursts */
            currentBurst = S1Specific->burstList[swathIndex] ;
            do {
                if (currentBurst->file[layerIndex]) {
                    freeRawFileDescriptor(currentBurst->file[layerIndex]) ;
                    currentBurst->file[layerIndex] = NULL ;
                }
            } while ((currentBurst = currentBurst->nextBurst));
        }
    }
}



void detectSelectedBurstsInCSLImage(CSLImage *thisImage, SLCImageInfo *info)
{
    char formatString[6] ;
    int i ;
    int unsigned swathIndex, burstIndex, minSwathIndex, maxSwathIndex, minBurstIndex, maxBurstIndex ;
    S1AdditionalInfo *S1Specific ;
    burstDescriptor *currentBurst ;

    S1Specific = info->sensorSpecificInfo ;

    minSwathIndex = 9999 ;
    maxSwathIndex = 0 ;
    minBurstIndex = 9999 ;
    maxBurstIndex = 0 ;

    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        sprintf(formatString, "SW%1d.b", swathIndex) ;
        for (i = 0; i < thisImage->numberOfDataFiles; i++) {
            if (isSubStringPresentInString(thisImage->dataFileNames[i], formatString)) {
                minSwathIndex = (swathIndex < minSwathIndex)? swathIndex : minSwathIndex ;
                maxSwathIndex = (swathIndex > maxSwathIndex)? swathIndex : maxSwathIndex ;

                sscanf(thisImage->dataFileNames[i] + 5, "%1d", &burstIndex) ;
                minBurstIndex = (minBurstIndex > burstIndex)? burstIndex : minBurstIndex ;
                maxBurstIndex = (maxBurstIndex < burstIndex)? burstIndex : maxBurstIndex ;
            }
        }
    }

    S1Specific->firstSwathIndex = minSwathIndex ;
    S1Specific->lastSwathIndex = maxSwathIndex ;
    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex ++) {
        currentBurst = S1Specific->burstList[swathIndex] ;
        do {
            currentBurst->isSelected = (swathIndex >= minSwathIndex && swathIndex <= maxSwathIndex && currentBurst->burstIndex >= minBurstIndex && currentBurst->burstIndex <= maxBurstIndex)? 1 : 0 ;
        } while ((currentBurst = currentBurst->nextBurst)) ;
    }

    updateSpecificFieldsForSelectedBursts(info) ;
}

void readBurstSelectionInCSLImage(CSLImage *thisImage, SLCImageInfo *info)
{
    char *aPath, aKey[_MAX_COMMENT_LENGTH_] ;
    int unsigned swathIndex, burstIndex ;
    int unsigned firstBurstIndex = 0, lastBurstIndex = 0 ;
    keyValue *SLCDataDescription ;
    S1AdditionalInfo *S1Specific ;
    CSVStruct *csv ;
    burstDescriptor *currentBurst ;

    S1Specific = info->sensorSpecificInfo ;

    /* Deselect all bursts */
    for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
        for (burstIndex = 0; burstIndex < S1Specific->numberOfBursts[swathIndex]; burstIndex++) {
            currentBurst = getBurstAtIndex(S1Specific->burstList[swathIndex], burstIndex) ;
            currentBurst->isSelected = 0 ;
        }
    }

    /* If a burst selection file exists, proceed and update fields with respect to selected bursts */
    aPath = initStringWith3Strings(thisImage->infoDirectoryPath, "/", "burstSelection.txt") ;
    if ((SLCDataDescription = readParameterFileAtPath(aPath))) {
        S1Specific->firstSwathIndex = getIntValForKeyIn(SLCDataDescription, "First swath index") ;
        S1Specific->lastSwathIndex = getIntValForKeyIn(SLCDataDescription, "Last swath index") ;

        for (swathIndex = S1Specific->firstSwathIndex; swathIndex <= S1Specific->lastSwathIndex; swathIndex++) {
            sprintf(aKey, "Swath %1d burst selection", swathIndex) ;
            if((csv = getCSVValForKeyIn(SLCDataDescription, aKey)) != NULL) {
                sscanf(csv->stringVal[0], "%d", &firstBurstIndex) ;
                sscanf(csv->stringVal[csv->numberOfEntries - 1], "%d", &lastBurstIndex) ;
                for (burstIndex = firstBurstIndex; burstIndex <= lastBurstIndex; burstIndex++) {
                    currentBurst = getBurstAtIndex(S1Specific->burstList[swathIndex], burstIndex) ;
                    currentBurst->isSelected = 1 ;
                }
            }

            freeCSVStruct(csv) ;
        }
        freeKeyValueList(SLCDataDescription) ;

        updateSpecificFieldsForSelectedBursts(info) ;
    }
    free(aPath) ;

}


CSVStruct *readS1Data(char *S1AccesPath, char *outputPath, quadrilateral *aoi, char *selectedPolarization, unsigned int flag)
{
    char *inputFileName, *outputDir, *containerPath, *framePath, frameName[32] ;
    char *infoImageFilePath, *logFilePath ;
    char *POEORB_Dir, readData ;
    int frameIndex, orbitUpdateFlag ;
    CSLImage *imageContainer, *thisFrame ;
    SLCImageInfo *frameInfo, *imageInfo ;
    CSVStruct *savedImages = NULL ;
    rawFileDescriptor *logFile = NULL ;

    /* Locate precise orbit directory */
    if ((POEORB_Dir = getenv("S1_ORBITS_DIR")) == NULL) {
        printf("\t -/-> S1 orbit directory not defined\n") ;
    }

    inputFileName = getPointerToFileNameInPath(S1AccesPath) ;
    /* First, we deal with stitching of already read data */
    if (flag & _S1_HEADER_STITCHING_) {
        if ((imageContainer = getCSLImageStructureAtPath(S1AccesPath)) == NULL) {
            sprintf(ertex, "_S1_HEADER_STITCHING_ : Input image is not a .csl image ---> %s", S1AccesPath) ;
            ase(ertex) ;
        }

        /* Update orbit */
        orbitUpdateFlag = updateS1PreciseOrbitInCSLImage(imageContainer) ;
        outputOrbitUpdateMessage(NULL, orbitUpdateFlag) ;

        /* Merge infomage with existing ones */
        imageInfo = mergeFrameInfo(imageContainer, selectedPolarization) ;
        infoImageFilePath = initStringWith2Strings(imageContainer->infoDirectoryPath, "/SLCImageInfo.txt") ;
        saveS1InfoImage(imageInfo, infoImageFilePath) ;
        free(infoImageFilePath) ;

        /* If stitching requested, proceed */
        if (flag & _S1_IMAGE_STITCHING_) {
            /* But only if stitched image does not already exists */
            if (!isSLCDataFilePresentInCSLImage(imageContainer, imageInfo)) {
                concatenateBurstsIntoWideSwathImage(imageContainer, imageInfo, _S1_KEEP_BURSTS_) ;
                savedImages = addStringValInCSVStruct(imageContainer->imageDirectoryPath, savedImages) ;
            }
            else {
                printf("\t---> Stitched image already existing. Nothing to be done\n") ;
            }

            /* If stitching worked out or already done, handle bursts as requested */
            if (flag & _S1_TRASH_BURSTS_) {
                printf("\t---> Trashing burst as requested\n") ;
                /* We first free and trash selected bursts */
                trashSelectedBursts(imageInfo) ;
                /* Then we trash all others (all files who's name contains "SW" without distinction) */
                trashAllBursts(imageContainer) ;
            }
       }

        freeS1Specific(imageInfo->sensorSpecificInfo, _S1_TRASH_BURSTS_) ;
        freeInfoImage(imageInfo) ;
        freeCSLImageStructure(imageContainer) ;
    }
    else {
        /* Create log file */
        logFilePath = initStringWith2Strings(outputPath, "/S1DataReaderLog.txt") ;
        logFile = openRawFileForReadingAndWritingAtPath(logFilePath) ;
        fseek(logFile->f, (off_t)0, SEEK_END) ;
        if (POEORB_Dir == NULL) {
            writeToLog(logFile->f, "\t -/-> Precise orbit directory not defined\n") ;
        }

        if ((frameInfo = createSLCImageInfoForS1Data(S1AccesPath, selectedPolarization)) != NULL) {
        /* If reading of new data is requested, create infoImage and proceed */
            /* Generate output name if required */
            if (flag & _S1_BULK_READING_) {
                outputDir = initStringWithString(outputPath) ;

                if (frameInfo->relativeOrbitNumber < 0) {
                    sprintf(accessPath, "%.3s_%.8s_%.1s", inputFileName, inputFileName + 17, frameInfo->heading) ;
                }
                else {
                    sprintf(accessPath, "%.3s_%d_%.8s_%.1s", inputFileName, frameInfo->relativeOrbitNumber, inputFileName + 17, frameInfo->heading) ;
                }
                containerPath = initStringWith3Strings(outputDir, "/", accessPath) ;
            }
            else {
                containerPath = initStringWithString(outputPath) ;
                outputDir = getDirectoryPathFromPath(containerPath) ;
            }

            /* First, we test if there is something to read */
            readData = 1 ;
            /* If we deal with an IW or EW image, we check that aoi is covered by available bursts */
            if (aoi && readData && !(flag & _S1_SM_READ_AND_SAVE_)) {
                printf("\n---> Selecting burst into image: %s\n", inputFileName) ;
                if (!(readData *= selectS1Bursts(aoi, frameInfo, flag))) {
                    sprintf(ertex, "\t\t---> Skip reading S1 image %s\n\t\t---> No common superposition with given aoi\n", S1AccesPath) ;
                    printf("%s", ertex) ;
                    writeToLog(logFile->f, ertex) ;
                }
            }
            /* If we deal with SM, we check if image was already read or not */
            if (flag & _S1_SM_READ_AND_SAVE_) {
                if (isCSLImageAtPath(containerPath)) {
                    if (flag & _S1_READ_OVERWRITE_) {
                        removeDirectoryAtPath(containerPath) ;
                    }
                    else{
                        sprintf(ertex, "\t\t---> Skip reading S1 image %s\n\t\t---> Image already existing at destination path\n", S1AccesPath) ;
                        printf("%s", ertex) ;
                        writeToLog(logFile->f, ertex) ;
                        readData = 0 ;
                        /* Update orbit if possible */
                        if ((orbitUpdateFlag = updateS1PreciseOrbitInCSLImageAtPath(containerPath))) {
                            if (orbitUpdateFlag == _S1_PRECISE_ORBIT_UPDATED_OK_) {
                                sprintf(ertex, "\t---> Anyway, precise orbit update performed\n") ;
                            }
                            if (orbitUpdateFlag == _S1_RESTITUTED_ORBIT_UPDATED_OK_) {
                                sprintf(ertex, "\t---> Anyway, restituted orbit update performed\n") ;
                            }
                        }
                        printf("%s", ertex) ;
                        writeToLog(logFile->f, ertex) ;
                    }
                }  
            }
            fflush(logFile->f) ;          

            if (readData) {
                /* First, if dealing with IW or EW data, we test if S1 image container is already existing in destination directory */
                if (isCSLImageAtPath(containerPath) && !(flag & _S1_SM_READ_AND_SAVE_)) {
                    if ((imageContainer = getCSLImageStructureAtPath(containerPath)) == NULL) {
                        sprintf(ertex, "_S1_SM_READ_AND_SAVE_ : Input image is not a .csl image ---> %s", containerPath) ;
                        ase(ertex) ;
                    }
                    /* If frame already present, handle it as requested */
                    if ((frameIndex = getFrameIndexInCSLImage(imageContainer, frameInfo)) != -1) {
                        sprintf(frameName, "Frame%1d.csl", frameIndex) ;
                        framePath = initStringWith3Strings(imageContainer->dataDirectoryPath, "/", frameName) ;
                        if (((flag & _S1_READ_OVERWRITE_) || (frameInfo->flag & _CSLIMAGE_FORCE_OVERWRITTING_)) && !(frameInfo->flag & _CSLIMAGE_CANCEL_OVERWRITTING_)) {
                            removeDirectoryAtPath(framePath) ;
                        }
                        else {
                            sprintf(ertex, "\t---> Skipping S1 image %s\n\t---> Frame already present in image %s.\n", S1AccesPath, getPointerToFileNameInPath(imageContainer->imageDirectoryPath)) ;
                            printf("%s", ertex) ;
                            writeToLog(logFile->f, ertex) ;
                            frameIndex = -1 ;
                            /* Update orbit if possible */
                            if ((orbitUpdateFlag = updateS1PreciseOrbitInCSLImageAtPath(framePath))) {
                                outputOrbitUpdateMessage(logFile, orbitUpdateFlag) ;
                            }
                        }
                        if (frameInfo->flag & _CSLIMAGE_FORCE_OVERWRITTING_) {
                            sprintf(ertex, "\t\t---> Fast-24h frame %d replaced by Normal Archive one in image %s\n", frameIndex, getPointerToFileNameInPath(imageContainer->imageDirectoryPath)) ;
                            printf("%s", ertex) ;
                            writeToLog(logFile->f, ertex) ;
                        }
                        free(framePath) ;
                    }
                    else {
                        frameIndex = getNewFrameIndexInCSLImage(imageContainer, frameInfo->FPAT) ;
                    }
                }
                else {
                    /* Else, create image container at requested location */
                    frameIndex = 0 ;
                    imageContainer = createCSLDirectoryStructureAtPath(containerPath, __SENTINEL1__) ;
                }
                fflush(logFile->f) ;

                if (frameIndex >= 0) {
                    /* If we deal with IW or EW data ...*/
                    if (!(flag & _S1_SM_READ_AND_SAVE_)) {
                        /* Generate frame name and path */
                        sprintf(frameName, "Frame%1d.csl", frameIndex) ;
                        framePath = initStringWith3Strings(imageContainer->dataDirectoryPath, "/", frameName) ;

                        /* Create destination frame */
                        thisFrame = createCSLDirectoryStructureAtPath(framePath, __SENTINEL1__) ;

                        /* Open destination burst files */
                        createBurstFilesForReadingAndWriting(thisFrame, frameInfo) ;
                    }
                    else {
                        framePath = initStringWithString(imageContainer->imageDirectoryPath) ;
                        thisFrame = imageContainer ;
                    }
                    /* Verify if orbitography can be updated with precise orbit data */
                    printf("\t---> Reading Sentinel 1 data %s\n", inputFileName) ;
                    printf("\t---> Writing to file %s\n", framePath) ;

                    /* Copy headers */
                    printf("\t\t---> Copying original headers into read frame\n") ;
                    copyS1HeadersToCSLImage(frameInfo->sensorSpecificInfo, thisFrame) ;

                    /* Save infoImage for read frame */
                    printf("\t\t---> Saving infoImage for read frame\n") ;
                    infoImageFilePath = initStringWith2Strings(thisFrame->infoDirectoryPath, "/SLCImageInfo.txt") ;
                    saveS1InfoImage(frameInfo, infoImageFilePath) ;
                    free(infoImageFilePath) ;

                    printf("\t\t---> Orbit management...\n") ;
                    orbitUpdateFlag = updateS1PreciseOrbitInCSLImageAtPath(framePath) ;
                    outputOrbitUpdateMessage(logFile, orbitUpdateFlag) ;

                    if ((flag & _S1_READ_IF_ORBIT_UPDATE_) && ((orbitUpdateFlag != _S1_PRECISE_ORBIT_UPDATED_OK_) && (orbitUpdateFlag != _S1_RESTITUTED_ORBIT_UPDATED_OK_))) {
                        printf("\t\t-/-> Skip reading as requested. No PRECISE or RESTITUTED orbit available for considered frame\n") ;
                        writeToLog(logFile->f, "\t\t-/-> Skip reading as requested. No PRECISE or RESTITUTED orbit available for considered frame\n") ;
                        removeDirectoryAtPath(thisFrame->imageDirectoryPath) ;
                        if (!getNumberOfFramesInCSLImage(imageContainer)) {
                            removeDirectoryAtPath(imageContainer->imageDirectoryPath) ;
                        }                       
                    }
                    else {
                        /* Merge infomage with existing ones */
                        imageInfo = NULL ;
                        if (!(flag & _S1_SM_READ_AND_SAVE_)) {
                            printf("\t\t---> merging infoImage of read frame(s) into root image container\n") ;
                            imageInfo = mergeFrameInfo(imageContainer, selectedPolarization) ;
                            infoImageFilePath = initStringWith2Strings(imageContainer->infoDirectoryPath, "/SLCImageInfo.txt") ;
                            saveS1InfoImage(imageInfo, infoImageFilePath) ;
                            free(infoImageFilePath) ;
                        }
                        /* Proceed to reading */
                        if (!(flag & _S1_READ_HEADERS_ONLY_)) {
                            if ((flag & _S1_SM_READ_AND_SAVE_)) {
                                if ((readS1DATALayersInto(imageContainer, frameInfo)) == -1){
                                    removeDirectoryAtPath(imageContainer->imageDirectoryPath) ;
                                    printf("\\t-/-> Removing image container.\n") ;
                                }
                            }
                            else {
                                if ((readS1DATALayersBurstsInto(thisFrame, frameInfo)) == -1){
                                    printf("\t-/-> Read error.\n\t-/-> Removing frame from image container.") ;
                                    removeDirectoryAtPath(thisFrame->imageDirectoryPath) ;
                                    if (!getNumberOfFramesInCSLImage(imageContainer)) {
                                        removeDirectoryAtPath(imageContainer->imageDirectoryPath) ;
                                        printf("\\t-/-> Removing image container.\n") ;
                                    }                       
                                }
                                if ((flag & _S1_TIFF_BURST_STITCHING_) ) {
                                    concatenateBurstsIntoWideSwathImage(imageContainer, imageInfo, _S1_KEEP_BURSTS_) ;
                                }
                                freeS1Specific(imageInfo->sensorSpecificInfo, _S1_TRASH_BURSTS_) ;
                                freeInfoImage(imageInfo) ;
                            }
                        }
                        savedImages = addStringValInCSVStruct(imageContainer->imageDirectoryPath, savedImages) ;
                    }
                    
                    freeCSLImageStructure(thisFrame) ;
                    if (!(flag & _S1_SM_READ_AND_SAVE_)) {
                        freeCSLImageStructure(imageContainer) ;
                    }
                    free(framePath) ;
                }
            }

            freeS1Specific(frameInfo->sensorSpecificInfo, _S1_TRASH_BURSTS_) ;
            freeInfoImage(frameInfo) ;
            free(outputDir) ;
            free(containerPath) ;
            if (logFile) {
                freeRawFileDescriptor(logFile) ;
                free(logFilePath) ;
            }
        }
        else {
            printf("%s", ertex) ;
            writeToLog(logFile->f, ertex) ;
            sprintf(ertex, "\t\t-/-> Skipping reading of image %s\n", inputFileName) ;
            printf("%s", ertex) ;
            writeToLog(logFile->f, ertex) ;
        }
    }

    return (savedImages) ;
}


/* Merge frames info and open all burst files for reading and writing */
/* If *selectedPolarizations is NULL or set to "ALL", original polarization scheme of the image is preserved */
/* If willing to limit polarization scheme, set *selectedPolarizations correspondingly */
/* Polarization scheme will be adapted provided it is contained within original one */
SLCImageInfo *mergeFrameInfo(CSLImage *imageContainer, char *selectedPolarizations)
{
    char *framePath, adaptPolScheme, testVal ;
    int unsigned numberOfFrames, frameIndex ;
    int unsigned swathIndex, orbitTypeID ;
    int iY1, iY2, numberOfStateVectors ; ;
    SLCImageInfo *imageInfo, *frameInfo ;
    S1AdditionalInfo *S1Specific, *S1FrameSpecific ;
    CSLImage *thisImage, *thisFrame ;
    burstDescriptor *lastBurst, *firstBurst ;
    struct stateVect *newStateVectorList, *lastStateVector ;
    CSVStruct *requestedPolScheme ;

    numberOfFrames = getNumberOfFramesInCSLImage(imageContainer) ;

    /* We read infoImage of first frame in order to create new instance of it */
    frameIndex = 0 ;
    sprintf(accessPath, "%s/Frame%1d.csl", imageContainer->dataDirectoryPath, frameIndex) ;

    /* If we do not deal with a Sentinel IW image return main imageInfo text file */
    if (!isDir(accessPath)) {
        sprintf(accessPath, "%s/SLCImageInfo.txt", imageContainer->infoDirectoryPath) ;
        imageInfo = readInfoImageFromTextFile(accessPath) ;
        return imageInfo ;
    }
    
    if ((thisImage = getCSLImageStructureAtPath(accessPath)) == NULL) {
        sprintf(ertex, "mergeFrameInfo : No .csl frame image found.\n---> %s", accessPath) ;
        ase(ertex) ;
    }
    
    sprintf(accessPath, "%s/Frame%1d.csl/Info/SLCImageInfo.txt", imageContainer->dataDirectoryPath, frameIndex) ;
    imageInfo = readInfoImageFromTextFile(accessPath) ;
    imageInfo->CSLImagePath = initStringWithString(imageContainer->imageDirectoryPath) ;

    /* Check if polarization scheme should be adapted */
    adaptPolScheme = 0 ;
    if (selectedPolarizations && !isSubStringPresentInString(selectedPolarizations, "ALL")) {
        requestedPolScheme = readCSVInString(selectedPolarizations) ;
        adaptPolScheme = 1 ;
        for (iY1 = 0; iY1 < requestedPolScheme->numberOfEntries; iY1++) {
            testVal = 0 ;
            for (iY2 = 0; iY2 < imageInfo->polScheme->numberOfEntries; iY2++) {
                testVal += (!strcmp(requestedPolScheme->stringVal[iY1], imageInfo->polScheme->stringVal[iY2]))? 1 : 0 ;
            }
            adaptPolScheme *= (testVal)? 1 : 0 ;
        }        
    }
    if (adaptPolScheme) {
        freeCSVStruct(imageInfo->polScheme) ;
        sprintf(imageInfo->polMode, "%s", selectedPolarizations) ;
        imageInfo->polScheme = readCSVInString(imageInfo->polMode) ;
    }

    /* Select orbit type */
    orbitTypeID = (isSubStringPresentInString(imageInfo->orbitTypeID, "Precise"))? 2 : (isSubStringPresentInString(imageInfo->orbitTypeID, "Restituted"))? 1 : 0 ;

    S1Specific = initS1SpecificInfo(imageInfo, thisImage->imageDirectoryPath) ;
    readBurstSelectionInCSLImage(thisImage, imageInfo) ;
    openBurstFilesForReadingAndWriting(thisImage, imageInfo) ;

    for (frameIndex = 1; frameIndex < numberOfFrames; frameIndex++) {
        sprintf(accessPath, "%s/Frame%1d.csl", imageContainer->dataDirectoryPath, frameIndex) ;
        framePath = initStringWithString(accessPath) ;
        if ((thisFrame = getCSLImageStructureAtPath(framePath)) == NULL) {
            sprintf(ertex, "mergeFrameInfo : Input frame is not a .csl image\n---> %s", framePath) ;
            ase(ertex) ;
        }

        sprintf(accessPath, "%s/Frame%1d.csl/Info/SLCImageInfo.txt", imageContainer->dataDirectoryPath, frameIndex) ;
        frameInfo = readInfoImageFromTextFile(accessPath) ;
        if (adaptPolScheme) {
            freeCSVStruct(frameInfo->polScheme) ;
            sprintf(frameInfo->polMode, "%s", selectedPolarizations) ;
            frameInfo->polScheme = readCSVInString(frameInfo->polMode) ;
        }

        S1FrameSpecific = initS1SpecificInfo(frameInfo, framePath) ;
        updateFrameIndexOfBursts(S1FrameSpecific, frameIndex) ;
        readBurstSelectionInCSLImage(thisFrame, frameInfo) ;

        /* Join burst lists */
        for (swathIndex = 0; swathIndex < S1Specific->numberOfSubSwaths; swathIndex++) {
            lastBurst = getLastBurstInList(S1Specific->burstList[swathIndex]) ;
            firstBurst = S1FrameSpecific->burstList[swathIndex] ;
            lastBurst->nextBurst = firstBurst ;
            firstBurst->preceedingBurst = lastBurst ;
        }

        /* Join state vector list */
        /* First, count number of state vectors in new list */
        numberOfStateVectors = imageInfo->nVect ;
        lastStateVector = imageInfo->S + (numberOfStateVectors - 1) ;
        iY2 = -1 ;
        for (iY1 = 0; iY1 < frameInfo->nVect; iY1++) {
            if (lastStateVector->t >= frameInfo->S[iY1].t) {
                iY2 = iY1 ;
            }
            else
                numberOfStateVectors ++ ;
        }
        newStateVectorList = allocVectorOfStateVectorsOfLength(numberOfStateVectors) ;
        for (iY1 = 0; iY1 < numberOfStateVectors; iY1++) {
            if (iY1 < imageInfo->nVect) {
                copyStateVect(imageInfo->S + iY1, newStateVectorList + iY1) ;
            }
            else {
                iY2++ ;
                copyStateVect(frameInfo->S + iY2, newStateVectorList + iY1) ;
            }
        }
        freeVectorOfStateVectorsOfLength(imageInfo->S, imageInfo->nVect) ;
        imageInfo->S = newStateVectorList ;
        imageInfo->nVect = numberOfStateVectors ;
        orbitTypeID *= (isSubStringPresentInString(imageInfo->orbitTypeID, "Precise"))? 2 : (isSubStringPresentInString(imageInfo->orbitTypeID, "Restituted"))? 1 : 0 ;

        openBurstFilesForReadingAndWriting(thisFrame, frameInfo) ;

        free(framePath) ;
        freeS1Specific(S1FrameSpecific, _S1_KEEP_BURSTS_) ;
        freeInfoImage(frameInfo) ;
        freeCSLImageStructure(thisFrame) ;
    }
    
    free(imageInfo->orbitTypeID) ;
    if (!orbitTypeID) {
        imageInfo->orbitTypeID = initStringWithString("Preliminary orbit") ;
    }
    else {
        if (orbitTypeID == 2 * numberOfFrames) {
            imageInfo->orbitTypeID = initStringWithString("Precise orbit") ;
        }
        else {
            imageInfo->orbitTypeID = initStringWithString("Restituted orbit") ;                  
        }
    }
    
    orderBurstInImage(S1Specific) ;
    freeOrbitInterpolation(imageInfo) ;
    updateSpecificFieldsForSelectedBursts(imageInfo) ;
    freeCSLImageStructure(thisImage) ;

    return (imageInfo) ;
}


void S1FilePathTimeOrdering(CSVStruct *S1FilePath)
{
    char *time1, *time2 ;
    char test ;
    int i, pos ;

    do {
        test = 0 ; 
        for (i = 0; i < S1FilePath->numberOfEntries - 1; i += 2) {
            pos = locateSubStringInString(S1FilePath->stringVal[i], "_SLC__") ;
            time1 = S1FilePath->stringVal[i] + pos + 20 ;
            pos = locateSubStringInString(S1FilePath->stringVal[i + 1], "_SLC__") ;
            time2 = S1FilePath->stringVal[i + 1] + pos + 20 ;
            if (strncmp(time1, time2, 6) < 0) {
                time1 = S1FilePath->stringVal[i] ;
                S1FilePath->stringVal[i] = S1FilePath->stringVal[i + 1] ;
                S1FilePath->stringVal[i + 1] = time1 ;
                test = 1 ;
            }
        }
        
        for (i = 1; i < S1FilePath->numberOfEntries - 1; i += 2) {
            pos = locateSubStringInString(S1FilePath->stringVal[i], "_SLC__") ;
            time1 = S1FilePath->stringVal[i] + pos + 20 ;
            pos = locateSubStringInString(S1FilePath->stringVal[i + 1], "_SLC__") ;
            time2 = S1FilePath->stringVal[i + 1] + pos + 20 ;
            if (strncmp(time1, time2, 6) < 0) {
                time1 = S1FilePath->stringVal[i] ;
                S1FilePath->stringVal[i] = S1FilePath->stringVal[i + 1] ;
                S1FilePath->stringVal[i + 1] = time1 ;
                test = 1 ;
            }
        }
    } while (test) ;
}


S1BurstSelection *getS1BurstSelectionForImage(CSLImage *refImage)
{
    char *kmlDir, *aPath, ***burstPath ;
    char aKey[32] ;
    int i ;
    int firstSwathIndex, lastSwathIndex, numberOfSwaths, swathIndex ;
    int *firstBurstIndex, *lastBurstIndex, *numberOfBursts, burstIndex ;
    keyValue *burstSelection ;
    CSVStruct *refPol, *burstList, *kmlFileName ;
    point2D **refPoint ;
    polygon ***aoi, *aoi2 ;
    S1BurstSelection *imageBurstSelection ;

    imageBurstSelection = malloc(sizeof(imageBurstSelection[0])) ;

    /* List available kml files */
    kmlDir = initStringWith2Strings(refImage->infoDirectoryPath, "/PerBurstInfo") ;
    kmlFileName = listFilesWithExtensionInDir(".kml", kmlDir) ;

    /* Get burst selection and read required parameters */
    aPath = initStringWith2Strings(refImage->infoDirectoryPath, "/burstSelection.txt") ;
    burstSelection = readParameterFileAtPath(aPath) ;
    free(aPath) ;

    imageBurstSelection->refPol = refPol = readCSVInString(getStringValForKeyIn(burstSelection, "Polarization")) ;
    imageBurstSelection->firstSwathIndex = firstSwathIndex = getIntValForKeyIn(burstSelection, "First swath index") ;
    imageBurstSelection->lastSwathIndex = lastSwathIndex = getIntValForKeyIn(burstSelection, "Last swath index") ;
    imageBurstSelection->numberOfSwath = numberOfSwaths = lastSwathIndex -firstSwathIndex + 1 ;
    imageBurstSelection->totalNumberOfBursts = 0 ;

    /* Allocation */
    if ((refPoint = malloc(numberOfSwaths * sizeof(refPoint[0]))) == NULL) {
        ase("\t-/-> Failed to allocate burst reference points\n\n") ;
    }
    refPoint -= firstSwathIndex ;
    imageBurstSelection->refPoint = refPoint ;

    if ((aoi = malloc(numberOfSwaths * sizeof(aoi[0]))) == NULL) {
        ase("\t-/-> Failed to allocate burst aoi\n\n") ;
    }
    aoi -= firstSwathIndex ;
    imageBurstSelection->aoi = aoi ;

    if ((burstPath = malloc(numberOfSwaths * sizeof(burstPath[0]))) == NULL) {
        ase("\t-/-> Failed to allocate burst path\n\n") ;
    }
    burstPath -= firstSwathIndex ;
    imageBurstSelection->burstPath = burstPath ;

    imageBurstSelection->firstBurstIndex = firstBurstIndex = vectorInt(firstSwathIndex, lastSwathIndex) ;
    imageBurstSelection->lastBurstIndex = lastBurstIndex = vectorInt(firstSwathIndex, lastSwathIndex) ;
    imageBurstSelection->numberOfBursts = numberOfBursts = vectorInt(firstSwathIndex, lastSwathIndex) ;


    /* Get burst aoi and reference points */
    for (swathIndex = firstSwathIndex; swathIndex <= lastSwathIndex; swathIndex++) {
        sprintf(aKey, "Swath %1d burst selection", swathIndex) ;
        if((burstList = getCSVValForKeyIn(burstSelection, aKey)) == NULL) {
            ase("Failed to read burst selection\n") ;
        }
        sscanf(burstList->stringVal[0], "%d", firstBurstIndex + swathIndex) ;
        sscanf(burstList->stringVal[burstList->numberOfEntries - 1], "%d", lastBurstIndex + swathIndex) ;
        numberOfBursts[swathIndex] = lastBurstIndex[swathIndex] - firstBurstIndex[swathIndex] + 1 ;
        
        if ((refPoint[swathIndex] = malloc(burstList->numberOfEntries * sizeof(refPoint[swathIndex][0]))) == NULL) {
            ase("\t-/-> Failed to allocate burst reference points\n\n") ;
        }
        refPoint[swathIndex] -= firstBurstIndex[swathIndex] ;

        if ((aoi[swathIndex] = malloc(burstList->numberOfEntries * sizeof(aoi[swathIndex][0]))) == NULL) {
            ase("\t-/-> Failed to allocate burst aoi\n\n") ;
        }
        aoi[swathIndex] -= firstBurstIndex[swathIndex] ;

        if ((burstPath[swathIndex] = malloc(burstList->numberOfEntries * sizeof(burstPath[swathIndex][0]))) == NULL) {
            ase("\t-/-> Failed to allocate burst path\n\n") ;
        }
        burstPath[swathIndex] -= firstBurstIndex[swathIndex] ;

        for (burstIndex = firstBurstIndex[swathIndex]; burstIndex <= lastBurstIndex[swathIndex]; burstIndex++) {
            sprintf(aKey, "/SW%db%d.csl", swathIndex, burstIndex) ;
            burstPath[swathIndex][burstIndex] = initStringWith2Strings(refImage->dataDirectoryPath, aKey) ;

            sprintf(aKey, "_swath%d.burst%d.kml", swathIndex, burstIndex) ;
            i = 0 ; 
            while (!isSubStringPresentInString(kmlFileName->stringVal[i], aKey) && i < kmlFileName->numberOfEntries) {
                i++ ;
            }
            if (i == kmlFileName->numberOfEntries) {
                printf("Burst kml file not found \n") ;
                free(kmlDir) ;
                freeCSVStruct(kmlFileName) ;
                freeKeyValueList(burstSelection) ;
                freeS1BurstSelection(imageBurstSelection) ;
                return NULL ;
            }
            aPath = kmlFileName->stringVal[i] ;
            
//            printf("%s\n", aPath) ;
            /* Get burst aoi */
            aoi[swathIndex][burstIndex] = getPolygonalAoIFromKMLFile(aPath) ;

            /* Compute central point of burst aoi in lon-lat coordinates */
            aoi2 = getRectangularAoIFromKMLFile(aPath) ;
            refPoint[swathIndex][burstIndex].p.x = (aoi2->P[0].x + aoi2->P[1].x) / 2 ;
            refPoint[swathIndex][burstIndex].p.y = (aoi2->P[0].y + aoi2->P[3].y) / 2 ;
            freePolygon(aoi2) ;
//            printf("Reference point burst %d swath %d = (%7.3f ; %7.3f) \n", burstIndex, swathIndex, refPoint[swathIndex][burstIndex].p.x, refPoint[swathIndex][burstIndex].p.y) ;

            removeStringValAtIndexInCSVStruct(i, kmlFileName) ;
        }

        freeCSVStruct(burstList) ;
    }

    free(kmlDir) ;
    freeCSVStruct(kmlFileName) ;
    freeKeyValueList(burstSelection) ;

    return (imageBurstSelection) ;
}

void freeS1BurstSelection (S1BurstSelection *imageBurstSelection)
{
    int swathIndex, burstIndex ;
    int numberOfSwaths ;

    numberOfSwaths = imageBurstSelection->lastSwathIndex - imageBurstSelection->firstSwathIndex + 1 ;
    for (swathIndex = imageBurstSelection->firstSwathIndex; swathIndex < numberOfSwaths; swathIndex++) {
        for (burstIndex = imageBurstSelection->firstBurstIndex[swathIndex]; burstIndex <= imageBurstSelection->lastBurstIndex[swathIndex]; burstIndex++) {
            freePolygon(imageBurstSelection->aoi[swathIndex][burstIndex]) ; 
            free(imageBurstSelection->burstPath[swathIndex][burstIndex]) ;
        }
        free(imageBurstSelection->refPoint[swathIndex] + imageBurstSelection->firstBurstIndex[swathIndex]) ;
        free(imageBurstSelection->aoi[swathIndex] + imageBurstSelection->firstBurstIndex[swathIndex]) ;
        free(imageBurstSelection->burstPath[swathIndex] + imageBurstSelection->firstBurstIndex[swathIndex]) ;
    }
    free(imageBurstSelection->refPoint + imageBurstSelection->firstSwathIndex) ;
    free(imageBurstSelection->aoi + imageBurstSelection->firstSwathIndex) ;
    free(imageBurstSelection->burstPath + imageBurstSelection->firstSwathIndex) ;
    freeVectorInt(imageBurstSelection->numberOfBursts, imageBurstSelection->firstSwathIndex) ;
    freeVectorInt(imageBurstSelection->lastBurstIndex, imageBurstSelection->firstSwathIndex) ;
    freeVectorInt(imageBurstSelection->firstBurstIndex, imageBurstSelection->firstSwathIndex) ;

    free(imageBurstSelection) ;
}
