/* 
*  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public (AGPL) License
 *  as published by the Free Software Foundation, either version 3
 *  of the License, or any later version. 
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 * 
 *  You should have received a copy of the GNU Affero General Public License 
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


/**************************************************
 * File name : BIOMASSDataReaderLib.c
 * Author : Dominique Derauw
 * Date : 2026-06-18
 * Copyright 2026 Dominique Derauw
 * Description : 
 **************************************************/


#include <stdio.h>
#include "BIOMASSDataReader.h"


CSVStruct *BIOMASSDataReader(CSVStruct *csv) 
{
    char *aString, *pol, *outputDir = NULL ;
    char *containerPath, *aPath ;
    int unsigned flag = 0 ;
    int i, polIndex ;
    CSVStruct *imageList ;
    CSVStruct *savedImages = NULL ;
    SLCImageInfo *info ;
    CSLImage *imageContainer ;


    if (csv->numberOfEntries == 1  || isArgumentPresentInCSV(csv, "-h")) {
        biomassDataReaderHelp () ;
    }

    printf("\nBIOMASSDataReader\n") ;

    aString = getValForKeyInCSV(csv, "P=") ;
    polIndex = 4 ;
    if (aString) {
        polIndex = 0 ;
        while (strncmp(aString, polScheme[polIndex], 2) && polIndex < 4) {
            polIndex++ ;
        }
    }

    
    flag |= (isFlagPresentInCSV(csv, "f"))? _FORCE_READING_ : flag ;
    flag |= (isFlagPresentInCSV(csv, "a"))? _SAVE_MOD_PHI_LAYERS_ : flag ;

    /* Select output directory as the second directory given as parameter*/
    for (i = 2; i < csv->numberOfEntries; i++) {
        if (isDir(csv->stringVal[i])) {
            outputDir = initStringWithString(csv->stringVal[i]) ;
            break ;
        }
    }

    /* List all available BIOMASS scene within input directory */
    if (!isDir(csv->stringVal[1])) {
        ase("\t-/-> First parameter must be the path to BIOMASS image(s) directory\n\n") ;
    }

    printf("\t---> Searching BIOMASS data in %s\n", csv->stringVal[1]) ;
    imageList = recursiveSearchOfDirInDir("_SCS__1S", csv->stringVal[1]);

    /* If no BIOMASS directories found, first parameter may be an image itself */
    if (!imageList) {
        if (isSubStringPresentInString(csv->stringVal[1], "_SCS__1S")) {
            imageList = addStringValInCSVStruct(csv->stringVal[1], imageList) ;
            /* If output directory was not given in command line and if we deal with an uncompressed single image, select upper directory as output one */
            if (!outputDir) {
                outputDir = getDirectoryPathFromPath(csv->stringVal[1]) ;
            }
        }
    }
    if (!imageList) {
        ase("\t-/-> No BIOMASS SLC images found. Nothing to read\n") ;
    }
    printf("\t---> %d BIOMASS image directories found\n", imageList->numberOfEntries) ;

    /* If output directory still not set, select it as the directory that contains the images to be read */
    if (!outputDir) {
        outputDir = initStringWithString(csv->stringVal[1]) ;
    }
    /* Verify write acces is granted at destination directory */
    if (!isWriteAccessGrantedAtPath(outputDir)) {
        ase("\t\t-/-> Write acces is not granted at destination directory; Stopping here.") ;
    }
    printf("\t---> Will save read data in %s\n\n", outputDir) ;

    for (i = 0; i < imageList->numberOfEntries; i++) {
        info = createSLCImageInfoForBIOMASSData(imageList->stringVal[i], pol) ;
        sprintf(accessPath, "BIO_%d_%.8s_%.1s.csl", info->relativeOrbitNumber, info->acquisitionDate, info->heading) ;
        containerPath = initStringWith3Strings(outputDir, "/", accessPath) ;
        if (flag & _FORCE_READING_) {
            removeDirectoryAtPath(containerPath) ;
        }
        
        if (!isCSLImageAtPath(containerPath)) {
            imageContainer = createCSLDirectoryStructureAtPath(containerPath, __BIOMASS1__) ;
            aPath = initStringWith2Strings(imageContainer->infoDirectoryPath, "/SLCImageInfo.txt") ;
            saveInfoImage(info, aPath) ;
            free(saveInfoKmlInDir(info, imageContainer->infoDirectoryPath)) ;
            free(aPath) ;

            printf("\t---> Reading %s\n\t---> Saving it as %s\n\n", imageList->stringVal[i], imageContainer->imageDirectoryPath) ;
            readBIOMASSData(imageList->stringVal[i], imageContainer, polIndex, flag) ;
            savedImages = addStringValInCSVStruct(imageContainer->imageDirectoryPath, savedImages) ;
            freeCSLImageStructure(imageContainer) ;
        }
        else {
            printf("\t---> Skip reading. Image already present at output path\n") ;
        }
        freeInfoImage(info) ;
        free(containerPath) ;
    }
    
    freeCSVStruct(imageList) ;
    free(outputDir) ;
    return (savedImages) ;
}

void biomassDataReaderHelp(void)
{
    printf("BIOMASSDataReader:\n") ;
    printf("Usage: BIOMASSDataReader inputDirectory [outputDirectory] [P=XX] [-fa]\n") ;
    printf("inputDirectory is the path to a BIOMASS image directory or to a directory containing BIOMASS images\n") ;
    printf("outputDirectory: If not given, .csl formatted images will be saved within inputDirectory\n") ;
    printf("By default, all available polarizations are read. If willing to limit to a single pol scheme, use option P=XX (with XX ==, HH, HV, VH or VV)\n") ;
    printf("-a : Amplitude and phase files are saved in line with SLCData complex float version of the image\n") ;
    printf("-f : Force rereading trashing and replacing existing images\n") ;
    exit(0) ;
}


void readBIOMASSData(char *inputDirectory, CSLImage *thisImage, int polIndex, int flag)
{
    char *tiffDir ;
    char *outputPath  ;
    int i, i0, imax, k, l ;
    int xDim, yDim, xDimTile, yDimTile ;
    int iXTile, iYTile ;
    float **mod, **phi ;
    complexFloat **slc ;
    CSVStruct *modTiff, *phaseTiff ;
    tileTool *modTileTool, *phiTileTool, *slcTileTool ;
    tiffFileDescriptor *desc ;
    rawFileDescriptor *slcOutputFile, *modOutputFile, *phiOutputFile ;
    lercTiffTileDecoder *modDec, *phiDec ;

    tiffDir = initStringWith2Strings(inputDirectory, "/measurement") ;
    modTiff = listFilesWithNameInDir("_i_abs.tiff", tiffDir) ;
    modDec = allocAndInitLERCTileDecoder(modTiff->stringVal[0]) ;
    phaseTiff = listFilesWithNameInDir("_i_phase.tiff", tiffDir) ;
    phiDec = allocAndInitLERCTileDecoder(phaseTiff->stringVal[0]) ;
    free(tiffDir) ;
    freeCSVStruct(modTiff) ;
    freeCSVStruct(phaseTiff) ;

    desc = modDec->desc ;
    xDim = modDec->xDim ;
    yDim = modDec->yDim ;
    xDimTile = modDec->xDimTile ;
    yDimTile = modDec->yDimTile ;

    outputPath = initStringWith2Strings(thisImage->headersDirectoryPath, "/GDAL_METADATA.txt") ;
    slcOutputFile = openRawFileForReadingAndWritingAtPath(outputPath) ;
    fprintf(slcOutputFile->f, "%s", modDec->GDAL) ;
    fprintf(slcOutputFile->f, "\n\n%s", phiDec->GDAL) ;
    freeRawFileDescriptor(slcOutputFile) ;
    free(outputPath) ;

    i0 = (polIndex == 4)? 0 : polIndex ;
    imax = (polIndex == 4)? 3 : polIndex ;
    
    for (i = i0; i <= imax; i++) {
        outputPath = initStringWith3Strings(thisImage->dataDirectoryPath, "/SLCData.", (char *)polScheme[i]) ;
        slcOutputFile = openRawFileForReadingAndWritingAtPath(outputPath) ;
        setRawFileDimensions(slcOutputFile, xDim, yDim) ;
        modOutputFile = phiOutputFile = slcOutputFile ;
        free(outputPath) ;
        
        if (flag & _SAVE_MOD_PHI_LAYERS_) {
            outputPath = initStringWith3Strings(thisImage->dataDirectoryPath, "/mod.", (char *)polScheme[i]) ;
            modOutputFile = openRawFileForReadingAndWritingAtPath(outputPath) ;
            setRawFileDimensions(modOutputFile, xDim, yDim) ;
            free(outputPath) ;
            outputPath = initStringWith3Strings(thisImage->dataDirectoryPath, "/phi.", (char *)polScheme[i]) ;
            phiOutputFile = openRawFileForReadingAndWritingAtPath(outputPath) ;
            setRawFileDimensions(phiOutputFile, xDim, yDim) ;
            free(outputPath) ;
        }
        
        modTileTool = allocTileToolForFilesOfType(modOutputFile, modOutputFile, "float") ;
        initTileToolWithSizes(modTileTool, xDimTile, yDimTile, 0, 0) ;
        modTileTool->flag |= _WITH_ZERO_PADDING_ ; 
        modDec->outputTile = modTileTool->tile[0] ;
        mod = modTileTool->tile ;

        phiTileTool = allocTileToolForFilesOfType(phiOutputFile, phiOutputFile, "float") ;
        initTileToolWithSizes(phiTileTool, xDimTile, yDimTile, 0, 0) ;
        phiTileTool->flag |= _WITH_ZERO_PADDING_ ; 
        phiDec->outputTile = phiTileTool->tile[0] ;
        phi = phiTileTool->tile ;
        
        slcTileTool = allocTileToolForFilesOfType(slcOutputFile, slcOutputFile, "complexFloat") ;
        initTileToolWithSizes(slcTileTool, xDimTile, yDimTile, 0, 0) ;
        slcTileTool->flag |= _WITH_ZERO_PADDING_ ; 
        slc = slcTileTool->tile ;

        for (iYTile = 0; iYTile < modTileTool->yTileNumber; iYTile++) {
            for (iXTile = 0; iXTile < modTileTool->xTileNumber; iXTile++) {
                updateTileToolForIndexes(modTileTool, iXTile, iYTile) ;
                updateTileToolForIndexes(phiTileTool, iXTile, iYTile) ;
                updateTileToolForIndexes(slcTileTool, iXTile, iYTile) ;

                decodeLERCTileAtIndex(modDec, iXTile, iYTile, i) ;
                decodeLERCTileAtIndex(phiDec, iXTile, iYTile, i) ;

                for (k = 0; k < modDec->yDimTile; k++) {
                    for (l = 0; l < modDec->yDimTile; l++) {
                        slc[k][l].r = mod[k][l] * cosf(phi[k][l]) ;
                        slc[k][l].i = mod[k][l] * sinf(phi[k][l]) ;
                    }
                }
                
                writeTile(slcTileTool) ;
                if (flag & _SAVE_MOD_PHI_LAYERS_) {
                    writeTile(modTileTool) ;
                    writeTile(phiTileTool) ;
                }
            }
        }
        
        freeTileTool(modTileTool) ;
        freeTileTool(phiTileTool) ;
        freeTileTool(slcTileTool) ;

        freeRawFileDescriptor(slcOutputFile) ;
        if (flag & _SAVE_MOD_PHI_LAYERS_) {
            freeRawFileDescriptor(modOutputFile) ;
            freeRawFileDescriptor(phiOutputFile) ;
        }
    }

    freeLERCDecoder(modDec) ;
    freeLERCDecoder(phiDec) ;
}



lercTiffTileDecoder *allocAndInitLERCTileDecoder(char *tiffFilePath) 
{
    tiffTag *aTag ;
    tiffFileDescriptor *desc ;
    lercTiffTileDecoder *decoder ;

    if (!(decoder = malloc(sizeof(decoder[0])))) {
        ase("\t-/-> Failed to allocate lerc decoder.\n") ;
    }

    desc = decoder->desc =  parseTiffFileAtPath(tiffFilePath) ;
    
    aTag = getDataForTagInTiff(desc, TIFFTAG_IMAGEWIDTH, &(decoder->xDim)) ;
    aTag = getDataForTagInTiff(desc, TIFFTAG_IMAGELENGTH, &(decoder->yDim)) ;
    aTag = getDataForTagInTiff(desc, TIFFTAG_TILEWIDTH, &(decoder->xDimTile)) ;
    aTag = getDataForTagInTiff(desc, TIFFTAG_TILELENGTH, &(decoder->yDimTile)) ;
    aTag = getDataForTagInTiff(desc, TIFFTAG_TILEOFFSETS, &(decoder->tileOffset)) ;
    aTag = getDataForTagInTiff(desc, TIFFTAG_TILEBYTECOUNTS, &(decoder->tileByteCount)) ;
    aTag = getDataForTagInTiff(desc, TIFFTAG_SAMPLEFORMAT, &(decoder->sampleFormat)) ;
    aTag = getDataForTagInTiff(desc, TIFFTAG_GDAL_METADATA, &(decoder->GDAL)) ;
    aTag = getDataForTagInTiff(desc, TIFFTAG_GDAL_NODATA, &(decoder->noVal)) ;
    aTag = getDataForTagInTiff(desc, TIFFTAG_LERC_PARAMETERS, &(decoder->lercParameters)) ;

    decoder->xTileNumber = (decoder->xDim + (decoder->xDimTile + 1)) / decoder->xDimTile ;
    decoder->yTileNumber = (decoder->yDim + (decoder->yDimTile + 1)) / decoder->yDimTile ;
    decoder->tileShift = decoder->xTileNumber * decoder->yTileNumber ;
    decoder->tileByteSize = decoder->xDimTile * (decoder->yDimTile + 1) * 4 ;
    if(!(decoder->buffer = malloc(decoder->tileByteSize))) {
        ase("\t-/-> Failed to allocate decompression buffer.\n") ;
    } 

    return (decoder) ;
}

void freeLERCDecoder(lercTiffTileDecoder *dec) 
{
    free(dec->buffer) ;
    freeTiffFileDescriptor(dec->desc) ;
    free(dec) ;
}

float *decodeLERCTileAtIndex(lercTiffTileDecoder *dec, int iXTile, int iYtile, int layerIndex)
{
    char unsigned *compressedTile, *buffer, noDataUse = 0, *lercMask ;
    int tileIndex, zRet ;
    int unsigned *lercInfo, lercMaskNumber ;
    unsigned long long zstdDecompressedSize ;
    double noDataVal = 0.0 ;
    size_t tileByteSize, offset, byteCount ;
    size_t lercSize ;    rawFileDescriptor *tiffFile ;
    z_stream zs ;
    lerc_status lercStatus ;

    dec->layerIndex = layerIndex ;
    tileIndex = layerIndex * dec->tileShift + iYtile * dec->xTileNumber + iXTile ;
    offset = dec->tileOffset[tileIndex] ;
    byteCount = dec->tileByteCount[tileIndex] ;
    tiffFile = dec->desc->tiffFile ;
    buffer = dec->buffer ;

    if (!(compressedTile = malloc(byteCount))) {
        ase("\t-/-> Failed to allocate compressed tile.\n") ;
    }
                
    if (fseek(tiffFile->f, offset, SEEK_SET)) {
        ase("\t-/-> Failed to seek into tiff file\n") ;
    }
    if (fread(compressedTile, 1, byteCount, tiffFile->f) != byteCount) {
        ase("\t -/-> Failed to read compressed tile in tiff file\n") ;
    }

    if (dec->lercParameters[1] == LERC_ADD_COMPRESSION_ZSTD) {
        zstdDecompressedSize = ZSTD_getFrameContentSize(compressedTile, byteCount) ;
        if (zstdDecompressedSize == ZSTD_CONTENTSIZE_UNKNOWN || zstdDecompressedSize == ZSTD_CONTENTSIZE_ERROR) {
            ase("\t-/-> Something gose wrong in tile ZSTD decompression. Failed to determine decompressed size.\n") ;
        }
        tileByteSize = (size_t)zstdDecompressedSize ;
        lercSize = ZSTD_decompress(buffer, tileByteSize, compressedTile, byteCount) ;
        if (ZSTD_isError(lercSize)) {
            ase("\t-/-> Failed to ZSTD decompress tile\n") ;
        }
    }
    if (dec->lercParameters[1] == LERC_ADD_COMPRESSION_DEFLATE) {
        memset(&zs, 0, sizeof(zs)) ;
        zs.next_in = compressedTile ;
        zs.avail_in = byteCount ;
        zs.next_out = buffer ;
        zs.avail_out = tileByteSize ;
        if (inflateInit(&zs) != Z_OK) {
            ase("\t-/-> Failed to initializs Z decompress.\n") ;
        }
        zRet = inflate(&zs, Z_FINISH) ;
        inflateEnd(&zs) ;
        if (zRet != Z_STREAM_END && zRet != Z_OK) {
            ase("\t-/-> Failed to Z decompress tile.\n") ;
        }
        lercSize = tileByteSize - zs.avail_out ;
    }
    lercInfo = vectorIntUnsigned(0, 9) ;
    lercStatus = lerc_getBlobInfo((const char unsigned *)buffer, (int unsigned)lercSize, lercInfo, NULL, 10, 0) ;
    if (lercStatus) {
        ase("\t-/- Failed to initialize LERC decompression.\n") ;
    }
    lercMask = NULL ;
    if (lercInfo[8] > 0) {
        lercMask = malloc((size_t)(lercInfo[3] * lercInfo[4] * lercInfo[8])) ;
    }

    lercStatus = lerc_decode_4D(
        (const char unsigned *)buffer, 
        (int unsigned)lercSize, 
        (int)lercInfo[8], 
        lercMask, 
        1, 
        (int)lercInfo[3], 
        (int)lercInfo[4], 
        1, 
        6, 
        (void *)dec->outputTile, 
        &noDataUse, 
        &noDataVal
    ) ;

    if (lercMask) {
        free(lercMask) ;
    }

    freeVectorIntUnsigned(lercInfo, 0) ;
    free(compressedTile) ;

    return (dec->outputTile) ;
}